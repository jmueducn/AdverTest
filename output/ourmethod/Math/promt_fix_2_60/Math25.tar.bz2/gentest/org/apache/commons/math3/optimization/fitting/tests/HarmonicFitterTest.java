package gentest.org.apache.commons.math3.optimization.fitting.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.fitting.*;
import org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer;
import org.apache.commons.math3.analysis.function.HarmonicOscillator;
import org.apache.commons.math3.exception.ZeroException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.MathIllegalStateException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
 
public class HarmonicFitterTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

       @Test
                                                                                                                                                  public void testGuessAOmega_WithValidObservations() {
                                                                                                                                                      // Setup
                                                                                                                                                      DifferentiableMultivariateVectorOptimizer optimizer = mock(DifferentiableMultivariateVectorOptimizer.class);
                                                                                                                                                      HarmonicFitter fitter = new HarmonicFitter(optimizer);
                                                                                                                                                      
                                                                                                                                                      WeightedObservedPoint[] observations = new WeightedObservedPoint[4];
                                                                                                                                                      observations[0] = new WeightedObservedPoint(1.0, 0.0, 1.0);
                                                                                                                                                      observations[1] = new WeightedObservedPoint(2.0, 1.0, 1.0);
                                                                                                                                                      observations[2] = new WeightedObservedPoint(3.0, 0.0, 1.0);
                                                                                                                                                      observations[3] = new WeightedObservedPoint(4.0, -1.0, 1.0);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to set private observations field
                                                                                                                                                      try {
                                                                                                                                                          java.lang.reflect.Field field = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                                          field.setAccessible(true);
                                                                                                                                                          field.set(fitter, observations);
                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                          fail("Failed to set observations field via reflection");
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      // Execute
                                                                                                                                                      try {
                                                                                                                                                          java.lang.reflect.Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                                          method.setAccessible(true);
                                                                                                                                                          method.invoke(fitter);
                                                                                                                                                          
                                                                                                                                                          // Verify
                                                                                                                                                          java.lang.reflect.Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                                                                          aField.setAccessible(true);
                                                                                                                                                          double a = aField.getDouble(fitter);
                                                                                                                                                          
                                                                                                                                                          java.lang.reflect.Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                                                                                                                          omegaField.setAccessible(true);
                                                                                                                                                          double omega = omegaField.getDouble(fitter);
                                                                                                                                                          
                                                                                                                                                          assertEquals(1.0, a, 0.01);
                                                                                                                                                          assertEquals(Math.PI/2, omega, 0.01);
                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                          fail("Exception occurred during test: " + e.getMessage());
                                                                                                                                                      }
                                                                                                                                                  }

 @Test
                                                                                                                                                  public void testGuessAOmega_WithSingleObservation_ThrowsZeroException() {
                                                                                                                                                      // Setup
                                                                                                                                                      DifferentiableMultivariateVectorOptimizer optimizer = mock(DifferentiableMultivariateVectorOptimizer.class);
                                                                                                                                                      HarmonicFitter fitter = new HarmonicFitter(optimizer);
                                                                                                                                                      
                                                                                                                                                      WeightedObservedPoint[] observations = new WeightedObservedPoint[1];
                                                                                                                                                      observations[0] = new WeightedObservedPoint(1.0, 0.0, 1.0);
                                                                                                                                                      
                                                                                                                                                      try {
                                                                                                                                                          java.lang.reflect.Field field = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                                          field.setAccessible(true);
                                                                                                                                                          field.set(fitter, observations);
                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                          fail("Failed to set observations field via reflection");
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      // Expect exception
                                                                                                                                                      thrown.expect(ZeroException.class);
                                                                                                                                                      
                                                                                                                                                      // Execute
                                                                                                                                                      try {
                                                                                                                                                          java.lang.reflect.Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                                          method.setAccessible(true);
                                                                                                                                                          method.invoke(fitter);
                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                          if (e.getCause() instanceof ZeroException) {
                                                                                                                                                              throw (ZeroException) e.getCause();
                                                                                                                                                          }
                                                                                                                                                          fail("Unexpected exception: " + e.getMessage());
                                                                                                                                                      }
                                                                                                                                                  }

 @Test
                                                                                                                                                  public void testGuessAOmega_WithZeroRange_ThrowsZeroException() {
                                                                                                                                                      // Setup
                                                                                                                                                      DifferentiableMultivariateVectorOptimizer optimizer = mock(DifferentiableMultivariateVectorOptimizer.class);
                                                                                                                                                      HarmonicFitter fitter = new HarmonicFitter(optimizer);
                                                                                                                                                      
                                                                                                                                                      WeightedObservedPoint[] observations = new WeightedObservedPoint[2];
                                                                                                                                                      observations[0] = new WeightedObservedPoint(1.0, 0.0, 1.0);
                                                                                                                                                      observations[1] = new WeightedObservedPoint(1.0, 1.0, 1.0); // Same x value
                                                                                                                                                      
                                                                                                                                                      try {
                                                                                                                                                          java.lang.reflect.Field field = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                                          field.setAccessible(true);
                                                                                                                                                          field.set(fitter, observations);
                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                          fail("Failed to set observations field via reflection");
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      // Expect exception
                                                                                                                                                      thrown.expect(ZeroException.class);
                                                                                                                                                      
                                                                                                                                                      // Execute
                                                                                                                                                      try {
                                                                                                                                                          java.lang.reflect.Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                                          method.setAccessible(true);
                                                                                                                                                          method.invoke(fitter);
                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                          if (e.getCause() instanceof ZeroException) {
                                                                                                                                                              throw (ZeroException) e.getCause();
                                                                                                                                                          }
                                                                                                                                                          fail("Unexpected exception: " + e.getMessage());
                                                                                                                                                      }
                                                                                                                                                  }

 @Test
                                                                                                                                                  public void testGuessAOmega_WithIllConditionedData_ThrowsMathIllegalStateException() {
                                                                                                                                                      // Setup
                                                                                                                                                      DifferentiableMultivariateVectorOptimizer optimizer = mock(DifferentiableMultivariateVectorOptimizer.class);
                                                                                                                                                      HarmonicFitter fitter = new HarmonicFitter(optimizer);
                                                                                                                                                      
                                                                                                                                                      // Create data that will cause c2 to be zero
                                                                                                                                                      WeightedObservedPoint[] observations = new WeightedObservedPoint[3];
                                                                                                                                                      observations[0] = new WeightedObservedPoint(0.0, 1.0, 1.0);
                                                                                                                                                      observations[1] = new WeightedObservedPoint(1.0, 1.0, 1.0);
                                                                                                                                                      observations[2] = new WeightedObservedPoint(2.0, 1.0, 1.0); // Flat line
                                                                                                                                                      
                                                                                                                                                      try {
                                                                                                                                                          java.lang.reflect.Field field = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                                          field.setAccessible(true);
                                                                                                                                                          field.set(fitter, observations);
                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                          fail("Failed to set observations field via reflection");
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      // Expect exception
                                                                                                                                                      thrown.expect(MathIllegalStateException.class);
                                                                                                                                                      thrown.expectMessage("zero denominator");
                                                                                                                                                      
                                                                                                                                                      // Execute
                                                                                                                                                      try {
                                                                                                                                                          java.lang.reflect.Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                                          method.setAccessible(true);
                                                                                                                                                          method.invoke(fitter);
                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                          if (e.getCause() instanceof MathIllegalStateException) {
                                                                                                                                                              throw (MathIllegalStateException) e.getCause();
                                                                                                                                                          }
                                                                                                                                                          fail("Unexpected exception: " + e.getMessage());
                                                                                                                                                      }
                                                                                                                                                  }

 @Test
                                                                                                                                                  public void testGuessAOmega_WithNegativeCondition() {
                                                                                                                                                      // Setup
                                                                                                                                                      DifferentiableMultivariateVectorOptimizer optimizer = mock(DifferentiableMultivariateVectorOptimizer.class);
                                                                                                                                                      HarmonicFitter fitter = new HarmonicFitter(optimizer);
                                                                                                                                                      
                                                                                                                                                      // Create data that will trigger the c1/c2 < 0 or c2/c3 < 0 condition
                                                                                                                                                      WeightedObservedPoint[] observations = new WeightedObservedPoint[4];
                                                                                                                                                      observations[0] = new WeightedObservedPoint(0.0, 0.0, 1.0);
                                                                                                                                                      observations[1] = new WeightedObservedPoint(1.0, 1.0, 1.0);
                                                                                                                                                      observations[2] = new WeightedObservedPoint(2.0, -1.0, 1.0);
                                                                                                                                                      observations[3] = new WeightedObservedPoint(3.0, 1.0, 1.0);
                                                                                                                                                      
                                                                                                                                                      try {
                                                                                                                                                          java.lang.reflect.Field field = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                                          field.setAccessible(true);
                                                                                                                                                          field.set(fitter, observations);
                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                          fail("Failed to set observations field via reflection");
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      // Execute
                                                                                                                                                      try {
                                                                                                                                                          java.lang.reflect.Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                                          method.setAccessible(true);
                                                                                                                                                          method.invoke(fitter);
                                                                                                                                                          
                                                                                                                                                          // Verify
                                                                                                                                                          java.lang.reflect.Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                                                                          aField.setAccessible(true);
                                                                                                                                                          double a = aField.getDouble(fitter);
                                                                                                                                                          
                                                                                                                                                          java.lang.reflect.Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                                                                                                                          omegaField.setAccessible(true);
                                                                                                                                                          double omega = omegaField.getDouble(fitter);
                                                                                                                                                          
                                                                                                                                                          assertEquals(1.0, a, 0.01);
                                                                                                                                                          assertEquals(2*Math.PI/3.0, omega, 0.01);
                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                          fail("Exception occurred during test: " + e.getMessage());
                                                                                                                                                      }
                                                                                                                                                  }

 @Test
                                                                                                                                          public void testGuessAOmega_AmplitudeCalculation() throws Exception {
                                                                                                                                              // Create test observations that will trigger the condition
                                                                                                                                              // Using simple harmonic data with known amplitude
                                                                                                                                              WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                                                  new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight 1.0, x=0.0, y=0.0
                                                                                                                                                  new WeightedObservedPoint(1.0, Math.PI/2, 1.0),  // y=1.0
                                                                                                                                                  new WeightedObservedPoint(1.0, Math.PI, 0.0),    // y=0.0
                                                                                                                                                  new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0) // y=-1.0
                                                                                                                                              };
                                                                                                                                              
                                                                                                                                              // Create HarmonicFitter instance (optimizer doesn't matter for this test)
                                                                                                                                              HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                                                              
                                                                                                                                              // Use reflection to set the observations since they're private final
                                                                                                                                              Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                              observationsField.setAccessible(true);
                                                                                                                                              observationsField.set(fitter, observations);
                                                                                                                                              
                                                                                                                                              // Call the private method using reflection
                                                                                                                                              Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                              guessAOmega.setAccessible(true);
                                                                                                                                              guessAOmega.invoke(fitter);
                                                                                                                                              
                                                                                                                                              // Get the calculated amplitude using reflection
                                                                                                                                              Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                                                              aField.setAccessible(true);
                                                                                                                                              double calculatedA = aField.getDouble(fitter);
                                                                                                                                              
                                                                                                                                              // Expected amplitude is (yMax - yMin)/2 = (1.0 - (-1.0))/2 = 1.0
                                                                                                                                              // Mutant would calculate (1.0 + (-1.0))/2 = 0.0
                                                                                                                                              assertEquals("Amplitude calculation is incorrect", 
                                                                                                                                                           1.0, calculatedA, 1e-10);
                                                                                                                                          }

 @Test
                                                                                                                                         public void testGuessAOmega_AmplitudeCalculation1() throws Exception {
                                                                                                                                             // Create test observations that will trigger the condition (c1/c2 < 0)
                                                                                                                                             WeightedObservedPoint[] observations = {
                                                                                                                                                 new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight doesn't matter here
                                                                                                                                                 new WeightedObservedPoint(2.0, 1.0, 1.0),
                                                                                                                                                 new WeightedObservedPoint(3.0, 0.0, 1.0),
                                                                                                                                                 new WeightedObservedPoint(4.0, -1.0, 1.0),
                                                                                                                                                 new WeightedObservedPoint(5.0, 0.0, 1.0)
                                                                                                                                             };
                                                                                                                                             
                                                                                                                                             // y values range from -1 to 1, so expected amplitude should be 1 (0.5*(1 - (-1)))
                                                                                                                                             double expectedAmplitude = 1.0;
                                                                                                                                             
                                                                                                                                             // Use reflection to test private method
                                                                                                                                             HarmonicFitter fitter = new HarmonicFitter(mock(DifferentiableMultivariateVectorOptimizer.class));
                                                                                                                                             
                                                                                                                                             // Set observations using reflection
                                                                                                                                             Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                             observationsField.setAccessible(true);
                                                                                                                                             observationsField.set(fitter, observations);
                                                                                                                                             
                                                                                                                                             // Call the private method using reflection
                                                                                                                                             Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                             guessAOmega.setAccessible(true);
                                                                                                                                             guessAOmega.invoke(fitter);
                                                                                                                                             
                                                                                                                                             // Get the calculated amplitude using reflection
                                                                                                                                             Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                                                             aField.setAccessible(true);
                                                                                                                                             double actualAmplitude = aField.getDouble(fitter);
                                                                                                                                             
                                                                                                                                             // Assert the amplitude is exactly half the y range
                                                                                                                                             assertEquals("Amplitude should be half of yMax - yMin", 
                                                                                                                                                         expectedAmplitude, 
                                                                                                                                                         actualAmplitude, 
                                                                                                                                                         1e-10);
                                                                                                                                         }

 @Test
                                                                                                                                        public void testGuessAOmega_AmplitudeCalculation2() {
                                                                                                                                            // Create test observations that will trigger the condition (c1/c2 < 0 or c2/c3 < 0)
                                                                                                                                            WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                                                new WeightedObservedPoint(1.0, 0.0, 1.0),  // x=0.0, y=1.0
                                                                                                                                                new WeightedObservedPoint(1.0, Math.PI/2, 0.0),  // x=π/2, y=0.0
                                                                                                                                                new WeightedObservedPoint(1.0, Math.PI, -1.0),  // x=π, y=-1.0
                                                                                                                                                new WeightedObservedPoint(1.0, 3*Math.PI/2, 0.0),  // x=3π/2, y=0.0
                                                                                                                                                new WeightedObservedPoint(1.0, 2*Math.PI, 1.0)  // x=2π, y=1.0
                                                                                                                                            };
                                                                                                                                            
                                                                                                                                            // Create HarmonicFitter instance (we'll use reflection to set observations)
                                                                                                                                            HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                                                            
                                                                                                                                            // Use reflection to set the private observations field
                                                                                                                                            try {
                                                                                                                                                Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                                observationsField.setAccessible(true);
                                                                                                                                                observationsField.set(fitter, observations);
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                fail("Failed to set observations field via reflection");
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            // Call the method under test
                                                                                                                                            try {
                                                                                                                                                Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                                guessAOmega.setAccessible(true);
                                                                                                                                                guessAOmega.invoke(fitter);
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                fail("Failed to invoke guessAOmega method");
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            // Verify the amplitude calculation
                                                                                                                                            try {
                                                                                                                                                Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                                                                aField.setAccessible(true);
                                                                                                                                                double calculatedA = aField.getDouble(fitter);
                                                                                                                                                
                                                                                                                                                // Expected amplitude is 0.5 * (yMax - yMin) = 0.5 * (1.0 - (-1.0)) = 1.0
                                                                                                                                                assertEquals(1.0, calculatedA, 1e-10);
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                fail("Failed to verify amplitude value");
                                                                                                                                            }
                                                                                                                                        }

 @Test
                                                                                                                                       public void testGuessAOmega_AmplitudeCalculation3() {
                                                                                                                                           // Create test observations that will trigger the condition (c1/c2 < 0 || c2/c3 < 0)
                                                                                                                                           WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                                               new WeightedObservedPoint(1.0, 0.0, 1.0),  // x=0.0, y=1.0
                                                                                                                                               new WeightedObservedPoint(1.0, Math.PI/2, 3.0),  // x=π/2, y=3.0
                                                                                                                                               new WeightedObservedPoint(1.0, Math.PI, 1.0),    // x=π, y=1.0
                                                                                                                                               new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0) // x=3π/2, y=-1.0
                                                                                                                                           };
                                                                                                                                           
                                                                                                                                           // Create HarmonicFitter instance (we'll use reflection to set observations)
                                                                                                                                           HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                                                           
                                                                                                                                           try {
                                                                                                                                               // Use reflection to set private observations field
                                                                                                                                               Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                               observationsField.setAccessible(true);
                                                                                                                                               observationsField.set(fitter, observations);
                                                                                                                                               
                                                                                                                                               // Use reflection to call private guessAOmega method
                                                                                                                                               Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                               guessAOmega.setAccessible(true);
                                                                                                                                               guessAOmega.invoke(fitter);
                                                                                                                                               
                                                                                                                                               // Get the calculated amplitude
                                                                                                                                               Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                                                               aField.setAccessible(true);
                                                                                                                                               double calculatedA = aField.getDouble(fitter);
                                                                                                                                               
                                                                                                                                               // Expected amplitude is half of (yMax - yMin) = 0.5 * (3.0 - (-1.0)) = 2.0
                                                                                                                                               double expectedA = 2.0;
                                                                                                                                               
                                                                                                                                               // Assert that calculated amplitude matches expected
                                                                                                                                               assertEquals("Amplitude calculation is incorrect", expectedA, calculatedA, 1e-10);
                                                                                                                                               
                                                                                                                                           } catch (Exception e) {
                                                                                                                                               fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                           }
                                                                                                                                       }

 @Test
                                                                                                                                      public void testGuessAOmega_AmplitudeCalculation4() {
                                                                                                                                          // Create test observations where (c1/c2 < 0) || (c2/c3 < 0) condition is true
                                                                                                                                          WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                                              new WeightedObservedPoint(1.0, 0.0, 1.0),  // x, y, weight
                                                                                                                                              new WeightedObservedPoint(2.0, 2.0, 1.0),
                                                                                                                                              new WeightedObservedPoint(3.0, 0.0, 1.0),
                                                                                                                                              new WeightedObservedPoint(4.0, -2.0, 1.0),
                                                                                                                                              new WeightedObservedPoint(5.0, 0.0, 1.0)
                                                                                                                                          };
                                                                                                                                          
                                                                                                                                          // Create HarmonicFitter instance and set observations
                                                                                                                                          HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                                                          try {
                                                                                                                                              // Use reflection to set private observations field for testing
                                                                                                                                              Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                              observationsField.setAccessible(true);
                                                                                                                                              observationsField.set(fitter, observations);
                                                                                                                                              
                                                                                                                                              // Call the private method using reflection
                                                                                                                                              Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                              guessAOmega.setAccessible(true);
                                                                                                                                              guessAOmega.invoke(fitter);
                                                                                                                                              
                                                                                                                                              // Get the calculated amplitude
                                                                                                                                              Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                                                              aField.setAccessible(true);
                                                                                                                                              double calculatedA = aField.getDouble(fitter);
                                                                                                                                              
                                                                                                                                              // Expected amplitude is half of (yMax - yMin) = 0.5 * (2.0 - (-2.0)) = 2.0
                                                                                                                                              double expectedA = 2.0;
                                                                                                                                              
                                                                                                                                              // Assert the calculated amplitude matches expected
                                                                                                                                              assertEquals(expectedA, calculatedA, 1e-10);
                                                                                                                                              
                                                                                                                                          } catch (Exception e) {
                                                                                                                                              fail("Exception occurred during test: " + e.getMessage());
                                                                                                                                          }
                                                                                                                                      }

 @Test
                                                                                                                                      public void testGuessAOmega_AmplitudeCalculation_DetectsMutant() {
                                                                                                                                          // Create test observations where yMax = 3.0 and yMin = -1.0
                                                                                                                                          WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                                              new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                                                              new WeightedObservedPoint(2.0, 3.0, 1.0),
                                                                                                                                              new WeightedObservedPoint(3.0, 1.0, 1.0),
                                                                                                                                              new WeightedObservedPoint(4.0, -1.0, 1.0),
                                                                                                                                              new WeightedObservedPoint(5.0, 1.0, 1.0)
                                                                                                                                          };
                                                                                                                                          
                                                                                                                                          // Rest of the test code remains the same...
                                                                                                                                          // Expected amplitude should be 0.5 * (3.0 - (-1.0)) = 2.0
                                                                                                                                          // Mutant would calculate 3.0 instead
                                                                                                                                      }

 @Test
                                                                                                                                     public void testGuessAOmega_AmplitudeCalculation5() {
                                                                                                                                         // Create test observations that will trigger the conditional branch
                                                                                                                                         WeightedObservedPoint[] observations = {
                                                                                                                                             new WeightedObservedPoint(1.0, 0.0, 1.0),  // x=0.0, y=1.0
                                                                                                                                             new WeightedObservedPoint(1.0, Math.PI/2, 3.0),  // x=π/2, y=3.0
                                                                                                                                             new WeightedObservedPoint(1.0, Math.PI, 1.0),    // x=π, y=1.0
                                                                                                                                             new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0) // x=3π/2, y=-1.0
                                                                                                                                         };
                                                                                                                                         
                                                                                                                                         // Create HarmonicFitter instance (optimizer doesn't matter for this test)
                                                                                                                                         HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                                                         
                                                                                                                                         // Use reflection to set the observations since it's private final
                                                                                                                                         try {
                                                                                                                                             Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                             observationsField.setAccessible(true);
                                                                                                                                             observationsField.set(fitter, observations);
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             fail("Failed to set observations field: " + e.getMessage());
                                                                                                                                         }
                                                                                                                                         
                                                                                                                                         // Call the method under test
                                                                                                                                         try {
                                                                                                                                             Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                             guessAOmega.setAccessible(true);
                                                                                                                                             guessAOmega.invoke(fitter);
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             fail("Failed to invoke guessAOmega: " + e.getMessage());
                                                                                                                                         }
                                                                                                                                         
                                                                                                                                         // Use reflection to get the amplitude 'a' since it's private
                                                                                                                                         double amplitude = 0;
                                                                                                                                         try {
                                                                                                                                             Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                                                             aField.setAccessible(true);
                                                                                                                                             amplitude = aField.getDouble(fitter);
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             fail("Failed to get amplitude field: " + e.getMessage());
                                                                                                                                         }
                                                                                                                                         
                                                                                                                                         // Calculate expected amplitude (0.5 * (yMax - yMin))
                                                                                                                                         double yMin = -1.0;
                                                                                                                                         double yMax = 3.0;
                                                                                                                                         double expectedAmplitude = 0.5 * (yMax - yMin);
                                                                                                                                         
                                                                                                                                         // Assert that the amplitude is calculated correctly
                                                                                                                                         assertEquals("Amplitude should be half the peak-to-peak value", 
                                                                                                                                                      expectedAmplitude, amplitude, 1e-10);
                                                                                                                                     }

 @Test(expected = MathIllegalStateException.class)
                                                                                                                                    public void testGuessAOmega_WhenC2IsZero_ShouldThrowException() {
                                                                                                                                        // Create test data that will result in c2=0
                                                                                                                                        WeightedObservedPoint[] observations = {
                                                                                                                                            new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                                                                                            new WeightedObservedPoint(1.0, Math.PI, 0.0),
                                                                                                                                            new WeightedObservedPoint(1.0, 2*Math.PI, 0.0)
                                                                                                                                        };
                                                                                                                                        
                                                                                                                                        // Use reflection to test private method
                                                                                                                                        HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                                                        try {
                                                                                                                                            // Set observations field through reflection
                                                                                                                                            Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                            observationsField.setAccessible(true);
                                                                                                                                            observationsField.set(fitter, observations);
                                                                                                                                            
                                                                                                                                            // Call private method through reflection
                                                                                                                                            Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                            method.setAccessible(true);
                                                                                                                                            method.invoke(fitter);
                                                                                                                                        } catch (InvocationTargetException e) {
                                                                                                                                            // Unwrap the expected exception
                                                                                                                                            throw (RuntimeException) e.getCause();
                                                                                                                                        } catch (Exception e) {
                                                                                                                                            fail("Unexpected exception: " + e);
                                                                                                                                        }
                                                                                                                                    }

 @Test(expected = MathIllegalStateException.class)
                                                                                                                                   public void testGuessAOmega_DetectsZeroDenominator() {
                                                                                                                                       // Create observations that will result in c2 = 0
                                                                                                                                       WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                                           new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                                                                                           new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                                                           new WeightedObservedPoint(1.0, 2.0, 1.0)
                                                                                                                                       };
                                                                                                                                       
                                                                                                                                       // Create HarmonicFitter instance (optimizer doesn't matter for this test)
                                                                                                                                       HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                                                       
                                                                                                                                       // Use reflection to set the private observations field
                                                                                                                                       try {
                                                                                                                                           Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                           observationsField.setAccessible(true);
                                                                                                                                           observationsField.set(fitter, observations);
                                                                                                                                           
                                                                                                                                           // Call the private method using reflection
                                                                                                                                           Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                           guessAOmega.setAccessible(true);
                                                                                                                                           guessAOmega.invoke(fitter);
                                                                                                                                       } catch (Exception e) {
                                                                                                                                           if (e.getCause() instanceof MathIllegalStateException) {
                                                                                                                                               throw (MathIllegalStateException) e.getCause();
                                                                                                                                           }
                                                                                                                                           fail("Unexpected exception: " + e);
                                                                                                                                       }
                                                                                                                                       
                                                                                                                                       // If we get here, the test fails because no exception was thrown
                                                                                                                                       fail("Expected MathIllegalStateException for zero denominator case");
                                                                                                                                   }

 @Test
                                                                                                                             public void testGuessAOmega_DetectMutant() throws Exception {
                                                                                                                                 // Create test data that will:
                                                                                                                                 // 1. Enter the else branch (c1/c2 >= 0 and c2/c3 >= 0)
                                                                                                                                 // 2. Have c2 != 0 (should not throw exception in original)
                                                                                                                                 WeightedObservedPoint[] observations = {
                                                                                                                                     new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                                                                                     new WeightedObservedPoint(1.0, Math.PI/2, 1.0),
                                                                                                                                     new WeightedObservedPoint(1.0, Math.PI, -1.0),
                                                                                                                                     new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0),
                                                                                                                                     new WeightedObservedPoint(1.0, 2*Math.PI, 1.0)
                                                                                                                                 };
                                                                                                                                 
                                                                                                                                 try {
                                                                                                                                     // Create harmonic fitter and set observations
                                                                                                                                     // Need to use reflection since observations is private final
                                                                                                                                     HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                                                     Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                     observationsField.setAccessible(true);
                                                                                                                                     observationsField.set(fitter, observations);
                                                                                                                                     
                                                                                                                                     // Call the method - should throw exception only with mutant
                                                                                                                                     Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                     method.setAccessible(true);
                                                                                                                                     method.invoke(fitter);
                                                                                                                                     
                                                                                                                                     // If we get here, the test fails (mutant not detected)
                                                                                                                                     // Because original code should compute values normally
                                                                                                                                     // With mutant, it will throw exception as expected
                                                                                                                                     fail("Expected exception not thrown - mutant not detected");
                                                                                                                                 } catch (InvocationTargetException e) {
                                                                                                                                     // This is expected for the mutant case
                                                                                                                                     // The original code should not throw an exception
                                                                                                                                     try {
                                                                                                                                         throw e.getTargetException();
                                                                                                                                     } catch (Throwable t) {
                                                                                                                                         // Expected path for mutant
                                                                                                                                     }
                                                                                                                                 }
                                                                                                                             }

 @Test(expected = MathIllegalStateException.class)
                                                                                                                         public void testGuessAOmega_DetectsZeroDenominator1() {
                                                                                                                             // Create observations that will lead to c2 = 0
                                                                                                                             // This requires creating data where sxy*sxz = sx2*syz
                                                                                                                             // One way is to have all y values equal (dy=0) which makes fPrime2Integral=0
                                                                                                                             // Then we need to arrange sxz=0 and syz=0
                                                                                                                             WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                                 new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                                                                                 new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                                                 new WeightedObservedPoint(1.0, 2.0, 1.0)
                                                                                                                             };
                                                                                                                             
                                                                                                                             // Use reflection to test private method
                                                                                                                             HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                                             try {
                                                                                                                                 // Set observations field via reflection
                                                                                                                                 Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                                 observationsField.setAccessible(true);
                                                                                                                                 observationsField.set(fitter, observations);
                                                                                                                                 
                                                                                                                                 // Call private method via reflection
                                                                                                                                 Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                                 method.setAccessible(true);
                                                                                                                                 method.invoke(fitter);
                                                                                                                             } catch (InvocationTargetException e) {
                                                                                                                                 // Unwrap the actual exception
                                                                                                                                 throw (RuntimeException) e.getCause();
                                                                                                                             } catch (Exception e) {
                                                                                                                                 throw new RuntimeException(e);
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                       public void testGuessAOmega_ZeroDenominator() {
                                                                                                                           // Create test data that will cause c2 to be zero
                                                                                                                           WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                               new WeightedObservedPoint(1.0, 0.0, 1.0),
                                                                                                                               new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                                               new WeightedObservedPoint(1.0, 2.0, 1.0),
                                                                                                                               new WeightedObservedPoint(1.0, 3.0, 1.0)
                                                                                                                           };
                                                                                                                           
                                                                                                                           // Create HarmonicFitter instance
                                                                                                                           HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                                           
                                                                                                                           try {
                                                                                                                               // Use reflection to set the observations field since it's private final
                                                                                                                               Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                               observationsField.setAccessible(true);
                                                                                                                               observationsField.set(fitter, observations);
                                                                                                                               
                                                                                                                               // Use reflection to call the private method
                                                                                                                               Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                               method.setAccessible(true);
                                                                                                                               method.invoke(fitter);
                                                                                                                               
                                                                                                                               // If we get here, the test fails (no exception thrown)
                                                                                                                               fail("Expected MathIllegalStateException");
                                                                                                                           } catch (InvocationTargetException e) {
                                                                                                                               // Check the actual cause of the exception
                                                                                                                               Throwable cause = e.getCause();
                                                                                                                               assertTrue(cause instanceof MathIllegalStateException);
                                                                                                                               assertEquals("zero denominator", 
                                                                                                                                           ((MathIllegalStateException)cause).getMessage());
                                                                                                                           } catch (Exception e) {
                                                                                                                               fail("Unexpected exception: " + e);
                                                                                                                           }
                                                                                                                       }

 @Test(expected = MathIllegalStateException.class)
                                                                                                                   public void testGuessAOmegaWithZeroDenominator() throws Exception {
                                                                                                                       // Create observations that will lead to c2 = 0
                                                                                                                       // This requires creating data where the calculations result in c2 being 0
                                                                                                                       // For simplicity, we'll create a mock array with specific values
                                                                                                                       
                                                                                                                       // Using reflection to test private method
                                                                                                                       Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                       method.setAccessible(true);
                                                                                                                       
                                                                                                                       // Create test observations that will cause c2 = 0
                                                                                                                       WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                           new WeightedObservedPoint(1.0, 0.0, 0.0),
                                                                                                                           new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                                           new WeightedObservedPoint(1.0, 2.0, 4.0)
                                                                                                                       };
                                                                                                                       
                                                                                                                       // Create HarmonicFitter instance and set observations
                                                                                                                       HarmonicFitter fitter = new HarmonicFitter(mock(DifferentiableMultivariateVectorOptimizer.class));
                                                                                                                       
                                                                                                                       // Use reflection to set private observations field
                                                                                                                       Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                       observationsField.setAccessible(true);
                                                                                                                       observationsField.set(fitter, observations);
                                                                                                                       
                                                                                                                       // Invoke the method - should throw exception
                                                                                                                       method.invoke(fitter);
                                                                                                                       
                                                                                                                       // If we get here, the mutant survived (it returned instead of throwing)
                                                                                                                       // The @Test(expected) will verify the exception was thrown
                                                                                                                   }

 @Test(expected = MathIllegalStateException.class)
                                                                                                                  public void testGuessAOmegaThrowsExceptionWhenC2IsZero() {
                                                                                                                      // Create test data that will result in c2 being zero
                                                                                                                      WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                          new WeightedObservedPoint(1.0, 0.0, 1.0),
                                                                                                                          new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                                          new WeightedObservedPoint(1.0, -1.0, 1.0)
                                                                                                                      };
                                                                                                                      
                                                                                                                      // Create HarmonicFitter instance and set observations
                                                                                                                      // Note: We need to use reflection to set the private observations field
                                                                                                                      // since there's no setter method in the provided class
                                                                                                                      HarmonicFitter fitter = new HarmonicFitter(mock(DifferentiableMultivariateVectorOptimizer.class));
                                                                                                                      
                                                                                                                      try {
                                                                                                                          Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                          observationsField.setAccessible(true);
                                                                                                                          observationsField.set(fitter, observations);
                                                                                                                      } catch (Exception e) {
                                                                                                                          fail("Failed to set observations field via reflection");
                                                                                                                      }
                                                                                                                      
                                                                                                                      // Call the method that should throw exception
                                                                                                                      // Again using reflection since the method is private
                                                                                                                      try {
                                                                                                                          Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                          method.setAccessible(true);
                                                                                                                          method.invoke(fitter);
                                                                                                                      } catch (InvocationTargetException e) {
                                                                                                                          throw (MathIllegalStateException) e.getCause();
                                                                                                                      } catch (Exception e) {
                                                                                                                          fail("Failed to invoke guessAOmega method via reflection");
                                                                                                                      }
                                                                                                                  }

 @Test
                                                                                                                public void testGuessAOmega_DetectsMutatedAmplitudeCalculation() {
                                                                                                                    // Create test observations that will produce known c1 and c2 values
                                                                                                                    WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                        new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                                                                        new WeightedObservedPoint(1.0, 1.0, 2.0),
                                                                                                                        new WeightedObservedPoint(1.0, 2.0, 1.0)
                                                                                                                    };
                                                                                                                    
                                                                                                                    // Create HarmonicFitter instance and set observations
                                                                                                                    DifferentiableMultivariateVectorOptimizer optimizer = mock(DifferentiableMultivariateVectorOptimizer.class);
                                                                                                                    HarmonicFitter fitter = new HarmonicFitter(optimizer);
                                                                                                                    
                                                                                                                    // Use reflection to set private observations field since there's no setter
                                                                                                                    try {
                                                                                                                        Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                        observationsField.setAccessible(true);
                                                                                                                        observationsField.set(fitter, observations);
                                                                                                                    } catch (Exception e) {
                                                                                                                        fail("Failed to set observations field via reflection");
                                                                                                                    }
                                                                                                                    
                                                                                                                    // Call the method under test
                                                                                                                    try {
                                                                                                                        Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                        guessAOmega.setAccessible(true);
                                                                                                                        guessAOmega.invoke(fitter);
                                                                                                                    } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                                                                                                                        fail("Failed to invoke guessAOmega method via reflection");
                                                                                                                    }
                                                                                                                    
                                                                                                                    // Get the calculated amplitude
                                                                                                                    double calculatedA = 0.0;
                                                                                                                    try {
                                                                                                                        Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                                        aField.setAccessible(true);
                                                                                                                        calculatedA = aField.getDouble(fitter);
                                                                                                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                        fail("Failed to get 'a' field via reflection");
                                                                                                                    }
                                                                                                                    
                                                                                                                    // Calculate expected values based on the math
                                                                                                                    // For our test data, c1 should be about 0.444 and c2 about 0.222
                                                                                                                    // So c1/c2 ≈ 2.0 and c2/c1 ≈ 0.5
                                                                                                                    double expectedA = FastMath.sqrt(2.0);  // sqrt(c1/c2)
                                                                                                                    double mutatedA = FastMath.sqrt(0.5);   // sqrt(c2/c1)
                                                                                                                    
                                                                                                                    // Verify the calculation matches expected (not mutated) behavior
                                                                                                                    assertEquals(expectedA, calculatedA, 1e-10);
                                                                                                                    
                                                                                                                    // Additional check to ensure we'd catch the mutation
                                                                                                                    assertNotEquals(mutatedA, calculatedA, 1e-10);
                                                                                                                }

 @Test
                                                                                                            public void testGuessAOmega_DetectsSqrtMutation() {
                                                                                                                // Create test data where c1/c2 > 1 to expose the sqrt mutation
                                                                                                                WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                    new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                                    new WeightedObservedPoint(2.0, 4.0, 1.0),
                                                                                                                    new WeightedObservedPoint(3.0, 9.0, 1.0)
                                                                                                                };
                                                                                                                
                                                                                                                // Using reflection to test private method
                                                                                                                try {
                                                                                                                    HarmonicFitter fitter = new HarmonicFitter(mock(DifferentiableMultivariateVectorOptimizer.class));
                                                                                                                    Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                    observationsField.setAccessible(true);
                                                                                                                    observationsField.set(fitter, observations);
                                                                                                                    
                                                                                                                    Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                    guessAOmega.setAccessible(true);
                                                                                                                    guessAOmega.invoke(fitter);
                                                                                                                    
                                                                                                                    // Get the calculated amplitude
                                                                                                                    Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                                    aField.setAccessible(true);
                                                                                                                    double calculatedA = aField.getDouble(fitter);
                                                                                                                    
                                                                                                                    // Get the calculated omega to compute expected values
                                                                                                                    Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                                                                                    omegaField.setAccessible(true);
                                                                                                                    double calculatedOmega = omegaField.getDouble(fitter);
                                                                                                                    
                                                                                                                    // Calculate what c1/c2 would be (without sqrt)
                                                                                                                    double c1OverC2 = calculatedA * calculatedA; // reverse the sqrt operation
                                                                                                                    
                                                                                                                    // Verify that the amplitude is indeed the sqrt of c1/c2
                                                                                                                    // This will fail if the mutation is present (a = c1/c2 instead of sqrt(c1/c2))
                                                                                                                    assertEquals(Math.sqrt(c1OverC2), calculatedA, 1e-10);
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                }
                                                                                                            }

 @Test
                                                                                                           public void testGuessAOmegaDetectsSqrtToAbsMutant() {
                                                                                                               // Create observations that will result in c1/c2 = 4 (perfect square)
                                                                                                               // This requires setting up specific values that will produce:
                                                                                                               // sy2*sxz - sxy*syz = 4 * (sxy*sxz - sx2*syz)
                                                                                                               // We'll create a minimal case with 3 points to control the sums
                                                                                                               
                                                                                                               // Mock observations - these values are carefully chosen to produce c1/c2 = 4
                                                                                                               WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                                   new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                                                                   new WeightedObservedPoint(1.0, 1.0, 2.0),
                                                                                                                   new WeightedObservedPoint(1.0, 2.0, 4.0)
                                                                                                               };
                                                                                                               
                                                                                                               // Create harmonic fitter and set observations (using reflection since observations is final)
                                                                                                               HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                               try {
                                                                                                                   Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                                   observationsField.setAccessible(true);
                                                                                                                   observationsField.set(fitter, observations);
                                                                                                               } catch (Exception e) {
                                                                                                                   fail("Failed to set observations field via reflection");
                                                                                                               }
                                                                                                               
                                                                                                               // Call the method under test
                                                                                                               try {
                                                                                                                   Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                                   guessAOmega.setAccessible(true);
                                                                                                                   guessAOmega.invoke(fitter);
                                                                                                                   
                                                                                                                   // Get the amplitude value
                                                                                                                   Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                                   aField.setAccessible(true);
                                                                                                                   double amplitude = aField.getDouble(fitter);
                                                                                                                   
                                                                                                                   // Verify the amplitude is the square root (not absolute value)
                                                                                                                   // With our test data, original would give sqrt(4) = 2
                                                                                                                   // Mutant would give abs(4) = 4
                                                                                                                   assertEquals(2.0, amplitude, 1e-10);
                                                                                                               } catch (Exception e) {
                                                                                                                   fail("Failed to invoke guessAOmega method");
                                                                                                               }
                                                                                                           }

 @Test
                                                                                                          public void testGuessAOmega_NonZeroAmplitudeCalculation() throws Exception {
                                                                                                              // Create test observations that will result in c1/c2 >=0 and c2/c3 >=0 and c2 != 0
                                                                                                              WeightedObservedPoint[] observations = {
                                                                                                                  new WeightedObservedPoint(1.0, 0.0, 1.0),  // t=0, y=0
                                                                                                                  new WeightedObservedPoint(1.0, Math.PI/2, 1.0),  // t=π/2, y=1
                                                                                                                  new WeightedObservedPoint(1.0, Math.PI, 1.0)    // t=π, y=0
                                                                                                              };
                                                                                                              
                                                                                                              // Use reflection to test private method
                                                                                                              HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                              Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                              observationsField.setAccessible(true);
                                                                                                              observationsField.set(fitter, observations);
                                                                                                              
                                                                                                              Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                              guessAOmega.setAccessible(true);
                                                                                                              guessAOmega.invoke(fitter);
                                                                                                              
                                                                                                              // Get the calculated amplitude
                                                                                                              Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                              aField.setAccessible(true);
                                                                                                              double calculatedA = aField.getDouble(fitter);
                                                                                                              
                                                                                                              // Verify amplitude is calculated properly (should be approximately 1 for this test data)
                                                                                                              // The mutant would set it to 0.0 instead
                                                                                                              assertEquals(1.0, calculatedA, 0.01);
                                                                                                              
                                                                                                              // Also verify omega is calculated (though not directly related to this mutant)
                                                                                                              Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                                                                              omegaField.setAccessible(true);
                                                                                                              double calculatedOmega = omegaField.getDouble(fitter);
                                                                                                              assertEquals(1.0, calculatedOmega, 0.01);
                                                                                                          }

 @Test
                                                                                                        public void testGuessAOmega_DetectsAmplitudeMutation() throws Exception {
                                                                                                            // Create test observations that will produce c1/c2 > 0 and c2/c3 > 0
                                                                                                            // and result in amplitude != 1.0
                                                                                                            WeightedObservedPoint[] observations = {
                                                                                                                new WeightedObservedPoint(1.0, 1.0, 2.0),  // (weight, x, y)
                                                                                                                new WeightedObservedPoint(1.0, 2.0, 4.0),
                                                                                                                new WeightedObservedPoint(1.0, 3.0, 2.0),
                                                                                                                new WeightedObservedPoint(1.0, 4.0, 0.0),
                                                                                                                new WeightedObservedPoint(1.0, 5.0, 2.0)
                                                                                                            };
                                                                                                            
                                                                                                            // Use reflection to test private method
                                                                                                            HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                            Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                            observationsField.setAccessible(true);
                                                                                                            observationsField.set(fitter, observations);
                                                                                                            
                                                                                                            Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                            guessAOmega.setAccessible(true);
                                                                                                            guessAOmega.invoke(fitter);
                                                                                                            
                                                                                                            // Get the amplitude value
                                                                                                            Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                            aField.setAccessible(true);
                                                                                                            double amplitude = aField.getDouble(fitter);
                                                                                                            
                                                                                                            // The expected amplitude should be calculated from c1/c2
                                                                                                            // For these points, it should be approximately 2.0, not 1.0
                                                                                                            assertEquals(2.0, amplitude, 0.1);  // Allowing small delta for floating point
                                                                                                            
                                                                                                            // Also verify omega was calculated (though not the focus of this test)
                                                                                                            Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                                                                            omegaField.setAccessible(true);
                                                                                                            double omega = omegaField.getDouble(fitter);
                                                                                                            assertTrue(omega > 0);  // Should be positive
                                                                                                        }

 @Test
                                                                                                    public void testGuessAOmegaDetectsMutant() throws Exception {
                                                                                                        // Create test observations that will produce known c2 and c3 values
                                                                                                        WeightedObservedPoint[] observations = {
                                                                                                            new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                                                            new WeightedObservedPoint(1.0, Math.PI/2, 1.0),
                                                                                                            new WeightedObservedPoint(1.0, Math.PI, 0.0)
                                                                                                        };
                                                                                                        
                                                                                                        // Use reflection to access private method and fields
                                                                                                        HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                        Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                        observationsField.setAccessible(true);
                                                                                                        observationsField.set(fitter, observations);
                                                                                                        
                                                                                                        Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                        guessAOmega.setAccessible(true);
                                                                                                        guessAOmega.invoke(fitter);
                                                                                                        
                                                                                                        // Get the calculated omega value
                                                                                                        Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                                                                        omegaField.setAccessible(true);
                                                                                                        double calculatedOmega = omegaField.getDouble(fitter);
                                                                                                        
                                                                                                        // Calculate expected omega value (should be 1 for this test data)
                                                                                                        double expectedOmega = 1.0;
                                                                                                        
                                                                                                        // Verify omega is calculated correctly (sqrt(c2/c3) not sqrt(c3/c2))
                                                                                                        assertEquals(expectedOmega, calculatedOmega, 1e-6);
                                                                                                        
                                                                                                        // Also verify that c2 and c3 are different to ensure the test is meaningful
                                                                                                        // (If they were equal, the mutant wouldn't be detected)
                                                                                                        assertNotEquals(0.0, calculatedOmega - FastMath.sqrt(1/expectedOmega), 1e-6);
                                                                                                    }

 @Test
                                                                                                   public void testGuessAOmegaDetectsSqrtMutation() throws Exception {
                                                                                                       // Create test observations that will produce non-perfect-square c2/c3 ratio
                                                                                                       WeightedObservedPoint[] observations = {
                                                                                                           new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                                                           new WeightedObservedPoint(1.0, Math.PI/4, Math.sqrt(2)/2),
                                                                                                           new WeightedObservedPoint(1.0, Math.PI/2, 1.0)
                                                                                                       };
                                                                                                       
                                                                                                       // Use reflection to test private method
                                                                                                       HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                       Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                       observationsField.setAccessible(true);
                                                                                                       observationsField.set(fitter, observations);
                                                                                                       
                                                                                                       Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                       guessAOmega.setAccessible(true);
                                                                                                       guessAOmega.invoke(fitter);
                                                                                                       
                                                                                                       // Get private fields to verify results
                                                                                                       Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                       Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                                                                       aField.setAccessible(true);
                                                                                                       omegaField.setAccessible(true);
                                                                                                       
                                                                                                       double a = aField.getDouble(fitter);
                                                                                                       double omega = omegaField.getDouble(fitter);
                                                                                                       
                                                                                                       // Calculate expected ratio from the method's internal calculations
                                                                                                       // For these observations, c2/c3 should be approximately 1 (but not exactly)
                                                                                                       // So omega should be approximately 1 (sqrt(1)), but mutant would return ~1
                                                                                                       
                                                                                                       // More precise verification - check if omega squared equals the ratio
                                                                                                       // We'll need to reproduce some of the method's calculations
                                                                                                       double sx2 = 0, sy2 = 0, sxy = 0, sxz = 0, syz = 0;
                                                                                                       double currentX = observations[0].getX();
                                                                                                       double currentY = observations[0].getY();
                                                                                                       double f2Integral = 0, fPrime2Integral = 0;
                                                                                                       final double startX = currentX;
                                                                                                       
                                                                                                       for (int i = 1; i < observations.length; ++i) {
                                                                                                           final double previousX = currentX;
                                                                                                           final double previousY = currentY;
                                                                                                           currentX = observations[i].getX();
                                                                                                           currentY = observations[i].getY();
                                                                                                           
                                                                                                           final double dx = currentX - previousX;
                                                                                                           final double dy = currentY - previousY;
                                                                                                           final double f2StepIntegral = dx * (previousY*previousY + previousY*currentY + currentY*currentY)/3;
                                                                                                           final double fPrime2StepIntegral = dy*dy/dx;
                                                                                                           
                                                                                                           final double x = currentX - startX;
                                                                                                           f2Integral += f2StepIntegral;
                                                                                                           fPrime2Integral += fPrime2StepIntegral;
                                                                                                           
                                                                                                           sx2 += x*x;
                                                                                                           sy2 += f2Integral*f2Integral;
                                                                                                           sxy += x*f2Integral;
                                                                                                           sxz += x*fPrime2Integral;
                                                                                                           syz += f2Integral*fPrime2Integral;
                                                                                                       }
                                                                                                       
                                                                                                       double c1 = sy2*sxz - sxy*syz;
                                                                                                       double c2 = sxy*sxz - sx2*syz;
                                                                                                       double c3 = sx2*sy2 - sxy*sxy;
                                                                                                       double ratio = c2/c3;
                                                                                                       
                                                                                                       // Original code would have omega = sqrt(ratio)
                                                                                                       // Mutant would have omega = ratio
                                                                                                       // So we verify that omega squared equals ratio (with delta for floating point precision)
                                                                                                       assertEquals(ratio, omega * omega, 1e-10);
                                                                                                   }

 @Test
                                                                                                  public void testGuessAOmegaDetectsSqrtToAbsMutant1() throws Exception {
                                                                                                      // Create observations that will produce known c2 and c3 values
                                                                                                      // We need values where c2/c3 is positive but not a perfect square
                                                                                                      // Let's aim for c2=2.0 and c3=8.0, so c2/c3=0.25, sqrt(0.25)=0.5, abs(0.25)=0.25
                                                                                                      WeightedObservedPoint[] observations = {
                                                                                                          new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                                                          new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                          new WeightedObservedPoint(1.0, 2.0, 0.0)
                                                                                                      };
                                                                                                      
                                                                                                      // Use reflection to access private method and fields
                                                                                                      HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                      Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                      observationsField.setAccessible(true);
                                                                                                      observationsField.set(fitter, observations);
                                                                                                      
                                                                                                      Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                      guessAOmega.setAccessible(true);
                                                                                                      guessAOmega.invoke(fitter);
                                                                                                      
                                                                                                      // Get the omega value
                                                                                                      Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                                                                      omegaField.setAccessible(true);
                                                                                                      double omega = omegaField.getDouble(fitter);
                                                                                                      
                                                                                                      // The correct omega should be sqrt(0.25) = 0.5
                                                                                                      // The mutant would give abs(0.25) = 0.25
                                                                                                      assertEquals(0.5, omega, 1e-10);
                                                                                                      
                                                                                                      // Also verify a since we're here
                                                                                                      Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                      aField.setAccessible(true);
                                                                                                      double a = aField.getDouble(fitter);
                                                                                                      // Expected a is sqrt(c1/c2), but with our test data we can calculate it
                                                                                                      // For our simple test case, we can accept any reasonable value
                                                                                                      assertTrue(a >= 0);
                                                                                                  }

 @Test
                                                                                                 public void testGuessAOmegaDetectsOmegaCalculationMutant() {
                                                                                                     // Create test observations that will ensure we enter the else branch
                                                                                                     // where omega is calculated (not the range-based estimation)
                                                                                                     WeightedObservedPoint[] observations = {
                                                                                                         new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                                                         new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                         new WeightedObservedPoint(1.0, 2.0, 0.0),
                                                                                                         new WeightedObservedPoint(1.0, 3.0, -1.0),
                                                                                                         new WeightedObservedPoint(1.0, 4.0, 0.0)
                                                                                                     };
                                                                                                     
                                                                                                     // Create HarmonicFitter instance and set observations
                                                                                                     // Note: We need to use reflection to set observations since it's private final
                                                                                                     HarmonicFitter fitter = new HarmonicFitter(null); // optimizer can be null for this test
                                                                                                     try {
                                                                                                         Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                         observationsField.setAccessible(true);
                                                                                                         observationsField.set(fitter, observations);
                                                                                                     } catch (Exception e) {
                                                                                                         fail("Failed to set observations field via reflection");
                                                                                                     }
                                                                                                     
                                                                                                     // Call the method under test
                                                                                                     try {
                                                                                                         Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                         guessAOmega.setAccessible(true);
                                                                                                         guessAOmega.invoke(fitter);
                                                                                                     } catch (Exception e) {
                                                                                                         fail("Failed to invoke guessAOmega method");
                                                                                                     }
                                                                                                     
                                                                                                     // Get the omega value using reflection
                                                                                                     double omega = 0;
                                                                                                     try {
                                                                                                         Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                                                                         omegaField.setAccessible(true);
                                                                                                         omega = omegaField.getDouble(fitter);
                                                                                                     } catch (Exception e) {
                                                                                                         fail("Failed to get omega field");
                                                                                                     }
                                                                                                     
                                                                                                     // Assert that omega is not zero (which would indicate the mutant)
                                                                                                     // We know with these test values omega should be approximately PI/2
                                                                                                     assertNotEquals("Omega should not be zero (mutant detected)", 0.0, omega, 0.0001);
                                                                                                     assertEquals(Math.PI/2, omega, 0.1); // Approximate expected value
                                                                                                 }

 @Test
                                                                                                public void testGuessAOmega_AmplitudeCalculation6() throws Exception {
                                                                                                    // Create test observations with asymmetric amplitudes
                                                                                                    WeightedObservedPoint[] observations = {
                                                                                                        new WeightedObservedPoint(1.0, 0.0, 1.0),   // t=0, y=1
                                                                                                        new WeightedObservedPoint(1.0, Math.PI/2, 2.0),   // t=π/2, y=2 (max)
                                                                                                        new WeightedObservedPoint(1.0, Math.PI, -1.0),   // t=π, y=-1 (min)
                                                                                                        new WeightedObservedPoint(1.0, 3*Math.PI/2, 0.0)  // t=3π/2, y=0
                                                                                                    };
                                                                                                    
                                                                                                    // Create HarmonicFitter instance (optimizer doesn't matter for this test)
                                                                                                    HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                    
                                                                                                    // Use reflection to set observations since it's private final
                                                                                                    Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                    observationsField.setAccessible(true);
                                                                                                    observationsField.set(fitter, observations);
                                                                                                    
                                                                                                    // Call the private method using reflection
                                                                                                    Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                    guessAOmega.setAccessible(true);
                                                                                                    guessAOmega.invoke(fitter);
                                                                                                    
                                                                                                    // Get the calculated amplitude
                                                                                                    Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                    aField.setAccessible(true);
                                                                                                    double calculatedA = aField.getDouble(fitter);
                                                                                                    
                                                                                                    // Expected amplitude is (max - min)/2 = (2 - (-1))/2 = 1.5
                                                                                                    double expectedA = 1.5;
                                                                                                    
                                                                                                    // This assertion will fail if the mutant is present
                                                                                                    // Mutant would calculate (2 + (-1))/2 = 0.5 instead
                                                                                                    assertEquals("Amplitude calculation is incorrect", 
                                                                                                                expectedA, calculatedA, 1e-10);
                                                                                                }

 @Test
                                                                                               public void testGuessAOmega_AmplitudeCalculation7() throws Exception {
                                                                                                   // Create test observations that will force the fallback path
                                                                                                   WeightedObservedPoint[] observations = {
                                                                                                       new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                                                       new WeightedObservedPoint(1.0, 1.0, 2.0),
                                                                                                       new WeightedObservedPoint(1.0, 2.0, 0.0),
                                                                                                       new WeightedObservedPoint(1.0, 3.0, 2.0),
                                                                                                       new WeightedObservedPoint(1.0, 4.0, 0.0)
                                                                                                   };
                                                                                                   
                                                                                                   // yMin = 0.0, yMax = 2.0, so expected amplitude should be 1.0 (0.5 * (2.0 - 0.0))
                                                                                                   
                                                                                                   // Use reflection to test private method
                                                                                                   HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                   Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                   observationsField.setAccessible(true);
                                                                                                   observationsField.set(fitter, observations);
                                                                                                   
                                                                                                   Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                   guessAOmega.setAccessible(true);
                                                                                                   guessAOmega.invoke(fitter);
                                                                                                   
                                                                                                   Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                   aField.setAccessible(true);
                                                                                                   double calculatedA = aField.getDouble(fitter);
                                                                                                   
                                                                                                   // Assert the amplitude is exactly half the peak-to-peak value
                                                                                                   assertEquals(1.0, calculatedA, 1e-10);
                                                                                                   
                                                                                                   // Also verify omega is calculated (though not the focus of this test)
                                                                                                   Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                                                                   omegaField.setAccessible(true);
                                                                                                   double calculatedOmega = omegaField.getDouble(fitter);
                                                                                                   assertTrue(calculatedOmega > 0);
                                                                                               }

 @Test
                                                                                              public void testGuessAOmega_AmplitudeCalculation8() {
                                                                                                  // Create test observations that will trigger the fallback condition
                                                                                                  WeightedObservedPoint[] observations = {
                                                                                                      new WeightedObservedPoint(1.0, 0.0, 2.0),  // x=0.0, y=2.0
                                                                                                      new WeightedObservedPoint(1.0, Math.PI/2, 0.0),  // x=π/2, y=0.0
                                                                                                      new WeightedObservedPoint(1.0, Math.PI, -2.0),  // x=π, y=-2.0
                                                                                                      new WeightedObservedPoint(1.0, 3*Math.PI/2, 0.0)  // x=3π/2, y=0.0
                                                                                                  };
                                                                                                  
                                                                                                  // Create HarmonicFitter instance (optimizer doesn't matter for this test)
                                                                                                  HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                  
                                                                                                  // Use reflection to set the observations since it's private final
                                                                                                  try {
                                                                                                      Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                      observationsField.setAccessible(true);
                                                                                                      observationsField.set(fitter, observations);
                                                                                                  } catch (Exception e) {
                                                                                                      fail("Failed to set observations field: " + e.getMessage());
                                                                                                  }
                                                                                                  
                                                                                                  // Call the method under test
                                                                                                  try {
                                                                                                      Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                      guessAOmega.setAccessible(true);
                                                                                                      guessAOmega.invoke(fitter);
                                                                                                  } catch (Exception e) {
                                                                                                      fail("Failed to invoke guessAOmega: " + e.getMessage());
                                                                                                  }
                                                                                                  
                                                                                                  // Verify the amplitude calculation
                                                                                                  // Expected amplitude is 0.5 * (yMax - yMin) = 0.5 * (2.0 - (-2.0)) = 2.0
                                                                                                  // Mutant would calculate 0.25 * (2.0 - (-2.0)) = 1.0
                                                                                                  try {
                                                                                                      Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                      aField.setAccessible(true);
                                                                                                      double calculatedA = aField.getDouble(fitter);
                                                                                                      assertEquals(2.0, calculatedA, 1e-10);
                                                                                                  } catch (Exception e) {
                                                                                                      fail("Failed to verify amplitude: " + e.getMessage());
                                                                                                  }
                                                                                              }

 @Test
                                                                                             public void testGuessAOmega_AmplitudeCalculation9() {
                                                                                                 // Create test observations that will trigger the amplitude calculation branch
                                                                                                 WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                                     new WeightedObservedPoint(1.0, 0.0, 1.0),  // x=0.0, y=1.0
                                                                                                     new WeightedObservedPoint(1.0, Math.PI/2, 3.0),  // x=π/2, y=3.0
                                                                                                     new WeightedObservedPoint(1.0, Math.PI, 1.0),    // x=π, y=1.0
                                                                                                     new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0), // x=3π/2, y=-1.0
                                                                                                     new WeightedObservedPoint(1.0, 2*Math.PI, 1.0)   // x=2π, y=1.0
                                                                                                 };
                                                                                                 
                                                                                                 // Create HarmonicFitter instance (optimizer doesn't matter for this test)
                                                                                                 HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                 
                                                                                                 // Use reflection to set the observations since it's private final
                                                                                                 try {
                                                                                                     Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                     observationsField.setAccessible(true);
                                                                                                     observationsField.set(fitter, observations);
                                                                                                 } catch (Exception e) {
                                                                                                     fail("Failed to set observations field: " + e.getMessage());
                                                                                                 }
                                                                                                 
                                                                                                 // Call the method under test
                                                                                                 try {
                                                                                                     Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                     guessAOmega.setAccessible(true);
                                                                                                     guessAOmega.invoke(fitter);
                                                                                                 } catch (Exception e) {
                                                                                                     fail("Failed to invoke guessAOmega: " + e.getMessage());
                                                                                                 }
                                                                                                 
                                                                                                 // Use reflection to get the amplitude 'a' since it's private
                                                                                                 double amplitude = 0;
                                                                                                 try {
                                                                                                     Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                     aField.setAccessible(true);
                                                                                                     amplitude = aField.getDouble(fitter);
                                                                                                 } catch (Exception e) {
                                                                                                     fail("Failed to get amplitude field: " + e.getMessage());
                                                                                                 }
                                                                                                 
                                                                                                 // Verify the amplitude is correctly calculated as half the peak-to-peak difference
                                                                                                 // yMax = 3.0, yMin = -1.0, so amplitude should be (3.0 - (-1.0))/2 = 2.0
                                                                                                 assertEquals(2.0, amplitude, 1e-10);
                                                                                             }

 @Test
                                                                                            public void testGuessAOmega_AmplitudeCalculation10() {
                                                                                                // Create test observations that will trigger the condition (c1/c2 < 0 or c2/c3 < 0)
                                                                                                WeightedObservedPoint[] observations = {
                                                                                                    new WeightedObservedPoint(1.0, 0.0, 1.0),  // x, y, weight
                                                                                                    new WeightedObservedPoint(2.0, 2.0, 1.0),
                                                                                                    new WeightedObservedPoint(3.0, 0.0, 1.0),
                                                                                                    new WeightedObservedPoint(4.0, -2.0, 1.0),
                                                                                                    new WeightedObservedPoint(5.0, 0.0, 1.0)
                                                                                                };
                                                                                                
                                                                                                // Create HarmonicFitter instance (optimizer doesn't matter for this test)
                                                                                                HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                                
                                                                                                // Use reflection to set the observations since it's private final
                                                                                                try {
                                                                                                    Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                                    observationsField.setAccessible(true);
                                                                                                    observationsField.set(fitter, observations);
                                                                                                } catch (Exception e) {
                                                                                                    fail("Failed to set observations field: " + e.getMessage());
                                                                                                }
                                                                                                
                                                                                                // Call the method to test
                                                                                                try {
                                                                                                    Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                                    guessAOmega.setAccessible(true);
                                                                                                    guessAOmega.invoke(fitter);
                                                                                                } catch (Exception e) {
                                                                                                    fail("Failed to invoke guessAOmega: " + e.getMessage());
                                                                                                }
                                                                                                
                                                                                                // Verify the amplitude calculation
                                                                                                // Expected amplitude is half of (yMax - yMin) = 0.5 * (2.0 - (-2.0)) = 2.0
                                                                                                try {
                                                                                                    Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                                    aField.setAccessible(true);
                                                                                                    double calculatedA = aField.getDouble(fitter);
                                                                                                    
                                                                                                    assertEquals(2.0, calculatedA, 1e-10);
                                                                                                } catch (Exception e) {
                                                                                                    fail("Failed to verify amplitude: " + e.getMessage());
                                                                                                }
                                                                                            }

 @Test
                                                                                          public void testGuessAOmega_AmplitudeCalculation11() throws Exception {
                                                                                              // Create test observations that will trigger the condition path
                                                                                              // and have a clear y-range (min=1, max=3, range=2)
                                                                                              WeightedObservedPoint[] observations = {
                                                                                                  new WeightedObservedPoint(1.0, 0, 1),  // weight=1.0, x=0, y=1
                                                                                                  new WeightedObservedPoint(1.0, 1, 3),  // weight=1.0, x=1, y=3
                                                                                                  new WeightedObservedPoint(1.0, 2, 1)   // weight=1.0, x=2, y=1
                                                                                              };
                                                                                              
                                                                                              // Create HarmonicFitter instance and set observations
                                                                                              DifferentiableMultivariateVectorOptimizer optimizer = mock(DifferentiableMultivariateVectorOptimizer.class);
                                                                                              HarmonicFitter fitter = new HarmonicFitter(optimizer);
                                                                                              Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                              observationsField.setAccessible(true);
                                                                                              observationsField.set(fitter, observations);
                                                                                              
                                                                                              // Call the method under test
                                                                                              Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                              guessAOmega.setAccessible(true);
                                                                                              guessAOmega.invoke(fitter);
                                                                                              
                                                                                              // Verify amplitude calculation
                                                                                              // Original: a = 0.5 * (3 - 1) = 1.0
                                                                                              // Mutant: a = 1.0 (yMin)
                                                                                              // We need to check that it's not just yMin
                                                                                              Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                              aField.setAccessible(true);
                                                                                              double calculatedA = aField.getDouble(fitter);
                                                                                              
                                                                                              // Assert that amplitude is calculated correctly (half the range)
                                                                                              assertEquals(1.0, calculatedA, 1e-10);
                                                                                              
                                                                                              // Second test case with different y values
                                                                                              WeightedObservedPoint[] observations2 = {
                                                                                                  new WeightedObservedPoint(1.0, 0, 2),  // weight=1.0, x=0, y=2
                                                                                                  new WeightedObservedPoint(1.0, 1, 6),  // weight=1.0, x=1, y=6
                                                                                                  new WeightedObservedPoint(1.0, 2, 2)   // weight=1.0, x=2, y=2
                                                                                              };
                                                                                              observationsField.set(fitter, observations2);
                                                                                              guessAOmega.invoke(fitter);
                                                                                              calculatedA = aField.getDouble(fitter);
                                                                                              
                                                                                              // Third test case where yMin != half range
                                                                                              WeightedObservedPoint[] observations3 = {
                                                                                                  new WeightedObservedPoint(1.0, 0, 1),  // weight=1.0, x=0, y=1
                                                                                                  new WeightedObservedPoint(1.0, 1, 5),  // weight=1.0, x=1, y=5
                                                                                                  new WeightedObservedPoint(1.0, 2, 1)   // weight=1.0, x=2, y=1
                                                                                              };
                                                                                              observationsField.set(fitter, observations3);
                                                                                              guessAOmega.invoke(fitter);
                                                                                              calculatedA = aField.getDouble(fitter);
                                                                                              
                                                                                              assertEquals(2.0, calculatedA, 1e-10);
                                                                                          }

 @Test(expected = MathIllegalStateException.class)
                                                                                      public void testGuessAOmega_WhenC2IsZero_ShouldThrowException1() throws Exception {
                                                                                          // Create observations that will result in c2 = 0
                                                                                          // We need sxy*sxz = sx2*syz to make c2 zero
                                                                                          // Let's create simple data points that satisfy this condition
                                                                                          WeightedObservedPoint[] observations = {
                                                                                              new WeightedObservedPoint(1.0, 0.0, 0.0),  // weight, x, y
                                                                                              new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                              new WeightedObservedPoint(1.0, 2.0, 0.0)
                                                                                          };
                                                                                          
                                                                                          // Use reflection to access private method and fields
                                                                                          HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                          
                                                                                          // Set observations using reflection
                                                                                          Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                          observationsField.setAccessible(true);
                                                                                          observationsField.set(fitter, observations);
                                                                                          
                                                                                          // Call the private method
                                                                                          Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                          method.setAccessible(true);
                                                                                          method.invoke(fitter);
                                                                                          
                                                                                          // If we reach here, the test fails because exception wasn't thrown
                                                                                          // The mutant would pass this point when c2=0 because of the inverted condition
                                                                                          fail("Expected MathIllegalStateException when c2=0");
                                                                                      }

 @Test
                                                                                    public void testGuessAOmega_DetectsC2ZeroCase() {
                                                                                        // Create test data that will result in c2=0
                                                                                        WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                                            new WeightedObservedPoint(1.0, 0.0, 1.0),
                                                                                            new WeightedObservedPoint(1.0, 0.0, 1.0)  // Same point will make dx=0 leading to c2=0
                                                                                        };
                                                                                        
                                                                                        // Use reflection to test private method
                                                                                        try {
                                                                                            HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                            Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                            observationsField.setAccessible(true);
                                                                                            observationsField.set(fitter, observations);
                                                                                            
                                                                                            Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                            guessAOmega.setAccessible(true);
                                                                                            guessAOmega.invoke(fitter);
                                                                                        } catch (InvocationTargetException e) {
                                                                                            // Unwrap the actual exception and fail if it's not the expected one
                                                                                            Throwable cause = e.getCause();
                                                                                            if (!(cause instanceof Exception)) {
                                                                                                fail("Unexpected exception type: " + cause.getClass().getName());
                                                                                            }
                                                                                            // We expect an exception to be thrown, so this is good
                                                                                        } catch (Exception e) {
                                                                                            fail("Unexpected exception: " + e.getMessage());
                                                                                        }
                                                                                    }

 @Test
                                                                                public void testGuessAOmega_ShouldNotThrowExceptionWhenC2IsNotZero() throws Exception {
                                                                                    // Create observations that will result in c2 != 0
                                                                                    WeightedObservedPoint[] observations = {
                                                                                        new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                                        new WeightedObservedPoint(1.0, Math.PI/2, 1.0),
                                                                                        new WeightedObservedPoint(1.0, Math.PI, -1.0),
                                                                                        new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0),
                                                                                        new WeightedObservedPoint(1.0, 2*Math.PI, 1.0)
                                                                                    };
                                                                                    
                                                                                    // Use reflection to test private method
                                                                                    HarmonicFitter fitter = new HarmonicFitter(mock(DifferentiableMultivariateVectorOptimizer.class));
                                                                                    
                                                                                    // Set observations field via reflection
                                                                                    Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                    observationsField.setAccessible(true);
                                                                                    observationsField.set(fitter, observations);
                                                                                    
                                                                                    // Call the private method
                                                                                    Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    try {
                                                                                        method.invoke(fitter);
                                                                                        // If we get here, the test passes (original behavior)
                                                                                        // Check that a and omega were set to reasonable values
                                                                                        Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                                        aField.setAccessible(true);
                                                                                        double a = aField.getDouble(fitter);
                                                                                        assertTrue(a > 0);
                                                                                        
                                                                                        Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                                                        omegaField.setAccessible(true);
                                                                                        double omega = omegaField.getDouble(fitter);
                                                                                        assertTrue(omega > 0);
                                                                                    } catch (InvocationTargetException e) {
                                                                                        if (e.getCause() instanceof MathIllegalStateException) {
                                                                                            fail("Method threw MathIllegalStateException when it shouldn't have (mutant detected)");
                                                                                        } else {
                                                                                            throw e;
                                                                                        }
                                                                                    }
                                                                                }

 @Test(expected = MathIllegalStateException.class)
                                                                               public void testGuessAOmega_WhenC2IsZero_ShouldThrowException2() throws Exception {
                                                                                   // Create observations that will result in c2=0
                                                                                   // We need sxz*sxy = sx2*syz and sy2*sxz = sxy*syz
                                                                                   // One way is to have all y values equal (dy=0) and equally spaced x values
                                                                                   WeightedObservedPoint[] observations = {
                                                                                       new WeightedObservedPoint(1.0, 1.0, 1.0),  // weight, x, y
                                                                                       new WeightedObservedPoint(1.0, 2.0, 1.0),
                                                                                       new WeightedObservedPoint(1.0, 3.0, 1.0)
                                                                                   };
                                                                                   
                                                                                   // Use reflection to access private method and fields
                                                                                   HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                   Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                   observationsField.setAccessible(true);
                                                                                   observationsField.set(fitter, observations);
                                                                                   
                                                                                   Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                   guessAOmega.setAccessible(true);
                                                                                   
                                                                                   // This should throw MathIllegalStateException in original code
                                                                                   // If mutant is present (if(false)), it will proceed to division by zero
                                                                                   guessAOmega.invoke(fitter);
                                                                               }

 @Test
                                                                         public void testGuessAOmegaThrowsCorrectExceptionWhenC2IsZero() {
                                                                             // Create test data that will make c2=0 in the calculations
                                                                             // We need observations that will lead to sx2*syz = sxy*sxz in the calculations
                                                                             WeightedObservedPoint[] observations = {
                                                                                 new WeightedObservedPoint(1.0, 0.0, 0.0),  // weight, x, y
                                                                                 new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                 new WeightedObservedPoint(1.0, 2.0, 0.0)
                                                                             };
                                                                             
                                                                             // Use reflection to test the private method
                                                                             try {
                                                                                 HarmonicFitter fitter = new HarmonicFitter(null);
                                                                                 
                                                                                 // Set observations field via reflection
                                                                                 Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                                 observationsField.setAccessible(true);
                                                                                 observationsField.set(fitter, observations);
                                                                                 
                                                                                 // Get the method via reflection
                                                                                 Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                                 method.setAccessible(true);
                                                                                 
                                                                                 // This should throw the exception
                                                                                 method.invoke(fitter);
                                                                                 
                                                                                 // If we get here, the test fails
                                                                                 fail("Expected MathIllegalStateException");
                                                                             } catch (InvocationTargetException e) {
                                                                                 // Check the actual cause of the exception
                                                                                 Throwable cause = e.getCause();
                                                                                 assertTrue(cause instanceof MathIllegalStateException);
                                                                                 assertEquals("zero denominator", 
                                                                                            ((MathIllegalStateException)cause).getMessage());
                                                                             } catch (Exception e) {
                                                                                 fail("Unexpected exception: " + e);
                                                                             }
                                                                         }

 @Test(expected = MathIllegalStateException.class)
                                                                    public void testGuessAOmegaWithZeroDenominator1() {
                                                                        // Create test data that will make c2 == 0 in the calculations
                                                                        // We need observations that will lead to sx2*syz == sxy*sxz in the calculations
                                                                        // One way is to create a simple set of points where this condition holds
                                                                        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] observations = {
                                                                            new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                            new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                            new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(1.0, 2.0, 1.0)
                                                                        };
                                                                        
                                                                        // Since we can't directly test the private method, we'll use reflection
                                                                        // to set the observations and then call a public method that uses guessAOmega
                                                                        org.apache.commons.math3.optimization.fitting.HarmonicFitter fitter = 
                                                                            new org.apache.commons.math3.optimization.fitting.HarmonicFitter(
                                                                                new org.apache.commons.math3.optimization.general.LevenbergMarquardtOptimizer());
                                                                        
                                                                        try {
                                                                            // Use reflection to set the private observations field
                                                                            java.lang.reflect.Field observationsField = 
                                                                                org.apache.commons.math3.optimization.fitting.HarmonicFitter.class.getDeclaredField("observations");
                                                                            observationsField.setAccessible(true);
                                                                            observationsField.set(fitter, observations);
                                                                            
                                                                            // Call fit() which will internally call guessAOmega()
                                                                            fitter.fit();
                                                                        } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                            fail("Failed to set up test using reflection: " + e.getMessage());
                                                                        }
                                                                        
                                                                        // If we get here, the mutant survived (no exception was thrown)
                                                                        // The @Test(expected) annotation will verify the exception is thrown
                                                                    }

 @Test
                                                                public void testGuessAOmegaWithZeroDenominator2() {
                                                                    // Create test data that will likely make c2 == 0 in the calculations
                                                                    // This is a bit tricky since we don't have direct access to the internals
                                                                    // We'll use constant y-values which might trigger the condition
                                                                    org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] observations = 
                                                                        new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[3];
                                                                    for (int i = 0; i < 3; i++) {
                                                                        observations[i] = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(1.0, i, 1.0);  // constant y-values
                                                                    }
                                                                    
                                                                    org.apache.commons.math3.optimization.fitting.HarmonicFitter fitter = 
                                                                        new org.apache.commons.math3.optimization.fitting.HarmonicFitter(
                                                                            new org.apache.commons.math3.optimization.general.LevenbergMarquardtOptimizer());
                                                                    
                                                                    // Add observations to the fitter
                                                                    for (org.apache.commons.math3.optimization.fitting.WeightedObservedPoint observation : observations) {
                                                                        fitter.addObservedPoint(observation);
                                                                    }
                                                                    
                                                                    try {
                                                                        fitter.fit();  // Call fit() without parameters
                                                                        fail("Expected ConvergenceException");
                                                                    } catch (org.apache.commons.math3.exception.ConvergenceException e) {
                                                                        // Expected behavior
                                                                    }
                                                                }

 @Test(expected = MathIllegalStateException.class)
                                                            public void testGuessAOmega_ThrowsExceptionWhenC2IsZero() {
                                                                // Create test data that will result in c2 == 0
                                                                WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                    new WeightedObservedPoint(1.0, 0.0, 1.0),
                                                                    new WeightedObservedPoint(1.0, Math.PI, -1.0),
                                                                    new WeightedObservedPoint(1.0, 2*Math.PI, 1.0)
                                                                };
                                                                
                                                                // Use reflection to test private method
                                                                try {
                                                                    HarmonicFitter fitter = new HarmonicFitter(null);
                                                                    
                                                                    // Set observations field via reflection
                                                                    Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                    observationsField.setAccessible(true);
                                                                    observationsField.set(fitter, observations);
                                                                    
                                                                    // Call private method via reflection
                                                                    Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                    method.setAccessible(true);
                                                                    method.invoke(fitter);
                                                                } catch (InvocationTargetException e) {
                                                                    // Unwrap the expected exception
                                                                    throw (RuntimeException) e.getCause();
                                                                } catch (Exception e) {
                                                                    fail("Unexpected exception: " + e);
                                                                }
                                                            }

 @Test
                                                           public void testGuessAOmega_DetectsMutatedAmplitudeCalculation1() {
                                                               // Create test observations that will produce known c1 and c2 values
                                                               WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                                   new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                   new WeightedObservedPoint(1.0, 1.0, 2.0),
                                                                   new WeightedObservedPoint(1.0, 2.0, 1.0),
                                                                   new WeightedObservedPoint(1.0, 3.0, 0.0)
                                                               };
                                                               
                                                               // Create HarmonicFitter instance and set observations
                                                               // Note: We need to use reflection to set private observations field
                                                               HarmonicFitter fitter = new HarmonicFitter(null); // optimizer can be null for this test
                                                               try {
                                                                   Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                   observationsField.setAccessible(true);
                                                                   observationsField.set(fitter, observations);
                                                               } catch (Exception e) {
                                                                   fail("Failed to set observations field via reflection");
                                                               }
                                                               
                                                               // Call the method under test
                                                               try {
                                                                   Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                   guessAOmega.setAccessible(true);
                                                                   guessAOmega.invoke(fitter);
                                                               } catch (Exception e) {
                                                                   fail("Failed to invoke guessAOmega method");
                                                               }
                                                               
                                                               // Get the calculated amplitude
                                                               double calculatedA;
                                                               try {
                                                                   Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                   aField.setAccessible(true);
                                                                   calculatedA = aField.getDouble(fitter);
                                                               } catch (Exception e) {
                                                                   fail("Failed to get amplitude field");
                                                                   return;
                                                               }
                                                               
                                                               // Expected amplitude calculation:
                                                               // For the given observations, we know:
                                                               // c1 = sy2*sxz - sxy*syz ≈ 0.6944
                                                               // c2 = sxy*sxz - sx2*syz ≈ 0.1389
                                                               // So a should be sqrt(c1/c2) ≈ sqrt(5) ≈ 2.236
                                                               // The mutant would calculate sqrt(c2/c1) ≈ sqrt(0.2) ≈ 0.447
                                                               
                                                               double expectedA = Math.sqrt(5.0); // ≈ 2.236
                                                               double mutantA = Math.sqrt(0.2);  // ≈ 0.447
                                                               
                                                               // Verify the calculated amplitude matches expected, not mutant
                                                               assertEquals(expectedA, calculatedA, 0.001);
                                                               
                                                               // Additional check to ensure we're not getting the mutant value
                                                               assertNotEquals(mutantA, calculatedA, 0.001);
                                                           }

 @Test
                                                          public void testGuessAOmega_DetectsSqrtMutation1() {
                                                              // Create test observations that will result in c1/c2 not being a perfect square
                                                              WeightedObservedPoint[] observations = {
                                                                  new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                                  new WeightedObservedPoint(1.0, 1.0, 2.0),
                                                                  new WeightedObservedPoint(1.0, 2.0, 1.5),
                                                                  new WeightedObservedPoint(1.0, 3.0, 0.5),
                                                                  new WeightedObservedPoint(1.0, 4.0, 1.0)
                                                              };
                                                              
                                                              HarmonicFitter fitter = new HarmonicFitter(null);
                                                              // Use reflection to set the observations since it's private final
                                                              try {
                                                                  Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                                  observationsField.setAccessible(true);
                                                                  observationsField.set(fitter, observations);
                                                              } catch (Exception e) {
                                                                  fail("Failed to set observations field via reflection");
                                                              }
                                                              
                                                              // Call the method under test
                                                              try {
                                                                  Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                                  guessAOmega.setAccessible(true);
                                                                  guessAOmega.invoke(fitter);
                                                              } catch (Exception e) {
                                                                  fail("Failed to invoke guessAOmega method");
                                                              }
                                                              
                                                              // Get the calculated amplitude
                                                              double calculatedA;
                                                              try {
                                                                  Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                                  aField.setAccessible(true);
                                                                  calculatedA = aField.getDouble(fitter);
                                                              } catch (Exception e) {
                                                                  fail("Failed to get 'a' field value");
                                                                  return;
                                                              }
                                                              
                                                              // Calculate what the value would be with the mutation (c1/c2)
                                                              // We need to compute c1 and c2 based on the test data
                                                              // This is a simplified version of the calculations in the method
                                                              double sx2 = 0, sy2 = 0, sxy = 0, sxz = 0, syz = 0;
                                                              double currentX = observations[0].getX();
                                                              double currentY = observations[0].getY();
                                                              double f2Integral = 0;
                                                              double fPrime2Integral = 0;
                                                              final double startX = currentX;
                                                              
                                                              for (int i = 1; i < observations.length; ++i) {
                                                                  final double previousX = currentX;
                                                                  final double previousY = currentY;
                                                                  currentX = observations[i].getX();
                                                                  currentY = observations[i].getY();
                                                                  
                                                                  final double dx = currentX - previousX;
                                                                  final double dy = currentY - previousY;
                                                                  final double f2StepIntegral = dx * (previousY * previousY + previousY * currentY + currentY * currentY) / 3;
                                                                  final double fPrime2StepIntegral = dy * dy / dx;
                                                                  
                                                                  final double x = currentX - startX;
                                                                  f2Integral += f2StepIntegral;
                                                                  fPrime2Integral += fPrime2StepIntegral;
                                                                  
                                                                  sx2 += x * x;
                                                                  sy2 += f2Integral * f2Integral;
                                                                  sxy += x * f2Integral;
                                                                  sxz += x * fPrime2Integral;
                                                                  syz += f2Integral * fPrime2Integral;
                                                              }
                                                              
                                                              double c1 = sy2 * sxz - sxy * syz;
                                                              double c2 = sxy * sxz - sx2 * syz;
                                                              double c3 = sx2 * sy2 - sxy * sxy;
                                                              
                                                              // Only proceed if we're in the sqrt branch
                                                              if (!((c1 / c2 < 0) || (c2 / c3 < 0)) && c2 != 0) {
                                                                  double expectedA = FastMath.sqrt(c1 / c2);
                                                                  double mutatedA = c1 / c2;
                                                                  
                                                                  // Verify that the calculated value matches the sqrt version, not the mutated version
                                                                  assertEquals(expectedA, calculatedA, 1e-10);
                                                                  assertNotEquals(mutatedA, calculatedA, 1e-10);
                                                              } else {
                                                                  fail("Test data didn't trigger the sqrt branch");
                                                              }
                                                          }

 @Test
                                                    public void testGuessAOmega_DetectsSqrtToAbsMutation() {
                                                        // Create observations that will trigger the else branch (positive c1/c2 and c2/c3)
                                                        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] observations = {
                                                            new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(1.0, 0.0, 1.0),  // t=0, y=1
                                                            new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(1.0, Math.PI/2, 0.0),  // t=π/2, y=0
                                                            new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(1.0, Math.PI, -1.0)   // t=π, y=-1
                                                        };
                                                        
                                                        // Create HarmonicFitter instance (optimizer doesn't matter for this test)
                                                        org.apache.commons.math3.optimization.fitting.HarmonicFitter fitter = 
                                                            new org.apache.commons.math3.optimization.fitting.HarmonicFitter(
                                                                new org.apache.commons.math3.optimization.general.LevenbergMarquardtOptimizer());
                                                        
                                                        // Use reflection to set observations since it's private final
                                                        try {
                                                            Field observationsField = org.apache.commons.math3.optimization.fitting.HarmonicFitter.class.getDeclaredField("observations");
                                                            observationsField.setAccessible(true);
                                                            observationsField.set(fitter, observations);
                                                        } catch (Exception e) {
                                                            org.junit.Assert.fail("Failed to set observations field: " + e.getMessage());
                                                        }
                                                        
                                                        // Call the method under test
                                                        try {
                                                            Method guessAOmega = org.apache.commons.math3.optimization.fitting.HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                            guessAOmega.setAccessible(true);
                                                            guessAOmega.invoke(fitter);
                                                        } catch (Exception e) {
                                                            org.junit.Assert.fail("Failed to invoke guessAOmega: " + e.getMessage());
                                                        }
                                                        
                                                        // Get the amplitude value
                                                        double amplitude;
                                                        try {
                                                            Field aField = org.apache.commons.math3.optimization.fitting.HarmonicFitter.class.getDeclaredField("a");
                                                            aField.setAccessible(true);
                                                            amplitude = aField.getDouble(fitter);
                                                        } catch (Exception e) {
                                                            org.junit.Assert.fail("Failed to get amplitude: " + e.getMessage());
                                                            return;
                                                        }
                                                        
                                                        // Expected amplitude is 1.0 (since we created a sine wave with amplitude 1)
                                                        // The mutant would calculate amplitude as (c1/c2) which would be different
                                                        org.junit.Assert.assertEquals(1.0, amplitude, 0.01);
                                                        
                                                        // Additional verification: check that amplitude is indeed the square root
                                                        // For our test data, c1/c2 should be approximately 1 (1^2 = 1)
                                                        // If it were using abs, the value would be different
                                                        org.junit.Assert.assertTrue(Math.abs(amplitude * amplitude - 1.0) < 0.01);
                                                    }

 @Test
                                                public void testGuessAOmega_DetectsAmplitudeCalculationMutant() throws Exception {
                                                    // Create test observations that will make c1/c2 and c2/c3 positive
                                                    WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                                        new WeightedObservedPoint(1.0, 0.0, 1.0),  // t=0, y=0
                                                        new WeightedObservedPoint(1.0, Math.PI/2, 2.0),  // t=π/2, y=2 (peak)
                                                        new WeightedObservedPoint(1.0, Math.PI, 0.0),   // t=π, y=0
                                                        new WeightedObservedPoint(1.0, 3*Math.PI/2, -2.0) // t=3π/2, y=-2 (trough)
                                                    };
                                                    
                                                    // Use reflection to test private method
                                                    HarmonicFitter fitter = new HarmonicFitter(null);
                                                    Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                    observationsField.setAccessible(true);
                                                    observationsField.set(fitter, observations);
                                                    
                                                    Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                    guessAOmega.setAccessible(true);
                                                    guessAOmega.invoke(fitter);
                                                    
                                                    // Get the calculated amplitude
                                                    Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                    aField.setAccessible(true);
                                                    double calculatedA = aField.getDouble(fitter);
                                                    
                                                    // For our test data, we know the amplitude should be 2.0
                                                    // The mutant would set it to 0.0 instead of calculating properly
                                                    assertEquals("Amplitude should be calculated correctly", 2.0, calculatedA, 1e-10);
                                                    
                                                    // Also verify omega was calculated (though not the focus of this test)
                                                    Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                    omegaField.setAccessible(true);
                                                    double calculatedOmega = omegaField.getDouble(fitter);
                                                    assertEquals("Omega should be calculated correctly", 1.0, calculatedOmega, 1e-10);
                                                }

 @Test
                                               public void testGuessAOmegaDetectsAmplitudeMutation() throws Exception {
                                                   // Create test observations that will produce c1/c2 > 0 and c2/c3 > 0
                                                   // and result in amplitude != 1.0
                                                   WeightedObservedPoint[] observations = {
                                                       new WeightedObservedPoint(1.0, 2.0, 1.0),  // x, y, weight
                                                       new WeightedObservedPoint(2.0, 4.0, 1.0),
                                                       new WeightedObservedPoint(3.0, 6.0, 1.0)
                                                   };
                                                   
                                                   // Use reflection to access private method and fields
                                                   HarmonicFitter fitter = new HarmonicFitter(mock(DifferentiableMultivariateVectorOptimizer.class));
                                                   
                                                   // Set observations using reflection
                                                   Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                   observationsField.setAccessible(true);
                                                   observationsField.set(fitter, observations);
                                                   
                                                   // Call the private method
                                                   Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                   guessAOmega.setAccessible(true);
                                                   guessAOmega.invoke(fitter);
                                                   
                                                   // Get the amplitude value
                                                   Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                   aField.setAccessible(true);
                                                   double amplitude = aField.getDouble(fitter);
                                                   
                                                   // Verify amplitude is calculated correctly (not 1.0)
                                                   // For these observations, the amplitude should be > 1.0
                                                   assertTrue("Amplitude should be calculated, not set to 1.0", 
                                                              amplitude != 1.0 && !Double.isNaN(amplitude));
                                                   
                                                   // Additional verification that omega is also calculated
                                                   Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                   omegaField.setAccessible(true);
                                                   double omega = omegaField.getDouble(fitter);
                                                   assertFalse("Omega should be calculated", Double.isNaN(omega));
                                               }

 @Test
                                              public void testGuessAOmegaDetectsMutant1() throws Exception {
                                                  // Create test observations that will produce known c2 and c3 values
                                                  WeightedObservedPoint[] observations = {
                                                      new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                                      new WeightedObservedPoint(1.0, Math.PI/2, 1.0),
                                                      new WeightedObservedPoint(1.0, Math.PI, -1.0),
                                                      new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0),
                                                      new WeightedObservedPoint(1.0, 2*Math.PI, 1.0)
                                                  };
                                                  
                                                  // Create HarmonicFitter instance and inject observations using reflection
                                                  HarmonicFitter fitter = new HarmonicFitter(null);
                                                  Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                  observationsField.setAccessible(true);
                                                  observationsField.set(fitter, observations);
                                                  
                                                  // Call the private method using reflection
                                                  Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                  guessAOmega.setAccessible(true);
                                                  guessAOmega.invoke(fitter);
                                                  
                                                  // Get the calculated omega using reflection
                                                  Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                  omegaField.setAccessible(true);
                                                  double actualOmega = omegaField.getDouble(fitter);
                                                  
                                                  // Expected omega should be approximately 1.0 for this test data
                                                  // (since we used points from a sine wave with omega=1)
                                                  double expectedOmega = 1.0;
                                                  
                                                  // Assert with tolerance for floating point calculations
                                                  assertEquals(expectedOmega, actualOmega, 0.01);
                                                  
                                                  // Additional check to ensure c2 and c3 are different
                                                  // (so the mutant would produce a different result)
                                                  assertNotEquals(0.0, actualOmega - 1.0/expectedOmega, 0.01);
                                              }

 @Test
                                              public void testGuessAOmegaDetectsMutant2() throws Exception {
                                                  // Create test observations that will produce c2 != c3
                                                  WeightedObservedPoint[] observations = {
                                                      new WeightedObservedPoint(1.0, 0.0, 0.0),
                                                      new WeightedObservedPoint(1.0, 1.0, 2.0),
                                                      new WeightedObservedPoint(1.0, 2.0, 4.0),
                                                      new WeightedObservedPoint(1.0, 3.0, 6.0)
                                                  };
                                                  
                                                  HarmonicFitter fitter = new HarmonicFitter(null);
                                                  Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                  observationsField.setAccessible(true);
                                                  observationsField.set(fitter, observations);
                                                  
                                                  Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                  guessAOmega.setAccessible(true);
                                                  guessAOmega.invoke(fitter);
                                                  
                                                  Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                  omegaField.setAccessible(true);
                                                  double actualOmega = omegaField.getDouble(fitter);
                                                  
                                                  // For this linear data, the original formula should give a specific value
                                                  // while the mutant would give its reciprocal
                                                  double expectedOmega = 1.224744871391589;  // sqrt(1.5)
                                                  double mutantOmega = 0.816496580927726;   // sqrt(1/1.5)
                                                  
                                                  // Verify we got the correct value, not the mutant's value
                                                  assertEquals(expectedOmega, actualOmega, 1.0e-10);
                                                  assertNotEquals(mutantOmega, actualOmega, 1.0e-10);
                                              }

 @Test
                                             public void testGuessAOmegaDetectsSqrtMutation1() {
                                                 // Create test observations that will produce c2/c3 = 4 (perfect square)
                                                 WeightedObservedPoint[] observations = {
                                                     new WeightedObservedPoint(1.0, 0.0, 0.0),  // weight, x, y
                                                     new WeightedObservedPoint(1.0, Math.PI/2, 1.0),
                                                     new WeightedObservedPoint(1.0, Math.PI, 0.0),
                                                     new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0),
                                                     new WeightedObservedPoint(1.0, 2*Math.PI, 0.0)
                                                 };
                                                 
                                                 HarmonicFitter fitter = new HarmonicFitter(null);
                                                 // Use reflection to set private observations field
                                                 try {
                                                     Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                     observationsField.setAccessible(true);
                                                     observationsField.set(fitter, observations);
                                                 } catch (Exception e) {
                                                     fail("Failed to set observations field via reflection");
                                                 }
                                                 
                                                 // Call the private method using reflection
                                                 try {
                                                     Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                     method.setAccessible(true);
                                                     method.invoke(fitter);
                                                 } catch (Exception e) {
                                                     fail("Failed to invoke guessAOmega method");
                                                 }
                                                 
                                                 // Get the omega value using reflection
                                                 double omega;
                                                 try {
                                                     Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                     omegaField.setAccessible(true);
                                                     omega = omegaField.getDouble(fitter);
                                                 } catch (Exception e) {
                                                     fail("Failed to get omega field");
                                                     return;
                                                 }
                                                 
                                                 // The correct omega should be 1.0 (frequency of sine wave)
                                                 // The mutant would return 1.0^2 = 1.0, so we need more precise test
                                                 // Let's verify the calculation is using sqrt by checking precision
                                                 
                                                 // Create a case where c2/c3 = 4 (sqrt would be 2)
                                                 // The test data above is designed to produce c2/c3 = omega^2
                                                 // For perfect sine wave with frequency 1, we expect omega = 1
                                                 assertEquals(1.0, omega, 1e-10);
                                                 
                                                 // Additional verification that it's not just returning the ratio
                                                 // If it were returning c2/c3 directly, it would be 1.0 for this case
                                                 // So we need to verify with another test case where c2/c3 != omega
                                                 
                                                 // Alternative approach: verify the calculation uses sqrt
                                                 // by checking the relationship between a and omega
                                                 double a;
                                                 try {
                                                     Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                     aField.setAccessible(true);
                                                     a = aField.getDouble(fitter);
                                                 } catch (Exception e) {
                                                     fail("Failed to get a field");
                                                     return;
                                                 }
                                                 
                                                 // For our test data, amplitude should be 1.0
                                                 assertEquals(1.0, a, 1e-10);
                                                 
                                                 // The key assertion: verify omega is the sqrt of what the mutant would return
                                                 // Since we can't access c2 and c3 directly, we rely on the physical correctness
                                                 // of the result for a known sine wave pattern
                                             }

 @Test
                                            public void testGuessAOmegaDetectsSqrtToAbsMutant2() throws Exception {
                                                // Create observations that will result in c2/c3 = 4
                                                // We need sx2*sy2 - sxy*sxy = c3, and other sums to produce c2=4*c3
                                                // This requires carefully crafted data points
                                                
                                                // Create mock observations that will produce the desired sums
                                                WeightedObservedPoint[] observations = new WeightedObservedPoint[3];
                                                observations[0] = new WeightedObservedPoint(1.0, 0.0, 1.0);  // x=1.0, y=0.0
                                                observations[1] = new WeightedObservedPoint(2.0, 2.0, 1.0);  // x=2.0, y=2.0
                                                observations[2] = new WeightedObservedPoint(3.0, 0.0, 1.0);  // x=3.0, y=0.0
                                                
                                                // Use reflection to set private observations field and call private method
                                                HarmonicFitter fitter = new HarmonicFitter(null);
                                                Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                                observationsField.setAccessible(true);
                                                observationsField.set(fitter, observations);
                                                
                                                Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                                guessAOmega.setAccessible(true);
                                                guessAOmega.invoke(fitter);
                                                
                                                // Get the omega value using reflection
                                                Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                                omegaField.setAccessible(true);
                                                double omega = omegaField.getDouble(fitter);
                                                
                                                // Verify omega is sqrt(c2/c3) not abs(c2/c3)
                                                // With these observations, c2/c3 should be 4, so:
                                                // Original: omega = sqrt(4) = 2
                                                // Mutant: omega = abs(4) = 4
                                                assertEquals(2.0, omega, 1e-10);
                                                
                                                // Also verify amplitude 'a' is calculated correctly as a secondary check
                                                Field aField = HarmonicFitter.class.getDeclaredField("a");
                                                aField.setAccessible(true);
                                                double a = aField.getDouble(fitter);
                                                assertEquals(1.0, a, 1e-10);  // Expected amplitude for this simple harmonic
                                            }

 @Test
                                           public void testGuessAOmega_DetectsOmegaZeroMutant() throws Exception {
                                               // Create test data - simple harmonic wave with known frequency (2π)
                                               WeightedObservedPoint[] observations = new WeightedObservedPoint[4];
                                               observations[0] = new WeightedObservedPoint(1.0, 0.0, 1.0);  // t=0, y=0
                                               observations[1] = new WeightedObservedPoint(1.0, 1.0, 1.0);  // t=0.25, y=1
                                               observations[2] = new WeightedObservedPoint(1.0, 0.0, 1.0);  // t=0.5, y=0
                                               observations[3] = new WeightedObservedPoint(1.0, -1.0, 1.0); // t=0.75, y=-1
                                               
                                               // Use reflection to test private method
                                               HarmonicFitter fitter = new HarmonicFitter(null);
                                               
                                               // Set observations field via reflection
                                               Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                               observationsField.setAccessible(true);
                                               observationsField.set(fitter, observations);
                                               
                                               // Call private guessAOmega method via reflection
                                               Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                               method.setAccessible(true);
                                               method.invoke(fitter);
                                               
                                               // Get omega field via reflection
                                               Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                               omegaField.setAccessible(true);
                                               double omega = omegaField.getDouble(fitter);
                                               
                                               // Verify omega is calculated correctly (should be ~2π for this data)
                                               // The mutant would set omega to 0.0
                                               assertEquals(2 * Math.PI, omega, 0.1);  // Allowing some numerical tolerance
                                           }

 @Test
                                          public void testGuessAOmega_AmplitudeCalculation12() throws Exception {
                                              // Create test observations that will trigger the amplitude calculation path
                                              WeightedObservedPoint[] observations = {
                                                  new WeightedObservedPoint(1.0, 0.0, 1.0),  // x, y, weight
                                                  new WeightedObservedPoint(2.0, 2.0, 1.0),
                                                  new WeightedObservedPoint(3.0, 0.0, 1.0),
                                                  new WeightedObservedPoint(4.0, -2.0, 1.0),
                                                  new WeightedObservedPoint(5.0, 0.0, 1.0)
                                              };
                                              
                                              // Create HarmonicFitter instance (constructor doesn't matter for this test)
                                              HarmonicFitter fitter = new HarmonicFitter(null);
                                              
                                              // Use reflection to set observations since it's private final
                                              Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                              observationsField.setAccessible(true);
                                              observationsField.set(fitter, observations);
                                              
                                              // Use reflection to call private guessAOmega method
                                              Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                              method.setAccessible(true);
                                              method.invoke(fitter);
                                              
                                              // Use reflection to get the calculated amplitude
                                              Field aField = HarmonicFitter.class.getDeclaredField("a");
                                              aField.setAccessible(true);
                                              double calculatedA = aField.getDouble(fitter);
                                              
                                              // Calculate expected amplitude (half of peak-to-peak)
                                              double yMin = -2.0;
                                              double yMax = 2.0;
                                              double expectedA = 0.5 * (yMax - yMin);  // Should be 2.0
                                              
                                              // Assert the calculated amplitude matches expected
                                              assertEquals(expectedA, calculatedA, 1e-10);
                                              
                                              // Also verify omega was calculated (though not the focus of this test)
                                              Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                              omegaField.setAccessible(true);
                                              double omega = omegaField.getDouble(fitter);
                                              assertTrue(omega > 0);  // Should be positive
                                          }

 @Test
                                         public void testGuessAOmega_AmplitudeCalculation13() throws Exception {
                                             // Create test observations that will trigger the branch where amplitude is calculated as 0.5*(yMax-yMin)
                                             WeightedObservedPoint[] observations = {
                                                 new WeightedObservedPoint(1.0, 1.0, 1.0),  // x, y, weight
                                                 new WeightedObservedPoint(2.0, 3.0, 1.0),
                                                 new WeightedObservedPoint(3.0, 1.0, 1.0),
                                                 new WeightedObservedPoint(4.0, 3.0, 1.0)
                                             };
                                             
                                             // yMin = 1.0, yMax = 3.0, so expected amplitude should be 0.5*(3.0-1.0) = 1.0
                                             
                                             // Use reflection to test private method
                                             HarmonicFitter fitter = new HarmonicFitter(null);
                                             
                                             // Set observations field via reflection
                                             Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                             observationsField.setAccessible(true);
                                             observationsField.set(fitter, observations);
                                             
                                             // Call private guessAOmega method via reflection
                                             Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                             method.setAccessible(true);
                                             method.invoke(fitter);
                                             
                                             // Get amplitude field via reflection
                                             Field aField = HarmonicFitter.class.getDeclaredField("a");
                                             aField.setAccessible(true);
                                             double calculatedA = aField.getDouble(fitter);
                                             
                                             // Verify amplitude is exactly half the difference
                                             assertEquals(1.0, calculatedA, 1e-10);
                                             
                                             // Also verify omega was calculated (though not the focus of this test)
                                             Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                             omegaField.setAccessible(true);
                                             double calculatedOmega = omegaField.getDouble(fitter);
                                             assertTrue(calculatedOmega > 0);
                                         }

 @Test
                                        public void testGuessAOmega_AmplitudeCalculation14() throws Exception {
                                            // Create test observations that will trigger the amplitude calculation path
                                            WeightedObservedPoint[] observations = {
                                                new WeightedObservedPoint(1.0, 0.0, 1.0),  // x=0.0, y=1.0
                                                new WeightedObservedPoint(1.0, Math.PI/2, 3.0),  // x=π/2, y=3.0
                                                new WeightedObservedPoint(1.0, Math.PI, 1.0),    // x=π, y=1.0
                                                new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0) // x=3π/2, y=-1.0
                                            };
                                            
                                            // yMin = -1.0, yMax = 3.0
                                            double expectedAmplitude = 0.5 * (3.0 - (-1.0)); // 2.0
                                            
                                            // Use reflection to test private method
                                            HarmonicFitter fitter = new HarmonicFitter(null);
                                            
                                            // Set observations field via reflection
                                            Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                            observationsField.setAccessible(true);
                                            observationsField.set(fitter, observations);
                                            
                                            // Call private method via reflection
                                            Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                            guessAOmega.setAccessible(true);
                                            guessAOmega.invoke(fitter);
                                            
                                            // Get amplitude field via reflection
                                            Field aField = HarmonicFitter.class.getDeclaredField("a");
                                            aField.setAccessible(true);
                                            double actualAmplitude = aField.getDouble(fitter);
                                            
                                            // Assert the amplitude is calculated correctly
                                            assertEquals("Amplitude should be exactly half of (yMax - yMin)", 
                                                        expectedAmplitude, actualAmplitude, 1e-10);
                                        }

 @Test
                                       public void testGuessAOmega_AmplitudeCalculation15() {
                                           // Create test observations that will trigger the fallback calculation path
                                           WeightedObservedPoint[] observations = {
                                               new WeightedObservedPoint(1.0, 0.0, 1.0),  // t=0, y=0
                                               new WeightedObservedPoint(1.0, Math.PI/2, 1.0),  // t=π/2, y=1
                                               new WeightedObservedPoint(1.0, Math.PI, 0.0),    // t=π, y=0
                                               new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0), // t=3π/2, y=-1
                                               new WeightedObservedPoint(1.0, 2*Math.PI, 0.0)   // t=2π, y=0
                                           };
                                           
                                           // Create HarmonicFitter instance (optimizer doesn't matter for this test)
                                           HarmonicFitter fitter = new HarmonicFitter(null);
                                           
                                           // Use reflection to set the observations since they're private final
                                           try {
                                               Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                               observationsField.setAccessible(true);
                                               observationsField.set(fitter, observations);
                                           } catch (Exception e) {
                                               fail("Failed to set observations field: " + e.getMessage());
                                           }
                                           
                                           // Call the method under test
                                           try {
                                               Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                               guessAOmega.setAccessible(true);
                                               guessAOmega.invoke(fitter);
                                           } catch (Exception e) {
                                               fail("Failed to invoke guessAOmega: " + e.getMessage());
                                           }
                                           
                                           // Verify the amplitude calculation
                                           // Expected amplitude is 1.0 (since y ranges from -1 to 1, 0.5*(1 - (-1)) = 1)
                                           // The mutant would calculate 2.0 instead
                                           try {
                                               Field aField = HarmonicFitter.class.getDeclaredField("a");
                                               aField.setAccessible(true);
                                               double calculatedA = aField.getDouble(fitter);
                                               
                                               assertEquals(1.0, calculatedA, 1e-10);
                                           } catch (Exception e) {
                                               fail("Failed to verify amplitude: " + e.getMessage());
                                           }
                                       }

 @Test
                                     public void testGuessAOmega_AmplitudeCalculation16() throws Exception {
                                         // Create test observations that will trigger the condition path
                                         // and have known y-values (min=2, max=6, range=4, expected amplitude=2)
                                         WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                             new WeightedObservedPoint(1.0, 1.0, 3.0),  // x=1, y=3 (won't be min/max)
                                             new WeightedObservedPoint(1.0, 2.0, 2.0),  // x=2, y=2 (min)
                                             new WeightedObservedPoint(1.0, 3.0, 4.0),  // x=3, y=4
                                             new WeightedObservedPoint(1.0, 4.0, 6.0)   // x=4, y=6 (max)
                                         };
                                         
                                         // Create HarmonicFitter instance and set observations
                                         // Note: We need to use reflection to set private fields since there's no setter
                                         HarmonicFitter fitter = new HarmonicFitter(mock(DifferentiableMultivariateVectorOptimizer.class));
                                         Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                         observationsField.setAccessible(true);
                                         observationsField.set(fitter, observations);
                                         
                                         // Call the private method using reflection
                                         Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                         guessAOmega.setAccessible(true);
                                         guessAOmega.invoke(fitter);
                                         
                                         // Verify the amplitude 'a' was calculated correctly
                                         Field aField = HarmonicFitter.class.getDeclaredField("a");
                                         aField.setAccessible(true);
                                         double calculatedA = aField.getDouble(fitter);
                                         
                                         // Original code should calculate 0.5*(6-2) = 2
                                         // Mutant would just take yMin = 2
                                         assertEquals(2.0, calculatedA, 1e-10);
                                         
                                         // Also verify omega was calculated (though not part of this mutation)
                                         Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                         omegaField.setAccessible(true);
                                         double calculatedOmega = omegaField.getDouble(fitter);
                                         assertTrue(calculatedOmega > 0);  // Should be positive
                                     }

 @Test
                                     public void testGuessAOmega_AmplitudeCalculation17() throws Exception {
                                         // Create test observations with different min/max values
                                         // min=3, max=7, range=4, expected amplitude=2
                                         WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                             new WeightedObservedPoint(1.0, 1.0, 4.0),
                                             new WeightedObservedPoint(1.0, 2.0, 3.0),  // min
                                             new WeightedObservedPoint(1.0, 3.0, 5.0),
                                             new WeightedObservedPoint(1.0, 4.0, 7.0)   // max
                                         };
                                         
                                         HarmonicFitter fitter = new HarmonicFitter(mock(DifferentiableMultivariateVectorOptimizer.class));
                                         Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                         observationsField.setAccessible(true);
                                         observationsField.set(fitter, observations);
                                         
                                         Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                         guessAOmega.setAccessible(true);
                                         guessAOmega.invoke(fitter);
                                         
                                         Field aField = HarmonicFitter.class.getDeclaredField("a");
                                         aField.setAccessible(true);
                                         double calculatedA = aField.getDouble(fitter);
                                         
                                         // Original code: 0.5*(7-3) = 2.0
                                         // Mutant code: 3.0
                                         assertEquals(2.0, calculatedA, 1e-10);  // This will fail for the mutant
                                     }

 @Test(expected = MathIllegalStateException.class)
                                   public void testGuessAOmega_WhenC2IsZero_ShouldThrowException3() {
                                       // Create observations that will result in c2=0
                                       WeightedObservedPoint[] observations = {
                                           new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                           new WeightedObservedPoint(1.0, 1.0, 1.0),
                                           new WeightedObservedPoint(1.0, 2.0, 1.0)
                                       };
                                       
                                       // Use reflection to test private method
                                       try {
                                           HarmonicFitter fitter = new HarmonicFitter(mock(DifferentiableMultivariateVectorOptimizer.class));
                                           
                                           // Set observations field via reflection
                                           Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                           observationsField.setAccessible(true);
                                           observationsField.set(fitter, observations);
                                           
                                           // Call private method via reflection
                                           Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                           method.setAccessible(true);
                                           method.invoke(fitter);
                                       } catch (InvocationTargetException e) {
                                           // Unwrap the actual exception
                                           throw (RuntimeException) e.getCause();
                                       } catch (Exception e) {
                                           fail("Unexpected exception: " + e);
                                       }
                                   }

 @Test
                                  public void testGuessAOmegaWithNonZeroC() throws Exception {
                                      // Create observations that will result in c2 != 0
                                      WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                          new WeightedObservedPoint(1.0, 0.0, 1.0),
                                          new WeightedObservedPoint(1.0, Math.PI/2, 1.0),
                                          new WeightedObservedPoint(1.0, Math.PI, 1.0)
                                      };
                                      
                                      // Create HarmonicFitter instance and set observations
                                      HarmonicFitter fitter = new HarmonicFitter(null);
                                      // Use reflection to set private observations field since there's no setter
                                      Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                      observationsField.setAccessible(true);
                                      observationsField.set(fitter, observations);
                                      
                                      // Use reflection to call private guessAOmega method
                                      Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                      method.setAccessible(true);
                                      
                                      // Should not throw exception for original code
                                      method.invoke(fitter);
                                      
                                      // Verify results were computed (original behavior)
                                      Field aField = HarmonicFitter.class.getDeclaredField("a");
                                      aField.setAccessible(true);
                                      double a = aField.getDouble(fitter);
                                      
                                      Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                                      omegaField.setAccessible(true);
                                      double omega = omegaField.getDouble(fitter);
                                      
                                      // Assert values were computed (would fail for mutant which throws exception)
                                      assertFalse(Double.isNaN(a));
                                      assertFalse(Double.isInfinite(a));
                                      assertFalse(Double.isNaN(omega));
                                      assertFalse(Double.isInfinite(omega));
                                  }

 @Test(expected = MathIllegalStateException.class)
                                 public void testGuessAOmega_DetectsZeroDenominator2() {
                                     // Create observations that will lead to c2=0
                                     // This requires creating data where sxy*sxz = sx2*syz
                                     // One way is to have all y values equal (dy=0) which makes fPrime2Integral=0
                                     WeightedObservedPoint[] observations = {
                                         new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                         new WeightedObservedPoint(1.0, 2.0, 1.0),
                                         new WeightedObservedPoint(1.0, 3.0, 1.0)
                                     };
                                     
                                     // Use reflection to test private method
                                     HarmonicFitter fitter = new HarmonicFitter(null);
                                     try {
                                         // Set observations field
                                         Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                         observationsField.setAccessible(true);
                                         observationsField.set(fitter, observations);
                                         
                                         // Call private method
                                         Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                         method.setAccessible(true);
                                         method.invoke(fitter);
                                     } catch (InvocationTargetException e) {
                                         // Unwrap the expected exception
                                         throw (RuntimeException) e.getCause();
                                     } catch (Exception e) {
                                         fail("Unexpected exception: " + e);
                                     }
                                 }

 @Test
                               public void testGuessAOmega_ZeroDenominatorCondition() {
                                   // Create test data that will lead to c2 == 0 condition
                                   WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                       new WeightedObservedPoint(1.0, 0.0, 1.0),
                                       new WeightedObservedPoint(1.0, 1.0, 1.0)  // Same x values will cause dx=0 in calculations
                                   };
                                   
                                   HarmonicFitter fitter = new HarmonicFitter(null);
                                   // Use reflection to set the private observations field
                                   try {
                                       Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                       observationsField.setAccessible(true);
                                       observationsField.set(fitter, observations);
                                       
                                       // Use reflection to call the private method
                                       Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                       guessAOmega.setAccessible(true);
                                       
                                       // This should throw MathIllegalStateException with ZERO_DENOMINATOR message
                                       guessAOmega.invoke(fitter);
                                       
                                       // If we get here, the test fails (no exception thrown)
                                       fail("Expected MathIllegalStateException");
                                   } catch (InvocationTargetException e) {
                                       // Get the actual exception thrown by the method
                                       Throwable cause = e.getCause();
                                       assertTrue(cause instanceof MathIllegalStateException);
                                       assertEquals("zero denominator", ((MathIllegalStateException)cause).getMessage());
                                   } catch (Exception e) {
                                       fail("Unexpected exception: " + e);
                                   }
                               }

 @Test(expected = MathIllegalStateException.class)
                           public void testGuessAOmega_ZeroDenominator1() {
                               // Create test data that will make c2 == 0
                               // We need observations that will lead to ill-conditioned calculations
                               WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                   new WeightedObservedPoint(1.0, 0.0, 1.0),
                                   new WeightedObservedPoint(1.0, 1.0, 1.0),
                                   new WeightedObservedPoint(1.0, 0.0, 1.0)
                               };
                               
                               // Create HarmonicFitter instance - need to use reflection since constructor is not standard
                               // and method is private
                               try {
                                   Constructor<HarmonicFitter> constructor = HarmonicFitter.class.getDeclaredConstructor(DifferentiableMultivariateVectorOptimizer.class);
                                   constructor.setAccessible(true);
                                   HarmonicFitter fitter = constructor.newInstance(mock(DifferentiableMultivariateVectorOptimizer.class));
                                   
                                   // Set observations using reflection since field is private
                                   Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                   observationsField.setAccessible(true);
                                   observationsField.set(fitter, observations);
                                   
                                   // Call the private method using reflection
                                   Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                   method.setAccessible(true);
                                   method.invoke(fitter);
                                   
                                   // If we get here, the mutant survived (no exception thrown)
                                   fail("Expected MathIllegalStateException but none was thrown");
                               } catch (InvocationTargetException e) {
                                   // Check if the cause is the expected exception
                                   if (e.getCause() instanceof MathIllegalStateException) {
                                       throw (MathIllegalStateException) e.getCause();
                                   }
                                   fail("Unexpected exception: " + e.getCause());
                               } catch (Exception e) {
                                   fail("Unexpected exception: " + e);
                               }
                           }

 @Test(expected = MathIllegalStateException.class)
                          public void testGuessAOmega_ZeroDenominator2() {
                              // Create test data that will result in c2 == 0
                              WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                  new WeightedObservedPoint(1.0, 0.0, 1.0),
                                  new WeightedObservedPoint(1.0, 1.0, 1.0),  // Same x values will lead to dx=0
                                  new WeightedObservedPoint(1.0, 2.0, 1.0)
                              };
                              
                              // Create HarmonicFitter instance and set observations
                              HarmonicFitter fitter = new HarmonicFitter(null);
                              try {
                                  // Use reflection to set private observations field for testing
                                  Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                  observationsField.setAccessible(true);
                                  observationsField.set(fitter, observations);
                                  
                                  // Call the method - should throw exception
                                  Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                  guessAOmega.setAccessible(true);
                                  guessAOmega.invoke(fitter);
                              } catch (InvocationTargetException e) {
                                  // Unwrap the actual exception thrown by the method
                                  throw (RuntimeException) e.getCause();
                              } catch (Exception e) {
                                  fail("Unexpected exception: " + e.getMessage());
                              }
                          }

 @Test
                         public void testGuessAOmega_DetectsMutatedAmplitudeCalculation2() {
                             // Create test observations where c1 and c2 will be different
                             WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                                 new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                                 new WeightedObservedPoint(1.0, Math.PI/2, 1.0),
                                 new WeightedObservedPoint(1.0, Math.PI, -1.0),
                                 new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0),
                                 new WeightedObservedPoint(1.0, 2*Math.PI, 1.0)
                             };
                             
                             // Create HarmonicFitter instance (we'll use reflection to test private method)
                             HarmonicFitter fitter = new HarmonicFitter(null);
                             
                             // Set observations using reflection since it's private final
                             try {
                                 Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                                 observationsField.setAccessible(true);
                                 observationsField.set(fitter, observations);
                             } catch (Exception e) {
                                 fail("Failed to set observations field via reflection");
                             }
                             
                             // Call the private method using reflection
                             try {
                                 Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                                 method.setAccessible(true);
                                 method.invoke(fitter);
                                 
                                 // Get the calculated amplitude
                                 Field aField = HarmonicFitter.class.getDeclaredField("a");
                                 aField.setAccessible(true);
                                 double calculatedA = aField.getDouble(fitter);
                                 
                                 // Expected amplitude should be approximately 1.0 for this test data
                                 // The mutant would calculate a completely different value
                                 assertEquals(1.0, calculatedA, 0.01);
                                 
                             } catch (Exception e) {
                                 fail("Failed to invoke guessAOmega via reflection");
                             }
                         }

 @Test
                       public void testGuessAOmega_DetectsSqrtMutation2() {
                           // Create test observations where c1/c2 > 1
                           WeightedObservedPoint[] observations = new WeightedObservedPoint[] {
                               new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                               new WeightedObservedPoint(1.0, 1.0, 3.0),
                               new WeightedObservedPoint(1.0, 2.0, 5.0),
                               new WeightedObservedPoint(1.0, 3.0, 7.0)
                           };
                           
                           // Create HarmonicFitter instance (need to use reflection since constructor requires optimizer)
                           DifferentiableMultivariateVectorOptimizer optimizer = mock(DifferentiableMultivariateVectorOptimizer.class);
                           HarmonicFitter fitter = new HarmonicFitter(optimizer);
                           
                           // Use reflection to set observations since it's private final
                           try {
                               Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                               observationsField.setAccessible(true);
                               observationsField.set(fitter, observations);
                           } catch (Exception e) {
                               fail("Failed to set observations field via reflection");
                           }
                           
                           // Call the method using reflection since it's private
                           try {
                               Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                               method.setAccessible(true);
                               method.invoke(fitter);
                           } catch (Exception e) {
                               fail("Failed to invoke guessAOmega method");
                           }
                           
                           // Get the 'a' value using reflection
                           double aValue;
                           try {
                               Field aField = HarmonicFitter.class.getDeclaredField("a");
                               aField.setAccessible(true);
                               aValue = aField.getDouble(fitter);
                           } catch (Exception e) {
                               fail("Failed to get 'a' field value");
                               return;
                           }
                           
                           // Calculate expected ratio based on test data
                           // For these points, the harmonic function would be approximately y = 2x + 1
                           // The c1/c2 ratio would be calculated from the harmonic analysis
                           // For this test case, we'll use a known expected value that would result from these points
                           double c1_c2_ratio = 4.0; // This is a simplified expected value for the test case
                           double expectedA = Math.sqrt(c1_c2_ratio);
                           
                           // The mutant would return c1_c2_ratio directly instead of sqrt(c1_c2_ratio)
                           assertEquals("Amplitude should be square root of c1/c2", expectedA, aValue, 1e-10);
                       }

 @Test
                  public void testGuessAOmegaDetectsSqrtToAbsMutation() {
                      // Create test data where c1/c2 is not a perfect square
                      // We'll use 3 points to force the else branch where mutation occurs
                      WeightedObservedPoint[] observations = {
                          new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
                          new WeightedObservedPoint(1.0, 1.0, 2.0),
                          new WeightedObservedPoint(1.0, 2.0, 1.5)
                      };
                      
                      // Create harmonic fitter and set observations
                      HarmonicFitter fitter = new HarmonicFitter(mock(DifferentiableMultivariateVectorOptimizer.class));
                      // Need to use reflection to set private observations field since there's no setter
                      try {
                          Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                          observationsField.setAccessible(true);
                          observationsField.set(fitter, observations);
                      } catch (Exception e) {
                          fail("Failed to set observations field via reflection");
                      }
                      
                      // Invoke the method under test
                      try {
                          Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                          guessAOmega.setAccessible(true);
                          guessAOmega.invoke(fitter);
                      } catch (Exception e) {
                          fail("Failed to invoke guessAOmega method");
                      }
                      
                      // Get the calculated amplitude
                      double calculatedA;
                      try {
                          Field aField = HarmonicFitter.class.getDeclaredField("a");
                          aField.setAccessible(true);
                          calculatedA = aField.getDouble(fitter);
                      } catch (Exception e) {
                          fail("Failed to get amplitude field");
                          return;
                      }
                      
                      // Calculate c1/c2 ratio from the test data
                      // For these points, c1 = 0.5 and c2 = 0.25 (calculated manually)
                      double c1OverC2 = 0.5 / 0.25;  // = 2.0
                      
                      // Calculate expected value (sqrt) vs what mutant would produce (abs)
                      double expectedWithSqrt = Math.sqrt(c1OverC2);
                      double expectedWithAbs = Math.abs(c1OverC2);
                      
                      // Verify the value matches sqrt calculation, not abs
                      // We use delta for floating point comparison
                      assertEquals(expectedWithSqrt, calculatedA, 1e-10);
                      
                      // Explicit check that it's not the mutated version
                      assertNotEquals(expectedWithAbs, calculatedA, 1e-10);
                  }

 @Test
             public void testGuessAOmega_NonZeroAmplitude() throws Exception {
                 // Create test observations that will make (c1/c2 < 0) || (c2/c3 < 0) false
                 // and produce a non-zero amplitude
                 WeightedObservedPoint[] observations = {
                     new WeightedObservedPoint(1.0, 1.0, 2.0),  // (weight, x, y)
                     new WeightedObservedPoint(1.0, 2.0, 4.0),
                     new WeightedObservedPoint(1.0, 3.0, 2.0),
                     new WeightedObservedPoint(1.0, 4.0, 0.0),
                     new WeightedObservedPoint(1.0, 5.0, 2.0)
                 };
                 
                 // Use reflection to access private method and fields
                 DifferentiableMultivariateVectorOptimizer optimizer = mock(DifferentiableMultivariateVectorOptimizer.class);
                 HarmonicFitter fitter = new HarmonicFitter(optimizer);
                 Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
                 observationsField.setAccessible(true);
                 observationsField.set(fitter, observations);
                 
                 Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
                 guessAOmega.setAccessible(true);
                 guessAOmega.invoke(fitter);
                 
                 // Get the amplitude value
                 Field aField = HarmonicFitter.class.getDeclaredField("a");
                 aField.setAccessible(true);
                 double amplitude = aField.getDouble(fitter);
                 
                 // Verify amplitude is calculated correctly (not zero)
                 assertNotEquals("Amplitude should not be zero", 0.0, amplitude, 0.0001);
                 
                 // Additional verification that omega is also calculated
                 Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
                 omegaField.setAccessible(true);
                 double omega = omegaField.getDouble(fitter);
                 assertTrue("Omega should be positive", omega > 0);
             }

 @Test
        public void testGuessAOmega_DetectsAmplitudeCalculationMutant1() throws Exception {
            // Create test observations that will produce c1/c2 > 0 and c2/c3 > 0
            // and where the calculated amplitude is not 1.0
            WeightedObservedPoint[] observations = {
                new WeightedObservedPoint(1.0, 0.0, 2.0),  // First point (weight, x, y)
                new WeightedObservedPoint(1.0, 2.0, 4.0),   // Second point - creates non-1.0 amplitude
                new WeightedObservedPoint(1.0, 3.0, 2.0)    // Third point
            };
            
            // Use reflection to test private method
            DifferentiableMultivariateVectorOptimizer optimizer = mock(DifferentiableMultivariateVectorOptimizer.class);
            HarmonicFitter fitter = new HarmonicFitter(optimizer);
            
            // Set observations field via reflection
            Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
            observationsField.setAccessible(true);
            observationsField.set(fitter, observations);
            
            // Call the private method
            Method method = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
            method.setAccessible(true);
            method.invoke(fitter);
            
            // Get the amplitude value via reflection
            Field aField = HarmonicFitter.class.getDeclaredField("a");
            aField.setAccessible(true);
            double calculatedA = aField.getDouble(fitter);
            
            // Verify amplitude is calculated correctly (not 1.0)
            // For these points, the expected amplitude is > 1.0
            assertTrue("Amplitude should be calculated, not set to 1.0", 
                       calculatedA != 1.0 && calculatedA > 0);
            
            // Additional verification that the value is reasonable
            // Based on the test data, we expect amplitude around 1.414 (sqrt(2))
            assertEquals("Amplitude calculation is incorrect", 
                        Math.sqrt(2), calculatedA, 0.001);
        }

 @Test
    public void testGuessAOmegaDetectsMutant3() throws Exception {
        // Create test observations that will trigger the else branch (c1/c2 > 0 and c2/c3 > 0)
        WeightedObservedPoint[] observations = {
            new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
            new WeightedObservedPoint(1.0, Math.PI/2, 1.0),
            new WeightedObservedPoint(1.0, Math.PI, 0.0),
            new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0),
            new WeightedObservedPoint(1.0, 2*Math.PI, 0.0)
        };
        
        // Use reflection to test private method
        HarmonicFitter fitter = new HarmonicFitter(null);
        Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
        observationsField.setAccessible(true);
        observationsField.set(fitter, observations);
        
        Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
        guessAOmega.setAccessible(true);
        guessAOmega.invoke(fitter);
        
        // Get the calculated omega value
        Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
        omegaField.setAccessible(true);
        double actualOmega = omegaField.getDouble(fitter);
        
        // Expected omega should be approximately 1 (since we used sin(x) data with period 2π)
        // The mutant would calculate 1/omega instead
        assertEquals(1.0, actualOmega, 0.01);
        
        // Also verify amplitude is calculated correctly (should be 1 for this test data)
        Field aField = HarmonicFitter.class.getDeclaredField("a");
        aField.setAccessible(true);
        double actualA = aField.getDouble(fitter);
        assertEquals(1.0, actualA, 0.01);
    }

 @Test
   public void testGuessAOmegaDetectsSqrtMutation2() throws Exception {
       // Create test data where c2/c3 is not a perfect square
       WeightedObservedPoint[] observations = {
           new WeightedObservedPoint(1.0, 0.0, 1.0),  // t=0, y=0
           new WeightedObservedPoint(1.0, Math.PI/2, 1.0),  // t=π/2, y=1
           new WeightedObservedPoint(1.0, Math.PI, 0.0),   // t=π, y=0
           new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0), // t=3π/2, y=-1
           new WeightedObservedPoint(1.0, 2*Math.PI, 0.0)  // t=2π, y=0
       };
       
       // Use reflection to test private method
       HarmonicFitter fitter = new HarmonicFitter(null);
       Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
       observationsField.setAccessible(true);
       observationsField.set(fitter, observations);
       
       Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
       guessAOmega.setAccessible(true);
       guessAOmega.invoke(fitter);
       
       // Get omega field value
       Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
       omegaField.setAccessible(true);
       double omega = omegaField.getDouble(fitter);
       
       // Expected omega should be 1 (frequency of the sine wave)
       // For the mutated version (without sqrt), omega would be 1*1=1 in this case
       // So we need a case where c2/c3 is not a perfect square
       
       // Let's modify the test data slightly to make c2/c3 not a perfect square
       observations = new WeightedObservedPoint[] {
           new WeightedObservedPoint(1.0, 0.0, 0.0),
           new WeightedObservedPoint(1.0, 1.0, Math.sin(2.0)), // Using 2.0 as frequency
           new WeightedObservedPoint(1.0, 2.0, Math.sin(4.0)),
           new WeightedObservedPoint(1.0, 3.0, Math.sin(6.0))
       };
       
       observationsField.set(fitter, observations);
       guessAOmega.invoke(fitter);
       omega = omegaField.getDouble(fitter);
       
       // Original would give sqrt(ratio), mutant would give ratio
       // Assert that omega is the square root of something (original behavior)
       // We know that for harmonic functions, omega should be the sqrt
       double ratio = omega * omega;
       double calculatedOmega = FastMath.sqrt(ratio);
       assertEquals(calculatedOmega, omega, 1e-10);
       
       // Alternative assertion - check against expected physical value
       // For the sine wave with frequency 2, omega should be 2
       double expectedOmega = 2.0;
       assertEquals(expectedOmega, omega, 1e-5);
   }

 @Test
  public void testGuessAOmegaDetectsSqrtToAbsMutant3() {
      // Create test data that will make c2/c3 = 4 (perfect square)
      // We need to carefully craft observations that will produce:
      // sx2*sy2 - sxy*sxy = c3
      // sxy*sxz - sx2*syz = c2
      // With c2/c3 = 4
      
      // Mock observations - simplified case to produce known ratios
      WeightedObservedPoint[] observations = new WeightedObservedPoint[3];
      observations[0] = new WeightedObservedPoint(1.0, 0.0, 1.0);  // weight, x, y
      observations[1] = new WeightedObservedPoint(1.0, 2.0, 2.0);
      observations[2] = new WeightedObservedPoint(1.0, 4.0, 0.0);
      
      // Create harmonic fitter - need to use reflection to test private method
      HarmonicFitter fitter = new HarmonicFitter(null);
      
      // Set observations using reflection
      try {
          Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
          observationsField.setAccessible(true);
          observationsField.set(fitter, observations);
          
          // Call the private method using reflection
          Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
          guessAOmega.setAccessible(true);
          guessAOmega.invoke(fitter);
          
          // Get omega value using reflection
          Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
          omegaField.setAccessible(true);
          double omega = omegaField.getDouble(fitter);
          
          // Verify omega is sqrt(c2/c3) not abs(c2/c3)
          // With this test data, sqrt(c2/c3) should be 2 (since 4 is perfect square)
          assertEquals(2.0, omega, 1e-10);
          
      } catch (Exception e) {
          fail("Reflection failed: " + e.getMessage());
      }
  }

 @Test
 public void testGuessAOmega_DetectsOmegaMutation() {
     // Create test observations that will make (c1/c2 < 0 || c2/c3 < 0) false
     // and c2 != 0, so it goes to the else branch where omega is calculated
     WeightedObservedPoint[] observations = {
         new WeightedObservedPoint(1.0, 0.0, 1.0),  // weight, x, y
         new WeightedObservedPoint(1.0, Math.PI/2, 1.0),
         new WeightedObservedPoint(1.0, Math.PI, -1.0),
         new WeightedObservedPoint(1.0, 3*Math.PI/2, -1.0),
         new WeightedObservedPoint(1.0, 2*Math.PI, 1.0)
     };
     
     // Create harmonic fitter and set observations
     HarmonicFitter fitter = new HarmonicFitter(null);
     // Use reflection to set private observations field since there's no setter
     try {
         Field observationsField = HarmonicFitter.class.getDeclaredField("observations");
         observationsField.setAccessible(true);
         observationsField.set(fitter, observations);
     } catch (Exception e) {
         fail("Failed to set observations field via reflection");
     }
     
     // Call the method under test
     try {
         Method guessAOmega = HarmonicFitter.class.getDeclaredMethod("guessAOmega");
         guessAOmega.setAccessible(true);
         guessAOmega.invoke(fitter);
     } catch (Exception e) {
         fail("Failed to invoke guessAOmega method");
     }
     
     // Get the omega value using reflection
     double omega = 0;
     try {
         Field omegaField = HarmonicFitter.class.getDeclaredField("omega");
         omegaField.setAccessible(true);
         omega = omegaField.getDouble(fitter);
     } catch (Exception e) {
         fail("Failed to get omega field via reflection");
     }
     
     // Verify omega is calculated correctly (should be approximately 1 for this input)
     // The mutant would set omega to 0.0 instead
     assertEquals(1.0, omega, 0.01);  // Allowing small floating point difference
 }

}
