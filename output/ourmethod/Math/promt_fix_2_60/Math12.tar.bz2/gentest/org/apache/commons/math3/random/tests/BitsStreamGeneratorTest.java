package gentest.org.apache.commons.math3.random.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.random.*;
import java.io.Serializable;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.util.FastMath;
 
public class BitsStreamGeneratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                    public void testNextBytes_NullInput() {
                                                                                                        // Setup
                                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                            @Override
                                                                                                            protected int next(int bits) { return 0; }
                                                                                                            @Override
                                                                                                            public void setSeed(int seed) {}
                                                                                                            @Override
                                                                                                            public void setSeed(int[] seed) {}
                                                                                                            @Override
                                                                                                            public void setSeed(long seed) {}
                                                                                                        };
                                                                                                        
                                                                                                        // Expect exception
                                                                                                        thrown.expect(NullPointerException.class);
                                                                                                        
                                                                                                        // Execute
                                                                                                        generator.nextBytes(null);
                                                                                                    }

 @Test
                                                                                                    public void testNextInt_ThrowsForNegativeInput() {
                                                                                                        BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                        when(generator.nextInt(anyInt())).thenCallRealMethod();
                                                                                                        
                                                                                                        thrown.expect(NotStrictlyPositiveException.class);
                                                                                                        generator.nextInt(-1);
                                                                                                    }

 @Test
                                                                                                    public void testNextInt_ThrowsForZeroInput() {
                                                                                                        BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                        when(generator.nextInt(anyInt())).thenCallRealMethod();
                                                                                                        
                                                                                                        thrown.expect(NotStrictlyPositiveException.class);
                                                                                                        generator.nextInt(0);
                                                                                                    }

 @Test
                                                                                            public void testSetSeed_WithIntParameter() {
                                                                                                // Create an anonymous implementation of BitsStreamGenerator for testing
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    private int seed;
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {
                                                                                                        this.seed = seed;
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {
                                                                                                        // Not used in this test
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {
                                                                                                        // Not used in this test
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0; // Not used in this test
                                                                                                    }
                                                                                                    
                                                                                                    public int getSeed() {
                                                                                                        return seed; // Helper method to verify seed was set
                                                                                                    }
                                                                                                };
                                                                                                
                                                                                                // Test typical values
                                                                                                generator.setSeed(42);
                                                                                                
                                                                                                // Test edge cases
                                                                                                generator.setSeed(0);
                                                                                                generator.setSeed(Integer.MAX_VALUE);
                                                                                                generator.setSeed(Integer.MIN_VALUE);
                                                                                            }

 @Test
                                                                                            public void testSetSeed_WithIntArrayParameter() {
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0;
                                                                                                    }
                                                                                                };
                                                                                                
                                                                                                // Test with normal array
                                                                                                int[] seed1 = {1, 2, 3, 4};
                                                                                                generator.setSeed(seed1);
                                                                                                
                                                                                                // Test with empty array
                                                                                                int[] emptySeed = {};
                                                                                                generator.setSeed(emptySeed);
                                                                                                
                                                                                                // Test with single element array
                                                                                                int[] singleSeed = {42};
                                                                                                generator.setSeed(singleSeed);
                                                                                                
                                                                                                // Test with large array
                                                                                                int[] largeSeed = new int[1000];
                                                                                                for (int i = 0; i < largeSeed.length; i++) {
                                                                                                    largeSeed[i] = i;
                                                                                                }
                                                                                                generator.setSeed(largeSeed);
                                                                                            }

 @Test
                                                                                            public void testSetSeed_WithLongParameter() {
                                                                                                BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                
                                                                                                // Test typical values
                                                                                                generator.setSeed(123456789L);
                                                                                                verify(generator).setSeed(123456789L);
                                                                                                
                                                                                                // Test edge cases
                                                                                                generator.setSeed(0L);
                                                                                                verify(generator).setSeed(0L);
                                                                                                
                                                                                                generator.setSeed(Long.MAX_VALUE);
                                                                                                verify(generator).setSeed(Long.MAX_VALUE);
                                                                                                
                                                                                                generator.setSeed(Long.MIN_VALUE);
                                                                                                verify(generator).setSeed(Long.MIN_VALUE);
                                                                                            }

 @Test
                                                                                            public void testSetSeedInt() {
                                                                                                // Create a mock of the abstract class
                                                                                                BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                
                                                                                                // Test that setSeed(int) can be called without exception
                                                                                                generator.setSeed(12345);
                                                                                                verify(generator).setSeed(12345);
                                                                                            }

 @Test
                                                                                            public void testSetSeedIntArray() {
                                                                                                // Create mock of BitsStreamGenerator
                                                                                                BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                
                                                                                                // Test that setSeed(int[]) can be called without exception
                                                                                                int[] seedArray = {1, 2, 3, 4};
                                                                                                generator.setSeed(seedArray);
                                                                                                verify(generator).setSeed(seedArray);
                                                                                            }

 @Test
                                                                                            public void testSetSeedIntArrayNull() {
                                                                                                org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                                thrown.expect(NullPointerException.class);
                                                                                                org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                    @Override
                                                                                                    protected int next(int bits) { return 0; }
                                                                                                };
                                                                                                generator.setSeed((int[])null);
                                                                                            }

 @Test
                                                                                            public void testSetSeedIntArrayEmpty() {
                                                                                                org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {
                                                                                                        if (seed.length == 0) {
                                                                                                            throw new IllegalArgumentException();
                                                                                                        }
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0;
                                                                                                    }
                                                                                                };
                                                                                                
                                                                                                org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                generator.setSeed(new int[0]);
                                                                                            }

 @Test
                                                                                            public void testSetSeedLong() {
                                                                                                // Create a mock of the abstract class
                                                                                                BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                
                                                                                                // Test that setSeed(long) can be called without exception
                                                                                                generator.setSeed(123456789L);
                                                                                                verify(generator).setSeed(123456789L);
                                                                                            }

 @Test
                                                                                            public void testNextGaussianInitialState() {
                                                                                                // Create a concrete instance of BitsStreamGenerator (could be a mock or real implementation)
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                    @Override
                                                                                                    protected int next(int bits) { return 0; }
                                                                                                };
                                                                                                
                                                                                                // Reset the state (constructor already sets nextGaussian to NaN)
                                                                                                generator.clear();
                                                                                                
                                                                                                // Initial state should be NaN
                                                                                                assertTrue(Double.isNaN(generator.nextGaussian()));
                                                                                            }

 @Test
                                                                                            public void testClearResetsNextGaussian() throws Exception {
                                                                                                // Create a concrete instance (using a subclass since BitsStreamGenerator is abstract)
                                                                                                BitsStreamGenerator generator = new Well19937c();
                                                                                                
                                                                                                // Set a non-NaN value using reflection
                                                                                                Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                                nextGaussianField.setAccessible(true);
                                                                                                nextGaussianField.set(generator, 1.0);
                                                                                                
                                                                                                // Call clear
                                                                                                generator.clear();
                                                                                                
                                                                                                // Verify nextGaussian was reset to NaN
                                                                                                assertTrue(Double.isNaN((Double)nextGaussianField.get(generator)));
                                                                                            }

 @Test
                                                                                            public void testNextGaussianAfterClear() {
                                                                                                // Create a mock of BitsStreamGenerator
                                                                                                BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                
                                                                                                // Reset the mock to get default behavior
                                                                                                reset(generator);
                                                                                                
                                                                                                // Call clear
                                                                                                generator.clear();
                                                                                                
                                                                                                // Stub nextGaussian to return NaN
                                                                                                when(generator.nextGaussian()).thenReturn(Double.NaN);
                                                                                                
                                                                                                // Verify nextGaussian is NaN
                                                                                                assertTrue(Double.isNaN(generator.nextGaussian()));
                                                                                            }

 @Test
                                                                                            public void testConstructorInitializesNextGaussian() throws NoSuchFieldException, IllegalAccessException {
                                                                                                // Test the constructor behavior
                                                                                                BitsStreamGenerator newGenerator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    protected int next(int bits) { return 0; }
                                                                                                };
                                                                                                
                                                                                                // Use reflection to access private field
                                                                                                Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                                nextGaussianField.setAccessible(true);
                                                                                                double nextGaussianValue = (Double) nextGaussianField.get(newGenerator);
                                                                                                
                                                                                                assertTrue(Double.isNaN(nextGaussianValue));
                                                                                            }

 @Test
                                                                                            public void testConstructorInitialization() throws Exception {
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                    @Override
                                                                                                    protected int next(int bits) { return 0; }
                                                                                                };
                                                                                                
                                                                                                // Use reflection to access private nextGaussian field
                                                                                                Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                                nextGaussianField.setAccessible(true);
                                                                                                double nextGaussianValue = (Double) nextGaussianField.get(generator);
                                                                                                
                                                                                                // Verify that nextGaussian is initialized to NaN
                                                                                                assertTrue(Double.isNaN(nextGaussianValue));
                                                                                            }

 @Test
                                                                                            public void testNextBoolean_UsesNextMethod() {
                                                                                                // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0; // Simple implementation for testing
                                                                                                    }
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                                
                                                                                                // Verify nextBoolean uses next(1)
                                                                                                boolean result = generator.nextBoolean();
                                                                                                // Since our test implementation returns 0 or 1 for next(1)
                                                                                                assertTrue(result == false || result == true);
                                                                                            }

 @Test
                                                                                            public void testNextInt_UsesNextMethod() {
                                                                                                // Create a concrete implementation or mock of BitsStreamGenerator
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return bits; // Simple implementation for testing
                                                                                                    }
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                                
                                                                                                // Verify nextInt uses next(32)
                                                                                                int result = generator.nextInt();
                                                                                                // Our test implementation returns values between 0-31
                                                                                                assertTrue(result >= 0 && result < 32);
                                                                                            }

 @Test
                                                                                            public void testNextIntWithBound_UsesNextMethod() {
                                                                                                // Create a concrete instance of BitsStreamGenerator for testing
                                                                                                // Since BitsStreamGenerator is abstract, we'll use a simple anonymous implementation
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        // Simple implementation that returns a predictable value for testing
                                                                                                        return 5; // This is just for basic testing
                                                                                                    }
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                            
                                                                                                // Verify nextInt(n) uses next(31)
                                                                                                int result = generator.nextInt(10);
                                                                                                assertTrue(result >= 0 && result < 10);
                                                                                                
                                                                                                // Test edge case with bound = 1 (should always return 0)
                                                                                                assertEquals(0, generator.nextInt(1));
                                                                                            }

 @Test
                                                                                            public void testNextIntWithInvalidBound() {
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0; // Dummy implementation for testing
                                                                                                    }
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                                
                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                generator.nextInt(0);
                                                                                                
                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                generator.nextInt(-1);
                                                                                            }

 @Test
                                                                                            public void testNextLong_UsesNextMethod() {
                                                                                                // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0; // Simple implementation for testing
                                                                                                    }
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                                
                                                                                                // Verify nextLong uses next(32) twice
                                                                                                long result = generator.nextLong();
                                                                                                // Our test implementation returns small numbers
                                                                                                assertTrue(result >= 0);
                                                                                            }

 @Test
                                                                                            public void testNextFloat_UsesNextMethod() {
                                                                                                // Create a concrete instance of BitsStreamGenerator for testing
                                                                                                // Since BitsStreamGenerator is abstract, we'll use a simple anonymous implementation
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0; // Simple implementation for testing
                                                                                                    }
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                                
                                                                                                // Verify nextFloat uses next(24)
                                                                                                float result = generator.nextFloat();
                                                                                                assertTrue(result >= 0.0f && result < 1.0f);
                                                                                            }

 @Test
                                                                                            public void testNextDouble_UsesNextMethod() {
                                                                                                // Create a concrete instance of BitsStreamGenerator for testing
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0; // Simple implementation for testing
                                                                                                    }
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {
                                                                                                    }
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {
                                                                                                    }
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {
                                                                                                    }
                                                                                                };
                                                                                                
                                                                                                // Verify nextDouble produces a value in [0.0, 1.0) range
                                                                                                double result = generator.nextDouble();
                                                                                                assertTrue(result >= 0.0 && result < 1.0);
                                                                                            }

 @Test
                                                                                            public void testNextGaussian_UsesNextMethod() {
                                                                                                // Create a concrete instance of BitsStreamGenerator for testing
                                                                                                // Since BitsStreamGenerator is abstract, we'll use a simple anonymous implementation
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0; // Simple implementation for testing
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                                
                                                                                                // First call should use nextDouble()
                                                                                                double result = generator.nextGaussian();
                                                                                                assertTrue(Double.isNaN(result) == false);
                                                                                                
                                                                                                // Second call should return cached value
                                                                                                double cachedResult = generator.nextGaussian();
                                                                                                assertEquals(result, cachedResult, 0.0001);
                                                                                            }

 @Test
                                                                                            public void testClear_ResetsNextGaussian() {
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0;
                                                                                                    }
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                                generator.nextGaussian(); // Sets a value
                                                                                                generator.clear();
                                                                                                assertTrue(Double.isNaN(generator.nextGaussian()));
                                                                                            }

 @Test
                                                                                            public void testNextBytes_FillsArray() {
                                                                                                // Create a concrete implementation or mock of BitsStreamGenerator
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 1; // Return a small positive number
                                                                                                    }
                                                                                                };
                                                                                                
                                                                                                byte[] bytes = new byte[10];
                                                                                                generator.nextBytes(bytes);
                                                                                                
                                                                                                // Verify all bytes were set (our mock returns small numbers)
                                                                                                for (byte b : bytes) {
                                                                                                    assertTrue(b >= 0);
                                                                                                }
                                                                                            }

 @Test
                                                                                            public void testNextBytes_NullArray() {
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0;
                                                                                                    }
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                                ExpectedException exception = ExpectedException.none();
                                                                                                exception.expect(NullPointerException.class);
                                                                                                generator.nextBytes(null);
                                                                                            }

 @Test
                                                                                            public void testNextBytes_EmptyArray() {
                                                                                                // Setup
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0;
                                                                                                    }
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                                
                                                                                                byte[] bytes = new byte[0];
                                                                                                
                                                                                                // Execute
                                                                                                generator.nextBytes(bytes);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals(0, bytes.length);
                                                                                            }

 @Test
                                                                                            public void testNextBytes_SingleByte() {
                                                                                                // Setup
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0xAABBCCDD;
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                                
                                                                                                byte[] bytes = new byte[1];
                                                                                                
                                                                                                // Execute
                                                                                                generator.nextBytes(bytes);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals((byte)0xDD, bytes[0]);
                                                                                            }

 @Test
                                                                                            public void testNextBytes_ThreeBytes() {
                                                                                                // Setup
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0x11223344;
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                                
                                                                                                byte[] bytes = new byte[3];
                                                                                                
                                                                                                // Execute
                                                                                                generator.nextBytes(bytes);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals((byte)0x44, bytes[0]);
                                                                                                assertEquals((byte)0x33, bytes[1]);
                                                                                                assertEquals((byte)0x22, bytes[2]);
                                                                                            }

 @Test
                                                                                            public void testNextBytes_FourBytes() {
                                                                                                // Setup
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return 0xDEADBEEF;
                                                                                                    }
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                                
                                                                                                byte[] bytes = new byte[4];
                                                                                                
                                                                                                // Execute
                                                                                                generator.nextBytes(bytes);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals((byte)0xEF, bytes[0]);
                                                                                                assertEquals((byte)0xBE, bytes[1]);
                                                                                                assertEquals((byte)0xAD, bytes[2]);
                                                                                                assertEquals((byte)0xDE, bytes[3]);
                                                                                            }

 @Test
                                                                                            public void testNextBytes_MultipleChunks() {
                                                                                                // Create a test subclass that exposes the protected next() method
                                                                                                class TestBitsStreamGenerator extends BitsStreamGenerator {
                                                                                                    private int callCount = 0;
                                                                                                    private final int[] returns = {0x01020304, 0xAABBCCDD};
                                                                                                    
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return returns[callCount++];
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                }
                                                                                                
                                                                                                // Setup
                                                                                                BitsStreamGenerator generator = new TestBitsStreamGenerator();
                                                                                                byte[] bytes = new byte[7]; // 4 + 3
                                                                                                
                                                                                                // Execute
                                                                                                generator.nextBytes(bytes);
                                                                                                
                                                                                                // Verify
                                                                                                // First chunk
                                                                                                assertEquals((byte)0x04, bytes[0]);
                                                                                                assertEquals((byte)0x03, bytes[1]);
                                                                                                assertEquals((byte)0x02, bytes[2]);
                                                                                                assertEquals((byte)0x01, bytes[3]);
                                                                                                // Second chunk
                                                                                                assertEquals((byte)0xDD, bytes[4]);
                                                                                                assertEquals((byte)0xCC, bytes[5]);
                                                                                                assertEquals((byte)0xBB, bytes[6]);
                                                                                            }

 @Test
                                                                                            public void testNextBytes_LargeArray() {
                                                                                                // Create a concrete subclass to test the protected method
                                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                    private int callCount = 0;
                                                                                                    private final int[] values = {0x11111111, 0x22222222, 0x33333333, 0x44444444, 0x55555555};
                                                                                                    
                                                                                                    @Override
                                                                                                    protected int next(int bits) {
                                                                                                        return values[callCount++];
                                                                                                    }
                                                                                            
                                                                                                    @Override
                                                                                                    public void setSeed(int seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(int[] seed) {}
                                                                                                    
                                                                                                    @Override
                                                                                                    public void setSeed(long seed) {}
                                                                                                };
                                                                                                
                                                                                                byte[] bytes = new byte[17]; // 4*4 + 1
                                                                                                
                                                                                                // Execute
                                                                                                generator.nextBytes(bytes);
                                                                                                
                                                                                                // Verify some sample bytes
                                                                                                assertEquals((byte)0x11, bytes[0]);
                                                                                                assertEquals((byte)0x11, bytes[4]);
                                                                                                assertEquals((byte)0x22, bytes[5]);
                                                                                                assertEquals((byte)0x33, bytes[8]);
                                                                                                assertEquals((byte)0x44, bytes[12]);
                                                                                                assertEquals((byte)0x55, bytes[16]);
                                                                                            }

 @Test
                                                                                        public void testNextGaussian_FirstCallGeneratesNewPair() {
                                                                                            // Create mock generator
                                                                                            BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                            
                                                                                            // Setup mock to return specific values for the polar method
                                                                                            when(generator.nextDouble())
                                                                                                .thenReturn(0.5) // x
                                                                                                .thenReturn(0.5); // y
                                                                                            
                                                                                            // Call the method (should generate new pair)
                                                                                            double result = generator.nextGaussian();
                                                                                            
                                                                                            // Verify the result is calculated correctly
                                                                                            double expectedAlpha = 2 * Math.PI * 0.5;
                                                                                            double expectedR = Math.sqrt(-2 * Math.log(0.5));
                                                                                            double expectedValue = expectedR * Math.cos(expectedAlpha);
                                                                                            
                                                                                            assertEquals(expectedValue, result, 0.0001);
                                                                                            
                                                                                            // Verify nextDouble was called twice (for x and y)
                                                                                            verify(generator, times(2)).nextDouble();
                                                                                        }

 @Test
                                                                                        public void testNextGaussian_SecondCallUsesStoredValue() {
                                                                                            // Create mock generator
                                                                                            BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                            
                                                                                            // First call generates pair and stores second value
                                                                                            when(generator.nextDouble())
                                                                                                .thenReturn(0.25) // x
                                                                                                .thenReturn(0.75); // y
                                                                                            
                                                                                            // First call - generates new pair
                                                                                            double firstResult = generator.nextGaussian();
                                                                                            
                                                                                            // Second call - should use stored value
                                                                                            double secondResult = generator.nextGaussian();
                                                                                            
                                                                                            // Calculate expected values
                                                                                            double alpha = 2 * Math.PI * 0.25;
                                                                                            double r = Math.sqrt(-2 * Math.log(0.75));
                                                                                            double expectedFirst = r * Math.cos(alpha);
                                                                                            double expectedSecond = r * Math.sin(alpha);
                                                                                            
                                                                                            assertEquals(expectedFirst, firstResult, 0.0001);
                                                                                            assertEquals(expectedSecond, secondResult, 0.0001);
                                                                                            
                                                                                            // Verify nextDouble was called exactly twice (only for first call)
                                                                                            verify(generator, times(2)).nextDouble();
                                                                                        }

 @Test
                                                                                        public void testNextGaussian_WithExtremeInputValues() {
                                                                                            // Create mock generator
                                                                                            BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                            
                                                                                            // Test with very small y value (close to 0)
                                                                                            when(generator.nextDouble())
                                                                                                .thenReturn(0.1) // x
                                                                                                .thenReturn(1e-300); // y (very small)
                                                                                            
                                                                                            double result = generator.nextGaussian();
                                                                                            
                                                                                            // Should be a very large number since log(y) is large negative
                                                                                            assertTrue(result > 1e100);
                                                                                            
                                                                                            // Test with y very close to 1
                                                                                            when(generator.nextDouble())
                                                                                                .thenReturn(0.9) // x
                                                                                                .thenReturn(1 - 1e-15); // y very close to 1
                                                                                            
                                                                                            result = generator.nextGaussian();
                                                                                            
                                                                                            // Should be a small number since log(y) is small negative
                                                                                            assertTrue(Math.abs(result) < 0.1);
                                                                                        }

 @Test
                                                                                        public void testNextGaussian_AlternatesBetweenGeneratedAndStored() {
                                                                                            // Create a mock of BitsStreamGenerator
                                                                                            BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                            
                                                                                            // First call - generates pair
                                                                                            when(generator.nextDouble())
                                                                                                .thenReturn(0.3, 0.7) // first pair
                                                                                                .thenReturn(0.2, 0.8); // second pair
                                                                                            
                                                                                            double first = generator.nextGaussian(); // generates pair
                                                                                            double second = generator.nextGaussian(); // uses stored
                                                                                            double third = generator.nextGaussian(); // generates new pair
                                                                                            double fourth = generator.nextGaussian(); // uses stored
                                                                                            
                                                                                            // Verify pattern: generate, use stored, generate, use stored
                                                                                            verify(generator, times(4)).nextDouble();
                                                                                            
                                                                                            // Verify all results are different (very high probability)
                                                                                            assertNotEquals(first, second);
                                                                                            assertNotEquals(second, third);
                                                                                            assertNotEquals(third, fourth);
                                                                                        }

 @Test(expected = IllegalArgumentException.class)
                                                                                        public void testNextGaussian_WithZeroYValue() {
                                                                                            // Create mock generator
                                                                                            BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                            
                                                                                            when(generator.nextDouble())
                                                                                                .thenReturn(0.5) // x
                                                                                                .thenReturn(0.0); // y (invalid)
                                                                                            
                                                                                            generator.nextGaussian(); // Should throw due to log(0)
                                                                                        }

 @Test
                                                                                        public void testNextGaussian_WithNegativeYValue() {
                                                                                            // Setup exception rule
                                                                                            ExpectedException thrown = ExpectedException.none();
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            
                                                                                            // Create mock generator
                                                                                            BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                            
                                                                                            // Stub the nextDouble calls
                                                                                            when(generator.nextDouble())
                                                                                                .thenReturn(0.5) // x
                                                                                                .thenReturn(-0.1); // y (invalid)
                                                                                            
                                                                                            generator.nextGaussian(); // Should throw due to log(-0.1)
                                                                                        }

 @Test
                                                                                        public void testNextGaussian_WithNaNNextGaussian() {
                                                                                            // Create a new BitsStreamGenerator instance
                                                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                @Override
                                                                                                protected int next(int bits) { return 0; }
                                                                                                @Override
                                                                                                public void setSeed(int seed) {}
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {}
                                                                                                @Override
                                                                                                public void setSeed(long seed) {}
                                                                                            };
                                                                                            
                                                                                            // Mock nextDouble for this specific test
                                                                                            BitsStreamGenerator spyGenerator = spy(generator);
                                                                                            when(spyGenerator.nextDouble())
                                                                                                .thenReturn(0.4, 0.6);
                                                                                            
                                                                                            double result = spyGenerator.nextGaussian();
                                                                                            
                                                                                            // Verify new pair was generated
                                                                                            double expectedAlpha = 2 * Math.PI * 0.4;
                                                                                            double expectedR = Math.sqrt(-2 * Math.log(0.6));
                                                                                            double expectedValue = expectedR * Math.cos(expectedAlpha);
                                                                                            
                                                                                            assertEquals(expectedValue, result, 0.0001);
                                                                                        }

 @Test
                                                                                        public void testNextInt_PowerOfTwoCase() {
                                                                                            // Create a concrete subclass to access protected next() method
                                                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                @Override
                                                                                                protected int next(int bits) {
                                                                                                    return 123456789; // Return fixed value for testing
                                                                                                }
                                                                                        
                                                                                                @Override
                                                                                                public void setSeed(int seed) {}
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {}
                                                                                                @Override
                                                                                                public void setSeed(long seed) {}
                                                                                            };
                                                                                            
                                                                                            int n = 16; // power of 2
                                                                                            int result = generator.nextInt(n);
                                                                                            
                                                                                            // Verify the calculation for power of 2 case
                                                                                            long expected = (n * (long) 123456789) >> 31;
                                                                                            assertEquals((int) expected, result);
                                                                                        }

 @Test
                                                                                        public void testNextInt_ValueInRange() {
                                                                                            // Create a concrete subclass to test the protected method
                                                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                @Override
                                                                                                protected int next(int bits) {
                                                                                                    return 500; // Return fixed value for testing
                                                                                                }
                                                                                        
                                                                                                @Override
                                                                                                public void setSeed(int seed) {}
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {}
                                                                                                @Override
                                                                                                public void setSeed(long seed) {}
                                                                                            };
                                                                                            
                                                                                            int n = 10;
                                                                                            int result = generator.nextInt(n);
                                                                                            
                                                                                            assertTrue(result >= 0);
                                                                                            assertTrue(result < n);
                                                                                        }

 @Test
                                                                                        public void testNextInt_EdgeCaseNEqualsOne() {
                                                                                            // Create a concrete subclass to access protected method
                                                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                @Override
                                                                                                protected int next(int bits) {
                                                                                                    return 12345;
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                public void setSeed(int seed) {}
                                                                                                
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {}
                                                                                                
                                                                                                @Override
                                                                                                public void setSeed(long seed) {}
                                                                                            };
                                                                                            
                                                                                            int result = generator.nextInt(1);
                                                                                            assertEquals(0, result); // should always return 0 when n=1
                                                                                        }

 @Test
                                                                                        public void testNextInt_LargeNValue() {
                                                                                            // Create a concrete subclass to access protected next() method
                                                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                private int callCount = 0;
                                                                                                
                                                                                                @Override
                                                                                                protected int next(int bits) {
                                                                                                    if (callCount++ == 0) {
                                                                                                        return Integer.MAX_VALUE - 100; // first call that will pass
                                                                                                    }
                                                                                                    return Integer.MAX_VALUE / 2; // second call that would pass
                                                                                                }
                                                                                        
                                                                                                @Override
                                                                                                public void setSeed(int seed) {}
                                                                                                
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {}
                                                                                                
                                                                                                @Override
                                                                                                public void setSeed(long seed) {}
                                                                                            };
                                                                                            
                                                                                            int n = Integer.MAX_VALUE - 1;
                                                                                            int result = generator.nextInt(n);
                                                                                            
                                                                                            assertTrue(result >= 0);
                                                                                            assertTrue(result < n);
                                                                                        }

 @Test
                                                                                    public void testClear_ResetsNextGaussianToNaN() {
                                                                                        // Create an instance of a concrete subclass of BitsStreamGenerator for testing
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                            @Override
                                                                                            protected int next(int bits) { return 0; }
                                                                                        };
                                                                                        
                                                                                        // Set nextGaussian to a non-NaN value first
                                                                                        try {
                                                                                            // This uses reflection to set the private field for testing purposes
                                                                                            java.lang.reflect.Field field = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                            field.setAccessible(true);
                                                                                            field.set(generator, 1.0);
                                                                                            
                                                                                            // Verify it was set correctly
                                                                                            assertEquals(1.0, field.getDouble(generator), 0.0);
                                                                                            
                                                                                            // Call the clear method
                                                                                            generator.clear();
                                                                                            
                                                                                            // Verify nextGaussian is now NaN
                                                                                            assertTrue(Double.isNaN(field.getDouble(generator)));
                                                                                        } catch (Exception e) {
                                                                                            fail("Exception occurred during test: " + e.getMessage());
                                                                                        }
                                                                                    }

 @Test
                                                                                    public void testClear_WhenNextGaussianAlreadyNaN() {
                                                                                        try {
                                                                                            // Create a concrete instance of BitsStreamGenerator for testing
                                                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                @Override
                                                                                                public void setSeed(int seed) {}
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {}
                                                                                                @Override
                                                                                                public void setSeed(long seed) {}
                                                                                                @Override
                                                                                                protected int next(int bits) { return 0; }
                                                                                            };
                                                                                            
                                                                                            // Get the field and ensure it's initially NaN (as per constructor)
                                                                                            java.lang.reflect.Field field = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                            field.setAccessible(true);
                                                                                            assertTrue(Double.isNaN(field.getDouble(generator)));
                                                                                            
                                                                                            // Call clear
                                                                                            generator.clear();
                                                                                            
                                                                                            // Should still be NaN
                                                                                            assertTrue(Double.isNaN(field.getDouble(generator)));
                                                                                        } catch (Exception e) {
                                                                                            fail("Exception occurred during test: " + e.getMessage());
                                                                                        }
                                                                                    }

 @Test
                                                                                    public void testClear_DoesNotAffectOtherOperations() {
                                                                                        // This test verifies that clear() doesn't throw exceptions
                                                                                        // and doesn't affect other basic operations
                                                                                        BitsStreamGenerator generator = new MersenneTwister(); // Using concrete implementation
                                                                                        generator.clear();
                                                                                        generator.nextBoolean();  // Should not throw
                                                                                        generator.nextBytes(new byte[1]);  // Should not throw
                                                                                        generator.nextDouble();  // Should not throw
                                                                                    }

 @Test
                                                                                    public void testConstructor_InitializesNextGaussian() throws Exception {
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                            @Override
                                                                                            protected int next(int bits) { return 0; }
                                                                                        };
                                                                                        
                                                                                        // Use reflection to access private nextGaussian field
                                                                                        Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                        nextGaussianField.setAccessible(true);
                                                                                        double nextGaussianValue = (Double) nextGaussianField.get(generator);
                                                                                        
                                                                                        // Verify that nextGaussian is initialized to NaN
                                                                                        assertTrue(Double.isNaN(nextGaussianValue));
                                                                                    }

 @Test
                                                                                    public void testSetSeedWithInt() throws Exception {
                                                                                        // Create an anonymous subclass of BitsStreamGenerator for testing
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            public void setSeed(int seed) {
                                                                                                // Implementation required by abstract class
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {
                                                                                                // Implementation required by abstract class
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {
                                                                                                // Implementation required by abstract class
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                // Implementation required by abstract class
                                                                                                return 0;
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        // Test typical values
                                                                                        generator.setSeed(12345);
                                                                                        generator.setSeed(0);
                                                                                        generator.setSeed(-1);
                                                                                        
                                                                                        // Use reflection to access private nextGaussian field
                                                                                        Field nextGaussianField = generator.getClass().getSuperclass().getDeclaredField("nextGaussian");
                                                                                        nextGaussianField.setAccessible(true);
                                                                                        double nextGaussianValue = (Double) nextGaussianField.get(generator);
                                                                                        
                                                                                        // Verify the nextGaussian is reset (from constructor)
                                                                                        assertTrue(Double.isNaN(nextGaussianValue));
                                                                                    }

 @Test
                                                                                    public void testSetSeedWithIntArray() {
                                                                                        // Setup
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 0;
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        // Test with normal array
                                                                                        generator.setSeed(new int[]{1, 2, 3});
                                                                                        
                                                                                        // Test with empty array
                                                                                        generator.setSeed(new int[]{});
                                                                                        
                                                                                        // Test with null array - should throw NullPointerException
                                                                                        try {
                                                                                            generator.setSeed((int[])null);
                                                                                            fail("Expected NullPointerException");
                                                                                        } catch (NullPointerException e) {
                                                                                            // expected
                                                                                        }
                                                                                    }

 @Test
                                                                                    public void testSetSeedWithLong() {
                                                                                        // Create an anonymous subclass of BitsStreamGenerator for testing
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 0;
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        // Test typical values
                                                                                        generator.setSeed(123456789L);
                                                                                        generator.setSeed(0L);
                                                                                        generator.setSeed(-1L);
                                                                                        generator.setSeed(Long.MAX_VALUE);
                                                                                        generator.setSeed(Long.MIN_VALUE);
                                                                                        
                                                                                        // Verify the nextGaussian is reset (from constructor)
                                                                                        // Need to use reflection to access the private field
                                                                                        try {
                                                                                            Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                            nextGaussianField.setAccessible(true);
                                                                                            double nextGaussianValue = nextGaussianField.getDouble(generator);
                                                                                            assertTrue(Double.isNaN(nextGaussianValue));
                                                                                        } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                            fail("Failed to access nextGaussian field: " + e.getMessage());
                                                                                        }
                                                                                    }

 @Test
                                                                                    public void testNext_ValidBitsRange() throws Exception {
                                                                                        // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                // Simple implementation that just returns a value
                                                                                                return 0;
                                                                                            }
                                                                                        
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                    
                                                                                        // Get the protected next method using reflection
                                                                                        Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                                                        nextMethod.setAccessible(true);
                                                                                        
                                                                                        // Test that next works with valid bit ranges (1-32)
                                                                                        int result1 = (int) nextMethod.invoke(generator, 1);
                                                                                        assertTrue("Should return value with 1 bit", result1 >= 0 && result1 < 2);
                                                                                        
                                                                                        int result16 = (int) nextMethod.invoke(generator, 16);
                                                                                        assertTrue("Should return value with 16 bits", result16 >= 0 && result16 < 65536);
                                                                                        
                                                                                        int result32 = (int) nextMethod.invoke(generator, 32);
                                                                                        assertTrue("Should return value with 32 bits", result32 >= 0);
                                                                                    }

 @Test
                                                                                    public void testNext_InvalidBitsRange() throws Exception {
                                                                                        // Create an anonymous subclass of BitsStreamGenerator for testing
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 0; // dummy implementation
                                                                                            }
                                                                                        
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                        
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                        
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        // Get the protected next method using reflection
                                                                                        Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                                                        nextMethod.setAccessible(true);
                                                                                        
                                                                                        // Test behavior with invalid bit counts
                                                                                        ExpectedException exception = ExpectedException.none();
                                                                                        exception.expect(IllegalArgumentException.class);
                                                                                        nextMethod.invoke(generator, 0);
                                                                                        
                                                                                        exception.expect(IllegalArgumentException.class);
                                                                                        nextMethod.invoke(generator, 33);
                                                                                    }

 @Test
                                                                                    public void testNextBoolean_ReturnsFalseWhenNextReturnsZero() {
                                                                                        // Arrange
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 0;  // Always return 0 when next(1) is called
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        // Act
                                                                                        boolean result = generator.nextBoolean();
                                                                                        
                                                                                        // Assert
                                                                                        assertFalse(result);
                                                                                    }

 @Test
                                                                                    public void testNextBoolean_ReturnsTrueWhenNextReturnsOne() {
                                                                                        // Arrange
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 1; // Always return 1 when next(1) is called
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        // Act
                                                                                        boolean result = generator.nextBoolean();
                                                                                        
                                                                                        // Assert
                                                                                        assertTrue(result);
                                                                                    }

 @Test
                                                                                    public void testNextBoolean_ReturnsTrueWhenNextReturnsNonZero() {
                                                                                        // Arrange
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 42; // any non-zero value
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        // Act
                                                                                        boolean result = generator.nextBoolean();
                                                                                        
                                                                                        // Assert
                                                                                        assertTrue(result);
                                                                                    }

 @Test
                                                                                    public void testNextBoolean_MultipleCallsReturnConsistentResults() {
                                                                                        // Arrange
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            private int callCount = 0;
                                                                                            private final int[] returns = {0, 1, 0, 1};
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return returns[callCount++ % returns.length];
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        // Act & Assert
                                                                                        assertFalse(generator.nextBoolean());
                                                                                        assertTrue(generator.nextBoolean());
                                                                                        assertFalse(generator.nextBoolean());
                                                                                        assertTrue(generator.nextBoolean());
                                                                                    }

 @Test
                                                                                    public void testNextDouble_Range() throws Exception {
                                                                                        // Create a subclass that exposes the protected next() method
                                                                                        class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 0; // default implementation
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                            
                                                                                            public int exposedNext(int bits) {
                                                                                                return next(bits);
                                                                                            }
                                                                                        }
                                                                                        
                                                                                        // Create a mock of our testable subclass
                                                                                        TestableBitsStreamGenerator generator = mock(TestableBitsStreamGenerator.class);
                                                                                        
                                                                                        // Test minimum possible value (all bits 0)
                                                                                        when(generator.exposedNext(anyInt())).thenReturn(0);
                                                                                        double result = generator.nextDouble();
                                                                                        assertEquals(0.0, result, 0.0);
                                                                                        
                                                                                        // Test maximum possible value (all bits 1)
                                                                                        when(generator.exposedNext(26)).thenReturn(0x3FFFFFF); // 26 bits of 1
                                                                                        result = generator.nextDouble();
                                                                                        // Should be (2^52 - 1)/2^52 = 0.9999999999999999
                                                                                        assertEquals(0.9999999999999999, result, 0.0);
                                                                                        
                                                                                        // Verify the result is always in [0,1) range
                                                                                        for (int i = 0; i < 100; i++) {
                                                                                            when(generator.exposedNext(26)).thenReturn((int)(Math.random() * 0x3FFFFFF));
                                                                                            result = generator.nextDouble();
                                                                                            assertTrue(result >= 0.0 && result < 1.0);
                                                                                        }
                                                                                    }

 @Test
                                                                                    public void testNextFloat_MinimumValue() {
                                                                                        // Arrange
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 0;  // Return 0 for minimum float value
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        // Act
                                                                                        float result = generator.nextFloat();
                                                                                        
                                                                                        // Assert
                                                                                        assertEquals(0.0f, result, 0.0f);
                                                                                    }

 @Test
                                                                                    public void testNextFloat_MaximumValue() {
                                                                                        // Arrange
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return (1 << 23) - 1; // Return max 23-bit value
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        int max23Bit = (1 << 23) - 1; // 2^23 - 1
                                                                                        
                                                                                        // Act
                                                                                        float result = generator.nextFloat();
                                                                                        
                                                                                        // Assert
                                                                                        // Maximum value should be (2^23-1) * 2^-23 = 0.99999994f
                                                                                        assertEquals(0.99999994f, result, 0.00000001f);
                                                                                        assertTrue(result < 1.0f); // Should be strictly less than 1.0
                                                                                    }

 @Test
                                                                                    public void testNextFloat_TypicalValue() throws Exception {
                                                                                        // Arrange
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 1234567;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        // Act
                                                                                        float result = generator.nextFloat();
                                                                                        
                                                                                        // Assert
                                                                                        float expected = 1234567 * 0x1.0p-23f;
                                                                                        assertEquals(expected, result, 0.0000001f);
                                                                                        assertTrue(result >= 0.0f && result < 1.0f);
                                                                                    }

 @Test
                                                                                    public void testNextFloat_RangeCheck() {
                                                                                        // Arrange - create a subclass that exposes the protected method
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            private int callCount = 0;
                                                                                            private final int[] values = {1, 500000, 8000000, (1 << 23) - 2};
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return values[callCount++];
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        // Act & Assert
                                                                                        float result1 = generator.nextFloat();
                                                                                        assertTrue(result1 >= 0.0f && result1 < 1.0f);
                                                                                        
                                                                                        float result2 = generator.nextFloat();
                                                                                        assertTrue(result2 >= 0.0f && result2 < 1.0f);
                                                                                        
                                                                                        float result3 = generator.nextFloat();
                                                                                        assertTrue(result3 >= 0.0f && result3 < 1.0f);
                                                                                        
                                                                                        float result4 = generator.nextFloat();
                                                                                        assertTrue(result4 >= 0.0f && result4 < 1.0f);
                                                                                    }

 @Test
                                                                                    public void testNextFloat_AllBitsPatterns() {
                                                                                        // Test that all bits patterns produce valid results
                                                                                        
                                                                                        // Arrange
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 0x7FFFFF; // All 23 bits set
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        // Act
                                                                                        float result = generator.nextFloat();
                                                                                        
                                                                                        // Assert
                                                                                        assertEquals(0.99999994f, result, 0.00000001f);
                                                                                    }

 @Test
                                                                                    public void testNextInt_ReturnsMinimum32BitValue() throws Exception {
                                                                                        BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                        
                                                                                        // Use reflection to access the protected next(int) method
                                                                                        Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                                                        nextMethod.setAccessible(true);
                                                                                        when(nextMethod.invoke(generator, 32)).thenReturn(Integer.MIN_VALUE);
                                                                                        
                                                                                        int result = generator.nextInt();
                                                                                        
                                                                                        assertEquals(Integer.MIN_VALUE, result);
                                                                                    }

 @Test
                                                                                    public void testNextInt_ReturnsMaximum32BitValue() {
                                                                                        // Create a concrete subclass to access the protected method
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return Integer.MAX_VALUE;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        int result = generator.nextInt();
                                                                                        
                                                                                        assertEquals(Integer.MAX_VALUE, result);
                                                                                    }

 @Test
                                                                                    public void testNextInt_ReturnsZero() {
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 0;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        int result = generator.nextInt();
                                                                                        
                                                                                        assertEquals(0, result);
                                                                                    }

 @Test
                                                                                    public void testNextInt_ReturnsPositiveValue() {
                                                                                        // Create a concrete subclass to expose the protected method
                                                                                        class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 54321; // Return our test value
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        }
                                                                                        
                                                                                        BitsStreamGenerator generator = new TestableBitsStreamGenerator();
                                                                                        int result = generator.nextInt();
                                                                                        assertEquals(54321, result);
                                                                                    }

 @Test
                                                                                    public void testNextLong_MaxValue() {
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 0xFFFFFFFF; // Always return max value
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        long result = generator.nextLong();
                                                                                        
                                                                                        assertEquals(0xFFFFFFFFFFFFFFFFL, result);
                                                                                    }

 @Test
                                                                                    public void testNextLong_MixedHighLowValues() {
                                                                                        // Create a concrete subclass to test the protected method
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            private int callCount = 0;
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                // Return different values on first and second calls
                                                                                                return (callCount++ == 0) ? 0xFFFF0000 : 0x0000FFFF;
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        long result = generator.nextLong();
                                                                                        
                                                                                        assertEquals(0xFFFF00000000FFFFL, result);
                                                                                    }

 @Test
                                                                                    public void testNextLong_ZeroHighBits() {
                                                                                        // Create a mock subclass that exposes the protected next() method
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            private int callCount = 0;
                                                                                            private final int[] values = {0x00000000, 0x12345678};
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return values[callCount++];
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        long result = generator.nextLong();
                                                                                        
                                                                                        assertEquals(0x0000000012345678L, result);
                                                                                    }

 @Test
                                                                                    public void testNextLong_ZeroLowBits() {
                                                                                        // Create a concrete subclass that exposes the protected next() method
                                                                                        class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                                                            private int[] values;
                                                                                            private int index = 0;
                                                                                            
                                                                                            TestableBitsStreamGenerator(int... values) {
                                                                                                this.values = values;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return values[index++];
                                                                                            }
                                                                                            
                                                                                            // Other abstract methods need to be implemented
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        }
                                                                                        
                                                                                        BitsStreamGenerator generator = new TestableBitsStreamGenerator(0x12345678, 0x00000000);
                                                                                        
                                                                                        long result = generator.nextLong();
                                                                                        
                                                                                        assertEquals(0x1234567800000000L, result);
                                                                                    }

 @Test
                                                                                public void testSetSeed_WithIntArrayParameter_NullInput() {
                                                                                    // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                    class TestBitsStreamGenerator extends BitsStreamGenerator {
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                        
                                                                                        @Override
                                                                                        protected int next(int bits) { return 0; }
                                                                                    }
                                                                                    
                                                                                    TestBitsStreamGenerator generator = new TestBitsStreamGenerator();
                                                                                    try {
                                                                                        generator.setSeed((int[]) null);
                                                                                        fail("Expected NullPointerException");
                                                                                    } catch (NullPointerException e) {
                                                                                        // Expected exception
                                                                                    }
                                                                                }

 @Test
                                                                                public void testNextLong_MinValue() {
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return 0; // Always return 0 to simulate minimum value
                                                                                        }
                                                                                    
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                    
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                    
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    long result = generator.nextLong();
                                                                                    
                                                                                    assertEquals(0x0000000000000000L, result);
                                                                                }

 @Test
                                                                            public void testNextLong_VerifyBitwiseOperations() {
                                                                                // Create a concrete subclass to access protected methods
                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                    private int callCount = 0;
                                                                                    
                                                                                    @Override
                                                                                    protected int next(int bits) {
                                                                                        // Alternate between returning 0xA5A5A5A5 and 0x5A5A5A5A
                                                                                        return (callCount++ % 2 == 0) ? 0xA5A5A5A5 : 0x5A5A5A5A;
                                                                                    }
                                                                            
                                                                                    @Override
                                                                                    public void setSeed(int seed) {}
                                                                                    
                                                                                    @Override
                                                                                    public void setSeed(int[] seed) {}
                                                                                    
                                                                                    @Override
                                                                                    public void setSeed(long seed) {}
                                                                                };
                                                                                
                                                                                long result = generator.nextLong();
                                                                                
                                                                                // Verify the bitwise operations
                                                                                long expectedHigh = ((long) 0xA5A5A5A5) << 32;
                                                                                long expectedLow = ((long) 0x5A5A5A5A) & 0xffffffffL;
                                                                                assertEquals(expectedHigh | expectedLow, result);
                                                                            }

 @Test
                                                                        public void testNextInt_ReturnsNegativeValue() {
                                                                            // Create a spy of a concrete subclass since we can't directly mock protected methods
                                                                            BitsStreamGenerator generator = spy(new BitsStreamGenerator() {
                                                                                @Override
                                                                                protected int next(int bits) {
                                                                                    return -12345;
                                                                                }
                                                                        
                                                                                @Override
                                                                                public void setSeed(int seed) {}
                                                                                
                                                                                @Override
                                                                                public void setSeed(int[] seed) {}
                                                                                
                                                                                @Override
                                                                                public void setSeed(long seed) {}
                                                                            });
                                                                            
                                                                            int result = generator.nextInt();
                                                                            
                                                                            assertEquals(-12345, result);
                                                                        }

 @Test
                                                                public void testNextDouble_Consistency() {
                                                                    // Create a concrete implementation that we can control
                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                        private int callCount = 0;
                                                                        
                                                                        protected int next(int bits) {
                                                                            // Alternate between two values
                                                                            return (callCount++ % 2 == 0) ? 123456 : 654321;
                                                                        }
                                                                        
                                                                        public void setSeed(int seed) {}
                                                                        public void setSeed(int[] seed) {}
                                                                        public void setSeed(long seed) {}
                                                                    };
                                                                    
                                                                    double firstResult = generator.nextDouble();
                                                                    double secondResult = generator.nextDouble();
                                                                    // The results should be different because we're returning different values from next()
                                                                    assertNotEquals(firstResult, secondResult, 0.0);
                                                                    
                                                                    // Test consistency by calling again with same sequence
                                                                    generator = new BitsStreamGenerator() {
                                                                        private int callCount = 0;
                                                                        
                                                                        protected int next(int bits) {
                                                                            // Return same sequence again
                                                                            return (callCount++ % 2 == 0) ? 123456 : 654321;
                                                                        }
                                                                        
                                                                        public void setSeed(int seed) {}
                                                                        public void setSeed(int[] seed) {}
                                                                        public void setSeed(long seed) {}
                                                                    };
                                                                    
                                                                    double thirdResult = generator.nextDouble();
                                                                    double fourthResult = generator.nextDouble();
                                                                    // The sequence should be consistent
                                                                    assertEquals(firstResult, thirdResult, 0.0);
                                                                    assertEquals(secondResult, fourthResult, 0.0);
                                                                }

 @Test
                                                        public void testNextDouble_Distribution() {
                                                            // Create a custom implementation where we can control the next() output
                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                private int callCount = 0;
                                                                private int[][] returnValues = new int[0][];
                                                                
                                                                public void setReturnValues(int[]... values) {
                                                                    this.returnValues = values;
                                                                    this.callCount = 0;
                                                                }
                                                                
                                                                @Override
                                                                protected int next(int bits) {
                                                                    return returnValues[callCount++ % returnValues.length][0];
                                                                }
                                                            
                                                                @Override
                                                                public void setSeed(int seed) {}
                                                            
                                                                @Override
                                                                public void setSeed(int[] seed) {}
                                                            
                                                                @Override
                                                                public void setSeed(long seed) {}
                                                            };
                                                            
                                                            // Case where high bits are 1 and low bits are 0
                                                    {}{}
                                                            double result = generator.nextDouble();
                                                            assertEquals(0.9999999999999999, result, 0.0);
                                                            
                                                            // Case where high bits are 0 and low bits are 1
                                                    {}{}
                                                            result = generator.nextDouble();
                                                            assertEquals(0.0000000000000002, result, 0.0); // 2^-52
                                                            
                                                            // Case with alternating bits
                                                    {}{}
                                                            result = generator.nextDouble();
                                                            assertEquals(0.3333333333333333, result, 0.0000000000000001);
                                                        }

 @Test
                                                        public void testNextDouble_EdgeCases() throws Exception {
                                                            // Create a concrete implementation
                                                            org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                                                                private int nextValue;
                                                                
                                                                public void setNextValue(int value) {
                                                                    this.nextValue = value;
                                                                }
                                                                
                                                                @Override
                                                                protected int next(int bits) {
                                                                    return nextValue;
                                                                }
                                                        
                                                                @Override
                                                                public void setSeed(int seed) {}
                                                        
                                                                @Override
                                                                public void setSeed(int[] seed) {}
                                                        
                                                                @Override
                                                                public void setSeed(long seed) {}
                                                            };
                                                            
                                                            // Test with minimum non-zero value
                                                            double result = generator.nextDouble();
                                                            assertEquals(Double.MIN_VALUE, result, 0.0);
                                                            
                                                            // Test with maximum value before 1.0
                                                            result = generator.nextDouble();
                                                            assertEquals(0.9999999999999998, result, 0.0);
                                                        }

 @Test
                                                        public void testNextInt_CallsNextWith32Bits() {
                                                            // Create a concrete subclass to test the protected method
                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                private int nextValue;
                                                                
                                                                @Override
                                                                protected int next(int bits) {
                                                                    return nextValue;
                                                                }
                                                                
                                                                @Override
                                                                public void setSeed(int seed) {}
                                                                
                                                                @Override
                                                                public void setSeed(int[] seed) {}
                                                                
                                                                @Override
                                                                public void setSeed(long seed) {}
                                                                
                                                                public void setNextValue(int value) {
                                                                    this.nextValue = value;
                                                                }
                                                            };
                                                            
                                                            // Set the expected return value using the anonymous class's method
                                                            
                                                            // Call method and verify
                                                            int result = generator.nextInt();
                                                            
                                                            // Verify result
                                                            assertEquals(123456789, result);
                                                        }

 @Test
                public void testNextInt_NonPowerOfTwoCase() {
                    // Create a spy of an anonymous subclass to access protected method
                    BitsStreamGenerator generator = spy(new BitsStreamGenerator() {
                        @Override
                        protected int next(int bits) {
                            return 0; // dummy implementation, will be mocked via spy
                        }
                    
                        @Override
                        public void setSeed(int seed) {}
                        
                        @Override
                        public void setSeed(int[] seed) {}
                        
                        @Override
                        public void setSeed(long seed) {}
                    });
                    
                    // Mock the protected next() method using Mockito's doReturn().when() pattern
                    // We need to use doReturn().when() pattern for protected methods
                    try {
                    } catch (Exception e) {
                        fail("Unexpected exception: " + e.getMessage());
                    }
                    
                    int n = 7; // not a power of 2
                    int result = generator.nextInt(n);
                    
                    assertEquals(1000 % n, result);
                }

 @Test
                public void testNextLong_CombinesHighAndLowBitsCorrectly() throws Exception {
                    // Create a concrete instance of the abstract class for testing
                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                        private int callCount = 0;
                        
                        @Override
                        protected int next(int bits) {
                            // Return different values on first and second calls
                            return (callCount++ == 0) ? 0x12345678 : 0x9ABCDEF0;
                        }
                    
                        @Override
                        public void setSeed(int seed) {}
                    
                        @Override
                        public void setSeed(int[] seed) {}
                    
                        @Override
                        public void setSeed(long seed) {}
                    };
                    
                    long result = generator.nextLong();
                    
                    // Verify the result is correctly combined
                    assertEquals(0x123456789ABCDEF0L, result);
                }

}
