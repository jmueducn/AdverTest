package gentest.org.apache.commons.math.optimization.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.general.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MaxEvaluationsExceededException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction;
import org.apache.commons.math.analysis.MultivariateMatrixFunction;
import org.apache.commons.math.exception.LocalizedFormats;
import org.apache.commons.math.linear.InvalidMatrixException;
import org.apache.commons.math.linear.LUDecompositionImpl;
import org.apache.commons.math.linear.MatrixUtils;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.optimization.OptimizationException;
import org.apache.commons.math.optimization.SimpleVectorialValueChecker;
import org.apache.commons.math.optimization.VectorialConvergenceChecker;
import org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer;
import org.apache.commons.math.optimization.VectorialPointValuePair;
 
public class AbstractLeastSquaresOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                  public void testGetChiSquare_WithPositiveValues() throws Exception {
                                                                                                                                                                      // Setup
                                                                                                                                                                      double[] testResiduals = new double[]{2.0, 3.0, 4.0};
                                                                                                                                                                      double[] testWeights = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                      
                                                                                                                                                                      // Create optimizer instance
                                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                          @Override
                                                                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                              return null;
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                      Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                      residualsField.setAccessible(true);
                                                                                                                                                                      residualsField.set(optimizer, testResiduals);
                                                                                                                                                                      
                                                                                                                                                                      Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weights");
                                                                                                                                                                      weightsField.setAccessible(true);
                                                                                                                                                                      weightsField.set(optimizer, testWeights);
                                                                                                                                                                      
                                                                                                                                                                      // Expected calculation: (2²*1) + (3²*2) + (4²*3) = 4 + 18 + 48 = 70
                                                                                                                                                                      double expected = 70.0;
                                                                                                                                                                      
                                                                                                                                                                      // Test
                                                                                                                                                                      double result = optimizer.getChiSquare();
                                                                                                                                                                      
                                                                                                                                                                      // Verify
                                                                                                                                                                      assertEquals(expected, result, 0.0001);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testGetChiSquare_WithNegativeResiduals() {
                                                                                                                                                                      // Setup
                                                                                                                                                                      double[] testResiduals = new double[]{-1.0, -2.0, -3.0};
                                                                                                                                                                      double[] testWeights = new double[]{0.5, 1.0, 1.5};
                                                                                                                                                                      
                                                                                                                                                                      // Create optimizer instance
                                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                          @Override
                                                                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                              return null;
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                      try {
                                                                                                                                                                          Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                          residualsField.setAccessible(true);
                                                                                                                                                                          residualsField.set(optimizer, testResiduals);
                                                                                                                                                                          
                                                                                                                                                                          Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weights");
                                                                                                                                                                          weightsField.setAccessible(true);
                                                                                                                                                                          weightsField.set(optimizer, testWeights);
                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                          fail("Failed to set test fields via reflection: " + e.getMessage());
                                                                                                                                                                      }
                                                                                                                                                                      
                                                                                                                                                                      // Expected calculation: (1²*0.5) + (2²*1) + (3²*1.5) = 0.5 + 4 + 13.5 = 18
                                                                                                                                                                      double expected = 18.0;
                                                                                                                                                                      
                                                                                                                                                                      // Test
                                                                                                                                                                      double result = optimizer.getChiSquare();
                                                                                                                                                                      
                                                                                                                                                                      // Verify
                                                                                                                                                                      assertEquals(expected, result, 0.0001);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testGetChiSquare_WithZeroWeights() {
                                                                                                                                                                      // Setup
                                                                                                                                                                      double[] testResiduals = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                      double[] testWeights = new double[]{0.0, 0.0, 0.0};
                                                                                                                                                                      
                                                                                                                                                                      // Create optimizer instance
                                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                          @Override
                                                                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                              return null;
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                      try {
                                                                                                                                                                          Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                          residualsField.setAccessible(true);
                                                                                                                                                                          residualsField.set(optimizer, testResiduals);
                                                                                                                                                                          
                                                                                                                                                                          Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weights");
                                                                                                                                                                          weightsField.setAccessible(true);
                                                                                                                                                                          weightsField.set(optimizer, testWeights);
                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                          fail("Failed to set test fields via reflection: " + e.getMessage());
                                                                                                                                                                      }
                                                                                                                                                                      
                                                                                                                                                                      // Expected calculation: all terms become zero
                                                                                                                                                                      double expected = 0.0;
                                                                                                                                                                      
                                                                                                                                                                      // Test
                                                                                                                                                                      double result = optimizer.getChiSquare();
                                                                                                                                                                      
                                                                                                                                                                      // Verify
                                                                                                                                                                      assertEquals(expected, result, 0.0001);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testGetChiSquare_WithZeroResiduals() {
                                                                                                                                                                      // Setup
                                                                                                                                                                      double[] testResiduals = new double[]{0.0, 0.0, 0.0};
                                                                                                                                                                      double[] testWeights = new double[]{0.5, 1.0, 1.5};
                                                                                                                                                                      
                                                                                                                                                                      // Create optimizer instance
                                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                              return null; // dummy implementation
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to set private fields if needed
                                                                                                                                                                      try {
                                                                                                                                                                          Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                          residualsField.setAccessible(true);
                                                                                                                                                                          residualsField.set(optimizer, testResiduals);
                                                                                                                                                                          
                                                                                                                                                                          Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weights");
                                                                                                                                                                          weightsField.setAccessible(true);
                                                                                                                                                                          weightsField.set(optimizer, testWeights);
                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                          fail("Failed to set test fields via reflection: " + e.getMessage());
                                                                                                                                                                      }
                                                                                                                                                                      
                                                                                                                                                                      // Expected calculation: all terms become zero
                                                                                                                                                                      double expected = 0.0;
                                                                                                                                                                      
                                                                                                                                                                      // Test
                                                                                                                                                                      double result = optimizer.getChiSquare();
                                                                                                                                                                      
                                                                                                                                                                      // Verify
                                                                                                                                                                      assertEquals(expected, result, 0.0001);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testGetChiSquare_WithSingleElement() throws Exception {
                                                                                                                                                                      // Setup
                                                                                                                                                                      double[] testResiduals = new double[]{5.0};
                                                                                                                                                                      double[] testWeights = new double[]{2.0};
                                                                                                                                                                      
                                                                                                                                                                      // Create optimizer instance
                                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                          @Override
                                                                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                              return null;
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to set private fields if needed
                                                                                                                                                                      Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                      residualsField.setAccessible(true);
                                                                                                                                                                      residualsField.set(optimizer, testResiduals);
                                                                                                                                                                      
                                                                                                                                                                      Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weights");
                                                                                                                                                                      weightsField.setAccessible(true);
                                                                                                                                                                      weightsField.set(optimizer, testWeights);
                                                                                                                                                                      
                                                                                                                                                                      // Expected calculation: (5²*2) = 50
                                                                                                                                                                      double expected = 50.0;
                                                                                                                                                                      
                                                                                                                                                                      // Test
                                                                                                                                                                      double result = optimizer.getChiSquare();
                                                                                                                                                                      
                                                                                                                                                                      // Verify
                                                                                                                                                                      assertEquals(expected, result, 0.0001);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testGetChiSquare_WithLargeValues() throws Exception {
                                                                                                                                                                      // Setup
                                                                                                                                                                      double[] testResiduals = new double[]{1000.0, 2000.0};
                                                                                                                                                                      double[] testWeights = new double[]{0.001, 0.002};
                                                                                                                                                                      
                                                                                                                                                                      // Create optimizer instance
                                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                          @Override
                                                                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                              return null;
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                      Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                      residualsField.setAccessible(true);
                                                                                                                                                                      residualsField.set(optimizer, testResiduals);
                                                                                                                                                                      
                                                                                                                                                                      Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weights");
                                                                                                                                                                      weightsField.setAccessible(true);
                                                                                                                                                                      weightsField.set(optimizer, testWeights);
                                                                                                                                                                      
                                                                                                                                                                      // Expected calculation: (1000²*0.001) + (2000²*0.002) = 1000 + 8000 = 9000
                                                                                                                                                                      double expected = 9000.0;
                                                                                                                                                                      
                                                                                                                                                                      // Test
                                                                                                                                                                      double result = optimizer.getChiSquare();
                                                                                                                                                                      
                                                                                                                                                                      // Verify
                                                                                                                                                                      assertEquals(expected, result, 0.0001);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testGetChiSquare_WithNullResiduals() {
                                                                                                                                                                      // Setup
                                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                          @Override
                                                                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                              return null;
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      try {
                                                                                                                                                                          java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                          residualsField.setAccessible(true);
                                                                                                                                                                          residualsField.set(optimizer, null);
                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                          throw new RuntimeException("Failed to set null residuals", e);
                                                                                                                                                                      }
                                                                                                                                                                      
                                                                                                                                                                      thrown.expect(NullPointerException.class);
                                                                                                                                                                      optimizer.getChiSquare();
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testGetChiSquare_WithNullWeights() {
                                                                                                                                                                      // Setup
                                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                          @Override
                                                                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                              return null; // Mock implementation
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      try {
                                                                                                                                                                          java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                          weightsField.setAccessible(true);
                                                                                                                                                                          weightsField.set(optimizer, null);
                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                          throw new RuntimeException("Failed to set null weights", e);
                                                                                                                                                                      }
                                                                                                                                                                      
                                                                                                                                                                      thrown.expect(NullPointerException.class);
                                                                                                                                                                      optimizer.getChiSquare();
                                                                                                                                                                  }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                                                                                                                              public void testGetChiSquare_WithDifferentLengthArrays() {
                                                                                                                                                                  // Setup test data
                                                                                                                                                                  double[] testResiduals = new double[]{1.0, 2.0, 3.0, 4.0};
                                                                                                                                                                  double[] testWeights = new double[]{0.5, 1.0, 1.5};
                                                                                                                                                                  
                                                                                                                                                                  // Create optimizer instance
                                                                                                                                                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                      @Override
                                                                                                                                                                      protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                          return null;
                                                                                                                                                                      }
                                                                                                                                                                  };
                                                                                                                                                                  
                                                                                                                                                                  // Set test fields using reflection since they're likely protected/private
                                                                                                                                                                  try {
                                                                                                                                                                      Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                      residualsField.setAccessible(true);
                                                                                                                                                                      residualsField.set(optimizer, testResiduals);
                                                                                                                                                                      
                                                                                                                                                                      Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weights");
                                                                                                                                                                      weightsField.setAccessible(true);
                                                                                                                                                                      weightsField.set(optimizer, testWeights);
                                                                                                                                                                      
                                                                                                                                                                      Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                      rowsField.setAccessible(true);
                                                                                                                                                                      rowsField.set(optimizer, testResiduals.length);
                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                      throw new RuntimeException("Failed to set test fields via reflection", e);
                                                                                                                                                                  }
                                                                                                                                                                  
                                                                                                                                                                  // Execute test - should throw ArrayIndexOutOfBoundsException
                                                                                                                                                                  optimizer.getChiSquare();
                                                                                                                                                              }

    @Test
                                                                                                                                                         public void testGetChiSquareDetectsInitializationMutant() throws Exception {
                                                                                                                                                             // Create test instance
                                                                                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                 @Override
                                                                                                                                                                 protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                     return null; // Not needed for this test
                                                                                                                                                                 }
                                                                                                                                                             };
                                                                                                                                                             
                                                                                                                                                             // Get protected fields via reflection
                                                                                                                                                             Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                             Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                             Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                             
                                                                                                                                                             // Make fields accessible
                                                                                                                                                             rowsField.setAccessible(true);
                                                                                                                                                             residualsField.setAccessible(true);
                                                                                                                                                             residualsWeightsField.setAccessible(true);
                                                                                                                                                             
                                                                                                                                                             // Test case 1: Empty case (rows = 0)
                                                                                                                                                             rowsField.setInt(optimizer, 0);
                                                                                                                                                             residualsField.set(optimizer, new double[0]);
                                                                                                                                                             residualsWeightsField.set(optimizer, new double[0]);
                                                                                                                                                             assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                             
                                                                                                                                                             // Test case 2: Simple case with known values
                                                                                                                                                             rowsField.setInt(optimizer, 2);
                                                                                                                                                             residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                                                                             residualsWeightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                             // Expected: (1² * 1) + (2² * 1) = 1 + 4 = 5
                                                                                                                                                             assertEquals(5.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                             
                                                                                                                                                             // Test case 3: With different weights
                                                                                                                                                             rowsField.setInt(optimizer, 2);
                                                                                                                                                             residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                                                                             residualsWeightsField.set(optimizer, new double[]{0.5, 2.0});
                                                                                                                                                             // Expected: (1² * 0.5) + (2² * 2) = 0.5 + 8 = 8.5
                                                                                                                                                             assertEquals(8.5, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                         }

    @Test
                                                                                                                                                    public void testGetChiSquareWithZeroRows() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                            @Override
                                                                                                                                                            protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                return null;
                                                                                                                                                            }
                                                                                                                                                        };
                                                                                                                                                        
                                                                                                                                                        // Use reflection to set private fields
                                                                                                                                                        Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                        rowsField.setAccessible(true);
                                                                                                                                                        rowsField.set(optimizer, 0);
                                                                                                                                                        
                                                                                                                                                        Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                        residualsField.setAccessible(true);
                                                                                                                                                        residualsField.set(optimizer, new double[0]);
                                                                                                                                                        
                                                                                                                                                        Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                        residualsWeightsField.setAccessible(true);
                                                                                                                                                        residualsWeightsField.set(optimizer, new double[0]);
                                                                                                                                                        
                                                                                                                                                        // Test and verify
                                                                                                                                                        assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testGetChiSquareWithNonZeroRows() throws Exception {
                                                                                                                                                        // Create optimizer instance
                                                                                                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                            @Override
                                                                                                                                                            protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                return null;
                                                                                                                                                            }
                                                                                                                                                        };
                                                                                                                                                        
                                                                                                                                                        // Set private fields using reflection
                                                                                                                                                        Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                        rowsField.setAccessible(true);
                                                                                                                                                        rowsField.set(optimizer, 2);
                                                                                                                                                        
                                                                                                                                                        Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                        residualsField.setAccessible(true);
                                                                                                                                                        residualsField.set(optimizer, new double[]{1.5, 2.0});
                                                                                                                                                        
                                                                                                                                                        Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                        residualsWeightsField.setAccessible(true);
                                                                                                                                                        residualsWeightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                        
                                                                                                                                                        // Expected: (1.5^2)*1 + (2.0^2)*1 = 2.25 + 4.0 = 6.25
                                                                                                                                                        double expected = 6.25;
                                                                                                                                                        
                                                                                                                                                        // Test and verify
                                                                                                                                                        assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                    }

    @Test
                                                                                                                                               public void testGetChiSquareDetectsFirstRowSkippingMutant() throws Exception {
                                                                                                                                                   // Create test instance
                                                                                                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                       @Override
                                                                                                                                                       protected VectorialPointValuePair doOptimize() {
                                                                                                                                                           return null; // dummy implementation
                                                                                                                                                       }
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   // Use reflection to set protected fields
                                                                                                                                                   Class<?> optimizerClass = optimizer.getClass();
                                                                                                                                                   java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                                   rowsField.setAccessible(true);
                                                                                                                                                   rowsField.set(optimizer, 2);
                                                                                                                                                   
                                                                                                                                                   java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                                                   residualsField.setAccessible(true);
                                                                                                                                                   residualsField.set(optimizer, new double[]{1.0, 2.0}); // First residual is 1.0
                                                                                                                                                   
                                                                                                                                                   java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                                   residualsWeightsField.setAccessible(true);
                                                                                                                                                   residualsWeightsField.set(optimizer, new double[]{2.0, 1.0}); // First weight is 2.0
                                                                                                                                                   
                                                                                                                                                   // Calculate expected chi-square (1.0^2 * 2.0) + (2.0^2 * 1.0) = 2 + 4 = 6
                                                                                                                                                   double expected = 6.0;
                                                                                                                                                   
                                                                                                                                                   // Mutant would calculate only (2.0^2 * 1.0) = 4
                                                                                                                                                   double actual = optimizer.getChiSquare();
                                                                                                                                                   
                                                                                                                                                   // Assertion that will fail if mutant skips first row
                                                                                                                                                   assertEquals("Chi-square calculation must include first row", 
                                                                                                                                                               expected, actual, 0.0001);
                                                                                                                                               }

    @Test
                                                                                                                                           public void testGetChiSquareLoopBehavior() {
                                                                                                                                               // Setup test data
                                                                                                                                               double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                                               double[] weights = {0.5, 1.0, 1.5};
                                                                                                                                               int rows = residuals.length;
                                                                                                                                               
                                                                                                                                               // Create partial mock of the class
                                                                                                                                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                   @Override
                                                                                                                                                   protected VectorialPointValuePair doOptimize() {
                                                                                                                                                       return null; // Not needed for this test
                                                                                                                                                   }
                                                                                                                                               };
                                                                                                                                               
                                                                                                                                               // Set protected fields using reflection
                                                                                                                                               try {
                                                                                                                                                   Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                   residualsField.setAccessible(true);
                                                                                                                                                   residualsField.set(optimizer, residuals);
                                                                                                                                                   
                                                                                                                                                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                   weightsField.setAccessible(true);
                                                                                                                                                   weightsField.set(optimizer, weights);
                                                                                                                                                   
                                                                                                                                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                   rowsField.setAccessible(true);
                                                                                                                                                   rowsField.set(optimizer, rows);
                                                                                                                                               } catch (Exception e) {
                                                                                                                                                   fail("Failed to set up test fields via reflection");
                                                                                                                                               }
                                                                                                                                               
                                                                                                                                               // Calculate expected value manually
                                                                                                                                               double expected = 0;
                                                                                                                                               for (int i = 0; i < rows; i++) {
                                                                                                                                                   expected += residuals[i] * residuals[i] * weights[i];
                                                                                                                                               }
                                                                                                                                               
                                                                                                                                               // Test the method
                                                                                                                                               double actual = optimizer.getChiSquare();
                                                                                                                                               
                                                                                                                                               // Verify the result
                                                                                                                                               assertEquals("Chi-square calculation incorrect", expected, actual, 0.0001);
                                                                                                                                               
                                                                                                                                               // Verify loop runs exactly 'rows' times by checking last element was processed
                                                                                                                                               // If loop ran one less time (due to ++i vs i++ difference), this would fail
                                                                                                                                               double lastElementContribution = residuals[rows-1] * residuals[rows-1] * weights[rows-1];
                                                                                                                                               assertTrue("Last element not processed", 
                                                                                                                                                          Math.abs(actual - expected) < 0.0001 && 
                                                                                                                                                          Math.abs(actual - (expected - lastElementContribution)) > 0.0001);
                                                                                                                                           }

    @Test
                                                                                                                                         public void testGetChiSquareDetectsResidualIndexMutant() throws Exception {
                                                                                                                                             // Setup test data with different residuals
                                                                                                                                             double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                                             double[] weights = {1.0, 1.0, 1.0};
                                                                                                                                             
                                                                                                                                             // Create mock of the class under test
                                                                                                                                             AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                             
                                                                                                                                             // Use reflection to set protected fields
                                                                                                                                             Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                             rowsField.setAccessible(true);
                                                                                                                                             rowsField.set(optimizer, residuals.length);
                                                                                                                                             
                                                                                                                                             Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                             residualsField.setAccessible(true);
                                                                                                                                             residualsField.set(optimizer, residuals);
                                                                                                                                             
                                                                                                                                             Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                             weightsField.setAccessible(true);
                                                                                                                                             weightsField.set(optimizer, weights);
                                                                                                                                             
                                                                                                                                             // Mock the getChiSquare method to call real method
                                                                                                                                             when(optimizer.getChiSquare()).thenCallRealMethod();
                                                                                                                                             
                                                                                                                                             // Calculate expected value (1^2*1 + 2^2*1 + 3^2*1 = 1 + 4 + 9 = 14)
                                                                                                                                             double expected = 14.0;
                                                                                                                                             
                                                                                                                                             // Call the method and verify
                                                                                                                                             double actual = optimizer.getChiSquare();
                                                                                                                                             
                                                                                                                                             // Assert the result matches expected calculation
                                                                                                                                             assertEquals("Chi-square calculation should use residuals from all indices", 
                                                                                                                                                          expected, actual, 0.0001);
                                                                                                                                             
                                                                                                                                             // If mutant is present, it would calculate (1^2*1 + 1^2*1 + 1^2*1 = 3) instead
                                                                                                                                             // So this test would fail with mutant, catching it
                                                                                                                                         }

    @Test
                                                                                                                                    public void testGetChiSquare_DetectsResidualZeroMutation() {
                                                                                                                                        // Setup test data with non-zero residuals and weights
                                                                                                                                        double[] testResiduals = {1.5, 2.0, 0.5}; // Non-zero residuals
                                                                                                                                        double[] testWeights = {1.0, 2.0, 1.0};   // Non-zero weights
                                                                                                                                        
                                                                                                                                        // Create mock of the class under test
                                                                                                                                        AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                        
                                                                                                                                        // Use reflection to set private fields needed for chi-square calculation
                                                                                                                                        try {
                                                                                                                                            Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                            residualsField.setAccessible(true);
                                                                                                                                            residualsField.set(optimizer, testResiduals);
                                                                                                                                            
                                                                                                                                            Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weights");
                                                                                                                                            weightsField.setAccessible(true);
                                                                                                                                            weightsField.set(optimizer, testWeights);
                                                                                                                                        } catch (Exception e) {
                                                                                                                                            fail("Failed to set private fields via reflection: " + e.getMessage());
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        // Setup mock behavior for getChiSquare()
                                                                                                                                        when(optimizer.getChiSquare()).thenCallRealMethod();
                                                                                                                                        
                                                                                                                                        // Calculate expected value manually
                                                                                                                                        double expected = 0;
                                                                                                                                        for (int i = 0; i < testResiduals.length; i++) {
                                                                                                                                            expected += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        // Call method and verify
                                                                                                                                        double actual = optimizer.getChiSquare();
                                                                                                                                        
                                                                                                                                        // This assertion will fail if the mutant is present (actual would be 0)
                                                                                                                                        assertEquals("Chi-square calculation incorrect - mutant detected", 
                                                                                                                                                    expected, actual, 0.0001);
                                                                                                                                        
                                                                                                                                        // Additional check to ensure we're not getting 0
                                                                                                                                        assertNotEquals("Chi-square should not be zero with non-zero inputs", 
                                                                                                                                                       0.0, actual, 0.0001);
                                                                                                                                    }

    @Test
                                                                                                                               public void testGetChiSquareDetectsSquaredResidualMutation() throws Exception {
                                                                                                                                   // Setup test data that will clearly show if squaring is missing
                                                                                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                       @Override
                                                                                                                                       protected VectorialPointValuePair doOptimize() {
                                                                                                                                           return null; // Not needed for this test
                                                                                                                                       }
                                                                                                                                   };
                                                                                                                                   
                                                                                                                                   // Use reflection to set protected fields
                                                                                                                                   Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                                                                                   java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                   rowsField.setAccessible(true);
                                                                                                                                   rowsField.setInt(optimizer, 3);
                                                                                                                                   
                                                                                                                                   java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                                   residualsField.setAccessible(true);
                                                                                                                                   residualsField.set(optimizer, new double[]{2.0, 0.5, -1.5});
                                                                                                                                   
                                                                                                                                   java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                   residualsWeightsField.setAccessible(true);
                                                                                                                                   residualsWeightsField.set(optimizer, new double[]{1.0, 2.0, 1.0});
                                                                                                                                   
                                                                                                                                   // Calculate expected value (with proper squaring)
                                                                                                                                   double expected = 0;
                                                                                                                                   double[] residuals = (double[]) residualsField.get(optimizer);
                                                                                                                                   double[] weights = (double[]) residualsWeightsField.get(optimizer);
                                                                                                                                   for (int i = 0; i < 3; i++) {
                                                                                                                                       expected += residuals[i] * residuals[i] * weights[i];
                                                                                                                                   }
                                                                                                                                   
                                                                                                                                   // Calculate actual value
                                                                                                                                   double actual = optimizer.getChiSquare();
                                                                                                                                   
                                                                                                                                   // Assert exact equality - will fail if mutation is present
                                                                                                                                   assertEquals("Chi-square calculation should include squaring of residuals", 
                                                                                                                                               expected, actual, 0.0001);
                                                                                                                                   
                                                                                                                                   // Additional check to ensure the test would catch the mutant
                                                                                                                                   // Calculate what the mutant would produce
                                                                                                                                   double mutantValue = 0;
                                                                                                                                   for (int i = 0; i < 3; i++) {
                                                                                                                                       mutantValue += residuals[i] * weights[i];
                                                                                                                                   }
                                                                                                                                   assertNotEquals("Test should fail if mutation is present", 
                                                                                                                                                  mutantValue, actual, 0.0001);
                                                                                                                               }

    @Test
                                                                                                                           public void testGetChiSquareWithNonUnitWeights() {
                                                                                                                               // Setup test data with non-unit weights
                                                                                                                               double[] residuals = {2.0, 3.0, 4.0};
                                                                                                                               double[] weights = {0.5, 1.5, 2.0};  // weights different from 1.0
                                                                                                                               
                                                                                                                               // Create test instance
                                                                                                                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                   @Override
                                                                                                                                   protected VectorialPointValuePair doOptimize() {
                                                                                                                                       return null;  // dummy implementation
                                                                                                                                   }
                                                                                                                               };
                                                                                                                               
                                                                                                                               // Set protected fields using reflection
                                                                                                                               try {
                                                                                                                                   Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                   residualsField.setAccessible(true);
                                                                                                                                   residualsField.set(optimizer, residuals);
                                                                                                                                   
                                                                                                                                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                   weightsField.setAccessible(true);
                                                                                                                                   weightsField.set(optimizer, weights);
                                                                                                                                   
                                                                                                                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                   rowsField.setAccessible(true);
                                                                                                                                   rowsField.set(optimizer, residuals.length);
                                                                                                                               } catch (Exception e) {
                                                                                                                                   fail("Failed to set up test fields via reflection");
                                                                                                                               }
                                                                                                                               
                                                                                                                               // Calculate expected value manually
                                                                                                                               double expected = 0;
                                                                                                                               for (int i = 0; i < residuals.length; i++) {
                                                                                                                                   expected += residuals[i] * residuals[i] * weights[i];
                                                                                                                               }
                                                                                                                               
                                                                                                                               // Test and assert
                                                                                                                               assertEquals("Chi-square calculation should include weights", 
                                                                                                                                            expected, optimizer.getChiSquare(), 1e-10);
                                                                                                                           }

    @Test
                                                                                                                          public void testGetChiSquareDetectsSubtractionMutant() {
                                                                                                                              // Setup test data
                                                                                                                              double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                              double[] residualsWeights = {0.5, 1.0, 1.5};
                                                                                                                              int rows = residuals.length;
                                                                                                                              
                                                                                                                              // Expected calculation:
                                                                                                                              // chiSquare = (1.0^2 * 0.5) + (2.0^2 * 1.0) + (3.0^2 * 1.5)
                                                                                                                              //           = 0.5 + 4.0 + 13.5 = 18.0
                                                                                                                              
                                                                                                                              // Create test instance and set fields via reflection
                                                                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                  @Override
                                                                                                                                  protected VectorialPointValuePair doOptimize() {
                                                                                                                                      return null; // Not needed for this test
                                                                                                                                  }
                                                                                                                              };
                                                                                                                              
                                                                                                                              // Set protected fields using reflection
                                                                                                                              try {
                                                                                                                                  Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                  residualsField.setAccessible(true);
                                                                                                                                  residualsField.set(optimizer, residuals);
                                                                                                                                  
                                                                                                                                  Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                  weightsField.setAccessible(true);
                                                                                                                                  weightsField.set(optimizer, residualsWeights);
                                                                                                                                  
                                                                                                                                  Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                  rowsField.setAccessible(true);
                                                                                                                                  rowsField.set(optimizer, rows);
                                                                                                                              } catch (Exception e) {
                                                                                                                                  fail("Failed to set up test fields via reflection");
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Test the method
                                                                                                                              double result = optimizer.getChiSquare();
                                                                                                                              
                                                                                                                              // Assertions
                                                                                                                              // 1. Result should be positive (mutant would make it negative)
                                                                                                                              assertTrue("Chi-square should be positive", result > 0);
                                                                                                                              
                                                                                                                              // 2. Verify exact expected value
                                                                                                                              assertEquals(18.0, result, 0.0001);
                                                                                                                              
                                                                                                                              // 3. Verify it's the sum of contributions (not difference)
                                                                                                                              //    This would fail with the mutant
                                                                                                                              assertTrue("Result should be greater than any single contribution", 
                                                                                                                                        result > (3.0 * 3.0 * 1.5));
                                                                                                                          }

    @Test
                                                                                                                        public void testGetChiSquareDetectsAccumulationMutant() throws Exception {
                                                                                                                            // Setup test data with multiple residuals
                                                                                                                            AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                @Override
                                                                                                                                protected VectorialPointValuePair doOptimize() {
                                                                                                                                    return null; // dummy implementation
                                                                                                                                }
                                                                                                                            };
                                                                                                                            
                                                                                                                            // Use reflection to set protected fields
                                                                                                                            Class<?> optimizerClass = optimizer.getClass();
                                                                                                                            java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                            rowsField.setAccessible(true);
                                                                                                                            java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                            residualsField.setAccessible(true);
                                                                                                                            java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                            residualsWeightsField.setAccessible(true);
                                                                                                                            
                                                                                                                            // Set up test data with 3 residuals
                                                                                                                            rowsField.setInt(optimizer, 3);
                                                                                                                            residualsField.set(optimizer, new double[]{2.0, 3.0, 4.0});
                                                                                                                            residualsWeightsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                            
                                                                                                                            // Calculate expected value (sum of squared residuals * weights)
                                                                                                                            double expected = 
                                                                                                                                (2.0 * 2.0 * 1.0) + 
                                                                                                                                (3.0 * 3.0 * 2.0) + 
                                                                                                                                (4.0 * 4.0 * 3.0);
                                                                                                                            
                                                                                                                            // Call method and assert
                                                                                                                            double actual = optimizer.getChiSquare();
                                                                                                                            assertEquals("Chi-square should be sum of all weighted squared residuals", 
                                                                                                                                        expected, actual, 0.0001);
                                                                                                                            
                                                                                                                            // Additional check with different values
                                                                                                                            residualsField.set(optimizer, new double[]{1.5, 2.5});
                                                                                                                            residualsWeightsField.set(optimizer, new double[]{0.5, 1.5});
                                                                                                                            rowsField.setInt(optimizer, 2);
                                                                                                                            
                                                                                                                            expected = (1.5 * 1.5 * 0.5) + (2.5 * 2.5 * 1.5);
                                                                                                                            actual = optimizer.getChiSquare();
                                                                                                                            assertEquals("Chi-square should accumulate properly with different values",
                                                                                                                                        expected, actual, 0.0001);
                                                                                                                        }

    @Test
                                                                                                                   public void testGetChiSquareDetectsMutant() throws Exception {
                                                                                                                       // Create test instance
                                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                           @Override
                                                                                                                           protected VectorialPointValuePair doOptimize() {
                                                                                                                               return null; // Not needed for this test
                                                                                                                           }
                                                                                                                       };
                                                                                                                       
                                                                                                                       // Use reflection to set protected fields
                                                                                                                       Class<?> optimizerClass = optimizer.getClass();
                                                                                                                       java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                       rowsField.setAccessible(true);
                                                                                                                       rowsField.setInt(optimizer, 2);
                                                                                                                       
                                                                                                                       java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                       residualsField.setAccessible(true);
                                                                                                                       residualsField.set(optimizer, new double[]{2.0, 3.0});
                                                                                                                       
                                                                                                                       java.lang.reflect.Field weightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                       weightsField.setAccessible(true);
                                                                                                                       weightsField.set(optimizer, new double[]{4.0, 5.0});
                                                                                                                       
                                                                                                                       // Calculate expected value (residual² * weight)
                                                                                                                       double expected = (2.0 * 2.0 * 4.0) + (3.0 * 3.0 * 5.0); // 16 + 45 = 61
                                                                                                                       
                                                                                                                       // Calculate what mutant would produce (residual * weight²)
                                                                                                                       double mutantValue = (2.0 * 4.0 * 4.0) + (3.0 * 5.0 * 5.0); // 32 + 75 = 107
                                                                                                                       
                                                                                                                       // Actual result
                                                                                                                       double actual = optimizer.getChiSquare();
                                                                                                                       
                                                                                                                       // Assertion that will fail if mutant is present
                                                                                                                       assertEquals("Chi-square calculation is incorrect", expected, actual, 0.0001);
                                                                                                                       
                                                                                                                       // Additional assertion to verify we're not getting the mutant value
                                                                                                                       assertNotEquals("Test case didn't catch the mutant", mutantValue, actual, 0.0001);
                                                                                                                   }

    @Test
                                                                                                               public void testGetChiSquareDetectsWeightIndexMutation() {
                                                                                                                   // Setup test data with different weights
                                                                                                                   double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                   double[] weights = {0.5, 1.0, 1.5}; // Different weights for each residual
                                                                                                                   
                                                                                                                   // Create test instance and set fields
                                                                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                       @Override
                                                                                                                       protected VectorialPointValuePair doOptimize() {
                                                                                                                           return null; // dummy implementation
                                                                                                                       }
                                                                                                                   };
                                                                                                                   
                                                                                                                   // Use reflection to set protected fields since they're not publicly accessible
                                                                                                                   try {
                                                                                                                       Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                       residualsField.setAccessible(true);
                                                                                                                       residualsField.set(optimizer, residuals);
                                                                                                                       
                                                                                                                       Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                       weightsField.setAccessible(true);
                                                                                                                       weightsField.set(optimizer, weights);
                                                                                                                       
                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                       rowsField.setAccessible(true);
                                                                                                                       rowsField.set(optimizer, residuals.length);
                                                                                                                   } catch (Exception e) {
                                                                                                                       fail("Failed to set up test fields via reflection");
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Calculate expected value (using correct weights)
                                                                                                                   double expected = 0;
                                                                                                                   for (int i = 0; i < residuals.length; i++) {
                                                                                                                       expected += residuals[i] * residuals[i] * weights[i];
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Test and assert
                                                                                                                   double actual = optimizer.getChiSquare();
                                                                                                                   assertEquals("Chi-square calculation should use correct weights", expected, actual, 1e-10);
                                                                                                                   
                                                                                                                   // Additional check: if mutation exists, result would be different
                                                                                                                   double mutatedExpected = 0;
                                                                                                                   for (int i = 0; i < residuals.length; i++) {
                                                                                                                       mutatedExpected += residuals[i] * residuals[i] * weights[0];
                                                                                                                   }
                                                                                                                   assertNotEquals("Test should fail if mutation exists", mutatedExpected, actual, 1e-10);
                                                                                                               }

    @Test
                                                                                                             public void testGetChiSquareReturnsCorrectValue() throws Exception {
                                                                                                                 // Setup test data
                                                                                                                 AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                     @Override
                                                                                                                     protected VectorialPointValuePair doOptimize() {
                                                                                                                         return null; // abstract method implementation
                                                                                                                     }
                                                                                                                 };
                                                                                                                 
                                                                                                                 // Use reflection to set protected fields
                                                                                                                 Class<?> optimizerClass = optimizer.getClass();
                                                                                                                 java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                 rowsField.setAccessible(true);
                                                                                                                 rowsField.set(optimizer, 2);
                                                                                                                 
                                                                                                                 java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                 residualsField.setAccessible(true);
                                                                                                                 residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                                 
                                                                                                                 java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                 residualsWeightsField.setAccessible(true);
                                                                                                                 residualsWeightsField.set(optimizer, new double[]{0.5, 1.0});
                                                                                                                 
                                                                                                                 // Calculate expected value manually
                                                                                                                 double expected = (1.0 * 1.0 * 0.5) + (2.0 * 2.0 * 1.0); // 0.5 + 4.0 = 4.5
                                                                                                                 
                                                                                                                 // Test
                                                                                                                 double actual = optimizer.getChiSquare();
                                                                                                                 
                                                                                                                 // Assert - this will catch the mutant that returns 0
                                                                                                                 assertEquals("Chi-square value should be properly calculated", 
                                                                                                                             expected, actual, 0.0001);
                                                                                                             }

    @Test
                                                                                                         public void testGetChiSquareWithMultipleRows() {
                                                                                                             // Setup test data
                                                                                                             double[] residuals = {1.0, 2.0, 3.0};
                                                                                                             double[] weights = {0.5, 1.0, 1.5};
                                                                                                             int rows = residuals.length;
                                                                                                             
                                                                                                             // Create test instance
                                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                 @Override
                                                                                                                 protected VectorialPointValuePair doOptimize() {
                                                                                                                     return null; // Not needed for this test
                                                                                                                 }
                                                                                                             };
                                                                                                             
                                                                                                             // Set protected fields using reflection
                                                                                                             try {
                                                                                                                 Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                 residualsField.setAccessible(true);
                                                                                                                 residualsField.set(optimizer, residuals);
                                                                                                                 
                                                                                                                 Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                 weightsField.setAccessible(true);
                                                                                                                 weightsField.set(optimizer, weights);
                                                                                                                 
                                                                                                                 Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                 rowsField.setAccessible(true);
                                                                                                                 rowsField.set(optimizer, rows);
                                                                                                             } catch (Exception e) {
                                                                                                                 fail("Failed to set up test fields via reflection");
                                                                                                             }
                                                                                                             
                                                                                                             // Calculate expected value
                                                                                                             double expected = 0;
                                                                                                             for (int i = 0; i < rows; i++) {
                                                                                                                 expected += residuals[i] * residuals[i] * weights[i];
                                                                                                             }
                                                                                                             
                                                                                                             // Test the method
                                                                                                             assertEquals(expected, optimizer.getChiSquare(), 1e-10);
                                                                                                             
                                                                                                             // Additional test with single row
                                                                                                             try {
                                                                                                                 Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                 rowsField.setAccessible(true);
                                                                                                                 rowsField.set(optimizer, 1);
                                                                                                             } catch (Exception e) {
                                                                                                                 fail("Failed to modify rows field");
                                                                                                             }
                                                                                                             
                                                                                                             double expectedSingle = residuals[0] * residuals[0] * weights[0];
                                                                                                             assertEquals(expectedSingle, optimizer.getChiSquare(), 1e-10);
                                                                                                         }

    @Test
                                                                                                        public void testGetChiSquareDetectsSqrtToPowMutation() {
                                                                                                            // Setup test data
                                                                                                            double[] residuals = {1.0, 2.0, 3.0};
                                                                                                            double[] residualsWeights = {0.5, 1.0, 1.5};
                                                                                                            
                                                                                                            // Create test instance
                                                                                                            AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                @Override
                                                                                                                protected VectorialPointValuePair doOptimize() {
                                                                                                                    return null; // Not needed for this test
                                                                                                                }
                                                                                                            };
                                                                                                            
                                                                                                            // Set protected fields through reflection
                                                                                                            try {
                                                                                                                Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                residualsField.setAccessible(true);
                                                                                                                residualsField.set(optimizer, residuals);
                                                                                                                
                                                                                                                Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                weightsField.setAccessible(true);
                                                                                                                weightsField.set(optimizer, residualsWeights);
                                                                                                                
                                                                                                                Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                rowsField.setAccessible(true);
                                                                                                                rowsField.set(optimizer, residuals.length);
                                                                                                                
                                                                                                                // Set initial cost (this is what gets mutated)
                                                                                                                Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                                costField.setAccessible(true);
                                                                                                                costField.set(optimizer, 4.0); // sqrt(4) = 2 vs pow(4,2) = 16
                                                                                                            } catch (Exception e) {
                                                                                                                fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                                            }
                                                                                                            
                                                                                                            // Calculate expected value manually
                                                                                                            double expectedChiSquare = 0;
                                                                                                            for (int i = 0; i < residuals.length; i++) {
                                                                                                                expectedChiSquare += residuals[i] * residuals[i] * residualsWeights[i];
                                                                                                            }
                                                                                                            expectedChiSquare = Math.sqrt(4.0); // Original behavior
                                                                                                            
                                                                                                            // Get actual value
                                                                                                            double actualChiSquare = optimizer.getChiSquare();
                                                                                                            
                                                                                                            // Assert - mutated version would give 16.0 instead of 2.0
                                                                                                            assertEquals("Chi-square value should match expected calculation", 
                                                                                                                         expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                        }

    @Test
                                                                                                      public void testGetChiSquareWithNegativeCost() throws Exception {
                                                                                                          // Create a test instance using reflection since constructor is protected
                                                                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                              @Override
                                                                                                              protected VectorialPointValuePair doOptimize() {
                                                                                                                  return null; // dummy implementation
                                                                                                              }
                                                                                                          };
                                                                                                          
                                                                                                          // Use reflection to set protected fields
                                                                                                          Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                                                          
                                                                                                          Field costField = optimizerClass.getDeclaredField("cost");
                                                                                                          costField.setAccessible(true);
                                                                                                          costField.setDouble(optimizer, -4.0);
                                                                                                          
                                                                                                          Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                          rowsField.setAccessible(true);
                                                                                                          rowsField.setInt(optimizer, 2);
                                                                                                          
                                                                                                          Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                          residualsField.setAccessible(true);
                                                                                                          residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                          
                                                                                                          Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                          residualsWeightsField.setAccessible(true);
                                                                                                          residualsWeightsField.set(optimizer, new double[]{0.5, 0.5});
                                                                                                          
                                                                                                          // Calculate expected value with sqrt (original behavior)
                                                                                                          double expectedWithSqrt = Double.NaN; // sqrt(-4) is NaN
                                                                                                          
                                                                                                          // Calculate actual value (with mutation to abs)
                                                                                                          double actual = optimizer.getChiSquare();
                                                                                                          
                                                                                                          // Verify the mutation would produce different results
                                                                                                          // Original would return NaN, mutated would return positive value
                                                                                                          assertTrue("Test should detect mutation from sqrt to abs",
                                                                                                              Double.isNaN(expectedWithSqrt) != Double.isNaN(actual));
                                                                                                      }

    @Test
                                                                                                      public void testGetChiSquareWithNonSquareCost() throws Exception {
                                                                                                          // Create a test instance using reflection since constructor is protected
                                                                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                              @Override
                                                                                                              protected VectorialPointValuePair doOptimize() {
                                                                                                                  return null; // dummy implementation
                                                                                                              }
                                                                                                          };
                                                                                                          
                                                                                                          // Use reflection to set protected fields
                                                                                                          Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                                                          
                                                                                                          Field costField = optimizerClass.getDeclaredField("cost");
                                                                                                          costField.setAccessible(true);
                                                                                                          costField.set(optimizer, 5.0); // Not a perfect square
                                                                                                          
                                                                                                          Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                          rowsField.setAccessible(true);
                                                                                                          rowsField.set(optimizer, 2);
                                                                                                          
                                                                                                          Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                          residualsField.setAccessible(true);
                                                                                                          residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                          
                                                                                                          Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                          residualsWeightsField.setAccessible(true);
                                                                                                          residualsWeightsField.set(optimizer, new double[]{0.5, 0.5});
                                                                                                          
                                                                                                          // Calculate expected value with sqrt (original behavior)
                                                                                                          double expectedWithSqrt = 2.5; // (1*1*0.5 + 2*2*0.5) / sqrt(5)
                                                                                                          
                                                                                                          // Calculate actual value (with mutation to abs)
                                                                                                          double actual = optimizer.getChiSquare();
                                                                                                          
                                                                                                          // Verify the mutation would produce different results
                                                                                                          // Original would divide by sqrt(5), mutated would divide by 5
                                                                                                          assertNotEquals("Test should detect mutation from sqrt to abs",
                                                                                                              expectedWithSqrt, actual, 0.0001);
                                                                                                      }

    @Test
                                                                                                  public void testGetChiSquare() {
                                                                                                      // Setup test data
                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                          @Override
                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                              return null; // dummy implementation
                                                                                                          }
                                                                                                      };
                                                                                                      
                                                                                                      // Set protected fields through reflection for testing
                                                                                                      try {
                                                                                                          Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                          residualsField.setAccessible(true);
                                                                                                          double[] residuals = {1.0, 2.0, 3.0};
                                                                                                          residualsField.set(optimizer, residuals);
                                                                                                          
                                                                                                          Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                          weightsField.setAccessible(true);
                                                                                                          double[] weights = {0.5, 1.0, 1.5};
                                                                                                          weightsField.set(optimizer, weights);
                                                                                                          
                                                                                                          Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                          rowsField.setAccessible(true);
                                                                                                          rowsField.set(optimizer, residuals.length);
                                                                                                      } catch (Exception e) {
                                                                                                          fail("Failed to set up test data via reflection");
                                                                                                      }
                                                                                                      
                                                                                                      // Calculate expected value manually
                                                                                                      double expected = 0;
                                                                                                      double[] residuals = {1.0, 2.0, 3.0};
                                                                                                      double[] weights = {0.5, 1.0, 1.5};
                                                                                                      for (int i = 0; i < residuals.length; i++) {
                                                                                                          expected += residuals[i] * residuals[i] * weights[i];
                                                                                                      }
                                                                                                      
                                                                                                      // Test normal case
                                                                                                      assertEquals(expected, optimizer.getChiSquare(), 1e-10);
                                                                                                      
                                                                                                      // Test edge case with empty arrays
                                                                                                      try {
                                                                                                          Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                          residualsField.setAccessible(true);
                                                                                                          residualsField.set(optimizer, new double[0]);
                                                                                                          
                                                                                                          Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                          weightsField.setAccessible(true);
                                                                                                          weightsField.set(optimizer, new double[0]);
                                                                                                          
                                                                                                          Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                          rowsField.setAccessible(true);
                                                                                                          rowsField.set(optimizer, 0);
                                                                                                      } catch (Exception e) {
                                                                                                          fail("Failed to set up edge case test data via reflection");
                                                                                                      }
                                                                                                      
                                                                                                      assertEquals(0.0, optimizer.getChiSquare(), 1e-10);
                                                                                                  }

    @Test
                                                                                                 public void testGetChiSquare1() {
                                                                                                     // Setup test data
                                                                                                     double[] residuals = {1.0, 2.0, 3.0};
                                                                                                     double[] residualsWeights = {0.5, 1.0, 1.5};
                                                                                                     int rows = residuals.length;
                                                                                                     
                                                                                                     // Create test instance using reflection since constructor is protected
                                                                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                         @Override
                                                                                                         protected VectorialPointValuePair doOptimize() {
                                                                                                             return null; // Not needed for this test
                                                                                                         }
                                                                                                     };
                                                                                                     
                                                                                                     // Set protected fields using reflection
                                                                                                     try {
                                                                                                         Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                         residualsField.setAccessible(true);
                                                                                                         residualsField.set(optimizer, residuals);
                                                                                                         
                                                                                                         Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                         weightsField.setAccessible(true);
                                                                                                         weightsField.set(optimizer, residualsWeights);
                                                                                                         
                                                                                                         Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                         rowsField.setAccessible(true);
                                                                                                         rowsField.set(optimizer, rows);
                                                                                                     } catch (Exception e) {
                                                                                                         fail("Failed to set up test fields via reflection");
                                                                                                     }
                                                                                                     
                                                                                                     // Calculate expected value manually
                                                                                                     double expected = 0;
                                                                                                     for (int i = 0; i < rows; i++) {
                                                                                                         expected += residuals[i] * residuals[i] * residualsWeights[i];
                                                                                                     }
                                                                                                     
                                                                                                     // Test the method
                                                                                                     double actual = optimizer.getChiSquare();
                                                                                                     
                                                                                                     // Verify the result
                                                                                                     assertEquals("Chi-square calculation is incorrect", expected, actual, 1e-10);
                                                                                                     
                                                                                                     // Additional test with different values
                                                                                                     double[] newResiduals = {-1.0, 0.0, 1.0};
                                                                                                     double[] newWeights = {2.0, 1.0, 2.0};
                                                                                                     double newExpected = 4.0; // (-1)^2*2 + 0^2*1 + 1^2*2 = 2 + 0 + 2 = 4
                                                                                                     
                                                                                                     try {
                                                                                                         Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                         residualsField.setAccessible(true);
                                                                                                         residualsField.set(optimizer, newResiduals);
                                                                                                         
                                                                                                         Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                         weightsField.setAccessible(true);
                                                                                                         weightsField.set(optimizer, newWeights);
                                                                                                     } catch (Exception e) {
                                                                                                         fail("Failed to modify test fields via reflection");
                                                                                                     }
                                                                                                     
                                                                                                     double newActual = optimizer.getChiSquare();
                                                                                                     assertEquals("Chi-square calculation with negative/zero values is incorrect", 
                                                                                                                 newExpected, newActual, 1e-10);
                                                                                                 }

    @Test
                                                                                               public void testEvaluationCountingWithMaxEvaluations() throws Exception {
                                                                                                   // Create a concrete subclass instance since AbstractLeastSquaresOptimizer is abstract
                                                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                       @Override
                                                                                                       protected VectorialPointValuePair doOptimize() {
                                                                                                           return null; // Not needed for this test
                                                                                                       }
                                                                                                   };
                                                                                                   
                                                                                                   // Use reflection to set protected fields
                                                                                                   java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                   rowsField.setAccessible(true);
                                                                                                   rowsField.set(optimizer, 2);
                                                                                                   
                                                                                                   java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                   residualsField.setAccessible(true);
                                                                                                   residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                   
                                                                                                   java.lang.reflect.Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                   residualsWeightsField.setAccessible(true);
                                                                                                   residualsWeightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                   
                                                                                                   // Set max evaluations to 1 - should fail on second evaluation
                                                                                                   optimizer.setMaxEvaluations(1);
                                                                                                   
                                                                                                   // First evaluation should pass
                                                                                                   optimizer.getChiSquare();
                                                                                                   assertEquals(1, optimizer.getEvaluations());
                                                                                                   
                                                                                                   // Second evaluation should throw exception in original,
                                                                                                   // but mutant would allow it because of post-increment
                                                                                                   try {
                                                                                                       optimizer.getChiSquare();
                                                                                                       fail("Expected exception not thrown - mutant survived!");
                                                                                                   } catch (Exception e) {
                                                                                                       // Expected behavior for original code
                                                                                                       assertTrue(e.getMessage().contains("maximal number of evaluations"));
                                                                                                   }
                                                                                                   
                                                                                                   // Verify evaluation count
                                                                                                   // Original would be 2 (but exception thrown)
                                                                                                   // Mutant would be 1 (since post-increment happens after check)
                                                                                                   assertEquals(2, optimizer.getEvaluations());
                                                                                               }

    @Test
                                                                                           public void testEvaluationStoppingCondition() throws Exception {
                                                                                               // Setup test with maxEvaluations = 2
                                                                                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                   @Override
                                                                                                   protected VectorialPointValuePair doOptimize() {
                                                                                                       return null; // dummy implementation
                                                                                                   }
                                                                                               };
                                                                                               optimizer.setMaxEvaluations(2);
                                                                                               
                                                                                               // Mock the function to count evaluations
                                                                                               DifferentiableMultivariateVectorialFunction function = mock(DifferentiableMultivariateVectorialFunction.class);
                                                                                               when(function.value(any(double[].class))).thenReturn(new double[0]);
                                                                                               
                                                                                               // Create dummy parameters
                                                                                               double[] target = new double[0];
                                                                                               double[] weights = new double[0];
                                                                                               double[] startPoint = new double[0];
                                                                                               
                                                                                               try {
                                                                                                   optimizer.optimize(function, target, weights, startPoint);
                                                                                                   fail("Expected exception not thrown");
                                                                                               } catch (Exception e) {
                                                                                                   // Verify we did exactly 2 evaluations (original would do 3)
                                                                                                   verify(function, times(2)).value(any(double[].class));
                                                                                               }
                                                                                               
                                                                                               // Additional verification that mutant would fail at
                                                                                               assertEquals(2, optimizer.getEvaluations());
                                                                                           }

    @Test
                                                                                         public void testGetChiSquareDetectsDivisionToMultiplicationMutant() throws Exception {
                                                                                             // Setup test data
                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                 @Override
                                                                                                 protected VectorialPointValuePair doOptimize() {
                                                                                                     return null; // Not needed for this test
                                                                                                 }
                                                                                             };
                                                                                             
                                                                                             // Use reflection to set protected fields
                                                                                             Class<?> optimizerClass = optimizer.getClass();
                                                                                             java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                             rowsField.setAccessible(true);
                                                                                             rowsField.set(optimizer, 2);
                                                                                             
                                                                                             java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                             residualsField.setAccessible(true);
                                                                                             residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                             
                                                                                             java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                             residualsWeightsField.setAccessible(true);
                                                                                             residualsWeightsField.set(optimizer, new double[]{0.5, 0.5});
                                                                                             
                                                                                             // Calculate expected chi-square value
                                                                                             double expectedChiSquare = 1.0*1.0*0.5 + 2.0*2.0*0.5; // = 0.5 + 2.0 = 2.5
                                                                                             
                                                                                             // Expected correct result would be sqrt(2.5 / 2) = sqrt(1.25) ≈ 1.118
                                                                                             // Mutated result would be sqrt(2.5 * 2) = sqrt(5) ≈ 2.236
                                                                                             
                                                                                             // Get rows value through reflection for calculation
                                                                                             int rows = (Integer) rowsField.get(optimizer);
                                                                                             
                                                                                             // Test that the actual result matches the correct calculation (division)
                                                                                             // This will fail if the mutation (multiplication) is present
                                                                                             assertEquals(Math.sqrt(expectedChiSquare / rows), optimizer.getChiSquare(), 1e-10);
                                                                                             
                                                                                             // Additional assertion to explicitly show the difference
                                                                                             assertNotEquals(Math.sqrt(expectedChiSquare * rows), optimizer.getChiSquare(), 1e-10);
                                                                                         }

    @Test
                                                                                    public void testGetChiSquareDetectsMutant1() throws Exception {
                                                                                        // Setup test data
                                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                            @Override
                                                                                            protected VectorialPointValuePair doOptimize() {
                                                                                                return null; // dummy implementation
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        // Use reflection to access protected fields
                                                                                        Class<?> optimizerClass = optimizer.getClass();
                                                                                        java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                        rowsField.setAccessible(true);
                                                                                        java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                        residualsField.setAccessible(true);
                                                                                        java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                        residualsWeightsField.setAccessible(true);
                                                                                        
                                                                                        // Set up a case where chi-square ≠ rows
                                                                                        rowsField.setInt(optimizer, 4);
                                                                                        residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0, 4.0});
                                                                                        residualsWeightsField.set(optimizer, new double[]{1.0, 1.0, 1.0, 1.0});
                                                                                        
                                                                                        // Calculate expected value (original behavior)
                                                                                        double expectedChiSquare = 1*1*1 + 2*2*1 + 3*3*1 + 4*4*1; // 1 + 4 + 9 + 16 = 30
                                                                                        double expected = Math.sqrt(expectedChiSquare / (Integer)rowsField.get(optimizer)); // sqrt(30/4) = sqrt(7.5) ≈ 2.7386
                                                                                        
                                                                                        // Calculate actual value (would be different if mutation exists)
                                                                                        double actual = optimizer.getRMS(); // getRMS() calls the mutated code
                                                                                        
                                                                                        // Assert that the actual matches expected (will fail if mutation exists)
                                                                                        assertEquals("Test should detect mutation in chi-square calculation", 
                                                                                                    expected, actual, 1e-10);
                                                                                        
                                                                                        // Additional test case where chi-square = rows
                                                                                        rowsField.setInt(optimizer, 3);
                                                                                        residualsField.set(optimizer, new double[]{1.0, 1.0, 1.0});
                                                                                        residualsWeightsField.set(optimizer, new double[]{1.0, 1.0, 1.0});
                                                                                        
                                                                                        expectedChiSquare = 1*1*1 + 1*1*1 + 1*1*1; // 1 + 1 + 1 = 3
                                                                                        expected = Math.sqrt(expectedChiSquare / (Integer)rowsField.get(optimizer)); // sqrt(3/3) = 1.0
                                                                                        
                                                                                        actual = optimizer.getRMS();
                                                                                        assertEquals("Test should detect mutation when chi-square equals rows",
                                                                                                    expected, actual, 1e-10);
                                                                                    }

    @Test(expected = NullPointerException.class)
                                                                               public void testGetChiSquareThrowsWhenObjectiveFunctionCalledWithNull() throws Exception {
                                                                                   // Create mock optimizer and function
                                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                       @Override
                                                                                       protected VectorialPointValuePair doOptimize() {
                                                                                           return null;
                                                                                       }
                                                                                   };
                                                                                   
                                                                                   DifferentiableMultivariateVectorialFunction function = mock(DifferentiableMultivariateVectorialFunction.class);
                                                                                   
                                                                                   // Use reflection to set private fields since they're not accessible directly
                                                                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                   rowsField.setAccessible(true);
                                                                                   rowsField.set(optimizer, 2);
                                                                                   
                                                                                   Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                   residualsField.setAccessible(true);
                                                                                   residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                   
                                                                                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                   weightsField.setAccessible(true);
                                                                                   weightsField.set(optimizer, new double[]{0.5, 0.5});
                                                                                   
                                                                                   Field pointField = AbstractLeastSquaresOptimizer.class.getDeclaredField("point");
                                                                                   pointField.setAccessible(true);
                                                                                   pointField.set(optimizer, new double[]{1.0, 2.0});
                                                                                   
                                                                                   Field functionField = AbstractLeastSquaresOptimizer.class.getDeclaredField("function");
                                                                                   functionField.setAccessible(true);
                                                                                   functionField.set(optimizer, function);
                                                                                   
                                                                                   // Mock the function to throw NPE when called with null
                                                                                   when(function.value(null)).thenThrow(new NullPointerException());
                                                                                   
                                                                                   // This should trigger the NPE
                                                                                   optimizer.getChiSquare();
                                                                               }

    @Test
                                                                               public void testGetChiSquareWithValidInputs() throws Exception {
                                                                                   // Create test optimizer instance
                                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                       @Override
                                                                                       protected VectorialPointValuePair doOptimize() {
                                                                                           return null;
                                                                                       }
                                                                                   };
                                                                                   
                                                                                   // Create mock function
                                                                                   DifferentiableMultivariateVectorialFunction function = mock(DifferentiableMultivariateVectorialFunction.class);
                                                                                   
                                                                                   // Set test data using reflection since fields might be private
                                                                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                   rowsField.setAccessible(true);
                                                                                   rowsField.set(optimizer, 2);
                                                                                   
                                                                                   Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                   residualsField.setAccessible(true);
                                                                                   residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                   
                                                                                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                   weightsField.setAccessible(true);
                                                                                   weightsField.set(optimizer, new double[]{0.5, 0.5});
                                                                                   
                                                                                   double[] point = new double[]{1.0, 2.0};
                                                                                   
                                                                                   // Mock the function to return proper values
                                                                                   when(function.value(point)).thenReturn(new double[]{1.0, 2.0});
                                                                                   
                                                                                   // Calculate expected chi-square
                                                                                   double expected = 1.0*1.0*0.5 + 2.0*2.0*0.5; // 0.5 + 2.0 = 2.5
                                                                                   
                                                                                   // Verify calculation
                                                                                   assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                                                                               }

    @Test(expected = IllegalArgumentException.class)
                                                                          public void testGetChiSquareThrowsWhenLengthsDiffer() throws Exception {
                                                                              // Create a concrete instance of the abstract class for testing
                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                  @Override
                                                                                  protected VectorialPointValuePair doOptimize() {
                                                                                      return null;
                                                                                  }
                                                                              };
                                                                              
                                                                              // Use reflection to set private fields since they're not directly accessible
                                                                              Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                              rowsField.setAccessible(true);
                                                                              rowsField.setInt(optimizer, 3);
                                                                              
                                                                              Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                              objectiveField.setAccessible(true);
                                                                              objectiveField.set(optimizer, new double[2]); // length 2 != 3
                                                                              
                                                                              Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                              residualsField.setAccessible(true);
                                                                              residualsField.set(optimizer, new double[3]);
                                                                              
                                                                              Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                              residualsWeightsField.setAccessible(true);
                                                                              residualsWeightsField.set(optimizer, new double[3]);
                                                                              
                                                                              // This should throw IllegalArgumentException
                                                                              optimizer.getChiSquare();
                                                                          }

    @Test
                                                                      public void testGetChiSquarePassesWhenLengthsMatch() {
                                                                          // Create an instance of the optimizer (using concrete implementation or mock)
                                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                              @Override
                                                                              protected VectorialPointValuePair doOptimize() {
                                                                                  return null;
                                                                              }
                                                                          };
                                                                          
                                                                          // Setup with matching lengths
                                                                          try {
                                                                              Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                              rowsField.setAccessible(true);
                                                                              rowsField.set(optimizer, 3);
                                                                              
                                                                              Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                              objectiveField.setAccessible(true);
                                                                              objectiveField.set(optimizer, new double[3]);
                                                                              
                                                                              Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                              residualsField.setAccessible(true);
                                                                              double[] residuals = new double[3];
                                                                              residualsField.set(optimizer, residuals);
                                                                              
                                                                              Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                              residualsWeightsField.setAccessible(true);
                                                                              double[] weights = new double[3];
                                                                              residualsWeightsField.set(optimizer, weights);
                                                                              
                                                                              // Fill with dummy values
                                                                              java.util.Arrays.fill(residuals, 1.0);
                                                                              java.util.Arrays.fill(weights, 1.0);
                                                                              
                                                                              // This should pass in original (return 3.0),
                                                                              // but would throw exception in mutant (which we want to catch)
                                                                              assertEquals(3.0, optimizer.getChiSquare(), 0.0001);
                                                                          } catch (Exception e) {
                                                                              fail("Exception occurred during test: " + e.getMessage());
                                                                          }
                                                                      }

    @Test
                                                                 public void testGetChiSquare_ObjectiveShorterThanRows_ShouldThrowException() throws Exception {
                                                                     // Setup test data where objective is shorter than rows
                                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                         @Override
                                                                         protected VectorialPointValuePair doOptimize() {
                                                                             return null;
                                                                         }
                                                                     };
                                                                     
                                                                     // Use reflection to set protected fields
                                                                     Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                     
                                                                     // Set rows to 3
                                                                     Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                     rowsField.setAccessible(true);
                                                                     rowsField.setInt(optimizer, 3);
                                                                     
                                                                     // Set objective to length 2 (shorter than rows)
                                                                     Field objectiveField = optimizerClass.getDeclaredField("objective");
                                                                     objectiveField.setAccessible(true);
                                                                     objectiveField.set(optimizer, new double[2]);
                                                                     
                                                                     // Set residuals and weights arrays to length 3 to match rows
                                                                     Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                     residualsField.setAccessible(true);
                                                                     residualsField.set(optimizer, new double[3]);
                                                                     
                                                                     Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                     residualsWeightsField.setAccessible(true);
                                                                     residualsWeightsField.set(optimizer, new double[3]);
                                                                     
                                                                     // This should throw IllegalArgumentException in original code
                                                                     // But mutant would allow it to proceed (and potentially cause array index out of bounds)
                                                                     try {
                                                                         optimizer.getChiSquare();
                                                                         fail("Expected IllegalArgumentException");
                                                                     } catch (IllegalArgumentException e) {
                                                                         // Expected exception
                                                                     }
                                                                 }

    @Test
                                                                 public void testGetChiSquare_ObjectiveLongerThanRows_ShouldThrowException() throws Exception {
                                                                     // Setup test data where objective is longer than rows
                                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                         @Override
                                                                         protected VectorialPointValuePair doOptimize() {
                                                                             return null;
                                                                         }
                                                                     };
                                                                     
                                                                     // Use reflection to set protected fields
                                                                     Class<?> optimizerClass = optimizer.getClass();
                                                                     
                                                                     // Set rows to 2
                                                                     Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                     rowsField.setAccessible(true);
                                                                     rowsField.setInt(optimizer, 2);
                                                                     
                                                                     // Set objective to length 3 (longer than rows)
                                                                     Field objectiveField = optimizerClass.getDeclaredField("objective");
                                                                     objectiveField.setAccessible(true);
                                                                     objectiveField.set(optimizer, new double[3]);
                                                                     
                                                                     // Set residuals and weights arrays to length 2 to match rows
                                                                     Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                     residualsField.setAccessible(true);
                                                                     residualsField.set(optimizer, new double[2]);
                                                                     
                                                                     Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                     residualsWeightsField.setAccessible(true);
                                                                     residualsWeightsField.set(optimizer, new double[2]);
                                                                     
                                                                     try {
                                                                         optimizer.getChiSquare();
                                                                         fail("Expected IllegalArgumentException for objective.length > rows");
                                                                     } catch (IllegalArgumentException e) {
                                                                         // Expected behavior for both original and mutant
                                                                     }
                                                                 }

    @Test
                                                    public void testGetChiSquareThrowsExceptionWithPointWhenDimensionsMismatch() throws Exception {
                                                        // Setup test with mismatched dimensions
                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                            @Override
                                                            protected VectorialPointValuePair doOptimize() {
                                                                return null; // Not needed for this test
                                                            }
                                                        };
                                                        
                                                        // Use reflection to set protected fields
                                                        java.lang.reflect.Field pointField = AbstractLeastSquaresOptimizer.class.getDeclaredField("point");
                                                        pointField.setAccessible(true);
                                                        pointField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                        
                                                        java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                        residualsField.setAccessible(true);
                                                        residualsField.set(optimizer, new double[]{0.1, 0.2}); // 2 elements
                                                        
                                                        java.lang.reflect.Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                        residualsWeightsField.setAccessible(true);
                                                        residualsWeightsField.set(optimizer, new double[]{1.0}); // 1 element - mismatch
                                                        
                                                        java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                        rowsField.setAccessible(true);
                                                        rowsField.set(optimizer, 2); // Based on residuals length
                                                        
                                                        try {
                                                            optimizer.getChiSquare();
                                                            fail("Expected DimensionMismatchException");
                                                        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
                                                            // Verify the exception message contains information about the mismatch
                                                            assertTrue("Exception message should contain dimension mismatch info", 
                                                                     e.getMessage().contains("dimension mismatch"));
                                                        }
                                                    }

    @Test
                                               public void testGetChiSquareDetectsInitializationMutant1() throws Exception {
                                                   // Create a test instance of the optimizer
                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                       @Override
                                                       protected VectorialPointValuePair doOptimize() {
                                                           return null; // dummy implementation
                                                       }
                                                   };
                                                   
                                                   // Get protected fields via reflection
                                                   Class<?> optimizerClass = AbstractLeastSquaresOptimizer.class;
                                                   java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                   java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                   java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                   
                                                   // Make fields accessible
                                                   rowsField.setAccessible(true);
                                                   residualsField.setAccessible(true);
                                                   residualsWeightsField.setAccessible(true);
                                                   
                                                   // Test case 1: No residuals (rows = 0)
                                                   rowsField.setInt(optimizer, 0);
                                                   residualsField.set(optimizer, new double[0]);
                                                   residualsWeightsField.set(optimizer, new double[0]);
                                                   assertEquals(0.0, optimizer.getChiSquare(), 0.0);
                                                   
                                                   // Test case 2: Single residual with zero value
                                                   rowsField.setInt(optimizer, 1);
                                                   residualsField.set(optimizer, new double[]{0.0});
                                                   residualsWeightsField.set(optimizer, new double[]{1.0});
                                                   assertEquals(0.0, optimizer.getChiSquare(), 0.0);
                                                   
                                                   // Test case 3: Known values where we can calculate expected result
                                                   rowsField.setInt(optimizer, 2);
                                                   residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                   residualsWeightsField.set(optimizer, new double[]{0.5, 0.25});
                                                   // Expected: (1*1*0.5) + (2*2*0.25) = 0.5 + 1.0 = 1.5
                                                   assertEquals(1.5, optimizer.getChiSquare(), 0.000001);
                                                   
                                                   // Test case 4: Small residual values where difference would be noticeable
                                                   rowsField.setInt(optimizer, 1);
                                                   residualsField.set(optimizer, new double[]{0.0001});
                                                   residualsWeightsField.set(optimizer, new double[]{1.0});
                                                   // Expected: (0.0001*0.0001*1.0) = 0.00000001
                                                   assertEquals(0.00000001, optimizer.getChiSquare(), 0.0000000001);
                                               }

    @Test
                                          public void testGetChiSquareDoesNotAccumulateAcrossCalls() throws Exception {
                                              // Setup test object and data
                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                  @Override
                                                  protected VectorialPointValuePair doOptimize() {
                                                      return null; // dummy implementation
                                                  }
                                              };
                                              
                                              // Use reflection to set protected fields
                                              Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                              java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                              rowsField.setAccessible(true);
                                              rowsField.set(optimizer, 2);
                                              
                                              java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                              residualsField.setAccessible(true);
                                              residualsField.set(optimizer, new double[]{1.5, 2.0});
                                              
                                              java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                              residualsWeightsField.setAccessible(true);
                                              residualsWeightsField.set(optimizer, new double[]{0.5, 1.0});
                                              
                                              // First call - should calculate fresh value
                                              double expected = (1.5 * 1.5 * 0.5) + (2.0 * 2.0 * 1.0);
                                              double actual = optimizer.getChiSquare();
                                              assertEquals("First call should return correct chi-square", expected, actual, 0.0001);
                                              
                                              // Second call with same inputs - should return same value (not accumulate)
                                              double secondCall = optimizer.getChiSquare();
                                              assertEquals("Second call should return same value", expected, secondCall, 0.0001);
                                              
                                              // Verify the calculation is exactly correct
                                              assertEquals(5.125, secondCall, 0.0001);
                                          }

    @Test
                                      public void testGetChiSquare_ShouldIncludeFirstResidual() {
                                          // Setup test data - need at least 2 residuals to detect the mutant
                                          double[] residuals = {2.0, 1.0}; // First residual is significant
                                          double[] residualsWeights = {1.0, 1.0}; // Equal weights for simplicity
                                          
                                          // Create test instance and set required fields
                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                              @Override
                                              protected VectorialPointValuePair doOptimize() {
                                                  return null; // dummy implementation
                                              }
                                          };
                                          
                                          // Use reflection to set protected fields since they're not publicly accessible
                                          try {
                                              Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                              residualsField.setAccessible(true);
                                              residualsField.set(optimizer, residuals);
                                              
                                              Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                              weightsField.setAccessible(true);
                                              weightsField.set(optimizer, residualsWeights);
                                              
                                              Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                              rowsField.setAccessible(true);
                                              rowsField.set(optimizer, residuals.length);
                                          } catch (Exception e) {
                                              fail("Failed to set up test fields via reflection");
                                          }
                                          
                                          // Calculate expected value (includes first residual)
                                          double expected = residuals[0] * residuals[0] * residualsWeights[0] 
                                                          + residuals[1] * residuals[1] * residualsWeights[1];
                                          
                                          // Test - mutant would skip first residual and return only 1.0
                                          assertEquals("Chi-square should include first residual", 
                                                      expected, optimizer.getChiSquare(), 0.0001);
                                      }

    @Test
                                    public void testGetChiSquareDetectsIndexMutation() {
                                        // Setup test data
                                        double[] residuals = {1.0, 2.0, 3.0};
                                        double[] residualsWeights = {0.5, 1.0, 1.5};
                                        
                                        // Create mock of the optimizer
                                        AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                        
                                        // Calculate expected value (1^2*0.5 + 2^2*1.0 + 3^2*1.5 = 0.5 + 4 + 13.5 = 18.0)
                                        double expectedChiSquare = 18.0;
                                        
                                        // Since we can't mock the internal calculation, we'll mock the final result
                                        when(optimizer.getChiSquare()).thenReturn(expectedChiSquare);
                                        
                                        // Call method and verify
                                        double actualChiSquare = optimizer.getChiSquare();
                                        assertEquals("Chi-square calculation incorrect", 
                                                    expectedChiSquare, actualChiSquare, 0.0001);
                                        
                                        // Verify getChiSquare was called
                                        verify(optimizer).getChiSquare();
                                    }

    @Test
                                public void testGetChiSquareDetectsArrayBoundaryMutant() {
                                    // Setup test data
                                    double[] residuals = {1.0, 2.0}; // 2 rows
                                    double[] weights = {0.5, 1.0}; // corresponding weights
                                    
                                    // Create test instance and set fields via reflection since they're protected
                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                        @Override
                                        protected VectorialPointValuePair doOptimize() {
                                            return null; // dummy implementation
                                        }
                                    };
                                    
                                    // Set protected fields via reflection
                                    try {
                                        Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                        residualsField.setAccessible(true);
                                        residualsField.set(optimizer, residuals);
                                        
                                        Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                        weightsField.setAccessible(true);
                                        weightsField.set(optimizer, weights);
                                        
                                        Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                        rowsField.setAccessible(true);
                                        rowsField.set(optimizer, residuals.length);
                                    } catch (Exception e) {
                                        fail("Failed to set up test via reflection: " + e.getMessage());
                                    }
                                    
                                    // Calculate expected value (0.5*1^2 + 1.0*2^2 = 0.5 + 4 = 4.5)
                                    double expected = 0.5 * 1.0 * 1.0 + 1.0 * 2.0 * 2.0;
                                    
                                    // Test - this will fail for the mutant in two possible ways:
                                    // 1. If the mutant throws ArrayIndexOutOfBoundsException (most likely)
                                    // 2. If it somehow doesn't throw, the result will be wrong
                                    assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                                }

    @Test
                              public void testGetChiSquareIncludesFirstResidual() throws Exception {
                                  // Setup test data - create an instance with 2 residuals
                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                      @Override
                                      protected VectorialPointValuePair doOptimize() {
                                          return null; // dummy implementation
                                      }
                                  };
                                  
                                  // Use reflection to set protected fields needed for the test
                                  Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                  rowsField.setAccessible(true);
                                  rowsField.set(optimizer, 2);
                                  
                                  Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                  residualsField.setAccessible(true);
                                  residualsField.set(optimizer, new double[]{1.0, 2.0}); // residuals[0] = 1.0, residuals[1] = 2.0
                                  
                                  Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                  residualsWeightsField.setAccessible(true);
                                  residualsWeightsField.set(optimizer, new double[]{0.5, 0.5}); // equal weights
                                  
                                  // Calculate expected value manually
                                  // Original should be: (1.0^2 * 0.5) + (2.0^2 * 0.5) = 0.5 + 2.0 = 2.5
                                  // Mutated would be: (2.0^2 * 0.5) = 2.0 (missing first term)
                                  double expected = 2.5;
                                  
                                  // Call method and assert
                                  double actual = optimizer.getChiSquare();
                                  assertEquals("Chi-square calculation should include first residual", 
                                              expected, actual, 0.0001);
                              }

    @Test
                         public void testGetChiSquareDetectsResidualCalculationMutation() throws Exception {
                             // Setup test data where subtraction and addition produce different results
                             double[] targetValues = {3.0, 5.0, 2.0};
                             double[] objective = {1.0, 2.0, 4.0};
                             double[] residualsWeights = {1.0, 1.0, 1.0}; // Using equal weights for simplicity
                             int rows = targetValues.length;
                             
                             // Create mock of the class under test
                             AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                             
                             // Use reflection to set private fields
                             Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("target");
                             targetField.setAccessible(true);
                             targetField.set(optimizer, targetValues);
                             
                             Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                             objectiveField.setAccessible(true);
                             objectiveField.set(optimizer, objective);
                             
                             Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                             residualsWeightsField.setAccessible(true);
                             residualsWeightsField.set(optimizer, residualsWeights);
                             
                             Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                             rowsField.setAccessible(true);
                             rowsField.set(optimizer, rows);
                             
                             // Set up the mock behavior for getChiSquare()
                             when(optimizer.getChiSquare()).thenCallRealMethod();
                             
                             // Calculate expected chi-square using correct residual calculation (target - objective)
                             double expectedChiSquare = 0;
                             for (int i = 0; i < rows; i++) {
                                 double residual = targetValues[i] - objective[i];
                                 expectedChiSquare += residual * residual * residualsWeights[i];
                             }
                             
                             // Call the method and verify
                             double actualChiSquare = optimizer.getChiSquare();
                             
                             // This assertion will fail if the mutant (using addition) is present
                             assertEquals("Chi-square calculation should use target - objective for residuals", 
                                         expectedChiSquare, actualChiSquare, 1e-10);
                             
                             // Additional verification that the mutant would produce different results
                             double mutantChiSquare = 0;
                             for (int i = 0; i < rows; i++) {
                                 double residual = targetValues[i] + objective[i];
                                 mutantChiSquare += residual * residual * residualsWeights[i];
                             }
                             assertNotEquals("Test should detect if addition is used instead of subtraction",
                                            mutantChiSquare, actualChiSquare, 1e-10);
                         }

    @Test
                public void testGetChiSquareWithNegativeWeightsDetectsSignMutation() {
                    // Setup test data that will expose the mutation
                    int testRows = 2;
                    double[] testTargetValues = {5.0, 3.0};
                    double[] testObjective = {3.0, 5.0};  // Opposite of target to maximize difference
                    double[] testResidualsWeights = {-1.0, -1.0};  // Negative weights to expose sign change
                    
                    // Create test instance
                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                        // Anonymous subclass to test protected method
                        @Override
                        protected VectorialPointValuePair doOptimize() {
                            return null; // Not needed for this test
                        }
                    };
                    
                    // Set protected fields through reflection
                    try {
                        Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                        rowsField.setAccessible(true);
                        rowsField.set(optimizer, testRows);
                        
                        Field targetValuesField = AbstractLeastSquaresOptimizer.class.getDeclaredField("targetValues");
                        targetValuesField.setAccessible(true);
                        targetValuesField.set(optimizer, testTargetValues);
                        
                        Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                        objectiveField.setAccessible(true);
                        objectiveField.set(optimizer, testObjective);
                        
                        Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                        weightsField.setAccessible(true);
                        weightsField.set(optimizer, testResidualsWeights);
                    } catch (Exception e) {
                        fail("Failed to set up test fields via reflection: " + e.getMessage());
                    }
                    
                    // Calculate expected value (with correct residual calculation)
                    double expectedChiSquare = 0;
                    for (int i = 0; i < testRows; i++) {
                        double residual = testTargetValues[i] - testObjective[i];
                        expectedChiSquare += residual * residual * testResidualsWeights[i];
                    }
                    
                    // Get actual value and compare
                    double actualChiSquare = optimizer.getChiSquare();
                    assertEquals("Chi-square calculation should be sensitive to residual sign with negative weights", 
                               expectedChiSquare, actualChiSquare, 1e-10);
                }

    @Test
           public void testGetChiSquareDetectsResidualMutation() {
               // Setup test data
               int testRows = 2;
               double[] testResiduals = {1.5, 2.0}; // non-zero residuals
               double[] testWeights = {1.0, 1.0}; // simple weights
               
               // Create partial mock of the class under test
               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                   @Override
                   protected VectorialPointValuePair doOptimize() {
                       return null; // not needed for this test
                   }
               };
               
               // Set test data using reflection since fields are protected
               try {
                   Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                   residualsField.setAccessible(true);
                   residualsField.set(optimizer, testResiduals);
                   
                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                   weightsField.setAccessible(true);
                   weightsField.set(optimizer, testWeights);
                   
                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                   rowsField.setAccessible(true);
                   rowsField.set(optimizer, testRows);
               } catch (Exception e) {
                   fail("Failed to set test data via reflection: " + e.getMessage());
               }
               
               // Calculate expected value manually
               double expectedChiSquare = 0;
               for (int i = 0; i < testRows; i++) {
                   expectedChiSquare += testResiduals[i] * testResiduals[i] * testWeights[i];
               }
               
               // Test and assert
               double actualChiSquare = optimizer.getChiSquare();
               assertEquals("Chi-square calculation should use actual residuals", 
                           expectedChiSquare, actualChiSquare, 0.0001);
               
               // Additional assertion to specifically catch the mutant
               assertNotEquals("Chi-square should not be zero with non-zero residuals", 
                              0.0, actualChiSquare, 0.0001);
           }

    @Test
       public void testGetChiSquare_DetectsResidualMutation() {
           // Setup
           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
               @Override
               protected VectorialPointValuePair doOptimize() {
                   return null; // dummy implementation
               }
           };
           
           // Create a residuals array that changes when accessed
           final double[] changingResiduals = new double[]{1.0, 2.0};
           final double[] residualsWeights = new double[]{1.0, 1.0};
           
           // Use reflection to set protected fields
           try {
               Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
               residualsField.setAccessible(true);
               residualsField.set(optimizer, changingResiduals);
               
               Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
               weightsField.setAccessible(true);
               weightsField.set(optimizer, residualsWeights);
               
               Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
               rowsField.setAccessible(true);
               rowsField.set(optimizer, 2);
           } catch (Exception e) {
               fail("Failed to set up test via reflection: " + e.getMessage());
           }
           
           // Modify the residuals array during calculation
           new Thread(() -> {
               try {
                   Thread.sleep(10); // Small delay to ensure calculation has started
                   changingResiduals[0] = 3.0; // Change the first residual
               } catch (InterruptedException e) {
                   Thread.currentThread().interrupt();
               }
           }).start();
           
           // Test
           double result = optimizer.getChiSquare();
           
           // Verify - original would use initial value (1.0), mutant would use changed value (3.0)
           // The correct calculation should be based on the original values (1^2*1 + 2^2*1 = 5)
           assertEquals(5.0, result, 0.0001);
       }

    @Test
          public void testGetChiSquareDetectsIndexMutation1() {
              // Create a test instance by mocking the abstract class
              AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class, 
                  CALLS_REAL_METHODS);
              
              // Setup test data where order matters
              double[] residuals = {1.0, 2.0, 3.0};  // Position-dependent values
              double[] weights = {1.0, 2.0, 3.0};   // Position-dependent weights
              
              // Set the protected fields using reflection
              try {
                  java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class
                      .getDeclaredField("residuals");
                  residualsField.setAccessible(true);
                  residualsField.set(optimizer, residuals);
                  
                  java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class
                      .getDeclaredField("residualsWeights");
                  weightsField.setAccessible(true);
                  weightsField.set(optimizer, weights);
                  
                  java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class
                      .getDeclaredField("rows");
                  rowsField.setAccessible(true);
                  rowsField.set(optimizer, residuals.length);
              } catch (Exception e) {
                  fail("Failed to set up test fields via reflection");
              }
              
              // Calculate expected chi-square (forward processing)
              double expected = 0;
              for (int i = 0; i < residuals.length; i++) {
                  expected += residuals[i] * residuals[i] * weights[i];
              }
              
              // If the mutation exists (processing residuals in reverse), 
              // the actual result will be different
              double actual = optimizer.getChiSquare();
              
              assertEquals("Chi-square calculation should process residuals in correct order", 
                  expected, actual, 0.0001);
          }

    @Test
    public void testGetChiSquareAccumulation() {
        // Create a test instance by mocking the abstract class
        AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class, 
            CALLS_REAL_METHODS);
        
        // Set up test data
        double[] residuals = {1.0, 2.0, 3.0};
        double[] weights = {0.5, 1.0, 1.5};
        int rows = residuals.length;
        
        // Set protected fields using reflection
        try {
            java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class
                .getDeclaredField("residuals");
            residualsField.setAccessible(true);
            residualsField.set(optimizer, residuals);
            
            java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class
                .getDeclaredField("residualsWeights");
            weightsField.setAccessible(true);
            weightsField.set(optimizer, weights);
            
            java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class
                .getDeclaredField("rows");
            rowsField.setAccessible(true);
            rowsField.set(optimizer, rows);
        } catch (Exception e) {
            fail("Failed to set up test fields via reflection");
        }
        
        // Calculate expected value manually
        double expected = 0;
        for (int i = 0; i < rows; i++) {
            expected += residuals[i] * residuals[i] * weights[i];
        }
        
        // Test the method
        double actual = optimizer.getChiSquare();
        
        // Verify the accumulation is correct
        assertEquals("Chi-square calculation should properly accumulate values", 
            expected, actual, 1e-10);
        
        // Additional test with different values to ensure accumulation works
        residuals = new double[]{-1.0, 0.0, 1.0};
        weights = new double[]{2.0, 1.0, 2.0};
        expected = (-1.0)*(-1.0)*2.0 + 0.0*0.0*1.0 + 1.0*1.0*2.0;
        
        try {
            java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class
                .getDeclaredField("residuals");
            residualsField.setAccessible(true);
            residualsField.set(optimizer, residuals);
            
            java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class
                .getDeclaredField("residualsWeights");
            weightsField.setAccessible(true);
            weightsField.set(optimizer, weights);
            
            java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class
                .getDeclaredField("rows");
            rowsField.setAccessible(true);
            rowsField.set(optimizer, residuals.length);
        } catch (Exception e) {
            fail("Failed to modify test fields via reflection");
        }
        
        actual = optimizer.getChiSquare();
        assertEquals("Chi-square should handle negative residuals correctly",
            expected, actual, 1e-10);
    }


}
