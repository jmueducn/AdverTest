package gentest.org.apache.commons.math3.analysis.differentiation.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.analysis.differentiation.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;
 
public class DSCompilerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                      public void testAtan2_PositiveX() {
                                          // Setup
                                          DSCompiler compiler = mock(DSCompiler.class);
                                          when(compiler.getSize()).thenReturn(2);
                                          
                                          double[] y = {1.0, 0.1};
                                          int yOffset = 0;
                                          double[] x = {1.0, 0.2};
                                          int xOffset = 0;
                                          double[] result = new double[2];
                                          int resultOffset = 0;
                                          
                                          // Mock the required method calls
                                          doAnswer(invocation -> {
                                              double[] res = invocation.getArgument(4);
                                              res[0] = x[0] * x[0]; // x^2
                                              res[1] = 2 * x[0] * x[1]; // derivative
                                              return null;
                                          }).when(compiler).multiply(eq(x), eq(xOffset), eq(x), eq(xOffset), any(double[].class), eq(0));
                                          
                                          doAnswer(invocation -> {
                                              double[] res = invocation.getArgument(4);
                                              res[0] = y[0] * y[0]; // y^2
                                              res[1] = 2 * y[0] * y[1]; // derivative
                                              return null;
                                          }).when(compiler).multiply(eq(y), eq(yOffset), eq(y), eq(yOffset), any(double[].class), eq(0));
                                          
                                          doAnswer(invocation -> {
                                              double[] res = invocation.getArgument(4);
                                              res[0] = x[0]*x[0] + y[0]*y[0]; // x^2 + y^2
                                              res[1] = 2*x[0]*x[1] + 2*y[0]*y[1]; // derivative
                                              return null;
                                          }).when(compiler).add(any(double[].class), eq(0), any(double[].class), eq(0), any(double[].class), eq(0));
                                          
                                          doAnswer(invocation -> {
                                              double[] res = invocation.getArgument(3);
                                              res[0] = Math.sqrt(x[0]*x[0] + y[0]*y[0]); // r
                                              res[1] = (x[0]*x[1] + y[0]*y[1]) / res[0]; // derivative
                                              return null;
                                          }).when(compiler).rootN(any(double[].class), eq(0), eq(2), any(double[].class), eq(0));
                                          
                                          doAnswer(invocation -> {
                                              double[] res = invocation.getArgument(4);
                                              double r = Math.sqrt(x[0]*x[0] + y[0]*y[0]);
                                              res[0] = r + x[0];
                                              res[1] = (x[0]*x[1] + y[0]*y[1])/r + x[1];
                                              return null;
                                          }).when(compiler).add(any(double[].class), eq(0), eq(x), eq(xOffset), any(double[].class), eq(0));
                                          
                                          doAnswer(invocation -> {
                                              double[] res = invocation.getArgument(4);
                                              double r = Math.sqrt(x[0]*x[0] + y[0]*y[0]);
                                              res[0] = y[0] / (r + x[0]);
                                              res[1] = (y[1]*(r+x[0]) - y[0]*((x[0]*x[1]+y[0]*y[1])/r + x[1])) / ((r+x[0])*(r+x[0]));
                                              return null;
                                          }).when(compiler).divide(eq(y), eq(yOffset), any(double[].class), eq(0), any(double[].class), eq(0));
                                          
                                          doAnswer(invocation -> {
                                              double[] operand = invocation.getArgument(0);
                                              double[] res = invocation.getArgument(3);
                                              res[0] = Math.atan(operand[0]);
                                              res[1] = operand[1] / (1 + operand[0]*operand[0]);
                                              return null;
                                          }).when(compiler).atan(any(double[].class), eq(0), any(double[].class), eq(0));
                                          
                                          // Execute
                                          compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                          
                                          // Verify
                                          double expected = FastMath.atan2(y[0], x[0]);
                                          assertEquals(expected, result[0], 1e-15);
                                          // Verify the derivative calculation
                                          assertNotEquals(0.0, result[1], 1e-15);
                                      }

    @Test
                                      public void testAtan2_NegativeX() {
                                          // Setup
                                          DSCompiler compiler = mock(DSCompiler.class);
                                          when(compiler.getSize()).thenReturn(2);
                                          
                                          double[] y = {1.0, 0.1};
                                          int yOffset = 0;
                                          double[] x = {-1.0, 0.2};
                                          int xOffset = 0;
                                          double[] result = new double[2];
                                          int resultOffset = 0;
                                          
                                          // Mock the required method calls
                                          doAnswer(invocation -> {
                                              double[] res = invocation.getArgument(4);
                                              res[0] = x[0] * x[0];
                                              res[1] = 2 * x[0] * x[1];
                                              return null;
                                          }).when(compiler).multiply(eq(x), eq(xOffset), eq(x), eq(xOffset), any(double[].class), eq(0));
                                          
                                          doAnswer(invocation -> {
                                              double[] res = invocation.getArgument(4);
                                              res[0] = y[0] * y[0];
                                              res[1] = 2 * y[0] * y[1];
                                              return null;
                                          }).when(compiler).multiply(eq(y), eq(yOffset), eq(y), eq(yOffset), any(double[].class), eq(0));
                                          
                                          doAnswer(invocation -> {
                                              double[] res = invocation.getArgument(4);
                                              res[0] = x[0]*x[0] + y[0]*y[0];
                                              res[1] = 2*x[0]*x[1] + 2*y[0]*y[1];
                                              return null;
                                          }).when(compiler).add(any(double[].class), eq(0), any(double[].class), eq(0), any(double[].class), eq(0));
                                          
                                          doAnswer(invocation -> {
                                              double[] res = invocation.getArgument(3);
                                              res[0] = Math.sqrt(x[0]*x[0] + y[0]*y[0]);
                                              res[1] = (x[0]*x[1] + y[0]*y[1]) / res[0];
                                              return null;
                                          }).when(compiler).rootN(any(double[].class), eq(0), eq(2), any(double[].class), eq(0));
                                          
                                          doAnswer(invocation -> {
                                              double[] res = invocation.getArgument(4);
                                              double r = Math.sqrt(x[0]*x[0] + y[0]*y[0]);
                                              res[0] = r - x[0];
                                              res[1] = (x[0]*x[1] + y[0]*y[1])/r - x[1];
                                              return null;
                                          }).when(compiler).subtract(any(double[].class), eq(0), eq(x), eq(xOffset), any(double[].class), eq(0));
                                          
                                          doAnswer(invocation -> {
                                              double[] res = invocation.getArgument(4);
                                              double r = Math.sqrt(x[0]*x[0] + y[0]*y[0]);
                                              res[0] = y[0] / (r - x[0]);
                                              res[1] = (y[1]*(r-x[0]) - y[0]*((x[0]*x[1]+y[0]*y[1])/r - x[1])) / ((r-x[0])*(r-x[0]));
                                              return null;
                                          }).when(compiler).divide(eq(y), eq(yOffset), any(double[].class), eq(0), any(double[].class), eq(0));
                                          
                                          doAnswer(invocation -> {
                                              double[] operand = invocation.getArgument(0);
                                              double[] res = invocation.getArgument(3);
                                              res[0] = Math.atan(operand[0]);
                                              res[1] = operand[1] / (1 + operand[0]*operand[0]);
                                              return null;
                                          }).when(compiler).atan(any(double[].class), eq(0), any(double[].class), eq(0));
                                          
                                          // Execute
                                          compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                          
                                          // Verify
                                          double expected = FastMath.atan2(y[0], x[0]);
                                          assertEquals(expected, result[0], 1e-15);
                                          // Verify the derivative calculation
                                          assertNotEquals(0.0, result[1], 1e-15);
                                      }

    @Test
                                      public void testAtan2_SpecialCases() {
                                          // Setup
                                          DSCompiler compiler = mock(DSCompiler.class);
                                          when(compiler.getSize()).thenReturn(1);
                                          
                                          // Test case 1: (0, 0)
                                          double[] y1 = {0.0};
                                          double[] x1 = {0.0};
                                          double[] result1 = new double[1];
                                          compiler.atan2(y1, 0, x1, 0, result1, 0);
                                          assertEquals(0.0, result1[0], 1e-15);
                                          
                                          // Test case 2: (0, positive)
                                          double[] y2 = {0.0};
                                          double[] x2 = {1.0};
                                          double[] result2 = new double[1];
                                          compiler.atan2(y2, 0, x2, 0, result2, 0);
                                          assertEquals(0.0, result2[0], 1e-15);
                                          
                                          // Test case 3: (0, negative)
                                          double[] y3 = {0.0};
                                          double[] x3 = {-1.0};
                                          double[] result3 = new double[1];
                                          compiler.atan2(y3, 0, x3, 0, result3, 0);
                                          assertEquals(FastMath.PI, result3[0], 1e-15);
                                          
                                          // Test case 4: (positive, 0)
                                          double[] y4 = {1.0};
                                          double[] x4 = {0.0};
                                          double[] result4 = new double[1];
                                          compiler.atan2(y4, 0, x4, 0, result4, 0);
                                          assertEquals(FastMath.PI/2, result4[0], 1e-15);
                                          
                                          // Test case 5: (negative, 0)
                                          double[] y5 = {-1.0};
                                          double[] x5 = {0.0};
                                          double[] result5 = new double[1];
                                          compiler.atan2(y5, 0, x5, 0, result5, 0);
                                          assertEquals(-FastMath.PI/2, result5[0], 1e-15);
                                      }

    @Test
                                      public void testAtan2_EdgeCases() {
                                          // Setup
                                          DSCompiler compiler = mock(DSCompiler.class);
                                          when(compiler.getSize()).thenReturn(1);
                                          
                                          // Test case 1: Large values
                                          double[] y1 = {1e300};
                                          double[] x1 = {1e300};
                                          double[] result1 = new double[1];
                                          compiler.atan2(y1, 0, x1, 0, result1, 0);
                                          assertEquals(FastMath.PI/4, result1[0], 1e-15);
                                          
                                          // Test case 2: Small values
                                          double[] y2 = {1e-300};
                                          double[] x2 = {1e-300};
                                          double[] result2 = new double[1];
                                          compiler.atan2(y2, 0, x2, 0, result2, 0);
                                          assertEquals(FastMath.PI/4, result2[0], 1e-15);
                                          
                                          // Test case 3: Infinity cases
                                          double[] y3 = {Double.POSITIVE_INFINITY};
                                          double[] x3 = {1.0};
                                          double[] result3 = new double[1];
                                          compiler.atan2(y3, 0, x3, 0, result3, 0);
                                          assertEquals(FastMath.PI/2, result3[0], 1e-15);
                                          
                                          double[] y4 = {1.0};
                                          double[] x4 = {Double.POSITIVE_INFINITY};
                                          double[] result4 = new double[1];
                                          compiler.atan2(y4, 0, x4, 0, result4, 0);
                                          assertEquals(0.0, result4[0], 1e-15);
                                      }

    @Test
                             public void testAtan2DetectsArgumentSwapMutant() {
                                 // Setup
                                 DSCompiler compiler = DSCompiler.getCompiler(2, 2); // Using public factory method instead of private constructor
                                 double[] y = new double[compiler.getSize()];
                                 double[] x = new double[compiler.getSize()];
                                 double[] result = new double[compiler.getSize()];
                                 
                                 // Choose values where atan2(y,x) != atan2(x,y)
                                 // Using (1,2) and (2,1) which should give different results
                                 y[0] = 1.0;
                                 x[0] = 2.0;
                                 
                                 // Expected value
                                 double expected = FastMath.atan2(y[0], x[0]);
                                 
                                 // Test
                                 compiler.atan2(y, 0, x, 0, result, 0);
                                 
                                 // Assert - this will fail if arguments are swapped
                                 assertEquals("Final result should match FastMath.atan2(y,x)", 
                                              expected, result[0], 1e-15);
                                 
                                 // Additional check with swapped values to be thorough
                                 y[0] = 2.0;
                                 x[0] = 1.0;
                                 expected = FastMath.atan2(y[0], x[0]);
                                 compiler.atan2(y, 0, x, 0, result, 0);
                                 assertEquals("Final result should match FastMath.atan2(y,x) for swapped values",
                                              expected, result[0], 1e-15);
                             }

    @Test
                         public void testAtan2SpecialCases() {
                             // Create test instance
                             DSCompiler compiler = DSCompiler.getCompiler(1, 1); // parameters=1, order=1
                             
                             // Test cases where FastMath.atan2 would return non-zero values
                             double[] yPosZero = {0.0};
                             double[] xNegZero = {-0.0};
                             double[] yNegZero = {-0.0};
                             double[] xPosZero = {0.0};
                             double[] yInf = {Double.POSITIVE_INFINITY};
                             double[] xInf = {Double.POSITIVE_INFINITY};
                             
                             // Result arrays
                             double[] result1 = new double[compiler.getSize()];
                             double[] result2 = new double[compiler.getSize()];
                             double[] result3 = new double[compiler.getSize()];
                             
                             // Test positive zero / negative zero (should be π)
                             compiler.atan2(yPosZero, 0, xNegZero, 0, result1, 0);
                             assertEquals(FastMath.atan2(0.0, -0.0), result1[0], 0.0001);
                             
                             // Test negative zero / positive zero (should be -π)
                             compiler.atan2(yNegZero, 0, xPosZero, 0, result2, 0);
                             assertEquals(FastMath.atan2(-0.0, 0.0), result2[0], 0.0001);
                             
                             // Test infinity / infinity (should be π/4)
                             compiler.atan2(yInf, 0, xInf, 0, result3, 0);
                             assertEquals(FastMath.atan2(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY), result3[0], 0.0001);
                         }

    @Test
                        public void testAtan2SpecialCasesDetectsMutant() {
                            // Setup test data for special cases
                            DSCompiler compiler = DSCompiler.getCompiler(2, 1); // assuming 2 parameters, order 1
                            
                            // Test case 1: (1,0) should return 0
                            double[] x1 = {1.0, 0.0}; // x = 1
                            double[] y1 = {0.0, 0.0};  // y = 0
                            double[] result1 = new double[compiler.getSize()];
                            compiler.atan2(y1, 0, x1, 0, result1, 0);
                            assertEquals(0.0, result1[0], 1e-15);
                            
                            // Test case 2: (0,1) should return π/2
                            double[] x2 = {0.0, 0.0}; // x = 0
                            double[] y2 = {1.0, 0.0};  // y = 1
                            double[] result2 = new double[compiler.getSize()];
                            compiler.atan2(y2, 0, x2, 0, result2, 0);
                            assertEquals(FastMath.PI/2, result2[0], 1e-15);
                            
                            // Test case 3: (-1,0) should return π (this case would pass with mutant)
                            double[] x3 = {-1.0, 0.0}; // x = -1
                            double[] y3 = {0.0, 0.0};   // y = 0
                            double[] result3 = new double[compiler.getSize()];
                            compiler.atan2(y3, 0, x3, 0, result3, 0);
                            assertEquals(FastMath.PI, result3[0], 1e-15);
                            
                            // Test case 4: (0,-1) should return -π/2
                            double[] x4 = {0.0, 0.0};  // x = 0
                            double[] y4 = {-1.0, 0.0}; // y = -1
                            double[] result4 = new double[compiler.getSize()];
                            compiler.atan2(y4, 0, x4, 0, result4, 0);
                            assertEquals(-FastMath.PI/2, result4[0], 1e-15);
                            
                            // Test case 5: (0,0) should return 0
                            double[] x5 = {0.0, 0.0}; // x = 0
                            double[] y5 = {0.0, 0.0};  // y = 0
                            double[] result5 = new double[compiler.getSize()];
                            compiler.atan2(y5, 0, x5, 0, result5, 0);
                            assertEquals(0.0, result5[0], 1e-15);
                        }

    @Test
                      public void testAtan2WithNegativeXShouldUseAtan2NotAtan() {
                          // Setup
                          DSCompiler compiler = DSCompiler.getCompiler(2, 2); // Use public factory method instead of private constructor
                          double[] y = new double[compiler.getSize()];
                          double[] x = new double[compiler.getSize()];
                          double[] result = new double[compiler.getSize()];
                          
                          // Test case where x is negative and y is positive (quadrant II)
                          y[0] = 1.0;  // y coordinate
                          x[0] = -1.0; // x coordinate (negative)
                          
                          // Expected value using correct atan2
                          double expected = FastMath.atan2(y[0], x[0]);
                          
                          // Call the method
                          compiler.atan2(y, 0, x, 0, result, 0);
                          
                          // Verify the result matches atan2 not atan
                          assertEquals("Result should use atan2 not atan for negative x", 
                                       expected, result[0], 1e-15);
                          
                          // Additional verification that it's not just atan(y)
                          assertNotEquals("Result should not match simple atan(y)",
                                         FastMath.atan(y[0]), result[0], 1e-15);
                          
                          // Test another case where x is negative and y is negative (quadrant III)
                          y[0] = -1.0;
                          x[0] = -1.0;
                          expected = FastMath.atan2(y[0], x[0]);
                          compiler.atan2(y, 0, x, 0, result, 0);
                          assertEquals("Result should use atan2 not atan for negative x", 
                                       expected, result[0], 1e-15);
                          assertNotEquals("Result should not match simple atan(y)",
                                         FastMath.atan(y[0]), result[0], 1e-15);
                      }

    @Test
                  public void testAtan2DetectsMutantIgnoringY() {
                      // Setup test data where y is non-zero to expose the mutant
                      DSCompiler compiler = DSCompiler.getCompiler(2, 2); // parameters=2, order=2
                      
                      // Case 1: x positive, y positive (should use first branch)
                      double[] x1 = {1.0, 0.0, 0.0}; // x=1.0
                      double[] y1 = {1.0, 0.0, 0.0}; // y=1.0
                      double[] result1 = new double[compiler.getSize()];
                      compiler.atan2(y1, 0, x1, 0, result1, 0);
                      
                      // Case 2: x negative, y positive (should use second branch)
                      double[] x2 = {-1.0, 0.0, 0.0}; // x=-1.0
                      double[] y2 = {1.0, 0.0, 0.0}; // y=1.0
                      double[] result2 = new double[compiler.getSize()];
                      compiler.atan2(y2, 0, x2, 0, result2, 0);
                      
                      // Verify both cases properly use y in calculation
                      // The mutant would compute atan(1.0) instead of atan2(1.0,1.0) for result1[0]
                      assertEquals(FastMath.atan2(1.0, 1.0), result1[0], 1e-10);
                      
                      // The mutant would compute atan(-1.0) instead of atan2(1.0,-1.0) for result2[0]
                      assertEquals(FastMath.atan2(1.0, -1.0), result2[0], 1e-10);
                      
                      // Also verify other array elements are properly set
                      for (int i = 1; i < result1.length; i++) {
                          assertEquals(0.0, result1[i], 1e-10);
                          assertEquals(0.0, result2[i], 1e-10);
                      }
                  }

    @Test
                 public void testAtan2DetectsMutant() {
                     // Create test compiler instance
                     DSCompiler compiler = DSCompiler.getCompiler(1, 1); // parameters=1, order=1
                     
                     // Test case where y=1 and x=1 (45 degrees, should be π/4)
                     double[] y = {1.0};
                     double[] x = {1.0};
                     double[] result = new double[compiler.getSize()];
                     
                     compiler.atan2(y, 0, x, 0, result, 0);
                     
                     // The mutant would set result[0] = y[0] = 1.0
                     // Correct value should be π/4 ≈ 0.78539816339
                     assertEquals(FastMath.atan2(1.0, 1.0), result[0], 1e-10);
                     
                     // Additional test case where y=1 and x=-1 (135 degrees, should be 3π/4)
                     x[0] = -1.0;
                     compiler.atan2(y, 0, x, 0, result, 0);
                     
                     // The mutant would set result[0] = y[0] = 1.0
                     // Correct value should be 3π/4 ≈ 2.35619449019
                     assertEquals(FastMath.atan2(1.0, -1.0), result[0], 1e-10);
                     
                     // Test case with y=0 to ensure special cases are handled
                     y[0] = 0.0;
                     x[0] = 1.0;
                     compiler.atan2(y, 0, x, 0, result, 0);
                     
                     // The mutant would set result[0] = y[0] = 0.0
                     // Correct value should be 0.0
                     assertEquals(FastMath.atan2(0.0, 1.0), result[0], 1e-10);
                 }

    @Test
                public void testAtan2DetectsMutant1() {
                    // Create a test instance of DSCompiler
                    DSCompiler compiler = DSCompiler.getCompiler(2, 1); // parameters=2, order=1
                    
                    // Test input values where x is positive
                    double[] x = {1.0, 0.0}; // x coordinate
                    double[] y = {1.0, 0.0}; // y coordinate
                    double[] result = new double[compiler.getSize()];
                    
                    // Calculate expected value using FastMath.atan2
                    double expected = FastMath.atan2(y[0], x[0]);
                    
                    // Call the method
                    compiler.atan2(y, 0, x, 0, result, 0);
                    
                    // Verify the first element matches the expected angle calculation
                    // This will fail if the mutant is present (would get x[0] instead)
                    assertEquals(expected, result[0], 1e-15);
                    
                    // Also test with negative x to cover both branches
                    x[0] = -1.0;
                    expected = FastMath.atan2(y[0], x[0]);
                    compiler.atan2(y, 0, x, 0, result, 0);
                    assertEquals(expected, result[0], 1e-15);
                    
                    // Test special case with zero values
                    x[0] = 0.0;
                    y[0] = 0.0;
                    expected = FastMath.atan2(y[0], x[0]);
                    compiler.atan2(y, 0, x, 0, result, 0);
                    assertEquals(expected, result[0], 1e-15);
                }

    @Test
               public void testAtan2DetectsSignFlipMutation() {
                   // Create a compiler instance (parameters=1, order=1 for simplicity)
                   DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                   
                   // Test case 1: x positive, y positive
                   double[] x1 = {1.0};
                   double[] y1 = {1.0};
                   double[] result1 = new double[1];
                   compiler.atan2(y1, 0, x1, 0, result1, 0);
                   double expected1 = FastMath.atan2(1.0, 1.0);
                   assertEquals("Positive y should give positive angle", expected1, result1[0], 1e-15);
                   
                   // Test case 2: x positive, y negative
                   double[] x2 = {1.0};
                   double[] y2 = {-1.0};
                   double[] result2 = new double[1];
                   compiler.atan2(y2, 0, x2, 0, result2, 0);
                   double expected2 = FastMath.atan2(-1.0, 1.0);
                   assertEquals("Negative y should give negative angle", expected2, result2[0], 1e-15);
                   
                   // Test case 3: x negative, y positive
                   double[] x3 = {-1.0};
                   double[] y3 = {1.0};
                   double[] result3 = new double[1];
                   compiler.atan2(y3, 0, x3, 0, result3, 0);
                   double expected3 = FastMath.atan2(1.0, -1.0);
                   assertEquals("Positive y with negative x should give correct angle", expected3, result3[0], 1e-15);
                   
                   // Test case 4: x negative, y negative
                   double[] x4 = {-1.0};
                   double[] y4 = {-1.0};
                   double[] result4 = new double[1];
                   compiler.atan2(y4, 0, x4, 0, result4, 0);
                   double expected4 = FastMath.atan2(-1.0, -1.0);
                   assertEquals("Negative y with negative x should give correct angle", expected4, result4[0], 1e-15);
               }

    @Test
              public void testAtan2DetectsSignFlipMutation1() {
                  // Create test instance
                  DSCompiler compiler = DSCompiler.getCompiler(2, 2); // Using arbitrary parameters
                  
                  // Test case with positive x (most likely to catch the mutation)
                  double[] y = {1.0, 0.0, 0.0}; // y value and derivatives
                  double[] x = {1.0, 0.0, 0.0}; // positive x value and derivatives
                  double[] result = new double[3];
                  
                  // Expected angle is π/4 (45 degrees) for atan2(1,1)
                  double expected = FastMath.atan2(1.0, 1.0);
                  
                  compiler.atan2(y, 0, x, 0, result, 0);
                  
                  // Verify the result matches FastMath.atan2 without sign flip
                  assertEquals("Main value should match correct atan2", expected, result[0], 1e-15);
                  
                  // Also test with negative x to ensure original behavior
                  x[0] = -1.0;
                  expected = FastMath.atan2(1.0, -1.0);
                  compiler.atan2(y, 0, x, 0, result, 0);
                  assertEquals("Should handle negative x correctly", expected, result[0], 1e-15);
                  
                  // Test with x=0 to ensure edge case handling
                  x[0] = 0.0;
                  expected = FastMath.atan2(1.0, 0.0);
                  compiler.atan2(y, 0, x, 0, result, 0);
                  assertEquals("Should handle x=0 correctly", expected, result[0], 1e-15);
              }

    @Test
            public void testAtan2WithNonZeroYShouldUseActualYValue() {
                // Setup
                DSCompiler compiler = DSCompiler.getCompiler(2, 2); // Using public factory method
                double[] y = {1.0, 0.0, 0.0}; // Non-zero y value
                int yOffset = 0;
                double[] x = {1.0, 0.0, 0.0}; // Positive x value
                int xOffset = 0;
                double[] result = new double[3];
                int resultOffset = 0;
                
                // Expected value
                double expected = FastMath.atan2(y[yOffset], x[xOffset]);
                
                // Test
                compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                
                // Verify
                assertEquals("Final result should use actual y value", 
                            expected, 
                            result[resultOffset], 
                            1e-15);
                
                // Additional verification for other array elements if needed
                for (int i = 1; i < result.length; i++) {
                    assertEquals(0.0, result[i], 1e-15);
                }
            }

    @Test
        public void testAtan2DetectsMutant2() {
            // Create test instance
            DSCompiler compiler = DSCompiler.getCompiler(2, 2); // Using arbitrary parameters and order
            
            // Test data where x is not zero
            double[] y = {1.0, 0.0, 0.0}; // y value
            double[] x = {1.0, 0.0, 0.0}; // x value (non-zero)
            double[] result = new double[compiler.getSize()];
            
            // Calculate expected value
            double expected = FastMath.atan2(y[0], x[0]);
            
            // Call the method
            compiler.atan2(y, 0, x, 0, result, 0);
            
            // Verify the result matches the expected FastMath.atan2 calculation
            assertEquals("Final result should match FastMath.atan2(y,x)", 
                         expected, result[0], 1e-15);
            
            // Additional test with negative x value
            x[0] = -1.0;
            expected = FastMath.atan2(y[0], x[0]);
            compiler.atan2(y, 0, x, 0, result, 0);
            assertEquals("Final result should match FastMath.atan2(y,x) for negative x",
                         expected, result[0], 1e-15);
        }

    @Test
       public void testAtan2SpecialCasesDetectsRandomMutant() {
           // Setup test inputs and expected values
           double[] y = {0.0, 1.0, 2.0};  // Includes 0 for special case
           double[] x = {0.0, 1.0, 2.0};  // Includes 0 for special case
           double[] result = new double[3];
           int yOffset = 0;
           int xOffset = 0;
           int resultOffset = 0;
           
           // Create compiler instance (simplified for test)
           DSCompiler compiler = mock(DSCompiler.class);
           when(compiler.getSize()).thenReturn(3);
           
           // Mock the internal method calls that we don't need to test
           doAnswer(invocation -> {
               double[] res = invocation.getArgument(4);
               res[0] = 1.0;  // Mock some intermediate result
               return null;
           }).when(compiler).multiply(any(), anyInt(), any(), anyInt(), any(), anyInt());
           
           doAnswer(invocation -> {
               double[] res = invocation.getArgument(4);
               res[0] = 1.0;  // Mock some intermediate result
               return null;
           }).when(compiler).add(any(), anyInt(), any(), anyInt(), any(), anyInt());
           
           doAnswer(invocation -> {
               double[] res = invocation.getArgument(3);
               res[0] = 1.0;  // Mock some intermediate result
               return null;
           }).when(compiler).rootN(any(), anyInt(), anyInt(), any(), anyInt());
           
           doAnswer(invocation -> {
               double[] res = invocation.getArgument(4);
               res[0] = 0.5;  // Mock atan result
               return null;
           }).when(compiler).atan(any(), anyInt(), any(), anyInt());
           
           // Call the method
           compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
           
           // Verify the first element matches FastMath.atan2() exactly
           // This will fail if the mutant replaces it with random()
           assertEquals(FastMath.atan2(y[yOffset], x[xOffset]), result[resultOffset], 0.0);
           
           // Additional test with negative zero
           y[0] = -0.0;
           x[0] = -0.0;
           compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
           assertEquals(FastMath.atan2(y[yOffset], x[xOffset]), result[resultOffset], 0.0);
           
           // Test with large numbers (potential infinity cases)
           y[0] = Double.MAX_VALUE;
           x[0] = Double.MAX_VALUE;
           compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
           assertEquals(FastMath.atan2(y[yOffset], x[xOffset]), result[resultOffset], 0.0);
       }

    @Test
      public void testAtan2WithNonUnitXValue() {
          // Setup
          DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Using simplest case with 1 parameter and order 1
          double[] y = {1.0, 0.0}; // y value with derivative
          double[] x = {2.0, 0.0}; // x ≠ 1.0 to catch the mutant
          double[] result = new double[compiler.getSize()];
          
          // Action
          compiler.atan2(y, 0, x, 0, result, 0);
          
          // Verification
          double expected = FastMath.atan2(y[0], x[0]);
          assertEquals("Main value should match FastMath.atan2", expected, result[0], 1e-15);
          
          // Also test negative x case
          x[0] = -2.0;
          compiler.atan2(y, 0, x, 0, result, 0);
          expected = FastMath.atan2(y[0], x[0]);
          assertEquals("Negative x case should match FastMath.atan2", expected, result[0], 1e-15);
      }

    @Test
    public void testAtan2DetectsMutantInSpecialCaseFix() {
        // Setup
        DSCompiler compiler = DSCompiler.getCompiler(2, 2); // Using public factory method instead of private constructor
        double[] x = new double[compiler.getSize()];
        double[] y = new double[compiler.getSize()];
        double[] result = new double[compiler.getSize()];
        
        // Test case where y[yOffset] is not 1.0 (using 2.0)
        x[0] = 1.0;  // x value
        y[0] = 2.0;  // y value (different from 1.0 to catch mutant)
        int xOffset = 0;
        int yOffset = 0;
        int resultOffset = 0;
        
        // Execute
        compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
        
        // Verify the special case fix was applied correctly
        // The mutant would use 1.0 instead of y[yOffset] (2.0)
        double expected = FastMath.atan2(y[yOffset], x[xOffset]);
        assertEquals("Special case fix should use actual y value", 
                    expected, 
                    result[resultOffset], 
                    1e-15);
        
        // Additional test case with negative y value
        y[0] = -0.5;
        compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
        expected = FastMath.atan2(y[yOffset], x[xOffset]);
        assertEquals("Special case fix should work with negative y values",
                    expected,
                    result[resultOffset],
                    1e-15);
        
        // Edge case: x=0, y=0
        x[0] = 0.0;
        y[0] = 0.0;
        compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
        expected = FastMath.atan2(y[yOffset], x[xOffset]);
        assertEquals("Special case fix should handle (0,0) correctly",
                    expected,
                    result[resultOffset],
                    1e-15);
    }


}
