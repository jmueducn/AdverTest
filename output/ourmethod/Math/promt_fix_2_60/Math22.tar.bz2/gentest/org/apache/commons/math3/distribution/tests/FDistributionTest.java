package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.special.Beta;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
 
public class FDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                           public void testGetDenominatorDegreesOfFreedom_WithPositiveValues() {
                               // Test with typical positive values
                               double numeratorDof = 5.0;
                               double denominatorDof = 10.0;
                               FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
                               
                               assertEquals(denominatorDof, fDist.getDenominatorDegreesOfFreedom(), 0.0);
                           }

 @Test
                           public void testGetDenominatorDegreesOfFreedom_WithFractionalValues() {
                               // Test with fractional degrees of freedom
                               double numeratorDof = 2.5;
                               double denominatorDof = 7.5;
                               FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
                               
                               assertEquals(denominatorDof, fDist.getDenominatorDegreesOfFreedom(), 0.0);
                           }

 @Test
                           public void testGetDenominatorDegreesOfFreedom_WithLargeValues() {
                               // Test with large values
                               double numeratorDof = 1000.0;
                               double denominatorDof = 2000.0;
                               FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
                               
                               assertEquals(denominatorDof, fDist.getDenominatorDegreesOfFreedom(), 0.0);
                           }

 @Test
                           public void testGetDenominatorDegreesOfFreedom_WithDifferentConstructors() {
                               // Test with different constructor variants
                               double numeratorDof = 3.0;
                               double denominatorDof = 6.0;
                               double inverseCumAccuracy = 1e-12;
                               
                               FDistribution fDist1 = new FDistribution(numeratorDof, denominatorDof);
                               FDistribution fDist2 = new FDistribution(numeratorDof, denominatorDof, inverseCumAccuracy);
                               
                               assertEquals(denominatorDof, fDist1.getDenominatorDegreesOfFreedom(), 0.0);
                               assertEquals(denominatorDof, fDist2.getDenominatorDegreesOfFreedom(), 0.0);
                           }

 @Test
                           public void testGetDenominatorDegreesOfFreedom_AfterConstruction() {
                               // Verify the value doesn't change after construction
                               double numeratorDof = 4.0;
                               double initialDenominatorDof = 8.0;
                               FDistribution fDist = new FDistribution(numeratorDof, initialDenominatorDof);
                               
                               // Call multiple times to ensure consistency
                               assertEquals(initialDenominatorDof, fDist.getDenominatorDegreesOfFreedom(), 0.0);
                               assertEquals(initialDenominatorDof, fDist.getDenominatorDegreesOfFreedom(), 0.0);
                           }

 @Test(expected = IllegalArgumentException.class)
                           public void testConstructorWithZeroDenominatorDof() {
                               // This tests that the constructor properly validates input
                               // The getter isn't directly involved but we should verify the object can't be created with invalid dof
                               new FDistribution(5.0, 0.0);
                           }

 @Test(expected = IllegalArgumentException.class)
                           public void testConstructorWithNegativeDenominatorDof() {
                               // Similar to above, testing boundary condition
                               new FDistribution(5.0, -1.0);
                           }

 @Test
                   public void testGetSolverAbsoluteAccuracy_DefaultConstructor() throws Exception {
                       // Test with default accuracy (DEFAULT_INVERSE_ABSOLUTE_ACCURACY)
                       double numeratorDF = 5.0;
                       double denominatorDF = 10.0;
                       FDistribution dist = new FDistribution(numeratorDF, denominatorDF);
                       
                       // Use reflection to access protected method
                       Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                       method.setAccessible(true);
                       double accuracy = (Double) method.invoke(dist);
                       
                       assertEquals(FDistribution.DEFAULT_INVERSE_ABSOLUTE_ACCURACY, accuracy, 0.0);
                   }

 @Test
                   public void testGetSolverAbsoluteAccuracy_CustomAccuracy() throws Exception {
                       // Test with custom accuracy value
                       double numeratorDF = 3.0;
                       double denominatorDF = 7.0;
                       double customAccuracy = 1e-12;
                       FDistribution dist = new FDistribution(numeratorDF, denominatorDF, customAccuracy);
                       
                       // Use reflection to access protected method
                       Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                       method.setAccessible(true);
                       double actualAccuracy = (Double) method.invoke(dist);
                       
                       assertEquals(customAccuracy, actualAccuracy, 0.0);
                   }

 @Test
                   public void testGetSolverAbsoluteAccuracy_DifferentDegreesOfFreedom() throws Exception {
                       // Test that accuracy remains the same regardless of degrees of freedom
                       double accuracy = 1e-10;
                       
                       // First case
                       FDistribution dist1 = new FDistribution(1.0, 1.0, accuracy);
                       Method getSolverAccuracy = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                       getSolverAccuracy.setAccessible(true);
                       assertEquals(accuracy, (Double)getSolverAccuracy.invoke(dist1), 0.0);
                       
                       // Second case with different degrees
                       FDistribution dist2 = new FDistribution(100.0, 50.0, accuracy);
                       assertEquals(accuracy, (Double)getSolverAccuracy.invoke(dist2), 0.0);
                       
                       // Third case with very large degrees
                       FDistribution dist3 = new FDistribution(1e6, 1e6, accuracy);
                       assertEquals(accuracy, (Double)getSolverAccuracy.invoke(dist3), 0.0);
                   }

 @Test
                   public void testGetSolverAbsoluteAccuracy_WithRandomGenerator() throws Exception {
                       // Test with full constructor including RandomGenerator
                       double numeratorDF = 2.0;
                       double denominatorDF = 5.0;
                       double accuracy = 1e-8;
                       RandomGenerator rng = new Well19937c();
                       FDistribution dist = new FDistribution(rng, numeratorDF, denominatorDF, accuracy);
                       
                       // Use reflection to access protected method
                       Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                       method.setAccessible(true);
                       double result = (Double) method.invoke(dist);
                       
                       assertEquals(accuracy, result, 0.0);
                   }

 @Test
                   public void testIsSupportLowerBoundInclusive_ReturnsFalse() {
                       // Create initial FDistribution instance with standard degrees of freedom
                       FDistribution fDistribution = new FDistribution(5.0, 10.0);
                       
                       // Test with standard degrees of freedom
                       assertFalse(fDistribution.isSupportLowerBoundInclusive());
                       
                       // Test with minimum valid degrees of freedom (just above 0)
                       FDistribution minDFDistribution = new FDistribution(Double.MIN_VALUE, Double.MIN_VALUE);
                       assertFalse(minDFDistribution.isSupportLowerBoundInclusive());
                       
                       // Test with large degrees of freedom
                       FDistribution largeDFDistribution = new FDistribution(1000.0, 1000.0);
                       assertFalse(largeDFDistribution.isSupportLowerBoundInclusive());
                       
                       // Test with different numerator and denominator degrees
                       FDistribution differentDFDistribution = new FDistribution(2.0, 50.0);
                       assertFalse(differentDFDistribution.isSupportLowerBoundInclusive());
                   }

 @Test
                   public void testIsSupportLowerBoundInclusive_Consistency() {
                       // Create an FDistribution instance with valid degrees of freedom
                       FDistribution fDistribution = new FDistribution(2.0, 5.0);
                       
                       // Verify the method consistently returns false across multiple calls
                       assertFalse(fDistribution.isSupportLowerBoundInclusive());
                       assertFalse(fDistribution.isSupportLowerBoundInclusive());
                       assertFalse(fDistribution.isSupportLowerBoundInclusive());
                   }

 @Test
                   public void testIsSupportLowerBoundInclusive_WithDifferentConstructors() {
                       // Test with different constructor variations
                       double numeratorDegrees = 5.0;  // example value for numerator degrees of freedom
                       double denominatorDegrees = 10.0; // example value for denominator degrees of freedom
                       
                       FDistribution dist1 = new FDistribution(numeratorDegrees, denominatorDegrees, 1e-12);
                       assertFalse(dist1.isSupportLowerBoundInclusive());
                       
                       FDistribution dist2 = new FDistribution(new Well19937c(), numeratorDegrees, denominatorDegrees, 1e-12);
                       assertFalse(dist2.isSupportLowerBoundInclusive());
                   }

 @Test
                   public void testGetDenominatorDegreesOfFreedom() {
                       // Test with normal values
                       double numeratorDF = 5.0;
                       double denominatorDF = 10.0;
                       FDistribution dist = new FDistribution(numeratorDF, denominatorDF);
                       assertEquals(denominatorDF, dist.getDenominatorDegreesOfFreedom(), 0.0);
                       
                       // Test with boundary value (just above 0)
                       denominatorDF = Double.MIN_VALUE;
                       dist = new FDistribution(numeratorDF, denominatorDF);
                       assertEquals(denominatorDF, dist.getDenominatorDegreesOfFreedom(), 0.0);
                       
                       // Test with large value
                       denominatorDF = Double.MAX_VALUE;
                       dist = new FDistribution(numeratorDF, denominatorDF);
                       assertEquals(denominatorDF, dist.getDenominatorDegreesOfFreedom(), 0.0);
                   }

 @Test
                  public void testGetDenominatorDegreesOfFreedomMethodSignature() throws Exception {
                      // Create an instance with arbitrary values
                      FDistribution dist = new FDistribution(2.0, 3.0);
                      
                      // Get the method via reflection
                      Method method = FDistribution.class.getMethod("getDenominatorDegreesOfFreedom");
                      
                      // Test that the method declaration string matches exactly (including whitespace)
                      assertEquals("public double getDenominatorDegreesOfFreedom()", 
                                  method.toString().replace("org.apache.commons.math3.distribution.", ""));
                      
                      // Also test the actual functionality works (though this wouldn't detect the whitespace change)
                      assertEquals(3.0, dist.getDenominatorDegreesOfFreedom(), 0.0001);
                  }

 @Test
                 public void testGetDenominatorDegreesOfFreedomReturnsExactValue() {
                     // Setup - create FDistribution with specific denominator degrees of freedom
                     double numeratorDof = 5.0;
                     double denominatorDof = 10.0;
                     FDistribution dist = new FDistribution(numeratorDof, denominatorDof);
                     
                     // Test - call the method
                     double result = dist.getDenominatorDegreesOfFreedom();
                     
                     // Verify - assert exact value is returned (not multiplied by 1)
                     assertEquals("Denominator degrees of freedom should return exact stored value", 
                                 denominatorDof, result, 0.0);
                 }

 @Test
                public void testGetDenominatorDegreesOfFreedomReturnsExactValue1() {
                    // Test with integer value
                    double testValue1 = 5.0;
                    FDistribution dist1 = new FDistribution(2.0, testValue1);
                    assertEquals("Should return exact denominator degrees of freedom for integer value",
                            testValue1, dist1.getDenominatorDegreesOfFreedom(), 0.0);
                    
                    // Test with non-integer value
                    double testValue2 = 5.5;
                    FDistribution dist2 = new FDistribution(2.0, testValue2);
                    assertEquals("Should return exact denominator degrees of freedom for non-integer value",
                            testValue2, dist2.getDenominatorDegreesOfFreedom(), 0.0);
                    
                    // Test with very small value
                    double testValue3 = Double.MIN_VALUE;
                    FDistribution dist3 = new FDistribution(2.0, testValue3);
                    assertEquals("Should return exact denominator degrees of freedom for very small value",
                            testValue3, dist3.getDenominatorDegreesOfFreedom(), 0.0);
                    
                    // Test with very large value
                    double testValue4 = Double.MAX_VALUE;
                    FDistribution dist4 = new FDistribution(2.0, testValue4);
                    assertEquals("Should return exact denominator degrees of freedom for very large value",
                            testValue4, dist4.getDenominatorDegreesOfFreedom(), 0.0);
                }

 @Test
               public void testGetDenominatorDegreesOfFreedomReturnsExactValue2() {
                   // Arrange
                   double numerator = 5.0;
                   double denominator = 10.0;
                   FDistribution fDist = new FDistribution(numerator, denominator);
                   
                   // Act
                   double result = fDist.getDenominatorDegreesOfFreedom();
                   
                   // Assert
                   assertEquals("Should return exact denominator value", 
                                denominator, result, 0.0001);
               }

 @Test
               public void testGetDenominatorDegreesOfFreedomWithDifferentValues() {
                   // Arrange
                   double numerator = 3.0;
                   double denominator1 = 7.5;
                   double denominator2 = 15.25;
                   
                   FDistribution fDist1 = new FDistribution(numerator, denominator1);
                   FDistribution fDist2 = new FDistribution(numerator, denominator2);
                   
                   // Act
                   double result1 = fDist1.getDenominatorDegreesOfFreedom();
                   double result2 = fDist2.getDenominatorDegreesOfFreedom();
                   
                   // Assert
                   assertEquals("Should return exact first denominator value", 
                                denominator1, result1, 0.0001);
                   assertEquals("Should return exact second denominator value", 
                                denominator2, result2, 0.0001);
               }

 @Test
              public void testGetDenominatorDegreesOfFreedom1() {
                  // Test with normal value
                  FDistribution dist = new FDistribution(5.0, 10.0);
                  assertEquals(10.0, dist.getDenominatorDegreesOfFreedom(), 0.0001);
                  
                  // Test with another value
                  FDistribution dist2 = new FDistribution(3.0, 7.5);
                  assertEquals(7.5, dist2.getDenominatorDegreesOfFreedom(), 0.0001);
                  
                  // Test with minimum valid value (just above 0)
                  FDistribution dist3 = new FDistribution(1.0, Double.MIN_VALUE);
                  assertEquals(Double.MIN_VALUE, dist3.getDenominatorDegreesOfFreedom(), 0.0);
              }

 @Test
             public void testGetDenominatorDegreesOfFreedom2() {
                 // Test with normal value
                 double testValue = 5.0;
                 FDistribution dist = new FDistribution(2.0, testValue);
                 assertEquals(testValue, dist.getDenominatorDegreesOfFreedom(), 0.0001);
                 
                 // Test with another value
                 testValue = 10.5;
                 dist = new FDistribution(3.0, testValue);
                 assertEquals(testValue, dist.getDenominatorDegreesOfFreedom(), 0.0001);
                 
                 // Test with edge case value
                 testValue = Double.MIN_VALUE;
                 dist = new FDistribution(1.0, testValue);
                 assertEquals(testValue, dist.getDenominatorDegreesOfFreedom(), 0.0001);
             }

 @Test
            public void testGetDenominatorDegreesOfFreedom3() {
                // Test with normal value
                double testDenominator = 5.0;
                FDistribution dist = new FDistribution(2.0, testDenominator);
                assertEquals("Denominator degrees of freedom should match exactly", 
                    testDenominator, 
                    dist.getDenominatorDegreesOfFreedom(), 
                    0.0);
                
                // Test with edge case value (minimum valid positive value)
                double edgeDenominator = Double.MIN_VALUE;
                FDistribution edgeDist = new FDistribution(2.0, edgeDenominator);
                assertEquals("Edge case denominator should match exactly",
                    edgeDenominator,
                    edgeDist.getDenominatorDegreesOfFreedom(),
                    0.0);
                    
                // Test with large value
                double largeDenominator = Double.MAX_VALUE;
                FDistribution largeDist = new FDistribution(2.0, largeDenominator);
                assertEquals("Large denominator should match exactly",
                    largeDenominator,
                    largeDist.getDenominatorDegreesOfFreedom(),
                    0.0);
            }

 @Test
           public void testGetDenominatorDegreesOfFreedom4() {
               // Test with normal positive value
               FDistribution dist1 = new FDistribution(5.0, 10.0);
               assertEquals(10.0, dist1.getDenominatorDegreesOfFreedom(), 0.0);
               
               // Test with very large value
               FDistribution dist2 = new FDistribution(5.0, Double.MAX_VALUE);
               assertEquals(Double.MAX_VALUE, dist2.getDenominatorDegreesOfFreedom(), 0.0);
               
               // Test with very small value
               FDistribution dist3 = new FDistribution(5.0, Double.MIN_VALUE);
               assertEquals(Double.MIN_VALUE, dist3.getDenominatorDegreesOfFreedom(), 0.0);
               
               // Test with fractional value
               FDistribution dist4 = new FDistribution(5.0, 7.5);
               assertEquals(7.5, dist4.getDenominatorDegreesOfFreedom(), 0.0);
               
               // Test with value that would show floating-point artifacts if divided
               FDistribution dist5 = new FDistribution(5.0, 0.1);
               assertEquals(0.1, dist5.getDenominatorDegreesOfFreedom(), 0.0);
           }

 @Test
          public void testGetDenominatorDegreesOfFreedomReturnsExactValue3() {
              // Test with normal positive value
              double testValue = 5.0;
              FDistribution dist = new FDistribution(2.0, testValue);
              assertEquals("Getter should return exact denominator degrees of freedom", 
                          testValue, 
                          dist.getDenominatorDegreesOfFreedom(), 
                          0.0);
              
              // Test with maximum double value to ensure no Math.abs transformation
              double maxValue = Double.MAX_VALUE;
              FDistribution distMax = new FDistribution(2.0, maxValue);
              assertEquals("Getter should return exact MAX_VALUE without transformation",
                          maxValue,
                          distMax.getDenominatorDegreesOfFreedom(),
                          0.0);
          }

 @Test
         public void testGetDenominatorDegreesOfFreedom5() {
             // Test with different valid denominator values
             double testValue1 = 5.0;
             FDistribution dist1 = new FDistribution(2.0, testValue1);
             assertEquals(testValue1, dist1.getDenominatorDegreesOfFreedom(), 0.0);
             
             double testValue2 = 10.5;
             FDistribution dist2 = new FDistribution(3.0, testValue2);
             assertEquals(testValue2, dist2.getDenominatorDegreesOfFreedom(), 0.0);
             
             // Test with minimum valid value (just above 0)
             double testValue3 = Double.MIN_VALUE;
             FDistribution dist3 = new FDistribution(1.0, testValue3);
             assertEquals(testValue3, dist3.getDenominatorDegreesOfFreedom(), 0.0);
         }

 @Test
        public void testGetDenominatorDegreesOfFreedom6() {
            // Test with different denominator values
            double testValue1 = 5.0;
            double testValue2 = 10.5;
            
            FDistribution dist1 = new FDistribution(2.0, testValue1);
            assertEquals("Getter should return constructor value", 
                        testValue1, 
                        dist1.getDenominatorDegreesOfFreedom(), 
                        0.0001);
            
            FDistribution dist2 = new FDistribution(3.0, testValue2);
            assertEquals("Getter should return constructor value", 
                        testValue2, 
                        dist2.getDenominatorDegreesOfFreedom(), 
                        0.0001);
        }

 @Test
       public void testGetDenominatorDegreesOfFreedomReturnsExactValue4() {
           // Arrange
           double numeratorDof = 5.0;
           double denominatorDof = 10.0;
           FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
           
           // Act
           double result = fDist.getDenominatorDegreesOfFreedom();
           
           // Assert
           assertEquals("Should return exact denominator degrees of freedom without modification", 
                        denominatorDof, result, 0.0);
       }

 @Test
      public void testGetDenominatorDegreesOfFreedomReturnsExactValue5() {
          // Setup - create FDistribution with specific denominator degrees of freedom
          double testDenominator = 5.67890123456789; // Using a precise value
          FDistribution fDist = new FDistribution(2.0, testDenominator);
          
          // Test - get the denominator degrees of freedom
          double result = fDist.getDenominatorDegreesOfFreedom();
          
          // Assert - verify exact same value is returned (delta=0 means exact match)
          assertEquals("Denominator degrees of freedom should return exact field value", 
                      testDenominator, result, 0.0);
          
          // Additional check - verify the bits are exactly the same
          assertTrue("Returned value should be exactly the same as field value",
                    Double.doubleToLongBits(testDenominator) == Double.doubleToLongBits(result));
      }

 @Test
     public void testGetDenominatorDegreesOfFreedomReturnsExactValue6() {
         // Setup - create FDistribution with specific denominator degrees of freedom
         double numeratorDof = 5.0;
         double denominatorDof = 10.0;
         FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
         
         // Test - verify getter returns exact value passed to constructor
         assertEquals("Getter should return exact denominator degrees of freedom value",
                      denominatorDof, 
                      fDist.getDenominatorDegreesOfFreedom(), 
                      0.0001);
         
         // Test with different value
         denominatorDof = 7.5;
         fDist = new FDistribution(numeratorDof, denominatorDof);
         assertEquals("Getter should return exact denominator degrees of freedom value",
                      denominatorDof, 
                      fDist.getDenominatorDegreesOfFreedom(), 
                      0.0001);
     }

}
