package gentest.org.apache.commons.math3.genetics.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.genetics.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
 
public class ListPopulationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                      public void testIterator_SingleChromosome() {
                                                                                                                                          // Create mock chromosome
                                                                                                                                          Chromosome mockChromosome1 = new Chromosome() {
                                                                                                                                              @Override
                                                                                                                                              public double fitness() {
                                                                                                                                                  return 0;
                                                                                                                                              }
                                                                                                                                          };
                                                                                                                                          
                                                                                                                                          // Initialize chromosomes list
                                                                                                                                          List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                                                                                          chromosomes.add(mockChromosome1);
                                                                                                                                          
                                                                                                                                          // Create population by implementing all abstract methods
                                                                                                                                          ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                                                              @Override
                                                                                                                                              public Population nextGeneration() {
                                                                                                                                                  return new ListPopulation(this.getChromosomes(), this.getPopulationLimit()) {
                                                                                                                                                      @Override
                                                                                                                                                      public Population nextGeneration() {
                                                                                                                                                          return null; // Dummy implementation
                                                                                                                                                      }
                                                                                                                                                  };
                                                                                                                                              }
                                                                                                                                          };
                                                                                                                                          
                                                                                                                                          // Test iterator
                                                                                                                                          Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                          assertTrue(iterator.hasNext());
                                                                                                                                          assertEquals(mockChromosome1, iterator.next());
                                                                                                                                          assertFalse(iterator.hasNext());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testIterator_MultipleChromosomes() {
                                                                                                                                          // Create mock chromosomes
                                                                                                                                          Chromosome mockChromosome1 = new Chromosome() {
                                                                                                                                              @Override
                                                                                                                                              public double fitness() {
                                                                                                                                                  return 0;
                                                                                                                                              }
                                                                                                                                          };
                                                                                                                                          Chromosome mockChromosome2 = new Chromosome() {
                                                                                                                                              @Override
                                                                                                                                              public double fitness() {
                                                                                                                                                  return 0;
                                                                                                                                              }
                                                                                                                                          };
                                                                                                                                          
                                                                                                                                          // Create chromosome list and population
                                                                                                                                          List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                                                                                          chromosomes.add(mockChromosome1);
                                                                                                                                          chromosomes.add(mockChromosome2);
                                                                                                                                          
                                                                                                                                          // Create concrete implementation of ListPopulation for testing
                                                                                                                                          ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                                                              @Override
                                                                                                                                              public Population nextGeneration() {
                                                                                                                                                  // Return a simple implementation for testing
                                                                                                                                                  return new ListPopulation(getPopulationLimit()) {
                                                                                                                                                      @Override
                                                                                                                                                      public Population nextGeneration() {
                                                                                                                                                          return null;
                                                                                                                                                      }
                                                                                                                                                  };
                                                                                                                                              }
                                                                                                                                          };
                                                                                                                                          
                                                                                                                                          // Test the iterator
                                                                                                                                          Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                          assertTrue(iterator.hasNext());
                                                                                                                                          assertEquals(mockChromosome1, iterator.next());
                                                                                                                                          assertTrue(iterator.hasNext());
                                                                                                                                          assertEquals(mockChromosome2, iterator.next());
                                                                                                                                          assertFalse(iterator.hasNext());
                                                                                                                                      }

    @Test
                                                                                                                                  public void testIterator_EmptyPopulation() {
                                                                                                                                      List<Chromosome> emptyList = Collections.emptyList();
                                                                                                                                      // Create an anonymous subclass of ListPopulation for testing
                                                                                                                                      ListPopulation population = new ListPopulation(emptyList, 10) {
                                                                                                                                          // Implement the abstract method
                                                                                                                                          @Override
                                                                                                                                          public Population nextGeneration() {
                                                                                                                                              return new ListPopulation(getPopulationLimit()) {
                                                                                                                                                  @Override
                                                                                                                                                  public Population nextGeneration() {
                                                                                                                                                      return null;
                                                                                                                                                  }
                                                                                                                                              };
                                                                                                                                          }
                                                                                                                                      };
                                                                                                                                      Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                      
                                                                                                                                      assertFalse(iterator.hasNext());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testIterator_RemoveOperationNotSupported() {
                                                                                                                                      List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                                                                                      Chromosome mockChromosome1 = new Chromosome() {
                                                                                                                                          @Override
                                                                                                                                          public double fitness() {
                                                                                                                                              return 0;
                                                                                                                                          }
                                                                                                                                      };
                                                                                                                                      chromosomes.add(mockChromosome1);
                                                                                                                                      
                                                                                                                                      // Create a concrete subclass of ListPopulation
                                                                                                                                      class ConcreteListPopulation extends ListPopulation {
                                                                                                                                          public ConcreteListPopulation(List<Chromosome> chromosomes, int populationLimit) {
                                                                                                                                              super(chromosomes, populationLimit);
                                                                                                                                          }
                                                                                                                                          
                                                                                                                                          @Override
                                                                                                                                          public Population nextGeneration() {
                                                                                                                                              return new ConcreteListPopulation(new ArrayList<Chromosome>(), getPopulationLimit());
                                                                                                                                          }
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      ListPopulation population = new ConcreteListPopulation(chromosomes, 10);
                                                                                                                                      
                                                                                                                                      Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                      iterator.next();
                                                                                                                                      
                                                                                                                                      thrown.expect(UnsupportedOperationException.class);
                                                                                                                                      iterator.remove();
                                                                                                                                  }

    @Test
                                                                                                      public void testIterator_AfterModification() {
                                                                                                          // Create mock chromosomes
                                                                                                          org.apache.commons.math3.genetics.Chromosome mockChromosome1 = new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                              @Override
                                                                                                              public double fitness() {
                                                                                                                  return 0;
                                                                                                              }
                                                                                                          };
                                                                                                          org.apache.commons.math3.genetics.Chromosome mockChromosome2 = new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                              @Override
                                                                                                              public double fitness() {
                                                                                                                  return 0;
                                                                                                              }
                                                                                                          };
                                                                                                          
                                                                                                          // Initialize chromosomes list
                                                                                                          java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
                                                                                                              new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
                                                                                                          chromosomes.add(mockChromosome1);
                                                                                                          
                                                                                                          // Create population using ListPopulation constructor
                                                                                                          org.apache.commons.math3.genetics.ListPopulation population = 
                                                                                                              new org.apache.commons.math3.genetics.ListPopulation(chromosomes, 10) {
                                                                                                                  // Implement abstract method nextGeneration
                                                                                                                  @Override
                                                                                                                  public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                                                                      return new org.apache.commons.math3.genetics.ListPopulation(this.getPopulationLimit()) {
                                                                                                                          @Override
                                                                                                                          public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                                                                              return null;
                                                                                                                          }
                                                                                                                      };
                                                                                                                  }
                                                                                                              };
                                                                                                          
                                                                                                          java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> iterator = population.iterator();
                                                                                                          population.addChromosome(mockChromosome2);
                                                                                                          
                                                                                                          try {
                                                                                                              iterator.hasNext();
                                                                                                              org.junit.Assert.fail("Expected ConcurrentModificationException");
                                                                                                          } catch (java.util.ConcurrentModificationException e) {
                                                                                                              // Expected exception
                                                                                                          }
                                                                                                      }

    @Test
                                                                                                  public void testIterator_VerifyNoMoreElements() {
                                                                                                      // Initialize required objects
                                                                                                      List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                                                      Chromosome mockChromosome1 = new Chromosome() {
                                                                                                          @Override
                                                                                                          public double fitness() {
                                                                                                              return 0;
                                                                                                          }
                                                                                                      };
                                                                                                      
                                                                                                      // Set up test data
                                                                                                      chromosomes.add(mockChromosome1);
                                                                                                      ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                          @Override
                                                                                                          public Population nextGeneration() {
                                                                                                              return null;
                                                                                                          }
                                                                                                      };
                                                                                                      
                                                                                                      // Test iterator behavior
                                                                                                      Iterator<Chromosome> iterator = population.iterator();
                                                                                                      iterator.next();  // Consume the only element
                                                                                                      
                                                                                                      // Verify exception when no more elements
                                                                                                      try {
                                                                                                          iterator.next();
                                                                                                          fail("Expected NoSuchElementException");
                                                                                                      } catch (java.util.NoSuchElementException e) {
                                                                                                          // Expected exception
                                                                                                      }
                                                                                                  }

    @Test
                                                                                     public void testIteratorReturnsRegularIteratorNotListIterator() {
                                                                                         // Setup test data
                                                                                         List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                                         chromosomes.add(mock(Chromosome.class));
                                                                                         chromosomes.add(mock(Chromosome.class));
                                                                                         
                                                                                         // Create a concrete subclass since ListPopulation is abstract
                                                                                         ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                             // Implement abstract method
                                                                                             @Override
                                                                                             public Population nextGeneration() {
                                                                                                 return null; // Simple implementation for test purposes
                                                                                             }
                                                                                         };
                                                                                         
                                                                                         // Get the iterator
                                                                                         Iterator<Chromosome> iterator = population.iterator();
                                                                                         
                                                                                         // Verify it's not a ListIterator
                                                                                         assertFalse("Iterator should not be a ListIterator", 
                                                                                                    iterator instanceof java.util.ListIterator);
                                                                                         
                                                                                         // Verify basic iteration works
                                                                                         assertTrue(iterator.hasNext());
                                                                                         assertNotNull(iterator.next());
                                                                                     }

    @Test
                                                                        public void testIteratorReturnsListIteratorNotStreamIterator() {
                                                                            // Setup test data
                                                                            List<Chromosome> chromosomes = new ArrayList<>();
                                                                            chromosomes.add(mock(Chromosome.class));
                                                                            chromosomes.add(mock(Chromosome.class));
                                                                            
                                                                            // Create a concrete subclass of ListPopulation for testing
                                                                            ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                @Override
                                                                                public Population nextGeneration() {
                                                                                    // Create a new anonymous subclass for the return value
                                                                                    return new ListPopulation(getChromosomes(), getPopulationLimit()) {
                                                                                        @Override
                                                                                        public Population nextGeneration() {
                                                                                            return null; // simple implementation
                                                                                        }
                                                                                    };
                                                                                }
                                                                            };
                                                                            
                                                                            // Get the iterator
                                                                            Iterator<Chromosome> iterator = population.iterator();
                                                                            
                                                                            // Verify it's a List iterator, not a Stream iterator
                                                                            // The stream iterator would be of type SpliteratorIterator or similar
                                                                            assertTrue("Iterator should be from List, not Stream", 
                                                                                       iterator.getClass().getName().contains("ArrayList$Itr"));
                                                                            
                                                                            // Also verify basic iteration works as expected
                                                                            assertTrue(iterator.hasNext());
                                                                            assertNotNull(iterator.next());
                                                                            assertTrue(iterator.hasNext());
                                                                            assertNotNull(iterator.next());
                                                                            assertFalse(iterator.hasNext());
                                                                        }

    @Test
                                                       public void testIteratorMaintainsOrder() {
                                                           // Setup test data
                                                           org.apache.commons.math3.genetics.Chromosome c1 = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                                           org.apache.commons.math3.genetics.Chromosome c2 = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                                           org.apache.commons.math3.genetics.Chromosome c3 = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                                           List<org.apache.commons.math3.genetics.Chromosome> chromosomes = new ArrayList<org.apache.commons.math3.genetics.Chromosome>();
                                                           chromosomes.add(c1);
                                                           chromosomes.add(c2);
                                                           chromosomes.add(c3);
                                                           
                                                           // Create population with known order - need to use a concrete subclass since ListPopulation is abstract
                                                           ListPopulation population = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomes, 3, 0.1) {
                                                               @Override
                                                               public Population nextGeneration() {
                                                                   ListPopulation nextGen = new org.apache.commons.math3.genetics.ElitisticListPopulation(this.getPopulationLimit(), 0.1);
                                                                   nextGen.addChromosomes(this.getChromosomes());
                                                                   return nextGen;
                                                               }
                                                           };
                                                           population.addChromosomes(chromosomes);
                                                           
                                                           // Get iterator and verify order
                                                           Iterator<org.apache.commons.math3.genetics.Chromosome> iterator = population.iterator();
                                                           assertSame("First element should be c1", c1, iterator.next());
                                                           assertSame("Second element should be c2", c2, iterator.next());
                                                           assertSame("Third element should be c3", c3, iterator.next());
                                                           assertFalse("Iterator should be exhausted", iterator.hasNext());
                                                       }

    @Test
                                              public void testIteratorBehaviorWithConcurrentModification() {
                                                  // Setup - create a population with some chromosomes
                                                  List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                  chromosomes.add(mock(Chromosome.class));
                                                  chromosomes.add(mock(Chromosome.class));
                                                  ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                      // Implement abstract method from Population
                                                      @Override
                                                      public Population nextGeneration() {
                                                          return null; // Simple implementation for test purposes
                                                      }
                                                  };
                                                  
                                                  // Get the iterator
                                                  Iterator<Chromosome> iterator = population.iterator();
                                                  
                                                  // Modify the underlying list
                                                  population.addChromosome(mock(Chromosome.class));
                                                  
                                                  // Try to use the iterator - should fail with ConcurrentModificationException
                                                  try {
                                                      iterator.next();
                                                      fail("Expected ConcurrentModificationException");
                                                  } catch (java.util.ConcurrentModificationException e) {
                                                      // This is expected behavior for the original implementation
                                                      // The mutated version with stream() may or may not throw this
                                                  }
                                                  
                                                  // Additional verification - check if iterator is from ArrayList directly
                                                  // The original implementation's iterator should be ArrayList's iterator
                                                  Iterator<Chromosome> directIterator = population.getChromosomes().iterator();
                                                  assertEquals("Iterator should be the same implementation as List's iterator",
                                                             directIterator.getClass(), iterator.getClass());
                                              }

    @Test
             public void testIteratorMaintainsOriginalOrder() {
                 // Create sample chromosomes with known order
                 Chromosome c1 = new Chromosome() {
                     @Override
                     public double fitness() {
                         return 0;
                     }
                 };
                 Chromosome c2 = new Chromosome() {
                     @Override
                     public double fitness() {
                         return 0;
                     }
                 };
                 Chromosome c3 = new Chromosome() {
                     @Override
                     public double fitness() {
                         return 0;
                     }
                 };
                 List<Chromosome> chromosomes = java.util.Arrays.asList(c1, c2, c3);
                 
                 // Create population with these chromosomes
                 ListPopulation population = new ListPopulation(chromosomes, 3) {
                     @Override
                     public Population nextGeneration() {
                         return null; // Implement abstract method
                     }
                 };
                 
                 // Iterate and collect results
                 java.util.Iterator<Chromosome> it = population.iterator();
                 org.junit.Assert.assertEquals(c1, it.next());
                 org.junit.Assert.assertEquals(c2, it.next());
                 org.junit.Assert.assertEquals(c3, it.next());
                 org.junit.Assert.assertFalse(it.hasNext());
                 
                 // Also verify the iteration order matches getChromosomes() order
                 java.util.Iterator<Chromosome> expected = population.getChromosomes().iterator();
                 it = population.iterator();
                 while (expected.hasNext()) {
                     org.junit.Assert.assertTrue(it.hasNext());
                     org.junit.Assert.assertEquals(expected.next(), it.next());
                 }
                 org.junit.Assert.assertFalse(it.hasNext());
             }

    @Test
    public void testIteratorReturnsChromosomeIterator() {
        // Setup test data
        List<Chromosome> chromosomes = new ArrayList<>();
        chromosomes.add(mock(Chromosome.class));
        chromosomes.add(mock(Chromosome.class));
        
        // Create concrete subclass of ListPopulation for testing
        class ConcreteListPopulation extends ListPopulation {
            public ConcreteListPopulation(List<Chromosome> chromosomes, int populationLimit) {
                super(chromosomes, populationLimit);
            }
            
            @Override
            public Population nextGeneration() {
                // Simple implementation just for testing
                return new ConcreteListPopulation(new ArrayList<Chromosome>(), getPopulationLimit());
            }
        }
        
        // Create population with test chromosomes
        ConcreteListPopulation population = new ConcreteListPopulation(chromosomes, 10);
        
        // Call iterator() method
        Iterator<Chromosome> iterator = population.iterator();
        
        // Verify return type is Iterator
        assertNotNull(iterator);
        
        // Verify iterator contains our test chromosomes
        assertSame(chromosomes.get(0), iterator.next());
        assertSame(chromosomes.get(1), iterator.next());
        assertFalse(iterator.hasNext());
        
        // Additional check to ensure we're not getting toString() result
        assertNotEquals(population.toString(), iterator);
    }


}
