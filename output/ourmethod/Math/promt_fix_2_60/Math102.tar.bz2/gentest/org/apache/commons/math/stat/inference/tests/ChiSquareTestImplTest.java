package gentest.org.apache.commons.math.stat.inference.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.inference.*;
import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.ChiSquaredDistribution;
import org.apache.commons.math.distribution.ChiSquaredDistributionImpl;
import org.apache.commons.math.distribution.DistributionFactory;
 
public class ChiSquareTestImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                        public void testChiSquare_ValidInputs_NoRescaling() {
                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                            double[] expected = {10.0, 20.0, 30.0};
                                            long[] observed = {12, 18, 32};
                                            
                                            double result = chiSquareTest.chiSquare(expected, observed);
                                            
                                            // Manually calculated expected value
                                            double expectedChiSquare = 
                                                Math.pow(12-10, 2)/10 + 
                                                Math.pow(18-20, 2)/20 + 
                                                Math.pow(32-30, 2)/30;
                                            assertEquals(expectedChiSquare, result, 1E-10);
                                        }

 @Test
                                        public void testChiSquare_ValidInputs_WithRescaling() {
                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                            double[] expected = {10.0, 20.0, 30.0};
                                            long[] observed = {6, 12, 18}; // Sum is 36 vs expected sum of 60
                                            
                                            double result = chiSquareTest.chiSquare(expected, observed);
                                            
                                            // Manually calculated expected value with rescaling
                                            double ratio = 36.0/60.0;
                                            double expectedChiSquare = 
                                                Math.pow(6 - (10*ratio), 2)/(10*ratio) + 
                                                Math.pow(12 - (20*ratio), 2)/(20*ratio) + 
                                                Math.pow(18 - (30*ratio), 2)/(30*ratio);
                                            assertEquals(expectedChiSquare, result, 1E-10);
                                        }

 @Test
                                        public void testChiSquare_ExpectedArrayTooShort() {
                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                            double[] expected = {10.0}; // Only 1 element
                                            long[] observed = {12, 18};
                                            
                                            thrown.expect(IllegalArgumentException.class);
                                            thrown.expectMessage("observed, expected array lengths incorrect");
                                            
                                            chiSquareTest.chiSquare(expected, observed);
                                        }

 @Test
                                        public void testChiSquare_ArrayLengthMismatch() {
                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                            double[] expected = {10.0, 20.0};
                                            long[] observed = {12, 18, 32}; // Different lengths
                                            
                                            thrown.expect(IllegalArgumentException.class);
                                            thrown.expectMessage("observed, expected array lengths incorrect");
                                            
                                            chiSquareTest.chiSquare(expected, observed);
                                        }

 @Test
                                        public void testChiSquare_NegativeObservedValue() {
                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                            double[] expected = {10.0, 20.0};
                                            long[] observed = {12, -1}; // Negative observed value
                                            
                                            thrown.expect(IllegalArgumentException.class);
                                            thrown.expectMessage("observed counts must be non-negative and expected counts must be postive");
                                            
                                            chiSquareTest.chiSquare(expected, observed);
                                        }

 @Test
                                        public void testChiSquare_NonPositiveExpectedValue() {
                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                            double[] expected = {10.0, 0.0}; // Zero expected value
                                            long[] observed = {12, 18};
                                            
                                            thrown.expect(IllegalArgumentException.class);
                                            thrown.expectMessage("observed counts must be non-negative and expected counts must be postive");
                                            
                                            chiSquareTest.chiSquare(expected, observed);
                                        }

 @Test
                                        public void testChiSquare_WithMockedDistribution() {
                                            // Mock the ChiSquaredDistribution dependency
                                            ChiSquaredDistribution mockDistribution = mock(ChiSquaredDistribution.class);
                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl(mockDistribution);
                                            
                                            double[] expected = {10.0, 20.0};
                                            long[] observed = {12, 18};
                                            
                                            double result = chiSquareTest.chiSquare(expected, observed);
                                            
                                            // Verify the calculation is correct regardless of the distribution
                                            double expectedChiSquare = 
                                                Math.pow(12-10, 2)/10 + 
                                                Math.pow(18-20, 2)/20;
                                            assertEquals(expectedChiSquare, result, 1E-10);
                                        }

 @Test
                                        public void testChiSquare_EdgeCase_ZeroObserved() {
                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                            double[] expected = {10.0, 20.0, 30.0};
                                            long[] observed = {0, 0, 0}; // All zeros
                                            
                                            double result = chiSquareTest.chiSquare(expected, observed);
                                            
                                            // With all zeros, ratio will be 0 and rescaling will occur
                                            double ratio = 0.0;
                                            double expectedChiSquare = 
                                                Math.pow(0 - (10*ratio), 2)/(10*ratio) + 
                                                Math.pow(0 - (20*ratio), 2)/(20*ratio) + 
                                                Math.pow(0 - (30*ratio), 2)/(30*ratio);
                                            // Note: This would actually result in NaN due to division by zero
                                            assertTrue(Double.isNaN(result));
                                        }

 @Test
                                public void testChiSquare_EdgeCase_LargeValues() {
                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                    double[] expected = {1E6, 2E6, 3E6};
                                    long[] observed = {(long)(1E6+100), (long)(2E6-200), (long)(3E6+100)};
                                    
                                    double result = chiSquareTest.chiSquare(expected, observed);
                                    
                                    // Verify calculation with large numbers
                                    double expectedChiSquare = 
                                        Math.pow(100, 2)/1E6 + 
                                        Math.pow(-200, 2)/2E6 + 
                                        Math.pow(100, 2)/3E6;
                                    assertEquals(expectedChiSquare, result, 1E-10);
                                }

 @Test
                                public void testChiSquare_3x2ContingencyTable() {
                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                    long[][] counts = {{5, 10}, {15, 20}, {25, 30}};
                                    
                                    double result = chiSquareTest.chiSquare(counts);
                                    
                                    // Expected calculations:
                                    // Row sums: 15, 35, 55
                                    // Column sums: 45, 60
                                    // Total: 105
                                    // Expected values:
                                    // (15*45)/105≈6.4286, (15*60)/105≈8.5714
                                    // (35*45)/105=15, (35*60)/105=20
                                    // (55*45)/105≈23.5714, (55*60)/105≈31.4286
                                    // Chi-square components sum to ≈0.4082
                                    assertEquals(0.4082, result, 0.0001);
                                }

 @Test
                                public void testChiSquare_AllValuesEqual() {
                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                    long[][] counts = {{5, 5}, {5, 5}};
                                    
                                    double result = chiSquareTest.chiSquare(counts);
                                    
                                    // Expected chi-square is 0 since observed equals expected
                                    assertEquals(0.0, result, 0.0001);
                                }

 @Test
                                public void testChiSquare_SingleCell() {
                                    long[][] counts = {{5}};
                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                    
                                    double result = chiSquareTest.chiSquare(counts);
                                    
                                    // Expected chi-square is 0 for single cell
                                    assertEquals(0.0, result, 0.0001);
                                }

 @Test
                                public void testChiSquare_WithZeroValues() {
                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                    long[][] counts = {{0, 10}, {10, 0}};
                                    
                                    double result = chiSquareTest.chiSquare(counts);
                                    
                                    // Expected calculations:
                                    // Row sums: 10, 10
                                    // Column sums: 10, 10
                                    // Total: 20
                                    // Expected values: all 5
                                    // Chi-square components sum to 10
                                    assertEquals(10.0, result, 0.0001);
                                }

 @Test
                                public void testChiSquare_NonRectangularArray() {
                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                    long[][] counts = {{1, 2}, {3}};
                                    
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("Not rectangular");
                                    chiSquareTest.chiSquare(counts);
                                }

 @Test
                                public void testChiSquare_NullInput() {
                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                    ExpectedException thrown = ExpectedException.none();
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("Null array");
                                    chiSquareTest.chiSquare((long[][]) null);
                                }

 @Test(expected = IllegalArgumentException.class)
                                public void testChiSquare_EmptyRow() {
                                    long[][] counts = {{}, {1, 2}};
                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                    chiSquareTest.chiSquare(counts);
                                }

 @Test
                                public void testChiSquare_NegativeValues() {
                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                    long[][] counts = {{1, -2}, {3, 4}};
                                    
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("Negative entry");
                                    chiSquareTest.chiSquare(counts);
                                }

 @Test
                            public void testChiSquare_2x2ContingencyTable() {
                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                long[][] counts = {{10, 20}, {30, 40}};
                                
                                double result = chiSquareTest.chiSquare(counts);
                                
                                // Expected calculations:
                                // Row sums: 30, 70
                                // Column sums: 40, 60
                                // Total: 100
                                // Expected values:
                                // (30*40)/100=12, (30*60)/100=18
                                // (70*40)/100=28, (70*60)/100=42
                                // Chi-square components:
                                // (10-12)²/12 + (20-18)²/18 + (30-28)²/28 + (40-42)²/42 ≈ 0.5442
                                assertEquals(0.5442, result, 0.0001);
                            }

 @Test
                            public void testChiSquare_EmptyInput() {
                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                long[][] counts = {};
                                
                                ExpectedException thrown = ExpectedException.none();
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("Empty array");
                                chiSquareTest.chiSquare(counts);
                            }

 @Test(expected = IllegalArgumentException.class)
                        public void testChiSquareWithSingleElementArrayShouldThrowException() {
                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                            
                            // Create arrays with length 1 (invalid for chi-square)
                            double[] expected = new double[]{1.0};
                            long[] observed = new long[]{1L};
                            
                            try {
                                chiSquareTest.chiSquare(expected, observed);
                                fail("Expected IllegalArgumentException for array length < 2");
                            } catch (IllegalArgumentException e) {
                                // Verify the exception message contains the expected text
                                assertTrue(e.getMessage().contains("observed, expected array lengths incorrect"));
                                throw e;
                            }
                        }

 @Test
                       public void testChiSquareWithSingleElementArray() {
                           // This test will catch the mutant as the original should reject length 1 arrays
                           long[] observed = new long[]{10L};
                           double[] expected = new double[]{10.0};
                           
                           ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                           
                           try {
                               chiSquareTest.chiSquare(expected, observed);
                               fail("Expected IllegalArgumentException");
                           } catch (IllegalArgumentException e) {
                               // Expected exception
                           }
                       }

 @Test
                       public void testChiSquareWithValidArrays() {
                           // Valid case with length 2 arrays
                           long[] observed = new long[]{10L, 20L};
                           double[] expected = new double[]{10.0, 20.0};
                           
                           // Create instance of ChiSquareTestImpl
                           ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                           
                           double result = chiSquareTest.chiSquare(expected, observed);
                           // Just verify it runs without exception
                           assertTrue(result >= 0);
                       }

 @Test(expected = IllegalArgumentException.class)
                       public void testChiSquareWithDifferentLengthArrays() {
                           // Arrays of different lengths should be rejected
                           ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                           long[] observed = new long[]{10L, 20L};
                           double[] expected = new double[]{10.0};
                           
                           chiSquareTest.chiSquare(expected, observed);
                       }

 @Test
                   public void testChiSquareWithRescalingDetectsRatioMutant() {
                       // Setup
                       ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                       double[] expected = {10.0, 20.0, 30.0};  // Sum = 60
                       long[] observed = {15L, 25L, 35L};       // Sum = 75 (different from expected)
                       
                       // Test - should calculate properly with rescaling
                       double result = chiSquareTest.chiSquare(expected, observed);
                       
                       // Verify - we don't need exact value, just ensure it's calculated
                       // The mutant would throw ArithmeticException due to division by zero
                       assertTrue("Result should be positive", result > 0);
                       
                       // Additional verification - check calculation is correct
                       // Expected calculation:
                       // ratio = 75/60 = 1.25
                       // For first element: (15 - 1.25*10)^2/(1.25*10) = (2.5)^2/12.5 = 0.5
                       // Second element: (25 - 1.25*20)^2/(1.25*20) = 0
                       // Third element: (35 - 1.25*30)^2/(1.25*30) ≈ (-2.5)^2/37.5 ≈ 0.1667
                       // Total ≈ 0.5 + 0 + 0.1667 ≈ 0.6667
                       assertEquals(0.6667, result, 0.0001);
                   }

 @Test
                   public void testChiSquareDetectsRatioMutation() {
                       // Setup
                       ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                       long[][] counts = {
                           {10, 10, 20},
                           {20, 20, 10}
                       };
                       
                       // Expected value calculated manually or from known correct implementation
                       double expectedChiSquare = 6.249999999999999;
                       
                       // Execute
                       double result = chiSquareTest.chiSquare(counts);
                       
                       // Verify
                       assertEquals("Chi-square value should match expected calculation", 
                                   expectedChiSquare, result, 1e-10);
                       
                       // Additional verification that ratio isn't zero by checking non-zero result
                       assertTrue("Result should be positive for this input", result > 0);
                   }

 @Test
                  public void testChiSquareWithEqualSumsShouldNotRescale() {
                      // Setup - create arrays where sums are equal (within tolerance)
                      double[] expected = {10.0, 20.0, 30.0};  // Sum = 60.0
                      long[] observed = {10L, 20L, 30L};       // Sum = 60.0
                      
                      // Create instance (using default constructor)
                      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                      
                      // Calculate expected result (using ratio=1.0)
                      double expectedResult = 0.0;  // Since observed exactly matches expected
                      
                      // Call method and assert
                      double actualResult = chiSquareTest.chiSquare(expected, observed);
                      assertEquals("Chi-square should be 0 when observed exactly matches expected", 
                                   expectedResult, actualResult, 1E-10);
                      
                      // Additional verification - with small differences that shouldn't trigger rescaling
                      long[] observed2 = {11L, 19L, 30L};  // Sum still 60.0
                      double expectedResult2 = (1*1)/10.0 + (1*1)/20.0;  // Only first two values differ
                      
                      double actualResult2 = chiSquareTest.chiSquare(expected, observed2);
                      assertEquals("Chi-square calculation incorrect with small differences", 
                                   expectedResult2, actualResult2, 1E-10);
                  }

 @Test
                  public void testChiSquareDetectsRatioMutation1() {
                      // Setup
                      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                      long[][] counts = {{10, 10}, {20, 20}}; // Simple 2x2 table
                      
                      // Expected calculation:
                      // Row sums: 20, 40
                      // Col sums: 30, 30
                      // Total: 60
                      // Expected values: all cells = (rowSum*colSum)/total
                      // For all cells: (20*30)/60 = 10, (40*30)/60 = 20
                      // Chi-square = 4*((10-10)^2/10) = 0 (all cells same as expected)
                      
                      // Execute
                      double result = chiSquareTest.chiSquare(counts);
                      
                      // Verify
                      assertEquals("Chi-square value should be 0 for perfect fit", 
                                  0.0, result, 0.0001);
                      
                      // If mutation exists (ratio=2.0), result would be 0*2=0, so this test wouldn't catch it
                      // Therefore we need a case where chi-square is not 0
                      
                      // Second test case with different values
                      long[][] counts2 = {{10, 20}, {10, 20}};
                      // Expected values:
                      // (30*20)/60 = 10, (30*40)/60 = 20
                      // (30*20)/60 = 10, (30*40)/60 = 20
                      // Chi-square = ((10-10)^2/10) + ((20-20)^2/20) + ((10-10)^2/10) + ((20-20)^2/20) = 0
                      
                      // Still 0, need a better test case
                      
                      // Third test case that will produce non-zero chi-square
                      long[][] counts3 = {{5, 15}, {10, 20}};
                      // Row sums: 20, 30
                      // Col sums: 15, 35
                      // Total: 50
                      // Expected:
                      // (20*15)/50=6, (20*35)/50=14
                      // (30*15)/50=9, (30*35)/50=21
                      // Chi-square:
                      // ((5-6)^2/6) + ((15-14)^2/14) + ((10-9)^2/9) + ((20-21)^2/21)
                      // = (1/6) + (1/14) + (1/9) + (1/21) ≈ 0.1667 + 0.0714 + 0.1111 + 0.0476 ≈ 0.3968
                      
                      double result3 = chiSquareTest.chiSquare(counts3);
                      assertEquals("Chi-square value should match manual calculation", 
                                  0.3968, result3, 0.0001);
                      
                      // If mutation exists (ratio=2.0), result would be 0.3968*2=0.7936
                      // which would fail the assertion
                  }

 @Test
                 public void testChiSquareNoRescalingNeeded() {
                     // Setup
                     ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                     double[] expected = {10.0, 20.0, 30.0};  // Sum = 60.0
                     long[] observed = {10L, 20L, 30L};       // Sum = 60.0
                     
                     // Expected calculation without rescaling
                     double expectedSumSq = 0.0;
                     for (int i = 0; i < observed.length; i++) {
                         double dev = observed[i] - expected[i];
                         expectedSumSq += dev * dev / expected[i];
                     }
                     
                     // Execute and verify
                     double actualSumSq = chiSquareTest.chiSquare(expected, observed);
                     assertEquals("Should not rescale when sums are equal", 
                                  expectedSumSq, actualSumSq, 1E-10);
                     
                     // For mutant detection: This will fail when rescale is forced to true
                     // because the ratio (1.0) would still be applied unnecessarily
                     // The values would be the same but the code path is different
                 }

 @Test
                 public void testChiSquareWithRescaling() {
                     // Create test instance
                     ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                     
                     // Create a simple 2x2 contingency table
                     long[][] counts = {
                         {10, 20},
                         {30, 40}
                     };
                     
                     // Calculate expected chi-square value without rescaling
                     // Manual calculation:
                     // Row sums: 30, 70
                     // Column sums: 40, 60
                     // Total: 100
                     // Expected values:
                     // [0][0]: (30*40)/100 = 12
                     // [0][1]: (30*60)/100 = 18
                     // [1][0]: (70*40)/100 = 28
                     // [1][1]: (70*60)/100 = 42
                     // Chi-square components:
                     // (10-12)^2/12 = 0.333
                     // (20-18)^2/18 = 0.222
                     // (30-28)^2/28 = 0.143
                     // (40-42)^2/42 = 0.095
                     // Sum: 0.333 + 0.222 + 0.143 + 0.095 = 0.793
                     double expected = 0.7936507936507936;
                     
                     // Calculate actual value
                     double actual = chiSquareTest.chiSquare(counts);
                     
                     // Verify with delta to account for floating point precision
                     assertEquals("Chi-square value should match expected calculation", 
                                 expected, actual, 1e-10);
                     
                     // If rescale=true was active, the result would likely be different
                     // This test would fail if rescaling was applied
                 }

 @Test
                public void testChiSquareRescalingBoundaryCondition() {
                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                    
                    // Create test data where sum difference is exactly 10E-6
                    double[] expected = new double[]{1.0, 1.0 + 10E-6/2};
                    long[] observed = new long[]{1, 1};
                    
                    // Calculate expected sums
                    double sumExpected = 0d;
                    double sumObserved = 0d;
                    for (int i = 0; i < observed.length; i++) {
                        sumExpected += expected[i];
                        sumObserved += observed[i];
                    }
                    
                    // Verify our test data meets the boundary condition
                    assertEquals(10E-6, Math.abs(sumExpected - sumObserved), 0.0);
                    
                    // Calculate expected result without rescaling (original behavior)
                    double expectedSumSq = 0.0;
                    for (int i = 0; i < observed.length; i++) {
                        double dev = observed[i] - expected[i];
                        expectedSumSq += dev * dev / expected[i];
                    }
                    
                    // Test the method
                    double result = chiSquareTest.chiSquare(expected, observed);
                    
                    // Assert the result matches non-rescaled calculation
                    // This will fail for the mutant (which would rescale)
                    assertEquals(expectedSumSq, result, 10E-10);
                }

 @Test
                public void testChiSquareWithExactThresholdDifference() {
                    // Create test instance
                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                    
                    // Create input data where the difference will be exactly 10E-6
                    // We need to carefully construct counts that will produce this exact difference
                    long[][] counts = new long[][] {
                        {1000000, 1000000},
                        {1000000, 1000001}  // Slight difference to create exact threshold case
                    };
                    
                    // Calculate expected chi-square value
                    double result = chiSquareTest.chiSquare(counts);
                    
                    // Verify the result is calculated correctly (not affected by the mutation)
                    // The exact expected value would need to be calculated, but we know it should be > 0
                    assertTrue(result > 0);
                    
                    // The key assertion is that the method processes the input correctly
                    // without being affected by the mutation in the comparison logic
                    // We can verify by checking against a known good implementation or expected value
                    
                    // For this specific case, we know the sums should be consistent
                    double[] rowSum = new double[2];
                    double[] colSum = new double[2];
                    double total = 0.0;
                    for (int row = 0; row < 2; row++) {
                        for (int col = 0; col < 2; col++) {
                            rowSum[row] += counts[row][col];
                            colSum[col] += counts[row][col];
                            total += counts[row][col];
                        }
                    }
                    
                    // Verify the sums are calculated correctly (this would fail if the mutation affected the summation)
                    assertEquals(2000000.0, rowSum[0], 0.0);
                    assertEquals(2000001.0, rowSum[1], 0.0);
                    assertEquals(2000000.0, colSum[0], 0.0);
                    assertEquals(2000001.0, colSum[1], 0.0);
                    assertEquals(4000001.0, total, 0.0);
                }

 @Test
               public void testChiSquareWithLargeButEqualSums() {
                   // Setup
                   ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                   double[] expected = {500000.0, 500000.0};  // Sum = 1,000,000
                   long[] observed = {500000L, 500000L};      // Sum = 1,000,000
                   
                   // Difference is 0 (shouldn't rescale), but sum is 2,000,000 (> 1e-6)
                   // Mutant would incorrectly trigger rescaling
                   
                   // Execute
                   double result = chiSquareTest.chiSquare(expected, observed);
                   
                   // Verify - with no rescaling, calculation should be:
                   // (500000-500000)²/500000 + (500000-500000)²/500000 = 0 + 0 = 0
                   assertEquals(0.0, result, 1e-10);
                   
                   // If mutant was present, it would incorrectly rescale and compute differently
                   // (though in this case result would still be 0 by coincidence)
                   // So let's also test with slightly different values
                   
                   double[] expected2 = {500000.0, 500000.0};
                   long[] observed2 = {500001L, 499999L};  // Sum still 1,000,000
                   
                   double result2 = chiSquareTest.chiSquare(expected2, observed2);
                   
                   // Without rescaling:
                   // (500001-500000)²/500000 + (499999-500000)²/500000 = 1/500000 + 1/500000 = 4e-6
                   assertEquals(4e-6, result2, 1e-10);
                   
                   // With mutant's incorrect rescaling (ratio would be 1.0):
                   // Would still get same result by coincidence, so need another test
                   
                   double[] expected3 = {1000000.0, 1000000.0};  // Sum = 2,000,000
                   long[] observed3 = {1000001L, 999999L};       // Sum = 2,000,000
                   
                   double result3 = chiSquareTest.chiSquare(expected3, observed3);
                   
                   // Without rescaling:
                   // (1000001-1000000)²/1000000 + (999999-1000000)²/1000000 = 1/1e6 + 1/1e6 = 2e-6
                   assertEquals(2e-6, result3, 1e-10);
                   
                   // With mutant's incorrect rescaling (ratio would be 1.0):
                   // Would still get same result, so we need to verify the internal behavior
                   
                   // Alternative approach - test with values where rescaling would produce different results
                   double[] expected4 = {2.0, 3.0};  // Sum = 5.0
                   long[] observed4 = {3L, 2L};      // Sum = 5.0
                   
                   double result4 = chiSquareTest.chiSquare(expected4, observed4);
                   
                   // Without rescaling:
                   // (3-2)²/2 + (2-3)²/3 = 1/2 + 1/3 = 0.5 + 0.333... = 0.833...
                   assertEquals(0.8333333333333333, result4, 1e-10);
                   
                   // With mutant's incorrect rescaling (ratio would be 1.0):
                   // Would produce same result, so this mutant is particularly tricky
                   
                   // Final verification - use values where sums are equal but large,
                   // and the mutant would incorrectly trigger rescaling
                   // Though in this implementation, rescaling with ratio=1 produces same result
                   // This suggests the mutant might be equivalent (hard to kill)
                   // Therefore we need to modify our approach
                   
                   // More effective test - use values where sums differ slightly (but < 1e-6)
                   double[] expected5 = {1.000001, 1.000001};
                   long[] observed5 = {1L, 1L};  // difference is ~2e-6, but mutant would use sum ~2.000002
                   
                   double result5 = chiSquareTest.chiSquare(expected5, observed5);
                   
                   // Original would not rescale (difference < 1e-6)
                   // Mutant would rescale (sum > 1e-6)
                   // Calculation without rescaling:
                   // (1-1.000001)²/1.000001 + (1-1.000001)²/1.000001 ≈ 2e-12
                   assertEquals(2e-12, result5, 1e-14);
               }

 @Test
               public void testChiSquareSumValidation() {
                   ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                   
                   // Create a contingency table where row/column sums don't match
                   // This should be caught by the original check but might pass mutant
                   long[][] counts = {
                       {10, 20, 30},  // row sum = 60
                       {20, 30, 40}    // row sum = 90
                   };                  // col sums = 30, 50, 70 (total=150)
                   
                   // The original should detect sum mismatch (60+90 != 30+50+70)
                   // But mutant might pass if |60+90+30+50+70| < 10E-6
                   
                   try {
                       chiSquareTest.chiSquare(counts);
                       fail("Expected IllegalArgumentException for sum mismatch");
                   } catch (IllegalArgumentException e) {
                       // Expected behavior - original would throw this
                       assertTrue(e.getMessage().contains("sum mismatch"));
                   }
                   
                   // Also test with correct sums that should pass validation
                   long[][] validCounts = {
                       {10, 20, 30},  // row sum = 60
                       {20, 30, 10}    // row sum = 60
                   };                  // col sums = 30, 50, 40 (total=120)
                   
                   double result = chiSquareTest.chiSquare(validCounts);
                   assertTrue(result >= 0);  // chi-square should always be >= 0
               }

 @Test
              public void testChiSquareNoRescalingNeeded1() {
                  // Setup - create test instance
                  ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                  
                  // Input where sums are equal (difference < 10E-6)
                  double[] expected = {10.0, 10.0, 10.0}; // sum = 30.0
                  long[] observed = {10L, 10L, 10L};      // sum = 30.0
                  
                  // Calculate expected result without rescaling
                  double expectedSumSq = 0.0;
                  for (int i = 0; i < observed.length; i++) {
                      double dev = observed[i] - expected[i];
                      expectedSumSq += dev * dev / expected[i];
                  }
                  
                  // Call method and get actual result
                  double actualSumSq = chiSquareTest.chiSquare(expected, observed);
                  
                  // Assert - should match non-rescaled calculation
                  assertEquals(expectedSumSq, actualSumSq, 1E-10);
                  
                  // With the mutant, actualSumSq would be different because:
                  // - It would use rescaling (ratio = 1.0)
                  // - But due to floating point precision, the calculation would differ slightly
                  // This assertion would fail with the mutant
              }

 @Test(expected = IllegalArgumentException.class)
              public void testChiSquareWithInvalidSumsShouldThrowException() {
                  // Create a test case where row/column sums don't properly correspond
                  // This should make sumExpected != sumObserved
                  long[][] counts = new long[][] {
                      {10, 20, 30},  // row sum = 60
                      {20, 30, 40}    // row sum = 90
                  };
                  // Column sums: 30, 50, 70
                  // Total sum is 150, but if we manipulate expected values calculation,
                  // the validation should fail
                  
                  ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                  
                  // This should throw IllegalArgumentException in original code
                  // but the mutant would proceed with calculation
                  chiSquareTest.chiSquare(counts);
                  
                  // If we reach here, the mutant survived (failed to throw exception)
                  // So we need to force a failure
                  fail("Expected IllegalArgumentException but none was thrown");
              }

 @Test
             public void testChiSquareDevInitialization() {
                 ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                 
                 // Test case where rescale is false
                 double[] expected = {2.0, 3.0};
                 long[] observed = {1L, 4L};
                 
                 // Calculate expected result manually
                 double expectedSumSq = 0.0;
                 for (int i = 0; i < observed.length; i++) {
                     double dev = observed[i] - expected[i];
                     expectedSumSq += dev * dev / expected[i];
                 }
                 
                 // The mutant would incorrectly add 1.0 to each dev calculation
                 double actual = chiSquareTest.chiSquare(expected, observed);
                 
                 // Verify the calculation is precise
                 assertEquals(expectedSumSq, actual, 1e-10);
                 
                 // Test case where rescale is true
                 double[] expected2 = {2.0, 3.0};
                 long[] observed2 = {10L, 15L}; // Sums differ forcing rescale
                 
                 // Calculate expected result manually with rescaling
                 double sumExpected = 0d;
                 double sumObserved = 0d;
                 for (int i = 0; i < observed2.length; i++) {
                     sumExpected += expected2[i];
                     sumObserved += observed2[i];
                 }
                 double ratio = sumObserved / sumExpected;
                 double expectedSumSq2 = 0.0;
                 for (int i = 0; i < observed2.length; i++) {
                     double dev = observed2[i] - ratio * expected2[i];
                     expectedSumSq2 += dev * dev / (ratio * expected2[i]);
                 }
                 
                 double actual2 = chiSquareTest.chiSquare(expected2, observed2);
                 assertEquals(expectedSumSq2, actual2, 1e-10);
             }

 @Test
             public void testChiSquareCalculation() {
                 // Setup
                 ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                 long[][] counts = {
                     {10, 20},
                     {30, 40}
                 };
                 
                 // Expected value calculated manually:
                 // Row sums: 30, 70
                 // Column sums: 40, 60
                 // Total: 100
                 // Expected values:
                 // [12, 18]
                 // [28, 42]
                 // Chi-square components:
                 // (10-12)²/12 + (20-18)²/18 + (30-28)²/28 + (40-42)²/42
                 // = 4/12 + 4/18 + 4/28 + 4/42 ≈ 0.79365079
                 
                 // Action
                 double result = chiSquareTest.chiSquare(counts);
                 
                 // Assertion
                 assertEquals(0.79365079, result, 1e-8);
                 
                 // This test would catch the mutation because any change in initialization
                 // that affects the calculation would make the result differ from the
                 // expected value we calculated manually
             }

 @Test
            public void testChiSquareWithDifferentObservedExpectedLengths() {
                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                
                // Create a 2x3 contingency table where expected array would be different size
                long[][] counts = {
                    {10, 20, 30},
                    {15, 25, 35}
                };
                
                // Calculate expected chi-square value manually for verification
                double expectedChiSquare = 0.0;
                
                // Manually compute row sums, column sums and total
                double[] rowSum = new double[2];
                double[] colSum = new double[3];
                double total = 0.0;
                
                for (int row = 0; row < 2; row++) {
                    for (int col = 0; col < 3; col++) {
                        rowSum[row] += counts[row][col];
                        colSum[col] += counts[row][col];
                        total += counts[row][col];
                    }
                }
                
                // Manually compute chi-square
                for (int row = 0; row < 2; row++) {
                    for (int col = 0; col < 3; col++) {
                        double expected = (rowSum[row] * colSum[col]) / total;
                        expectedChiSquare += Math.pow(counts[row][col] - expected, 2) / expected;
                    }
                }
                
                // The test will fail with the mutant because:
                // - observed.length is 2 (rows)
                // - expected.length would be 3 (columns)
                // Mutant would try to loop up to expected.length (3) for rows, causing ArrayIndexOutOfBoundsException
                double actualChiSquare = chiSquareTest.chiSquare(counts);
                
                assertEquals(expectedChiSquare, actualChiSquare, 0.0001);
            }

 @Test
           public void testChiSquareWithDifferentLengthArrays1() throws Exception {
               // Create instance of the class under test
               ChiSquareTestImpl testImpl = new ChiSquareTestImpl();
               
               // Create arrays where observed.length != expected.length
               double[] expected = new double[]{1.0, 2.0, 3.0}; // length 3
               long[] observed = new long[]{1L, 2L}; // length 2
               
               // Use reflection to bypass the length check validation
               Method method = ChiSquareTestImpl.class.getDeclaredMethod(
                   "chiSquare", double[].class, long[].class);
               method.setAccessible(true);
               
               try {
                   // This should throw ArrayIndexOutOfBoundsException with the mutant
                   // but work fine with original code
                   double result = (double) method.invoke(testImpl, expected, observed);
                   
                   // If we get here, the test failed to catch the mutant
                   fail("Expected ArrayIndexOutOfBoundsException but got result: " + result);
               } catch (InvocationTargetException e) {
                   // Check if the cause is ArrayIndexOutOfBoundsException
                   assertTrue("Expected ArrayIndexOutOfBoundsException", 
                             e.getCause() instanceof ArrayIndexOutOfBoundsException);
               }
           }

 @Test
       public void testChiSquareNoRescalingNeeded2() {
           // Setup
           ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
           double[] expected = new double[]{10.0, 20.0, 30.0};
           long[] observed = new long[]{10, 20, 30}; // Sums are equal (60), no rescaling needed
           
           // Expected calculation without rescaling
           double expectedSumSq = 0.0;
           for (int i = 0; i < observed.length; i++) {
               double dev = observed[i] - expected[i];
               expectedSumSq += dev * dev / expected[i];
           }
           
           // Actual calculation
           double actualSumSq = chiSquareTest.chiSquare(expected, observed);
           
           // Verify
           assertEquals("Chi-square should match expected calculation", 
                       expectedSumSq, actualSumSq, 1E-10);
           
           // Now test with sums not equal but very close (within 10E-6)
           // This would trigger rescaling in original but not in mutant
           double[] expected2 = new double[]{10.0, 20.0, 30.0000001}; // sum = 60.0000001
           long[] observed2 = new long[]{10, 20, 30}; // sum = 60 (diff = 1E-7 < 10E-6)
           
           // Original would not rescale, mutant would rescale
           double actualSumSq2 = chiSquareTest.chiSquare(expected2, observed2);
           double expectedSumSq2 = 0.0;
           for (int i = 0; i < observed2.length; i++) {
               double dev = observed2[i] - expected2[i];
               expectedSumSq2 += dev * dev / expected2[i];
           }
           
           assertEquals("Chi-square should not rescale for small differences",
                       expectedSumSq2, actualSumSq2, 1E-10);
       }

 @Test
       public void testChiSquareContingencyTableBoundaryConditions() {
           ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
           
           // Test case that would catch boundary condition issues
           long[][] counts1 = {
               {10, 20},
               {30, 40}
           };
           double result1 = chiSquareTest.chiSquare(counts1);
           assertTrue("Chi-square value should be positive", result1 > 0);
           
           // Test with very small counts that might trigger rescaling
           long[][] counts2 = {
               {1, 1},
               {1, 1}
           };
           double result2 = chiSquareTest.chiSquare(counts2);
           assertTrue("Chi-square value should handle small counts", result2 >= 0);
           
           // Test with zero counts (should still work)
           long[][] counts3 = {
               {0, 10},
               {10, 0}
           };
           double result3 = chiSquareTest.chiSquare(counts3);
           assertTrue("Chi-square should handle zero counts", result3 >= 0);
           
           // Test rectangular array
           long[][] counts4 = {
               {5, 5, 5},
               {5, 5, 5}
           };
           double result4 = chiSquareTest.chiSquare(counts4);
           assertTrue("Chi-square should work with rectangular arrays", result4 == 0);
       }

 @Test
      public void testChiSquareWithRescalingDetectsSubtractionMutant() {
          // Setup
          ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
          double[] expected = {10.0, 20.0, 30.0};  // Sum = 60
          long[] observed = {15L, 25L, 35L};       // Sum = 75 (different from expected)
          
          // Execute
          double result = chiSquareTest.chiSquare(expected, observed);
          
          // Verify
          // Original code would return positive sum of squared terms
          // Mutant would return negative value due to subtraction
          assertTrue("Chi-square result should be positive", result > 0);
          
          // Additional verification of actual value (optional but good practice)
          double expectedValue = 0.0;
          double ratio = 75.0 / 60.0;  // sumObserved/sumExpected
          for (int i = 0; i < observed.length; i++) {
              double dev = observed[i] - ratio * expected[i];
              expectedValue += dev * dev / (ratio * expected[i]);
          }
          assertEquals(expectedValue, result, 1E-10);
      }

 @Test
      public void testChiSquarePositiveResult() {
          // Setup
          ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
          long[][] counts = new long[][] {
              {10, 20},
              {30, 40}
          };
          
          // Expected calculation:
          // Row sums: 30, 70
          // Column sums: 40, 60
          // Total: 100
          // Expected values:
          // [0][0]: (30*40)/100 = 12
          // [0][1]: (30*60)/100 = 18
          // [1][0]: (70*40)/100 = 28
          // [1][1]: (70*60)/100 = 42
          // Chi-square components:
          // (10-12)²/12 = 0.333
          // (20-18)²/18 = 0.222
          // (30-28)²/28 = 0.143
          // (40-42)²/42 = 0.095
          // Total expected: ~0.333 + 0.222 + 0.143 + 0.095 = ~0.793
          
          // Execute
          double result = chiSquareTest.chiSquare(counts);
          
          // Verify
          // 1. Result should be positive (catches the -= mutant)
          assertTrue("Chi-square result should be positive", result > 0);
          
          // 2. Result should match our manual calculation (with some tolerance)
          assertEquals(0.793, result, 0.001);
          
          // 3. Verify it's not negative (explicit check for the mutant)
          assertFalse("Chi-square result should not be negative", result < 0);
      }

 @Test
     public void testChiSquareRescaleWithMultipleElements() {
         ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
         
         // Create test data where rescaling will be needed (sums differ)
         double[] expected = {10.0, 20.0, 30.0};  // sum = 60
         long[] observed = {15L, 25L, 35L};       // sum = 75
         
         // Calculate expected value manually
         double ratio = 75.0 / 60.0;  // 1.25
         double expectedSumSq = 0.0;
         for (int i = 0; i < observed.length; i++) {
             double dev = observed[i] - ratio * expected[i];
             expectedSumSq += dev * dev / (ratio * expected[i]);
         }
         
         // Call method and assert
         double actualSumSq = chiSquareTest.chiSquare(expected, observed);
         assertEquals("Chi-square sum should accumulate all deviations", 
                      expectedSumSq, actualSumSq, 1E-10);
     }

 @Test
     public void testChiSquareDetectsSumAccumulationMutant() {
         // Create a test instance
         ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
         
         // Create a 2x2 contingency table where multiple cells contribute
         long[][] counts = new long[][] {
             {10, 20},
             {30, 40}
         };
         
         // Calculate expected value manually
         // Row sums: 30, 70
         // Column sums: 40, 60
         // Total: 100
         // Expected values:
         // Cell[0][0]: (30*40)/100 = 12
         // Cell[0][1]: (30*60)/100 = 18
         // Cell[1][0]: (70*40)/100 = 28
         // Cell[1][1]: (70*60)/100 = 42
         // Chi-square components:
         // (10-12)²/12 = 0.333...
         // (20-18)²/18 = 0.222...
         // (30-28)²/28 = 0.142...
         // (40-42)²/42 = 0.095...
         // Total expected chi-square: ~0.333 + 0.222 + 0.142 + 0.095 = ~0.792
         
         double result = chiSquareTest.chiSquare(counts);
         
         // Verify the result includes all components
         // The mutated version would only return the last component (~0.095)
         // We use delta of 0.001 for floating point comparison
         assertEquals(0.792, result, 0.001);
         
         // Additional assertion to ensure it's not just the last component
         assertTrue(result > 0.5); // Should be true for original, false for mutant
     }

 @Test
    public void testChiSquareWithRescalingDetectsSquaredDeviationMutant() {
        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
        
        // Create test data where sums differ (forcing rescaling)
        double[] expected = {10.0, 20.0, 30.0};  // Sum = 60
        long[] observed = {12L, 18L, 35L};       // Sum = 65 (different from expected)
        
        // Calculate expected value manually
        double ratio = 65.0 / 60.0;
        double expectedSumSq = 0.0;
        for (int i = 0; i < observed.length; i++) {
            double dev = observed[i] - ratio * expected[i];
            expectedSumSq += dev * dev / (ratio * expected[i]);
        }
        
        // Call method and assert
        double actualSumSq = chiSquareTest.chiSquare(expected, observed);
        
        // This will fail if the mutant is present because:
        // Original: sums (dev * dev) / (ratio*expected)
        // Mutant: sums dev / (ratio*expected)
        assertEquals(expectedSumSq, actualSumSq, 1e-10);
        
        // Additional check that the value is non-zero (we have actual deviations)
        assertTrue(actualSumSq > 0);
    }

 @Test
    public void testChiSquareDetectsSquaredDifferenceMutation() {
        // Create a simple 2x2 contingency table where we can manually calculate expected values
        long[][] counts = {
            {10, 20},
            {30, 40}
        };
        
        // Expected row sums: 30, 70
        // Expected column sums: 40, 60
        // Total: 100
        
        // Manually calculate expected values and chi-square contributions:
        // Cell (0,0): expected = (30*40)/100 = 12, contribution = (10-12)^2/12 = 4/12 = 0.333...
        // Cell (0,1): expected = (30*60)/100 = 18, contribution = (20-18)^2/18 = 4/18 = 0.222...
        // Cell (1,0): expected = (70*40)/100 = 28, contribution = (30-28)^2/28 = 4/28 = 0.142...
        // Cell (1,1): expected = (70*60)/100 = 42, contribution = (40-42)^2/42 = 4/42 = 0.095...
        // Total expected chi-square: 0.333 + 0.222 + 0.142 + 0.095 = ~0.792
        
        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
        double result = chiSquareTest.chiSquare(counts);
        
        // With the mutation, the result would be:
        // (10-12)/12 + (20-18)/18 + (30-28)/28 + (40-42)/42 = -0.166 + 0.111 + 0.071 - 0.047 = -0.031
        // So we can assert the result should be positive and approximately 0.792
        
        // Check the result is positive (mutant would give negative)
        assertTrue(result > 0);
        
        // Check the value is approximately correct (with some tolerance for floating point)
        assertEquals(0.792, result, 0.001);
        
        // Additional check that the result isn't too small (mutant would give much smaller absolute value)
        assertTrue(result > 0.5);
    }

 @Test
   public void testChiSquareEqualSumsButDifferentValues() {
       ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
       
       // Arrays with equal sums but different individual values
       double[] expected = new double[]{10.0, 20.0, 30.0}; // sum = 60
       long[] observed = new long[]{15, 15, 30}; // sum = 60
       
       // Calculate expected result manually
       double expectedSumSq = 0.0;
       for (int i = 0; i < observed.length; i++) {
           double dev = observed[i] - expected[i];
           expectedSumSq += dev * dev / expected[i];
       }
       
       // With mutation, it would incorrectly use ratio (1.0) scaling
       // The result would be same as correct calculation in this case
       // But we need a case where ratio*expected differs from expected
       
       // So let's try another case
       expected = new double[]{5.0, 10.0, 15.0}; // sum = 30
       observed = new long[]{8, 8, 14}; // sum = 30
       
       expectedSumSq = 0.0;
       for (int i = 0; i < observed.length; i++) {
           double dev = observed[i] - expected[i];
           expectedSumSq += dev * dev / expected[i];
       }
       
       double result = chiSquareTest.chiSquare(expected, observed);
       
       // The mutation would calculate:
       // dev = observed[i] - 1.0*expected[i] (same as correct)
       // So it wouldn't be caught. Need a better test case
       
       // Better test case - use arrays where rescale=false but mutation would affect result
       // Actually, since ratio is 1.0 when rescale=false, the mutation has no effect
       // This explains why it wasn't caught before
       
       // Therefore, we need to test the case where rescale=true but sums are very close
       // to trigger the rescaling logic while keeping ratio close to 1.0
       expected = new double[]{10.0, 20.0, 30.00001}; // sum = 60.00001
       observed = new long[]{15, 15, 30}; // sum = 60
       
       // Correct calculation would use rescaling
       double sumExpected = 60.00001;
       double sumObserved = 60;
       double ratio = sumObserved / sumExpected;
       
       expectedSumSq = 0.0;
       for (int i = 0; i < observed.length; i++) {
           double dev = observed[i] - (i == 2 ? ratio * expected[i] : expected[i]);
           expectedSumSq += dev * dev / (i == 2 ? ratio * expected[i] : expected[i]);
       }
       
       result = chiSquareTest.chiSquare(expected, observed);
       assertEquals(expectedSumSq, result, 1E-10);
   }

 @Test
   public void testRescaleFlagBehavior() {
       ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
       
       // Case where sums are exactly equal (rescale=false)
       double[] expected1 = {10.0, 20.0, 30.0};
       long[] observed1 = {15, 15, 30};
       double result1 = chiSquareTest.chiSquare(expected1, observed1);
       
       // Case where sums differ slightly (rescale=true)
       double[] expected2 = {10.0, 20.0, 30.00001};
       long[] observed2 = {15, 15, 30};
       double result2 = chiSquareTest.chiSquare(expected2, observed2);
       
       // Results should be different
       assertNotEquals(result1, result2, 1E-10);
   }

 @Test
       public void testChiSquareDetectsMutant() {
           // Create a simple 2x2 contingency table where we can manually compute expected values
           long[][] counts = {
               {10, 20},
               {30, 40}
           };
           
           // Manually compute expected values:
           // Row sums: 30, 70
           // Column sums: 40, 60
           // Total: 100
           // Expected values:
           // [0][0]: 30*40/100 = 12
           // [0][1]: 30*60/100 = 18
           // [1][0]: 70*40/100 = 28
           // [1][1]: 70*60/100 = 42
           
           // Manually compute chi-square:
           // (10-12)^2/12 + (20-18)^2/18 + (30-28)^2/28 + (40-42)^2/42
           // = 4/12 + 4/18 + 4/28 + 4/42 ≈ 0.7937
           
           ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
           double result = chiSquareTest.chiSquare(counts);
           
           // The mutant would multiply expected by some ratio, making the result different
           assertEquals(0.7937, result, 0.0001);
           
           // Additional test case with all equal expected/observed to ensure 0 result
           long[][] perfectFit = {
               {5, 5},
               {5, 5}
           };
           assertEquals(0.0, chiSquareTest.chiSquare(perfectFit), 0.0001);
       }

 @Test
  public void testChiSquareRescalingThreshold() {
      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
      
      // Test case where difference is between 10E-6 and 10E-5
      // Should trigger rescaling in mutant but not original
      double[] expected = new double[]{1.000005, 1.000005}; // sum = 2.00001
      long[] observed = new long[]{1, 1};                   // sum = 2.0
      double diff = Math.abs(2.00001 - 2.0); // 0.00001
      
      // Verify the difference is in our target range
      assertTrue(diff > 10E-6);  // Original would rescale
      assertTrue(diff <= 10E-5);  // Mutant would NOT rescale
      
      // Calculate with and without rescaling to verify behavior
      double noRescaleResult = 0.0;
      for (int i = 0; i < observed.length; i++) {
          double dev = observed[i] - expected[i];
          noRescaleResult += dev * dev / expected[i];
      }
      
      double ratio = 2.0 / 2.00001;
      double rescaleResult = 0.0;
      for (int i = 0; i < observed.length; i++) {
          double dev = observed[i] - ratio * expected[i];
          rescaleResult += dev * dev / (ratio * expected[i]);
      }
      
      // The original would use rescaleResult (since diff > 10E-6)
      // The mutant would use noRescaleResult (since diff <= 10E-5)
      double originalResult = chiSquareTest.chiSquare(expected, observed);
      
      // Assert that the result matches the rescale calculation
      // This will fail for the mutant since it won't rescale
      assertEquals(rescaleResult, originalResult, 10E-10);
  }

 @Test
  public void testChiSquarePrecisionThreshold() {
      // Create a test case where the difference is between 10E-6 and 10E-5
      long[][] counts = new long[][] {
          {1000000, 1000000},
          {1000000, 1000000 + 6}  // Difference of 6 in last cell (6/1e6 = 6e-6)
      };
      
      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
      double result = chiSquareTest.chiSquare(counts);
      
      // The exact expected value needs to be calculated, but we know it should be > 0
      // and sensitive to the small difference we introduced
      assertTrue("Chi-square value should be greater than 0", result > 0);
      
      // More precise assertion would require calculating exact expected value
      double expected = 6.0 / 1000000;  // Approximate expected chi-square value
      assertEquals(expected, result, 1e-8);
      
      // The key is that with the original precision (1e-6), this difference matters
      // With the mutant precision (1e-5), it might be ignored
  }

 @Test
 public void testChiSquareWithSmallDifference() {
     // Setup test data where difference is between 10E-7 and 10E-6
     double[] expected = new double[]{1.0, 1.0000005}; // sum = 2.0000005
     long[] observed = new long[]{1, 1};               // sum = 2
     // Difference is 0.0000005 (5E-7) which is > 10E-7 but < 10E-6
     
     ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
     
     // Calculate expected result without rescaling (original behavior)
     double expectedSumSq = 0.0;
     for (int i = 0; i < observed.length; i++) {
         double dev = observed[i] - expected[i];
         expectedSumSq += dev * dev / expected[i];
     }
     
     // Calculate actual result
     double actualSumSq = chiSquareTest.chiSquare(expected, observed);
     
     // Verify results are different (mutant would rescale, original wouldn't)
     assertNotEquals("Mutant should be detected - results should differ due to different rescaling behavior",
                    expectedSumSq, actualSumSq, 0.00001);
     
     // Additional verification that mutant would rescale
     // With rescaling, ratio would be sumObserved/sumExpected = 2/2.0000005
     double expectedRescaledSumSq = 0.0;
     double ratio = 2.0 / 2.0000005;
     for (int i = 0; i < observed.length; i++) {
         double dev = observed[i] - ratio * expected[i];
         expectedRescaledSumSq += dev * dev / (ratio * expected[i]);
     }
     
     assertEquals("Mutant should use rescaled calculation",
                 expectedRescaledSumSq, actualSumSq, 0.00001);
 }

 @Test
 public void testChiSquareWithSmallDifference1() {
     ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
     
     // Create input where sumExpected and sumObserved differ by ~5E-7
     long[][] counts = new long[][] {
         {1000000, 1000000},
         {1000000, 1000005}  // Small difference in one cell
     };
     
     double result = chiSquareTest.chiSquare(counts);
     
     // Verify the result is calculated correctly
     // With original threshold, this would pass
     // With mutated threshold, this would fail
     double expectedRowSum1 = counts[0][0] + counts[0][1];
     double expectedRowSum2 = counts[1][0] + counts[1][1];
     double expectedColSum1 = counts[0][0] + counts[1][0];
     double expectedColSum2 = counts[0][1] + counts[1][1];
     double total = expectedRowSum1 + expectedRowSum2;
     
     double expected11 = (expectedRowSum1 * expectedColSum1) / total;
     double expected12 = (expectedRowSum1 * expectedColSum2) / total;
     double expected21 = (expectedRowSum2 * expectedColSum1) / total;
     double expected22 = (expectedRowSum2 * expectedColSum2) / total;
     
     double expectedSumSq = 
         Math.pow(counts[0][0] - expected11, 2) / expected11 +
         Math.pow(counts[0][1] - expected12, 2) / expected12 +
         Math.pow(counts[1][0] - expected21, 2) / expected21 +
         Math.pow(counts[1][1] - expected22, 2) / expected22;
     
     assertEquals(expectedSumSq, result, 1E-10);
 }

}
