package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import org.apache.commons.math.MathRuntimeException;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                            public void testDistance_TypicalCases() {
                                                                                                                                                                // Test with 2D coordinates
                                                                                                                                                                double[] point1 = {1.0, 2.0};
                                                                                                                                                                double[] point2 = {4.0, 6.0};
                                                                                                                                                                assertEquals(5.0, MathUtils.distance(point1, point2), 0.0001);
                                                                                                                                                                
                                                                                                                                                                // Test with 3D coordinates
                                                                                                                                                                double[] point3 = {1.0, 2.0, 3.0};
                                                                                                                                                                double[] point4 = {4.0, 5.0, 6.0};
                                                                                                                                                                assertEquals(Math.sqrt(27), MathUtils.distance(point3, point4), 0.0001);
                                                                                                                                                                
                                                                                                                                                                // Test with negative coordinates
                                                                                                                                                                double[] point5 = {-1.0, -2.0};
                                                                                                                                                                double[] point6 = {-4.0, -6.0};
                                                                                                                                                                assertEquals(5.0, MathUtils.distance(point5, point6), 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_ZeroDistance() {
                                                                                                                                                                // Test with identical points
                                                                                                                                                                double[] point1 = {3.0, 4.0, 5.0};
                                                                                                                                                                double[] point2 = {3.0, 4.0, 5.0};
                                                                                                                                                                assertEquals(0.0, MathUtils.distance(point1, point2), 0.0001);
                                                                                                                                                                
                                                                                                                                                                // Test with zero vectors
                                                                                                                                                                double[] zeroVector = {0.0, 0.0, 0.0};
                                                                                                                                                                assertEquals(0.0, MathUtils.distance(zeroVector, zeroVector), 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_SingleDimension() {
                                                                                                                                                                // Test with 1D points
                                                                                                                                                                double[] point1 = {5.0};
                                                                                                                                                                double[] point2 = {9.0};
                                                                                                                                                                assertEquals(4.0, MathUtils.distance(point1, point2), 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_ExtremeValues() {
                                                                                                                                                                // Test with very large values
                                                                                                                                                                double[] large1 = {Double.MAX_VALUE, Double.MAX_VALUE};
                                                                                                                                                                double[] large2 = {Double.MAX_VALUE/2, Double.MAX_VALUE/2};
                                                                                                                                                                assertEquals(Double.MAX_VALUE/Math.sqrt(2), MathUtils.distance(large1, large2), 1e292);
                                                                                                                                                                
                                                                                                                                                                // Test with very small values
                                                                                                                                                                double[] small1 = {Double.MIN_VALUE, Double.MIN_VALUE};
                                                                                                                                                                double[] small2 = {Double.MIN_VALUE*2, Double.MIN_VALUE*2};
                                                                                                                                                                assertEquals(Double.MIN_VALUE*Math.sqrt(2), MathUtils.distance(small1, small2), 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_WithNaNValues() {
                                                                                                                                                                double[] nanPoint = {Double.NaN, 2.0};
                                                                                                                                                                double[] validPoint = {1.0, 2.0};
                                                                                                                                                                
                                                                                                                                                                assertEquals(Double.NaN, MathUtils.distance(nanPoint, validPoint), 0.0001);
                                                                                                                                                                assertEquals(Double.NaN, MathUtils.distance(validPoint, nanPoint), 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_WithInfiniteValues() {
                                                                                                                                                                double[] infPoint = {Double.POSITIVE_INFINITY, 2.0};
                                                                                                                                                                double[] validPoint = {1.0, 2.0};
                                                                                                                                                                
                                                                                                                                                                assertEquals(Double.POSITIVE_INFINITY, MathUtils.distance(infPoint, validPoint), 0.0001);
                                                                                                                                                                assertEquals(Double.POSITIVE_INFINITY, MathUtils.distance(validPoint, infPoint), 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_TypicalCase() {
                                                                                                                                                                double[] p1 = {1.0, 2.0, 3.0};
                                                                                                                                                                double[] p2 = {4.0, 6.0, 9.0};
                                                                                                                                                                double expected = Math.sqrt((1-4)*(1-4) + (2-6)*(2-6) + (3-9)*(3-9));
                                                                                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                                                                                assertEquals(expected, result, 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_ZeroDistance1() {
                                                                                                                                                                double[] p1 = {5.0, 3.0, 2.0};
                                                                                                                                                                double[] p2 = {5.0, 3.0, 2.0};
                                                                                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                                                                                assertEquals(0.0, result, 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_NegativeCoordinates() {
                                                                                                                                                                double[] p1 = {-1.0, -2.0, -3.0};
                                                                                                                                                                double[] p2 = {-4.0, -6.0, -9.0};
                                                                                                                                                                double expected = Math.sqrt((-1+4)*(-1+4) + (-2+6)*(-2+6) + (-3+9)*(-3+9));
                                                                                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                                                                                assertEquals(expected, result, 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_MixedSignCoordinates() {
                                                                                                                                                                double[] p1 = {-1.0, 2.0, -3.0};
                                                                                                                                                                double[] p2 = {4.0, -6.0, 9.0};
                                                                                                                                                                double expected = Math.sqrt((-1-4)*(-1-4) + (2+6)*(2+6) + (-3-9)*(-3-9));
                                                                                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                                                                                assertEquals(expected, result, 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_SingleDimension1() {
                                                                                                                                                                double[] p1 = {5.0};
                                                                                                                                                                double[] p2 = {9.0};
                                                                                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                                                                                assertEquals(4.0, result, 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_HighDimensionalSpace() {
                                                                                                                                                                double[] p1 = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0};
                                                                                                                                                                double[] p2 = {11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0};
                                                                                                                                                                double sum = 0;
                                                                                                                                                                for (int i = 0; i < 10; i++) {
                                                                                                                                                                    sum += (10.0 * 10.0);
                                                                                                                                                                }
                                                                                                                                                                double expected = Math.sqrt(sum);
                                                                                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                                                                                assertEquals(expected, result, 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_WithNaNValues1() {
                                                                                                                                                                double[] p1 = {1.0, Double.NaN, 3.0};
                                                                                                                                                                double[] p2 = {4.0, 6.0, 9.0};
                                                                                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                                                                                assertTrue(Double.isNaN(result));
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_WithInfiniteValues1() {
                                                                                                                                                                double[] p1 = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                                                                                                                                double[] p2 = {4.0, 6.0, 9.0};
                                                                                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                                                                                assertEquals(Double.POSITIVE_INFINITY, result, 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_WithMixedInfiniteValues() {
                                                                                                                                                                double[] p1 = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                                                                                                                                double[] p2 = {4.0, Double.NEGATIVE_INFINITY, 9.0};
                                                                                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                                                                                assertEquals(Double.POSITIVE_INFINITY, result, 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_VerySmallValues() {
                                                                                                                                                                double[] p1 = {Double.MIN_VALUE, Double.MIN_VALUE};
                                                                                                                                                                double[] p2 = {Double.MIN_VALUE * 2, Double.MIN_VALUE * 2};
                                                                                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                                                                                assertTrue(result > 0 && result < Double.MIN_NORMAL);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testDistance_VeryLargeValues() {
                                                                                                                                                                double[] p1 = {Double.MAX_VALUE, Double.MAX_VALUE};
                                                                                                                                                                double[] p2 = {Double.MAX_VALUE / 2, Double.MAX_VALUE / 2};
                                                                                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                                                                                assertEquals(Double.POSITIVE_INFINITY, result, 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                    public void testDistance_DifferentLengthArrays() {
                                                                                                                                                        ExpectedException exceptionRule = ExpectedException.none();
                                                                                                                                                        exceptionRule.expect(IllegalArgumentException.class);
                                                                                                                                                        exceptionRule.expectMessage("Arrays must have the same length");
                                                                                                                                                        
                                                                                                                                                        double[] point1 = {1.0, 2.0};
                                                                                                                                                        double[] point2 = {1.0, 2.0, 3.0};
                                                                                                                                                        MathUtils.distance(point1, point2);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testDistance_EmptyArrays() {
                                                                                                                                                        ExpectedException exceptionRule = ExpectedException.none();
                                                                                                                                                        exceptionRule.expect(IllegalArgumentException.class);
                                                                                                                                                        exceptionRule.expectMessage("Arrays cannot be empty");
                                                                                                                                                        
                                                                                                                                                        double[] empty1 = {};
                                                                                                                                                        double[] empty2 = {};
                                                                                                                                                        MathUtils.distance(empty1, empty2);
                                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                public void testDistance_NullArrays() {
                                                                                                                                                    double[] validPoint = {1.0, 2.0};
                                                                                                                                                    MathUtils.distance(null, validPoint);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testDistance_FirstArrayNull() {
                                                                                                                                                    org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                                                                                                                                    exceptionRule.expect(NullPointerException.class);
                                                                                                                                                    exceptionRule.expectMessage("Points arrays must not be null");
                                                                                                                                                    double[] p1 = null;
                                                                                                                                                    double[] p2 = {1.0, 2.0, 3.0};
                                                                                                                                                    org.apache.commons.math.util.MathUtils.distance(p1, p2);
                                                                                                                                                }

    @Test(expected = NullPointerException.class)
                                                                                                                                                public void testDistance_SecondArrayNull() {
                                                                                                                                                    double[] p1 = {1.0, 2.0, 3.0};
                                                                                                                                                    double[] p2 = null;
                                                                                                                                                    MathUtils.distance(p1, p2);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testDistance_DifferentLengthArrays1() {
                                                                                                                                                    try {
                                                                                                                                                        double[] p1 = {1.0, 2.0, 3.0};
                                                                                                                                                        double[] p2 = {4.0, 5.0};
                                                                                                                                                        MathUtils.distance(p1, p2);
                                                                                                                                                        fail("Expected IllegalArgumentException");
                                                                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                                                                        assertEquals("Points arrays must have equal length", e.getMessage());
                                                                                                                                                    }
                                                                                                                                                }

    @Test
                                                                                                                                            public void testDistance_EmptyArrays1() {
                                                                                                                                                ExpectedException exceptionRule = ExpectedException.none();
                                                                                                                                                exceptionRule.expect(IllegalArgumentException.class);
                                                                                                                                                exceptionRule.expectMessage("Points arrays must not be empty");
                                                                                                                                                double[] p1 = {};
                                                                                                                                                double[] p2 = {};
                                                                                                                                                MathUtils.distance(p1, p2);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testAddAndCheck_normalAddition() {
                                                                                                                                                // Test normal addition without overflow
                                                                                                                                                assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                                                                                                assertEquals(0, MathUtils.addAndCheck(-1, 1));
                                                                                                                                                assertEquals(-5, MathUtils.addAndCheck(-2, -3));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testAddAndCheck_boundaryCases() {
                                                                                                                                                // Test boundary cases
                                                                                                                                                assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                                                                                                                                                assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                                                                                                                                            }

    @Test(expected = ArithmeticException.class)
                                                                                                                                            public void testAddAndCheck_overflowPositive() {
                                                                                                                                                // Test overflow in positive direction
                                                                                                                                                MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                                                                                            }

    @Test(expected = ArithmeticException.class)
                                                                                                                                            public void testAddAndCheck_overflowNegative() {
                                                                                                                                                // Test overflow in negative direction
                                                                                                                                                MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testAddAndCheck_zeroCases() {
                                                                                                                                                // Specifically test zero cases which would be affected by sum=1 mutation
                                                                                                                                                assertEquals(0, MathUtils.addAndCheck(0, 0));
                                                                                                                                                assertEquals(1, MathUtils.addAndCheck(1, 0));
                                                                                                                                                assertEquals(-1, MathUtils.addAndCheck(0, -1));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testAddAndCheckAccuracy() {
                                                                                                                                                // Test simple addition cases that would fail if sum starts at 1
                                                                                                                                                assertEquals(0, MathUtils.addAndCheck(0, 0));  // 0+0 should be 0, mutant would return 1
                                                                                                                                                assertEquals(5, MathUtils.addAndCheck(2, 3));   // 2+3 should be 5, mutant would return 6
                                                                                                                                                assertEquals(-1, MathUtils.addAndCheck(2, -3)); // 2+(-3) should be -1, mutant would return 0
                                                                                                                                                
                                                                                                                                                // Test boundary cases
                                                                                                                                                assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE, 0));
                                                                                                                                                assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE, 0));
                                                                                                                                                
                                                                                                                                                // Test that adding 1 to MAX_VALUE throws exception (overflow)
                                                                                                                                                try {
                                                                                                                                                    MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                                                                                                    fail("Expected ArithmeticException for overflow");
                                                                                                                                                } catch (ArithmeticException e) {
                                                                                                                                                    // Expected behavior
                                                                                                                                                }
                                                                                                                                            }

    @Test
                                                                                                                                    public void testAddAndCheck() throws Exception {
                                                                                                                                        // Get the private method
                                                                                                                                        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                                        addAndCheck.setAccessible(true);
                                                                                                                                        
                                                                                                                                        // Test symmetry case (a > b)
                                                                                                                                        assertEquals("Should work for a > b", 5, addAndCheck.invoke(null, 3L, 2L, "Should work for a > b"));
                                                                                                                                        
                                                                                                                                        // Test both positive numbers - no overflow
                                                                                                                                        assertEquals("Should add positive numbers", Long.MAX_VALUE - 1, 
                                                                                                                                            addAndCheck.invoke(null, Long.MAX_VALUE - 2, 1L, "Should add positive numbers"));
                                                                                                                                        
                                                                                                                                        // Test both negative numbers - no overflow
                                                                                                                                        assertEquals("Should add negative numbers", Long.MIN_VALUE + 1, 
                                                                                                                                            addAndCheck.invoke(null, Long.MIN_VALUE, 1L, "Should add negative numbers"));
                                                                                                                                        
                                                                                                                                        // Test opposite signs - always safe
                                                                                                                                        assertEquals("Opposite signs should be safe", 0, addAndCheck.invoke(null, -1L, 1L, "Opposite signs should be safe"));
                                                                                                                                        assertEquals("Opposite signs should be safe", 0, addAndCheck.invoke(null, 1L, -1L, "Opposite signs should be safe"));
                                                                                                                                        
                                                                                                                                        // Test positive overflow
                                                                                                                                        try {
                                                                                                                                            addAndCheck.invoke(null, Long.MAX_VALUE, 1L, "Should throw overflow");
                                                                                                                                            fail("Should have thrown ArithmeticException");
                                                                                                                                        } catch (InvocationTargetException e) {
                                                                                                                                            assertTrue(e.getCause() instanceof ArithmeticException);
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        // Test negative overflow
                                                                                                                                        try {
                                                                                                                                            addAndCheck.invoke(null, Long.MIN_VALUE, -1L, "Should throw underflow");
                                                                                                                                            fail("Should have thrown ArithmeticException");
                                                                                                                                        } catch (InvocationTargetException e) {
                                                                                                                                            assertTrue(e.getCause() instanceof ArithmeticException);
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        // Test boundary cases
                                                                                                                                        assertEquals("Zero addition", 0, addAndCheck.invoke(null, 0L, 0L, "Zero addition"));
                                                                                                                                        assertEquals("Adding zero", Long.MAX_VALUE, 
                                                                                                                                            addAndCheck.invoke(null, Long.MAX_VALUE, 0L, "Adding zero"));
                                                                                                                                        assertEquals("Adding zero", Long.MIN_VALUE, 
                                                                                                                                            addAndCheck.invoke(null, Long.MIN_VALUE, 0L, "Adding zero"));
                                                                                                                                    }

    @Test
                                                                                                                                    public void testAddAndCheck_normalCase() {
                                                                                                                                        // Test normal case without overflow
                                                                                                                                        int x = 100;
                                                                                                                                        int y = 200;
                                                                                                                                        int expected = 300;
                                                                                                                                        
                                                                                                                                        int result = MathUtils.addAndCheck(x, y);
                                                                                                                                        assertEquals(expected, result);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testAddAndCheck_boundaryCase() {
                                                                                                                                        // Test boundary case (sum equals Integer.MAX_VALUE)
                                                                                                                                        int x = Integer.MAX_VALUE - 1;
                                                                                                                                        int y = 1;
                                                                                                                                        int expected = Integer.MAX_VALUE;
                                                                                                                                        
                                                                                                                                        int result = MathUtils.addAndCheck(x, y);
                                                                                                                                        assertEquals(expected, result);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testAddAndCheckWithLargeNumbers() {
                                                                                                                                        // Test with values that would overflow if summed as ints but not as longs
                                                                                                                                        long a = Long.MAX_VALUE - 10;
                                                                                                                                        long b = 5;
                                                                                                                                        
                                                                                                                                        // The original version with double sum should handle this correctly
                                                                                                                                        // The mutated version with int sum would fail due to integer overflow
                                                                                                                                        long result = MathUtils.addAndCheck(a, b);
                                                                                                                                        
                                                                                                                                        assertEquals("Should correctly sum large long values", Long.MAX_VALUE - 5, result);
                                                                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                                                                    public void testAddAndCheckWithActualOverflow() {
                                                                                                                                        // Test with values that should cause actual overflow
                                                                                                                                        long a = Long.MAX_VALUE;
                                                                                                                                        long b = 1;
                                                                                                                                        
                                                                                                                                        // Both versions should throw ArithmeticException for real overflow
                                                                                                                                        MathUtils.addAndCheck(a, b);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testAddAndCheckWithBoundaryValues() {
                                                                                                                                        // Test with values near the boundary where int would overflow but long wouldn't
                                                                                                                                        long a = Integer.MAX_VALUE;
                                                                                                                                        long b = Integer.MAX_VALUE;
                                                                                                                                        
                                                                                                                                        long expected = (long)Integer.MAX_VALUE + Integer.MAX_VALUE;
                                                                                                                                        long result = MathUtils.addAndCheck(a, b);
                                                                                                                                        
                                                                                                                                        assertEquals("Should handle sum of two large ints correctly as longs", 
                                                                                                                                                    expected, result);
                                                                                                                                    }

    @Test
                                                                                                                            public void testAddAndCheck_overflowCase() {
                                                                                                                                // Test case where sum exceeds Integer.MAX_VALUE
                                                                                                                                int x = Integer.MAX_VALUE - 100;
                                                                                                                                int y = 101;
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    int result = org.apache.commons.math.util.MathUtils.addAndCheck(x, y);
                                                                                                                                    // If we get here, the overflow check failed
                                                                                                                                    org.junit.Assert.fail("Expected ArithmeticException for overflow case");
                                                                                                                                } catch (ArithmeticException e) {
                                                                                                                                    // Verify correct exception with message
                                                                                                                                    org.junit.Assert.assertThat(e.getMessage(), org.hamcrest.CoreMatchers.is("overflow: add"));
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testAddAndCheckWithLargeValues() throws Exception {
                                                                                                                                // Get the private method
                                                                                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod(
                                                                                                                                    "addAndCheck", long.class, long.class, String.class);
                                                                                                                                addAndCheck.setAccessible(true);
                                                                                                                                
                                                                                                                                // Test case to detect int sum mutation
                                                                                                                                long max = Long.MAX_VALUE;
                                                                                                                                long min = Long.MIN_VALUE;
                                                                                                                                
                                                                                                                                // Test near upper boundary
                                                                                                                                assertEquals(max - 1, addAndCheck.invoke(null, max - 2, 1, "Should not overflow"));
                                                                                                                                assertEquals(-1, addAndCheck.invoke(null, max, min + 1, "Should handle min+max correctly"));
                                                                                                                                
                                                                                                                                // Test near lower boundary
                                                                                                                                assertEquals(min + 1, addAndCheck.invoke(null, min, 1, "Should handle min+1 correctly"));
                                                                                                                                assertEquals(max - 1, addAndCheck.invoke(null, max, -1, "Should handle max-1 correctly"));
                                                                                                                                
                                                                                                                                // Test with values that would overflow int but not long
                                                                                                                                long largeButSafe = Integer.MAX_VALUE;
                                                                                                                                assertEquals(2L * largeButSafe, 
                                                                                                                                           addAndCheck.invoke(null, largeButSafe, largeButSafe, "Should handle int overflow cases"));
                                                                                                                                
                                                                                                                                // Test with values that would overflow int sum
                                                                                                                                long veryLarge = 1L << 40; // Much larger than Integer.MAX_VALUE
                                                                                                                                assertEquals(2L * veryLarge, 
                                                                                                                                           addAndCheck.invoke(null, veryLarge, veryLarge, "Should handle very large values"));
                                                                                                                            }

    @Test
                                                                                                                        public void testAddAndCheck_underflowCase() {
                                                                                                                            // Test case where sum is below Integer.MIN_VALUE
                                                                                                                            int x = Integer.MIN_VALUE + 100;
                                                                                                                            int y = -101;
                                                                                                                            
                                                                                                                            try {
                                                                                                                                int result = org.apache.commons.math.util.MathUtils.addAndCheck(x, y);
                                                                                                                                // If we get here, the underflow check failed
                                                                                                                                fail("Expected ArithmeticException for underflow case");
                                                                                                                            } catch (ArithmeticException e) {
                                                                                                                                // Verify correct exception with message
                                                                                                                                assertEquals("overflow: add", e.getMessage());
                                                                                                                            }
                                                                                                                        }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                                                                                        public void testDistance1WithMutatedLoopCondition() {
                                                                                                                            // Prepare test data
                                                                                                                            int[] p1 = {1, 2, 3};
                                                                                                                            int[] p2 = {4, 5, 6};
                                                                                                                            
                                                                                                                            // If the mutant is present (i <= p1.length instead of i < p1.length),
                                                                                                                            // this should throw ArrayIndexOutOfBoundsException
                                                                                                                            MathUtils.distance1(p1, p2);
                                                                                                                            
                                                                                                                            // If we reach this point, the test fails as the mutant wasn't caught
                                                                                                                            fail("Expected ArrayIndexOutOfBoundsException due to mutated loop condition");
                                                                                                                        }

    @Test
                                                                                                                        public void testDistance1NormalCase() {
                                                                                                                            // Test normal case to ensure original functionality works
                                                                                                                            int[] p1 = {1, 2};
                                                                                                                            int[] p2 = {3, 4};
                                                                                                                            int expected = Math.abs(1-3) + Math.abs(2-4); // |1-3| + |2-4| = 4
                                                                                                                            
                                                                                                                            assertEquals(expected, MathUtils.distance1(p1, p2));
                                                                                                                        }

    @Test
                                                                                                                        public void testAddAndCheckArrayBoundary() {
                                                                                                                            // Test case to detect the array boundary mutation
                                                                                                                            // Create test arrays that would expose the boundary condition
                                                                                                                            int[] testArray1 = {1, 2, 3};
                                                                                                                            int[] testArray2 = {4, 5, 6};
                                                                                                                            
                                                                                                                            // The original method should process exactly 3 elements (indices 0,1,2)
                                                                                                                            // The mutated version would try to process index 3, which would throw ArrayIndexOutOfBoundsException
                                                                                                                            
                                                                                                                            try {
                                                                                                                                // Call the distance method which likely uses the addAndCheck internally
                                                                                                                                double result = MathUtils.distance(testArray1, testArray2);
                                                                                                                                
                                                                                                                                // If we get here, the mutation wasn't caught - fail the test
                                                                                                                                fail("Expected ArrayIndexOutOfBoundsException due to mutant not being caught");
                                                                                                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                // This is what we expect from the mutated version
                                                                                                                                assertTrue(true); // Mutation was caught
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Unexpected exception: " + e.getClass().getSimpleName());
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                                                                        public void testAddAndCheckArrayBoundaryWithEmptyArray() {
                                                                                                                            // Additional test case with empty array
                                                                                                                            int[] empty1 = {};
                                                                                                                            int[] empty2 = {};
                                                                                                                            
                                                                                                                            try {
                                                                                                                                double result = MathUtils.distance(empty1, empty2);
                                                                                                                                // For empty arrays, both original and mutant should behave the same
                                                                                                                                assertEquals(0.0, result, 0.0001);
                                                                                                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                fail("Empty array should not cause boundary exception");
                                                                                                                            }
                                                                                                                        }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                                                                                        public void testDistance1WithMutant() {
                                                                                                                            // Arrange
                                                                                                                            int[] p1 = {1, 2, 3};  // Non-empty array
                                                                                                                            int[] p2 = {4, 5, 6};  // Same length as p1
                                                                                                                            
                                                                                                                            // Act
                                                                                                                            // This should throw ArrayIndexOutOfBoundsException with the mutant
                                                                                                                            // because it will try to access index 3 (p1.length) which is out of bounds
                                                                                                                            MathUtils.distance1(p1, p2);
                                                                                                                            
                                                                                                                            // Assert
                                                                                                                            // The expected exception in the @Test annotation will handle the verification
                                                                                                                            // If the method doesn't throw, the test will fail
                                                                                                                        }

    @Test
                                                                                                                        public void testDistance1OriginalBehavior() {
                                                                                                                            // Arrange
                                                                                                                            int[] p1 = {1, 2, 3};
                                                                                                                            int[] p2 = {4, 5, 6};
                                                                                                                            int expected = 9;  // (4-1)+(5-2)+(6-3) = 3+3+3 = 9
                                                                                                                            
                                                                                                                            // Act
                                                                                                                            int result = MathUtils.distance1(p1, p2);
                                                                                                                            
                                                                                                                            // Assert
                                                                                                                            assertEquals("Distance should be calculated correctly", expected, result);
                                                                                                                        }

    @Test
                                                                                                                public void testAddAndCheckNoOverflow() {
                                                                                                                    assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                                                                }

    @Test
                                                                                                                public void testAddAndCheckMaxBoundary() {
                                                                                                                    assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                                                                                                                }

    @Test(expected = ArithmeticException.class)
                                                                                                                public void testAddAndCheckOverflowPositive() {
                                                                                                                    MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                                                                }

    @Test(expected = ArithmeticException.class)
                                                                                                                public void testAddAndCheckOverflowNegative() {
                                                                                                                    MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                                                                }

    @Test
                                                                                                                public void testDistance1DetectsFirstElement() {
                                                                                                                    int[] p1 = {10, 0, 0};  // First element different
                                                                                                                    int[] p2 = {0, 0, 0};
                                                                                                                    // Original would return 10, mutated would return 0
                                                                                                                    assertEquals(10, MathUtils.distance1(p1, p2));
                                                                                                                }

    @Test
                                                                                                                public void testDistance1SingleElementArray() {
                                                                                                                    int[] p1 = {5};
                                                                                                                    int[] p2 = {2};
                                                                                                                    // Original would return 3, mutated would throw ArrayIndexOutOfBounds
                                                                                                                    assertEquals(3, MathUtils.distance1(p1, p2));
                                                                                                                }

    @Test
                                                                                                                    public void testDistanceIntArraysFirstElementDifference() {
                                                                                                                        // Create test arrays where only the first element differs
                                                                                                                        int[] p1 = {5, 2, 3};  // First element is 5
                                                                                                                        int[] p2 = {1, 2, 3};  // First element is 1 (different from p1)
                                                                                                                        
                                                                                                                        // Calculate expected distance (using standard Euclidean distance formula)
                                                                                                                        // sqrt((5-1)² + (2-2)² + (3-3)²) = sqrt(16 + 0 + 0) = 4.0
                                                                                                                        double expectedDistance = 4.0;
                                                                                                                        
                                                                                                                        // Call the method and assert the result
                                                                                                                        double actualDistance = MathUtils.distance(p1, p2);
                                                                                                                        
                                                                                                                        // This assertion will fail with the mutated code (which skips first element)
                                                                                                                        assertEquals("Distance calculation should include first array elements", 
                                                                                                                                    expectedDistance, actualDistance, 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testDistanceIntArraysAllElementsSame() {
                                                                                                                        // Arrays where all elements are identical
                                                                                                                        int[] p1 = {1, 2, 3};
                                                                                                                        int[] p2 = {1, 2, 3};
                                                                                                                        
                                                                                                                        // Expected distance should be 0
                                                                                                                        double expectedDistance = 0.0;
                                                                                                                        
                                                                                                                        double actualDistance = MathUtils.distance(p1, p2);
                                                                                                                        
                                                                                                                        assertEquals("Distance should be 0 for identical arrays", 
                                                                                                                                    expectedDistance, actualDistance, 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testDistanceIntArraysSingleElement() {
                                                                                                                        // Single-element arrays - mutation would skip the only element
                                                                                                                        int[] p1 = {5};
                                                                                                                        int[] p2 = {1};
                                                                                                                        
                                                                                                                        // Expected distance: sqrt((5-1)²) = 4.0
                                                                                                                        double expectedDistance = 4.0;
                                                                                                                        
                                                                                                                        double actualDistance = MathUtils.distance(p1, p2);
                                                                                                                        
                                                                                                                        assertEquals("Distance should work for single-element arrays", 
                                                                                                                                    expectedDistance, actualDistance, 0.0001);
                                                                                                                    }

    @Test
                                                                                                            public void testAddAndCheck_NegativeBoundaryCase() throws Exception {
                                                                                                                // Test case where a + b = Long.MIN_VALUE exactly
                                                                                                                long a = Long.MIN_VALUE + 5;
                                                                                                                long b = -5;
                                                                                                                
                                                                                                                // Get the private method using reflection
                                                                                                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                addAndCheckMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Invoke the method
                                                                                                                long result = (long) addAndCheckMethod.invoke(null, a, b, "Should not overflow");
                                                                                                                
                                                                                                                assertEquals(Long.MIN_VALUE, result);
                                                                                                            }

    @Test
                                                                                                            public void testAddAndCheck_NegativeOverflow() throws Exception {
                                                                                                                // Test case where a + b would underflow Long.MIN_VALUE
                                                                                                                long a = Long.MIN_VALUE + 5;
                                                                                                                long b = -6;  // a + b = Long.MIN_VALUE - 1
                                                                                                                
                                                                                                                // Get the private method via reflection
                                                                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                addAndCheck.setAccessible(true);
                                                                                                                
                                                                                                                try {
                                                                                                                    addAndCheck.invoke(null, a, b, "Should overflow");
                                                                                                                    fail("Expected ArithmeticException for negative overflow");
                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                    assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                            public void testAddAndCheck_PositiveBoundaryCase() throws Exception {
                                                                                                                // Test positive boundary case
                                                                                                                long a = Long.MAX_VALUE - 5;
                                                                                                                long b = 5;
                                                                                                                
                                                                                                                // Get the private method using reflection
                                                                                                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                addAndCheckMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Invoke the method
                                                                                                                long result = (long) addAndCheckMethod.invoke(null, a, b, "Should not overflow");
                                                                                                                
                                                                                                                assertEquals(Long.MAX_VALUE, result);
                                                                                                            }

    @Test
                                                                                                            public void testAddAndCheck_PositiveOverflow() throws Exception {
                                                                                                                // Test positive overflow
                                                                                                                long a = Long.MAX_VALUE - 5;
                                                                                                                long b = 6;
                                                                                                                
                                                                                                                // Get the private method via reflection
                                                                                                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                addAndCheckMethod.setAccessible(true);
                                                                                                                
                                                                                                                try {
                                                                                                                    addAndCheckMethod.invoke(null, a, b, "Should overflow");
                                                                                                                    fail("Expected ArithmeticException for positive overflow");
                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                    assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                            public void testDistanceWithDifferentLengthArrays() {
                                                                                                                // Prepare test data
                                                                                                                int[] p1 = {1, 2, 3};  // length 3
                                                                                                                int[] p2 = {4, 5};     // length 2
                                                                                                                
                                                                                                                try {
                                                                                                                    // This should throw an exception or return wrong result with the mutant
                                                                                                                    double result = MathUtils.distance(p1, p2);
                                                                                                                    
                                                                                                                    // If no exception, verify the result is incorrect for the mutant
                                                                                                                    // The correct implementation should throw an exception before reaching here
                                                                                                                    fail("Expected IllegalArgumentException for arrays of different lengths");
                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                    // Expected behavior for correct implementation
                                                                                                                    assertEquals("Arrays must have the same length", e.getMessage());
                                                                                                                } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                    // This would catch the mutant behavior
                                                                                                                    fail("Mutant detected: Using wrong array length in loop condition");
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                            public void testDistanceWithEqualLengthArrays() {
                                                                                                                int[] p1 = {1, 2, 3};
                                                                                                                int[] p2 = {4, 5, 6};
                                                                                                                
                                                                                                                // Should work correctly for arrays of same length
                                                                                                                double expected = Math.sqrt(Math.pow(1-4, 2) + Math.pow(2-5, 2) + Math.pow(3-6, 2));
                                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                                
                                                                                                                assertEquals(expected, result, 0.0001);
                                                                                                            }

    @Test
                                                                                                            public void testDistanceWithEmptyArrays() {
                                                                                                                int[] p1 = {};
                                                                                                                int[] p2 = {};
                                                                                                                
                                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                                assertEquals(0.0, result, 0.0);
                                                                                                            }

    @Test
                                                                                                            public void testDistance1WithDifferentLengthArrays() {
                                                                                                                // Create arrays of different lengths
                                                                                                                int[] p1 = {1, 2, 3};  // length 3
                                                                                                                int[] p2 = {4, 5};     // length 2
                                                                                                                
                                                                                                                // Test should pass with original code (using p1.length)
                                                                                                                // but would fail with mutant (using p2.length) due to ArrayIndexOutOfBoundsException
                                                                                                                // or incorrect calculation if exception is handled
                                                                                                                
                                                                                                                try {
                                                                                                                    int result = MathUtils.distance1(p1, p2);
                                                                                                                    // If no exception, verify the calculation is correct for original
                                                                                                                    // The expected value is |1-4| + |2-5| + |3-0| (assuming 0 for missing elements)
                                                                                                                    assertEquals(3 + 3 + 3, result);
                                                                                                                } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                    // This would indicate the mutant was caught
                                                                                                                    fail("Mutant detected: Used p2.length instead of p1.length");
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                            public void testDistance1WithP1LongerThanP() {
                                                                                                                int[] longerArray = {1, 2, 3, 4};
                                                                                                                int[] shorterArray = {5, 6};
                                                                                                                
                                                                                                                try {
                                                                                                                    int result = MathUtils.distance1(longerArray, shorterArray);
                                                                                                                    // Expected: |1-5| + |2-6| + |3-0| + |4-0| = 4 + 4 + 3 + 4 = 15
                                                                                                                    assertEquals(15, result);
                                                                                                                } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                    fail("Mutant detected: Used shorter array's length for iteration");
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                            public void testDistance1WithP2LongerThanP() {
                                                                                                                int[] shorterArray = {1, 2};
                                                                                                                int[] longerArray = {3, 4, 5, 6};
                                                                                                                
                                                                                                                try {
                                                                                                                    int result = MathUtils.distance1(shorterArray, longerArray);
                                                                                                                    // Expected: |1-3| + |2-4| + |0-5| + |0-6| = 2 + 2 + 5 + 6 = 15
                                                                                                                    assertEquals(15, result);
                                                                                                                } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                    fail("Mutant detected: Used longer array's length for iteration");
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                    public void testAddAndCheck1() throws Exception {
                                                                                                        // Get the private method using reflection
                                                                                                        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                        addAndCheck.setAccessible(true);
                                                                                                        
                                                                                                        // Test normal addition without overflow
                                                                                                        assertEquals(5, addAndCheck.invoke(null, 2L, 3L, "Should not throw"));
                                                                                                        assertEquals(-1, addAndCheck.invoke(null, 2L, -3L, "Should not throw"));
                                                                                                        assertEquals(0, addAndCheck.invoke(null, Long.MAX_VALUE, Long.MIN_VALUE + 1, "Should not throw"));
                                                                                                        
                                                                                                        // Test positive overflow boundary
                                                                                                        assertEquals(Long.MAX_VALUE, addAndCheck.invoke(null, Long.MAX_VALUE - 1, 1L, "Should not throw"));
                                                                                                        assertEquals(Long.MAX_VALUE, addAndCheck.invoke(null, 1L, Long.MAX_VALUE - 1, "Should not throw"));
                                                                                                        
                                                                                                        // Test negative overflow boundary
                                                                                                        assertEquals(Long.MIN_VALUE, addAndCheck.invoke(null, Long.MIN_VALUE + 1, -1L, "Should not throw"));
                                                                                                        assertEquals(Long.MIN_VALUE, addAndCheck.invoke(null, -1L, Long.MIN_VALUE + 1, "Should not throw"));
                                                                                                        
                                                                                                        // Test positive overflow
                                                                                                        try {
                                                                                                            addAndCheck.invoke(null, Long.MAX_VALUE, 1L, "Should throw");
                                                                                                            fail("Expected ArithmeticException");
                                                                                                        } catch (InvocationTargetException e) {
                                                                                                            assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                                                                        }
                                                                                                        
                                                                                                        // Test negative overflow
                                                                                                        try {
                                                                                                            addAndCheck.invoke(null, Long.MIN_VALUE, -1L, "Should throw");
                                                                                                            fail("Expected ArithmeticException");
                                                                                                        } catch (InvocationTargetException e) {
                                                                                                            assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                                                                        }
                                                                                                        
                                                                                                        // Test commutative property
                                                                                                        assertEquals(addAndCheck.invoke(null, 12345L, 67890L, "msg"), 
                                                                                                                     addAndCheck.invoke(null, 67890L, 12345L, "msg"));
                                                                                                        
                                                                                                        // Test with a == b (symmetry case)
                                                                                                        assertEquals(20, addAndCheck.invoke(null, 10L, 10L, "Should not throw"));
                                                                                                    }

    @Test
                                                                                                    public void testDistance1DetectsSubtractionMutant() {
                                                                                                        // Arrange
                                                                                                        int[] p1 = {5, 3};
                                                                                                        int[] p2 = {2, 1};
                                                                                                        
                                                                                                        // Act - this would call the mutated method
                                                                                                        int result = MathUtils.distance1(p1, p2);
                                                                                                        
                                                                                                        // Assert - verify correct Manhattan distance calculation
                                                                                                        // Original would calculate (5-2) + (3-1) = 5
                                                                                                        // Mutant would calculate (5+2) + (3+1) = 11
                                                                                                        assertEquals("Manhattan distance calculation is incorrect", 5, result);
                                                                                                    }

    @Test
                                                                                                    public void testDistanceDetectsSubtractionMutantForDoubleArrays() {
                                                                                                        // Arrange
                                                                                                        double[] p1 = {5.5, 3.3};
                                                                                                        double[] p2 = {2.2, 1.1};
                                                                                                        double delta = 0.0001;
                                                                                                        
                                                                                                        // Act
                                                                                                        double result = MathUtils.distance(p1, p2);
                                                                                                        
                                                                                                        // Assert - verify correct Euclidean distance
                                                                                                        // Original: sqrt((5.5-2.2)^2 + (3.3-1.1)^2) ≈ sqrt(10.89 + 4.84) ≈ 3.9685
                                                                                                        // Mutant: sqrt((5.5+2.2)^2 + (3.3+1.1)^2) ≈ sqrt(59.29 + 19.36) ≈ 8.8651
                                                                                                        assertEquals("Euclidean distance calculation is incorrect", 3.9685, result, delta);
                                                                                                    }

    @Test
                                                                                                    public void testDistanceCalculationDetectsComponentAdditionMutant() {
                                                                                                        // Test case that would fail if components are added instead of subtracted
                                                                                                        double[] p1 = {5.0, 3.0};
                                                                                                        double[] p2 = {2.0, 1.0};
                                                                                                        
                                                                                                        // Expected distance calculation: sqrt((5-2)² + (3-1)²) = sqrt(9 + 4) = sqrt(13) ≈ 3.6055
                                                                                                        double expectedDistance = Math.sqrt(13);
                                                                                                        double actualDistance = MathUtils.distance(p1, p2);
                                                                                                        
                                                                                                        // This assertion would fail if components were added (which would give sqrt(49 + 16) = sqrt(65) ≈ 8.0622)
                                                                                                        assertEquals("Distance calculation should use component differences", 
                                                                                                                    expectedDistance, actualDistance, MathUtils.EPSILON);
                                                                                                        
                                                                                                        // Additional test case with negative values
                                                                                                        double[] p3 = {-1.0, 0.0};
                                                                                                        double[] p4 = {1.0, 0.0};
                                                                                                        assertEquals("Distance with negative components", 
                                                                                                                    2.0, MathUtils.distance(p3, p4), MathUtils.EPSILON);
                                                                                                        
                                                                                                        // Edge case: zero distance
                                                                                                        double[] p5 = {2.5, 3.5};
                                                                                                        assertEquals("Zero distance case", 
                                                                                                                    0.0, MathUtils.distance(p5, p5), MathUtils.EPSILON);
                                                                                                    }

    @Test
                                                                                            public void testAddAndCheckNegativeOverflow() throws Exception {
                                                                                                // Get the private method using reflection
                                                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                addAndCheck.setAccessible(true);
                                                                                                
                                                                                                // Test case where a + b equals Long.MIN_VALUE (exact boundary)
                                                                                                try {
                                                                                                    long result = (long) addAndCheck.invoke(null, Long.MIN_VALUE + 5, -5L, "Should not throw");
                                                                                                    assertEquals(Long.MIN_VALUE, result);
                                                                                                } catch (InvocationTargetException e) {
                                                                                                    if (e.getTargetException() instanceof ArithmeticException) {
                                                                                                        fail("Should not throw for exact boundary case");
                                                                                                    }
                                                                                                }
                                                                                            
                                                                                                // Test case where a + b would underflow (should throw)
                                                                                                try {
                                                                                                    addAndCheck.invoke(null, Long.MIN_VALUE + 5, -6L, "Should throw");
                                                                                                    fail("Should have thrown ArithmeticException for underflow");
                                                                                                } catch (InvocationTargetException e) {
                                                                                                    assertTrue(e.getTargetException() instanceof ArithmeticException);
                                                                                                    assertEquals("Should throw", e.getTargetException().getMessage());
                                                                                                }
                                                                                            
                                                                                                // Test case where a + b is safely above Long.MIN_VALUE
                                                                                                try {
                                                                                                    long result = (long) addAndCheck.invoke(null, Long.MIN_VALUE + 5, -4L, "Should not throw");
                                                                                                    assertEquals(Long.MIN_VALUE + 1, result);
                                                                                                } catch (InvocationTargetException e) {
                                                                                                    if (e.getTargetException() instanceof ArithmeticException) {
                                                                                                        fail("Should not throw for safe negative addition");
                                                                                                    }
                                                                                                }
                                                                                            }

    @Test
                                                                                            public void testAddAndCheckPositiveOverflow() throws Exception {
                                                                                                // Get the private method using reflection
                                                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                addAndCheck.setAccessible(true);
                                                                                                
                                                                                                // Test case where a + b equals Long.MAX_VALUE (exact boundary)
                                                                                                try {
                                                                                                    long result = (long) addAndCheck.invoke(null, Long.MAX_VALUE - 5, 5, "Should not throw");
                                                                                                    assertEquals(Long.MAX_VALUE, result);
                                                                                                } catch (InvocationTargetException e) {
                                                                                                    if (e.getTargetException() instanceof ArithmeticException) {
                                                                                                        fail("Should not throw for exact boundary case");
                                                                                                    } else {
                                                                                                        throw e;
                                                                                                    }
                                                                                                }
                                                                                            
                                                                                                // Test case where a + b would overflow (should throw)
                                                                                                try {
                                                                                                    addAndCheck.invoke(null, Long.MAX_VALUE - 5, 6, "Should throw");
                                                                                                    fail("Should have thrown ArithmeticException for overflow");
                                                                                                } catch (InvocationTargetException e) {
                                                                                                    assertTrue(e.getTargetException() instanceof ArithmeticException);
                                                                                                    assertEquals("Should throw", e.getTargetException().getMessage());
                                                                                                }
                                                                                            
                                                                                                // Test case where a + b is safely below Long.MAX_VALUE
                                                                                                try {
                                                                                                    long result = (long) addAndCheck.invoke(null, Long.MAX_VALUE - 5, 4, "Should not throw");
                                                                                                    assertEquals(Long.MAX_VALUE - 1, result);
                                                                                                } catch (InvocationTargetException e) {
                                                                                                    if (e.getTargetException() instanceof ArithmeticException) {
                                                                                                        fail("Should not throw for safe positive addition");
                                                                                                    } else {
                                                                                                        throw e;
                                                                                                    }
                                                                                                }
                                                                                            }

    @Test
                                                                                            public void testAddAndCheckMixedSigns() throws Exception {
                                                                                                // Get the private method using reflection
                                                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                addAndCheck.setAccessible(true);
                                                                                                
                                                                                                // Test case with opposite signs (always safe)
                                                                                                assertEquals(-1L, addAndCheck.invoke(null, Long.MAX_VALUE, -Long.MAX_VALUE - 1, ""));
                                                                                                assertEquals(0L, addAndCheck.invoke(null, -5L, 5L, ""));
                                                                                                assertEquals(Long.MIN_VALUE + 1, addAndCheck.invoke(null, Long.MIN_VALUE + 2, -1L, ""));
                                                                                            }

    @Test
                                                                                            public void testDistance_ShouldDetectCoordinateDifferenceMutation() {
                                                                                                // Setup test data with both positive and negative coordinates
                                                                                                double[] p1 = {3.0, -4.0, 5.0};
                                                                                                double[] p2 = {1.0, 2.0, -3.0};
                                                                                                
                                                                                                // Expected differences (p1[i] - p2[i])
                                                                                                double[] expectedDiffs = {2.0, -6.0, 8.0};
                                                                                                
                                                                                                // Mock the MathUtils class to spy on actual differences being calculated
                                                                                                MathUtils mathUtils = spy(MathUtils.class);
                                                                                                
                                                                                                // Calculate distance
                                                                                                double distance = mathUtils.distance(p1, p2);
                                                                                                
                                                                                                // Verify the actual differences used in calculation
                                                                                                // This would fail if the mutant is present (p2[i] - p1[i] instead of p1[i] - p2[i])
                                                                                                for (int i = 0; i < p1.length; i++) {
                                                                                                    double actualDiff = p1[i] - p2[i];
                                                                                                    assertEquals("Coordinate difference calculation is mutated", 
                                                                                                                 expectedDiffs[i], actualDiff, 0.0001);
                                                                                                }
                                                                                                
                                                                                                // Also verify the final distance is correct
                                                                                                double expectedDistance = Math.sqrt(4.0 + 36.0 + 64.0); // sqrt(2² + 6² + 8²)
                                                                                                assertEquals(expectedDistance, distance, 0.0001);
                                                                                            }

    @Test
                                                                                            public void testDistanceWithFloatingPointPrecision() {
                                                                                                // Test case designed to catch the subtraction order mutation
                                                                                                double[] p1 = {1.000000000000001, 2.000000000000002};
                                                                                                double[] p2 = {1.0, 2.0};
                                                                                                
                                                                                                // The mutation would reverse the subtraction order, which could affect floating point precision
                                                                                                double expectedDistance = Math.sqrt(Math.pow(0.000000000000001, 2) + Math.pow(0.000000000000002, 2));
                                                                                                double actualDistance = MathUtils.distance(p1, p2);
                                                                                                
                                                                                                // Verify the distance calculation is precise
                                                                                                assertEquals("Distance calculation should be precise with small floating point differences", 
                                                                                                            expectedDistance, actualDistance, 0.0);
                                                                                            }

    @Test
                                                                                            public void testDistanceWithSpecialValues() {
                                                                                                // Test with special values where subtraction order matters
                                                                                                double[] p1 = {Double.POSITIVE_INFINITY, Double.NaN};
                                                                                                double[] p2 = {Double.NEGATIVE_INFINITY, 0.0};
                                                                                                
                                                                                                // The original and mutated versions would both return NaN or Infinity,
                                                                                                // but we want to ensure the subtraction order doesn't affect special value handling
                                                                                                double result = MathUtils.distance(p1, p2);
                                                                                                
                                                                                                assertTrue("Should handle special values correctly", 
                                                                                                          Double.isNaN(result) || Double.isInfinite(result));
                                                                                            }

    @Test
                                                                                            public void testDistanceWithLargeNumbers() {
                                                                                                // Test with large numbers where subtraction order might affect precision
                                                                                                double[] p1 = {Double.MAX_VALUE, Double.MAX_VALUE};
                                                                                                double[] p2 = {Double.MAX_VALUE - 1.0E292, Double.MAX_VALUE - 1.0E292};
                                                                                                
                                                                                                // The mutation would reverse the subtraction, potentially affecting precision
                                                                                                double expectedDistance = Math.sqrt(2 * Math.pow(1.0E292, 2));
                                                                                                double actualDistance = MathUtils.distance(p1, p2);
                                                                                                
                                                                                                assertEquals("Should handle large numbers correctly", 
                                                                                                           expectedDistance, actualDistance, 1.0E291);
                                                                                            }

    @Test
                                                                                    public void testAddAndCheckNegativeOverflow1() throws Exception {
                                                                                        // Get the private method using reflection
                                                                                        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                        addAndCheck.setAccessible(true);
                                                                                        
                                                                                        // Test case where both numbers are negative and their sum would overflow
                                                                                        long a = Long.MIN_VALUE + 5;
                                                                                        long b = -6;
                                                                                        
                                                                                        try {
                                                                                            // This should throw ArithmeticException since a + b would be Long.MIN_VALUE - 1
                                                                                            addAndCheck.invoke(null, a, b, "Overflow occurred");
                                                                                            fail("Expected ArithmeticException for negative overflow");
                                                                                        } catch (InvocationTargetException e) {
                                                                                            // Expected behavior
                                                                                            assertEquals("Overflow occurred", ((ArithmeticException)e.getCause()).getMessage());
                                                                                        }
                                                                                        
                                                                                        // Test with swapped values
                                                                                        try {
                                                                                            addAndCheck.invoke(null, b, a, "Overflow occurred");
                                                                                            fail("Expected ArithmeticException for negative overflow");
                                                                                        } catch (InvocationTargetException e) {
                                                                                            // Expected behavior
                                                                                            assertEquals("Overflow occurred", ((ArithmeticException)e.getCause()).getMessage());
                                                                                        }
                                                                                        
                                                                                        // Test case that should pass (no overflow)
                                                                                        long result = (long) addAndCheck.invoke(null, Long.MIN_VALUE + 10, -5, "Should not overflow");
                                                                                        assertEquals(Long.MIN_VALUE + 5, result);
                                                                                        
                                                                                        // Test case with one negative and one positive (should never overflow)
                                                                                        result = (long) addAndCheck.invoke(null, -100, 200, "Mixed signs should not overflow");
                                                                                        assertEquals(100, result);
                                                                                    }

    @Test
                                                                                    public void testAddAndCheckPositiveOverflow1() throws Exception {
                                                                                        // Get the private method using reflection
                                                                                        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                        addAndCheck.setAccessible(true);
                                                                                        
                                                                                        // Test case where both numbers are positive and their sum would overflow
                                                                                        long a = Long.MAX_VALUE - 5;
                                                                                        long b = 6;
                                                                                        
                                                                                        try {
                                                                                            addAndCheck.invoke(null, a, b, "Overflow occurred");
                                                                                            fail("Expected ArithmeticException for positive overflow");
                                                                                        } catch (InvocationTargetException e) {
                                                                                            assertEquals("Overflow occurred", ((ArithmeticException)e.getCause()).getMessage());
                                                                                        }
                                                                                        
                                                                                        // Test with swapped values
                                                                                        try {
                                                                                            addAndCheck.invoke(null, b, a, "Overflow occurred");
                                                                                            fail("Expected ArithmeticException for positive overflow");
                                                                                        } catch (InvocationTargetException e) {
                                                                                            assertEquals("Overflow occurred", ((ArithmeticException)e.getCause()).getMessage());
                                                                                        }
                                                                                        
                                                                                        // Test case that should pass (no overflow)
                                                                                        long result = (long) addAndCheck.invoke(null, Long.MAX_VALUE - 10, 5, "Should not overflow");
                                                                                        assertEquals(Long.MAX_VALUE - 5, result);
                                                                                    }

    @Test
                                                                                    public void testAddAndCheckNormalAddition() {
                                                                                        assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                                        assertEquals(0, MathUtils.addAndCheck(0, 0));
                                                                                        assertEquals(-5, MathUtils.addAndCheck(-2, -3));
                                                                                        assertEquals(2, MathUtils.addAndCheck(5, -3));
                                                                                    }

    @Test
                                                                                    public void testAddAndCheckBoundaryCases() {
                                                                                        assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE, 0));
                                                                                        assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE, 0));
                                                                                        assertEquals(-1, MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE));
                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                    public void testAddAndCheckPositiveOverflow2() {
                                                                                        MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                    public void testAddAndCheckNegativeOverflow2() {
                                                                                        MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                                    }

    @Test
                                                                                    public void testAddAndCheckExceptionMessage() {
                                                                                        try {
                                                                                            MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MAX_VALUE);
                                                                                            fail("Expected ArithmeticException");
                                                                                        } catch (ArithmeticException e) {
                                                                                            assertEquals("overflow: add", e.getMessage());
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testAddAndCheckLargeNumbers() {
                                                                                        assertEquals(Integer.MAX_VALUE - 100, MathUtils.addAndCheck(Integer.MAX_VALUE - 200, 100));
                                                                                        assertEquals(Integer.MIN_VALUE + 100, MathUtils.addAndCheck(Integer.MIN_VALUE + 200, -100));
                                                                                    }

    @Test
                                                                                    public void testDistanceWithFractionalValues() {
                                                                                        // Setup test data with fractional values that would behave differently
                                                                                        // with int vs double arithmetic
                                                                                        double[] p1 = {1.5, 2.5};
                                                                                        double[] p2 = {1.0, 2.0};
                                                                                        
                                                                                        // The mutation would calculate (int)(1.5-1.0) = 0 instead of 0.5
                                                                                        // and (int)(2.5-2.0) = 0 instead of 0.5
                                                                                        // This would make the distance calculation completely wrong
                                                                                        
                                                                                        // Calculate expected value using correct double arithmetic
                                                                                        double expected = Math.sqrt(0.5*0.5 + 0.5*0.5); // ~0.7071
                                                                                        
                                                                                        // Call the method (assuming it's distance() based on the mutation context)
                                                                                        double actual = MathUtils.distance(p1, p2);
                                                                                        
                                                                                        // Verify with a delta to account for any floating point imprecision
                                                                                        assertEquals("Distance calculation should handle fractional values correctly", 
                                                                                                    expected, actual, 0.0001);
                                                                                    }

    @Test
                                                                                    public void testDistanceWithLargeNumbers1() {
                                                                                        // Test with large numbers where integer overflow could occur
                                                                                        double[] p1 = {Integer.MAX_VALUE + 0.5, Integer.MAX_VALUE + 0.5};
                                                                                        double[] p2 = {Integer.MAX_VALUE, Integer.MAX_VALUE};
                                                                                        
                                                                                        // With int arithmetic, this would overflow
                                                                                        // With double arithmetic, it should work fine
                                                                                        double expected = Math.sqrt(0.5*0.5 + 0.5*0.5); // ~0.7071
                                                                                        
                                                                                        double actual = MathUtils.distance(p1, p2);
                                                                                        
                                                                                        assertEquals("Distance calculation should handle large numbers without overflow", 
                                                                                                    expected, actual, 0.0001);
                                                                                    }

    @Test
                                                                                public void testDistanceWithPrecisionLoss() {
                                                                                    double[] p1 = {1.5, 2.5};
                                                                                    double[] p2 = {1.0, 2.0};
                                                                                    
                                                                                    // The original double version would give precise results
                                                                                    double expected = Math.sqrt(Math.pow(0.5, 2) + Math.pow(0.5, 2));
                                                                                    
                                                                                    // If mutated to use int, it would truncate to 0.0 for each dimension
                                                                                    double actual = MathUtils.distance(p1, p2);
                                                                                    
                                                                                    // This assertion would fail if the calculation used int instead of double
                                                                                    assertEquals(expected, actual, 0.0001);
                                                                                }

    @Test
                                                                            public void testAddAndCheck2() throws Exception {
                                                                                // Get the private method using reflection
                                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                addAndCheck.setAccessible(true);
                                                                                
                                                                                // Test normal addition without overflow
                                                                                assertEquals(5, addAndCheck.invoke(null, 2L, 3L, "Should not throw"));
                                                                                assertEquals(-1, addAndCheck.invoke(null, 2L, -3L, "Should not throw"));
                                                                                
                                                                                // Test symmetric case
                                                                                assertEquals(5, addAndCheck.invoke(null, 3L, 2L, "Should not throw"));
                                                                                
                                                                                // Test boundary cases
                                                                                assertEquals(Long.MAX_VALUE, addAndCheck.invoke(null, Long.MAX_VALUE - 1, 1L, "Should not throw"));
                                                                                assertEquals(Long.MIN_VALUE, addAndCheck.invoke(null, Long.MIN_VALUE + 1, -1L, "Should not throw"));
                                                                                
                                                                                // Test positive overflow
                                                                                try {
                                                                                    addAndCheck.invoke(null, Long.MAX_VALUE, 1L, "Should throw");
                                                                                    fail("Should have thrown ArithmeticException");
                                                                                } catch (InvocationTargetException e) {
                                                                                    assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                                                }
                                                                                
                                                                                // Test negative overflow
                                                                                try {
                                                                                    addAndCheck.invoke(null, Long.MIN_VALUE, -1L, "Should throw");
                                                                                    fail("Should have thrown ArithmeticException");
                                                                                } catch (InvocationTargetException e) {
                                                                                    assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                                                }
                                                                                
                                                                                // Test opposite signs (should never overflow)
                                                                                assertEquals(0, addAndCheck.invoke(null, Long.MAX_VALUE, -Long.MAX_VALUE, "Should not throw"));
                                                                                assertEquals(-1, addAndCheck.invoke(null, Long.MIN_VALUE, Long.MAX_VALUE, "Should not throw"));
                                                                            }

    @Test
                                                                            public void testAddAndCheckWithinRange() {
                                                                                assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                                assertEquals(0, MathUtils.addAndCheck(-1, 1));
                                                                                assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE, 0));
                                                                                assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE, 0));
                                                                            }

    @Test(expected = ArithmeticException.class)
                                                                            public void testAddAndCheckPositiveOverflow3() {
                                                                                MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                            }

    @Test(expected = ArithmeticException.class)
                                                                            public void testAddAndCheckNegativeOverflow3() {
                                                                                MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                            }

    @Test
                                                                            public void testAddAndCheckBoundaryNoOverflow() {
                                                                                assertEquals(-1, MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE));
                                                                            }

    @Test(expected = ArithmeticException.class)
                                                                            public void testAddAndCheckLargePositiveOverflow() {
                                                                                MathUtils.addAndCheck(Integer.MAX_VALUE / 2 + 1, Integer.MAX_VALUE / 2 + 1);
                                                                            }

    @Test(expected = ArithmeticException.class)
                                                                            public void testAddAndCheckLargeNegativeOverflow() {
                                                                                MathUtils.addAndCheck(Integer.MIN_VALUE / 2 - 1, Integer.MIN_VALUE / 2 - 1);
                                                                            }

    @Test
                                                                            public void testAddAndCheckWithDeltaValues() {
                                                                                // Test with values that would expose the mutation
                                                                                // Original behavior would square the delta (3*3=9), mutant would just add (3)
                                                                                // We need to test the internal behavior through observable results
                                                                                
                                                                                // Since the method is private, we'll need to test it indirectly through public methods
                                                                                // that use it, or use reflection. For this example, I'll assume we're testing
                                                                                // a public method that internally uses this private method.
                                                                                
                                                                                // Create test values where the difference matters
                                                                                long a = Long.MAX_VALUE - 5;
                                                                                long b = 3;  // This is our dp value
                                                                                
                                                                                try {
                                                                                    // The original would handle this differently than the mutant
                                                                                    long result = MathUtils.addAndCheck(a, b);
                                                                                    
                                                                                    // If we get here, the test should verify the correct calculation was done
                                                                                    // Since we can't directly observe the private method, we need to assert
                                                                                    // on the expected behavior of the public interface
                                                                                    
                                                                                    // The key point is that the mutant would produce different internal calculations
                                                                                    // We need to design a test where the squared vs non-squared difference would
                                                                                    // affect the final outcome
                                                                                    
                                                                                    // For example, test boundary conditions where the squared term matters
                                                                                    long expected = a + b;
                                                                                    assertEquals(expected, result);
                                                                                    
                                                                                    // Additional test case where squaring would make a difference
                                                                                    long c = 2;
                                                                                    long d = 3;
                                                                                    long expectedSum = c + d;  // Would be same for both, need different approach
                                                                                    
                                                                                    // Alternative approach: test with values where overflow would occur differently
                                                                                    // depending on whether values are squared or not
                                                                                    try {
                                                                                        MathUtils.addAndCheck(Long.MAX_VALUE / 2, Long.MAX_VALUE / 2);
                                                                                    } catch (ArithmeticException e) {
                                                                                        assertEquals("overflow: add", e.getMessage());
                                                                                    }
                                                                                    
                                                                                } catch (ArithmeticException e) {
                                                                                    // Verify the correct exception message for overflow cases
                                                                                    assertEquals("overflow: add", e.getMessage());
                                                                                }
                                                                            }

    @Test
                                                                    public void testAddAndCheck_NegativeBoundaryCase1() throws Exception {
                                                                        // Test case where a + b = Long.MIN_VALUE
                                                                        long a = Long.MIN_VALUE + 1;
                                                                        long b = -1;
                                                                        String msg = "Overflow occurred";
                                                                        
                                                                        // Get the private method using reflection
                                                                        Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                        addAndCheckMethod.setAccessible(true);
                                                                        
                                                                        // Should not throw exception since Long.MIN_VALUE + 1 - 1 = Long.MIN_VALUE
                                                                        // which is exactly the minimum value and should be allowed
                                                                        long result = (long) addAndCheckMethod.invoke(null, a, b, msg);
                                                                        assertEquals(Long.MIN_VALUE, result);
                                                                        
                                                                        // Also test the symmetric case
                                                                        result = (long) addAndCheckMethod.invoke(null, b, a, msg);
                                                                        assertEquals(Long.MIN_VALUE, result);
                                                                        
                                                                        // Test the exact boundary case where both numbers are Long.MIN_VALUE/2
                                                                        // This would sum to exactly Long.MIN_VALUE when added
                                                                        a = Long.MIN_VALUE / 2;
                                                                        b = Long.MIN_VALUE / 2;
                                                                        result = (long) addAndCheckMethod.invoke(null, a, b, msg);
                                                                        assertEquals(Long.MIN_VALUE, result);
                                                                    }

    @Test
                                                                    public void testAddAndCheck_NegativeOverflow1() throws Exception {
                                                                        // Test case that should overflow
                                                                        long a = Long.MIN_VALUE;
                                                                        long b = -1;
                                                                        String msg = "Overflow occurred";
                                                                        
                                                                        // Get the private method using reflection
                                                                        Class<?> mathUtilsClass = Class.forName("org.apache.commons.math.util.MathUtils");
                                                                        Method addAndCheckMethod = mathUtilsClass.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                        addAndCheckMethod.setAccessible(true);
                                                                        
                                                                        // This should throw exception since Long.MIN_VALUE - 1 would underflow
                                                                        try {
                                                                            addAndCheckMethod.invoke(null, a, b, msg);
                                                                            fail("Expected ArithmeticException");
                                                                        } catch (InvocationTargetException e) {
                                                                            assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                                            assertEquals(msg, e.getCause().getMessage());
                                                                        }
                                                                    }

    @Test
                                                                    public void testAddAndCheckNormalCase() {
                                                                        int result = MathUtils.addAndCheck(2, 3);
                                                                        assertEquals(5, result);
                                                                    }

    @Test
                                                                    public void testAddAndCheckWithZero() {
                                                                        int result = MathUtils.addAndCheck(0, 5);
                                                                        assertEquals(5, result);
                                                                        
                                                                        result = MathUtils.addAndCheck(-5, 0);
                                                                        assertEquals(-5, result);
                                                                    }

    @Test
                                                                    public void testAddAndCheckNegativeNumbers() {
                                                                        int result = MathUtils.addAndCheck(-2, -3);
                                                                        assertEquals(-5, result);
                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                    public void testAddAndCheckPositiveOverflow4() {
                                                                        MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                    public void testAddAndCheckNegativeOverflow4() {
                                                                        MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                    }

    @Test
                                                                    public void testAddAndCheckBoundaryNoOverflow1() {
                                                                        // Just below overflow cases
                                                                        int result = MathUtils.addAndCheck(Integer.MAX_VALUE - 10, 10);
                                                                        assertEquals(Integer.MAX_VALUE, result);
                                                                        
                                                                        result = MathUtils.addAndCheck(Integer.MIN_VALUE + 10, -10);
                                                                        assertEquals(Integer.MIN_VALUE, result);
                                                                    }

    @Test
                                                                    public void testAddAndCheckMaxAndMin() {
                                                                        // MAX + MIN should equal -1
                                                                        int result = MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE);
                                                                        assertEquals(-1, result);
                                                                    }

    @Test
                                                            public void testAddAndCheckDetectsSumOfSquaresMutant() throws Exception {
                                                                // Test case designed to detect the sum += dp*dp vs sum -= dp*dp mutant
                                                                // Using values where the difference between addition and subtraction would be significant
                                                                
                                                                // Create test data where dp*dp is non-zero
                                                                long a = 3L;
                                                                long b = 4L;
                                                                String msg = "test overflow";
                                                                
                                                                // Get the private method using reflection
                                                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                addAndCheckMethod.setAccessible(true);
                                                                
                                                                // Calculate expected result (sum of squares)
                                                                long expected = a + b + (a * a) + (b * b); // Assuming original code does sum += dp*dp
                                                                
                                                                // Call the method using reflection
                                                                long result = (Long) addAndCheckMethod.invoke(null, a, b, msg);
                                                                
                                                                // Verify the result matches expected sum
                                                                assertEquals("The method should correctly calculate sum including squared terms", 
                                                                            expected, result);
                                                                
                                                                // Also test with zero values to ensure basic addition still works
                                                                assertEquals(0L, addAndCheckMethod.invoke(null, 0L, 0L, msg));
                                                                assertEquals(5L, addAndCheckMethod.invoke(null, 2L, 3L, msg));
                                                            }

    @Test
                                                            public void testAddAndCheck3() throws Exception {
                                                                // Get the private method using reflection
                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                addAndCheck.setAccessible(true);
                                                                
                                                                // Test symmetric case (a > b)
                                                                assertEquals(5, addAndCheck.invoke(null, 3L, 2L, "Should not throw"));
                                                                assertEquals(5, addAndCheck.invoke(null, 2L, 3L, "Should not throw"));
                                                                
                                                                // Test safe additions
                                                                assertEquals(0, addAndCheck.invoke(null, -1L, 1L, "Should not throw"));
                                                                assertEquals(-2, addAndCheck.invoke(null, -1L, -1L, "Should not throw"));
                                                                assertEquals(2, addAndCheck.invoke(null, 1L, 1L, "Should not throw"));
                                                                
                                                                // Test boundary values
                                                                assertEquals(Long.MAX_VALUE, addAndCheck.invoke(null, Long.MAX_VALUE - 1, 1L, "Should not throw"));
                                                                assertEquals(Long.MIN_VALUE, addAndCheck.invoke(null, Long.MIN_VALUE + 1, -1L, "Should not throw"));
                                                                
                                                                // Test positive overflow
                                                                try {
                                                                    addAndCheck.invoke(null, Long.MAX_VALUE - 1, 2L, "Should throw");
                                                                    fail("Should have thrown ArithmeticException");
                                                                } catch (InvocationTargetException e) {
                                                                    assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                                }
                                                                
                                                                // Test negative overflow
                                                                try {
                                                                    addAndCheck.invoke(null, Long.MIN_VALUE + 1, -2L, "Should throw");
                                                                    fail("Should have thrown ArithmeticException");
                                                                } catch (InvocationTargetException e) {
                                                                    assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                                }
                                                                
                                                                // Test exactly at overflow boundaries
                                                                assertEquals(Long.MAX_VALUE, addAndCheck.invoke(null, Long.MAX_VALUE, 0L, "Should not throw"));
                                                                assertEquals(Long.MIN_VALUE, addAndCheck.invoke(null, Long.MIN_VALUE, 0L, "Should not throw"));
                                                            }

    @Test
                                                            public void testAddAndCheckNormalAddition1() {
                                                                int result = MathUtils.addAndCheck(10, 20);
                                                                assertEquals(30, result);
                                                            }

    @Test
                                                            public void testAddAndCheckMaxValueNoOverflow() {
                                                                int result = MathUtils.addAndCheck(Integer.MAX_VALUE - 10, 9);
                                                                assertEquals(Integer.MAX_VALUE - 1, result);
                                                            }

    @Test
                                                            public void testAddAndCheckMinValueNoOverflow() {
                                                                int result = MathUtils.addAndCheck(Integer.MIN_VALUE + 10, -9);
                                                                assertEquals(Integer.MIN_VALUE + 1, result);
                                                            }

    @Test(expected = ArithmeticException.class)
                                                            public void testAddAndCheckPositiveOverflow5() {
                                                                MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                            }

    @Test(expected = ArithmeticException.class)
                                                            public void testAddAndCheckNegativeOverflow5() {
                                                                MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                            }

    @Test(expected = ArithmeticException.class)
                                                            public void testAddAndCheckLargePositiveOverflow1() {
                                                                MathUtils.addAndCheck(Integer.MAX_VALUE / 2 + 1, Integer.MAX_VALUE / 2 + 1);
                                                            }

    @Test(expected = ArithmeticException.class)
                                                            public void testAddAndCheckLargeNegativeOverflow1() {
                                                                MathUtils.addAndCheck(Integer.MIN_VALUE / 2 - 1, Integer.MIN_VALUE / 2 - 1);
                                                            }

    @Test
                                                    public void testAddAndCheckWithNonOneValues() throws Exception {
                                                        // Test with values that would show difference between multiplication and division
                                                        long a = 5L;
                                                        long b = 10L;
                                                        
                                                        // Get the private method via reflection
                                                        Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                            "addAndCheck", long.class, long.class, String.class);
                                                        addAndCheckMethod.setAccessible(true);
                                                        
                                                        try {
                                                            // The original implementation would process these values differently
                                                            // than the mutated version (dp*dp vs dp/dp)
                                                            long result = (Long)addAndCheckMethod.invoke(null, a, b, "overflow: add");
                                                            
                                                            // If we reach here, we need to verify the calculation wasn't affected
                                                            // by the mutation. Since we don't have the full method implementation,
                                                            // we'll assume the test should fail if the mutation exists
                                                            fail("Expected ArithmeticException for overflow check");
                                                        } catch (InvocationTargetException e) {
                                                            // This is expected for overflow cases
                                                            assertEquals("overflow: add", e.getCause().getMessage());
                                                        }
                                                        
                                                        // Additional test case that would catch the dp*dp vs dp/dp difference
                                                        // if the method was doing accumulation
                                                        try {
                                                            // Test with values that would show different results between original and mutant
                                                            long x = 2L;
                                                            long y = 3L;
                                                            addAndCheckMethod.invoke(null, x, y, "overflow: add");
                                                            
                                                            // If the method was accumulating with dp*dp vs dp/dp,
                                                            // this would show different results
                                                            // Since we can't see the full implementation, we're testing the overflow check
                                                            // which should be the main purpose of addAndCheck
                                                        } catch (InvocationTargetException e) {
                                                            assertEquals("overflow: add", e.getCause().getMessage());
                                                        }
                                                    }

    @Test
                                                    public void testAddAndCheck4() throws Exception {
                                                        // Get the private method using reflection
                                                        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                        addAndCheck.setAccessible(true);
                                                        
                                                        // Test basic addition
                                                        assertEquals(5L, addAndCheck.invoke(null, 2L, 3L, "Should not throw"));
                                                        
                                                        // Test commutative property
                                                        assertEquals(5L, addAndCheck.invoke(null, 3L, 2L, "Should not throw"));
                                                        
                                                        // Test with zero
                                                        assertEquals(2L, addAndCheck.invoke(null, 2L, 0L, "Should not throw"));
                                                        assertEquals(2L, addAndCheck.invoke(null, 0L, 2L, "Should not throw"));
                                                        
                                                        // Test negative numbers
                                                        assertEquals(-5L, addAndCheck.invoke(null, -2L, -3L, "Should not throw"));
                                                        
                                                        // Test opposite signs
                                                        assertEquals(1L, addAndCheck.invoke(null, -2L, 3L, "Should not throw"));
                                                        assertEquals(-1L, addAndCheck.invoke(null, 2L, -3L, "Should not throw"));
                                                        
                                                        // Test near overflow (positive)
                                                        assertEquals(Long.MAX_VALUE, addAndCheck.invoke(null, Long.MAX_VALUE - 1, 1L, "Should not throw"));
                                                        
                                                        // Test near overflow (negative)
                                                        assertEquals(Long.MIN_VALUE, addAndCheck.invoke(null, Long.MIN_VALUE + 1, -1L, "Should not throw"));
                                                        
                                                        // Test symmetry handling (a > b case)
                                                        assertEquals(5L, addAndCheck.invoke(null, 3L, 2L, "Should not throw"));
                                                    }

    @Test(expected = ArithmeticException.class)
                                                    public void testAddAndCheckPositiveOverflow6() throws Exception {
                                                        Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                        method.setAccessible(true);
                                                        method.invoke(null, Long.MAX_VALUE, 1L, "Should throw");
                                                    }

    @Test
                                                    public void testAddAndCheckNegativeOverflow6() throws Exception {
                                                        try {
                                                            Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                            method.setAccessible(true);
                                                            method.invoke(null, Long.MIN_VALUE, -1L, "Should throw");
                                                            fail("Expected ArithmeticException");
                                                        } catch (InvocationTargetException e) {
                                                            assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                        }
                                                    }

    @Test
                                                    public void testAddAndCheckBothNegativeOverflow() throws Exception {
                                                        try {
                                                            Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                            method.setAccessible(true);
                                                            method.invoke(null, Long.MIN_VALUE, Long.MIN_VALUE, "Should throw");
                                                            fail("Expected ArithmeticException");
                                                        } catch (InvocationTargetException e) {
                                                            assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                        }
                                                    }

    @Test
                                                    public void testAddAndCheckBothPositiveOverflow() throws Exception {
                                                        // Get the private method using reflection
                                                        Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                            "addAndCheck", long.class, long.class, String.class
                                                        );
                                                        addAndCheckMethod.setAccessible(true);
                                                        
                                                        // Invoke the method and expect an exception
                                                        try {
                                                            addAndCheckMethod.invoke(null, Long.MAX_VALUE, Long.MAX_VALUE, "Should throw");
                                                            fail("Expected ArithmeticException");
                                                        } catch (InvocationTargetException e) {
                                                            assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                        }
                                                    }

    @Test
                                                    public void testAddAndCheckBoundaryCases1() {
                                                        // Test case where sum equals Integer.MAX_VALUE
                                                        int max = Integer.MAX_VALUE;
                                                        assertEquals(max, MathUtils.addAndCheck(max - 1, 1));
                                                        assertEquals(max, MathUtils.addAndCheck(0, max));
                                                        assertEquals(max, MathUtils.addAndCheck(1, max - 1));
                                                        
                                                        // Test case where sum equals Integer.MIN_VALUE
                                                        int min = Integer.MIN_VALUE;
                                                        assertEquals(min, MathUtils.addAndCheck(min + 1, -1));
                                                        assertEquals(min, MathUtils.addAndCheck(0, min));
                                                        assertEquals(min, MathUtils.addAndCheck(-1, min + 1));
                                                        
                                                        // Test cases just below and above boundaries
                                                        assertEquals(Integer.MAX_VALUE - 1, MathUtils.addAndCheck(max - 2, 1));
                                                        assertEquals(Integer.MIN_VALUE + 1, MathUtils.addAndCheck(min + 2, -1));
                                                    }

    @Test(expected = ArithmeticException.class)
                                                    public void testAddAndCheckOverflowMax() {
                                                        MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                    }

    @Test(expected = ArithmeticException.class)
                                                    public void testAddAndCheckOverflowMin() {
                                                        MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                    }

    @Test
                                                    public void testAddAndCheckNoOverflow1() {
                                                        // Test normal addition without overflow
                                                        long a = 1000L;
                                                        long b = 2000L;
                                                        long expected = 3000L;
                                                        
                                                        assertEquals(expected, MathUtils.addAndCheck(a, b));
                                                    }

    @Test(expected = ArithmeticException.class)
                                                    public void testAddAndCheckWithOverflow() {
                                                        // Test addition that would cause overflow
                                                        long a = Long.MAX_VALUE;
                                                        long b = 1L;
                                                        
                                                        MathUtils.addAndCheck(a, b);
                                                    }

    @Test
                                                    public void testAddAndCheckNegativeNumbers1() {
                                                        // Test addition of negative numbers
                                                        long a = -1000L;
                                                        long b = -2000L;
                                                        long expected = -3000L;
                                                        
                                                        assertEquals(expected, MathUtils.addAndCheck(a, b));
                                                    }

    @Test(expected = ArithmeticException.class)
                                                    public void testAddAndCheckUnderflow() {
                                                        // Test addition that would cause underflow
                                                        long a = Long.MIN_VALUE;
                                                        long b = -1L;
                                                        
                                                        MathUtils.addAndCheck(a, b);
                                                    }

    @Test
                                                    public void testAddAndCheckZero() {
                                                        // Test addition with zero
                                                        long a = 0L;
                                                        long b = 500L;
                                                        long expected = 500L;
                                                        
                                                        assertEquals(expected, MathUtils.addAndCheck(a, b));
                                                    }

    @Test
                                            public void testAddAndCheck_AccumulationBehavior() throws Exception {
                                                // Test case to detect mutation from += to =
                                                // This would fail if the sum is not being accumulated properly
                                                
                                                // Get the private method using reflection
                                                Method addAndCheck = MathUtils.class.getDeclaredMethod(
                                                    "addAndCheck", long.class, long.class, String.class);
                                                addAndCheck.setAccessible(true);
                                                
                                                // Setup - we'll test multiple additions that should accumulate
                                                long result = 0;
                                                String msg = "Overflow occurred";
                                                
                                                // First addition
                                                result = (long) addAndCheck.invoke(null, result, 5L, msg);
                                                assertEquals(5L, result);
                                                
                                                // Second addition - should accumulate
                                                result = (long) addAndCheck.invoke(null, result, 10L, msg);
                                                assertEquals(15L, result);
                                                
                                                // Third addition - should accumulate
                                                result = (long) addAndCheck.invoke(null, result, 20L, msg);
                                                assertEquals(35L, result);
                                                
                                                // If the mutation exists (sum = dp * dp instead of sum += dp * dp),
                                                // the result would be 20 instead of 35 after these operations
                                            }

    @Test
                                        public void testAddAndCheckReturnsCorrectSum() {
                                            // Test normal addition cases
                                            assertEquals(5, MathUtils.addAndCheck(2, 3));
                                            assertEquals(0, MathUtils.addAndCheck(0, 0));
                                            assertEquals(-1, MathUtils.addAndCheck(2, -3));
                                            assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                                            assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                                            
                                            // Test that the result is exactly the sum, not square root of sum
                                            // Using 16 and 9 since sqrt(25) would be 5, while sum is 25
                                            assertEquals(25, MathUtils.addAndCheck(16, 9));
                                            
                                            // Test with larger numbers where sum would differ significantly from sqrt
                                            assertEquals(10000, MathUtils.addAndCheck(9999, 1));
                                            assertEquals(200, MathUtils.addAndCheck(100, 100));
                                        }

    @Test(expected = ArithmeticException.class)
                                        public void testAddAndCheckOverflowPositive1() {
                                            MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                        }

    @Test(expected = ArithmeticException.class)
                                        public void testAddAndCheckOverflowNegative1() {
                                            MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                        }

    @Test
                                    public void testAddAndCheckWithNonPerfectSquare() throws Exception {
                                        // Test with values whose sum is not a perfect square
                                        long a = 5L;
                                        long b = 6L;
                                        String msg = "overflow: add";
                                        
                                        // Calculate expected values for both original and mutated versions
                                        long directSum = a + b; // Would be 11
                                        double sqrtSum = Math.sqrt(directSum); // Would be ~3.3166
                                        
                                        // Use reflection to access the private method
                                        Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                        addAndCheckMethod.setAccessible(true);
                                        
                                        // Call the method
                                        double result = (double) addAndCheckMethod.invoke(null, a, b, msg);
                                        
                                        // Verify the result is the square root of the sum, not the sum itself
                                        assertEquals(sqrtSum, result, 0.0001);
                                        assertNotEquals((double)directSum, result, 0.0001);
                                    }

    @Test
                                    public void testAddAndCheckWithPerfectSquare() throws Exception {
                                        // Test with values whose sum is a perfect square
                                        long a = 5L;
                                        long b = 20L;
                                        String msg = "overflow: add";
                                        
                                        // Both versions would return the same value in this case
                                        long directSum = a + b; // 25
                                        double sqrtSum = Math.sqrt(directSum); // 5.0
                                        
                                        // Use reflection to access the private method
                                        Class<?> mathUtilsClass = Class.forName("org.apache.commons.math.util.MathUtils");
                                        Method addAndCheckMethod = mathUtilsClass.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                        addAndCheckMethod.setAccessible(true);
                                        double result = (double) addAndCheckMethod.invoke(null, a, b, msg);
                                        
                                        // Both original and mutated would pass this assertion
                                        assertEquals(sqrtSum, result, 0.0001);
                                    }

    @Test
                                    public void testAddAndCheckReturnsSquareRootOfSum() throws Exception {
                                        // Get the private method using reflection
                                        Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                        addAndCheckMethod.setAccessible(true);
                                        
                                        // Test case where sum is a perfect square (16)
                                        long a = 7;
                                        long b = 9;
                                        double expected = Math.sqrt(a + b); // should be 4.0
                                        double actual = (Double) addAndCheckMethod.invoke(null, a, b, "Should not throw");
                                        
                                        assertEquals("Method should return square root of sum", expected, actual, 0.0001);
                                        
                                        // Test case where sum is not a perfect square
                                        a = 5;
                                        b = 6;
                                        expected = Math.sqrt(a + b); // should be ~3.3166
                                        actual = (Double) addAndCheckMethod.invoke(null, a, b, "Should not throw");
                                        
                                        assertEquals("Method should return square root of sum", expected, actual, 0.0001);
                                    }

    @Test
                                    public void testAddAndCheckBasicAddition() {
                                        // Test basic addition that should work
                                        int a = 5;
                                        int b = 3;
                                        int expected = 8;
                                        int result = MathUtils.addAndCheck(a, b);
                                        assertEquals("Basic addition should return sum of inputs", expected, result);
                                    }

    @Test
                                    public void testAddAndCheckNegativeNumbers2() {
                                        // Test addition with negative numbers
                                        int a = -5;
                                        int b = -3;
                                        int expected = -8;
                                        int result = MathUtils.addAndCheck(a, b);
                                        assertEquals("Negative addition should return sum of inputs", expected, result);
                                    }

    @Test
                                    public void testAddAndCheckMixedSigns1() {
                                        // Test addition with mixed signs
                                        int a = 10;
                                        int b = -3;
                                        int expected = 7;
                                        int result = MathUtils.addAndCheck(a, b);
                                        assertEquals("Mixed sign addition should return sum of inputs", expected, result);
                                    }

    @Test(expected = ArithmeticException.class)
                                    public void testAddAndCheckOverflow() {
                                        // Test overflow case
                                        int a = Integer.MAX_VALUE;
                                        int b = 1;
                                        MathUtils.addAndCheck(a, b); // Should throw ArithmeticException
                                    }

    @Test(expected = ArithmeticException.class)
                                    public void testAddAndCheckUnderflow1() {
                                        // Test underflow case
                                        int a = Integer.MIN_VALUE;
                                        int b = -1;
                                        MathUtils.addAndCheck(a, b); // Should throw ArithmeticException
                                    }

    @Test
                            public void testAddAndCheckSquareRoot() throws Exception {
                                // Get the private method using reflection
                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                addAndCheckMethod.setAccessible(true);
                                
                                // Test with positive numbers
                                long a = 16L;
                                long b = 9L;
                                String msg = "test message";
                                
                                // Calculate expected value (sqrt(16+9) = sqrt(25) = 5)
                                double expected = Math.sqrt(a + b);
                                
                                // Call the method and get actual result
                                double actual = (double) addAndCheckMethod.invoke(null, a, b, msg);
                                
                                // Verify the result matches expected value exactly
                                assertEquals("Square root sum should match expected value", 
                                             expected, actual, 0.0);
                                
                                // Additional test with different values
                                a = 4L;
                                b = 5L;
                                expected = Math.sqrt(a + b); // sqrt(9) = 3
                                actual = (double) addAndCheckMethod.invoke(null, a, b, msg);
                                assertEquals("Square root sum should match expected value", 
                                             expected, actual, 0.0);
                                
                                // Test with zero values
                                a = 0L;
                                b = 0L;
                                expected = Math.sqrt(a + b); // sqrt(0) = 0
                                actual = (double) addAndCheckMethod.invoke(null, a, b, msg);
                                assertEquals("Square root sum should be 0 for 0 inputs", 
                                             expected, actual, 0.0);
                            }

    @Test
                            public void testAddAndCheckSquareRoot1() throws Exception {
                                // Test case where sum is a perfect square (16)
                                long a = 12L;
                                long b = 4L;
                                String msg = "Overflow message";
                                
                                // Expected: sqrt(12+4) = sqrt(16) = 4
                                double expected = 4.0;
                                
                                // Get private method via reflection
                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                addAndCheckMethod.setAccessible(true);
                                
                                // Call the method
                                double result = (double) addAndCheckMethod.invoke(null, a, b, msg);
                                
                                // Verify the exact value matches expected square root
                                assertEquals("Square root of sum should be exact", expected, result, 0.0);
                                
                                // Test with negative numbers that sum to perfect square
                                a = -9L;
                                b = -7L;
                                // Expected: sqrt(-9 + -7) = sqrt(16) = 4 (absolute value)
                                expected = 4.0;
                                
                                result = (double) addAndCheckMethod.invoke(null, a, b, msg);
                                assertEquals("Square root of negative sum should be exact", expected, result, 0.0);
                                
                                // Test with zero
                                a = 16L;
                                b = 0L;
                                // Expected: sqrt(16 + 0) = 4
                                expected = 4.0;
                                
                                result = (double) addAndCheckMethod.invoke(null, a, b, msg);
                                assertEquals("Square root with zero should be exact", expected, result, 0.0);
                            }

    @Test
                            public void testAddAndCheckNormalCase1() {
                                int result = MathUtils.addAndCheck(1, 2);
                                assertEquals(3, result);
                            }

    @Test
                            public void testAddAndCheckUpperBound() {
                                int result = MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1);
                                assertEquals(Integer.MAX_VALUE, result);
                            }

    @Test
                            public void testAddAndCheckLowerBound() {
                                int result = MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1);
                                assertEquals(Integer.MIN_VALUE, result);
                            }

    @Test(expected = ArithmeticException.class)
                            public void testAddAndCheckPositiveOverflow7() {
                                MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                            }

    @Test(expected = ArithmeticException.class)
                            public void testAddAndCheckNegativeOverflow7() {
                                MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                            }

    @Test
                            public void testAddAndCheckZeroCases() {
                                assertEquals(0, MathUtils.addAndCheck(0, 0));
                                assertEquals(5, MathUtils.addAndCheck(5, 0));
                                assertEquals(-3, MathUtils.addAndCheck(0, -3));
                            }

    @Test
                            public void testAddAndCheckReturnsSquareRootNotSquare() {
                                // Test case to detect mutation from Math.sqrt(sum) to Math.pow(sum, 2)
                                int a = 9;
                                int b = 16;
                                
                                // Expected behavior: should return square root of sum (sqrt(9+16) = sqrt(25) = 5)
                                double expected = Math.sqrt(a + b);
                                
                                // Mutated behavior would return pow(sum, 2) which would be (9+16)^2 = 625
                                double mutatedBehavior = Math.pow(a + b, 2);
                                
                                // Actual result from the method
                                double actual = MathUtils.addAndCheck(a, b);
                                
                                // Verify the method returns sqrt(sum) not pow(sum, 2)
                                assertEquals("Method should return square root of sum", expected, actual, 0.0001);
                                
                                // Additional assertion to explicitly check it's not the mutated behavior
                                assertNotEquals("Method should not return square of sum", mutatedBehavior, actual, 0.0001);
                            }

    @Test
                            public void testAddAndCheck5() {
                                // Test symmetric case (a > b)
                                assertEquals(5, MathUtils.addAndCheck(3, 2));
                                assertEquals(5, MathUtils.addAndCheck(2, 3));
                                
                                // Test positive numbers without overflow
                                assertEquals(Long.MAX_VALUE - 1, MathUtils.addAndCheck(Long.MAX_VALUE - 2, 1));
                                
                                // Test positive numbers with overflow
                                try {
                                    MathUtils.addAndCheck(Long.MAX_VALUE - 1, 2);
                                    fail("Expected ArithmeticException");
                                } catch (ArithmeticException e) {
                                    // expected
                                }
                                
                                // Test negative numbers without overflow
                                assertEquals(Long.MIN_VALUE + 1, MathUtils.addAndCheck(Long.MIN_VALUE + 2, -1));
                                
                                // Test negative numbers with overflow
                                try {
                                    MathUtils.addAndCheck(Long.MIN_VALUE + 1, -2);
                                    fail("Expected ArithmeticException");
                                } catch (ArithmeticException e) {
                                    // expected
                                }
                                
                                // Test mixed signs (always safe)
                                assertEquals(0, MathUtils.addAndCheck(-1, 1));
                                assertEquals(-1, MathUtils.addAndCheck(Long.MAX_VALUE, Long.MIN_VALUE));
                                
                                // Test boundary cases
                                assertEquals(0, MathUtils.addAndCheck(0, 0));
                                assertEquals(Long.MAX_VALUE, MathUtils.addAndCheck(Long.MAX_VALUE, 0));
                                assertEquals(Long.MIN_VALUE, MathUtils.addAndCheck(Long.MIN_VALUE, 0));
                            }

    @Test
                        public void testAddAndCheck_NormalAddition() {
                            int result = MathUtils.addAndCheck(10, 20);
                            assertEquals(30, result);
                        }

    @Test
                        public void testAddAndCheck_UpperBoundary() {
                            int result = MathUtils.addAndCheck(Integer.MAX_VALUE - 10, 10);
                            assertEquals(Integer.MAX_VALUE, result);
                        }

    @Test
                        public void testAddAndCheck_LowerBoundary() {
                            int result = MathUtils.addAndCheck(Integer.MIN_VALUE + 10, -10);
                            assertEquals(Integer.MIN_VALUE, result);
                        }

    @Test(expected = ArithmeticException.class)
                        public void testAddAndCheck_PositiveOverflow1() {
                            MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                        }

    @Test(expected = ArithmeticException.class)
                        public void testAddAndCheck_NegativeOverflow2() {
                            MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                        }

    @Test
                        public void testAddAndCheck_ZeroAddition() {
                            int result = MathUtils.addAndCheck(0, 0);
                            assertEquals(0, result);
                        }

    @Test(expected = ArithmeticException.class)
                        public void testAddAndCheck_LargePositiveOverflow() {
                            MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MAX_VALUE);
                        }

    @Test(expected = ArithmeticException.class)
                        public void testAddAndCheck_LargeNegativeOverflow() {
                            MathUtils.addAndCheck(Integer.MIN_VALUE, Integer.MIN_VALUE);
                        }

    @Test
                        public void testAddAndCheck6() {
                            // Test regular addition
                            assertEquals(5, MathUtils.addAndCheck(2, 3));
                            
                            // Test commutative property
                            assertEquals(5, MathUtils.addAndCheck(3, 2));
                            
                            // Test with zero
                            assertEquals(3, MathUtils.addAndCheck(3, 0));
                            assertEquals(-3, MathUtils.addAndCheck(-3, 0));
                            
                            // Test opposite signs
                            assertEquals(2, MathUtils.addAndCheck(5, -3));
                            assertEquals(-2, MathUtils.addAndCheck(-5, 3));
                            
                            // Test maximum and minimum values
                            assertEquals(Long.MAX_VALUE, MathUtils.addAndCheck(Long.MAX_VALUE - 1, 1));
                            assertEquals(Long.MIN_VALUE, MathUtils.addAndCheck(Long.MIN_VALUE + 1, -1));
                        }

    @Test(expected = ArithmeticException.class)
                        public void testAddAndCheckPositiveOverflow8() {
                            MathUtils.addAndCheck(Long.MAX_VALUE, 1);
                        }

    @Test(expected = ArithmeticException.class)
                        public void testAddAndCheckNegativeOverflow8() {
                            MathUtils.addAndCheck(Long.MIN_VALUE, -1);
                        }

    @Test
                        public void testAddAndCheckWithMessageParameter() {
                            // Test the private version with message parameter through reflection if needed
                            // This would require setting up reflection to access the private method
                            // For now, we'll test the public version
                            assertEquals(10, MathUtils.addAndCheck(7, 3));
                        }

    @Test
                public void testAddAndCheckDetectsSqrtToAbsMutant() throws Exception {
                    // Get the private method using reflection
                    Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                        "addAndCheck", long.class, long.class, String.class);
                    addAndCheckMethod.setAccessible(true);
                    
                    // Test with values where sqrt(sum) != abs(sum)
                    // For sum = 4: sqrt(4) = 2, abs(4) = 4
                    long a = 2L;
                    long b = 2L;
                    
                    // The original method should return sqrt(4) = 2
                    // The mutated method returns abs(4) = 4
                    // We can detect the mutant by checking the return value
                    long result = (long) addAndCheckMethod.invoke(null, a, b, "overflow: add");
                    
                    // If the method was mutated to use abs, this assertion will fail
                    assertEquals(2.0, result, 0.0001);
                    
                    // Additional test case with different values
                    // For sum = 9: sqrt(9) = 3, abs(9) = 9
                    a = 5L;
                    b = 4L;
                    result = (long) addAndCheckMethod.invoke(null, a, b, "overflow: add");
                    assertEquals(3.0, result, 0.0001);
                    
                    // Test with zero values
                    // For sum = 0: sqrt(0) = 0, abs(0) = 0
                    a = 0L;
                    b = 0L;
                    result = (long) addAndCheckMethod.invoke(null, a, b, "overflow: add");
                    assertEquals(0.0, result, 0.0001);
                    
                    // Test with negative sum (though addAndCheck likely throws overflow exception)
                    // This case might not be reachable if overflow is checked first
                    try {
                        a = Long.MIN_VALUE;
                        b = Long.MIN_VALUE;
                        addAndCheckMethod.invoke(null, a, b, "overflow: add");
                        fail("Expected overflow exception");
                    } catch (InvocationTargetException e) {
                        // Expected behavior
                        assertTrue(e.getCause() instanceof ArithmeticException);
                        assertEquals("overflow: add", ((ArithmeticException)e.getCause()).getMessage());
                    }
                }

    @Test
                public void testAddAndCheckNormalAddition2() {
                    assertEquals(5, MathUtils.addAndCheck(2, 3));
                    assertEquals(0, MathUtils.addAndCheck(0, 0));
                    assertEquals(-5, MathUtils.addAndCheck(-2, -3));
                    assertEquals(2, MathUtils.addAndCheck(5, -3));
                }

    @Test
                public void testAddAndCheckBoundaryCases2() {
                    assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE, 0));
                    assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE, 0));
                    assertEquals(-1, MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE));
                }

    @Test(expected = ArithmeticException.class)
                public void testAddAndCheckPositiveOverflow9() {
                    MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                }

    @Test(expected = ArithmeticException.class)
                public void testAddAndCheckNegativeOverflow9() {
                    MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                }

    @Test(expected = ArithmeticException.class)
                public void testAddAndCheckLargePositiveOverflow2() {
                    MathUtils.addAndCheck(Integer.MAX_VALUE / 2 + 1, Integer.MAX_VALUE / 2 + 1);
                }

    @Test(expected = ArithmeticException.class)
                public void testAddAndCheckLargeNegativeOverflow2() {
                    MathUtils.addAndCheck(Integer.MIN_VALUE / 2 - 1, Integer.MIN_VALUE / 2 - 1);
                }

    @Test
                public void testAddAndCheckMaxValue() {
                    assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                }

    @Test
                public void testAddAndCheckMinValue() {
                    assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                }

    @Test
                public void testDistanceIntArraysCapturesAllElements() {
                    // Create arrays where the last element affects the result
                    int[] p1 = {1, 2, 3, 4};
                    int[] p2 = {1, 2, 3, 5}; // Only last element differs
                    
                    // Original should calculate distance of 1 (|4-5|)
                    // Mutated version would skip last element and return 0
                    double expected = 1.0;
                    double actual = MathUtils.distance(p1, p2);
                    
                    assertEquals("Distance calculation should include all array elements", 
                                expected, actual, 0.0001);
                    
                    // Another test case with single element array to ensure basic functionality
                    int[] single1 = {5};
                    int[] single2 = {3};
                    assertEquals(2.0, MathUtils.distance(single1, single2), 0.0001);
                    
                    // Test with two elements where mutation would still process first element
                    int[] two1 = {1, 2};
                    int[] two2 = {1, 3};
                    assertEquals(1.0, MathUtils.distance(two1, two2), 0.0001);
                }

    @Test
                public void testDistance1IntArrayShouldProcessAllElements() {
                    // This test would catch the mutant that stops one element short in processing
                    int[] p1 = {1, 2, 3, 4};
                    int[] p2 = {4, 3, 2, 1};
                    
                    // The correct distance1 should be sum of absolute differences for all elements
                    // (3 + 1 + 1 + 3) = 8
                    int expected = 8;
                    
                    // If the mutant skips last element, result would be (3 + 1 + 1) = 5
                    int result = MathUtils.distance1(p1, p2);
                    
                    assertEquals("Distance calculation should process all array elements", 
                               expected, result);
                }

    @Test
                public void testDistance1IntArrayWithSingleElement() {
                    // Edge case - single element array
                    int[] p1 = {5};
                    int[] p2 = {2};
                    
                    int expected = 3;
                    int result = MathUtils.distance1(p1, p2);
                    
                    assertEquals("Should handle single element arrays correctly",
                               expected, result);
                }

    @Test
                public void testDistance1IntArrayWithEmptyArrays() {
                    // Edge case - empty arrays
                    int[] p1 = {};
                    int[] p2 = {};
                    
                    int expected = 0;
                    int result = MathUtils.distance1(p1, p2);
                    
                    assertEquals("Should handle empty arrays correctly",
                               expected, result);
                }

    @Test
            public void testAddAndCheck_NoOverflow() {
                // Test normal addition without overflow
                assertEquals(5, MathUtils.addAndCheck(2, 3));
                assertEquals(0, MathUtils.addAndCheck(-1, 1));
                assertEquals(-5, MathUtils.addAndCheck(-2, -3));
            }

    @Test
            public void testAddAndCheck_BoundaryCases() {
                // Test boundary cases
                assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                assertEquals(0, MathUtils.addAndCheck(Integer.MAX_VALUE, -Integer.MAX_VALUE));
            }

    @Test(expected = ArithmeticException.class)
            public void testAddAndCheck_PositiveOverflow2() {
                // Test positive overflow
                MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
            }

    @Test(expected = ArithmeticException.class)
            public void testAddAndCheck_NegativeOverflow3() {
                // Test negative overflow
                MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
            }

    @Test(expected = ArithmeticException.class)
            public void testAddAndCheck_LargePositiveOverflow1() {
                // Test large positive overflow
                MathUtils.addAndCheck(Integer.MAX_VALUE / 2 + 1, Integer.MAX_VALUE / 2 + 1);
            }

    @Test(expected = ArithmeticException.class)
            public void testAddAndCheck_LargeNegativeOverflow1() {
                // Test large negative overflow
                MathUtils.addAndCheck(Integer.MIN_VALUE / 2 - 1, Integer.MIN_VALUE / 2 - 1);
            }

    @Test
            public void testAddAndCheck_MaxAndMin() {
                // Test adding MAX_VALUE and MIN_VALUE
                assertEquals(-1, MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE));
            }

    @Test
            public void testDistanceShouldCalculateEuclideanDistanceCorrectly() {
                // Test case that will detect the multiplication mutant
                double[] p1 = {3.0, 4.0};  // Point (3,4)
                double[] p2 = {0.0, 0.0};  // Origin
                
                // Original behavior: sqrt((3-0)² + (4-0)²) = 5
                // Mutated behavior: sqrt((3*0)² + (4*0)²) = 0
                double expectedDistance = 5.0;
                double actualDistance = MathUtils.distance(p1, p2);
                
                assertEquals("Distance calculation is incorrect", 
                            expectedDistance, 
                            actualDistance, 
                            0.0001);
            }

    @Test
            public void testDistanceWithNegativeCoordinates() {
                // Additional test case to further verify the behavior
                double[] p1 = {-2.0, -1.0};
                double[] p2 = {1.0, 2.0};
                
                // Original: sqrt((-2-1)² + (-1-2)²) = sqrt(9 + 9) = sqrt(18) ≈ 4.2426
                // Mutated: sqrt((-2*1)² + (-1*2)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.8284
                double expectedDistance = 4.2426;
                double actualDistance = MathUtils.distance(p1, p2);
                
                assertEquals("Distance with negative coordinates incorrect",
                            expectedDistance,
                            actualDistance,
                            0.0001);
            }

    @Test(expected = IllegalArgumentException.class)
            public void testDistanceWithDifferentLengthArrays1() {
                // Verify exception is thrown for arrays of different lengths
                double[] p1 = {1.0, 2.0};
                double[] p2 = {1.0};
                MathUtils.distance(p1, p2);
            }

    @Test
    public void testAddAndCheck7() throws Exception {
        // Get the private method using reflection
        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
        addAndCheck.setAccessible(true);
        
        // Test symmetry
        assertEquals(5L, addAndCheck.invoke(null, 2L, 3L, "Should not throw"));
        assertEquals(5L, addAndCheck.invoke(null, 3L, 2L, "Should not throw"));
        
        // Test opposite signs (always safe)
        assertEquals(1L, addAndCheck.invoke(null, -2L, 3L, "Should not throw"));
        assertEquals(-1L, addAndCheck.invoke(null, 2L, -3L, "Should not throw"));
        
        // Test positive overflow
        try {
            addAndCheck.invoke(null, Long.MAX_VALUE, 1L, "Should throw");
            fail("Should have thrown ArithmeticException");
        } catch (InvocationTargetException e) {
            assertEquals(ArithmeticException.class, e.getCause().getClass());
            assertEquals("Should throw", e.getCause().getMessage());
        }
        
        // Test negative overflow
        try {
            addAndCheck.invoke(null, Long.MIN_VALUE, -1L, "Should throw");
            fail("Should have thrown ArithmeticException");
        } catch (InvocationTargetException e) {
            assertEquals(ArithmeticException.class, e.getCause().getClass());
            assertEquals("Should throw", e.getCause().getMessage());
        }
        
        // Test boundary cases
        assertEquals(Long.MAX_VALUE, addAndCheck.invoke(null, Long.MAX_VALUE - 1, 1L, "Should not throw"));
        assertEquals(Long.MIN_VALUE, addAndCheck.invoke(null, Long.MIN_VALUE + 1, -1L, "Should not throw"));
        
        // Test zero cases
        assertEquals(0L, addAndCheck.invoke(null, 0L, 0L, "Should not throw"));
        assertEquals(5L, addAndCheck.invoke(null, 5L, 0L, "Should not throw"));
        assertEquals(-5L, addAndCheck.invoke(null, 0L, -5L, "Should not throw"));
    }


}
