package gentest.org.apache.commons.math.dfp.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.dfp.*;
import java.util.Arrays;
import org.apache.commons.math.FieldElement;
 
public class DfpTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                    public void testToDouble_PositiveInfinity() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                                                                                                                                                                        Dfp dfp;
                                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                                                                                                                            dfp = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                                                                                            throw new RuntimeException("Failed to create Dfp instance", e);
                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(dfp.isInfinite()).thenReturn(true);
                                                                                                                                                                                                                                                                        when(dfp.lessThan(any(Dfp.class))).thenReturn(false);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                                        double result = dfp.toDouble();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testToDouble_NegativeInfinity() throws Exception {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                                                                                                                                                                        when(field.getRadixDigits()).thenReturn(1); // Needed for constructor
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Use reflection to access protected constructor
                                                                                                                                                                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                                                                                                                        Dfp dfp = constructor.newInstance(field, (byte)-1, Dfp.INFINITE);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(dfp.isInfinite()).thenReturn(true);
                                                                                                                                                                                                                                                                        when(dfp.lessThan(any(Dfp.class))).thenReturn(true);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                                        double result = dfp.toDouble();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                        assertEquals(Double.NEGATIVE_INFINITY, result, 0.0);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testToDouble_NaN() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                                                                                                                                                                        Dfp dfp;
                                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                                                                                                                            dfp = constructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                                                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                                                                                            fail("Failed to create Dfp instance via reflection");
                                                                                                                                                                                                                                                                            return;
                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(dfp.isNaN()).thenReturn(true);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                                        double result = dfp.toDouble();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(result));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testToDouble_NegativeZero() throws Exception {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                                                                                                                                                                        Dfp zero = mock(Dfp.class);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Create Dfp instance using reflection to access protected constructor
                                                                                                                                                                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                                                                                                                        Dfp dfp = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(field.getZero()).thenReturn(zero);
                                                                                                                                                                                                                                                                        when(dfp.getZero()).thenReturn(zero);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Mock compare method using reflection
                                                                                                                                                                                                                                                                        Method compareMethod = Dfp.class.getDeclaredMethod("compare", Dfp.class, Dfp.class);
                                                                                                                                                                                                                                                                        compareMethod.setAccessible(true);
                                                                                                                                                                                                                                                                        when(compareMethod.invoke(dfp, dfp, zero)).thenReturn(0);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                                        double result = dfp.toDouble();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                        assertEquals(0.0, result, 0.0);
                                                                                                                                                                                                                                                                        assertTrue(Double.doubleToLongBits(result) < 0); // Negative zero
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testToDouble_NormalPositiveNumber() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                                                                                                                                                                        Dfp dfp = mock(Dfp.class); // Use mock instead of trying to instantiate directly
                                                                                                                                                                                                                                                                        Dfp zero = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp two = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp one = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp powResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp divideResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp subtractResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp multiplyResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp rintResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(field.getZero()).thenReturn(zero);
                                                                                                                                                                                                                                                                        when(field.getTwo()).thenReturn(two);
                                                                                                                                                                                                                                                                        when(field.getOne()).thenReturn(one);
                                                                                                                                                                                                                                                                        when(dfp.lessThan(zero)).thenReturn(false);
                                                                                                                                                                                                                                                                        when(dfp.greaterThan(zero)).thenReturn(true); // Replace private compare with public greaterThan
                                                                                                                                                                                                                                                                        when(dfp.log10()).thenReturn(2); // log10 of 100
                                                                                                                                                                                                                                                                        when(DfpMath.pow(two, 6)).thenReturn(powResult); // 3.32 * 2 ≈ 6
                                                                                                                                                                                                                                                                        when(powResult.lessThan(dfp)).thenReturn(true);
                                                                                                                                                                                                                                                                        when(powResult.equals(dfp)).thenReturn(false);
                                                                                                                                                                                                                                                                        when(powResult.multiply(two)).thenReturn(powResult);
                                                                                                                                                                                                                                                                        when(dfp.divide(powResult)).thenReturn(divideResult);
                                                                                                                                                                                                                                                                        when(divideResult.subtract(one)).thenReturn(subtractResult);
                                                                                                                                                                                                                                                                        when(subtractResult.multiply(any(Dfp.class))).thenReturn(multiplyResult);
                                                                                                                                                                                                                                                                        when(multiplyResult.rint()).thenReturn(rintResult);
                                                                                                                                                                                                                                                                        when(rintResult.toString()).thenReturn("4503599627370496");
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                                        double result = dfp.toDouble();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                        assertTrue(result > 0);
                                                                                                                                                                                                                                                                        assertTrue(Double.isFinite(result));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testToDouble_NormalNegativeNumber() throws Exception {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Use reflection to access protected constructor
                                                                                                                                                                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                                                                                                                        Dfp dfp = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        Dfp zero = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp two = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp one = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp powResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp divideResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp subtractResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp multiplyResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp rintResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp negated = mock(Dfp.class);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(field.getZero()).thenReturn(zero);
                                                                                                                                                                                                                                                                        when(field.getTwo()).thenReturn(two);
                                                                                                                                                                                                                                                                        when(field.getOne()).thenReturn(one);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Use reflection to access private compare method
                                                                                                                                                                                                                                                                        Method compareMethod = Dfp.class.getDeclaredMethod("compare", Dfp.class, Dfp.class);
                                                                                                                                                                                                                                                                        compareMethod.setAccessible(true);
                                                                                                                                                                                                                                                                        when(compareMethod.invoke(null, dfp, zero)).thenReturn(-1);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(dfp.negate()).thenReturn(negated);
                                                                                                                                                                                                                                                                        when(negated.log10()).thenReturn(2); // log10 of 100
                                                                                                                                                                                                                                                                        when(DfpMath.pow(two, 6)).thenReturn(powResult); // 3.32 * 2 ≈ 6
                                                                                                                                                                                                                                                                        when(powResult.lessThan(negated)).thenReturn(true);
                                                                                                                                                                                                                                                                        when(powResult.equals(negated)).thenReturn(false);
                                                                                                                                                                                                                                                                        when(powResult.multiply(two)).thenReturn(powResult);
                                                                                                                                                                                                                                                                        when(negated.divide(powResult)).thenReturn(divideResult);
                                                                                                                                                                                                                                                                        when(divideResult.subtract(one)).thenReturn(subtractResult);
                                                                                                                                                                                                                                                                        when(subtractResult.multiply(any(Dfp.class))).thenReturn(multiplyResult);
                                                                                                                                                                                                                                                                        when(multiplyResult.rint()).thenReturn(rintResult);
                                                                                                                                                                                                                                                                        when(rintResult.toString()).thenReturn("4503599627370496");
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                                        double result = dfp.toDouble();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                        assertTrue(result < 0);
                                                                                                                                                                                                                                                                        assertTrue(Double.isFinite(result));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testToDouble_SubnormalNumber() throws Exception {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                                                                                                                                                                        // Use newInstance() instead of protected constructor
                                                                                                                                                                                                                                                                        Dfp dfp = mock(Dfp.class);
                                                                                                                                                                                                                                                                        when(dfp.getField()).thenReturn(field);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        Dfp zero = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp two = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp one = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp powResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp divideResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp subtractResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp multiplyResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp rintResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(field.getZero()).thenReturn(zero);
                                                                                                                                                                                                                                                                        when(field.getTwo()).thenReturn(two);
                                                                                                                                                                                                                                                                        when(field.getOne()).thenReturn(one);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Mock comparison through public methods instead of private compare()
                                                                                                                                                                                                                                                                        when(dfp.lessThan(zero)).thenReturn(false);
                                                                                                                                                                                                                                                                        when(dfp.greaterThan(zero)).thenReturn(true);
                                                                                                                                                                                                                                                                        when(dfp.equals(zero)).thenReturn(false);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(dfp.log10()).thenReturn(-310); // Very small number
                                                                                                                                                                                                                                                                        when(DfpMath.pow(two, -1029)).thenReturn(powResult); // Will result in exponent < -1023
                                                                                                                                                                                                                                                                        when(powResult.lessThan(dfp)).thenReturn(true);
                                                                                                                                                                                                                                                                        when(powResult.equals(dfp)).thenReturn(false);
                                                                                                                                                                                                                                                                        when(powResult.multiply(two)).thenReturn(powResult);
                                                                                                                                                                                                                                                                        when(dfp.divide(powResult)).thenReturn(divideResult);
                                                                                                                                                                                                                                                                        when(divideResult.subtract(one)).thenReturn(subtractResult);
                                                                                                                                                                                                                                                                        when(subtractResult.multiply(any(Dfp.class))).thenReturn(multiplyResult);
                                                                                                                                                                                                                                                                        when(multiplyResult.rint()).thenReturn(rintResult);
                                                                                                                                                                                                                                                                        when(rintResult.toString()).thenReturn("123456789"); // Some small mantissa
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                                        double result = dfp.toDouble();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                        assertTrue(result > 0);
                                                                                                                                                                                                                                                                        assertTrue(result < Double.MIN_NORMAL); // Should be subnormal
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testToDouble_ExponentTooLarge() throws Exception {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Use reflection to access protected constructor
                                                                                                                                                                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                                                                                                                        Dfp dfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        Dfp zero = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp two = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp one = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp powResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(field.getZero()).thenReturn(zero);
                                                                                                                                                                                                                                                                        when(field.getTwo()).thenReturn(two);
                                                                                                                                                                                                                                                                        when(field.getOne()).thenReturn(one);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Mock the compare method using reflection
                                                                                                                                                                                                                                                                        Method compareMethod = Dfp.class.getDeclaredMethod("compare", Dfp.class, Dfp.class);
                                                                                                                                                                                                                                                                        compareMethod.setAccessible(true);
                                                                                                                                                                                                                                                                        when(compareMethod.invoke(dfp, dfp, zero)).thenReturn(1);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(dfp.lessThan(zero)).thenReturn(false);
                                                                                                                                                                                                                                                                        when(dfp.log10()).thenReturn(310); // Very large number
                                                                                                                                                                                                                                                                        when(DfpMath.pow(two, 1029)).thenReturn(powResult); // Will result in exponent > 1023
                                                                                                                                                                                                                                                                        when(powResult.lessThan(dfp)).thenReturn(true);
                                                                                                                                                                                                                                                                        when(powResult.equals(dfp)).thenReturn(false);
                                                                                                                                                                                                                                                                        when(powResult.multiply(two)).thenReturn(powResult);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                                        double result = dfp.toDouble();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testToDouble_ExponentTooSmall() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                                                                                                                                                                        Dfp dfp = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp zero = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp two = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp one = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp powResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(field.getZero()).thenReturn(zero);
                                                                                                                                                                                                                                                                        when(field.getTwo()).thenReturn(two);
                                                                                                                                                                                                                                                                        when(field.getOne()).thenReturn(one);
                                                                                                                                                                                                                                                                        when(dfp.getField()).thenReturn(field);
                                                                                                                                                                                                                                                                        when(dfp.lessThan(zero)).thenReturn(false);
                                                                                                                                                                                                                                                                        when(dfp.log10()).thenReturn(-310); // Very small number
                                                                                                                                                                                                                                                                        when(DfpMath.pow(two, -1075)).thenReturn(powResult); // Will result in exponent < -1074
                                                                                                                                                                                                                                                                        when(powResult.lessThan(dfp)).thenReturn(true);
                                                                                                                                                                                                                                                                        when(powResult.equals(dfp)).thenReturn(false);
                                                                                                                                                                                                                                                                        when(powResult.multiply(two)).thenReturn(powResult);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                                        double result = dfp.toDouble();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                        assertEquals(0.0, result, 0.0);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testToDouble_MantissaRoundUp() throws Exception {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Use reflection to access protected constructor
                                                                                                                                                                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                                                                                                                        Dfp dfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        Dfp zero = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp two = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp one = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp powResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp divideResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp subtractResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp multiplyResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        Dfp rintResult = mock(Dfp.class);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(field.getZero()).thenReturn(zero);
                                                                                                                                                                                                                                                                        when(field.getTwo()).thenReturn(two);
                                                                                                                                                                                                                                                                        when(field.getOne()).thenReturn(one);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Mock the compare method using reflection
                                                                                                                                                                                                                                                                        Method compareMethod = Dfp.class.getDeclaredMethod("compare", Dfp.class, Dfp.class);
                                                                                                                                                                                                                                                                        compareMethod.setAccessible(true);
                                                                                                                                                                                                                                                                        when(compareMethod.invoke(dfp, dfp, zero)).thenReturn(1);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(dfp.lessThan(zero)).thenReturn(false);
                                                                                                                                                                                                                                                                        when(dfp.log10()).thenReturn(2); // log10 of 100
                                                                                                                                                                                                                                                                        when(DfpMath.pow(two, 6)).thenReturn(powResult); // 3.32 * 2 ≈ 6
                                                                                                                                                                                                                                                                        when(powResult.lessThan(dfp)).thenReturn(true);
                                                                                                                                                                                                                                                                        when(powResult.equals(dfp)).thenReturn(false);
                                                                                                                                                                                                                                                                        when(powResult.multiply(two)).thenReturn(powResult);
                                                                                                                                                                                                                                                                        when(dfp.divide(powResult)).thenReturn(divideResult);
                                                                                                                                                                                                                                                                        when(divideResult.subtract(one)).thenReturn(subtractResult);
                                                                                                                                                                                                                                                                        when(subtractResult.multiply(any(Dfp.class))).thenReturn(multiplyResult);
                                                                                                                                                                                                                                                                        when(multiplyResult.rint()).thenReturn(rintResult);
                                                                                                                                                                                                                                                                        when(rintResult.toString()).thenReturn("4503599627370496"); // Special case that requires rounding up
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                                        double result = dfp.toDouble();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                        assertTrue(result > 0);
                                                                                                                                                                                                                                                                        assertTrue(Double.isFinite(result));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                        public void testToDouble_PositiveZero() {
                                                                                                                                                                                            // Setup
                                                                                                                                                                                            DfpField field = new DfpField(10); // Create actual field with radix digits
                                                                                                                                                                                            Dfp zero = field.getZero(); // Use field to get zero instance
                                                                                                                                                                                            
                                                                                                                                                                                            // Create Dfp instance using newInstance with double value
                                                                                                                                                                                            
                                                                                                                                                                                            // Use reflection to access private compare method
                                                                                                                                                                                            try {
                                                                                                                                                                                                Method compareMethod = Dfp.class.getDeclaredMethod("compare", Dfp.class, Dfp.class);
                                                                                                                                                                                                compareMethod.setAccessible(true);
                                                                                                                                                                                                
                                                                                                                                                                                                // Invoke the compare method directly instead of mocking
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify the comparison is as expected
                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                fail("Failed to access private compare method");
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            // Test
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                public void testNewInstanceWithZeroAndNonZero() throws Exception {
                                                                                                                                                                                    // Create a field to use for testing
                                                                                                                                                                                    DfpField field = new DfpField(20); // assuming 20 radix digits
                                                                                                                                                                                    
                                                                                                                                                                                    // Test case 1: Current instance is zero
                                                                                                                                                                                    Dfp zeroInstance = field.getZero();
                                                                                                                                                                                    Dfp newZeroInstance = zeroInstance.newInstance();
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access protected fields
                                                                                                                                                                                    Class<?> dfpClass = Dfp.class;
                                                                                                                                                                                    java.lang.reflect.Field expField = dfpClass.getDeclaredField("exp");
                                                                                                                                                                                    java.lang.reflect.Field signField = dfpClass.getDeclaredField("sign");
                                                                                                                                                                                    java.lang.reflect.Field nansField = dfpClass.getDeclaredField("nans");
                                                                                                                                                                                    java.lang.reflect.Field mantField = dfpClass.getDeclaredField("mant");
                                                                                                                                                                                    
                                                                                                                                                                                    expField.setAccessible(true);
                                                                                                                                                                                    signField.setAccessible(true);
                                                                                                                                                                                    nansField.setAccessible(true);
                                                                                                                                                                                    mantField.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify properties of new instance created from zero
                                                                                                                                                                                    assertEquals(0, expField.get(newZeroInstance));
                                                                                                                                                                                    assertEquals(1, signField.get(newZeroInstance)); // positive zero
                                                                                                                                                                                    assertEquals(Dfp.FINITE, nansField.get(newZeroInstance));
                                                                                                                                                                                    assertTrue(Arrays.equals(new int[20], (int[]) mantField.get(newZeroInstance))); // all mantissa digits should be 0
                                                                                                                                                                                    
                                                                                                                                                                                    // Test case 2: Current instance is non-zero
                                                                                                                                                                                    Dfp nonZeroInstance = field.getOne(); // value = 1
                                                                                                                                                                                    Dfp newNonZeroInstance = nonZeroInstance.newInstance();
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify properties of new instance created from non-zero
                                                                                                                                                                                    assertEquals(0, expField.get(newNonZeroInstance)); // for value 1
                                                                                                                                                                                    assertEquals(1, signField.get(newNonZeroInstance)); // positive
                                                                                                                                                                                    assertEquals(Dfp.FINITE, nansField.get(newNonZeroInstance));
                                                                                                                                                                                    // First mantissa digit should be 1, others 0
                                                                                                                                                                                    int[] expectedMant = new int[20];
                                                                                                                                                                                    expectedMant[19] = 1; // assuming mant[19] is least significant digit
                                                                                                                                                                                    assertTrue(Arrays.equals(expectedMant, (int[]) mantField.get(newNonZeroInstance)));
                                                                                                                                                                                    
                                                                                                                                                                                    // The mutation would make both cases behave the same (as non-zero),
                                                                                                                                                                                    // so this test would fail when the mutation is present
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testNewInstanceComparisonWithZero() {
                                                                                                                                                                                    // Create test field
                                                                                                                                                                                    DfpField field = new DfpField(20); // Assuming DfpField constructor takes radix digits
                                                                                                                                                                                    
                                                                                                                                                                                    // Test case 1: Positive number
                                                                                                                                                                                    Dfp positive = field.newDfp(5.0);
                                                                                                                                                                                    Dfp positiveInstance = positive.newInstance(10.0);
                                                                                                                                                                                    assertTrue(positiveInstance.greaterThan(positive.getZero()));
                                                                                                                                                                                    
                                                                                                                                                                                    // Test case 2: Zero
                                                                                                                                                                                    Dfp zero = field.newDfp(0.0);
                                                                                                                                                                                    Dfp zeroInstance = zero.newInstance(0.0);
                                                                                                                                                                                    assertTrue(zeroInstance.equals(zero.getZero()));
                                                                                                                                                                                    
                                                                                                                                                                                    // Test case 3: Negative number
                                                                                                                                                                                    Dfp negative = field.newDfp(-3.0);
                                                                                                                                                                                    Dfp negativeInstance = negative.newInstance(-2.0);
                                                                                                                                                                                    assertTrue(negativeInstance.lessThan(negative.getZero()));
                                                                                                                                                                                    
                                                                                                                                                                                    // Test case 4: Verify comparison in newInstance
                                                                                                                                                                                    // The mutation would fail this test because it always assumes cmp0=1
                                                                                                                                                                                    Dfp testValue = field.newDfp(-1.0);
                                                                                                                                                                                    Dfp newInstance = testValue.newInstance(1.0);
                                                                                                                                                                                    // If the mutation exists, this would incorrectly treat negative as positive
                                                                                                                                                                                    assertFalse("Should not treat negative as positive", 
                                                                                                                                                                                               newInstance.greaterThan(testValue.getZero()));
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testNewInstanceWithSignAndCodeHandlesZeroComparison() throws Exception {
                                                                                                                                                                                    // Setup test environment
                                                                                                                                                                                    DfpField field = mock(DfpField.class);
                                                                                                                                                                                    Dfp zeroDfp = mock(Dfp.class);
                                                                                                                                                                                    when(field.getZero()).thenReturn(zeroDfp);
                                                                                                                                                                                    
                                                                                                                                                                                    // Get protected constructor via reflection
                                                                                                                                                                                    Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Test case 1: Positive value (should pass both original and mutant)
                                                                                                                                                                                    Dfp positiveDfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                                                                                                                    Method compareMethod = Dfp.class.getDeclaredMethod("compare", Dfp.class, Dfp.class);
                                                                                                                                                                                    compareMethod.setAccessible(true);
                                                                                                                                                                                    when(compareMethod.invoke(positiveDfp, positiveDfp, zeroDfp)).thenReturn(1);
                                                                                                                                                                                    Dfp result1 = positiveDfp.newInstance((byte)1, Dfp.FINITE);
                                                                                                                                                                                    assertNotNull(result1);
                                                                                                                                                                                    
                                                                                                                                                                                    // Test case 2: Zero value (should detect mutant)
                                                                                                                                                                                    Dfp zeroValue = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                                                                                                                    when(compareMethod.invoke(zeroValue, zeroValue, zeroDfp)).thenReturn(0);
                                                                                                                                                                                    Dfp result2 = zeroValue.newInstance((byte)0, Dfp.FINITE);
                                                                                                                                                                                    // If mutant exists, this would incorrectly handle the zero case
                                                                                                                                                                                    Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                    signField.setAccessible(true);
                                                                                                                                                                                    assertEquals(0, signField.get(result2));
                                                                                                                                                                                    
                                                                                                                                                                                    // Test case 3: Negative value (should detect mutant)
                                                                                                                                                                                    Dfp negativeDfp = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                                                                                                                    when(compareMethod.invoke(negativeDfp, negativeDfp, zeroDfp)).thenReturn(-1);
                                                                                                                                                                                    Dfp result3 = negativeDfp.newInstance((byte)-1, Dfp.FINITE);
                                                                                                                                                                                    // If mutant exists, this would incorrectly handle the negative case
                                                                                                                                                                                    assertEquals(-1, signField.get(result3));
                                                                                                                                                                                }

    @Test
                                                                                                                                                                            public void testNewInstanceComparisonWithZero1() {
                                                                                                                                                                                // Create test DfpField
                                                                                                                                                                                DfpField field = new DfpField(10); // Assuming DfpField needs radix digits
                                                                                                                                                                                
                                                                                                                                                                                // Create Dfp instances for different scenarios using newInstance
                                                                                                                                                                                Dfp negativeDfp = field.newDfp().newInstance(-1);  // negative number
                                                                                                                                                                                Dfp zeroDfp = field.newDfp().newInstance(0);       // zero
                                                                                                                                                                                Dfp positiveDfp = field.newDfp().newInstance(1);   // positive number
                                                                                                                                                                                
                                                                                                                                                                                // Test negative number comparison using public methods
                                                                                                                                                                                assertTrue("Negative number should compare less than zero", 
                                                                                                                                                                                           negativeDfp.lessThan(negativeDfp.getZero()));
                                                                                                                                                                                
                                                                                                                                                                                // Test zero comparison using public methods
                                                                                                                                                                                assertTrue("Zero should compare equal to zero", 
                                                                                                                                                                                           zeroDfp.equals(zeroDfp.getZero()));
                                                                                                                                                                                
                                                                                                                                                                                // Test positive number comparison using public methods
                                                                                                                                                                                assertTrue("Positive number should compare greater than zero", 
                                                                                                                                                                                           positiveDfp.greaterThan(positiveDfp.getZero()));
                                                                                                                                                                                
                                                                                                                                                                                // Verify that newInstance() creates objects with correct field
                                                                                                                                                                                assertEquals("New instance should have same field", 
                                                                                                                                                                                            negativeDfp.getField(), negativeDfp.newInstance().getField());
                                                                                                                                                                                assertEquals("New instance should have same field", 
                                                                                                                                                                                            zeroDfp.getField(), zeroDfp.newInstance().getField());
                                                                                                                                                                                assertEquals("New instance should have same field", 
                                                                                                                                                                                            positiveDfp.getField(), positiveDfp.newInstance().getField());
                                                                                                                                                                            }

    @Test
                                                                                                                                                                            public void testNewInstanceDetectsCompareMutant() {
                                                                                                                                                                                // Setup test field
                                                                                                                                                                                DfpField field = new DfpField(10); // Assuming DfpField constructor takes radix digits
                                                                                                                                                                                
                                                                                                                                                                                // Create test cases using newInstance instead of direct constructor calls
                                                                                                                                                                                Dfp positive = field.getOne();  // compare() should return 1
                                                                                                                                                                                Dfp zero = field.getZero();     // compare() should return 0
                                                                                                                                                                                Dfp negative = field.getOne().negate(); // compare() should return -1
                                                                                                                                                                                
                                                                                                                                                                                // Test with positive value (should behave same in original and mutant)
                                                                                                                                                                                Dfp resultPos = positive.newInstance(5);
                                                                                                                                                                                assertNotNull(resultPos);
                                                                                                                                                                                
                                                                                                                                                                                // Critical test: with zero value
                                                                                                                                                                                // In original, compare(zero, zero.getZero()) would return 0
                                                                                                                                                                                // In mutant, it would use 1
                                                                                                                                                                                Dfp resultZero = zero.newInstance(0);
                                                                                                                                                                                assertNotNull(resultZero);
                                                                                                                                                                                
                                                                                                                                                                                // Critical test: with negative value
                                                                                                                                                                                // In original, compare(negative, negative.getZero()) would return -1
                                                                                                                                                                                // In mutant, it would use 1
                                                                                                                                                                                Dfp resultNeg = negative.newInstance(-5);
                                                                                                                                                                                assertNotNull(resultNeg);
                                                                                                                                                                                
                                                                                                                                                                                // Additional verification - check if sign is handled correctly
                                                                                                                                                                                // The mutant might incorrectly handle negative numbers
                                                                                                                                                                                try {
                                                                                                                                                                                    Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                    signField.setAccessible(true);
                                                                                                                                                                                    assertEquals(-1, signField.getInt(resultNeg));
                                                                                                                                                                                    assertEquals(0, signField.getInt(resultZero));
                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                    fail("Failed to access sign field: " + e.getMessage());
                                                                                                                                                                                }
                                                                                                                                                                            }

    @Test
                                                                                                                                                                            public void testNewInstanceWithDifferentSigns() throws Exception {
                                                                                                                                                                                // Setup test field
                                                                                                                                                                                DfpField field = new DfpField(20); // Assuming DfpField constructor takes radix digits
                                                                                                                                                                                
                                                                                                                                                                                // Use reflection to access protected fields
                                                                                                                                                                                Class<Dfp> dfpClass = Dfp.class;
                                                                                                                                                                                java.lang.reflect.Field signField = dfpClass.getDeclaredField("sign");
                                                                                                                                                                                java.lang.reflect.Field mantField = dfpClass.getDeclaredField("mant");
                                                                                                                                                                                java.lang.reflect.Field expField = dfpClass.getDeclaredField("exp");
                                                                                                                                                                                java.lang.reflect.Field nansField = dfpClass.getDeclaredField("nans");
                                                                                                                                                                                signField.setAccessible(true);
                                                                                                                                                                                mantField.setAccessible(true);
                                                                                                                                                                                expField.setAccessible(true);
                                                                                                                                                                                nansField.setAccessible(true);
                                                                                                                                                                                
                                                                                                                                                                                // Test with positive value - using newInstance(double) instead of constructor
                                                                                                                                                                                Dfp positive = field.newDfp(5.0);
                                                                                                                                                                                Dfp positiveCopy = positive.newInstance(positive);
                                                                                                                                                                                assertEquals(1, signField.getInt(positiveCopy));
                                                                                                                                                                                assertTrue(positive.equals(positiveCopy)); // Using equals() instead of private compare()
                                                                                                                                                                                
                                                                                                                                                                                // Test with negative value (should detect the mutant)
                                                                                                                                                                                Dfp negative = field.newDfp(-3.0);
                                                                                                                                                                                Dfp negativeCopy = negative.newInstance(negative);
                                                                                                                                                                                assertEquals(-1, signField.getInt(negativeCopy)); // This will fail if mutant is present
                                                                                                                                                                                assertTrue(negative.equals(negativeCopy));
                                                                                                                                                                                
                                                                                                                                                                                // Test with zero value (should detect the mutant)
                                                                                                                                                                                Dfp zero = field.newDfp(0.0);
                                                                                                                                                                                Dfp zeroCopy = zero.newInstance(zero);
                                                                                                                                                                                assertEquals(1, signField.getInt(zeroCopy)); // Zero should have positive sign
                                                                                                                                                                                assertTrue(zero.equals(zeroCopy));
                                                                                                                                                                                
                                                                                                                                                                                // Additional assertion to verify exact equality
                                                                                                                                                                                assertArrayEquals((int[])mantField.get(zero), (int[])mantField.get(zeroCopy));
                                                                                                                                                                                assertEquals(expField.getInt(zero), expField.getInt(zeroCopy));
                                                                                                                                                                                assertEquals(nansField.getByte(zero), nansField.getByte(zeroCopy));
                                                                                                                                                                            }

    @Test
                                                                                                                                                                public void testNewInstanceStringWithZeroComparison() {
                                                                                                                                                                    // Setup test field
                                                                                                                                                                    DfpField field = new DfpField(100);
                                                                                                                                                                    
                                                                                                                                                                    // Create base instances using protected constructor with String parameter
                                                                                                                                                                    Dfp base;
                                                                                                                                                                    try {
                                                                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, String.class);
                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                        base = constructor.newInstance(field, "0");
                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                        throw new RuntimeException("Failed to create Dfp instance", e);
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    // Test case 1: Positive number (should be > 0)
                                                                                                                                                                    Dfp positiveInstance = base.newInstance("123.456");
                                                                                                                                                                    assertTrue(positiveInstance.greaterThan(field.getZero()));
                                                                                                                                                                    
                                                                                                                                                                    // Test case 2: Zero (should equal 0)
                                                                                                                                                                    Dfp zeroInstance = base.newInstance("0");
                                                                                                                                                                    assertTrue(zeroInstance.equals(field.getZero()));
                                                                                                                                                                    
                                                                                                                                                                    // Test case 3: Negative number (should be < 0)
                                                                                                                                                                    Dfp negativeInstance = base.newInstance("-123.456");
                                                                                                                                                                    assertTrue(negativeInstance.lessThan(field.getZero()));
                                                                                                                                                                    
                                                                                                                                                                    // Test case 4: Verify comparison in mathematical operation
                                                                                                                                                                    Dfp result = positiveInstance.add(zeroInstance);
                                                                                                                                                                    assertTrue(result.equals(positiveInstance));
                                                                                                                                                                    
                                                                                                                                                                    // Test case 5: Verify comparison in mathematical operation with negative
                                                                                                                                                                    Dfp result2 = negativeInstance.add(zeroInstance);
                                                                                                                                                                    assertTrue(result2.equals(negativeInstance));
                                                                                                                                                                }

    @Test
                                                                                                                                            public void testCompareWithZero() {
                                                                                                                                                // Create a DfpField with specific radix digits
                                                                                                                                                org.apache.commons.math.dfp.DfpField field = new org.apache.commons.math.dfp.DfpField(10);
                                                                                                                                                
                                                                                                                                                // Test case 1: Current object is less than zero
                                                                                                                                                org.apache.commons.math.dfp.Dfp negativeValue = field.newDfp(-1);
                                                                                                                                                boolean isLessThanZero = negativeValue.lessThan(field.getZero());
                                                                                                                                                assertTrue("Negative value should be less than zero", isLessThanZero);
                                                                                                                                                
                                                                                                                                                // Test case 2: Current object equals zero
                                                                                                                                                org.apache.commons.math.dfp.Dfp zeroValue = field.newDfp(0);
                                                                                                                                                boolean isEqualToZero = zeroValue.equals(field.getZero());
                                                                                                                                                assertTrue("Zero value should equal zero", isEqualToZero);
                                                                                                                                                
                                                                                                                                                // Test case 3: Current object is greater than zero
                                                                                                                                                org.apache.commons.math.dfp.Dfp positiveValue = field.newDfp(1);
                                                                                                                                                boolean isGreaterThanZero = positiveValue.greaterThan(field.getZero());
                                                                                                                                                assertTrue("Positive value should be greater than zero", isGreaterThanZero);
                                                                                                                                            }

    @Test
                                                                                                                                    public void testNewInstanceShouldNotReturnOne() throws Exception {
                                                                                                                                        // Setup
                                                                                                                                        DfpField mockField = mock(DfpField.class);
                                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                        Dfp original = constructor.newInstance(mockField, 5);
                                                                                                                                        
                                                                                                                                        // Mock getOne() to return a specific Dfp if needed
                                                                                                                                        Dfp one = constructor.newInstance(mockField, 1);
                                                                                                                                        when(mockField.getOne()).thenReturn(one);
                                                                                                                                        
                                                                                                                                        // Test
                                                                                                                                        Dfp result = original.newInstance();
                                                                                                                                        
                                                                                                                                        // Verify
                                                                                                                                        assertNotEquals("newInstance should not return the value one", 
                                                                                                                                                       one, result);
                                                                                                                                        assertEquals("Should maintain the same field", 
                                                                                                                                                    original.getField(), result.getField());
                                                                                                                                        
                                                                                                                                        // Additional check to ensure it's not returning one
                                                                                                                                        assertFalse(result.equals(one));
                                                                                                                                    }

    @Test
                                                                                                                                    public void testNewInstanceWithSigAndCodePreservesOriginalProperties() throws Exception {
                                                                                                                                        // Create a test DfpField
                                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                                        
                                                                                                                                        // Create original Dfp with specific properties using reflection
                                                                                                                                        byte originalSign = -1;
                                                                                                                                        byte originalNans = Dfp.INFINITE;
                                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                        Dfp original = constructor.newInstance(field, originalSign, originalNans);
                                                                                                                                        
                                                                                                                                        // Mock the field's newDfp method to just pass through the parameters
                                                                                                                                        when(field.newDfp(anyByte(), anyByte())).thenAnswer(invocation -> {
                                                                                                                                            byte sig = invocation.getArgument(0);
                                                                                                                                            byte code = invocation.getArgument(1);
                                                                                                                                            Constructor<Dfp> ctor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                            ctor.setAccessible(true);
                                                                                                                                            return ctor.newInstance(field, sig, code);
                                                                                                                                        });
                                                                                                                                        
                                                                                                                                        // Test data
                                                                                                                                        byte testSig = 1;
                                                                                                                                        byte testCode = Dfp.QNAN;
                                                                                                                                        
                                                                                                                                        // Create new instance
                                                                                                                                        Dfp newInstance = original.newInstance(testSig, testCode);
                                                                                                                                        
                                                                                                                                        // Use reflection to access private/protected fields for verification
                                                                                                                                        Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                        signField.setAccessible(true);
                                                                                                                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                        nansField.setAccessible(true);
                                                                                                                                        Field fieldField = Dfp.class.getDeclaredField("field");
                                                                                                                                        fieldField.setAccessible(true);
                                                                                                                                        
                                                                                                                                        // Verify the new instance has:
                                                                                                                                        // 1. The test signature we passed
                                                                                                                                        // 2. The test code we passed
                                                                                                                                        // 3. The same field as original
                                                                                                                                        assertEquals("Signature should match input", testSig, signField.get(newInstance));
                                                                                                                                        assertEquals("Code should match input", testCode, nansField.get(newInstance));
                                                                                                                                        assertSame("Field should be the same", fieldField.get(original), fieldField.get(newInstance));
                                                                                                                                        
                                                                                                                                        // Verify the field's newDfp was called with our parameters
                                                                                                                                        verify(field).newDfp(testSig, testCode);
                                                                                                                                    }

    @Test
                                                                                                                            public void testNewInstanceFieldConsistency() throws Exception {
                                                                                                                                // Create mock fields
                                                                                                                                DfpField originalField = mock(DfpField.class);
                                                                                                                                DfpField differentField = mock(DfpField.class);
                                                                                                                                
                                                                                                                                // Get the protected int constructor
                                                                                                                                Constructor<Dfp> intConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                                                intConstructor.setAccessible(true);
                                                                                                                                
                                                                                                                                // Create test Dfp instances
                                                                                                                                Dfp original = intConstructor.newInstance(originalField, 0);
                                                                                                                                Dfp one = intConstructor.newInstance(differentField, 1);
                                                                                                                                
                                                                                                                                // Mock getOne() to return our test instance
                                                                                                                                when(original.getOne()).thenReturn(one);
                                                                                                                                
                                                                                                                                // Call the method under test
                                                                                                                                Dfp result = original.newInstance();
                                                                                                                                
                                                                                                                                // Verify the result has the same field as original
                                                                                                                                assertSame("newInstance should use the original object's field", 
                                                                                                                                          originalField, result.getField());
                                                                                                                                
                                                                                                                                // Verify getOne() wasn't called
                                                                                                                                verify(original, never()).getOne();
                                                                                                                            }

    @Test
                                                                                                                            public void testNewInstanceDfpCopiesValueCorrectly() {
                                                                                                                                // Setup test environment
                                                                                                                                DfpField field = new DfpField(10);
                                                                                                                                Dfp original;
                                                                                                                                try {
                                                                                                                                    // Access protected constructor via reflection
                                                                                                                                    java.lang.reflect.Constructor<Dfp> constructor = 
                                                                                                                                        Dfp.class.getDeclaredConstructor(DfpField.class, String.class);
                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                    original = constructor.newInstance(field, "12345");
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Failed to create Dfp instance: " + e.getMessage());
                                                                                                                                    return;
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Test the newInstance method
                                                                                                                                Dfp copy = original.newInstance(original);
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    // Use reflection to access protected/private fields
                                                                                                                                    java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                    mantField.setAccessible(true);
                                                                                                                                    int[] originalMant = (int[]) mantField.get(original);
                                                                                                                                    int[] copyMant = (int[]) mantField.get(copy);
                                                                                                                                    
                                                                                                                                    java.lang.reflect.Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                    signField.setAccessible(true);
                                                                                                                                    byte originalSign = signField.getByte(original);
                                                                                                                                    byte copySign = signField.getByte(copy);
                                                                                                                                    
                                                                                                                                    java.lang.reflect.Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                                    expField.setAccessible(true);
                                                                                                                                    int originalExp = expField.getInt(original);
                                                                                                                                    int copyExp = expField.getInt(copy);
                                                                                                                                    
                                                                                                                                    java.lang.reflect.Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                    nansField.setAccessible(true);
                                                                                                                                    byte originalNans = nansField.getByte(original);
                                                                                                                                    byte copyNans = nansField.getByte(copy);
                                                                                                                                    
                                                                                                                                    java.lang.reflect.Field fieldField = Dfp.class.getDeclaredField("field");
                                                                                                                                    fieldField.setAccessible(true);
                                                                                                                                    DfpField originalField = (DfpField) fieldField.get(original);
                                                                                                                                    DfpField copyField = (DfpField) fieldField.get(copy);
                                                                                                                                    
                                                                                                                                    // Verify the copy has the same value as original
                                                                                                                                    assertEquals("Mantissa should be copied", originalMant[originalMant.length-1], copyMant[copyMant.length-1]);
                                                                                                                                    assertEquals("Sign should be copied", originalSign, copySign);
                                                                                                                                    assertEquals("Exponent should be copied", originalExp, copyExp);
                                                                                                                                    assertEquals("NaN status should be copied", originalNans, copyNans);
                                                                                                                                    
                                                                                                                                    // Verify field properties are the same
                                                                                                                                    assertSame("Field should be the same", originalField, copyField);
                                                                                                                                    
                                                                                                                                    // Additional check for complete value equality
                                                                                                                                    assertEquals("Complete value should be equal", original.toString(), copy.toString());
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Reflection failed: " + e.getMessage());
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                    public void testNewInstanceReturnsCorrectValue() throws Exception {
                                                                                                                        // Setup test objects
                                                                                                                        DfpField mockField = mock(DfpField.class);
                                                                                                                        
                                                                                                                        // Get protected constructor and make it accessible
                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                                        constructor.setAccessible(true);
                                                                                                                        
                                                                                                                        // Create instances using reflection
                                                                                                                        Dfp original = constructor.newInstance(mockField, 5);
                                                                                                                        Dfp expectedOne = constructor.newInstance(mockField, 1);
                                                                                                                        
                                                                                                                        // Mock getOne() to return a specific instance
                                                                                                                        when(mockField.getOne()).thenReturn(expectedOne);
                                                                                                                        
                                                                                                                        // Call the method under test
                                                                                                                        Dfp result = original.newInstance();
                                                                                                                        
                                                                                                                        // Verify the result is not the "one" value (which would indicate mutant survived)
                                                                                                                        assertNotEquals("newInstance() should not return the 'one' value", 
                                                                                                                                        expectedOne, result);
                                                                                                                        
                                                                                                                        // Additional verification that it's not null
                                                                                                                        assertNotNull("newInstance() should not return null", result);
                                                                                                                        
                                                                                                                        // Verify getOne() was not called (which the mutant would do)
                                                                                                                        verify(mockField, never()).getOne();
                                                                                                                    }

    @Test
                                                                                                    public void testNewInstanceDetectsMutant() throws Exception {
                                                                                                        // Create mock field objects to differentiate between original and getOne() fields
                                                                                                        DfpField originalField = mock(DfpField.class);
                                                                                                        DfpField differentField = mock(DfpField.class);
                                                                                                        
                                                                                                        // Get the protected constructor and make it accessible
                                                                                                        Constructor<Dfp> intConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                        intConstructor.setAccessible(true);
                                                                                                        
                                                                                                        // Create test Dfp object with original field using int constructor
                                                                                                        Dfp originalDfp = intConstructor.newInstance(originalField, 0);
                                                                                                        
                                                                                                        // Create a Dfp with different field for getOne() to return
                                                                                                        Dfp oneDfp = intConstructor.newInstance(differentField, 0);
                                                                                                        when(originalField.getOne()).thenReturn(oneDfp);
                                                                                                        
                                                                                                        // Call newInstance()
                                                                                                        Dfp newInstance = originalDfp.newInstance();
                                                                                                        
                                                                                                        // Verify the new instance has the original field, not the getOne() field
                                                                                                        assertSame("New instance should have same field as original object", 
                                                                                                                  originalField, newInstance.getField());
                                                                                                        
                                                                                                        // Additional verification that it's not using getOne()'s field
                                                                                                        assertNotSame("New instance should not have getOne()'s field",
                                                                                                                     differentField, newInstance.getField());
                                                                                                    }

    @Test
                                                                                                    public void testNewInstanceDetectsMutant1() throws Exception {
                                                                                                        // Create mock field objects to differentiate between original and getOne() fields
                                                                                                        DfpField originalField = mock(DfpField.class);
                                                                                                        DfpField differentField = mock(DfpField.class);
                                                                                                        
                                                                                                        // Get the protected constructor Dfp(DfpField, String)
                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, String.class);
                                                                                                        constructor.setAccessible(true);
                                                                                                        
                                                                                                        // Create test Dfp object with original field using the constructor
                                                                                                        Dfp originalDfp = constructor.newInstance(originalField, "0");
                                                                                                        
                                                                                                        // Create a Dfp with different field for getOne() to return
                                                                                                        Dfp oneDfp = constructor.newInstance(differentField, "0");
                                                                                                        when(originalField.getOne()).thenReturn(oneDfp);
                                                                                                        
                                                                                                        // Call newInstance()
                                                                                                        Dfp newInstance = originalDfp.newInstance();
                                                                                                        
                                                                                                        // Verify the new instance has the original field, not the getOne() field
                                                                                                        assertSame("New instance should have same field as original object", 
                                                                                                                  originalField, newInstance.getField());
                                                                                                        
                                                                                                        // Additional verification that it's not using getOne()'s field
                                                                                                        assertNotSame("New instance should not have getOne()'s field",
                                                                                                                     differentField, newInstance.getField());
                                                                                                    }

    @Test
                                                                                                public void testNewInstanceCreatesNewObjectWithSameField() {
                                                                                                    // Setup
                                                                                                    DfpField mockField = mock(DfpField.class);
                                                                                                    
                                                                                                    // Create original instance using reflection to access protected constructor
                                                                                                    Dfp original;
                                                                                                    Dfp expectedOne;
                                                                                                    try {
                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                        constructor.setAccessible(true);
                                                                                                        original = constructor.newInstance(mockField, 0);
                                                                                                        expectedOne = constructor.newInstance(mockField, 1);
                                                                                                    } catch (Exception e) {
                                                                                                        throw new RuntimeException("Failed to create Dfp instance", e);
                                                                                                    }
                                                                                                    
                                                                                                    // Mock the getOne() behavior
                                                                                                    when(mockField.getOne()).thenReturn(expectedOne);
                                                                                                    
                                                                                                    // Exercise
                                                                                                    Dfp result = original.newInstance();
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertNotSame("Should not return the same instance", original, result);
                                                                                                    assertNotSame("Should not return field's one value", expectedOne, result);
                                                                                                    assertEquals("Should have the same field", mockField, result.getField());
                                                                                                    
                                                                                                    // Additional verification to ensure it's a fresh instance
                                                                                                    assertNotNull(result);
                                                                                                    verify(mockField, never()).getOne(); // This would fail if mutant is present
                                                                                                }

    @Test
                                                                                        public void testNewInstanceSignPreservation() throws Exception {
                                                                                            // Create a mock DfpField
                                                                                            DfpField mockField = mock(DfpField.class);
                                                                                            when(mockField.getRadixDigits()).thenReturn(16); // Assuming a default value
                                                                                            
                                                                                            // Create a Dfp with negative sign using reflection since constructor is protected
                                                                                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                            constructor.setAccessible(true);
                                                                                            Dfp original = constructor.newInstance(mockField, (byte)-1, Dfp.FINITE);
                                                                                            
                                                                                            // Call newInstance
                                                                                            Dfp newInstance = original.newInstance();
                                                                                            
                                                                                            // Verify the new instance has the same field
                                                                                            assertEquals(mockField, newInstance.getField());
                                                                                            
                                                                                            // Verify the sign is preserved (should be -1, but mutant would make it +1)
                                                                                            Field signField = Dfp.class.getDeclaredField("sign");
                                                                                            signField.setAccessible(true);
                                                                                            assertEquals(-1, signField.get(newInstance));
                                                                                            
                                                                                            // Additional verification that it's a finite zero
                                                                                            Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                            nansField.setAccessible(true);
                                                                                            assertEquals(Dfp.FINITE, nansField.get(newInstance));
                                                                                            
                                                                                            Field expField = Dfp.class.getDeclaredField("exp");
                                                                                            expField.setAccessible(true);
                                                                                            assertEquals(0, expField.get(newInstance));
                                                                                            
                                                                                            Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                            mantField.setAccessible(true);
                                                                                            int[] mant = (int[]) mantField.get(newInstance);
                                                                                            for (int m : mant) {
                                                                                                assertEquals(0, m);
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testNewInstancePreservesNegativeZeroSign() throws Exception {
                                                                                            // Create a field instance
                                                                                            DfpField field = new DfpField(10); // Using 10 as example radix digits
                                                                                            
                                                                                            // Get the protected Dfp constructor that takes double
                                                                                            Constructor<Dfp> doubleConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
                                                                                            doubleConstructor.setAccessible(true);
                                                                                            
                                                                                            // Create a Dfp instance with negative zero
                                                                                            Dfp original = doubleConstructor.newInstance(field, -0.0);
                                                                                            
                                                                                            // Create new instance which should preserve the sign
                                                                                            Dfp newInstance = original.newInstance(-0.0);
                                                                                            
                                                                                            // Get the protected sign field using reflection
                                                                                            Field signField = Dfp.class.getDeclaredField("sign");
                                                                                            signField.setAccessible(true);
                                                                                            int signValue = signField.getInt(newInstance);
                                                                                            
                                                                                            // Verify the sign is preserved (should be -1 for negative zero)
                                                                                            assertEquals("Sign of negative zero should be preserved", 
                                                                                                        -1, signValue);
                                                                                            
                                                                                            // Additional check - verify the double value is negative zero
                                                                                            assertEquals("Double value should be negative zero", 
                                                                                                        -0.0, newInstance.toDouble(), 0.0);
                                                                                        }

    @Test
                                                                                        public void testNewInstancePreservesNegativeZero() throws Exception {
                                                                                            // Setup test environment
                                                                                            DfpField field1 = new DfpField(10); // Assuming DfpField constructor exists
                                                                                            DfpField field2 = new DfpField(20); // Different radix digits
                                                                                            
                                                                                            // Create a negative zero Dfp using reflection to access protected constructor
                                                                                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                            constructor.setAccessible(true);
                                                                                            Dfp negativeZero = constructor.newInstance(field1, (byte)-1, Dfp.FINITE);
                                                                                            
                                                                                            // Set exp and mantissa using reflection
                                                                                            Field expField = Dfp.class.getDeclaredField("exp");
                                                                                            expField.setAccessible(true);
                                                                                            expField.set(negativeZero, 0);
                                                                                            
                                                                                            Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                            mantField.setAccessible(true);
                                                                                            int[] mant = (int[]) mantField.get(negativeZero);
                                                                                            Arrays.fill(mant, 0);
                                                                                            
                                                                                            // Test case 1: Different radix digits (should return QNAN)
                                                                                            Dfp result1 = negativeZero.newInstance(field2.getZero());
                                                                                            Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                            nansField.setAccessible(true);
                                                                                            assertEquals("Different radix should return QNAN", Dfp.QNAN, nansField.get(result1));
                                                                                            
                                                                                            // Test case 2: Same radix digits (should preserve sign)
                                                                                            Dfp sameRadixDfp = constructor.newInstance(field1, (byte)-1, Dfp.FINITE);
                                                                                            expField.set(sameRadixDfp, 0);
                                                                                            mant = (int[]) mantField.get(sameRadixDfp);
                                                                                            Arrays.fill(mant, 0);
                                                                                            
                                                                                            Dfp result2 = negativeZero.newInstance(sameRadixDfp);
                                                                                            Field signField = Dfp.class.getDeclaredField("sign");
                                                                                            signField.setAccessible(true);
                                                                                            assertEquals("Same radix should preserve negative zero", 
                                                                                                         (byte)-1, signField.get(result2));
                                                                                            assertEquals("Should be finite", Dfp.FINITE, nansField.get(result2));
                                                                                            mant = (int[]) mantField.get(result2);
                                                                                            assertTrue("All mantissa bits should be zero", 
                                                                                                      Arrays.stream(mant).allMatch(i -> i == 0));
                                                                                            
                                                                                            // Test case 3: Explicitly test zero sign preservation
                                                                                            Dfp positiveZero = constructor.newInstance(field1, (byte)1, Dfp.FINITE);
                                                                                            expField.set(positiveZero, 0);
                                                                                            mant = (int[]) mantField.get(positiveZero);
                                                                                            Arrays.fill(mant, 0);
                                                                                            
                                                                                            Dfp result3 = positiveZero.newInstance(sameRadixDfp);
                                                                                            assertEquals("Should preserve positive zero", 
                                                                                                        (byte)1, signField.get(result3));
                                                                                        }

    @Test
                                                                                public void testNewInstanceWithNegativeSignReturnsNegativeZero() {
                                                                                    // Setup
                                                                                    DfpField mockField = mock(DfpField.class);
                                                                                    // Create a Dfp instance using the public copy constructor
                                                                                    // First create a temporary Dfp using reflection
                                                                                    Dfp tempDfp = null;
                                                                                    try {
                                                                                        Constructor<Dfp> tempConstructor = Dfp.class.getDeclaredConstructor(DfpField.class);
                                                                                        tempConstructor.setAccessible(true);
                                                                                        tempDfp = tempConstructor.newInstance(mockField);
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to create temporary Dfp instance via reflection: " + e.getMessage());
                                                                                    }
                                                                                    Dfp dfp = new Dfp(tempDfp);
                                                                                    
                                                                                    // Mock the newDfp method to return our test value
                                                                                    // Need to use reflection to create the test Dfp instance since the constructor is protected
                                                                                    Dfp negativeZero = null;
                                                                                    try {
                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                        constructor.setAccessible(true);
                                                                                        negativeZero = constructor.newInstance(mockField, (byte)-1, Dfp.FINITE);
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to create Dfp instance via reflection: " + e.getMessage());
                                                                                    }
                                                                                    
                                                                                    when(mockField.newDfp(anyByte(), anyByte())).thenReturn(negativeZero);
                                                                                    
                                                                                    // Test negative sign case
                                                                                    byte negativeSign = -1;
                                                                                    byte code = 0; // arbitrary code value
                                                                                    
                                                                                    // Execute
                                                                                    Dfp result = dfp.newInstance(negativeSign, code);
                                                                                    
                                                                                    // Verify - should be negative zero
                                                                                    assertTrue("Negative sign should produce negative zero", 
                                                                                              Double.compare(result.toDouble(), -0.0) == 0);
                                                                                }

    @Test
                                                                                public void testNewInstanceWithPositiveSignReturnsPositiveZero() {
                                                                                    // Setup
                                                                                    DfpField mockField = mock(DfpField.class);
                                                                                    
                                                                                    // Create a Dfp instance using reflection to access protected constructor
                                                                                    Dfp dfp;
                                                                                    try {
                                                                                        Constructor<Dfp> baseConstructor = Dfp.class.getDeclaredConstructor(DfpField.class);
                                                                                        baseConstructor.setAccessible(true);
                                                                                        dfp = baseConstructor.newInstance(mockField);
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to create base Dfp instance through reflection: " + e.getMessage());
                                                                                        return;
                                                                                    }
                                                                                    
                                                                                    // Mock the newDfp method - need to use reflection to access protected constructor
                                                                                    try {
                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                        constructor.setAccessible(true);
                                                                                        Dfp mockDfp = constructor.newInstance(mockField, (byte)1, Dfp.FINITE);
                                                                                        when(mockField.newDfp(anyByte(), anyByte())).thenReturn(mockDfp);
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to create Dfp instance through reflection: " + e.getMessage());
                                                                                    }
                                                                                    
                                                                                    // Test positive sign case
                                                                                    byte positiveSign = 1;
                                                                                    byte code = 0; // arbitrary code value
                                                                                    
                                                                                    // Execute
                                                                                    Dfp result = dfp.newInstance(positiveSign, code);
                                                                                    
                                                                                    // Verify - should be positive zero
                                                                                    assertTrue("Positive sign should produce positive zero", 
                                                                                              Double.compare(result.toDouble(), +0.0) == 0);
                                                                                }

    @Test
                                                                        public void testNewInstanceWithNegativeZero() throws Exception {
                                                                            // Create a field instance to use for testing
                                                                            DfpField field = new DfpField(20); // Assuming 20 digits of precision
                                                                            
                                                                            // Create a Dfp instance from -0.0 using the protected constructor via reflection
                                                                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, String.class);
                                                                            constructor.setAccessible(true);
                                                                            Dfp original = constructor.newInstance(field, "-0.0");
                                                                            
                                                                            // Create new instance using the method
                                                                            Dfp newInstance = original.newInstance(-0.0);
                                                                            
                                                                            // Use reflection to access protected fields
                                                                            Class<?> dfpClass = Dfp.class;
                                                                            java.lang.reflect.Field signField = dfpClass.getDeclaredField("sign");
                                                                            signField.setAccessible(true);
                                                                            java.lang.reflect.Field expField = dfpClass.getDeclaredField("exp");
                                                                            expField.setAccessible(true);
                                                                            java.lang.reflect.Field mantField = dfpClass.getDeclaredField("mant");
                                                                            mantField.setAccessible(true);
                                                                            java.lang.reflect.Field nansField = dfpClass.getDeclaredField("nans");
                                                                            nansField.setAccessible(true);
                                                                            
                                                                            // Verify the new instance preserved the negative zero
                                                                            assertEquals(-1, signField.getInt(newInstance)); // Should be negative sign
                                                                            assertTrue(Double.doubleToLongBits(newInstance.toDouble()) < 0); // Check sign bit
                                                                            
                                                                            // Additional checks to ensure it's really zero
                                                                            assertEquals(0, expField.getInt(newInstance));
                                                                            int[] mant = (int[]) mantField.get(newInstance);
                                                                            for (int m : mant) {
                                                                                assertEquals(0, m); // All mantissa digits should be zero
                                                                            }
                                                                            assertEquals(Dfp.FINITE, nansField.get(newInstance)); // Should be finite
                                                                        }

    @Test
                                                            public void testNewInstancePreservesNegativeZeroSign1() {
                                                                // Setup
                                                                DfpField field = mock(DfpField.class);
                                                                when(field.getRadixDigits()).thenReturn(4); // Example value
                                                                
                                                                // Create initial Dfp instance using public constructor with another Dfp instance
                                                                // First create a zero instance using the String constructor (which is protected)
                                                                // We'll use reflection to access it
                                                                try {
                                                                    Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, String.class);
                                                                    constructor.setAccessible(true);
                                                                    Dfp baseDfp = constructor.newInstance(field, "0.0");
                                                                    
                                                                    // Create a new instance using the public copy constructor
                                                                    baseDfp = new Dfp(baseDfp);
                                                                    
                                                                    // Test negative zero
                                                                    double negativeZero = -0.0;
                                                                    Dfp dfp = baseDfp.newInstance(negativeZero);
                                                                    
                                                                    // Verify the sign is preserved using reflection to access protected field
                                                                    Field signField = Dfp.class.getDeclaredField("sign");
                                                                    signField.setAccessible(true);
                                                                    int negativeZeroSign = signField.getInt(dfp);
                                                                    assertEquals("Sign of -0.0 should be preserved", -1, negativeZeroSign);
                                                                    
                                                                    // Additional check for positive zero for completeness
                                                                    Dfp positiveZeroDfp = baseDfp.newInstance(0.0);
                                                                    int positiveZeroSign = signField.getInt(positiveZeroDfp);
                                                                    assertEquals("Sign of +0.0 should be preserved", 1, positiveZeroSign);
                                                                } catch (Exception e) {
                                                                    fail("Reflection failed: " + e.getMessage());
                                                                }
                                                            }

    @Test
                                                        public void testNewInstancePreservesNegativeZeroSign2() {
                                                            // Setup
                                                            DfpField field = mock(DfpField.class);
                                                            when(field.getRadixDigits()).thenReturn(4); // Example value
                                                            
                                                            try {
                                                                // Create initial Dfp instance using protected constructor with double parameter
                                                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
                                                                constructor.setAccessible(true);
                                                                Dfp baseDfp = constructor.newInstance(field, 0.0);
                                                                
                                                                // Create a new instance using the public copy constructor
                                                                baseDfp = new Dfp(baseDfp);
                                                                
                                                                // Test negative zero
                                                                double negativeZero = -0.0;
                                                                Dfp dfp = baseDfp.newInstance(negativeZero);
                                                                
                                                                // Verify the sign is preserved using reflection to access protected field
                                                                Field signField = Dfp.class.getDeclaredField("sign");
                                                                signField.setAccessible(true);
                                                                int negativeZeroSign = signField.getInt(dfp);
                                                                assertEquals("Sign of -0.0 should be preserved", -1, negativeZeroSign);
                                                                
                                                                // Additional check for positive zero for completeness
                                                                Dfp positiveZeroDfp = baseDfp.newInstance(0.0);
                                                                int positiveZeroSign = signField.getInt(positiveZeroDfp);
                                                                assertEquals("Sign of +0.0 should be preserved", 1, positiveZeroSign);
                                                            } catch (Exception e) {
                                                                fail("Reflection failed: " + e.getMessage());
                                                            }
                                                        }

    @Test
                                                        public void testNewInstancePreservesNegativeZeroSign3() throws Exception {
                                                            // Create a field instance to use for testing
                                                            DfpField field = new DfpField(20); // Assuming DfpField constructor takes radix digits
                                                            
                                                            // Create a Dfp instance with negative zero by creating zero and then negating it
                                                            Dfp original = field.getZero();
                                                            original = original.negate(); // This creates negative zero
                                                            
                                                            // Create new instance - original should preserve sign, mutant will always use +0.0
                                                            Dfp newInstance = original.newInstance(original.toDouble());
                                                            
                                                            // Use reflection to access the protected sign field
                                                            Field signField = Dfp.class.getDeclaredField("sign");
                                                            signField.setAccessible(true);
                                                            byte signValue = (byte) signField.get(newInstance);
                                                            
                                                            // Verify the sign is preserved (should be -1 for negative zero)
                                                            assertEquals("Sign of negative zero should be preserved", 
                                                                        (byte)-1, signValue);
                                                                        
                                                            // Additional verification through string representation
                                                            assertTrue("String representation should show negative zero",
                                                                     newInstance.toString().startsWith("-0"));
                                                        }

    @Test
                                                public void testNewInstanceSignForZero() throws Exception {
                                                    // Setup - create a Dfp field and instance with positive sign
                                                    DfpField field = new DfpField(20);
                                                    
                                                    // Use reflection to access protected constructor
                                                    Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                    constructor.setAccessible(true);
                                                    
                                                    // Create original with positive sign
                                                    Dfp original = constructor.newInstance(field, (byte)1, (byte)Dfp.FINITE);
                                                    
                                                    // Test - create new instance
                                                    Dfp result = original.newInstance(0.0);
                                                    
                                                    // Use reflection to access protected sign field
                                                    Field signField = Dfp.class.getDeclaredField("sign");
                                                    signField.setAccessible(true);
                                                    
                                                    // Verify the sign is preserved for zero
                                                    assertEquals("Positive zero should have sign 1", 1, signField.get(result));
                                                    assertTrue("Value should be zero", result.equals(field.getZero()));
                                                    
                                                    // Additional test for negative zero case
                                                    Dfp negativeOriginal = constructor.newInstance(field, (byte)-1, (byte)Dfp.FINITE);
                                                    Dfp negativeResult = negativeOriginal.newInstance(0.0);
                                                    assertEquals("Negative zero should have sign -1", -1, signField.get(negativeResult));
                                                    assertTrue("Value should be zero", negativeResult.equals(field.getZero()));
                                                }

    @Test
                                                public void testNewInstanceSignHandling() throws Exception {
                                                    // Create a DfpField instance
                                                    DfpField field = new DfpField(10); // Using arbitrary radix digits
                                                    
                                                    // Get the protected constructor
                                                    Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                    constructor.setAccessible(true);
                                                    
                                                    // Test with positive sign
                                                    byte positiveSign = 1;
                                                    byte code = 0; // Assuming code represents zero
                                                    Dfp positiveZero = constructor.newInstance(field, positiveSign, code);
                                                    
                                                    // Verify it creates positive zero (original behavior)
                                                    assertFalse("Positive sign should create positive zero", 
                                                               Double.valueOf(positiveZero.toDouble()).equals(-0.0));
                                                    
                                                    // Test with negative sign
                                                    byte negativeSign = -1;
                                                    Dfp negativeZero = constructor.newInstance(field, negativeSign, code);
                                                    
                                                    // Verify it creates negative zero
                                                    assertTrue("Negative sign should create negative zero", 
                                                              Double.valueOf(negativeZero.toDouble()).equals(-0.0));
                                                    
                                                    // Additional check using Dfp's sign field via reflection
                                                    Field signField = Dfp.class.getDeclaredField("sign");
                                                    signField.setAccessible(true);
                                                    
                                                    assertEquals("Positive sign Dfp should have sign=1", 
                                                                1, signField.get(positiveZero));
                                                    assertEquals("Negative sign Dfp should have sign=-1", 
                                                                -1, signField.get(negativeZero));
                                                }

    @Test
                                            public void testNewInstanceSignHandling1() throws Exception {
                                                // Create a mock field
                                                DfpField field = mock(DfpField.class);
                                                
                                                // Get the sign field for reflection access
                                                Field signField = Dfp.class.getDeclaredField("sign");
                                                signField.setAccessible(true);
                                                
                                                // Get the protected constructor
                                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                constructor.setAccessible(true);
                                                
                                                // Test with positive sign
                                                Dfp positiveDfp = constructor.newInstance(field, (byte)1, (byte)0);
                                                Dfp newPositiveInstance = positiveDfp.newInstance();
                                                assertEquals("New instance from positive Dfp should have positive sign", 
                                                            1, signField.getInt(newPositiveInstance));
                                                
                                                // Test with negative sign
                                                Dfp negativeDfp = constructor.newInstance(field, (byte)-1, (byte)0);
                                                Dfp newNegativeInstance = negativeDfp.newInstance();
                                                assertEquals("New instance from negative Dfp should have negative sign", 
                                                            -1, signField.getInt(newNegativeInstance));
                                                
                                                // Additional test for zero case
                                                Dfp zeroDfp = constructor.newInstance(field, (byte)1, (byte)0); // positive zero
                                                Dfp newZeroInstance = zeroDfp.newInstance();
                                                assertNotEquals("New zero instance should not have negative sign", 
                                                               -1, signField.getInt(newZeroInstance));
                                            }

    @Test
                                            public void testNewInstanceZeroSignHandling() throws Exception {
                                                // Create a Dfp field to use for testing
                                                DfpField field = new DfpField(20); // Assuming 20 radix digits
                                                
                                                // Get zero instance to use for creating new instances
                                                Dfp zero = field.getZero();
                                                
                                                // Test positive zero
                                                Dfp resultPositive = zero.newInstance(0.0);
                                                
                                                // Use reflection to access protected sign field
                                                Field signField = Dfp.class.getDeclaredField("sign");
                                                signField.setAccessible(true);
                                                byte positiveSign = (byte) signField.get(resultPositive);
                                                
                                                assertEquals("Positive zero should have sign 1", (byte)1, positiveSign);
                                                assertTrue("Positive zero should equal 0.0", resultPositive.equals(zero.newInstance(0.0)));
                                                
                                                // Test negative zero
                                                Dfp resultNegative = zero.newInstance(-0.0);
                                                
                                                byte negativeSign = (byte) signField.get(resultNegative);
                                                
                                                assertEquals("Negative zero should have sign -1", (byte)-1, negativeSign);
                                                assertTrue("Negative zero should equal -0.0", resultNegative.equals(zero.newInstance(-0.0)));
                                            }

    @Test
                                            public void testNewInstanceStringZeroSign() throws Exception {
                                                // Setup
                                                DfpField field = new DfpField(100); // Assuming 100 digits precision
                                                Dfp dfp = field.getZero(); // Get zero instance from the field
                                                
                                                // Get the sign field for reflection access
                                                Field signField = Dfp.class.getDeclaredField("sign");
                                                signField.setAccessible(true);
                                                
                                                // Test positive zero
                                                Dfp positiveZero = dfp.newInstance("0");
                                                assertEquals("Positive zero should have sign 1", 1, signField.getInt(positiveZero));
                                                
                                                // Test negative zero
                                                Dfp negativeZero = dfp.newInstance("-0");
                                                assertEquals("Negative zero should have sign -1", -1, signField.getInt(negativeZero));
                                                
                                                // Additional check for explicit positive sign
                                                Dfp explicitPositiveZero = dfp.newInstance("+0");
                                                assertEquals("Explicit positive zero should have sign 1", 1, signField.getInt(explicitPositiveZero));
                                            }

    @Test
                                        public void testNewInstancePreservesPositiveZeroSign() {
                                            // Setup
                                            DfpField mockField = mock(DfpField.class);
                                            // Use the protected constructor with double parameter through reflection
                                            Constructor<Dfp> constructor;
                                            Dfp dfp = null;
                                            try {
                                                constructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
                                                constructor.setAccessible(true);
                                                dfp = constructor.newInstance(mockField, 0.0);
                                                
                                                // Set sign field using reflection since it's protected
                                                Field signField = Dfp.class.getDeclaredField("sign");
                                                signField.setAccessible(true);
                                                signField.setInt(dfp, 1);  // Set positive sign
                                                
                                                // Test
                                                Dfp result = dfp.newInstance(0.0);
                                                
                                                // Verify - original would have +0.0, mutant will have -0.0
                                                assertTrue("Result should be positive zero", 
                                                           Double.doubleToRawLongBits(result.toDouble()) >= 0);
                                                
                                                // Additional check to ensure it's really zero
                                                assertEquals(0.0, result.toDouble(), 0.0);
                                            } catch (Exception e) {
                                                fail("Operation failed: " + e.getMessage());
                                            }
                                        }

    @Test
                                    public void testNewInstancePreservesZeroSign() throws Exception {
                                        // Create a mock DfpField
                                        DfpField mockField = mock(DfpField.class);
                                        
                                        // Create test Dfp instance with mock field using accessible constructor
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, String.class);
                                        constructor.setAccessible(true);
                                        Dfp dfp = constructor.newInstance(mockField, "0.0");
                                        
                                        // Get the sign field for reflection access
                                        Field signField = Dfp.class.getDeclaredField("sign");
                                        signField.setAccessible(true);
                                        
                                        // Test case 1: Positive zero should result in +0.0
                                        Dfp resultPosZero = dfp.newInstance(+0.0);
                                        assertEquals("Positive zero should result in +0.0", 1, signField.getInt(resultPosZero));
                                        
                                        // Test case 2: Negative zero should result in -0.0
                                        Dfp resultNegZero = dfp.newInstance(-0.0);
                                        assertEquals("Negative zero should result in -0.0", -1, signField.getInt(resultNegZero));
                                        
                                        // Test case 3: Regular positive number that rounds to zero
                                        Dfp resultSmallPos = dfp.newInstance(Double.MIN_VALUE / 2);
                                        assertEquals("Small positive should result in +0.0", 1, signField.getInt(resultSmallPos));
                                    }

    @Test
                                    public void testNewInstancePreservesZeroSign1() throws Exception {
                                        // Create a mock DfpField
                                        DfpField mockField = mock(DfpField.class);
                                        
                                        // Create test Dfp instance with mock field using protected constructor
                                        // Need to use reflection to access protected constructor
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
                                        constructor.setAccessible(true);
                                        Dfp dfp = constructor.newInstance(mockField, 0.0);
                                        
                                        // Get the sign field for reflection access
                                        Field signField = Dfp.class.getDeclaredField("sign");
                                        signField.setAccessible(true);
                                        
                                        // Test case 1: Positive zero should result in +0.0
                                        Dfp resultPosZero = dfp.newInstance(+0.0);
                                        assertEquals("Positive zero should result in +0.0", 1, signField.getInt(resultPosZero));
                                        
                                        // Test case 2: Negative zero should result in -0.0
                                        Dfp resultNegZero = dfp.newInstance(-0.0);
                                        assertEquals("Negative zero should result in -0.0", -1, signField.getInt(resultNegZero));
                                        
                                        // Test case 3: Regular positive number that rounds to zero
                                        Dfp resultSmallPos = dfp.newInstance(Double.MIN_VALUE / 2);
                                        assertEquals("Small positive should result in +0.0", 1, signField.getInt(resultSmallPos));
                                    }

    @Test
                            public void testNewInstanceCreatesNewObject() throws Exception {
                                // Create a mock field
                                DfpField mockField = mock(DfpField.class);
                                when(mockField.getRadixDigits()).thenReturn(10); // Assuming default radix digits
                                
                                // Create a test Dfp object with non-default values using reflection
                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                constructor.setAccessible(true);
                                Dfp original = constructor.newInstance(mockField, (byte)-1, Dfp.INFINITE);
                                
                                // Set exponent using reflection
                                Field expField = Dfp.class.getDeclaredField("exp");
                                expField.setAccessible(true);
                                expField.set(original, 5);
                                
                                // Call the method under test
                                Dfp result = original.newInstance();
                                
                                // Verify it's a new instance (not same reference)
                                assertNotSame("newInstance should return a new object", original, result);
                                
                                // Verify it has default values using getters/reflection
                                Field signField = Dfp.class.getDeclaredField("sign");
                                signField.setAccessible(true);
                                assertEquals("Sign should be default", 1, signField.get(result));
                                
                                Field resultExpField = Dfp.class.getDeclaredField("exp");
                                resultExpField.setAccessible(true);
                                assertEquals("Exp should be default", 0, resultExpField.get(result));
                                
                                Field nansField = Dfp.class.getDeclaredField("nans");
                                nansField.setAccessible(true);
                                assertEquals("Nans should be default", Dfp.FINITE, nansField.get(result));
                                
                                // Verify the field is the same
                                assertSame("Field should be the same", mockField, result.getField());
                            }

    @Test
                            public void testNewInstancePreservesOriginalValues() throws Exception {
                                // Create a test DfpField (we'll mock it since we don't have its implementation)
                                DfpField field = mock(DfpField.class);
                                when(field.getRadixDigits()).thenReturn(4); // Need to mock this for mantissa array
                                
                                // Create a non-zero Dfp object with known values using reflection
                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                constructor.setAccessible(true);
                                Dfp original = constructor.newInstance(field, 123);
                                
                                // Set some explicit values to ensure they're not zero using reflection
                                Field signField = Dfp.class.getDeclaredField("sign");
                                signField.setAccessible(true);
                                signField.set(original, 1);
                                
                                Field expField = Dfp.class.getDeclaredField("exp");
                                expField.setAccessible(true);
                                expField.set(original, 2);
                                
                                Field mantField = Dfp.class.getDeclaredField("mant");
                                mantField.setAccessible(true);
                                mantField.set(original, new int[]{1, 2, 3}); // Sample mantissa values
                                
                                // Call the method under test
                                Dfp result = original.newInstance();
                                
                                // Verify the new instance has same values as original using reflection
                                assertEquals("Sign should be preserved", signField.get(original), signField.get(result));
                                assertEquals("Exponent should be preserved", expField.get(original), expField.get(result));
                                assertArrayEquals("Mantissa should be preserved", (int[])mantField.get(original), (int[])mantField.get(result));
                                assertSame("Field should be the same", original.getField(), result.getField());
                            }

    @Test
                            public void testNewInstanceStringPreservesValue() {
                                // Setup
                                DfpField field = new DfpField(10); // Assuming DfpField constructor takes radix digits
                                String testValue = "123.456";
                                
                                // Create original Dfp instance
                                Dfp original = field.newDfp(testValue);
                                
                                // Test newInstance
                                Dfp newInstance = original.newInstance(testValue);
                                
                                // Verify the new instance has the same value as if created directly
                                Dfp expected = field.newDfp(testValue);
                                
                                // Use reflection to access protected fields
                                try {
                                    Field signField = Dfp.class.getDeclaredField("sign");
                                    signField.setAccessible(true);
                                    Field expField = Dfp.class.getDeclaredField("exp");
                                    expField.setAccessible(true);
                                    Field mantField = Dfp.class.getDeclaredField("mant");
                                    mantField.setAccessible(true);
                                    Field nansField = Dfp.class.getDeclaredField("nans");
                                    nansField.setAccessible(true);
                                    
                                    // These assertions would fail if the mutation is present
                                    assertEquals("Sign should match", signField.get(expected), signField.get(newInstance));
                                    assertEquals("Exponent should match", expField.get(expected), expField.get(newInstance));
                                    assertArrayEquals("Mantissa should match", (int[])mantField.get(expected), (int[])mantField.get(newInstance));
                                    assertEquals("NaN status should match", nansField.get(expected), nansField.get(newInstance));
                                } catch (Exception e) {
                                    fail("Reflection failed: " + e.getMessage());
                                }
                            }

    @Test
                            public void testNewInstanceWithSigAndCodePreservesOriginalState() throws Exception {
                                // Create a test DfpField
                                DfpField field = new DfpField(10);
                                
                                // Create a non-zero Dfp instance using the protected constructor via reflection
                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                constructor.setAccessible(true);
                                Dfp original = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                
                                // Set non-default values using reflection
                                Field expField = Dfp.class.getDeclaredField("exp");
                                expField.setAccessible(true);
                                expField.set(original, 5);
                                
                                Field signField = Dfp.class.getDeclaredField("sign");
                                signField.setAccessible(true);
                                signField.set(original, -1);
                                
                                Field mantField = Dfp.class.getDeclaredField("mant");
                                mantField.setAccessible(true);
                                int[] mant = (int[]) mantField.get(original);
                                mant[0] = 1234;
                                
                                // Create new instance using the method
                                byte testSig = 1;
                                byte testCode = Dfp.FINITE;
                                Dfp newInstance = original.newInstance(testSig, testCode);
                                
                                // Verify the new instance maintains properties from original using reflection
                                assertEquals("Sign should be preserved from original", 
                                        signField.get(original), signField.get(newInstance));
                                assertEquals("Exponent should be preserved from original", 
                                        expField.get(original), expField.get(newInstance));
                                
                                int[] originalMant = (int[]) mantField.get(original);
                                int[] newMant = (int[]) mantField.get(newInstance);
                                assertArrayEquals("Mantissa should be preserved from original", originalMant, newMant);
                                
                                Field fieldField = Dfp.class.getDeclaredField("field");
                                fieldField.setAccessible(true);
                                assertEquals("Field should be the same", 
                                        fieldField.get(original), fieldField.get(newInstance));
                                
                                // Verify the sig and code were properly set
                                assertEquals("Signature should match input", testSig, signField.get(newInstance));
                                
                                Field nansField = Dfp.class.getDeclaredField("nans");
                                nansField.setAccessible(true);
                                assertEquals("Code should match input", testCode, nansField.get(newInstance));
                            }

    @Test
                        public void testNewInstancePreservesOriginalValues1() throws Exception {
                            // Create a DfpField - since it's final we need to create it properly
                            DfpField field = new DfpField(10); // Using arbitrary radix digits
                            
                            // Use reflection to access protected constructor
                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                            constructor.setAccessible(true);
                            Dfp original = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                            
                            // Use reflection to set protected fields
                            Field expField = Dfp.class.getDeclaredField("exp");
                            expField.setAccessible(true);
                            expField.set(original, 5);
                            
                            Field mantField = Dfp.class.getDeclaredField("mant");
                            mantField.setAccessible(true);
                            mantField.set(original, new int[]{1, 2, 3});
                            
                            // Call newInstance
                            Dfp copy = original.newInstance();
                            
                            // Use reflection to verify all fields are copied correctly
                            Field signField = Dfp.class.getDeclaredField("sign");
                            signField.setAccessible(true);
                            assertEquals("Sign should be preserved", signField.get(original), signField.get(copy));
                            
                            assertEquals("Exp should be preserved", expField.get(original), expField.get(copy));
                            
                            Field nansField = Dfp.class.getDeclaredField("nans");
                            nansField.setAccessible(true);
                            assertEquals("Nans should be preserved", nansField.get(original), nansField.get(copy));
                            
                            assertArrayEquals("Mantissa should be preserved", 
                                            (int[])mantField.get(original), 
                                            (int[])mantField.get(copy));
                            
                            // Also verify it's a different object (not same reference)
                            assertNotSame("Should return a new instance", original, copy);
                        }

    @Test
                    public void testNewInstancePreservesValue() {
                        // Create a test DfpField
                        DfpField field = mock(DfpField.class);
                        
                        // Create a non-zero Dfp object (value = 5) using String constructor which is protected
                        // We'll use reflection to access the protected constructor
                        Dfp original;
                        try {
                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, String.class);
                            constructor.setAccessible(true);
                            original = constructor.newInstance(field, "5");
                        } catch (Exception e) {
                            fail("Failed to create Dfp instance: " + e.getMessage());
                            return;
                        }
                        
                        // Create expected zero instance for comparison using String constructor
                        Dfp zero;
                        try {
                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, String.class);
                            constructor.setAccessible(true);
                            zero = constructor.newInstance(field, "0");
                        } catch (Exception e) {
                            fail("Failed to create zero Dfp instance: " + e.getMessage());
                            return;
                        }
                        when(field.getZero()).thenReturn(zero);
                        
                        // Call newInstance()
                        Dfp result = original.newInstance();
                        
                        // Verify the result is not zero (would fail with mutant)
                        assertNotEquals("New instance should not be zero", zero, result);
                        
                        // Verify the field is the same
                        assertEquals("Fields should match", original.getField(), result.getField());
                        
                        // Additional check - verify mantissa isn't all zeros
                        boolean allZeros = true;
                        try {
                            Field mantField = Dfp.class.getDeclaredField("mant");
                            mantField.setAccessible(true);
                            int[] mant = (int[]) mantField.get(result);
                            for (int m : mant) {
                                if (m != 0) {
                                    allZeros = false;
                                    break;
                                }
                            }
                        } catch (Exception e) {
                            fail("Failed to access mantissa field: " + e.getMessage());
                        }
                        assertFalse("Mantissa should not be all zeros", allZeros);
                    }

    @Test
                    public void testNewInstanceDfpPreservesValue() {
                        // Setup test objects
                        DfpField field = new DfpField(10); // Assuming DfpField constructor takes radix digits
                        Dfp original = field.newDfp().newInstance("12345"); // Create a non-zero Dfp using newInstance
                        
                        // Call method under test
                        Dfp result = original.newInstance(original);
                        
                        // Use reflection to access protected fields
                        try {
                            Field mantField = Dfp.class.getDeclaredField("mant");
                            mantField.setAccessible(true);
                            int[] originalMant = (int[]) mantField.get(original);
                            int[] resultMant = (int[]) mantField.get(result);
                            assertArrayEquals("Mantissa should be copied", originalMant, resultMant);
                    
                            Field signField = Dfp.class.getDeclaredField("sign");
                            signField.setAccessible(true);
                            assertEquals("Sign should be copied", signField.get(original), signField.get(result));
                    
                            Field expField = Dfp.class.getDeclaredField("exp");
                            expField.setAccessible(true);
                            assertEquals("Exponent should be copied", expField.get(original), expField.get(result));
                    
                            Field nansField = Dfp.class.getDeclaredField("nans");
                            nansField.setAccessible(true);
                            assertEquals("NaN status should be copied", nansField.get(original), nansField.get(result));
                        } catch (Exception e) {
                            fail("Reflection failed: " + e.getMessage());
                        }
                        
                        // Additional check for the actual value
                        assertFalse("Result should not be zero", result.equals(original.getZero()));
                    }

    @Test
            public void testNewInstanceReturnsCopyOfCurrentObject() {
                // Setup
                DfpField field = new DfpField(10); // Assuming DfpField needs radix digits
                Dfp zero = field.getZero(); // Get zero instance through field
                zero = zero.newInstance(0); // Set value to 0 using newInstance
                Dfp original = new Dfp(zero); // Create copy using public constructor
                Dfp valueToAdd = field.newDfp(123); // Create Dfp with value 123 using field's method
                original = original.add(valueToAdd.newInstance(123)); // Set value to 123 using add method
                
                // Mock getZero() to return our zero instance
                when(original.getZero()).thenReturn(zero);
                
                // Test
                Dfp result = original.newInstance();
                
                // Verify
                // Should equal original (test fails with mutant since it would return zero)
                assertEquals(original, result);
                
                // Should not be zero (additional check)
                assertNotEquals(zero, result);
                
                // Verify the objects have same field (additional check)
                assertSame(original.getField(), result.getField());
            }

    @Test
    public void testNewInstanceNegationBehavior() {
        // Create a mock field
        DfpField mockField = mock(DfpField.class);
        when(mockField.getRadixDigits()).thenReturn(4); // arbitrary number
        
        // Create original Dfp instance with positive sign
        Dfp original = new Dfp(mockField, 1); // use constructor that takes int to set value
        
        // Use reflection to access protected sign field
        try {
            Field signField = Dfp.class.getDeclaredField("sign");
            signField.setAccessible(true);
            int originalSign = (int) signField.get(original);
            
            // Create first instance - should have same sign as original
            Dfp instance1 = original.newInstance();
            int instance1Sign = (int) signField.get(instance1);
            assertEquals("First instance should have same sign as original", 
                        originalSign, instance1Sign);
            
            // Create second instance - should STILL have same sign as original
            Dfp instance2 = original.newInstance();
            int instance2Sign = (int) signField.get(instance2);
            assertEquals("Second instance should maintain same sign as original", 
                        originalSign, instance2Sign);
            
            // Verify the field is properly passed to new instances
            assertSame("New instance should have same field", 
                     original.getField(), instance1.getField());
            assertSame("New instance should have same field", 
                     original.getField(), instance2.getField());
        } catch (Exception e) {
            fail("Reflection failed: " + e.getMessage());
        }
    }

    @Test
    public void testNewInstanceSignHandling2() throws Exception {
        // Create a field and initial Dfp object
        DfpField field = new DfpField(20); // assuming 20 radix digits
        Dfp original = field.newDfp(5.0); // positive number
        
        // Helper method to get sign field via reflection
        java.lang.reflect.Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        
        // Test normal new instance creation
        Dfp newPos = original.newInstance(10.0);
        assertEquals(1, signField.get(newPos)); // should remain positive
        
        // Test negation behavior
        Dfp negated = newPos.negate();
        assertEquals(-1, signField.get(negated)); // should be negative
        
        // Test creating new instance after negation
        Dfp newAfterNegate = negated.newInstance(7.0);
        assertEquals(1, signField.get(newAfterNegate)); // should be positive (new value)
        
        // Test creating negative instance
        Dfp newNeg = original.newInstance(-3.0);
        assertEquals(-1, signField.get(newNeg)); // should be negative
        
        // Test creating new instance after multiple operations
        Dfp temp = original.newInstance(2.0);
        temp = temp.negate(); // -2
        temp = temp.newInstance(4.0); // 4
        temp = temp.negate(); // -4
        assertEquals(-1, signField.get(temp)); // should be negative
        
        // Test with zero
        Dfp zero = original.newInstance(0.0);
        assertEquals(1, signField.get(zero)); // zero should be positive
        Dfp negZero = zero.negate();
        assertEquals(-1, signField.get(negZero)); // negated zero should be negative
    }

    @Test
    public void testNewInstanceSignConsistency() throws Exception {
        // Setup test environment
        DfpField field = new DfpField(10); // Assuming DfpField has a public constructor with precision
        Dfp original = field.newDfp(10); // positive value
        
        // Helper method to get sign via reflection
        java.lang.reflect.Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        
        // Test newInstance maintains correct sign
        Dfp instance1 = original.newInstance(5); // should be positive
        assertEquals("First instance should be positive", 1, signField.getInt(instance1));
        
        Dfp instance2 = original.newInstance(-3); // should be negative
        assertEquals("Negative value instance should be negative", -1, signField.getInt(instance2));
        
        Dfp instance3 = original.newInstance(0); // should be positive
        assertEquals("Zero instance should be positive", 1, signField.getInt(instance3));
        
        // Test multiple consecutive calls with same value
        Dfp instance4 = original.newInstance(7);
        Dfp instance5 = original.newInstance(7);
        assertEquals("Consecutive instances with same value should have same sign", 
                     signField.getInt(instance4), signField.getInt(instance5));
        
        // Test with original negative value
        Dfp negativeOriginal = field.newDfp(-10);
        Dfp instance6 = negativeOriginal.newInstance(2);
        assertEquals("Instance from negative original should be positive", 1, signField.getInt(instance6));
    }

    @Test
    public void testNegationBehavior() throws Exception {
        // Create a test field
        DfpField field = new DfpField(20); // Assuming DfpField constructor takes radix digits
        
        // Create positive and negative test values
        Dfp positiveValue = field.newDfp(10); // value = 10
        Dfp negativeValue = field.newDfp(-10); // value = -10
        
        // Test original newInstance behavior with positive value
        Dfp newPositive = positiveValue.newInstance(5);
        assertEquals("New instance from positive should have correct value", 5, newPositive.intValue());
        
        // Get sign field using reflection since it's protected
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        int newPositiveSign = signField.getInt(newPositive);
        assertEquals("New instance from positive should be positive", 1, newPositiveSign);
        
        // Test original newInstance behavior with negative value
        Dfp newNegative = negativeValue.newInstance(5);
        assertEquals("New instance from negative should have correct value", 5, newNegative.intValue());
        int newNegativeSign = signField.getInt(newNegative);
        assertEquals("New instance from negative should be positive", 1, newNegativeSign);
        
        // Test negation operations
        Dfp negatedPositive = positiveValue.negate();
        int negatedPositiveSign = signField.getInt(negatedPositive);
        assertEquals("Negated positive should be negative", -1, negatedPositiveSign);
        
        Dfp negatedNegative = negativeValue.negate();
        int negatedNegativeSign = signField.getInt(negatedNegative);
        assertEquals("Negated negative should be positive", 1, negatedNegativeSign);
        
        // Test chain of operations that might trigger the negate mutation
        Dfp result = positiveValue.newInstance(10)
                                .add(negativeValue.newInstance(5))
                                .negate()
                                .multiply(positiveValue.newInstance(2));
        assertEquals("Chain of operations should have correct value", -10, result.intValue());
        int resultSign = signField.getInt(result);
        assertEquals("Chain of operations should have correct sign", -1, resultSign);
    }

    @Test
    public void testNewInstanceSignHandling3() throws Exception {
        // Setup test environment
        DfpField field = new DfpField(10); // Assuming DfpField needs digits parameter
        Dfp original = new Dfp(field, 10L); // positive value
        
        // Helper method to get sign field via reflection
        java.lang.reflect.Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        
        // Test positive value remains positive
        Dfp positiveInstance = original.newInstance(5L);
        assertEquals("Positive value should remain positive", 1, signField.getInt(positiveInstance));
        
        // Test negative value becomes negative
        Dfp negativeInstance = original.newInstance(-5L);
        assertEquals("Negative value should be negative", -1, signField.getInt(negativeInstance));
        
        // Test zero value remains zero (with positive sign)
        Dfp zeroInstance = original.newInstance(0L);
        assertEquals("Zero should have positive sign", 1, signField.getInt(zeroInstance));
        
        // Test sign consistency with large negative value
        Dfp largeNegative = original.newInstance(Long.MIN_VALUE + 1);
        assertEquals("Large negative should be negative", -1, signField.getInt(largeNegative));
        
        // Test sign consistency with large positive value
        Dfp largePositive = original.newInstance(Long.MAX_VALUE);
        assertEquals("Large positive should be positive", 1, signField.getInt(largePositive));
    }

    @Test
    public void testNewInstanceWithDifferentRadixDigits() throws Exception {
        // Create two DfpFields with different radix digits
        DfpField field1 = mock(DfpField.class);
        when(field1.getRadixDigits()).thenReturn(10);
        when(field1.getZero()).thenReturn(new Dfp(field1));
        when(field1.getFLAG_INVALID()).thenReturn(1); // Assuming FLAG_INVALID is 1
        
        DfpField field2 = mock(DfpField.class);
        when(field2.getRadixDigits()).thenReturn(15);
        when(field2.getZero()).thenReturn(new Dfp(field2));
        
        // Create source Dfp with field1
        Dfp source = new Dfp(field1);
        
        // Create target Dfp with field2 (different radix digits)
        Dfp target = new Dfp(field2);
        
        // Test the newInstance method
        Dfp result = source.newInstance(target);
        
        // Use reflection to access protected fields
        Class<?> dfpClass = Dfp.class;
        Field nansField = dfpClass.getDeclaredField("nans");
        Field signField = dfpClass.getDeclaredField("sign");
        nansField.setAccessible(true);
        signField.setAccessible(true);
        
        // Verify the results
        assertEquals(Dfp.QNAN, nansField.get(result)); // Should be QNAN
        assertEquals(1, signField.get(result)); // Default sign should be 1 (not affected by the mutant)
        
        // Verify the invalid flag was set
        verify(field1).setIEEEFlagsBits(1);
        
        // Additional test to catch the negate mutation
        Dfp negated = result.negate();
        // The mutant would toggle negation each time, so we verify consistent behavior
        assertEquals(-1, signField.get(negated)); // Should be -1 regardless of mutation
        assertEquals(Dfp.QNAN, nansField.get(negated)); // Should remain QNAN
    }

    @Test
    public void testNewInstanceStringNegativeNumber() {
        // Setup
        DfpField field = new DfpField(100); // Assuming DfpField constructor takes radix digits
        String negativeNumber = "-123.456";
        
        // Test
        Dfp result = field.newInstance(negativeNumber);
        
        // Verify
        try {
            Field signField = Dfp.class.getDeclaredField("sign");
            signField.setAccessible(true);
            int signValue = signField.getInt(result);
            assertEquals("Negative number should have sign -1", -1, signValue);
        } catch (Exception e) {
            fail("Failed to access sign field: " + e.getMessage());
        }
        assertFalse("Negative number should be finite", result.isInfinite());
        assertFalse("Negative number should not be NaN", result.isNaN());
    }

    @Test
    public void testNewInstanceStringWithMultipleMinusSigns() throws Exception {
        // Setup
        DfpField field = new DfpField(100);
        String weirdNegative = "--123.456"; // Should be invalid but might get through
        
        // Test
        Dfp result = field.newInstance(weirdNegative);
        
        // Verify
        // Use reflection to access protected 'sign' field
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        int signValue = signField.getInt(result);
        
        // Original behavior would make this negative (first minus sets negate=true)
        // Mutated behavior might make this positive (first minus toggles negate, second toggles back)
        assertEquals("Multiple minus signs should result in positive number", 1, signValue);
    }

    @Test
    public void testNewInstanceStringSpecialNegativeCases() {
        // Setup
        DfpField field = new DfpField(100);
        String negativeInfinity = "-Infinity"; // Replaced private constant with direct string
        String negativeZero = "-0";
        
        // Test negative infinity
        Dfp infResult = field.newInstance(negativeInfinity); // Using newInstance instead of direct constructor
        try {
            Field signField = Dfp.class.getDeclaredField("sign");
            signField.setAccessible(true);
            int signValue = signField.getInt(infResult);
            assertEquals("Negative infinity should have sign -1", -1, signValue);
        } catch (Exception e) {
            fail("Failed to access sign field");
        }
        assertTrue("Should be infinite", infResult.isInfinite());
        
        // Test negative zero
        Dfp zeroResult = field.newInstance(negativeZero); // Using newInstance instead of direct constructor
        try {
            Field signField = Dfp.class.getDeclaredField("sign");
            signField.setAccessible(true);
            int signValue = signField.getInt(zeroResult);
            assertEquals("Negative zero should have sign -1", -1, signValue);
        } catch (Exception e) {
            fail("Failed to access sign field");
        }
        assertTrue("Should be zero", zeroResult.equals(field.getZero().negate()));
    }

    @Test
    public void testNewInstanceWithSignAndCode() throws Exception {
        // Create a mock DfpField
        DfpField field = mock(DfpField.class);
        
        // Create the test Dfp instance using reflection to access protected constructor
        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
        constructor.setAccessible(true);
        Dfp dfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
        
        // Mock the newDfp method to return a known Dfp with specific sign
        Dfp expectedDfp = constructor.newInstance(field, (byte)0, (byte)0);
        
        // Set sign field using reflection
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.set(expectedDfp, (byte)1);  // Positive sign
        
        when(field.newDfp(anyByte(), anyByte())).thenReturn(expectedDfp);
        
        // Test with positive sign
        Dfp result = dfp.newInstance((byte)1, Dfp.FINITE);
        assertEquals("Sign should be positive", 1, signField.get(result));
        
        // Test with negative sign to catch the mutation
        signField.set(expectedDfp, (byte)-1);  // Negative sign
        when(field.newDfp(anyByte(), anyByte())).thenReturn(expectedDfp);
        
        result = dfp.newInstance((byte)-1, Dfp.FINITE);
        assertEquals("Sign should be negative", -1, signField.get(result));
        
        // Verify the interaction with the mock
        verify(field, times(2)).newDfp(anyByte(), anyByte());
    }


}
