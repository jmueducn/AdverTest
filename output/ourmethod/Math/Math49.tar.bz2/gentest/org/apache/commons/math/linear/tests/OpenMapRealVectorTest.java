package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathArithmeticException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.OpenIntToDoubleHashMap;
import org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator;
import org.apache.commons.math.util.FastMath;
 
public class OpenMapRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testEbeDivide_TypicalCase() {
                                                    // Setup
                                                    double[] data1 = {4.0, 9.0, 16.0};
                                                    double[] data2 = {2.0, 3.0, 4.0};
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                    
                                                    // Verify
                                                    assertEquals(2.0, result.getEntry(0), 0.0001);
                                                    assertEquals(3.0, result.getEntry(1), 0.0001);
                                                    assertEquals(4.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeDivide_WithZeroValues() {
                                                    // Setup
                                                    double[] data1 = {0.0, 5.0, 0.0};
                                                    double[] data2 = {1.0, 2.5, 3.0};
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                    
                                                    // Verify
                                                    assertEquals(0.0, result.getEntry(0), 0.0001);
                                                    assertEquals(2.0, result.getEntry(1), 0.0001);
                                                    assertEquals(0.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeDivide_DivideByZeroShouldReturnInfinity() {
                                                    // Setup
                                                    double[] data1 = {1.0, 2.0, 3.0};
                                                    double[] data2 = {1.0, 0.0, 3.0};
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                    
                                                    // Verify
                                                    assertEquals(1.0, result.getEntry(0), 0.0001);
                                                    assertTrue(Double.isInfinite(result.getEntry(1)));
                                                    assertEquals(1.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeDivide_WithSparseVectors() {
                                                    // Setup - using constructor that allows specifying expected size
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(3, 1); // Only 1 non-zero expected
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(3, 1);
                                                    vector1.setEntry(1, 10.0); // Only set one entry
                                                    vector2.setEntry(1, 2.0);  // Only set corresponding entry
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                    
                                                    // Verify
                                                    assertEquals(0.0, result.getEntry(0), 0.0001); // Default value
                                                    assertEquals(5.0, result.getEntry(1), 0.0001); // 10/2
                                                    assertEquals(0.0, result.getEntry(2), 0.0001); // Default value
                                                }

    @Test
                                                public void testEbeDivide_WithRealVectorParameter() {
                                                    // Setup
                                                    double[] data1 = {6.0, 8.0, 10.0};
                                                    double[] data2 = {2.0, 4.0, 5.0};
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                                    RealVector vector2 = mock(RealVector.class);
                                                    
                                                    // Mock behavior
                                                    when(vector2.getDimension()).thenReturn(3);
                                                    when(vector2.getEntry(0)).thenReturn(2.0);
                                                    when(vector2.getEntry(1)).thenReturn(4.0);
                                                    when(vector2.getEntry(2)).thenReturn(5.0);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                    
                                                    // Verify
                                                    assertEquals(3.0, result.getEntry(0), 0.0001);
                                                    assertEquals(2.0, result.getEntry(1), 0.0001);
                                                    assertEquals(2.0, result.getEntry(2), 0.0001);
                                                    
                                                    // Verify interactions
                                                    verify(vector2).getDimension();
                                                    verify(vector2, times(3)).getEntry(anyInt());
                                                }

    @Test
                                                public void testEbeDivide_WithNegativeValues() {
                                                    // Setup
                                                    double[] data1 = {-4.0, 9.0, -16.0};
                                                    double[] data2 = {2.0, -3.0, 4.0};
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                    
                                                    // Verify
                                                    assertEquals(-2.0, result.getEntry(0), 0.0001);
                                                    assertEquals(-3.0, result.getEntry(1), 0.0001);
                                                    assertEquals(-4.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeDivide_TypicalCase1() {
                                                    // Setup
                                                    double[] values = {4.0, 9.0, 16.0};
                                                    double[] divisors = {2.0, 3.0, 4.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector.ebeDivide(divisors);
                                                    
                                                    // Verify
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(2.0, result.getEntry(0), 0.0001);
                                                    assertEquals(3.0, result.getEntry(1), 0.0001);
                                                    assertEquals(4.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeDivide_WithZeroValues1() {
                                                    // Setup
                                                    double[] values = {0.0, 5.0, 0.0};
                                                    double[] divisors = {1.0, 5.0, 10.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector.ebeDivide(divisors);
                                                    
                                                    // Verify
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(0.0, result.getEntry(0), 0.0001);
                                                    assertEquals(1.0, result.getEntry(1), 0.0001);
                                                    assertEquals(0.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeDivide_WithSparseVector() {
                                                    // Setup
                                                    OpenMapRealVector vector = new OpenMapRealVector(3);
                                                    vector.setEntry(1, 10.0); // Only set middle value
                                                    double[] divisors = {1.0, 2.0, 1.0};
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector.ebeDivide(divisors);
                                                    
                                                    // Verify
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(0.0, result.getEntry(0), 0.0001); // Default value
                                                    assertEquals(5.0, result.getEntry(1), 0.0001); // Only non-default
                                                    assertEquals(0.0, result.getEntry(2), 0.0001); // Default value
                                                }

    @Test
                                                public void testEbeDivide_WithNegativeValues1() {
                                                    // Setup
                                                    double[] values = {-4.0, 9.0, -16.0};
                                                    double[] divisors = {-2.0, 3.0, -4.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector.ebeDivide(divisors);
                                                    
                                                    // Verify
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(2.0, result.getEntry(0), 0.0001);
                                                    assertEquals(3.0, result.getEntry(1), 0.0001);
                                                    assertEquals(4.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeDivide_WithEmptyVector() {
                                                    // Setup
                                                    double[] values = {};
                                                    double[] divisors = {};
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector.ebeDivide(divisors);
                                                    
                                                    // Verify
                                                    assertEquals(0, result.getDimension());
                                                }

    @Test
                                                public void testEbeDivide_VerifyOriginalVectorNotModified() {
                                                    // Setup
                                                    double[] values = {1.0, 2.0, 3.0};
                                                    double[] divisors = {1.0, 1.0, 1.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector.ebeDivide(divisors);
                                                    
                                                    // Verify original unchanged
                                                    assertEquals(1.0, vector.getEntry(0), 0.0001);
                                                    assertEquals(2.0, vector.getEntry(1), 0.0001);
                                                    assertEquals(3.0, vector.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeMultiply_WithEmptyVector() {
                                                    // Setup empty vector
                                                    OpenMapRealVector emptyVector = new OpenMapRealVector(0);
                                                    double[] input = {};
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = emptyVector.ebeMultiply(input);
                                                    
                                                    // Verify
                                                    assertNotNull(result);
                                                    assertEquals(0, result.getDimension());
                                                }

    @Test(expected = ArithmeticException.class)
                                        public void testEbeDivide_WithDivisionByZero() {
                                            // Setup
                                            double[] values = {1.0, 2.0, 3.0};
                                            double[] divisors = {1.0, 0.0, 3.0};
                                            OpenMapRealVector vector = new OpenMapRealVector(values);
                                            
                                            // Execute - should throw ArithmeticException
                                            vector.ebeDivide(divisors);
                                        }

    @Test
                                        public void testEbeDivide_WithDifferentDimensions() {
                                            // Setup
                                            double[] values = {1.0, 2.0, 3.0};
                                            double[] divisors = {1.0, 2.0}; // Shorter array
                                            OpenMapRealVector vector = new OpenMapRealVector(values);
                                            
                                            // Expect exception
                                            ExpectedException exception = ExpectedException.none();
                                            exception.expect(IllegalArgumentException.class);
                                            exception.expectMessage("vector length mismatch");
                                            
                                            // Execute
                                            vector.ebeDivide(divisors);
                                        }

    @Test
                                        public void testEbeDivide_WithNullInput() {
                                            // Setup
                                            OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0, 2.0});
                                            
                                            // Expect exception
                                            try {
                                                // Execute
                                                vector.ebeDivide((RealVector) null);
                                                fail("Expected NullPointerException");
                                            } catch (NullPointerException e) {
                                                // Expected exception
                                            }
                                        }

    @Test
                                        public void testEbeMultiply_TypicalCase() {
                                            OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0, 2.0, 0.0, 4.0});
                                            OpenMapRealVector other = new OpenMapRealVector(new double[]{2.0, 3.0, 5.0, 0.5});
                                            OpenMapRealVector result = vector.ebeMultiply(other);
                                            
                                            assertEquals(4, result.getDimension());
                                            assertEquals(2.0, result.getEntry(0), 0.0001);  // 1.0 * 2.0
                                            assertEquals(6.0, result.getEntry(1), 0.0001);  // 2.0 * 3.0
                                            assertEquals(0.0, result.getEntry(2), 0.0001);  // 0.0 * 5.0
                                            assertEquals(2.0, result.getEntry(3), 0.0001);  // 4.0 * 0.5
                                        }

    @Test
                                        public void testEbeMultiply_WithZeroVector() {
                                            OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0, 4.0});
                                            OpenMapRealVector zeroVector = new OpenMapRealVector(new double[]{0.0, 0.0, 0.0, 0.0});
                                            OpenMapRealVector result = vector.ebeMultiply(zeroVector);
                                            
                                            assertEquals(4, result.getDimension());
                                            assertEquals(0.0, result.getEntry(0), 0.0001);
                                            assertEquals(0.0, result.getEntry(1), 0.0001);
                                            assertEquals(0.0, result.getEntry(2), 0.0001);
                                            assertEquals(0.0, result.getEntry(3), 0.0001);
                                        }

    @Test
                                        public void testEbeMultiply_WithSparseVector() {
                                            // Create and initialize the main vector
                                            OpenMapRealVector vector = new OpenMapRealVector(4);
                                            vector.setEntry(0, 1.0);
                                            vector.setEntry(1, 2.0);
                                            vector.setEntry(2, 3.0);
                                            vector.setEntry(3, 4.0);
                                            
                                            // Create sparse vector with only one non-zero value
                                            OpenMapRealVector sparseVector = new OpenMapRealVector(4);
                                            sparseVector.setEntry(1, 3.0);
                                            
                                            OpenMapRealVector result = vector.ebeMultiply(sparseVector);
                                            
                                            assertEquals(4, result.getDimension());
                                            assertEquals(0.0, result.getEntry(0), 0.0001);  // 1.0 * 0.0 (default)
                                            assertEquals(6.0, result.getEntry(1), 0.0001);  // 2.0 * 3.0
                                            assertEquals(0.0, result.getEntry(2), 0.0001);  // 3.0 * 0.0 (default)
                                            assertEquals(0.0, result.getEntry(3), 0.0001);  // 4.0 * 0.0 (default)
                                        }

    @Test
                                        public void testEbeMultiply_WithDifferentDimension() {
                                            OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0});
                                            OpenMapRealVector differentDimVector = new OpenMapRealVector(new double[]{1.0, 2.0});
                                            
                                            thrown.expect(IllegalArgumentException.class);
                                            vector.ebeMultiply(differentDimVector);
                                        }

    @Test
                                        public void testEbeMultiply_WithNullVector() {
                                            OpenMapRealVector vector = new OpenMapRealVector(1); // Initialize with dimension 1
                                            ExpectedException thrown = ExpectedException.none();
                                            thrown.expect(NullPointerException.class);
                                            vector.ebeMultiply((RealVector)null);
                                        }

    @Test
                                        public void testEbeMultiply_WithMockVector() {
                                            // Create the test vector with initial values that match the test assertions
                                            OpenMapRealVector vector = new OpenMapRealVector(new double[] {1.0, 2.0, 0.0, 4.0});
                                            
                                            RealVector mockVector = mock(RealVector.class);
                                            when(mockVector.getDimension()).thenReturn(4);
                                            when(mockVector.getEntry(0)).thenReturn(2.0);
                                            when(mockVector.getEntry(1)).thenReturn(0.5);
                                            when(mockVector.getEntry(2)).thenReturn(1.0);
                                            when(mockVector.getEntry(3)).thenReturn(3.0);
                                            
                                            OpenMapRealVector result = vector.ebeMultiply(mockVector);
                                            
                                            assertEquals(4, result.getDimension());
                                            assertEquals(2.0, result.getEntry(0), 0.0001);  // 1.0 * 2.0
                                            assertEquals(1.0, result.getEntry(1), 0.0001);  // 2.0 * 0.5
                                            assertEquals(0.0, result.getEntry(2), 0.0001);  // 0.0 * 1.0
                                            assertEquals(12.0, result.getEntry(3), 0.0001); // 4.0 * 3.0
                                            
                                            verify(mockVector, times(1)).getDimension();
                                            verify(mockVector, times(1)).getEntry(0);
                                            verify(mockVector, times(1)).getEntry(1);
                                            verify(mockVector, times(1)).getEntry(2);
                                            verify(mockVector, times(1)).getEntry(3);
                                        }

    @Test
                                        public void testEbeMultiply_PreservesSparsity() {
                                            OpenMapRealVector sparseVector = new OpenMapRealVector(4);
                                            sparseVector.setEntry(1, 3.0);
                                            sparseVector.setEntry(3, 0.0);  // Explicit zero
                                            
                                            OpenMapRealVector vector = new OpenMapRealVector(4);
                                            vector.setEntry(1, 2.0);  // This will multiply with 3.0 to give 6.0
                                            
                                            OpenMapRealVector result = vector.ebeMultiply(sparseVector);
                                            
                                            // Check that the result maintains sparsity
                                            assertEquals(0.0, result.getEntry(0), 0.0001);
                                            assertEquals(6.0, result.getEntry(1), 0.0001);
                                            assertEquals(0.0, result.getEntry(2), 0.0001);
                                            assertEquals(0.0, result.getEntry(3), 0.0001);
                                        }

    @Test
                                        public void testEbeMultiply_WithNegativeValues() {
                                            // Setup test data
                                            double[] input = {-1.0, 1.0, -1.0, 1.0, -1.0};
                                            
                                            // Create the vector with test data
                                            OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0, 4.0, 5.0});
                                            
                                            // Create and configure mock iterator
                                            OpenIntToDoubleHashMap.Iterator mockIterator = mock(OpenIntToDoubleHashMap.Iterator.class);
                                            when(mockIterator.hasNext()).thenReturn(true, true, true, true, true, false);
                                            when(mockIterator.key()).thenReturn(0, 1, 2, 3, 4);
                                            when(mockIterator.value()).thenReturn(1.0, 2.0, 3.0, 4.0, 5.0);
                                            
                                            // Use reflection to inject the mock iterator into the vector
                                            try {
                                                Field entriesField = OpenMapRealVector.class.getDeclaredField("entries");
                                                entriesField.setAccessible(true);
                                                OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) entriesField.get(vector);
                                                
                                                Field iteratorField = OpenIntToDoubleHashMap.class.getDeclaredField("iterator");
                                                iteratorField.setAccessible(true);
                                                iteratorField.set(entries, mockIterator);
                                            } catch (Exception e) {
                                                fail("Failed to set up mock iterator via reflection: " + e.getMessage());
                                            }
                                            
                                            // Execute
                                            OpenMapRealVector result = vector.ebeMultiply(input);
                                            
                                            // Verify
                                            assertNotNull(result);
                                            assertEquals(1.0 * -1.0, result.getEntry(0), 0.0001);
                                            assertEquals(2.0 * 1.0, result.getEntry(1), 0.0001);
                                            assertEquals(3.0 * -1.0, result.getEntry(2), 0.0001);
                                            assertEquals(4.0 * 1.0, result.getEntry(3), 0.0001);
                                            assertEquals(5.0 * -1.0, result.getEntry(4), 0.0001);
                                        }

    @Test
                                        public void testEbeMultiply_DimensionMismatch() {
                                            // Create a vector with dimension 5
                                            OpenMapRealVector vector = new OpenMapRealVector(5);
                                            
                                            // Setup test data with wrong dimension
                                            double[] input = {1.0, 2.0, 3.0}; // length 3 vs vector length 5
                                            
                                            // Setup exception rule
                                            ExpectedException thrown = ExpectedException.none();
                                            thrown.expect(IllegalArgumentException.class);
                                            thrown.expectMessage("vector length mismatch: 5 != 3");
                                            
                                            // Execute
                                            vector.ebeMultiply(input);
                                        }

    @Test
                                    public void testEbeDivide_DifferentDimensionsShouldThrowException() {
                                        // Setup
                                        double[] data1 = {1.0, 2.0};
                                        double[] data2 = {1.0, 2.0, 3.0};
                                        OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                        OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                        
                                        try {
                                            // Execute
                                            vector1.ebeDivide(vector2);
                                            fail("Expected IllegalArgumentException");
                                        } catch (IllegalArgumentException e) {
                                            // Verify exception message
                                            assertEquals("vector length mismatch", e.getMessage());
                                            throw e;
                                        }
                                    }

    @Test
                                public void testEbeMultiply_WithZeroValues() {
                                    // Setup test data
                                    double[] input = {0.0, 1.0, 0.0, 1.0, 0.0};
                                    double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                    
                                    // Create the vector to test
                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                    
                                    // Execute
                                    OpenMapRealVector result = vector.ebeMultiply(input);
                                    
                                    // Verify
                                    assertNotNull(result);
                                    assertEquals(0.0, result.getEntry(0), 0.0001);
                                    assertEquals(2.0, result.getEntry(1), 0.0001);  // 2.0 * 1.0 = 2.0
                                    assertEquals(0.0, result.getEntry(2), 0.0001);
                                    assertEquals(4.0, result.getEntry(3), 0.0001);  // 4.0 * 1.0 = 4.0
                                    assertEquals(0.0, result.getEntry(4), 0.0001);
                                }

    @Test
                                public void testEbeMultiply_WithNullInput() {
                                    // Setup
                                    OpenMapRealVector vector = new OpenMapRealVector(3); // Create a vector with dimension 3
                                    
                                    // Expect exception
                                    thrown.expect(NullPointerException.class);
                                    
                                    // Execute
                                    vector.ebeMultiply((RealVector) null);
                                }

    @Test
                                public void testEbeMultiply_SparseVectorMultiplication() {
                                    // Setup sparse vector (only some entries have non-zero values)
                                    double[] input = {1.0, 2.0, 3.0, 4.0, 5.0};
                                    
                                    // Create the vector to test (initialized with zeros by default)
                                    OpenMapRealVector vector = new OpenMapRealVector(input.length);
                                    
                                    // Set some non-zero values
                                    vector.setEntry(1, 2.0);
                                    vector.setEntry(3, 4.0);
                                    
                                    // Execute
                                    OpenMapRealVector result = vector.ebeMultiply(input);
                                    
                                    // Verify
                                    assertNotNull(result);
                                    // Default value (0.0) for non-specified entries
                                    assertEquals(0.0, result.getEntry(0), 0.0001);
                                    assertEquals(2.0 * 2.0, result.getEntry(1), 0.0001);
                                    assertEquals(0.0, result.getEntry(2), 0.0001);
                                    assertEquals(4.0 * 4.0, result.getEntry(3), 0.0001);
                                    assertEquals(0.0, result.getEntry(4), 0.0001);
                                }

    @Test
    public void testEbeMultiply_TypicalCase1() {
        // Setup test data
        double[] input = {1.0, 2.0, 3.0, 4.0, 5.0};
        
        // Create and initialize the vector
        OpenMapRealVector vector = new OpenMapRealVector(input);
        
        try {
            // Get the entries field
            Field entriesField = OpenMapRealVector.class.getDeclaredField("entries");
            entriesField.setAccessible(true);
            OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) entriesField.get(vector);
            
            // Create mock Iterator instances using reflection since constructor is private
            Class<?> iteratorClass = OpenIntToDoubleHashMap.Iterator.class;
            Constructor<?> iteratorConstructor = iteratorClass.getDeclaredConstructor(OpenIntToDoubleHashMap.class);
            iteratorConstructor.setAccessible(true);
            
            OpenIntToDoubleHashMap.Iterator iter0 = (OpenIntToDoubleHashMap.Iterator) iteratorConstructor.newInstance(entries);
            OpenIntToDoubleHashMap.Iterator iter1 = (OpenIntToDoubleHashMap.Iterator) iteratorConstructor.newInstance(entries);
            OpenIntToDoubleHashMap.Iterator iter2 = (OpenIntToDoubleHashMap.Iterator) iteratorConstructor.newInstance(entries);
            OpenIntToDoubleHashMap.Iterator iter3 = (OpenIntToDoubleHashMap.Iterator) iteratorConstructor.newInstance(entries);
            OpenIntToDoubleHashMap.Iterator iter4 = (OpenIntToDoubleHashMap.Iterator) iteratorConstructor.newInstance(entries);
            
            // Mock the iterator values using reflection
            Field valueField = OpenIntToDoubleHashMap.Iterator.class.getDeclaredField("value");
            valueField.setAccessible(true);
            valueField.set(iter0, 2.0);
            valueField.set(iter1, 3.0);
            valueField.set(iter2, 4.0);
            valueField.set(iter3, 5.0);
            valueField.set(iter4, 6.0);
            
            Field keyField = OpenIntToDoubleHashMap.Iterator.class.getDeclaredField("key");
            keyField.setAccessible(true);
            keyField.set(iter0, 0);
            keyField.set(iter1, 1);
            keyField.set(iter2, 2);
            keyField.set(iter3, 3);
            keyField.set(iter4, 4);
            
            // Create a mock iterator using Mockito - removed type parameter
            Iterator mockIterator = mock(Iterator.class);
            when(mockIterator.hasNext()).thenReturn(true, true, true, true, true, false);
            
            // Replace the vector's iterator with our mock
            Field iteratorField = OpenIntToDoubleHashMap.class.getDeclaredField("iterator");
            iteratorField.setAccessible(true);
            iteratorField.set(entries, mockIterator);
        } catch (Exception e) {
            fail("Failed to set mock iterator via reflection: " + e.getMessage());
        }
        
        // Execute
        OpenMapRealVector result = vector.ebeMultiply(input);
        
        // Verify
        assertNotNull(result);
        assertEquals(2.0 * 1.0, result.getEntry(0), 0.0001);
        assertEquals(3.0 * 2.0, result.getEntry(1), 0.0001);
        assertEquals(4.0 * 3.0, result.getEntry(2), 0.0001);
        assertEquals(5.0 * 4.0, result.getEntry(3), 0.0001);
        assertEquals(6.0 * 5.0, result.getEntry(4), 0.0001);
    }


}
