package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                        public void testAdd_TypicalComplexNumbers() {
                                                            Complex c1 = new Complex(3.0, 4.0);
                                                            Complex c2 = new Complex(2.0, -1.0);
                                                            Complex result = c1.add(c2);
                                                            
                                                            assertEquals(5.0, result.getReal(), 0.0001);
                                                            assertEquals(3.0, result.getImaginary(), 0.0001);
                                                        }

    @Test
                                                        public void testAdd_WithZero() {
                                                            Complex c1 = new Complex(1.5, 2.5);
                                                            Complex c2 = Complex.ZERO;
                                                            Complex result = c1.add(c2);
                                                            
                                                            assertEquals(1.5, result.getReal(), 0.0001);
                                                            assertEquals(2.5, result.getImaginary(), 0.0001);
                                                        }

    @Test
                                                        public void testAdd_WithNaN() {
                                                            Complex c1 = new Complex(Double.NaN, 4.0);
                                                            Complex c2 = new Complex(2.0, 3.0);
                                                            Complex result = c1.add(c2);
                                                            
                                                            assertTrue(result.isNaN());
                                                        }

    @Test
                                                        public void testAdd_BothNaN() {
                                                            Complex c1 = new Complex(Double.NaN, Double.NaN);
                                                            Complex c2 = new Complex(Double.NaN, 3.0);
                                                            Complex result = c1.add(c2);
                                                            
                                                            assertTrue(result.isNaN());
                                                        }

    @Test
                                                        public void testAdd_WithInfinity() {
                                                            Complex c1 = new Complex(Double.POSITIVE_INFINITY, 4.0);
                                                            Complex c2 = new Complex(2.0, 3.0);
                                                            Complex result = c1.add(c2);
                                                            
                                                            assertTrue(result.isInfinite());
                                                            assertEquals(Double.POSITIVE_INFINITY, result.getReal(), 0.0001);
                                                            assertEquals(7.0, result.getImaginary(), 0.0001);
                                                        }

    @Test
                                                        public void testAdd_NullArgument() {
                                                            Complex c1 = new Complex(1.0, 2.0);
                                                            
                                                            thrown.expect(NullPointerException.class);
                                                            c1.add(null);
                                                        }

    @Test
                                                        public void testAdd_CommutativeProperty() {
                                                            Complex c1 = new Complex(1.5, 2.5);
                                                            Complex c2 = new Complex(3.5, 4.5);
                                                            
                                                            Complex result1 = c1.add(c2);
                                                            Complex result2 = c2.add(c1);
                                                            
                                                            assertEquals(result1.getReal(), result2.getReal(), 0.0001);
                                                            assertEquals(result1.getImaginary(), result2.getImaginary(), 0.0001);
                                                        }

    @Test
                                                        public void testAdd_AssociativeProperty() {
                                                            Complex c1 = new Complex(1.0, 2.0);
                                                            Complex c2 = new Complex(3.0, 4.0);
                                                            Complex c3 = new Complex(5.0, 6.0);
                                                            
                                                            Complex result1 = c1.add(c2).add(c3);
                                                            Complex result2 = c1.add(c2.add(c3));
                                                            
                                                            assertEquals(result1.getReal(), result2.getReal(), 0.0001);
                                                            assertEquals(result1.getImaginary(), result2.getImaginary(), 0.0001);
                                                        }

    @Test
                                                        public void testAdd_WithNegativeValues() {
                                                            Complex c1 = new Complex(-3.0, -4.0);
                                                            Complex c2 = new Complex(-2.0, 1.0);
                                                            Complex result = c1.add(c2);
                                                            
                                                            assertEquals(-5.0, result.getReal(), 0.0001);
                                                            assertEquals(-3.0, result.getImaginary(), 0.0001);
                                                        }

    @Test
                                                        public void testAdd_WithMockedComplex() {
                                                            Complex c1 = new Complex(2.0, 3.0);
                                                            Complex mockedComplex = mock(Complex.class);
                                                            
                                                            when(mockedComplex.getReal()).thenReturn(1.5);
                                                            when(mockedComplex.getImaginary()).thenReturn(2.5);
                                                            when(mockedComplex.isNaN()).thenReturn(false);
                                                            
                                                            Complex result = c1.add(mockedComplex);
                                                            
                                                            assertEquals(3.5, result.getReal(), 0.0001);
                                                            assertEquals(5.5, result.getImaginary(), 0.0001);
                                                            
                                                            verify(mockedComplex).getReal();
                                                            verify(mockedComplex).getImaginary();
                                                            verify(mockedComplex).isNaN();
                                                        }

    @Test
                                                    public void testEqualsWithNaN() {
                                                        // Create test objects
                                                        Complex nanComplex = new Complex(Double.NaN, 1.0);
                                                        Complex normalComplex = new Complex(1.0, 1.0);
                                                        Complex anotherNanComplex = new Complex(Double.NaN, Double.NaN);
                                                        
                                                        // Case 1: this is NaN, rhs is not NaN
                                                        assertFalse("Should return false when only this is NaN", 
                                                                   nanComplex.equals(normalComplex));
                                                        
                                                        // Case 2: this is not NaN, rhs is NaN
                                                        assertFalse("Should return false when only rhs is NaN", 
                                                                   normalComplex.equals(nanComplex));
                                                        
                                                        // Case 3: both are NaN
                                                        assertTrue("Should return true when both are NaN",
                                                                  nanComplex.equals(anotherNanComplex));
                                                        
                                                        // Case 4: neither is NaN
                                                        Complex sameNormalComplex = new Complex(1.0, 1.0);
                                                        assertTrue("Should return true for equal normal complexes",
                                                                  normalComplex.equals(sameNormalComplex));
                                                    }

    @Test
                                                public void testAbsWithNaNReal() {
                                                    // Create complex number with NaN real part
                                                    Complex c = new Complex(Double.NaN, 1.0);
                                                    
                                                    // Verify abs returns NaN when real is NaN
                                                    assertEquals(Double.NaN, c.abs(), 0.0);
                                                }

    @Test
                                                public void testAbsWithNaNImaginary() {
                                                    // Create complex number with NaN imaginary part
                                                    Complex c = new Complex(1.0, Double.NaN);
                                                    
                                                    // Verify abs returns NaN when imaginary is NaN
                                                    assertEquals(Double.NaN, c.abs(), 0.0);
                                                }

    @Test
                                                public void testAbsWithBothNaN() {
                                                    // Create complex number with both parts NaN
                                                    Complex c = new Complex(Double.NaN, Double.NaN);
                                                    
                                                    // Verify abs returns NaN
                                                    assertEquals(Double.NaN, c.abs(), 0.0);
                                                }

    @Test
                                            public void testAddDetectsOperandOrderMutation() {
                                                // Setup test with values where floating point addition order matters
                                                Complex c1 = new Complex(1.0e-16, 2.0e-16);
                                                Complex c2 = new Complex(1.0, 2.0);
                                                
                                                // Test addition both ways
                                                Complex result1 = c1.add(c2);
                                                Complex result2 = c2.add(c1);
                                                
                                                // Verify real part addition
                                                assertEquals(1.0 + 1.0e-16, result1.getReal(), 1.0e-20);
                                                assertEquals(1.0 + 1.0e-16, result2.getReal(), 1.0e-20);
                                                
                                                // Verify imaginary part addition
                                                assertEquals(2.0 + 2.0e-16, result1.getImaginary(), 1.0e-20);
                                                assertEquals(2.0 + 2.0e-16, result2.getImaginary(), 1.0e-20);
                                                
                                                // Test with special values
                                                Complex cNaN = new Complex(Double.NaN, Double.NaN);
                                                Complex cInf = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                                                
                                                // NaN tests
                                                assertTrue(c1.add(cNaN).isNaN());
                                                assertTrue(cNaN.add(c1).isNaN());
                                                
                                                // Infinity tests
                                                assertTrue(c1.add(cInf).isInfinite());
                                                assertTrue(cInf.add(c1).isInfinite());
                                                
                                                // Zero addition tests
                                                Complex zero = new Complex(0, 0);
                                                assertEquals(c1, c1.add(zero));
                                                assertEquals(c1, zero.add(c1));
                                            }

    @Test
                                        public void testAddImaginaryOrder() {
                                            // Create a mock Complex object to track getImaginary() calls
                                            Complex rhs = mock(Complex.class);
                                            when(rhs.getImaginary()).thenReturn(2.0);
                                            
                                            // Create a test complex number
                                            Complex complex = new Complex(1.0, 3.0);
                                            
                                            // Perform the addition
                                            complex.add(rhs);
                                            
                                            // Verify the order of operations - this will fail if the mutant survives
                                            verify(rhs).getImaginary();
                                            
                                            // Additional test with floating point precision considerations
                                            Complex c1 = new Complex(0.0, Double.MIN_VALUE);
                                            Complex c2 = new Complex(0.0, Double.MIN_VALUE);
                                            Complex result = c1.add(c2);
                                            
                                            // Verify the addition was performed correctly
                                            assertEquals(2.0 * Double.MIN_VALUE, result.getImaginary(), 0.0);
                                        }

    @Test
                            public void testAbsWithNullInputShouldThrowNullArgumentException() {
                                // Arrange
                                Complex complex = new Complex(1.0, 1.0);
                                
                                // Set up exception expectation
                                thrown.expect(NullArgumentException.class);
                                thrown.expectMessage("null is not allowed");
                                
                                // Act - this should throw the exception
                                // Since abs() doesn't take parameters, we need to test a method that does
                                complex.add(null);
                            }

    @Test(expected = NullPointerException.class)
                            public void testAddWithNullShouldThrowException() {
                                Complex complex = new Complex(1.0, 2.0);
                                complex.add(null);
                            }

    @Test(expected = NullPointerException.class)
                            public void testSubtractWithNullShouldThrowException() {
                                Complex complex = new Complex(1.0, 2.0);
                                complex.subtract(null);
                            }

    @Test(expected = NullPointerException.class)
                            public void testDivideWithNullShouldThrowException() {
                                Complex complex = new Complex(1.0, 2.0);
                                complex.divide(null);
                            }

    @Test(expected = NullPointerException.class)
                            public void testMultiplyWithNullShouldThrowException() {
                                Complex complex = new Complex(1.0, 2.0);
                                complex.multiply(null);
                            }

    @Test(expected = NullPointerException.class)
                            public void testPowWithNullShouldThrowException() {
                                Complex complex = new Complex(1.0, 2.0);
                                complex.pow(null);
                            }

    @Test
                            public void testAbsWithNaN() {
                                Complex complex = new Complex(Double.NaN, 1.0);
                                assertEquals(Double.NaN, complex.abs(), 0.0);
                            }

    @Test
                            public void testAbsWithInfinite() {
                                Complex complex = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                assertEquals(Double.POSITIVE_INFINITY, complex.abs(), 0.0);
                            }

    @Test
                            public void testAbsWithRealDominant() {
                                Complex complex = new Complex(3.0, 4.0);
                                assertEquals(5.0, complex.abs(), 0.0001);
                            }

    @Test
                            public void testAbsWithImaginaryDominant() {
                                Complex complex = new Complex(4.0, 3.0);
                                assertEquals(5.0, complex.abs(), 0.0001);
                            }

    @Test
                            public void testAbsWithZeroReal() {
                                Complex complex = new Complex(0.0, 5.0);
                                assertEquals(5.0, complex.abs(), 0.0);
                            }

    @Test
                            public void testAbsWithZeroImaginary() {
                                Complex complex = new Complex(5.0, 0.0);
                                assertEquals(5.0, complex.abs(), 0.0);
                            }

    @Test
                        public void testAbsWithNaN1() {
                            // Case 1: Current complex is NaN
                            Complex nanComplex = new Complex(Double.NaN, 1.0);
                            assertEquals(Double.NaN, nanComplex.abs(), 0.0);
                            
                            // Case 2: Current complex has NaN in imaginary part
                            Complex nanImaginary = new Complex(1.0, Double.NaN);
                            assertEquals(Double.NaN, nanImaginary.abs(), 0.0);
                            
                            // Case 3: Regular number (not NaN)
                            Complex regular = new Complex(3.0, 4.0);
                            assertEquals(5.0, regular.abs(), 0.0001);
                            
                            // Case 4: Infinite number
                            Complex infinite = new Complex(Double.POSITIVE_INFINITY, 1.0);
                            assertEquals(Double.POSITIVE_INFINITY, infinite.abs(), 0.0);
                        }

    @Test
                    public void testEqualsWithNaN1() {
                        Complex nan1 = new Complex(Double.NaN, 1.0);
                        Complex nan2 = new Complex(1.0, Double.NaN);
                        Complex regular = new Complex(1.0, 1.0);
                        
                        // Original would return true for these cases, mutant would return false
                        assertTrue(nan1.equals(regular));  // Should be true because nan1 is NaN
                        assertTrue(regular.equals(nan2));  // Should be true because nan2 is NaN
                        assertTrue(nan1.equals(nan2));     // Both are NaN
                        assertTrue(regular.equals(regular)); // Neither is NaN
                    }

    @Test
                public void testAbsWithNaN2() {
                    // Create a complex number with NaN components
                    Complex nanComplex = new Complex(Double.NaN, Double.NaN);
                    
                    // Verify the isNaN flag is set (sanity check)
                    assertTrue(nanComplex.isNaN());
                    
                    // Test the abs() method - should return Double.NaN
                    double result = nanComplex.abs();
                    
                    // This assertion will catch the mutant:
                    // Original code returns NaN, mutant will return calculated value
                    assertTrue(Double.isNaN(result));
                    
                    // Additional test cases with partial NaN
                    Complex partialNan1 = new Complex(Double.NaN, 1.0);
                    assertTrue(Double.isNaN(partialNan1.abs()));
                    
                    Complex partialNan2 = new Complex(1.0, Double.NaN);
                    assertTrue(Double.isNaN(partialNan2.abs()));
                }

    @Test
                public void testAddDetectsOperandOrderMutation1() {
                    // Test with regular numbers
                    Complex c1 = new Complex(1.5, 2.5);
                    Complex c2 = new Complex(3.5, 4.5);
                    Complex result = c1.add(c2);
                    assertEquals(5.0, result.getReal(), 0.0);  // 1.5 + 3.5
                    assertEquals(7.0, result.getImaginary(), 0.0);  // 2.5 + 4.5
                    
                    // Test with negative numbers
                    Complex c3 = new Complex(-1.0, -2.0);
                    Complex c4 = new Complex(-3.0, -4.0);
                    result = c3.add(c4);
                    assertEquals(-4.0, result.getReal(), 0.0);
                    assertEquals(-6.0, result.getImaginary(), 0.0);
                    
                    // Test with NaN
                    Complex c5 = new Complex(Double.NaN, 1.0);
                    Complex c6 = new Complex(1.0, 1.0);
                    result = c5.add(c6);
                    assertTrue(Double.isNaN(result.getReal()));
                    assertTrue(Double.isNaN(result.getImaginary()));
                    
                    // Test with infinity
                    Complex c7 = new Complex(Double.POSITIVE_INFINITY, 1.0);
                    Complex c8 = new Complex(1.0, 1.0);
                    result = c7.add(c8);
                    assertEquals(Double.POSITIVE_INFINITY, result.getReal(), 0.0);
                    assertEquals(2.0, result.getImaginary(), 0.0);
                    
                    // Test with very small numbers where operand order might matter
                    Complex c9 = new Complex(Double.MIN_VALUE, 0.0);
                    Complex c10 = new Complex(Double.MIN_VALUE, 0.0);
                    result = c9.add(c10);
                    assertEquals(2 * Double.MIN_VALUE, result.getReal(), 0.0);
                }

    @Test
            public void testAddCommutativeProperty() {
                // Test with normal numbers
                Complex c1 = new Complex(1.5, 2.5);
                Complex c2 = new Complex(3.5, 4.5);
                Complex result1 = c1.add(c2);
                Complex result2 = c2.add(c1);
                assertEquals(result1.getReal(), result2.getReal(), 0.000001);
                assertEquals(result1.getImaginary(), result2.getImaginary(), 0.000001);
                
                // Test with edge cases
                Complex c3 = new Complex(Double.MIN_VALUE, Double.MAX_VALUE);
                Complex c4 = new Complex(Double.MAX_VALUE, Double.MIN_VALUE);
                Complex result3 = c3.add(c4);
                Complex result4 = c4.add(c3);
                assertEquals(result3.getReal(), result4.getReal(), 0.000001);
                assertEquals(result3.getImaginary(), result4.getImaginary(), 0.000001);
                
                // Test with very small differences
                Complex c5 = new Complex(1.000000000000001, 2.000000000000002);
                Complex c6 = new Complex(3.000000000000003, 4.000000000000004);
                Complex result5 = c5.add(c6);
                Complex result6 = c6.add(c5);
                assertEquals(result5.getReal(), result6.getReal(), 0.0000000000000001);
                assertEquals(result5.getImaginary(), result6.getImaginary(), 0.0000000000000001);
            }

    @Test
            public void testAddWithMock() {
                // Create a mock Complex object
                Complex mockComplex = mock(Complex.class);
                when(mockComplex.getReal()).thenReturn(2.0);
                when(mockComplex.getImaginary()).thenReturn(3.0);
                
                // Test with real Complex and mock
                Complex c1 = new Complex(1.0, 2.0);
                Complex result = c1.add(mockComplex);
                
                // Verify interactions
                verify(mockComplex).getReal();
                verify(mockComplex).getImaginary();
                
                // Verify results
                assertEquals(3.0, result.getReal(), 0.000001);
                assertEquals(5.0, result.getImaginary(), 0.000001);
            }

    @Test
        public void testAddWithNullArgumentThrowsException() {
            Complex complex = new Complex(1.0, 2.0);
            
            // Expect NullPointerException for original code, 
            // but NullArgumentException for mutated code
            thrown.expect(NullPointerException.class);
            complex.add(null);
        }

    @Test
        public void testSubtractWithNullArgumentThrowsException() {
            Complex complex = new Complex(1.0, 2.0);
            
            thrown.expect(NullPointerException.class);
            complex.subtract(null);
        }

    @Test
        public void testMultiplyWithNullArgumentThrowsException() {
            Complex complex = new Complex(1.0, 2.0);
            
            thrown.expect(NullPointerException.class);
            complex.multiply((Complex)null);
        }

    @Test
        public void testDivideWithNullArgumentThrowsException() {
            Complex complex = new Complex(1.0, 2.0);
            
            thrown.expect(NullPointerException.class);
            complex.divide(null);
        }

}
