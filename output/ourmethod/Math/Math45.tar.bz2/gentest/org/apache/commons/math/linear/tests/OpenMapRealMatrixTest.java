package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import org.apache.commons.math.exception.NumberIsTooLargeException;
import org.apache.commons.math.util.OpenIntToDoubleHashMap;
 
public class OpenMapRealMatrixTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                        public void testConstructor_NormalDimensions() {
                                                            // Test normal case with valid dimensions
                                                            OpenMapRealMatrix matrix = new OpenMapRealMatrix(3, 4);
                                                            
                                                            assertEquals(3, matrix.getRowDimension());
                                                            assertEquals(4, matrix.getColumnDimension());
                                                            // Verify entries map is initialized (can't directly test private field, but can test behavior)
                                                            assertEquals(0.0, matrix.getEntry(0, 0), 0.0001);
                                                        }

    @Test
                                                        public void testConstructor_MinimumDimensions() {
                                                            // Test smallest possible dimensions
                                                            OpenMapRealMatrix matrix = new OpenMapRealMatrix(1, 1);
                                                            
                                                            assertEquals(1, matrix.getRowDimension());
                                                            assertEquals(1, matrix.getColumnDimension());
                                                        }

    @Test
                                                        public void testConstructor_ZeroRows() {
                                                            thrown.expect(IllegalArgumentException.class);
                                                            new OpenMapRealMatrix(0, 5); // 0 rows should throw exception
                                                        }

    @Test
                                                        public void testConstructor_ZeroColumns() {
                                                            thrown.expect(IllegalArgumentException.class);
                                                            new OpenMapRealMatrix(5, 0); // 0 columns should throw exception
                                                        }

    @Test
                                                        public void testConstructor_NegativeRows() {
                                                            thrown.expect(IllegalArgumentException.class);
                                                            new OpenMapRealMatrix(-1, 5); // negative rows should throw exception
                                                        }

    @Test
                                                        public void testConstructor_NegativeColumns() {
                                                            thrown.expect(IllegalArgumentException.class);
                                                            new OpenMapRealMatrix(5, -1); // negative columns should throw exception
                                                        }

    @Test
                                                        public void testConstructor_MaxDimensionsJustBelowLimit() {
                                                            // Test dimensions where product is just below Integer.MAX_VALUE
                                                            // Using prime factors to avoid exact square root
                                                            int rows = 46340; // sqrt(Integer.MAX_VALUE) is ~46340.95
                                                            int cols = 46340;
                                                            
                                                            OpenMapRealMatrix matrix = new OpenMapRealMatrix(rows, cols);
                                                            
                                                            assertEquals(rows, matrix.getRowDimension());
                                                            assertEquals(cols, matrix.getColumnDimension());
                                                        }

    @Test
                                                        public void testConstructor_DimensionsExceedingIntegerMax() {
                                                            thrown.expect(NumberIsTooLargeException.class);
                                                            // Test dimensions where product would exceed Integer.MAX_VALUE
                                                            int rows = 50000;
                                                            int cols = 50000;
                                                            new OpenMapRealMatrix(rows, cols);
                                                        }

    @Test
                                                        public void testConstructor_OneDimensionVeryLarge() {
                                                            thrown.expect(NumberIsTooLargeException.class);
                                                            // Test where one dimension is 1 and the other is Integer.MAX_VALUE
                                                            // This should still throw because 1 * Integer.MAX_VALUE == Integer.MAX_VALUE
                                                            // and the check is >= Integer.MAX_VALUE
                                                            new OpenMapRealMatrix(1, Integer.MAX_VALUE);
                                                        }

    @Test
                                                        public void testConstructor_EntriesMapInitialized() {
                                                            OpenMapRealMatrix matrix = new OpenMapRealMatrix(2, 2);
                                                            
                                                            // Verify entries map is properly initialized by testing behavior
                                                            // Default value should be 0.0
                                                            assertEquals(0.0, matrix.getEntry(0, 0), 0.0001);
                                                            assertEquals(0.0, matrix.getEntry(1, 1), 0.0001);
                                                            
                                                            // Test setting and getting a value
                                                            matrix.setEntry(0, 0, 1.5);
                                                            assertEquals(1.5, matrix.getEntry(0, 0), 0.0001);
                                                        }

    @Test
                                                        public void testConstructor_CopyValidMatrix() {
                                                            // Setup original matrix with some entries
                                                            OpenMapRealMatrix original = new OpenMapRealMatrix(3, 4);
                                                            original.setEntry(0, 0, 1.5);
                                                            original.setEntry(1, 2, 2.5);
                                                            original.setEntry(2, 3, 3.5);
                                                            
                                                            // Create copy using constructor
                                                            OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                                            
                                                            // Verify dimensions are copied correctly
                                                            assertEquals(original.getRowDimension(), copy.getRowDimension());
                                                            assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                                                            
                                                            // Verify all entries are copied correctly
                                                            assertEquals(1.5, copy.getEntry(0, 0), 0.0001);
                                                            assertEquals(2.5, copy.getEntry(1, 2), 0.0001);
                                                            assertEquals(3.5, copy.getEntry(2, 3), 0.0001);
                                                            
                                                            // Verify it's a deep copy by modifying original and checking copy remains unchanged
                                                            original.setEntry(0, 0, 99.9);
                                                            assertEquals(1.5, copy.getEntry(0, 0), 0.0001);
                                                        }

    @Test
                                                        public void testConstructor_CopyEmptyMatrix() {
                                                            // Setup empty matrix
                                                            OpenMapRealMatrix original = new OpenMapRealMatrix(2, 2);
                                                            
                                                            // Create copy
                                                            OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                                            
                                                            // Verify dimensions
                                                            assertEquals(2, copy.getRowDimension());
                                                            assertEquals(2, copy.getColumnDimension());
                                                            
                                                            // Verify all entries are zero (default)
                                                            assertEquals(0.0, copy.getEntry(0, 0), 0.0001);
                                                            assertEquals(0.0, copy.getEntry(0, 1), 0.0001);
                                                            assertEquals(0.0, copy.getEntry(1, 0), 0.0001);
                                                            assertEquals(0.0, copy.getEntry(1, 1), 0.0001);
                                                        }

    @Test
                                                        public void testConstructor_CopySparseMatrix() {
                                                            // Setup sparse matrix with only one entry
                                                            OpenMapRealMatrix original = new OpenMapRealMatrix(100, 100);
                                                            original.setEntry(99, 99, 42.0);
                                                            
                                                            // Create copy
                                                            OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                                            
                                                            // Verify dimensions
                                                            assertEquals(100, copy.getRowDimension());
                                                            assertEquals(100, copy.getColumnDimension());
                                                            
                                                            // Verify only the set entry is copied
                                                            assertEquals(42.0, copy.getEntry(99, 99), 0.0001);
                                                            assertEquals(0.0, copy.getEntry(0, 0), 0.0001);
                                                        }

    @Test
                                                        public void testConstructor_CopyModifiedAfterCreation() {
                                                            // Setup original matrix
                                                            OpenMapRealMatrix original = new OpenMapRealMatrix(2, 2);
                                                            original.setEntry(0, 0, 5.0);
                                                            
                                                            // Create copy
                                                            OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                                            
                                                            // Modify copy and verify original remains unchanged
                                                            copy.setEntry(0, 0, 10.0);
                                                            assertEquals(5.0, original.getEntry(0, 0), 0.0001);
                                                            assertEquals(10.0, copy.getEntry(0, 0), 0.0001);
                                                        }

    @Test(expected = NullPointerException.class)
                                                public void testConstructor_NullInput() {
                                                    // Testing copy constructor with null
                                                    new OpenMapRealMatrix((OpenMapRealMatrix)null);
                                                }

    @Test
                                                public void testConstructor_CopyWithMockedEntries() throws Exception {
                                                    // Mock the entries map
                                                    OpenIntToDoubleHashMap mockedEntries = mock(OpenIntToDoubleHashMap.class);
                                                    
                                                    // Create a mock matrix
                                                    OpenMapRealMatrix mockMatrix = mock(OpenMapRealMatrix.class);
                                                    when(mockMatrix.getRowDimension()).thenReturn(3);
                                                    when(mockMatrix.getColumnDimension()).thenReturn(3);
                                                    
                                                    // Use reflection to set the private entries field
                                                    Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                                                    entriesField.setAccessible(true);
                                                    entriesField.set(mockMatrix, mockedEntries);
                                                    
                                                    // Create copy
                                                    OpenMapRealMatrix copy = new OpenMapRealMatrix(mockMatrix);
                                                    
                                                    // Verify interactions
                                                    assertEquals(3, copy.getRowDimension());
                                                    assertEquals(3, copy.getColumnDimension());
                                                    verify(mockMatrix, times(1)).getRowDimension();
                                                    verify(mockMatrix, times(1)).getColumnDimension();
                                                    
                                                    // Verify the entries were accessed through the constructor
                                                    OpenIntToDoubleHashMap copyEntries = (OpenIntToDoubleHashMap) entriesField.get(copy);
                                                    assertNotNull(copyEntries);
                                                }

    @Test
                                                public void testCopyPreservesDimensions() {
                                                    // Create original matrix with distinct dimensions
                                                    int originalRows = 3;
                                                    int originalCols = 5;
                                                    OpenMapRealMatrix original = new OpenMapRealMatrix(originalRows, originalCols);
                                                    
                                                    // Set some values to ensure the copy operation works
                                                    original.setEntry(0, 0, 1.0);
                                                    original.setEntry(1, 2, 2.0);
                                                    original.setEntry(2, 4, 3.0);
                                                    
                                                    // Perform the copy operation
                                                    OpenMapRealMatrix copy = original.copy();
                                                    
                                                    // Verify dimensions are preserved (this would fail with the mutant)
                                                    assertEquals("Row dimension should match original", 
                                                                originalRows, copy.getRowDimension());
                                                    assertEquals("Column dimension should match original", 
                                                                originalCols, copy.getColumnDimension());
                                                    
                                                    // Verify data is correctly copied
                                                    assertEquals(1.0, copy.getEntry(0, 0), 0.0001);
                                                    assertEquals(2.0, copy.getEntry(1, 2), 0.0001);
                                                    assertEquals(3.0, copy.getEntry(2, 4), 0.0001);
                                                }

    @Test
                                            public void testCopyWithLargeDimensions() {
                                                // Test with dimensions that would overflow if not properly cast to long
                                                int largeDimension = Integer.MAX_VALUE / 2 + 1;
                                                
                                                // This should not throw an exception with proper casting
                                                OpenMapRealMatrix original = new OpenMapRealMatrix(largeDimension, 1);
                                                
                                                // Test the copy method
                                                OpenMapRealMatrix copy = original.copy();
                                                
                                                // Verify the copy has same dimensions
                                                assertEquals(original.getRowDimension(), copy.getRowDimension());
                                                assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                                            }

    @Test(expected = NumberIsTooLargeException.class)
                                            public void testConstructorWithOverflowingDimensions() {
                                                // These dimensions will overflow when multiplied if not properly cast to long
                                                int maxDim = Integer.MAX_VALUE;
                                                new OpenMapRealMatrix(maxDim, maxDim);
                                            }

    @Test
                                        public void testCopyConstructorWithLargeDimensions() {
                                            // Test case where row and column dimensions are different
                                            // and their product is close to Integer.MAX_VALUE
                                            
                                            // Create a matrix with dimensions that would fail validation if rows and columns were swapped
                                            int largeRows = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                                            int smallColumns = 1;
                                            
                                            try {
                                                // Original constructor should pass since (largeRows * 1) < MAX_VALUE
                                                OpenMapRealMatrix original = new OpenMapRealMatrix(largeRows, smallColumns);
                                                
                                                // The copy should maintain the same validation
                                                OpenMapRealMatrix copy = original.copy();
                                                
                                                // Verify dimensions are correctly copied
                                                assertEquals(largeRows, copy.getRowDimension());
                                                assertEquals(smallColumns, copy.getColumnDimension());
                                            } catch (NumberIsTooLargeException e) {
                                                fail("Valid matrix creation threw unexpected exception");
                                            }
                                            
                                            // Now test the opposite case that would fail with the mutation
                                            try {
                                                // If the mutation exists, this would incorrectly pass validation
                                                // because it would check (smallColumns * largeRows) instead of (largeRows * smallColumns)
                                                OpenMapRealMatrix mutated = new OpenMapRealMatrix(smallColumns, largeRows);
                                                
                                                // This should throw an exception, but with the mutation it might not
                                                mutated.copy();
                                                
                                                // If we get here, the mutation survived - the test should fail
                                                fail("Expected NumberIsTooLargeException not thrown - mutation survived");
                                            } catch (NumberIsTooLargeException e) {
                                                // This is expected for the original code
                                                assertTrue(e.getMessage().contains("exceeds"));
                                            }
                                        }

    @Test(expected = NumberIsTooLargeException.class)
                                        public void testCopyConstructorWithExtremeDimensions() {
                                            // Test case where dimensions are large enough that their product exceeds MAX_VALUE
                                            int extremeDimension = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                                            
                                            // This should throw exception in both original and mutated cases
                                            OpenMapRealMatrix matrix = new OpenMapRealMatrix(extremeDimension, extremeDimension);
                                            matrix.copy();
                                        }

    @Test
                                    public void testConstructorWithLargeDimensionsShouldThrowException() {
                                        int largeDim = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                                        
                                        thrown.expect(NumberIsTooLargeException.class);
                                        new OpenMapRealMatrix(largeDim, largeDim);
                                    }

    @Test
                                    public void testCopyWithLargeOriginalMatrix() {
                                        // Create a matrix with dimensions that would overflow if not properly cast to long
                                        int largeDim = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                                        OpenMapRealMatrix original = null;
                                        
                                        try {
                                            // This should throw exception in original version
                                            original = new OpenMapRealMatrix(largeDim, largeDim);
                                            fail("Expected NumberIsTooLargeException not thrown");
                                        } catch (NumberIsTooLargeException e) {
                                            // Expected behavior
                                            return;
                                        }
                                        
                                        // If we get here, the original constructor didn't throw exception
                                        // Now test the copy method
                                        thrown.expect(NumberIsTooLargeException.class);
                                        original.copy();
                                    }

    @Test
                        public void testConstructorThrowsWhenMatrixSizeExceedsMaxInt() {
                            // Choose dimensions where:
                            // rows * columns > Integer.MAX_VALUE (should throw)
                            // but rows + columns < Integer.MAX_VALUE (mutant wouldn't throw)
                            int largeDim = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                            
                            thrown.expect(NumberIsTooLargeException.class);
                            thrown.expectMessage(String.valueOf(Integer.MAX_VALUE));
                            
                            // This should throw in original, but mutant would allow it
                            new OpenMapRealMatrix(largeDim, largeDim);
                        }

    @Test
                        public void testCopyOfLargeMatrixThrowsSizeException() {
                            // First create a matrix with dimensions that would be invalid if constructed directly
                            // We need to bypass the constructor check to set up this test
                            OpenMapRealMatrix original = new OpenMapRealMatrix(1, 1) {
                                @Override
                                public int getRowDimension() {
                                    return (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                                }
                                @Override
                                public int getColumnDimension() {
                                    return (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                                }
                            };
                        
                            thrown.expect(NumberIsTooLargeException.class);
                            thrown.expectMessage(String.valueOf(Integer.MAX_VALUE));
                            
                            // The copy operation should fail the same size check
                            original.copy();
                        }

    @Test
                        public void testCopyConstructorWithMaxSizeMatrix() {
                            // Calculate dimensions that multiply to exactly Integer.MAX_VALUE
                            // Using prime factors of Integer.MAX_VALUE (which is 2^31-1 and prime)
                            // We'll use 1 and Integer.MAX_VALUE as dimensions
                            int rows = 1;
                            int cols = Integer.MAX_VALUE;
                            
                            try {
                                // Create original matrix (should fail due to memory constraints in reality,
                                // but we're testing the theoretical boundary check)
                                OpenMapRealMatrix original = new OpenMapRealMatrix(rows, cols);
                                
                                // Try to copy - original code would succeed, mutant would throw exception
                                OpenMapRealMatrix copy = original.copy();
                                
                                // If we get here, the test passes for original code (no exception)
                                // This means we've detected the mutant if it throws exception
                            } catch (NumberIsTooLargeException e) {
                                // Verify it's the correct exception with correct parameters
                                assertEquals(Integer.MAX_VALUE, e.getMax());
                                assertEquals(Integer.MAX_VALUE, e.getArgument());
                                assertTrue(e.getBoundIsAllowed());
                                // This assertion catches the mutant
                                fail("Mutant detected: Exception thrown for matrix size equal to MAX_VALUE");
                            }
                        }

    @Test(expected = NumberIsTooLargeException.class)
                        public void testConstructorWithSizeExceedingMaxValue() {
                            // Test case where size exceeds MAX_VALUE to ensure original exception behavior
                            int rows = Integer.MAX_VALUE;
                            int cols = 2;  // This will definitely exceed MAX_VALUE when multiplied
                            
                            new OpenMapRealMatrix(rows, cols);
                        }

    @Test
                    public void testConstructorWithLargeDimensions() {
                        // Test case where original would throw but mutant wouldn't
                        // Choose dimensions where (rows+1)*columns >= MAX_VALUE but rows*columns < MAX_VALUE
                        int largeRows = Integer.MAX_VALUE / 1000;
                        int columns = 1000;
                        
                        // Original code would accept this, mutant would throw
                        new OpenMapRealMatrix(largeRows, columns);
                        
                        // Now test case where both should throw
                        thrown.expect(NumberIsTooLargeException.class);
                        new OpenMapRealMatrix(Integer.MAX_VALUE / 2 + 1, 2);
                    }

    @Test
                    public void testCopyWithLargeOriginalMatrix1() {
                        // Create original matrix with dimensions that would fail in mutant constructor
                        int largeRows = Integer.MAX_VALUE / 1000;
                        int columns = 1000;
                        OpenMapRealMatrix original = new OpenMapRealMatrix(largeRows, columns);
                        
                        // Copy should work fine since it uses different constructor
                        OpenMapRealMatrix copy = original.copy();
                        assertEquals(original.getRowDimension(), copy.getRowDimension());
                        assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                    }

    @Test
                public void testCopyWithLargeDimensionsShouldThrowException() {
                    // These dimensions are chosen so that:
                    // As ints: 46341 * 46341 = -2147479015 (overflow)
                    // As longs: 46341L * 46341L = 2147488281 (valid, but > Integer.MAX_VALUE)
                    int largeDim = 46341;
                    
                    // Create original matrix with large dimensions
                    OpenMapRealMatrix original = new OpenMapRealMatrix(largeDim, largeDim);
                    
                    // The copy operation should throw NumberIsTooLargeException because
                    // the constructor checks the dimension product
                    thrown.expect(NumberIsTooLargeException.class);
                    thrown.expectMessage("2147488281");
                    
                    // This should trigger the exception in the constructor
                    original.copy();
                }

    @Test
            public void testConstructorThrowsWhenMatrixTooLarge() {
                // This test will catch the mutant because:
                // Original: 46342 * 46342 = 2,147,580,964 > Integer.MAX_VALUE (2,147,483,647) → should throw
                // Mutant: 46342 - 46342 = 0 < Integer.MAX_VALUE → won't throw
                int largeSize = 46342; // sqrt(Integer.MAX_VALUE) ≈ 46340.95
                
                thrown.expect(NumberIsTooLargeException.class);
                thrown.expectMessage("2,147,580,964");
                
                // This should throw in original but mutant would allow it
                new OpenMapRealMatrix(largeSize, largeSize);
            }

    @Test
            public void testConstructorAllowsValidSize() {
                // Valid case that both original and mutant should allow
                new OpenMapRealMatrix(100, 100);
            }

    @Test
            public void testConstructorThrowsWhenDifferenceTooLarge() {
                // This case would fail in mutant but pass in original
                // Not needed to catch this specific mutant but good for completeness
                int largeRow = Integer.MAX_VALUE;
                int smallCol = 1;
                
                thrown.expect(NumberIsTooLargeException.class);
                thrown.expectMessage(String.valueOf(largeRow - smallCol));
                
                // Mutant would throw here but original wouldn't
                new OpenMapRealMatrix(largeRow, smallCol);
            }

    @Test
        public void testCopyWithLargeButValidDimensions() {
            // These dimensions are large but their product is just below Integer.MAX_VALUE
            // sqrt(Integer.MAX_VALUE) ~= 46340, so 30000 x 70000 is valid (2.1e9 < 2.147483647e9)
            int largeRows = 30000;
            int largeCols = 70000;
            
            // Create original matrix - should succeed
            OpenMapRealMatrix original = new OpenMapRealMatrix(largeRows, largeCols);
            
            // Test copying - should succeed with original code but fail with mutant
            OpenMapRealMatrix copy = original.copy();
            
            // Verify the copy has same dimensions
            assertEquals(largeRows, copy.getRowDimension());
            assertEquals(largeCols, copy.getColumnDimension());
        }

    @Test
        public void testCopyWithTooLargeDimensions() {
            // These dimensions are too large (product would exceed Integer.MAX_VALUE)
            int tooLargeRows = 50000;
            int tooLargeCols = 50000;
            
            thrown.expect(NumberIsTooLargeException.class);
            thrown.expectMessage("50000 * 50000 = 2,500,000,000 >= 2,147,483,647");
            
            // This should throw in both original and mutant
            OpenMapRealMatrix original = new OpenMapRealMatrix(tooLargeRows, tooLargeCols);
        }

}
