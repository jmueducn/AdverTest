package gentest.org.apache.commons.math.optimization.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.linear.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.math.linear.MatrixUtils;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.RealMatrixImpl;
import org.apache.commons.math.linear.RealVector;
import org.apache.commons.math.optimization.GoalType;
import org.apache.commons.math.optimization.RealPointValuePair;
import org.apache.commons.math.util.MathUtils;
 
public class SimplexTableauTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                public void testGetBasicRow_MultipleOneEntriesReturnsNull() throws Exception {
                                                                                                                                                                                                                    // Create real tableau instance using reflection
                                                                                                                                                                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0, 0}, 0);
                                                                                                                                                                                                                    Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                                    GoalType goalType = GoalType.MAXIMIZE;
                                                                                                                                                                                                                    double epsilon = 1.0e-6;
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Get the SimplexTableau class
                                                                                                                                                                                                                    Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Get the constructor
                                                                                                                                                                                                                    Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                        LinearObjectiveFunction.class, Collection.class, GoalType.class, boolean.class, double.class);
                                                                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                                                                    Object tableau = constructor.newInstance(f, constraints, goalType, true, epsilon);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Use reflection to set up the tableau state
                                                                                                                                                                                                                    Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                                                                                                                                                                                                    tableauField.setAccessible(true);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Create the matrix implementation (using the correct class name)
                                                                                                                                                                                                                    Class<?> realMatrixImplClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                                                                                                                                                                                                    Object matrix = realMatrixImplClass.getConstructor(double[][].class)
                                                                                                                                                                                                                        .newInstance(new double[][]{
                                                                                                                                                                                                                            {0, 0, 0, 0},
                                                                                                                                                                                                                            {0, 0, 1.0000001, 0},
                                                                                                                                                                                                                            {0, 0, 0.0, 0},
                                                                                                                                                                                                                            {0, 0, 0.9999999, 0}
                                                                                                                                                                                                                        });
                                                                                                                                                                                                                    tableauField.set(tableau, matrix);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Use reflection to call the private method
                                                                                                                                                                                                                    Method getBasicRow = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                    getBasicRow.setAccessible(true);
                                                                                                                                                                                                                    Integer result = (Integer) getBasicRow.invoke(tableau, 2);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    assertNull(result);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testGetBasicRow_NonZeroEntryReturnsNull() throws Exception {
                                                                                                                                                                                                                    // Create necessary objects for SimplexTableau constructor
                                                                                                                                                                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                                                    Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                                    constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 1));
                                                                                                                                                                                                                    GoalType goalType = GoalType.MAXIMIZE;
                                                                                                                                                                                                                    boolean restrictToNonNegative = true;
                                                                                                                                                                                                                    double epsilon = 0.000001;
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Use reflection to create SimplexTableau instance
                                                                                                                                                                                                                    Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                    Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                        LinearObjectiveFunction.class, 
                                                                                                                                                                                                                        Collection.class, 
                                                                                                                                                                                                                        GoalType.class, 
                                                                                                                                                                                                                        boolean.class, 
                                                                                                                                                                                                                        double.class
                                                                                                                                                                                                                    );
                                                                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                                                                    Object tableau = constructor.newInstance(f, constraints, goalType, restrictToNonNegative, epsilon);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Use reflection to access private getBasicRow method
                                                                                                                                                                                                                    Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                    getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Use reflection to access private setEntry method
                                                                                                                                                                                                                    Method setEntryMethod = tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                                                                    setEntryMethod.setAccessible(true);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Set up test data in the tableau
                                                                                                                                                                                                                    setEntryMethod.invoke(tableau, 1, 2, 1.0000001);
                                                                                                                                                                                                                    setEntryMethod.invoke(tableau, 2, 2, 0.0);
                                                                                                                                                                                                                    setEntryMethod.invoke(tableau, 3, 2, 0.5);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Invoke the method
                                                                                                                                                                                                                    Integer result = (Integer) getBasicRowMethod.invoke(tableau, 2);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Verify the result
                                                                                                                                                                                                                    assertNull(result);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testGetBasicRow_FirstRowMatches() throws Exception {
                                                                                                                                                                                                                    // Use reflection to create necessary objects for SimplexTableau constructor
                                                                                                                                                                                                                    Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                                                                                                                                                    Object f = linearObjectiveFunctionClass.getConstructor(double[].class, double.class)
                                                                                                                                                                                                                            .newInstance(new double[]{1, 1}, 0.0);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    Collection<Object> constraints = new ArrayList<>();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                                                                                                                                                                    Object goalType = Enum.valueOf((Class<Enum>)goalTypeClass, "MAXIMIZE");
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    boolean restrictToNonNegative = true;
                                                                                                                                                                                                                    double epsilon = 1e-6;
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Create actual tableau instance using reflection
                                                                                                                                                                                                                    Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                    Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                            linearObjectiveFunctionClass, 
                                                                                                                                                                                                                            Collection.class, 
                                                                                                                                                                                                                            goalTypeClass, 
                                                                                                                                                                                                                            boolean.class, 
                                                                                                                                                                                                                            double.class);
                                                                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                                                                    Object tableau = constructor.newInstance(f, constraints, goalType, restrictToNonNegative, epsilon);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Use reflection to access private getBasicRow method
                                                                                                                                                                                                                    Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                    getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Set up tableau state using reflection to modify private fields
                                                                                                                                                                                                                    Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                                                                    tableauField.setAccessible(true);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    Class<?> realMatrixImplClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                                                                                                                                                                                                    Object matrix = realMatrixImplClass.getConstructor(double[][].class)
                                                                                                                                                                                                                            .newInstance((Object) new double[][]{
                                                                                                                                                                                                                                {0, 0, 0},  // objective row
                                                                                                                                                                                                                                {0, 0, 1.0000001},  // first constraint row
                                                                                                                                                                                                                                {0, 0, 0.0}   // second constraint row
                                                                                                                                                                                                                            });
                                                                                                                                                                                                                    tableauField.set(tableau, matrix);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    Field heightField = tableauClass.getDeclaredField("height");
                                                                                                                                                                                                                    heightField.setAccessible(true);
                                                                                                                                                                                                                    heightField.set(tableau, 3);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Invoke the method
                                                                                                                                                                                                                    Integer result = (Integer) getBasicRowMethod.invoke(tableau, 2);
                                                                                                                                                                                                                    assertEquals(Integer.valueOf(1), result);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testGetBasicRow_ValueJustOutsideEpsilonReturnsNull() throws Exception {
                                                                                                                                                                                                                    // Create necessary objects for constructor
                                                                                                                                                                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                                                    Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                                                                                                                                                                                                    GoalType goalType = GoalType.MAXIMIZE;
                                                                                                                                                                                                                    double epsilon = 0.000001;
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Get the SimplexTableau class using reflection
                                                                                                                                                                                                                    Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Create real instance using reflection since constructor is not public
                                                                                                                                                                                                                    Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                        LinearObjectiveFunction.class, Collection.class, GoalType.class, boolean.class, double.class);
                                                                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                                                                    Object tableau = constructor.newInstance(f, constraints, goalType, true, epsilon);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Set up entries using reflection
                                                                                                                                                                                                                    Method setEntryMethod = simplexTableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                                                                    setEntryMethod.setAccessible(true);
                                                                                                                                                                                                                    setEntryMethod.invoke(tableau, 1, 2, 0.0);
                                                                                                                                                                                                                    setEntryMethod.invoke(tableau, 2, 2, 0.000002); // just outside epsilon
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Test getBasicRow using reflection
                                                                                                                                                                                                                    Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                    getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                                    Integer result = (Integer) getBasicRowMethod.invoke(tableau, 2);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    assertNull(result);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testGetBasicRow_EmptyTableauReturnsNull() throws Exception {
                                                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                                                                                                                                                                                                                    Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Create instance using reflection since constructor is protected
                                                                                                                                                                                                                    Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                    Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                        LinearObjectiveFunction.class, 
                                                                                                                                                                                                                        Collection.class, 
                                                                                                                                                                                                                        GoalType.class, 
                                                                                                                                                                                                                        boolean.class, 
                                                                                                                                                                                                                        double.class
                                                                                                                                                                                                                    );
                                                                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                                                                    Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, 0.0);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Get the protected method using reflection
                                                                                                                                                                                                                    Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                    getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Test the method
                                                                                                                                                                                                                    Integer result = (Integer) getBasicRowMethod.invoke(tableau, 2);
                                                                                                                                                                                                                    assertNull(result);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                            public void testGetBasicRow_FindsSingleOneEntry() throws Exception {
                                                                                                                                                                                                                // Create necessary objects for SimplexTableau constructor
                                                                                                                                                                                                                Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                                                                                                                                                Object f = linearObjectiveFunctionClass.getConstructor(double[].class, double.class)
                                                                                                                                                                                                                        .newInstance(new double[]{1, 1}, 0);
                                                                                                                                                                                                                
                                                                                                                                                                                                                Collection<Object> constraints = new ArrayList<>();
                                                                                                                                                                                                                Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                                                                                                                                                                Object goalType = Enum.valueOf((Class<Enum>)goalTypeClass, "MAXIMIZE");
                                                                                                                                                                                                                double epsilon = 1.0e-6;
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Get the SimplexTableau class and its constructor using reflection
                                                                                                                                                                                                                Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                        linearObjectiveFunctionClass,
                                                                                                                                                                                                                        Collection.class,
                                                                                                                                                                                                                        goalTypeClass,
                                                                                                                                                                                                                        boolean.class,
                                                                                                                                                                                                                        double.class
                                                                                                                                                                                                                );
                                                                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Create actual tableau instance using reflection
                                                                                                                                                                                                                Object tableau = constructor.newInstance(f, constraints, goalType, true, epsilon);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Use reflection to access private getBasicRow method
                                                                                                                                                                                                                Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Setup tableau state (using reflection to set internal state if needed)
                                                                                                                                                                                                                // For this test, we'll assume the tableau is already in the desired state
                                                                                                                                                                                                                // where column 2 has [0.0, 1.0000001, 0.0] in rows 1-3
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Call the method
                                                                                                                                                                                                                Integer result = (Integer) getBasicRowMethod.invoke(tableau, 2);
                                                                                                                                                                                                                
                                                                                                                                                                                                                assertEquals(Integer.valueOf(2), result);
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                            public void testGetBasicRow_LastRowMatches() throws Exception {
                                                                                                                                                                                                                // Create necessary objects for constructor using reflection
                                                                                                                                                                                                                Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                                                                                                                                                Object f = linearObjectiveFunctionClass.getConstructor(double[].class, double.class)
                                                                                                                                                                                                                        .newInstance(new double[]{1, 1}, 0.0);
                                                                                                                                                                                                                
                                                                                                                                                                                                                Collection<Object> constraints = new ArrayList<>();
                                                                                                                                                                                                                
                                                                                                                                                                                                                Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                                                                                                                                                                Object goalType = Enum.valueOf((Class<Enum>)goalTypeClass, "MAXIMIZE");
                                                                                                                                                                                                                
                                                                                                                                                                                                                boolean restrictToNonNegative = true;
                                                                                                                                                                                                                double epsilon = 0.000001;
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Create real tableau instance using reflection
                                                                                                                                                                                                                Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                        linearObjectiveFunctionClass, 
                                                                                                                                                                                                                        Collection.class, 
                                                                                                                                                                                                                        goalTypeClass, 
                                                                                                                                                                                                                        boolean.class, 
                                                                                                                                                                                                                        double.class);
                                                                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                                                                Object tableau = constructor.newInstance(f, constraints, goalType, restrictToNonNegative, epsilon);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Use reflection to set private fields needed for the test
                                                                                                                                                                                                                Field numObjectiveFunctionsField = simplexTableauClass.getDeclaredField("numObjectiveFunctions");
                                                                                                                                                                                                                numObjectiveFunctionsField.setAccessible(true);
                                                                                                                                                                                                                numObjectiveFunctionsField.set(tableau, 1);
                                                                                                                                                                                                                
                                                                                                                                                                                                                Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                                                                                                                                                                                                tableauField.setAccessible(true);
                                                                                                                                                                                                                Class<?> realMatrixImplClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                                                                                                                                                                                                Object matrix = realMatrixImplClass.getConstructor(double[][].class)
                                                                                                                                                                                                                        .newInstance((Object) new double[][]{
                                                                                                                                                                                                                            {0, 0, 0, 0},
                                                                                                                                                                                                                            {0, 0, 0, 0},
                                                                                                                                                                                                                            {0, 0, 0, 0},
                                                                                                                                                                                                                            {0, 0, 0.9999999, 0}
                                                                                                                                                                                                                        });
                                                                                                                                                                                                                tableauField.set(tableau, matrix);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Use reflection to access private method
                                                                                                                                                                                                                Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                                
                                                                                                                                                                                                                Integer result = (Integer) getBasicRowMethod.invoke(tableau, 2);
                                                                                                                                                                                                                assertEquals(Integer.valueOf(3), result);
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                        public void testGetBasicRow_NoOneEntryReturnsNull() throws Exception {
                                                                                                                                                                                                            // Setup test data
                                                                                                                                                                                                            org.apache.commons.math.optimization.linear.LinearObjectiveFunction f = 
                                                                                                                                                                                                                new org.apache.commons.math.optimization.linear.LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                                            Collection<org.apache.commons.math.optimization.linear.LinearConstraint> constraints = 
                                                                                                                                                                                                                new ArrayList<org.apache.commons.math.optimization.linear.LinearConstraint>();
                                                                                                                                                                                                            constraints.add(new org.apache.commons.math.optimization.linear.LinearConstraint(
                                                                                                                                                                                                                new double[]{1, 1}, org.apache.commons.math.optimization.linear.Relationship.LEQ, 1));
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Create real instance using reflection
                                                                                                                                                                                                            Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                            Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                org.apache.commons.math.optimization.linear.LinearObjectiveFunction.class,
                                                                                                                                                                                                                Collection.class,
                                                                                                                                                                                                                org.apache.commons.math.optimization.GoalType.class,
                                                                                                                                                                                                                boolean.class,
                                                                                                                                                                                                                double.class);
                                                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                                                            Object tableau = constructor.newInstance(
                                                                                                                                                                                                                f, 
                                                                                                                                                                                                                constraints, 
                                                                                                                                                                                                                org.apache.commons.math.optimization.GoalType.MAXIMIZE, 
                                                                                                                                                                                                                true, 
                                                                                                                                                                                                                1e-15);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Use reflection to access private method
                                                                                                                                                                                                            Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                            getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test and verify
                                                                                                                                                                                                            Integer result = (Integer) getBasicRowMethod.invoke(tableau, 2);
                                                                                                                                                                                                            assertNull(result);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                public void testCreateTableau_ConstraintRowPositions() throws Exception {
                                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                                                                                                                                                                                                    List<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                    constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 10));
                                                                                                                                                                                                    constraints.add(new LinearConstraint(new double[]{2, 1}, Relationship.GEQ, 5));
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Create test instance using reflection
                                                                                                                                                                                                    Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                    Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                        LinearObjectiveFunction.class, 
                                                                                                                                                                                                        Collection.class, 
                                                                                                                                                                                                        GoalType.class, 
                                                                                                                                                                                                        boolean.class, 
                                                                                                                                                                                                        double.class
                                                                                                                                                                                                    );
                                                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                                                    Object tableau = constructor.newInstance(
                                                                                                                                                                                                        f, 
                                                                                                                                                                                                        constraints, 
                                                                                                                                                                                                        GoalType.MAXIMIZE, 
                                                                                                                                                                                                        true, 
                                                                                                                                                                                                        0.0001
                                                                                                                                                                                                    );
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Execute method under test using reflection
                                                                                                                                                                                                    Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                                                                                                                                                                                                    createTableauMethod.setAccessible(true);
                                                                                                                                                                                                    double[][] result = (double[][]) createTableauMethod.invoke(tableau, true);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Get numObjectiveFunctions using reflection
                                                                                                                                                                                                    Method getNumObjectiveFunctionsMethod = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                                                                                                                                                                                    getNumObjectiveFunctionsMethod.setAccessible(true);
                                                                                                                                                                                                    int numObjectiveFunctions = (int) getNumObjectiveFunctionsMethod.invoke(tableau);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Get slackVariableOffset using reflection
                                                                                                                                                                                                    Method getSlackVariableOffsetMethod = tableauClass.getDeclaredMethod("getSlackVariableOffset");
                                                                                                                                                                                                    getSlackVariableOffsetMethod.setAccessible(true);
                                                                                                                                                                                                    int slackVariableOffset = (int) getSlackVariableOffsetMethod.invoke(tableau);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify constraint rows are placed correctly
                                                                                                                                                                                                    // Check first constraint row position and values
                                                                                                                                                                                                    int firstConstraintRow = numObjectiveFunctions;
                                                                                                                                                                                                    assertEquals(1.0, result[firstConstraintRow][0], 0.0001); // First coefficient
                                                                                                                                                                                                    assertEquals(1.0, result[firstConstraintRow][1], 0.0001); // Second coefficient
                                                                                                                                                                                                    assertEquals(1.0, result[firstConstraintRow][slackVariableOffset], 0.0001); // Slack var
                                                                                                                                                                                                    assertEquals(10.0, result[firstConstraintRow][result[0].length - 1], 0.0001); // RHS
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Check second constraint row position and values
                                                                                                                                                                                                    int secondConstraintRow = numObjectiveFunctions + 1;
                                                                                                                                                                                                    assertEquals(2.0, result[secondConstraintRow][0], 0.0001); // First coefficient
                                                                                                                                                                                                    assertEquals(1.0, result[secondConstraintRow][1], 0.0001); // Second coefficient
                                                                                                                                                                                                    assertEquals(-1.0, result[secondConstraintRow][slackVariableOffset], 0.0001); // Excess var
                                                                                                                                                                                                    assertEquals(5.0, result[secondConstraintRow][result[0].length - 1], 0.0001); // RHS
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify no constraints were incorrectly placed in row 0
                                                                                                                                                                                                    if (numObjectiveFunctions == 1) {
                                                                                                                                                                                                        // If single objective function, row 0 should only have objective coefficients
                                                                                                                                                                                                        assertEquals(-1.0, result[0][0], 0.0001);
                                                                                                                                                                                                    }
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                        public void testGetBasicRowWithStrictCondition() throws Exception {
                                                                                                                                                                                            // Setup test data using reflection
                                                                                                                                                                                            LinearObjectiveFunction f = mock(LinearObjectiveFunction.class);
                                                                                                                                                                                            Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                            
                                                                                                                                                                                            // Get constructor and create instance
                                                                                                                                                                                            Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                            Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                LinearObjectiveFunction.class, 
                                                                                                                                                                                                Collection.class, 
                                                                                                                                                                                                GoalType.class, 
                                                                                                                                                                                                boolean.class, 
                                                                                                                                                                                                double.class
                                                                                                                                                                                            );
                                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                                            Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, 0.001);
                                                                                                                                                                                            
                                                                                                                                                                                            // Create spy using reflection
                                                                                                                                                                                            Object spyTableau = spy(tableau);
                                                                                                                                                                                            
                                                                                                                                                                                            // Case 1: Entry equals 1.0 and row is null (should return true)
                                                                                                                                                                                            when((Double)tableauClass.getDeclaredMethod("getEntry", int.class, int.class)
                                                                                                                                                                                                .invoke(spyTableau, 0, 0)).thenReturn(1.0);
                                                                                                                                                                                            Integer result1 = (Integer)tableauClass.getDeclaredMethod("getBasicRow", int.class)
                                                                                                                                                                                                .invoke(spyTableau, 0);
                                                                                                                                                                                            
                                                                                                                                                                                            // Case 2: Entry equals 1.0 but row is not null (should return false for original)
                                                                                                                                                                                            when((Double)tableauClass.getDeclaredMethod("getEntry", int.class, int.class)
                                                                                                                                                                                                .invoke(spyTableau, 1, 0)).thenReturn(1.0);
                                                                                                                                                                                            tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class)
                                                                                                                                                                                                .invoke(spyTableau, 1, 0, 1.0);
                                                                                                                                                                                            Integer result2 = (Integer)tableauClass.getDeclaredMethod("getBasicRow", int.class)
                                                                                                                                                                                                .invoke(spyTableau, 0);
                                                                                                                                                                                            assertNull("Should not find basic row when row exists", result2);
                                                                                                                                                                                            
                                                                                                                                                                                            // Case 3: Row is null but entry doesn't equal 1.0 (should return false for original)
                                                                                                                                                                                            when((Double)tableauClass.getDeclaredMethod("getEntry", int.class, int.class)
                                                                                                                                                                                                .invoke(spyTableau, 2, 0)).thenReturn(0.5);
                                                                                                                                                                                            Integer result3 = (Integer)tableauClass.getDeclaredMethod("getBasicRow", int.class)
                                                                                                                                                                                                .invoke(spyTableau, 0);
                                                                                                                                                                                            assertNull("Should not find basic row when entry != 1.0", result3);
                                                                                                                                                                                            
                                                                                                                                                                                            // Case 4: Neither condition is true (should return false)
                                                                                                                                                                                            when((Double)tableauClass.getDeclaredMethod("getEntry", int.class, int.class)
                                                                                                                                                                                                .invoke(spyTableau, 3, 0)).thenReturn(0.5);
                                                                                                                                                                                            tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class)
                                                                                                                                                                                                .invoke(spyTableau, 3, 0, 0.5);
                                                                                                                                                                                            Integer result4 = (Integer)tableauClass.getDeclaredMethod("getBasicRow", int.class)
                                                                                                                                                                                                .invoke(spyTableau, 0);
                                                                                                                                                                                            assertNull("Should not find basic row when neither condition is true", result4);
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                public void testCreateTableau_ConstraintRowPositions1() throws Exception {
                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                                                                                                                                                                                    List<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                    constraints.add(new LinearConstraint(new double[]{1, 0}, Relationship.LEQ, 10));
                                                                                                                                                                                    constraints.add(new LinearConstraint(new double[]{0, 1}, Relationship.GEQ, 5));
                                                                                                                                                                                    
                                                                                                                                                                                    // Create SimplexTableau instance using reflection
                                                                                                                                                                                    Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                    Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                        LinearObjectiveFunction.class,
                                                                                                                                                                                        Collection.class,
                                                                                                                                                                                        GoalType.class,
                                                                                                                                                                                        boolean.class,
                                                                                                                                                                                        double.class
                                                                                                                                                                                    );
                                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                                    Object tableau = constructor.newInstance(
                                                                                                                                                                                        f,
                                                                                                                                                                                        constraints,
                                                                                                                                                                                        GoalType.MAXIMIZE,
                                                                                                                                                                                        true,
                                                                                                                                                                                        0.000001
                                                                                                                                                                                    );
                                                                                                                                                                                    
                                                                                                                                                                                    // Call the method under test using reflection
                                                                                                                                                                                    Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                                                                                                                                                                                    createTableauMethod.setAccessible(true);
                                                                                                                                                                                    double[][] matrix = (double[][]) createTableauMethod.invoke(tableau, true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Get numObjectiveFunctions using reflection
                                                                                                                                                                                    Method getNumObjectiveFunctionsMethod = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                                                                                                                                                                    getNumObjectiveFunctionsMethod.setAccessible(true);
                                                                                                                                                                                    int numObjectiveFunctions = (int) getNumObjectiveFunctionsMethod.invoke(tableau);
                                                                                                                                                                                    
                                                                                                                                                                                    // Get slackVariableOffset using reflection
                                                                                                                                                                                    Method getSlackVariableOffsetMethod = tableauClass.getDeclaredMethod("getSlackVariableOffset");
                                                                                                                                                                                    getSlackVariableOffsetMethod.setAccessible(true);
                                                                                                                                                                                    int slackVariableOffset = (int) getSlackVariableOffsetMethod.invoke(tableau);
                                                                                                                                                                                    
                                                                                                                                                                                    // First constraint should be at row numObjectiveFunctions
                                                                                                                                                                                    assertEquals(1.0, matrix[numObjectiveFunctions][0], 0.000001); // coefficient
                                                                                                                                                                                    assertEquals(10.0, matrix[numObjectiveFunctions][matrix[0].length - 1], 0.000001); // RHS
                                                                                                                                                                                    
                                                                                                                                                                                    // Second constraint should be at row numObjectiveFunctions + 1
                                                                                                                                                                                    assertEquals(1.0, matrix[numObjectiveFunctions + 1][1], 0.000001); // coefficient
                                                                                                                                                                                    assertEquals(5.0, matrix[numObjectiveFunctions + 1][matrix[0].length - 1], 0.000001); // RHS
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify slack variables are in correct positions
                                                                                                                                                                                    assertEquals(1.0, matrix[numObjectiveFunctions][slackVariableOffset], 0.000001); // LEQ slack
                                                                                                                                                                                    assertEquals(-1.0, matrix[numObjectiveFunctions + 1][slackVariableOffset + 1], 0.000001); // GEQ excess
                                                                                                                                                                                }

    @Test
                                                                                                                                                                        public void testGetBasicRowWithZeroAndNonZeroEntries() throws Exception {
                                                                                                                                                                            // Setup test data
                                                                                                                                                                            LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                                                                                                                                                                            Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                            constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 10));
                                                                                                                                                                            constraints.add(new LinearConstraint(new double[]{2, 1}, Relationship.GEQ, 5));
                                                                                                                                                                            
                                                                                                                                                                            // Create SimplexTableau instance using reflection
                                                                                                                                                                            Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                            Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                LinearObjectiveFunction.class, 
                                                                                                                                                                                Collection.class, 
                                                                                                                                                                                GoalType.class, 
                                                                                                                                                                                boolean.class, 
                                                                                                                                                                                double.class
                                                                                                                                                                            );
                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                            Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, 1.0e-6);
                                                                                                                                                                            
                                                                                                                                                                            // Get methods using reflection
                                                                                                                                                                            Method setEntry = tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                            Method getBasicRow = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                            Method getHeight = tableauClass.getDeclaredMethod("getHeight");
                                                                                                                                                                            setEntry.setAccessible(true);
                                                                                                                                                                            getBasicRow.setAccessible(true);
                                                                                                                                                                            getHeight.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            // Force specific values in the tableau for testing
                                                                                                                                                                            setEntry.invoke(tableau, 0, 0, 1.0);  // non-zero
                                                                                                                                                                            setEntry.invoke(tableau, 0, 1, 0.0);  // exact zero
                                                                                                                                                                            setEntry.invoke(tableau, 1, 0, 1.0e-7);  // very small (within epsilon)
                                                                                                                                                                            setEntry.invoke(tableau, 1, 1, 2.0);  // non-zero
                                                                                                                                                                            
                                                                                                                                                                            // Test column with non-zero entry
                                                                                                                                                                            int col = 0;
                                                                                                                                                                            Integer basicRow = (Integer) getBasicRow.invoke(tableau, col);
                                                                                                                                                                            assertNotNull("Should find basic row for non-zero column", basicRow);
                                                                                                                                                                            
                                                                                                                                                                            // Test column with exact zero entry
                                                                                                                                                                            col = 1;
                                                                                                                                                                            basicRow = (Integer) getBasicRow.invoke(tableau, col);
                                                                                                                                                                            assertNull("Should not find basic row for zero column", basicRow);
                                                                                                                                                                            
                                                                                                                                                                            // Test column with near-zero entry (within epsilon)
                                                                                                                                                                            col = 0;
                                                                                                                                                                            // Set all other entries in column to zero
                                                                                                                                                                            int height = (Integer) getHeight.invoke(tableau);
                                                                                                                                                                            for (int i = 0; i < height; i++) {
                                                                                                                                                                                if (i != 1) {
                                                                                                                                                                                    setEntry.invoke(tableau, i, col, 0.0);
                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                            basicRow = (Integer) getBasicRow.invoke(tableau, col);
                                                                                                                                                                            assertNull("Should not find basic row for near-zero column (within epsilon)", basicRow);
                                                                                                                                                                            
                                                                                                                                                                            // Test column with mix of zero and non-zero entries
                                                                                                                                                                            col = 0;
                                                                                                                                                                            setEntry.invoke(tableau, 0, col, 1.0);
                                                                                                                                                                            setEntry.invoke(tableau, 1, col, 0.0);
                                                                                                                                                                            basicRow = (Integer) getBasicRow.invoke(tableau, col);
                                                                                                                                                                            assertEquals("Should return first non-zero row", Integer.valueOf(0), basicRow);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                public void testZeroEntryHandling() {
                                                                                                                                                                    // Setup test data
                                                                                                                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                    List<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                    constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 10));
                                                                                                                                                                    
                                                                                                                                                                    try {
                                                                                                                                                                        // Use reflection to access the non-public SimplexTableau class
                                                                                                                                                                        Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                        Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                            LinearObjectiveFunction.class, 
                                                                                                                                                                            Collection.class, 
                                                                                                                                                                            GoalType.class, 
                                                                                                                                                                            boolean.class, 
                                                                                                                                                                            double.class
                                                                                                                                                                        );
                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                        Object tableau = constructor.newInstance(
                                                                                                                                                                            f, 
                                                                                                                                                                            constraints, 
                                                                                                                                                                            GoalType.MAXIMIZE, 
                                                                                                                                                                            true,  // restrictToNonNegative
                                                                                                                                                                            1e-10  // epsilon
                                                                                                                                                                        );
                                                                                                                                                                        
                                                                                                                                                                        // Verify zero entries are properly handled
                                                                                                                                                                        int testRow = 1;
                                                                                                                                                                        int testCol = 0;
                                                                                                                                                                        Method getEntryMethod = tableauClass.getDeclaredMethod("getEntry", int.class, int.class);
                                                                                                                                                                        getEntryMethod.setAccessible(true);
                                                                                                                                                                        double entry = (Double) getEntryMethod.invoke(tableau, testRow, testCol);
                                                                                                                                                                        
                                                                                                                                                                        // Get epsilon value
                                                                                                                                                                        Field epsilonField = tableauClass.getDeclaredField("epsilon");
                                                                                                                                                                        epsilonField.setAccessible(true);
                                                                                                                                                                        double epsilon = (Double) epsilonField.get(tableau);
                                                                                                                                                                        
                                                                                                                                                                        // The entry should be treated as zero (within epsilon)
                                                                                                                                                                        assertTrue(MathUtils.equals(entry, 0.0, epsilon));
                                                                                                                                                                        
                                                                                                                                                                        // Also test the behavior of methods that depend on zero-checking
                                                                                                                                                                        Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                        getBasicRowMethod.setAccessible(true);
                                                                                                                                                                        Integer basicRow = (Integer) getBasicRowMethod.invoke(tableau, testCol);
                                                                                                                                                                        if (basicRow != null) {
                                                                                                                                                                            double basicEntry = (Double) getEntryMethod.invoke(tableau, basicRow, testCol);
                                                                                                                                                                            assertFalse(MathUtils.equals(basicEntry, 0.0, epsilon));
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        // Test with explicit zero value
                                                                                                                                                                        Method setEntryMethod = tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                        setEntryMethod.setAccessible(true);
                                                                                                                                                                        setEntryMethod.invoke(tableau, testRow, testCol, 0.0);
                                                                                                                                                                        entry = (Double) getEntryMethod.invoke(tableau, testRow, testCol);
                                                                                                                                                                        assertTrue(MathUtils.equals(entry, 0.0, epsilon));
                                                                                                                                                                        
                                                                                                                                                                        // Test with very small value (should still be considered zero)
                                                                                                                                                                        setEntryMethod.invoke(tableau, testRow, testCol, 1e-20);
                                                                                                                                                                        entry = (Double) getEntryMethod.invoke(tableau, testRow, testCol);
                                                                                                                                                                        assertTrue(MathUtils.equals(entry, 0.0, epsilon));
                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                        fail("Failed to test SimplexTableau due to reflection error: " + e.getMessage());
                                                                                                                                                                    }
                                                                                                                                                                }

    @Test
                                                                                                                                                        public void testCreateTableauReturnsCorrectMatrixType() throws Exception {
                                                                                                                                                            // Setup test data
                                                                                                                                                            LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                                                                                                                                                            Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                            constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 3));
                                                                                                                                                            
                                                                                                                                                            // Create test instance using reflection
                                                                                                                                                            Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                            Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                LinearObjectiveFunction.class,
                                                                                                                                                                Collection.class,
                                                                                                                                                                GoalType.class,
                                                                                                                                                                boolean.class,
                                                                                                                                                                double.class
                                                                                                                                                            );
                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                            Object tableau = constructor.newInstance(
                                                                                                                                                                f,
                                                                                                                                                                constraints,
                                                                                                                                                                GoalType.MAXIMIZE,
                                                                                                                                                                true,
                                                                                                                                                                0.000001
                                                                                                                                                            );
                                                                                                                                                            
                                                                                                                                                            // Call method under test using reflection
                                                                                                                                                            Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                                                                                                                                                            createTableauMethod.setAccessible(true);
                                                                                                                                                            double[][] result = (double[][]) createTableauMethod.invoke(tableau, true);
                                                                                                                                                            
                                                                                                                                                            // Assertions to catch the mutant
                                                                                                                                                            assertNotNull("Returned matrix should not be null", result);
                                                                                                                                                            assertTrue("Matrix should have positive height", result.length > 0);
                                                                                                                                                            assertTrue("Matrix should have positive width", result[0].length > 0);
                                                                                                                                                            
                                                                                                                                                            // Additional checks to verify basic matrix structure
                                                                                                                                                            assertEquals("First objective row should have -1 in first position", 
                                                                                                                                                                        -1.0, result[0][0], 0.000001);
                                                                                                                                                            assertEquals("Second row should have 1 or -1 in diagonal position",
                                                                                                                                                                        Math.abs(result[1][1]), 1.0, 0.000001);
                                                                                                                                                        }

    @Test
                                                                                                                                                public void testCreateTableauReturnsCorrectMatrixType1() throws Exception {
                                                                                                                                                    // Setup test data
                                                                                                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                                                                                                                                                    Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                    constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 10));
                                                                                                                                                    
                                                                                                                                                    // Create test instance using reflection
                                                                                                                                                    Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                    Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                        LinearObjectiveFunction.class, 
                                                                                                                                                        Collection.class, 
                                                                                                                                                        GoalType.class, 
                                                                                                                                                        boolean.class, 
                                                                                                                                                        double.class
                                                                                                                                                    );
                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                    Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, 0.000001);
                                                                                                                                                    
                                                                                                                                                    // Call method under test using reflection
                                                                                                                                                    Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                                                                                                                                                    createTableauMethod.setAccessible(true);
                                                                                                                                                    double[][] result = (double[][]) createTableauMethod.invoke(tableau, true);
                                                                                                                                                    
                                                                                                                                                    // Assertions to catch the mutant
                                                                                                                                                    assertNotNull("Returned matrix should not be null", result);
                                                                                                                                                    assertTrue("Return type should be double[][]", result instanceof double[][]);
                                                                                                                                                    
                                                                                                                                                    // Verify basic matrix properties
                                                                                                                                                    Method getNumObjectiveFunctions = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                                                                                                                                    getNumObjectiveFunctions.setAccessible(true);
                                                                                                                                                    Method getNumDecisionVariables = tableauClass.getDeclaredMethod("getNumDecisionVariables");
                                                                                                                                                    getNumDecisionVariables.setAccessible(true);
                                                                                                                                                    Method getNumSlackVariables = tableauClass.getDeclaredMethod("getNumSlackVariables");
                                                                                                                                                    getNumSlackVariables.setAccessible(true);
                                                                                                                                                    Method getNumArtificialVariables = tableauClass.getDeclaredMethod("getNumArtificialVariables");
                                                                                                                                                    getNumArtificialVariables.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    int numObjectiveFunctions = (int) getNumObjectiveFunctions.invoke(tableau);
                                                                                                                                                    int expectedHeight = numObjectiveFunctions + constraints.size();
                                                                                                                                                    int expectedWidth = (int) getNumDecisionVariables.invoke(tableau) 
                                                                                                                                                                      + (int) getNumSlackVariables.invoke(tableau)
                                                                                                                                                                      + (int) getNumArtificialVariables.invoke(tableau)
                                                                                                                                                                      + numObjectiveFunctions + 1;
                                                                                                                                                    
                                                                                                                                                    assertEquals("Matrix height should match constraints", expectedHeight, result.length);
                                                                                                                                                    if (result.length > 0) {
                                                                                                                                                        assertEquals("Matrix width should match variables", expectedWidth, result[0].length);
                                                                                                                                                    }
                                                                                                                                                }

    @Test
                                                                                                                                        public void testGetBasicRowWithEpsilonBoundary() throws Exception {
                                                                                                                                            // Setup test data with values near epsilon boundary
                                                                                                                                            double epsilon = 1e-10;
                                                                                                                                            double boundaryValue = 1.0 + epsilon * 1.5; // Between epsilon and 2*epsilon
                                                                                                                                            
                                                                                                                                            // Create mock objects
                                                                                                                                            LinearObjectiveFunction f = mock(LinearObjectiveFunction.class);
                                                                                                                                            Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                            
                                                                                                                                            // Create SimplexTableau instance using reflection
                                                                                                                                            Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                            Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                LinearObjectiveFunction.class, 
                                                                                                                                                Collection.class, 
                                                                                                                                                GoalType.class, 
                                                                                                                                                boolean.class, 
                                                                                                                                                double.class
                                                                                                                                            );
                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                            Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, epsilon);
                                                                                                                                            
                                                                                                                                            // Create spy using reflection
                                                                                                                                            Object spyTableau = spy(tableau);
                                                                                                                                            
                                                                                                                                            // Mock getEntry method
                                                                                                                                            Method getEntryMethod = tableauClass.getDeclaredMethod("getEntry", int.class, int.class);
                                                                                                                                            when(getEntryMethod.invoke(spyTableau, anyInt(), anyInt())).thenReturn(boundaryValue);
                                                                                                                                            
                                                                                                                                            // Test getBasicRow behavior
                                                                                                                                            Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                            getBasicRowMethod.setAccessible(true);
                                                                                                                                            Integer result = (Integer) getBasicRowMethod.invoke(spyTableau, 0);
                                                                                                                                            
                                                                                                                                            // Assertion
                                                                                                                                            assertNull("Should return null for value outside original epsilon tolerance", result);
                                                                                                                                        }

    @Test
                                                                                                                            public void testEntryComparisonWithEpsilon() {
                                                                                                                                // Setup test data with a value that's between epsilon and 2*epsilon
                                                                                                                                double testEpsilon = 1e-10;
                                                                                                                                double testValue = 1.5e-10; // Between epsilon and 2*epsilon
                                                                                                                                
                                                                                                                                // Create a simple optimization problem
                                                                                                                                LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 10));
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    // Get the SimplexTableau class from its package
                                                                                                                                    Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                    
                                                                                                                                    // Get the SimplexTableau constructor
                                                                                                                                    Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                                                                                                        LinearObjectiveFunction.class, 
                                                                                                                                        Collection.class, 
                                                                                                                                        GoalType.class, 
                                                                                                                                        boolean.class, 
                                                                                                                                        double.class);
                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Create the tableau instance
                                                                                                                                    Object tableau = constructor.newInstance(
                                                                                                                                        f, constraints, GoalType.MAXIMIZE, true, testEpsilon);
                                                                                                                                    
                                                                                                                                    // Get the tableau matrix
                                                                                                                                    Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                                                                                                                    tableauField.setAccessible(true);
                                                                                                                                    RealMatrix matrix = (RealMatrix) tableauField.get(tableau);
                                                                                                                                    
                                                                                                                                    // Set a test value at (0,0) that's between epsilon and 2*epsilon
                                                                                                                                    Method setEntryMethod = simplexTableauClass.getDeclaredMethod(
                                                                                                                                        "setEntry", int.class, int.class, double.class);
                                                                                                                                    setEntryMethod.setAccessible(true);
                                                                                                                                    setEntryMethod.invoke(tableau, 0, 0, testValue);
                                                                                                                                    
                                                                                                                                    // Now test the getEntry comparison behavior
                                                                                                                                    Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod(
                                                                                                                                        "getBasicRow", int.class);
                                                                                                                                    getBasicRowMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // The original code should find this row (value > epsilon)
                                                                                                                                    // Mutated code would return null (value < 2*epsilon)
                                                                                                                                    Integer basicRow = (Integer) getBasicRowMethod.invoke(tableau, 0);
                                                                                                                                    
                                                                                                                                    // Assert that the value was properly detected as non-zero
                                                                                                                                    assertNotNull("Entry should be detected as non-zero", basicRow);
                                                                                                                                    assertEquals(0, basicRow.intValue());
                                                                                                                                    
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Reflection failed: " + e.getMessage());
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                    public void testCreateTableau_RowIndexCalculation() throws Exception {
                                                                                                                        // Setup test data
                                                                                                                        LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                                                                                                                        List<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                        constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 10));
                                                                                                                        constraints.add(new LinearConstraint(new double[]{2, 1}, Relationship.GEQ, 5));
                                                                                                                        constraints.add(new LinearConstraint(new double[]{1, 3}, Relationship.EQ, 8));
                                                                                                                        
                                                                                                                        // Create test instance using reflection
                                                                                                                        Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                        Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                            LinearObjectiveFunction.class, 
                                                                                                                            Collection.class, 
                                                                                                                            GoalType.class, 
                                                                                                                            boolean.class, 
                                                                                                                            double.class
                                                                                                                        );
                                                                                                                        constructor.setAccessible(true);
                                                                                                                        Object tableau = constructor.newInstance(
                                                                                                                            f, 
                                                                                                                            constraints, 
                                                                                                                            GoalType.MAXIMIZE, 
                                                                                                                            false, 
                                                                                                                            0.0001
                                                                                                                        );
                                                                                                                        
                                                                                                                        // Get createTableau method
                                                                                                                        Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                                                                                                                        createTableauMethod.setAccessible(true);
                                                                                                                        double[][] result = (double[][]) createTableauMethod.invoke(tableau, true);
                                                                                                                        
                                                                                                                        // Get numObjectiveFunctions method
                                                                                                                        Method getNumObjectiveFunctionsMethod = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                                                                                                        getNumObjectiveFunctionsMethod.setAccessible(true);
                                                                                                                        int numObjectiveFunctions = (int) getNumObjectiveFunctionsMethod.invoke(tableau);
                                                                                                                        
                                                                                                                        // Verify row indices are calculated correctly
                                                                                                                        // For single objective function, constraints should start at row 1
                                                                                                                        // For double objective function, constraints should start at row 2
                                                                                                                        
                                                                                                                        // Check first constraint is in correct row
                                                                                                                        int expectedFirstConstraintRow = numObjectiveFunctions;
                                                                                                                        assertNotEquals("Constraint should not be placed in row 1 when not appropriate", 
                                                                                                                            1, expectedFirstConstraintRow);
                                                                                                                        
                                                                                                                        // Verify constraint coefficients are in correct rows
                                                                                                                        for (int i = 0; i < constraints.size(); i++) {
                                                                                                                            int expectedRow = numObjectiveFunctions + i;
                                                                                                                            double[] constraintRow = result[expectedRow];
                                                                                                                            
                                                                                                                            // Verify some coefficient from the constraint exists in the expected row
                                                                                                                            boolean found = false;
                                                                                                                            for (double val : constraintRow) {
                                                                                                                                if (val == constraints.get(i).getCoefficients().getData()[0] || 
                                                                                                                                    val == constraints.get(i).getCoefficients().getData()[1]) {
                                                                                                                                    found = true;
                                                                                                                                    break;
                                                                                                                                }
                                                                                                                            }
                                                                                                                            assertTrue("Constraint coefficients not found in expected row " + expectedRow, found);
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Verify no ArrayIndexOutOfBoundsException occurred during processing
                                                                                                                        // (implicitly verified by successful completion of createTableau)
                                                                                                                    }

    @Test
                                                                                                            public void testCreateTableauConstraintRowPositions() throws Exception {
                                                                                                                // Setup test data
                                                                                                                LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                                                                                                                List<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 10));
                                                                                                                constraints.add(new LinearConstraint(new double[]{2, 1}, Relationship.GEQ, 5));
                                                                                                                
                                                                                                                // Create SimplexTableau instance using reflection
                                                                                                                Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                    LinearObjectiveFunction.class, 
                                                                                                                    Collection.class, 
                                                                                                                    GoalType.class, 
                                                                                                                    boolean.class, 
                                                                                                                    double.class
                                                                                                                );
                                                                                                                constructor.setAccessible(true);
                                                                                                                Object tableau = constructor.newInstance(
                                                                                                                    f, 
                                                                                                                    constraints, 
                                                                                                                    GoalType.MAXIMIZE, 
                                                                                                                    false, 
                                                                                                                    0.0001
                                                                                                                );
                                                                                                                
                                                                                                                // Call method under test using reflection
                                                                                                                Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                                                                                                                createTableauMethod.setAccessible(true);
                                                                                                                double[][] result = (double[][]) createTableauMethod.invoke(tableau, true);
                                                                                                                
                                                                                                                // Get number of objective functions using reflection
                                                                                                                Method getNumObjFunctionsMethod = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                                                                                                getNumObjFunctionsMethod.setAccessible(true);
                                                                                                                int numObjFunctions = (int) getNumObjFunctionsMethod.invoke(tableau);
                                                                                                                
                                                                                                                // Verify constraint rows are placed correctly
                                                                                                                for (int i = 0; i < constraints.size(); i++) {
                                                                                                                    int expectedRow = numObjFunctions + i;
                                                                                                                    // Check that constraint coefficients appear in the expected row
                                                                                                                    assertNotEquals("First coefficient should not be in row 0", 
                                                                                                                                    0, result[expectedRow][1], 0.0001);
                                                                                                                    // Check RHS value is in correct row
                                                                                                                    assertEquals("Constraint value should be in correct row",
                                                                                                                                constraints.get(i).getValue(),
                                                                                                                                result[expectedRow][result[expectedRow].length - 1],
                                                                                                                                0.0001);
                                                                                                                }
                                                                                                                
                                                                                                                // Verify no constraint data appears in row 0 (unless it's an objective function)
                                                                                                                if (numObjFunctions == 1) {
                                                                                                                    // For single objective function, row 0 should only contain objective data
                                                                                                                    assertEquals("Row 0 should have objective coefficient", 
                                                                                                                                1.0, result[0][0], 0.0001);
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                    public void testCreateTableau_ShouldNotModifyObjectiveRows() throws Exception {
                                                                                                        // Setup test data
                                                                                                        LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 3);
                                                                                                        Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                        constraints.add(new LinearConstraint(new double[]{4, 5}, Relationship.LEQ, 6));
                                                                                                        constraints.add(new LinearConstraint(new double[]{7, 8}, Relationship.GEQ, 9));
                                                                                                        
                                                                                                        // Create test instance using reflection
                                                                                                        Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                        Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                            LinearObjectiveFunction.class, 
                                                                                                            Collection.class, 
                                                                                                            GoalType.class, 
                                                                                                            boolean.class, 
                                                                                                            double.class
                                                                                                        );
                                                                                                        constructor.setAccessible(true);
                                                                                                        Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, 0.001);
                                                                                                        
                                                                                                        // Get original objective row values
                                                                                                        Method getDataMethod = tableauClass.getDeclaredMethod("getData");
                                                                                                        getDataMethod.setAccessible(true);
                                                                                                        double[][] originalMatrix = (double[][]) getDataMethod.invoke(tableau);
                                                                                                        double[] originalObjectiveRow = new double[originalMatrix[0].length];
                                                                                                        System.arraycopy(originalMatrix[0], 0, originalObjectiveRow, 0, originalObjectiveRow.length);
                                                                                                        
                                                                                                        // Force tableau recreation
                                                                                                        Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                                                                                                        createTableauMethod.setAccessible(true);
                                                                                                        double[][] newMatrix = (double[][]) createTableauMethod.invoke(tableau, true);
                                                                                                        double[] newObjectiveRow = new double[newMatrix[0].length];
                                                                                                        System.arraycopy(newMatrix[0], 0, newObjectiveRow, 0, newObjectiveRow.length);
                                                                                                        
                                                                                                        // Verify objective row wasn't modified
                                                                                                        assertArrayEquals("Objective function row should remain unchanged", 
                                                                                                                         originalObjectiveRow, newObjectiveRow, 0.0001);
                                                                                                        
                                                                                                        // Additional check: verify constraint rows were properly processed
                                                                                                        assertEquals("First constraint RHS should be set", 
                                                                                                                    6.0, newMatrix[1][newMatrix[1].length - 1], 0.0001);
                                                                                                        assertEquals("Second constraint RHS should be set", 
                                                                                                                    9.0, newMatrix[2][newMatrix[2].length - 1], 0.0001);
                                                                                                    }

    @Test
                                                                                        public void testGetBasicRowIdentifiesCorrectRow() {
                                                                                            // Setup test data
                                                                                            LinearObjectiveFunction f = mock(LinearObjectiveFunction.class);
                                                                                            when(f.getCoefficients()).thenReturn(mock(RealVector.class));
                                                                                            when(f.getConstantTerm()).thenReturn(0.0);
                                                                                            
                                                                                            LinearConstraint constraint = mock(LinearConstraint.class);
                                                                                            when(constraint.getCoefficients()).thenReturn(mock(RealVector.class));
                                                                                            when(constraint.getRelationship()).thenReturn(Relationship.LEQ);
                                                                                            when(constraint.getValue()).thenReturn(1.0);
                                                                                            
                                                                                            List<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                                                                            constraints.add(constraint);
                                                                                            
                                                                                            // Create tableau using reflection since constructor is not public
                                                                                            Object tableau = null;
                                                                                            try {
                                                                                                Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                    LinearObjectiveFunction.class, 
                                                                                                    Collection.class, 
                                                                                                    GoalType.class, 
                                                                                                    boolean.class, 
                                                                                                    double.class);
                                                                                                constructor.setAccessible(true);
                                                                                                tableau = constructor.newInstance(
                                                                                                    f, constraints, GoalType.MAXIMIZE, true, 0.000001);
                                                                                            } catch (Exception e) {
                                                                                                fail("Failed to create SimplexTableau instance: " + e.getMessage());
                                                                                            }
                                                                                            
                                                                                            // Force a known state where we expect getBasicRow to find a specific row
                                                                                            try {
                                                                                                Method setEntry = tableau.getClass().getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                                                setEntry.setAccessible(true);
                                                                                                setEntry.invoke(tableau, 0, 0, 0.0); // other row
                                                                                                setEntry.invoke(tableau, 1, 0, 1.0); // should be identified as basic row
                                                                                                
                                                                                                // Test getBasicRow - should return row 1 for column 0
                                                                                                Method getBasicRow = tableau.getClass().getDeclaredMethod("getBasicRow", int.class);
                                                                                                getBasicRow.setAccessible(true);
                                                                                                Integer basicRow = (Integer) getBasicRow.invoke(tableau, 0);
                                                                                                
                                                                                                // Verify - this will fail if the mutant is present (comparing to 2.0 instead of 1.0)
                                                                                                assertEquals("Should identify row with value 1.0 as basic row", 
                                                                                                            Integer.valueOf(1), basicRow);
                                                                                                
                                                                                                // Additional verification - no other row should be identified as basic
                                                                                                setEntry.invoke(tableau, 1, 0, 0.0); // clear the basic row
                                                                                                assertNull("No row should be basic when no entry equals 1.0", 
                                                                                                          getBasicRow.invoke(tableau, 0));
                                                                                            } catch (Exception e) {
                                                                                                fail("Failed to invoke methods on SimplexTableau: " + e.getMessage());
                                                                                            }
                                                                                        }

    @Test
                                                                                public void testGetBasicRowFindsCorrectRowWhenEntryEqualsOne() throws Exception {
                                                                                    // Setup test data
                                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                    Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                    constraints.add(new LinearConstraint(new double[]{1, 0}, Relationship.EQ, 1));
                                                                                    
                                                                                    // Create SimplexTableau instance using reflection
                                                                                    Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                    Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                        LinearObjectiveFunction.class, 
                                                                                        Collection.class, 
                                                                                        GoalType.class, 
                                                                                        boolean.class, 
                                                                                        double.class
                                                                                    );
                                                                                    constructor.setAccessible(true);
                                                                                    Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, 1e-15);
                                                                                    
                                                                                    // Set entry using reflection
                                                                                    Method setEntryMethod = tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                                    setEntryMethod.setAccessible(true);
                                                                                    setEntryMethod.invoke(tableau, 1, 0, 1.0);
                                                                                    
                                                                                    // Test getBasicRow using reflection
                                                                                    Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                    getBasicRowMethod.setAccessible(true);
                                                                                    int basicRow = (int) getBasicRowMethod.invoke(tableau, 0);
                                                                                    
                                                                                    // Verify correct row is found
                                                                                    assertEquals("Should find row with entry = 1.0", 1, basicRow);
                                                                                    
                                                                                    // Additional check to ensure it's not returning -1 (not found)
                                                                                    assertNotEquals("Should not return -1 when valid row exists", -1, basicRow);
                                                                                }

    @Test
                                                                        public void testCreateTableau_ConstraintRowCalculation() throws Exception {
                                                                            // Setup test data
                                                                            LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                                                                            List<LinearConstraint> constraints = new ArrayList<>();
                                                                            constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 10));
                                                                            
                                                                            // Create SimplexTableau instance using reflection
                                                                            Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                            Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                LinearObjectiveFunction.class, 
                                                                                Collection.class, 
                                                                                GoalType.class, 
                                                                                boolean.class, 
                                                                                double.class
                                                                            );
                                                                            constructor.setAccessible(true);
                                                                            Object tableau = constructor.newInstance(
                                                                                f, 
                                                                                constraints, 
                                                                                GoalType.MAXIMIZE, 
                                                                                true,  // restrictToNonNegative
                                                                                0.001  // epsilon
                                                                            );
                                                                            
                                                                            // Call the method under test using reflection
                                                                            Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                                                                            createTableauMethod.setAccessible(true);
                                                                            double[][] matrix = (double[][]) createTableauMethod.invoke(tableau, true);
                                                                            
                                                                            // Get numObjectiveFunctions using reflection
                                                                            Method getNumObjectiveFunctionsMethod = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                                                            getNumObjectiveFunctionsMethod.setAccessible(true);
                                                                            int expectedRow = (int) getNumObjectiveFunctionsMethod.invoke(tableau);
                                                                            
                                                                            // Verify constraint was placed in correct row
                                                                            assertEquals(1.0, matrix[expectedRow][0], 0.0001); // Verify first coefficient
                                                                            assertEquals(1.0, matrix[expectedRow][1], 0.0001); // Verify second coefficient
                                                                            assertEquals(10.0, matrix[expectedRow][matrix[expectedRow].length - 1], 0.0001); // Verify RHS
                                                                            
                                                                            // Additional verification for slack variable (since relationship is LEQ)
                                                                            Method getSlackVariableOffsetMethod = tableauClass.getDeclaredMethod("getSlackVariableOffset");
                                                                            getSlackVariableOffsetMethod.setAccessible(true);
                                                                            int slackVarOffset = (int) getSlackVariableOffsetMethod.invoke(tableau);
                                                                            assertEquals(1.0, matrix[expectedRow][slackVarOffset], 0.0001);
                                                                        }

    @Test
                                                                public void testCreateTableauReturnsMatrix() throws Exception {
                                                                    // Setup test data
                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                                                                    List<LinearConstraint> constraints = new ArrayList<>();
                                                                    constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 3));
                                                                    
                                                                    // Create test instance using reflection
                                                                    Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                    Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                        LinearObjectiveFunction.class, 
                                                                        Collection.class, 
                                                                        GoalType.class, 
                                                                        boolean.class, 
                                                                        double.class
                                                                    );
                                                                    constructor.setAccessible(true);
                                                                    Object tableau = constructor.newInstance(
                                                                        f, 
                                                                        constraints, 
                                                                        GoalType.MAXIMIZE, 
                                                                        true, 
                                                                        0.000001
                                                                    );
                                                                    
                                                                    // Call method under test using reflection
                                                                    Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                                                                    createTableauMethod.setAccessible(true);
                                                                    Object result = createTableauMethod.invoke(tableau, true);
                                                                    
                                                                    // Verify return type is double[][]
                                                                    assertTrue("Return value should be a double[][]", result instanceof double[][]);
                                                                    
                                                                    // Verify matrix is not null
                                                                    assertNotNull("Returned matrix should not be null", result);
                                                                    
                                                                    // Verify basic matrix properties
                                                                    double[][] matrix = (double[][]) result;
                                                                    assertTrue("Matrix should have at least one row", matrix.length > 0);
                                                                    assertTrue("Matrix rows should have at least one column", matrix[0].length > 0);
                                                                    
                                                                    // Additional checks to ensure proper matrix construction
                                                                    assertEquals("First objective row should have -1 in first position", 
                                                                                -1.0, matrix[0][0], 0.000001);
                                                                }

    @Test
                                                        public void testCreateTableauReturnsMatrix1() throws Exception {
                                                            // Setup test data
                                                            LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                                                            Collection<LinearConstraint> constraints = new ArrayList<>();
                                                            constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 10));
                                                            constraints.add(new LinearConstraint(new double[]{2, 1}, Relationship.GEQ, 5));
                                                            
                                                            // Create test instance using reflection
                                                            Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                            Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                LinearObjectiveFunction.class, 
                                                                Collection.class, 
                                                                GoalType.class, 
                                                                boolean.class, 
                                                                double.class
                                                            );
                                                            constructor.setAccessible(true);
                                                            Object tableau = constructor.newInstance(
                                                                f, 
                                                                constraints, 
                                                                GoalType.MAXIMIZE, 
                                                                false, 
                                                                0.0001
                                                            );
                                                            
                                                            // Call method under test using reflection
                                                            Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                                                            createTableauMethod.setAccessible(true);
                                                            double[][] result = (double[][]) createTableauMethod.invoke(tableau, true);
                                                            
                                                            // Verify return type and basic properties
                                                            assertNotNull("Returned matrix should not be null", result);
                                                            assertTrue("Return value should be a 2D array", result instanceof double[][]);
                                                            
                                                            // Get necessary values using reflection
                                                            Method getNumObjectiveFunctions = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                                            getNumObjectiveFunctions.setAccessible(true);
                                                            int numObjectiveFunctions = (int) getNumObjectiveFunctions.invoke(tableau);
                                                            
                                                            Method getNumDecisionVariables = tableauClass.getDeclaredMethod("getNumDecisionVariables");
                                                            getNumDecisionVariables.setAccessible(true);
                                                            int numDecisionVariables = (int) getNumDecisionVariables.invoke(tableau);
                                                            
                                                            Method getNumSlackVariables = tableauClass.getDeclaredMethod("getNumSlackVariables");
                                                            getNumSlackVariables.setAccessible(true);
                                                            int numSlackVariables = (int) getNumSlackVariables.invoke(tableau);
                                                            
                                                            Method getNumArtificialVariables = tableauClass.getDeclaredMethod("getNumArtificialVariables");
                                                            getNumArtificialVariables.setAccessible(true);
                                                            int numArtificialVariables = (int) getNumArtificialVariables.invoke(tableau);
                                                            
                                                            // Verify expected dimensions
                                                            int expectedHeight = constraints.size() + numObjectiveFunctions;
                                                            int expectedWidth = numDecisionVariables + numSlackVariables + 
                                                                               numArtificialVariables + numObjectiveFunctions + 1;
                                                            
                                                            assertEquals("Matrix height should match constraints + objective functions", 
                                                                        expectedHeight, result.length);
                                                            if (result.length > 0) {
                                                                assertEquals("Matrix width should match calculated width", 
                                                                            expectedWidth, result[0].length);
                                                            }
                                                            
                                                            // Verify some content (basic sanity checks)
                                                            if (numObjectiveFunctions == 2) {
                                                                assertEquals("First objective function should be -1", -1, result[0][0], 0.0001);
                                                            }
                                                            int zIndex = (numObjectiveFunctions == 1) ? 0 : 1;
                                                            assertEquals("zIndex should be 1 for maximize", 1, result[zIndex][zIndex], 0.0001);
                                                        }

    @Test
                                            public void testGetBasicRowWithEpsilonPrecision() {
                                                // Setup test data with values near 1.0
                                                double epsilon = 1e-10;
                                                double valueJustAbove = 1.0 + epsilon * 1.5; // Within original epsilon*2 but outside original epsilon
                                                
                                                // Create objects needed for SimplexTableau constructor
                                                LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1.0}, 0.0);
                                                Collection<LinearConstraint> constraints = new ArrayList<>();
                                                GoalType goalType = GoalType.MAXIMIZE;
                                                boolean restrictToNonNegative = false;
                                                
                                                // Create SimplexTableau instance using reflection
                                                try {
                                                    // Get the SimplexTableau class
                                                    Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                    
                                                    // Get the constructor
                                                    Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                        LinearObjectiveFunction.class, 
                                                        Collection.class, 
                                                        GoalType.class, 
                                                        boolean.class, 
                                                        double.class
                                                    );
                                                    constructor.setAccessible(true);
                                                    
                                                    // Create instance
                                                    Object tableau = constructor.newInstance(f, constraints, goalType, restrictToNonNegative, epsilon);
                                                    
                                                    // Get the private getBasicRow method
                                                    Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                    getBasicRowMethod.setAccessible(true);
                                                    
                                                    // Get the tableau data field to modify entries
                                                    Field dataField = simplexTableauClass.getDeclaredField("tableau");
                                                    dataField.setAccessible(true);
                                                    Object matrix = dataField.get(tableau);
                                                    
                                                    // Get setEntry method from matrix class
                                                    Method setEntryMethod = matrix.getClass().getMethod("setEntry", int.class, int.class, double.class);
                                                    
                                                    // Set test value in the matrix
                                                    setEntryMethod.invoke(matrix, 0, 0, valueJustAbove);
                                                    
                                                    // This should return null since value isn't exactly 1.0 within epsilon
                                                    Integer result = (Integer) getBasicRowMethod.invoke(tableau, 0);
                                                    assertNull("Should return null for value not exactly 1.0 within epsilon", result);
                                                    
                                                    // Now test with value exactly at 1.0 + epsilon (should be detected with original epsilon)
                                                    setEntryMethod.invoke(matrix, 0, 0, 1.0 + epsilon * 0.9);
                                                    result = (Integer) getBasicRowMethod.invoke(tableau, 0);
                                                    assertNotNull("Should detect value exactly at 1.0 ± epsilon", result);
                                                } catch (Exception e) {
                                                    fail("Reflection failed: " + e.getMessage());
                                                }
                                            }

    @Test
                                    public void testCreateTableauEpsilonComparison() throws Exception {
                                        // Setup test data with values near epsilon threshold
                                        double testEpsilon = 1e-6;
                                        double testValue = testEpsilon * 1.5; // Between original and mutated threshold
                                        
                                        // Create constraints that would produce the test value
                                        LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1.0}, 0.0);
                                        List<LinearConstraint> constraints = new ArrayList<>();
                                        constraints.add(new LinearConstraint(new double[]{testValue}, Relationship.EQ, 0.0));
                                        
                                        // Use reflection to create SimplexTableau instance
                                        Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                        Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                            LinearObjectiveFunction.class, 
                                            Collection.class, 
                                            GoalType.class, 
                                            boolean.class, 
                                            double.class
                                        );
                                        constructor.setAccessible(true);
                                        Object tableau = constructor.newInstance(
                                            f, 
                                            constraints, 
                                            GoalType.MAXIMIZE, 
                                            false, 
                                            testEpsilon
                                        );
                                        
                                        // Get the created matrix using reflection
                                        Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                                        createTableauMethod.setAccessible(true);
                                        double[][] matrix = (double[][]) createTableauMethod.invoke(tableau, true);
                                        
                                        // Verify the constraint row was properly handled
                                        Method getNumObjectiveFunctionsMethod = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                        getNumObjectiveFunctionsMethod.setAccessible(true);
                                        int constraintRow = (int) getNumObjectiveFunctionsMethod.invoke(tableau);
                                        double storedValue = matrix[constraintRow][1]; // coefficient position
                                        
                                        // The original would treat testValue as non-zero (stored as-is)
                                        // The mutant would treat it as zero (wouldn't store it)
                                        assertEquals("Value near epsilon threshold should be stored as-is", 
                                                    testValue, storedValue, 0.0);
                                        
                                        // Also verify artificial variable was added (since EQ constraint)
                                        Method getNumArtificialVariablesMethod = tableauClass.getDeclaredMethod("getNumArtificialVariables");
                                        getNumArtificialVariablesMethod.setAccessible(true);
                                        int numArtificialVariables = (int) getNumArtificialVariablesMethod.invoke(tableau);
                                        assertTrue("Artificial variable should be added for EQ constraint",
                                                   numArtificialVariables > 0);
                                    }

    @Test
                            public void testCreateTableauReturnsNonNullMatrix() throws Exception {
                                // Setup test data
                                LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                                Collection<LinearConstraint> constraints = new ArrayList<>();
                                constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 10));
                                constraints.add(new LinearConstraint(new double[]{2, 1}, Relationship.GEQ, 5));
                                
                                // Create test instance using reflection
                                Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                    LinearObjectiveFunction.class,
                                    Collection.class,
                                    GoalType.class,
                                    boolean.class,
                                    double.class
                                );
                                constructor.setAccessible(true);
                                Object tableau = constructor.newInstance(
                                    f,
                                    constraints,
                                    GoalType.MAXIMIZE,
                                    true,  // restrictToNonNegative
                                    0.001  // epsilon
                                );
                                
                                // Call method under test using reflection
                                Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                                createTableauMethod.setAccessible(true);
                                double[][] result = (double[][]) createTableauMethod.invoke(tableau, true);
                                
                                // Assertions to catch the mutant
                                assertNotNull("Returned matrix should not be null", result);
                                
                                // Verify matrix dimensions are as expected
                                Method getNumObjectiveFunctions = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                getNumObjectiveFunctions.setAccessible(true);
                                Method getNumDecisionVariables = tableauClass.getDeclaredMethod("getNumDecisionVariables");
                                getNumDecisionVariables.setAccessible(true);
                                Method getNumSlackVariables = tableauClass.getDeclaredMethod("getNumSlackVariables");
                                getNumSlackVariables.setAccessible(true);
                                Method getNumArtificialVariables = tableauClass.getDeclaredMethod("getNumArtificialVariables");
                                getNumArtificialVariables.setAccessible(true);
                                
                                int expectedHeight = constraints.size() + (int) getNumObjectiveFunctions.invoke(tableau);
                                int expectedWidth = (int) getNumDecisionVariables.invoke(tableau) + 
                                                   (int) getNumSlackVariables.invoke(tableau) + 
                                                   (int) getNumArtificialVariables.invoke(tableau) + 
                                                   (int) getNumObjectiveFunctions.invoke(tableau) + 1;
                                assertEquals("Matrix height should match constraints + objective functions", 
                                            expectedHeight, result.length);
                                if (result.length > 0) {
                                    assertEquals("Matrix width should match calculated width", 
                                                expectedWidth, result[0].length);
                                }
                            }

    @Test
                    public void testCreateTableau_ConstraintRowPlacement() throws Exception {
                        // Setup test data
                        LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                        List<LinearConstraint> constraints = new ArrayList<>();
                        constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 10));
                        constraints.add(new LinearConstraint(new double[]{2, 1}, Relationship.GEQ, 5));
                        constraints.add(new LinearConstraint(new double[]{1, 3}, Relationship.EQ, 8));
                        
                        // Create SimplexTableau instance using reflection
                        Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                        Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                            LinearObjectiveFunction.class, 
                            Collection.class, 
                            GoalType.class, 
                            boolean.class, 
                            double.class
                        );
                        constructor.setAccessible(true);
                        Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, 1e-6);
                        
                        // Get createTableau method using reflection
                        Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                        createTableauMethod.setAccessible(true);
                        double[][] matrix = (double[][]) createTableauMethod.invoke(tableau, true);
                        
                        // Get numObjectiveFunctions using reflection
                        Method getNumObjectiveFunctionsMethod = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                        getNumObjectiveFunctionsMethod.setAccessible(true);
                        int numObjectiveFunctions = (int) getNumObjectiveFunctionsMethod.invoke(tableau);
                        
                        // Check first constraint row (should be at index numObjectiveFunctions)
                        assertNotEquals(0, matrix[numObjectiveFunctions][0]); // Should have constraint coefficients
                        assertEquals(1.0, matrix[numObjectiveFunctions][0], 1e-6); // First coefficient of first constraint
                        
                        // Check second constraint row (should be at index numObjectiveFunctions + 1)
                        assertNotEquals(0, matrix[numObjectiveFunctions + 1][0]); // Should have constraint coefficients
                        assertEquals(2.0, matrix[numObjectiveFunctions + 1][0], 1e-6); // First coefficient of second constraint
                        
                        // Verify objective function rows remain unchanged
                        if (numObjectiveFunctions == 2) {
                            assertEquals(-1.0, matrix[0][0], 1e-6); // First objective row marker
                        }
                        assertEquals(1.0, matrix[numObjectiveFunctions - 1][numObjectiveFunctions - 1], 1e-6); // Maximize marker
                    }

    @Test
            public void testCreateTableauProcessesAllConstraints() throws Exception {
                // Setup test data
                LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 2}, 0);
                List<LinearConstraint> constraints = new ArrayList<>();
                constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 10));
                constraints.add(new LinearConstraint(new double[]{2, 1}, Relationship.GEQ, 5));
                
                // Create test instance using reflection
                Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                    LinearObjectiveFunction.class, 
                    Collection.class, 
                    GoalType.class, 
                    boolean.class, 
                    double.class
                );
                constructor.setAccessible(true);
                Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, 0.0001);
                
                // Call method under test using reflection
                Method createTableauMethod = tableauClass.getDeclaredMethod("createTableau", boolean.class);
                createTableauMethod.setAccessible(true);
                double[][] result = (double[][]) createTableauMethod.invoke(tableau, true);
                
                // Get necessary methods for verification
                Method getNumObjectiveFunctions = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                getNumObjectiveFunctions.setAccessible(true);
                int numObjectiveFunctions = (int) getNumObjectiveFunctions.invoke(tableau);
                
                Method getSlackVariableOffset = tableauClass.getDeclaredMethod("getSlackVariableOffset");
                getSlackVariableOffset.setAccessible(true);
                int slackVarOffset = (int) getSlackVariableOffset.invoke(tableau);
                
                Method getRhsOffset = tableauClass.getDeclaredMethod("getRhsOffset");
                getRhsOffset.setAccessible(true);
                int rhsOffset = (int) getRhsOffset.invoke(tableau);
                
                // Verify constraints were processed by checking matrix entries
                // Check first constraint row (LEQ)
                assertEquals(1.0, result[numObjectiveFunctions][0], 0.0001);  // x1 coefficient
                assertEquals(1.0, result[numObjectiveFunctions][1], 0.0001);  // x2 coefficient
                assertEquals(1.0, result[numObjectiveFunctions][slackVarOffset], 0.0001);  // slack var
                assertEquals(10.0, result[numObjectiveFunctions][rhsOffset], 0.0001);  // RHS
                
                // Check second constraint row (GEQ)
                assertEquals(2.0, result[numObjectiveFunctions+1][0], 0.0001);  // x1 coefficient
                assertEquals(1.0, result[numObjectiveFunctions+1][1], 0.0001);  // x2 coefficient
                assertEquals(-1.0, result[numObjectiveFunctions+1][slackVarOffset], 0.0001);  // excess var
                assertEquals(5.0, result[numObjectiveFunctions+1][rhsOffset], 0.0001);  // RHS
                
                // Verify artificial variables if needed (for EQ/GEQ constraints)
                Method getNumArtificialVariables = tableauClass.getDeclaredMethod("getNumArtificialVariables");
                getNumArtificialVariables.setAccessible(true);
                int numArtificialVars = (int) getNumArtificialVariables.invoke(tableau);
                
                if (numArtificialVars > 0) {
                    Method getArtificialVariableOffset = tableauClass.getDeclaredMethod("getArtificialVariableOffset");
                    getArtificialVariableOffset.setAccessible(true);
                    int artificialVarOffset = (int) getArtificialVariableOffset.invoke(tableau);
                    assertEquals(1.0, result[0][artificialVarOffset], 0.0001);
                    assertEquals(1.0, result[numObjectiveFunctions+1][artificialVarOffset], 0.0001);
                }
            }

    @Test
    public void testGetBasicRowDetectsPositiveOneEntries() throws Exception {
        // Setup test data
        LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
        Collection<LinearConstraint> constraints = new ArrayList<>();
        constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.EQ, 1));
        
        // Get SimplexTableau constructor via reflection
        Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
        Constructor<?> constructor = tableauClass.getDeclaredConstructor(
            LinearObjectiveFunction.class,
            Collection.class,
            GoalType.class,
            boolean.class,
            double.class
        );
        constructor.setAccessible(true);
        
        // Create tableau using reflection
        Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, 1e-6);
        
        // Get methods via reflection
        Method setEntry = tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
        setEntry.setAccessible(true);
        Method getBasicRow = tableauClass.getDeclaredMethod("getBasicRow", int.class);
        getBasicRow.setAccessible(true);
        
        // Force known values into the tableau
        int testCol = 1;
        int expectedRow = 2;
        setEntry.invoke(tableau, expectedRow, testCol, 1.0);  // Set a 1.0 in known position
        
        // Test that the correct row is found for positive 1.0
        assertEquals("Should find row with 1.0 value", 
                    expectedRow, 
                    getBasicRow.invoke(tableau, testCol));
        
        // Test that no row is found for -1.0 (would catch the mutant)
        setEntry.invoke(tableau, expectedRow, testCol, -1.0);
        assertNull("Should not find row with -1.0 value", 
                   getBasicRow.invoke(tableau, testCol));
        
        // Additional check: verify behavior with multiple entries
        setEntry.invoke(tableau, 0, testCol, -1.0);
        setEntry.invoke(tableau, 1, testCol, 0.5);
        setEntry.invoke(tableau, expectedRow, testCol, 1.0);
        assertEquals("Should still find row with 1.0 value among mixed entries",
                    expectedRow,
                    getBasicRow.invoke(tableau, testCol));
    }


}
