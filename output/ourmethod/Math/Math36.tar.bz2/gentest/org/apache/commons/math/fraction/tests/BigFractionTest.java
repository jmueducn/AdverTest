package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.MathIllegalArgumentException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.ZeroException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.FastMath;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.ArithmeticUtils;
 
public class BigFractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                                                        public void testDoubleValue_NormalFractions() {
                                                                                                                                                            // Test simple fractions
                                                                                                                                                            BigFraction half = new BigFraction(1, 2);
                                                                                                                                                            assertEquals(0.5, half.doubleValue(), 0.0);
                                                                                                                                                            
                                                                                                                                                            BigFraction third = new BigFraction(1, 3);
                                                                                                                                                            assertEquals(1.0/3.0, third.doubleValue(), 0.000000000000001);
                                                                                                                                                            
                                                                                                                                                            BigFraction negative = new BigFraction(-3, 4);
                                                                                                                                                            assertEquals(-0.75, negative.doubleValue(), 0.0);
                                                                                                                                                            
                                                                                                                                                            BigFraction wholeNumber = new BigFraction(5, 1);
                                                                                                                                                            assertEquals(5.0, wholeNumber.doubleValue(), 0.0);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testDoubleValue_ZeroCases() {
                                                                                                                                                            // Test zero numerator
                                                                                                                                                            BigFraction zero = new BigFraction(0, 1);
                                                                                                                                                            assertEquals(0.0, zero.doubleValue(), 0.0);
                                                                                                                                                            
                                                                                                                                                            // Test zero numerator with large denominator
                                                                                                                                                            BigFraction zeroLargeDenom = new BigFraction(BigInteger.ZERO, BigInteger.TEN.pow(100));
                                                                                                                                                            assertEquals(0.0, zeroLargeDenom.doubleValue(), 0.0);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testDoubleValue_VeryLargeNumbers() {
                                                                                                                                                            // Test numbers that would normally overflow but should be handled by the shift logic
                                                                                                                                                            BigInteger hugeNum = BigInteger.TEN.pow(1000);
                                                                                                                                                            BigInteger hugeDen = BigInteger.TEN.pow(999);
                                                                                                                                                            
                                                                                                                                                            BigFraction hugeFraction = new BigFraction(hugeNum, hugeDen);
                                                                                                                                                            assertEquals(10.0, hugeFraction.doubleValue(), 0.000000000000001);
                                                                                                                                                            
                                                                                                                                                            // Test with numbers that are very large but still within double range
                                                                                                                                                            BigInteger largeNum = BigInteger.valueOf(2).pow(1020);
                                                                                                                                                            BigInteger largeDen = BigInteger.valueOf(2).pow(1000);
                                                                                                                                                            BigFraction largeFraction = new BigFraction(largeNum, largeDen);
                                                                                                                                                            assertEquals(Math.pow(2, 20), largeFraction.doubleValue(), 0.0);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testDoubleValue_VerySmallNumbers() {
                                                                                                                                                            // Test very small numbers
                                                                                                                                                            BigInteger tinyNum = BigInteger.ONE;
                                                                                                                                                            BigInteger tinyDen = BigInteger.TEN.pow(100);
                                                                                                                                                            
                                                                                                                                                            BigFraction tinyFraction = new BigFraction(tinyNum, tinyDen);
                                                                                                                                                            assertEquals(0.0, tinyFraction.doubleValue(), 0.0); // Should underflow to 0.0
                                                                                                                                                            
                                                                                                                                                            // Test numbers that are very small but still within double range
                                                                                                                                                            BigInteger smallNum = BigInteger.ONE;
                                                                                                                                                            BigInteger smallDen = BigInteger.valueOf(2).pow(1000);
                                                                                                                                                            BigFraction smallFraction = new BigFraction(smallNum, smallDen);
                                                                                                                                                            assertEquals(Math.pow(2, -1000), smallFraction.doubleValue(), 0.0);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testDoubleValue_EdgeCases() {
                                                                                                                                                            // Test maximum double value
                                                                                                                                                            BigInteger maxDoubleNum = BigInteger.valueOf(2).pow(1023);
                                                                                                                                                            BigInteger maxDoubleDen = BigInteger.ONE;
                                                                                                                                                            BigFraction maxDoubleFraction = new BigFraction(maxDoubleNum, maxDoubleDen);
                                                                                                                                                            assertEquals(Double.MAX_VALUE, maxDoubleFraction.doubleValue(), 0.0);
                                                                                                                                                            
                                                                                                                                                            // Test minimum normal double value
                                                                                                                                                            BigInteger minNormalNum = BigInteger.ONE;
                                                                                                                                                            BigInteger minNormalDen = BigInteger.valueOf(2).pow(1022);
                                                                                                                                                            BigFraction minNormalFraction = new BigFraction(minNormalNum, minNormalDen);
                                                                                                                                                            assertEquals(Double.MIN_NORMAL, minNormalFraction.doubleValue(), 0.0);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testDoubleValue_SpecialConstants() {
                                                                                                                                                            // Test class constants
                                                                                                                                                            assertEquals(1.0, BigFraction.ONE.doubleValue(), 0.0);
                                                                                                                                                            assertEquals(0.0, BigFraction.ZERO.doubleValue(), 0.0);
                                                                                                                                                            assertEquals(-1.0, BigFraction.MINUS_ONE.doubleValue(), 0.0);
                                                                                                                                                            assertEquals(0.5, BigFraction.ONE_HALF.doubleValue(), 0.0);
                                                                                                                                                            assertEquals(0.25, BigFraction.ONE_QUARTER.doubleValue(), 0.0);
                                                                                                                                                            assertEquals(0.2, BigFraction.ONE_FIFTH.doubleValue(), 0.0);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFloatValue_NormalFractions() {
                                                                                                                                                            // Test simple fractions
                                                                                                                                                            BigFraction half = new BigFraction(1, 2);
                                                                                                                                                            assertEquals(0.5f, half.floatValue(), 0.0001f);
                                                                                                                                                            
                                                                                                                                                            BigFraction quarter = new BigFraction(1, 4);
                                                                                                                                                            assertEquals(0.25f, quarter.floatValue(), 0.0001f);
                                                                                                                                                            
                                                                                                                                                            BigFraction threeQuarters = new BigFraction(3, 4);
                                                                                                                                                            assertEquals(0.75f, threeQuarters.floatValue(), 0.0001f);
                                                                                                                                                            
                                                                                                                                                            // Test negative fractions
                                                                                                                                                            BigFraction negativeHalf = new BigFraction(-1, 2);
                                                                                                                                                            assertEquals(-0.5f, negativeHalf.floatValue(), 0.0001f);
                                                                                                                                                            
                                                                                                                                                            // Test whole numbers
                                                                                                                                                            BigFraction five = new BigFraction(5, 1);
                                                                                                                                                            assertEquals(5.0f, five.floatValue(), 0.0001f);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFloatValue_ExtremeValues() {
                                                                                                                                                            // Test with very large numbers that still fit in float range
                                                                                                                                                            BigInteger largeNum = BigInteger.valueOf(2).pow(100);
                                                                                                                                                            BigInteger largeDen = BigInteger.valueOf(2).pow(100).add(BigInteger.ONE);
                                                                                                                                                            BigFraction largeFraction = new BigFraction(largeNum, largeDen);
                                                                                                                                                            assertFalse(Float.isNaN(largeFraction.floatValue()));
                                                                                                                                                            
                                                                                                                                                            // Test with values near Float.MAX_VALUE
                                                                                                                                                            BigInteger nearMaxNum = BigInteger.valueOf(2).pow(120);
                                                                                                                                                            BigInteger nearMaxDen = BigInteger.valueOf(2).pow(20);
                                                                                                                                                            BigFraction nearMaxFraction = new BigFraction(nearMaxNum, nearMaxDen);
                                                                                                                                                            assertEquals(Float.MAX_VALUE, nearMaxFraction.floatValue(), Float.MAX_VALUE * 0.01f);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFloatValue_OutOfRangeValues() {
                                                                                                                                                            // Test with numbers that would normally overflow float range
                                                                                                                                                            BigInteger hugeNum = BigInteger.valueOf(2).pow(200);
                                                                                                                                                            BigInteger hugeDen = BigInteger.valueOf(2).pow(100);
                                                                                                                                                            BigFraction hugeFraction = new BigFraction(hugeNum, hugeDen);
                                                                                                                                                            
                                                                                                                                                            // The method should handle this by shifting and return a valid float
                                                                                                                                                            assertFalse(Float.isNaN(hugeFraction.floatValue()));
                                                                                                                                                            assertTrue(hugeFraction.floatValue() < Float.POSITIVE_INFINITY);
                                                                                                                                                            
                                                                                                                                                            // Test with very small numbers
                                                                                                                                                            BigInteger tinyNum = BigInteger.valueOf(1);
                                                                                                                                                            BigInteger tinyDen = BigInteger.valueOf(2).pow(200);
                                                                                                                                                            BigFraction tinyFraction = new BigFraction(tinyNum, tinyDen);
                                                                                                                                                            assertEquals(0.0f, tinyFraction.floatValue(), 0.0001f);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFloatValue_ZeroAndSpecialCases() {
                                                                                                                                                            // Test zero
                                                                                                                                                            BigFraction zero = new BigFraction(0, 1);
                                                                                                                                                            assertEquals(0.0f, zero.floatValue(), 0.0f);
                                                                                                                                                            
                                                                                                                                                            // Test one
                                                                                                                                                            BigFraction one = new BigFraction(1, 1);
                                                                                                                                                            assertEquals(1.0f, one.floatValue(), 0.0f);
                                                                                                                                                            
                                                                                                                                                            // Test negative one
                                                                                                                                                            BigFraction minusOne = new BigFraction(-1, 1);
                                                                                                                                                            assertEquals(-1.0f, minusOne.floatValue(), 0.0f);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFloatValue_ReducedFractions() {
                                                                                                                                                            // Test that reduction doesn't affect float value
                                                                                                                                                            BigFraction reduced = new BigFraction(2, 4); // Should reduce to 1/2
                                                                                                                                                            assertEquals(0.5f, reduced.floatValue(), 0.0001f);
                                                                                                                                                            
                                                                                                                                                            BigFraction nonReduced = new BigFraction(1, 2);
                                                                                                                                                            assertEquals(reduced.floatValue(), nonReduced.floatValue(), 0.0f);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFloatValue_WithMockedBigIntegers() {
                                                                                                                                                            // Mock numerator and denominator to test the NaN handling path
                                                                                                                                                            BigInteger mockNum = mock(BigInteger.class);
                                                                                                                                                            BigInteger mockDen = mock(BigInteger.class);
                                                                                                                                                            
                                                                                                                                                            when(mockNum.floatValue()).thenReturn(Float.POSITIVE_INFINITY);
                                                                                                                                                            when(mockDen.floatValue()).thenReturn(1.0f);
                                                                                                                                                            when(mockNum.bitLength()).thenReturn(200);
                                                                                                                                                            when(mockDen.bitLength()).thenReturn(100);
                                                                                                                                                            when(mockNum.shiftRight(anyInt())).thenReturn(BigInteger.valueOf(2).pow(100));
                                                                                                                                                            when(mockDen.shiftRight(anyInt())).thenReturn(BigInteger.ONE);
                                                                                                                                                            
                                                                                                                                                            BigFraction fraction = new BigFraction(mockNum, mockDen);
                                                                                                                                                            float result = fraction.floatValue();
                                                                                                                                                            
                                                                                                                                                            assertFalse(Float.isNaN(result));
                                                                                                                                                            verify(mockNum, atLeastOnce()).shiftRight(anyInt());
                                                                                                                                                            verify(mockDen, atLeastOnce()).shiftRight(anyInt());
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testGetReducedFractionWithZeroNumerator() {
                                                                                                                                                        // Test the actual shown method's zero numerator case
                                                                                                                                                        BigFraction result = BigFraction.getReducedFraction(0, 1);
                                                                                                                                                        assertSame(BigFraction.ZERO, result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testGetReducedFractionWithNonZeroNumerator() {
                                                                                                                                                        // Test normal case of the shown method
                                                                                                                                                        BigFraction result = BigFraction.getReducedFraction(1, 2);
                                                                                                                                                        assertEquals(BigInteger.ONE, result.getNumerator());
                                                                                                                                                        assertEquals(BigInteger.valueOf(2), result.getDenominator());
                                                                                                                                                    }

    @Test
                                                                                                                                    public void testConstructorWithNaNShouldThrowException() {
                                                                                                                                        ExpectedException thrown = ExpectedException.none();
                                                                                                                                        thrown.expect(MathIllegalArgumentException.class);
                                                                                                                                        thrown.expectMessage("NaN is not allowed");
                                                                                                                                        
                                                                                                                                        new BigFraction(Double.NaN);
                                                                                                                                    }

    @Test
                                                                                                                            public void testGetReducedFraction() {
                                                                                                                                // Test zero numerator case (should return ZERO)
                                                                                                                                BigFraction zeroFraction = BigFraction.getReducedFraction(0, 1);
                                                                                                                                assertSame(BigFraction.ZERO, zeroFraction);
                                                                                                                                
                                                                                                                                // Test regular fraction case
                                                                                                                                BigFraction half = BigFraction.getReducedFraction(1, 2);
                                                                                                                                assertEquals(BigInteger.valueOf(1), half.getNumerator());
                                                                                                                                assertEquals(BigInteger.valueOf(2), half.getDenominator());
                                                                                                                                
                                                                                                                                // Test reduced fraction case
                                                                                                                                BigFraction reduced = BigFraction.getReducedFraction(2, 4);
                                                                                                                                assertEquals(BigInteger.valueOf(1), reduced.getNumerator());
                                                                                                                                assertEquals(BigInteger.valueOf(2), reduced.getDenominator());
                                                                                                                                
                                                                                                                                // Test negative fraction case
                                                                                                                                BigFraction negative = BigFraction.getReducedFraction(-1, 2);
                                                                                                                                assertEquals(BigInteger.valueOf(-1), negative.getNumerator());
                                                                                                                                assertEquals(BigInteger.valueOf(2), negative.getDenominator());
                                                                                                                                
                                                                                                                                // Test case with denominator zero (should throw exception)
                                                                                                                                try {
                                                                                                                                    BigFraction.getReducedFraction(1, 0);
                                                                                                                                    fail("Expected exception for zero denominator");
                                                                                                                                } catch (ZeroException e) {
                                                                                                                                    // Expected behavior
                                                                                                                                }
                                                                                                                            }

    @Test(expected = MathIllegalArgumentException.class)
                                                                                                                            public void testGetReducedFractionWithNaN() {
                                                                                                                                // Create a NaN value
                                                                                                                                double nanValue = Double.NaN;
                                                                                                                                
                                                                                                                                // This should throw MathIllegalArgumentException for NaN input
                                                                                                                                // The mutant would fail to catch this since it checks for infinity instead
                                                                                                                                new BigFraction(nanValue);
                                                                                                                            }

    @Test
                                                                                                                            public void testGetReducedFractionWithZeroNumerator1() {
                                                                                                                                // Test the zero numerator case
                                                                                                                                BigFraction result = BigFraction.getReducedFraction(0, 1);
                                                                                                                                assertEquals(BigFraction.ZERO, result);
                                                                                                                            }

    @Test
                                                                                                                            public void testGetReducedFractionNormalCase() {
                                                                                                                                // Test normal fraction reduction
                                                                                                                                BigFraction result = BigFraction.getReducedFraction(2, 4);
                                                                                                                                assertEquals(BigInteger.ONE, result.getNumerator());
                                                                                                                                assertEquals(BigInteger.valueOf(2), result.getDenominator());
                                                                                                                            }

    @Test(expected = MathIllegalArgumentException.class)
                                                                                                                            public void testGetReducedFractionWithInfiniteValue() {
                                                                                                                                // Test infinite value case
                                                                                                                                double infiniteValue = Double.POSITIVE_INFINITY;
                                                                                                                                new BigFraction(infiniteValue);
                                                                                                                            }

    @Test
                                                                                                                        public void testGetReducedFractionWithZeroNumerator2() {
                                                                                                                            // Test normal zero case
                                                                                                                            BigFraction result = BigFraction.getReducedFraction(0, 1);
                                                                                                                            assertSame(BigFraction.ZERO, result);
                                                                                                                        }

    @Test
                                                                                                                        public void testGetReducedFractionNormalCase1() {
                                                                                                                            // Test normal non-zero case
                                                                                                                            BigFraction result = BigFraction.getReducedFraction(1, 2);
                                                                                                                            assertEquals(1, result.getNumeratorAsInt());
                                                                                                                            assertEquals(2, result.getDenominatorAsInt());
                                                                                                                        }

    @Test
                                                                                                                public void testGetReducedFractionWithNaN1() {
                                                                                                                    // Setup expectation for NaN case
                                                                                                                    thrown.expect(MathIllegalArgumentException.class);
                                                                                                                    thrown.expectMessage("cannot convert NaN value");
                                                                                                                    
                                                                                                                    // Create a NaN value
                                                                                                                    double nanValue = Double.NaN;
                                                                                                                    
                                                                                                                    // This should throw exception due to NaN check in constructor
                                                                                                                    // The mutant would skip this check and create invalid fraction
                                                                                                                    BigFraction.getReducedFraction((int) nanValue, 1);
                                                                                                                }

    @Test
                                                                                                                public void testGetReducedFractionWithFiniteValue() {
                                                                                                                    // Test with a finite value that should work normally
                                                                                                                    double finiteValue = 0.5;
                                                                                                                    BigFraction fraction = new BigFraction(finiteValue);
                                                                                                                    
                                                                                                                    // Verify the fraction was created correctly
                                                                                                                    assertEquals(BigInteger.ONE, fraction.getNumerator());
                                                                                                                    assertEquals(BigInteger.valueOf(2), fraction.getDenominator());
                                                                                                                }

    @Test
                                                                                                                public void testGetReducedFractionWithZeroNumerator3() {
                                                                                                                    // Test the zero numerator case
                                                                                                                    BigFraction result = BigFraction.getReducedFraction(0, 1);
                                                                                                                    assertEquals(BigFraction.ZERO, result);
                                                                                                                }

    @Test
                                                                                                                public void testGetReducedFractionWithNonZeroNumerator1() {
                                                                                                                    // Test normal fraction reduction
                                                                                                                    BigFraction result = BigFraction.getReducedFraction(2, 4);
                                                                                                                    assertEquals(BigInteger.ONE, result.getNumerator());
                                                                                                                    assertEquals(BigInteger.valueOf(2), result.getDenominator());
                                                                                                                }

    @Test
                                                                                                        public void testGetReducedFractionWithNaN2() {
                                                                                                            // Create a NaN value
                                                                                                            double nanValue = Double.NaN;
                                                                                                            
                                                                                                            try {
                                                                                                                // Try to create a BigFraction with NaN value
                                                                                                                new BigFraction(nanValue);
                                                                                                                fail("Expected MathIllegalArgumentException for NaN value");
                                                                                                            } catch (MathIllegalArgumentException e) {
                                                                                                                // Verify that an exception was thrown
                                                                                                                assertNotNull(e);
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                public void testGetReducedFractionWithNaN3() {
                                                                                                    // Test case that would produce NaN in the original implementation
                                                                                                    // We need to mock or create a scenario where the result would be NaN
                                                                                                    
                                                                                                    // Since the method doesn't directly work with doubles, we need to test through
                                                                                                    // the constructor that takes double values which could produce NaN
                                                                                                    
                                                                                                    try {
                                                                                                        // This should throw an exception due to NaN value
                                                                                                        BigFraction fraction = new BigFraction(Double.NaN);
                                                                                                        fail("Expected MathIllegalArgumentException for NaN value");
                                                                                                    } catch (MathIllegalArgumentException e) {
                                                                                                        // Verify the exception message
                                                                                                        assertEquals("cannot convert NaN value", e.getMessage());
                                                                                                    }
                                                                                                    
                                                                                                    // Test the getReducedFraction method with zero numerator
                                                                                                    BigFraction zeroFraction = BigFraction.getReducedFraction(0, 1);
                                                                                                    assertEquals(BigFraction.ZERO, zeroFraction);
                                                                                                    
                                                                                                    // Test normal fraction
                                                                                                    BigFraction normalFraction = BigFraction.getReducedFraction(1, 2);
                                                                                                    assertEquals(BigInteger.ONE, normalFraction.getNumerator());
                                                                                                    assertEquals(BigInteger.valueOf(2), normalFraction.getDenominator());
                                                                                                    
                                                                                                    // Test that the NaN check is properly implemented in the constructor
                                                                                                    try {
                                                                                                        // This should also throw an exception
                                                                                                        new BigFraction(Double.NaN, 0.0001, 100);
                                                                                                        fail("Expected MathIllegalArgumentException for NaN value with epsilon");
                                                                                                    } catch (MathIllegalArgumentException e) {
                                                                                                        assertEquals("cannot convert NaN value", e.getMessage());
                                                                                                    }
                                                                                                }

    @Test
                                                                                                public void testGetReducedFractionFloatValue() {
                                                                                                    // Create a number where shift left vs right would produce different results
                                                                                                    int numerator = 8;  // 2^3
                                                                                                    int denominator = 1;
                                                                                                    
                                                                                                    // Create the fraction
                                                                                                    BigFraction fraction = BigFraction.getReducedFraction(numerator, denominator);
                                                                                                    
                                                                                                    // Test floatValue() - original would do shiftRight(3) on 8 (which is 1.0)
                                                                                                    // Mutant does shiftLeft(3) on 8 (which is 64.0)
                                                                                                    // We expect the original behavior (1.0)
                                                                                                    assertEquals(1.0f, fraction.floatValue(), 0.0001f);
                                                                                                    
                                                                                                    // Also test with a different value to be thorough
                                                                                                    numerator = 16; // 2^4
                                                                                                    fraction = BigFraction.getReducedFraction(numerator, denominator);
                                                                                                    assertEquals(1.0f, fraction.floatValue(), 0.0001f);
                                                                                                }

    @Test
                                                                                                public void testGetReducedFractionWithZero() {
                                                                                                    // Test the zero case
                                                                                                    BigFraction fraction = BigFraction.getReducedFraction(0, 1);
                                                                                                    assertSame(BigFraction.ZERO, fraction);
                                                                                                }

    @Test
                                                                                    public void testGetReducedFractionWithShiftPrecision() {
                                                                                        // Create a numerator that when shifted right will produce different float vs int results
                                                                                        int numerator = 5; // Binary 101
                                                                                        int denominator = 1;
                                                                                        
                                                                                        // Shift right by 1: 101 >> 1 = 10.1
                                                                                        // floatValue() would preserve the 0.1 part (2.5), intValue() would truncate (2)
                                                                                        BigFraction fraction = BigFraction.getReducedFraction(numerator, denominator);
                                                                                        
                                                                                        // Test floatValue() after operations that might involve shifting
                                                                                        // The original would preserve precision, mutant would lose it
                                                                                        float result = fraction.floatValue();
                                                                                        assertEquals(5.0f, result, 0.0001f);
                                                                                        
                                                                                        // Test with a value that would show the difference more clearly
                                                                                        int largeNumerator = 123456789;
                                                                                        int largeDenominator = 1000;
                                                                                        BigFraction largeFraction = BigFraction.getReducedFraction(largeNumerator, largeDenominator);
                                                                                        
                                                                                        // This would be 123456.789 as float, 123456 as int
                                                                                        float largeResult = largeFraction.floatValue();
                                                                                        assertEquals(123456.789f, largeResult, 0.001f);
                                                                                        
                                                                                        // Additional test case with negative number to check sign handling
                                                                                        int negativeNumerator = -5;
                                                                                        BigFraction negativeFraction = BigFraction.getReducedFraction(negativeNumerator, denominator);
                                                                                        float negativeResult = negativeFraction.floatValue();
                                                                                        assertEquals(-5.0f, negativeResult, 0.0001f);
                                                                                    }

    @Test
                                                                                    public void testGetReducedFractionDetectsBitLengthMutation() {
                                                                                        // Case 1: numerator has larger bit length than denominator
                                                                                        // 17 in binary is 10001 (5 bits), 3 is 11 (2 bits)
                                                                                        BigFraction fraction1 = BigFraction.getReducedFraction(17, 3);
                                                                                        assertEquals(BigInteger.valueOf(17), fraction1.getNumerator());
                                                                                        assertEquals(BigInteger.valueOf(3), fraction1.getDenominator());
                                                                                        
                                                                                        // Case 2: denominator has larger bit length than numerator
                                                                                        // 3 is 11 (2 bits), 17 is 10001 (5 bits)
                                                                                        BigFraction fraction2 = BigFraction.getReducedFraction(3, 17);
                                                                                        assertEquals(BigInteger.valueOf(3), fraction2.getNumerator());
                                                                                        assertEquals(BigInteger.valueOf(17), fraction2.getDenominator());
                                                                                        
                                                                                        // Case 3: both have same bit length
                                                                                        // 5 is 101 (3 bits), 3 is 011 (3 bits)
                                                                                        BigFraction fraction3 = BigFraction.getReducedFraction(5, 3);
                                                                                        assertEquals(BigInteger.valueOf(5), fraction3.getNumerator());
                                                                                        assertEquals(BigInteger.valueOf(3), fraction3.getDenominator());
                                                                                        
                                                                                        // Case 4: large difference in bit lengths
                                                                                        // 1023 is 1111111111 (10 bits), 1 is 1 (1 bit)
                                                                                        BigFraction fraction4 = BigFraction.getReducedFraction(1023, 1);
                                                                                        assertEquals(BigInteger.valueOf(1023), fraction4.getNumerator());
                                                                                        assertEquals(BigInteger.valueOf(1), fraction4.getDenominator());
                                                                                    }

    @Test
                                                                                public void testGetReducedFractionDetectsShiftMutation() {
                                                                                    // Test with values that would involve shift operations in double conversion
                                                                                    // Using large numbers where shift operations would be significant
                                                                                    
                                                                                    // Create a fraction with numerator that would be affected by shift operations
                                                                                    BigInteger numerator = new BigInteger("12345678901234567890");
                                                                                    BigInteger denominator = BigInteger.ONE;
                                                                                    
                                                                                    // Expected value would be numerator divided by 2^shift (if shiftRight was used)
                                                                                    // But with shiftLeft, it would be numerator multiplied by 2^shift
                                                                                    BigFraction fraction = new BigFraction(numerator, denominator);
                                                                                    
                                                                                    // Get the expected value by manually doing shiftRight
                                                                                    int shift = numerator.bitLength() - 1;
                                                                                    double expected = numerator.shiftRight(shift).doubleValue() / denominator.doubleValue();
                                                                                    expected *= Math.scalb(1.0, shift);
                                                                                    
                                                                                    // Compare with actual doubleValue()
                                                                                    assertEquals("Double value should match expected calculation", 
                                                                                                expected, fraction.doubleValue(), 1e-10);
                                                                                    
                                                                                    // Also test with denominator that would require shifting
                                                                                    denominator = new BigInteger("98765432109876543210");
                                                                                    fraction = new BigFraction(numerator, denominator);
                                                                                    
                                                                                    // Calculate expected value with shiftRight
                                                                                    int numShift = numerator.bitLength() - 1;
                                                                                    int denShift = denominator.bitLength() - 1;
                                                                                    double expectedNum = numerator.shiftRight(numShift).doubleValue() * Math.scalb(1.0, numShift);
                                                                                    double expectedDen = denominator.shiftRight(denShift).doubleValue() * Math.scalb(1.0, denShift);
                                                                                    expected = expectedNum / expectedDen;
                                                                                    
                                                                                    assertEquals("Double value with denominator should match", 
                                                                                                expected, fraction.doubleValue(), 1e-10);
                                                                                }

    @Test
                                                                    public void testGetReducedFractionPrecisionWithLargeNumbers() {
                                                                        // Create a very large number that will lose precision when converted to float
                                                                        BigInteger hugeNumerator = new BigInteger("123456789012345678901234567890");
                                                                        BigInteger hugeDenominator = BigInteger.ONE;
                                                                        
                                                                        // Use constructor instead of getReducedFraction since it only accepts int parameters
                                                                        BigFraction fraction = new BigFraction(hugeNumerator, hugeDenominator);
                                                                        
                                                                        // Verify doubleValue maintains precision
                                                                        double doubleVal = fraction.doubleValue();
                                                                        assertEquals(1.2345678901234568E29, doubleVal, 0.0);
                                                                        
                                                                        // Verify floatValue loses precision (this would catch the mutant)
                                                                        float floatVal = fraction.floatValue();
                                                                        assertNotEquals((float)1.2345678901234568E29, floatVal, 0.0);
                                                                        
                                                                        // The actual float value would be different due to precision loss
                                                                        assertEquals(1.2345679E29f, floatVal, 0.0);
                                                                    }

    @Test
                                                                    public void testGetReducedFractionWithZeroNumerator4() {
                                                                        BigFraction fraction = BigFraction.getReducedFraction(0, 10);
                                                                        assertSame(BigFraction.ZERO, fraction);
                                                                    }

    @Test
                                                                    public void testGetReducedFractionWithRegularNumbers() {
                                                                        BigInteger numerator = BigInteger.valueOf(6);
                                                                        BigInteger denominator = BigInteger.valueOf(8);
                                                                        
                                                                        BigFraction fraction = BigFraction.getReducedFraction(numerator.intValue(), denominator.intValue());
                                                                        
                                                                        assertEquals(3, fraction.getNumerator().intValue());
                                                                        assertEquals(4, fraction.getDenominator().intValue());
                                                                    }

    @Test
                                                                    public void testGetReducedFractionWithZeroNumerator5() {
                                                                        BigFraction zeroFraction = BigFraction.getReducedFraction(0, 1);
                                                                        assertEquals(BigFraction.ZERO, zeroFraction);
                                                                    }

    @Test
                                                            public void testGetReducedFractionWithDifferentBitLengths() {
                                                                // Test case where numerator has larger bit length than denominator
                                                                BigInteger bigNum = new BigInteger("123456789012345678901234567890");
                                                                BigInteger smallDen = BigInteger.valueOf(5);
                                                                BigFraction fraction1 = new BigFraction(bigNum, smallDen);
                                                                assertEquals(bigNum, fraction1.getNumerator());
                                                                assertEquals(smallDen, fraction1.getDenominator());
                                                                
                                                                // Test case where denominator has larger bit length than numerator
                                                                BigInteger smallNum = BigInteger.valueOf(3);
                                                                BigInteger bigDen = new BigInteger("987654321098765432109876543210");
                                                                BigFraction fraction2 = new BigFraction(smallNum, bigDen);
                                                                assertEquals(smallNum, fraction2.getNumerator());
                                                                assertEquals(bigDen, fraction2.getDenominator());
                                                                
                                                                // Test case where both have same bit length
                                                                BigInteger num = new BigInteger("12345");
                                                                BigInteger den = new BigInteger("67890");
                                                                BigFraction fraction3 = new BigFraction(num, den);
                                                                assertEquals(num, fraction3.getNumerator());
                                                                assertEquals(den, fraction3.getDenominator());
                                                            }

    @Test
                                                            public void testGetReducedFractionWithNaN4() {
                                                                // Create a scenario that would produce NaN
                                                                // Using Double.NaN as input to constructor which would then check isNaN
                                                                try {
                                                                    BigFraction fraction = new BigFraction(Double.NaN);
                                                                    // If we get here, the NaN check was skipped (mutant survived)
                                                                    fail("Expected MathIllegalArgumentException for NaN input");
                                                                } catch (MathIllegalArgumentException e) {
                                                                    // This is the expected behavior - original code would throw
                                                                    assertEquals(LocalizedFormats.NAN_VALUE_CONVERSION, e.getLocalizedMessage());
                                                                }
                                                                
                                                                // Also test with infinity which should similarly be checked
                                                                try {
                                                                    BigFraction fraction = new BigFraction(Double.POSITIVE_INFINITY);
                                                                    fail("Expected MathIllegalArgumentException for infinite input");
                                                                } catch (MathIllegalArgumentException e) {
                                                                    assertEquals(LocalizedFormats.INFINITE_VALUE_CONVERSION, e.getLocalizedMessage());
                                                                }
                                                            }

    @Test
                                                        public void testGetReducedFractionNormalCase2() {
                                                            // Additional test for normal case to ensure basic functionality
                                                            BigFraction result = BigFraction.getReducedFraction(1, 2);
                                                            assertEquals(1, result.getNumeratorAsInt());
                                                            assertEquals(2, result.getDenominatorAsInt());
                                                        }

    @Test
                                                        public void testGetReducedFractionZeroNumerator() {
                                                            // Test zero numerator case
                                                            BigFraction result = BigFraction.getReducedFraction(0, 1);
                                                            assertSame(BigFraction.ZERO, result);
                                                        }

    @Test(expected = MathIllegalArgumentException.class)
                                                public void testGetReducedFractionWithNaN5() {
                                                    // This test will fail if the mutant is present because:
                                                    // Original code would throw exception for NaN input
                                                    // Mutated code (with if(true)) would bypass the check
                                                    
                                                    // Create fraction with numerator that would represent NaN if interpreted as double bits
                                                    // In IEEE 754, any float with exponent 0x7ff is NaN
                                                    int nanBits = 0x7ff80000;
                                                    
                                                    // Try to create fraction from NaN-like bits
                                                    // This should throw MathIllegalArgumentException in original code
                                                    // But would pass with the mutant
                                                    BigFraction.getReducedFraction(nanBits, 1);
                                                }

    @Test
                                                public void testGetReducedFractionWithZeroNumerator6() {
                                                    // Test the basic zero numerator case
                                                    BigFraction result = BigFraction.getReducedFraction(0, 1);
                                                    assertEquals(BigFraction.ZERO, result);
                                                }

    @Test
                                                public void testGetReducedFractionWithNormalValues() {
                                                    // Test normal fraction reduction
                                                    BigFraction result = BigFraction.getReducedFraction(2, 4);
                                                    assertEquals(BigInteger.ONE, result.getNumerator());
                                                    assertEquals(BigInteger.valueOf(2), result.getDenominator());
                                                }

    @Test(expected = MathIllegalArgumentException.class)
                                                public void testGetReducedFractionWithNaN6() {
                                                    // This would catch the mutation if it's in the constructor
                                                    // by verifying NaN values are still properly rejected
                                                    new BigFraction(Double.NaN);
                                                }

    @Test(expected = MathIllegalArgumentException.class)
                                                public void testGetReducedFractionWithPositiveInfinity() {
                                                    // This tests the infinite case handling
                                                    new BigFraction(Double.POSITIVE_INFINITY);
                                                }

    @Test(expected = MathIllegalArgumentException.class)
                                                public void testGetReducedFractionWithNegativeInfinity() {
                                                    // This tests the infinite case handling
                                                    new BigFraction(Double.NEGATIVE_INFINITY);
                                                }

    @Test
                                                public void testGetReducedFractionEdgeCases() {
                                                    // Test edge cases that might trigger the mutation
                                                    BigFraction result = BigFraction.getReducedFraction(Integer.MIN_VALUE, 1);
                                                    assertEquals(BigInteger.valueOf(Integer.MIN_VALUE), result.getNumerator());
                                                    assertEquals(BigInteger.ONE, result.getDenominator());
                                                }

    @Test
                                            public void testGetReducedFractionWithNaN7() {
                                                // Test case to detect the NaN handling mutant
                                                try {
                                                    // Create a NaN value
                                                    double nanValue = Double.NaN;
                                                    
                                                    // Try to create a BigFraction with NaN
                                                    new BigFraction(nanValue);
                                                    
                                                    // If we get here, the mutant survived (should have thrown exception)
                                                    fail("Expected MathIllegalArgumentException for NaN value");
                                                } catch (MathIllegalArgumentException e) {
                                                    // This is the expected behavior - original code would throw for NaN
                                                    assertEquals(LocalizedFormats.NAN_VALUE_CONVERSION, e.getLocalizedMessage());
                                                }
                                            }

    @Test
                                            public void testGetReducedFractionWithValidDouble() {
                                                // Test with valid double value to ensure normal case works
                                                double validValue = 1.5;
                                                BigFraction fraction = new BigFraction(validValue);
                                                
                                                // Verify the fraction was created correctly
                                                assertEquals(BigInteger.valueOf(3), fraction.getNumerator());
                                                assertEquals(BigInteger.valueOf(2), fraction.getDenominator());
                                            }

    @Test
                                            public void testGetReducedFractionWithZeroNumerator7() {
                                                // Test the zero numerator case
                                                BigFraction result = BigFraction.getReducedFraction(0, 1);
                                                assertEquals(BigFraction.ZERO, result);
                                            }

    @Test
                                            public void testGetReducedFractionNormalCase3() {
                                                // Test normal fraction reduction
                                                BigFraction result = BigFraction.getReducedFraction(2, 4);
                                                assertEquals(BigInteger.ONE, result.getNumerator());
                                                assertEquals(BigInteger.valueOf(2), result.getDenominator());
                                            }

    @Test(expected = MathIllegalArgumentException.class)
                                        public void testGetReducedFractionWithNaN8() {
                                            // Create a NaN value
                                            double nanValue = Double.NaN;
                                            
                                            // Try to create a BigFraction with NaN
                                            // This should throw MathIllegalArgumentException
                                            new BigFraction(nanValue);
                                        }

    @Test
                                        public void testGetReducedFractionWithZeroNumerator8() {
                                            // Test the zero numerator case
                                            BigFraction result = BigFraction.getReducedFraction(0, 1);
                                            assertEquals(BigFraction.ZERO, result);
                                        }

    @Test
                                        public void testGetReducedFractionNormalCase4() {
                                            // Test normal fraction reduction
                                            BigFraction result = BigFraction.getReducedFraction(2, 4);
                                            assertEquals(BigInteger.ONE, result.getNumerator());
                                            assertEquals(BigInteger.valueOf(2), result.getDenominator());
                                        }

    @Test(expected = MathIllegalArgumentException.class)
                                    public void testGetReducedFractionWithNaN9() {
                                        // This test will fail if the mutant is present because:
                                        // - Original code explicitly checks Double.isNaN() and throws exception
                                        // - Mutant code (result != result) might not catch all NaN cases
                                        // - We're testing with a value that should always throw for NaN
                                        double nanValue = Double.NaN;
                                        
                                        // Try to create fraction with NaN - should throw
                                        BigFraction.getReducedFraction(
                                            (int)(nanValue * 10),  // Force NaN to int conversion
                                            10
                                        );
                                    }

    @Test
                                    public void testGetReducedFractionWithZeroNumerator9() {
                                        // Normal case that should work with both original and mutant
                                        BigFraction result = BigFraction.getReducedFraction(0, 1);
                                        assertEquals(BigFraction.ZERO, result);
                                    }

    @Test
                                    public void testGetReducedFractionNormalCase5() {
                                        // Another normal case
                                        BigFraction result = BigFraction.getReducedFraction(1, 2);
                                        assertEquals(new BigFraction(1, 2), result);
                                    }

    @Test
                                public void testGetReducedFractionFloatValue1() {
                                    // Create a fraction where numerator would be affected by shifting
                                    // Using 8 as numerator (binary 1000) and 2 as denominator
                                    BigFraction fraction = BigFraction.getReducedFraction(8, 2);
                                    
                                    // Calculate expected float value (8/2 = 4.0)
                                    float expected = 4.0f;
                                    
                                    // The mutation would calculate this as:
                                    // numerator.shiftLeft(shift) would multiply 8 by 2^shift
                                    // So instead of getting 4.0, we'd get a much larger number
                                    
                                    // Verify the actual float value matches expected
                                    assertEquals("Float value should match expected calculation", 
                                                 expected, fraction.floatValue(), 0.0001f);
                                    
                                    // Additional test with negative number to ensure sign handling
                                    BigFraction negativeFraction = BigFraction.getReducedFraction(-8, 2);
                                    assertEquals("Negative float value should match", 
                                                 -4.0f, negativeFraction.floatValue(), 0.0001f);
                                }

    @Test
                                public void testZeroNumeratorReturnsZeroInstance() {
                                    // Verify that numerator 0 returns the ZERO instance
                                    BigFraction zeroFraction = BigFraction.getReducedFraction(0, 1);
                                    assertSame("Zero numerator should return ZERO instance",
                                              BigFraction.ZERO, zeroFraction);
                                }

    @Test
                            public void testGetReducedFractionFloatPrecision() {
                                // Create a number that when shifted right will produce a fractional float value
                                BigInteger numerator = new BigInteger("5"); // Binary 101
                                BigInteger denominator = BigInteger.ONE;
                                
                                // Shift right by 1: 101 >> 1 = 10.1 in binary = 2.5 in decimal
                                // floatValue() should preserve the 0.5, intValue() would truncate to 2
                                BigFraction fraction = new BigFraction(numerator, denominator);
                                
                                // The mutation would affect floatValue() by losing precision
                                assertEquals(2.5f, fraction.floatValue(), 0.0001f);
                                
                                // Also test with a larger number to ensure the behavior is consistent
                                BigInteger largeNumerator = new BigInteger("123456789");
                                BigFraction largeFraction = new BigFraction(largeNumerator, BigInteger.ONE);
                                // Calculate expected float value (original behavior)
                                float expected = largeNumerator.shiftRight(1).floatValue();
                                assertEquals(expected, largeFraction.floatValue(), 0.0001f);
                            }

    @Test
                        public void testGetReducedFractionDetectsBitLengthMutant() {
                            // Test case where numerator and denominator have different bit lengths
                            // This should expose the Math.max -> Math.min mutation
                            
                            // Create a fraction where numerator has more bits than denominator
                            BigInteger num = new BigInteger("12345678901234567890"); // 64 bits
                            BigInteger den = BigInteger.valueOf(5); // 3 bits
                            
                            // Original behavior (using Math.max) would use numerator's bit length (64)
                            // Mutant behavior (using Math.min) would use denominator's bit length (3)
                            // This difference should be detectable in the reduced fraction
                            
                            BigFraction fraction = new BigFraction(num, den);
                            BigFraction reduced = BigFraction.getReducedFraction(num.intValue(), den.intValue());
                            
                            // Verify numerator and denominator are properly reduced
                            assertEquals("Numerator should match", num, reduced.getNumerator());
                            assertEquals("Denominator should match", den, reduced.getDenominator());
                            
                            // Verify the fraction is indeed reduced (GCD should be 1)
                            assertEquals(BigInteger.ONE, 
                                       reduced.getNumerator().gcd(reduced.getDenominator()));
                            
                            // Verify the actual value is correct
                            assertEquals(0, fraction.compareTo(reduced));
                        }

    @Test
                    public void testDoubleValueWithShiftOperations() {
                        // Create a BigFraction with numerator that's a power of 2 (8)
                        BigFraction fraction = new BigFraction(8, 1);
                        
                        // With shiftRight(1), 8 should become 4 (8 / 2)
                        double expectedRightShift = 4.0;
                        
                        // With shiftLeft(1), 8 should become 16 (8 * 2)
                        double expectedLeftShift = 16.0;
                        
                        // Get the actual double value
                        double actualValue = fraction.doubleValue();
                        
                        // The original implementation uses shiftRight, so we expect 4.0
                        // The mutant using shiftLeft would produce 16.0
                        // This assertion will fail if the mutant is present
                        assertEquals("Double value should reflect right-shift operation", 
                                    expectedRightShift, actualValue, 0.0001);
                        
                        // Additional check to ensure it's not the mutated version
                        assertNotEquals("Double value should not match left-shift result", 
                                      expectedLeftShift, actualValue, 0.0001);
                    }

    @Test
        public void testGetReducedFractionPrecision() {
            // Create a very large number that would show precision differences
            // between float and double conversion
            long hugeNumerator = 1234567890123456789L;
            long hugeDenominator = 1L;
            
            // Create expected value using double conversion
            double expectedValue = hugeNumerator;
            
            // Create BigFraction instance
            BigFraction fraction = BigFraction.getReducedFraction((int)hugeNumerator, (int)hugeDenominator);
            
            // Verify the doubleValue() matches expected double conversion
            assertEquals("Double value should match precise conversion", 
                        expectedValue, 
                        fraction.doubleValue(), 
                        0.000001);
            
            // The mutation would fail here because floatValue() would lose precision
            // compared to the original doubleValue() implementation
            double actualValue = fraction.doubleValue();
            assertNotEquals("Float conversion would differ for large numbers",
                          (float)expectedValue,
                          actualValue,
                          0.000001);
        }

    @Test
        public void testGetReducedFractionWithZeroNumerator10() {
            // Test the zero numerator case
            BigFraction fraction = BigFraction.getReducedFraction(0, 1);
            assertSame("Zero numerator should return ZERO instance",
                      BigFraction.ZERO,
                      fraction);
        }

    @Test
        public void testGetReducedFractionNormalCase6() {
            // Test normal fraction reduction
            BigFraction fraction = BigFraction.getReducedFraction(4, 8);
            
            assertEquals("Numerator should be reduced", 
                        BigInteger.ONE, 
                        fraction.getNumerator());
            assertEquals("Denominator should be reduced",
                        BigInteger.valueOf(2),
                        fraction.getDenominator());
        }

    @Test
        public void testGetReducedFractionDetectsBitLengthMutant1() {
            // Test case where numerator and denominator have different bit lengths
            // This should reveal if Math.max was mutated to Math.min
            
            // 255/256 - numbers with different bit lengths (8 vs 9)
            BigFraction fraction = BigFraction.getReducedFraction(255, 256);
            
            // Verify the fraction is properly reduced (should be same as input since no common divisors)
            assertEquals(BigInteger.valueOf(255), fraction.getNumerator());
            assertEquals(BigInteger.valueOf(256), fraction.getDenominator());
            
            // 510/512 - should reduce to 255/256
            BigFraction fraction2 = BigFraction.getReducedFraction(510, 512);
            assertEquals(BigInteger.valueOf(255), fraction2.getNumerator());
            assertEquals(BigInteger.valueOf(256), fraction2.getDenominator());
            
            // 1023/1024 - large numbers with different bit lengths (10 vs 11)
            BigFraction fraction3 = BigFraction.getReducedFraction(1023, 1024);
            assertEquals(BigInteger.valueOf(1023), fraction3.getNumerator());
            assertEquals(BigInteger.valueOf(1024), fraction3.getDenominator());
            
            // Edge case with very different bit lengths
            // 1/32768 (1 vs 16 bits)
            BigFraction fraction4 = BigFraction.getReducedFraction(1, 32768);
            assertEquals(BigInteger.ONE, fraction4.getNumerator());
            assertEquals(BigInteger.valueOf(32768), fraction4.getDenominator());
        }

    @Test
        public void testGetReducedFractionWithZeroNumerator11() {
            // Verify zero case works correctly
            BigFraction zeroFraction = BigFraction.getReducedFraction(0, 1);
            assertSame(BigFraction.ZERO, zeroFraction);
        }

}
