package gentest.org.apache.commons.math3.dfp.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.dfp.*;
import java.util.Arrays;
import org.apache.commons.math3.FieldElement;
 
public class DfpTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                    public void testMultiply_OutsideRadixRange() throws Exception {
                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                                                                                                        when(field.getRadixDigits()).thenReturn(10); // Assuming 10 radix digits
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Create Dfp instances using protected constructor through reflection
                                                                                                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                                                        Dfp dfp = constructor.newInstance(field, 5); // Create Dfp with value 5
                                                                                                                                                                                                        Dfp expectedResult = constructor.newInstance(field, 20);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Use reflection to set RADIX since it's final
                                                                                                                                                                                                        Field radixField = Dfp.class.getDeclaredField("RADIX");
                                                                                                                                                                                                        radixField.setAccessible(true);
                                                                                                                                                                                                        radixField.setInt(null, 16); // Set RADIX to 16 for this test
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Mock the newInstance and regular multiply methods
                                                                                                                                                                                                        Dfp spyDfp = spy(dfp);
                                                                                                                                                                                                        Dfp mockDfp = mock(Dfp.class);
                                                                                                                                                                                                        
                                                                                                                                                                                                        doReturn(mockDfp).when(spyDfp).newInstance(17);
                                                                                                                                                                                                        doReturn(expectedResult).when(spyDfp).multiply(mockDfp);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test with x=17 (outside RADIX range)
                                                                                                                                                                                                        Dfp result = spyDfp.multiply(17);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                        assertEquals(expectedResult, result);
                                                                                                                                                                                                        verify(spyDfp).newInstance(17);
                                                                                                                                                                                                        verify(spyDfp).multiply(mockDfp);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Can't verify multiplyFast since it's private
                                                                                                                                                                                                        // Instead verify that regular multiply was called
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                public void testMultiply_ExactlyRadix() {
                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                    DfpField field = mock(DfpField.class);
                                                                                                                                                                                                    when(field.getRadixDigits()).thenReturn(10);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Create Dfp instance using accessible constructor
                                                                                                                                                                                                    Dfp dfp = null;
                                                                                                                                                                                                    try {
                                                                                                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                                                        dfp = constructor.newInstance(field, 5);
                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                        fail("Failed to create Dfp instance");
                                                                                                                                                                                                    }
                                                                                                                                                                                                    
                                                                                                                                                                                                    try {
                                                                                                                                                                                                        // Use reflection to set RADIX since it's final
                                                                                                                                                                                                        Field radixField = Dfp.class.getDeclaredField("RADIX");
                                                                                                                                                                                                        radixField.setAccessible(true);
                                                                                                                                                                                                        Field modifiersField = Field.class.getDeclaredField("modifiers");
                                                                                                                                                                                                        modifiersField.setAccessible(true);
                                                                                                                                                                                                        modifiersField.setInt(radixField, radixField.getModifiers() & ~Modifier.FINAL);
                                                                                                                                                                                                        radixField.set(null, 16);
                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                        fail("Failed to set RADIX value");
                                                                                                                                                                                                    }
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Mock the newInstance and regular multiply methods
                                                                                                                                                                                                    Dfp spyDfp = spy(dfp);
                                                                                                                                                                                                    Dfp mockDfp = mock(Dfp.class);
                                                                                                                                                                                                    Dfp expectedResult = null;
                                                                                                                                                                                                    try {
                                                                                                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                                                        expectedResult = constructor.newInstance(field, 5 * 16);
                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                        fail("Failed to create expectedResult Dfp instance");
                                                                                                                                                                                                    }
                                                                                                                                                                                                    
                                                                                                                                                                                                    doReturn(mockDfp).when(spyDfp).newInstance(16);
                                                                                                                                                                                                    doReturn(expectedResult).when(spyDfp).multiply(mockDfp);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Test with x=16 (RADIX)
                                                                                                                                                                                                    Dfp result = spyDfp.multiply(16);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                    assertEquals(expectedResult, result);
                                                                                                                                                                                                    verify(spyDfp).newInstance(16);
                                                                                                                                                                                                    verify(spyDfp).multiply(mockDfp);
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testMultiply_DifferentRadixDigits_ReturnsQNaN() {
                                                                                                                                                                                                    // Create main field and dfp instance
                                                                                                                                                                                                    DfpField field = new DfpField(10); // assuming 10 radix digits for main field
                                                                                                                                                                                                    Dfp dfp = field.newDfp(0); // create finite dfp
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Create different radix field and dfp
                                                                                                                                                                                                    DfpField otherField = new DfpField(5); // different radix digits
                                                                                                                                                                                                    Dfp differentRadixDfp = otherField.newDfp(0);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Set up test conditions
                                                                                                                                                                                                    try {
                                                                                                                                                                                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                        nansField.setAccessible(true);
                                                                                                                                                                                                        nansField.set(dfp, Dfp.FINITE);
                                                                                                                                                                                                        
                                                                                                                                                                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                        mantField.setAccessible(true);
                                                                                                                                                                                                        mantField.set(dfp, new int[]{1, 2, 3, 4});
                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                        fail("Failed to set up test conditions via reflection");
                                                                                                                                                                                                    }
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Perform operation
                                                                                                                                                                                                    Dfp result = dfp.multiply(differentRadixDfp);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify results
                                                                                                                                                                                                    assertEquals(Dfp.QNAN, result.classify());
                                                                                                                                                                                                    
                                                                                                                                                                                                    try {
                                                                                                                                                                                                        Field flagsField = DfpField.class.getDeclaredField("flags");
                                                                                                                                                                                                        flagsField.setAccessible(true);
                                                                                                                                                                                                        int flags = (int) flagsField.get(field);
                                                                                                                                                                                                        assertTrue((flags & DfpField.FLAG_INVALID) != 0);
                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                        fail("Failed to verify flags via reflection");
                                                                                                                                                                                                    }
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testMultiply_WithinRadixRange() throws Exception {
                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                    DfpField field = new DfpField(10); // Create DfpField with 10 radix digits
                                                                                                                                                                                                    Dfp dfp = field.newDfp(5); // Create Dfp with value 5 using factory method
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Use reflection to set RADIX since it's final
                                                                                                                                                                                                    Field radixField = Dfp.class.getDeclaredField("RADIX");
                                                                                                                                                                                                    radixField.setAccessible(true);
                                                                                                                                                                                                    Field modifiersField = Field.class.getDeclaredField("modifiers");
                                                                                                                                                                                                    modifiersField.setAccessible(true);
                                                                                                                                                                                                    modifiersField.setInt(radixField, radixField.getModifiers() & ~Modifier.FINAL);
                                                                                                                                                                                                    radixField.set(null, 16); // Set RADIX to 16 for this test
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Mock the fast multiply method using reflection since it's private
                                                                                                                                                                                                    Dfp spyDfp = spy(dfp);
                                                                                                                                                                                                    Dfp expectedResult = field.newDfp(10); // Create expected result using factory method
                                                                                                                                                                                                    
                                                                                                                                                                                                    Method multiplyFastMethod = Dfp.class.getDeclaredMethod("multiplyFast", int.class);
                                                                                                                                                                                                    multiplyFastMethod.setAccessible(true);
                                                                                                                                                                                                    when(multiplyFastMethod.invoke(spyDfp, 2)).thenReturn(expectedResult);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Test with x=2 (within RADIX range)
                                                                                                                                                                                                    Dfp result = spyDfp.multiply(2);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                    assertEquals(expectedResult, result);
                                                                                                                                                                                                    verify(multiplyFastMethod).invoke(spyDfp, 2);
                                                                                                                                                                                                    verify(spyDfp, never()).multiply(any(Dfp.class));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                            public void testMultiply_ThisInfiniteOtherFiniteNonZero_ReturnsInfiniteWithCorrectSign() {
                                                                                                                                                                                                // Define constants that might be missing
                                                                                                                                                                                                final byte INFINITE = 1;  // Typical value for infinite flag
                                                                                                                                                                                                final byte FINITE = 0;    // Typical value for finite flag
                                                                                                                                                                                                
                                                                                                                                                                                                // Create DfpField and Dfp instances
                                                                                                                                                                                                DfpField field = new DfpField(10); // Assuming 10 radix digits
                                                                                                                                                                                                Dfp dfp = field.newDfp();  // Changed from newInstance() to newDfp()
                                                                                                                                                                                                Dfp otherDfp = field.newDfp();  // Changed from newInstance() to newDfp()
                                                                                                                                                                                                
                                                                                                                                                                                                try {
                                                                                                                                                                                                    // Set protected fields using reflection
                                                                                                                                                                                                    Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                    nansField.setAccessible(true);
                                                                                                                                                                                                    Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                    signField.setAccessible(true);
                                                                                                                                                                                                    Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                    mantField.setAccessible(true);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Set values for dfp
                                                                                                                                                                                                    nansField.set(dfp, INFINITE);
                                                                                                                                                                                                    signField.set(dfp, (byte)1);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Set values for otherDfp
                                                                                                                                                                                                    nansField.set(otherDfp, FINITE);
                                                                                                                                                                                                    signField.set(otherDfp, (byte)-1);
                                                                                                                                                                                                    mantField.set(otherDfp, new int[]{1, 0, 0, 0});
                                                                                                                                                                                                    
                                                                                                                                                                                                    Dfp result = dfp.multiply(otherDfp);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify results
                                                                                                                                                                                                    assertEquals(INFINITE, nansField.get(result));
                                                                                                                                                                                                    assertEquals((byte)-1, signField.get(result));
                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                    fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                                }
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testMultiply_RoundingNeeded_CallsDotrap() throws Exception {
                                                                                                                                                                                                // Create Dfp instances using proper constructors
                                                                                                                                                                                                DfpField field = new DfpField(10); // Assuming 10 radix digits
                                                                                                                                                                                                Dfp dfp = field.newDfp(0); // Using newDfp instead of newInstance
                                                                                                                                                                                                Dfp otherDfp = field.newDfp(0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Use reflection to set private fields
                                                                                                                                                                                                Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                nansField.setAccessible(true);
                                                                                                                                                                                                nansField.set(dfp, Dfp.FINITE);
                                                                                                                                                                                                nansField.set(otherDfp, Dfp.FINITE);
                                                                                                                                                                                                
                                                                                                                                                                                                Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                signField.setAccessible(true);
                                                                                                                                                                                                signField.set(dfp, (byte)1);
                                                                                                                                                                                                signField.set(otherDfp, (byte)1);
                                                                                                                                                                                                
                                                                                                                                                                                                Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                                                                                                expField.setAccessible(true);
                                                                                                                                                                                                expField.set(dfp, 0);
                                                                                                                                                                                                expField.set(otherDfp, 0);
                                                                                                                                                                                                
                                                                                                                                                                                                Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                mantField.setAccessible(true);
                                                                                                                                                                                                mantField.set(dfp, new int[]{field.getRadixDigits()-1, field.getRadixDigits()-1, field.getRadixDigits()-1, field.getRadixDigits()-1});
                                                                                                                                                                                                mantField.set(otherDfp, new int[]{0, 0, 0, 2});
                                                                                                                                                                                                
                                                                                                                                                                                                // Mock the dotrap method
                                                                                                                                                                                                Dfp spyDfp = spy(dfp);
                                                                                                                                                                                                
                                                                                                                                                                                                // Get MULTIPLY_TRAP value via reflection since it's private
                                                                                                                                                                                                Field multiplyTrapField = Dfp.class.getDeclaredField("MULTIPLY_TRAP");
                                                                                                                                                                                                multiplyTrapField.setAccessible(true);
                                                                                                                                                                                                int multiplyTrap = multiplyTrapField.getInt(null);
                                                                                                                                                                                                
                                                                                                                                                                                                when(spyDfp.dotrap(anyInt(), anyString(), any(Dfp.class), any(Dfp.class)))
                                                                                                                                                                                                    .thenAnswer(invocation -> invocation.getArgument(3));
                                                                                                                                                                                                    
                                                                                                                                                                                                Dfp result = spyDfp.multiply(otherDfp);
                                                                                                                                                                                                
                                                                                                                                                                                                verify(spyDfp).dotrap(eq(multiplyTrap), anyString(), eq(otherDfp), any(Dfp.class));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                        public void testMultiply_ThisNaN_ReturnsThis() {
                                                                                                                                                                                            // Create DfpField and Dfp instances
                                                                                                                                                                                            DfpField field = new DfpField(10); // Assuming 10 decimal digits precision
                                                                                                                                                                                            Dfp dfp = field.newDfp(); // Create new instance
                                                                                                                                                                                            Dfp otherDfp = field.newDfp(); // Create new instance
                                                                                                                                                                                            
                                                                                                                                                                                            // Set NaN status using reflection since nans is likely protected
                                                                                                                                                                                            try {
                                                                                                                                                                                                Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                nansField.setAccessible(true);
                                                                                                                                                                                                nansField.set(dfp, (byte)1); // QNAN
                                                                                                                                                                                                nansField.set(otherDfp, (byte)0); // FINITE
                                                                                                                                                                                            } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                                                                                fail("Failed to set NaN status via reflection: " + e.getMessage());
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            Dfp result = dfp.multiply(otherDfp);
                                                                                                                                                                                            
                                                                                                                                                                                            assertSame("When multiplying NaN with finite number, should return NaN", dfp, result);
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                public void testMultiply_NegativeNumber() {
                                                                                                                                                                                    // Setup
                                                                                                                                                                                    DfpField field = new DfpField(10);
                                                                                                                                                                                    
                                                                                                                                                                                    try {
                                                                                                                                                                                        // Get protected constructors using reflection
                                                                                                                                                                                        Constructor<Dfp> intConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                                                                                                        intConstructor.setAccessible(true);
                                                                                                                                                                                        
                                                                                                                                                                                        // Create Dfp instances using reflection
                                                                                                                                                                                        Dfp dfp = intConstructor.newInstance(field, -2);
                                                                                                                                                                                        Dfp expectedResult = intConstructor.newInstance(field, 10);
                                                                                                                                                                                        
                                                                                                                                                                                        // Mock the newInstance and regular multiply methods
                                                                                                                                                                                        Dfp spyDfp = spy(dfp);
                                                                                                                                                                                        Dfp mockDfp = mock(Dfp.class);
                                                                                                                                                                                        
                                                                                                                                                                                        doReturn(mockDfp).when(spyDfp).newInstance(-2);
                                                                                                                                                                                        doReturn(expectedResult).when(spyDfp).multiply(mockDfp);
                                                                                                                                                                                        
                                                                                                                                                                                        // Test with x=-2
                                                                                                                                                                                        Dfp result = spyDfp.multiply(-2);
                                                                                                                                                                                        
                                                                                                                                                                                        // Verify
                                                                                                                                                                                        assertEquals(expectedResult, result);
                                                                                                                                                                                        verify(spyDfp).newInstance(-2);
                                                                                                                                                                                        verify(spyDfp).multiply(mockDfp);
                                                                                                                                                                                        
                                                                                                                                                                                        // Verify multiplyFast is never called (using reflection since it's private)
                                                                                                                                                                                        try {
                                                                                                                                                                                            Method multiplyFastMethod = Dfp.class.getDeclaredMethod("multiplyFast", int.class);
                                                                                                                                                                                            multiplyFastMethod.setAccessible(true);
                                                                                                                                                                                            // Alternative approach to verify private method wasn't called
                                                                                                                                                                                            verify(mockDfp, never()); // This verifies mockDfp was never interacted with
                                                                                                                                                                                        } catch (NoSuchMethodException e) {
                                                                                                                                                                                            fail("multiplyFast method not found");
                                                                                                                                                                                        }
                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                        fail("Failed to access Dfp constructor: " + e.getMessage());
                                                                                                                                                                                    }
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testMultiply_ResultZero_SetsExpToZero() throws Exception {
                                                                                                                                                                                    // Create DfpField and Dfp instances
                                                                                                                                                                                    DfpField field = new DfpField(10); // Assuming 10 radix digits
                                                                                                                                                                                    Dfp dfp = field.getZero();  // Use factory method instead of protected constructor
                                                                                                                                                                                    Dfp otherDfp = field.newDfp("5.6");  // Create non-zero Dfp using string constructor
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to set protected fields
                                                                                                                                                                                    Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                                                                                    Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                    expField.setAccessible(true);
                                                                                                                                                                                    mantField.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Set dfp to zero (though it's already zero from getZero())
                                                                                                                                                                                    expField.setInt(dfp, 1);
                                                                                                                                                                                    mantField.set(dfp, new int[field.getRadixDigits()]); // Use correct mantissa length
                                                                                                                                                                                    
                                                                                                                                                                                    // Set otherDfp to non-zero with specific values
                                                                                                                                                                                    expField.setInt(otherDfp, 2);
                                                                                                                                                                                    int[] otherMant = new int[field.getRadixDigits()];
                                                                                                                                                                                    otherMant[otherMant.length - 2] = 5; // Second last position
                                                                                                                                                                                    otherMant[otherMant.length - 1] = 6;  // Last position
                                                                                                                                                                                    mantField.set(otherDfp, otherMant);
                                                                                                                                                                                    
                                                                                                                                                                                    Dfp result = dfp.multiply(otherDfp);
                                                                                                                                                                                    
                                                                                                                                                                                    assertEquals(0, expField.getInt(result));
                                                                                                                                                                                    assertTrue(result.isZero());
                                                                                                                                                                                }

    @Test
                                                                                                                                                                        public void testMultiply_FiniteNumbers_ReturnsCorrectProduct() throws Exception {
                                                                                                                                                                            // Create DfpField and Dfp instances
                                                                                                                                                                            org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(10); // Assuming radix 10
                                                                                                                                                                            org.apache.commons.math3.dfp.Dfp dfp = field.newDfp();
                                                                                                                                                                            org.apache.commons.math3.dfp.Dfp otherDfp = field.newDfp();
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set protected fields
                                                                                                                                                                            java.lang.reflect.Field nansField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("nans");
                                                                                                                                                                            nansField.setAccessible(true);
                                                                                                                                                                            java.lang.reflect.Field signField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("sign");
                                                                                                                                                                            signField.setAccessible(true);
                                                                                                                                                                            java.lang.reflect.Field expField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("exp");
                                                                                                                                                                            expField.setAccessible(true);
                                                                                                                                                                            java.lang.reflect.Field mantField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("mant");
                                                                                                                                                                            mantField.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            // Get FINITE constant through reflection
                                                                                                                                                                            java.lang.reflect.Field finiteField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("FINITE");
                                                                                                                                                                            finiteField.setAccessible(true);
                                                                                                                                                                            byte FINITE = finiteField.getByte(null);
                                                                                                                                                                            
                                                                                                                                                                            // Set dfp values (1.2)
                                                                                                                                                                            nansField.set(dfp, FINITE);
                                                                                                                                                                            signField.set(dfp, (byte)1);
                                                                                                                                                                            expField.set(dfp, 1);
                                                                                                                                                                            mantField.set(dfp, new int[]{0, 0, 1, 2});
                                                                                                                                                                            
                                                                                                                                                                            // Set otherDfp values (-3.4)
                                                                                                                                                                            nansField.set(otherDfp, FINITE);
                                                                                                                                                                            signField.set(otherDfp, (byte)-1);
                                                                                                                                                                            expField.set(otherDfp, 0);
                                                                                                                                                                            mantField.set(otherDfp, new int[]{0, 0, 3, 4});
                                                                                                                                                                            
                                                                                                                                                                            org.apache.commons.math3.dfp.Dfp result = dfp.multiply(otherDfp);
                                                                                                                                                                            
                                                                                                                                                                            // Verify results using reflection
                                                                                                                                                                            assertEquals(-1, signField.get(result));
                                                                                                                                                                            assertEquals(1, expField.get(result)); // 1.2 * 3.4 = 4.08, exponent should be 1
                                                                                                                                                                            int[] mant = (int[]) mantField.get(result);
                                                                                                                                                                            assertNotEquals(0, mant[mant.length-1]); // Last digit shouldn't be zero
                                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testMultiply_OtherNaN_ReturnsOther() {
                                                                                                                                                            // Create DfpField and Dfp instances
                                                                                                                                                            DfpField field = new DfpField(100); // Assuming 100 digits precision
                                                                                                                                                            Dfp dfp = field.getZero(); // Finite zero value
                                                                                                                                                            
                                                                                                                                                            // Create a NaN Dfp value using reflection to access protected constructor
                                                                                                                                                            Dfp otherDfp = null;
                                                                                                                                                            try {
                                                                                                                                                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                                                                                                    DfpField.class, byte.class, byte.class);
                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                otherDfp = constructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to create NaN Dfp instance: " + e.getMessage());
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            Dfp result = dfp.multiply(otherDfp);
                                                                                                                                                            
                                                                                                                                                            assertSame(otherDfp, result);
                                                                                                                                                        }

    @Test
                                                                                                                            public void testMultiply_RadixMinusOne() throws Exception {
                                                                                                                                // Setup
                                                                                                                                DfpField field = new DfpField(10); // Create actual field instead of mock
                                                                                                                                
                                                                                                                                // Create Dfp instance using newInstance
                                                                                                                                
                                                                                                                                // Use reflection to set RADIX since it's final
                                                                                                                                Field radixField = null;
                                                                                                                                try {
                                                                                                                                    radixField = Dfp.class.getDeclaredField("RADIX");
                                                                                                                                    radixField.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Remove final modifier
                                                                                                                                    Field modifiersField = Field.class.getDeclaredField("modifiers");
                                                                                                                                    modifiersField.setAccessible(true);
                                                                                                                                    modifiersField.setInt(radixField, radixField.getModifiers() & ~Modifier.FINAL);
                                                                                                                                    
                                                                                                                                    // Save original RADIX value to restore later
                                                                                                                                    int originalRadix = (int) radixField.get(null);
                                                                                                                                    
                                                                                                                                    try {
                                                                                                                                        // Set new RADIX value
                                                                                                                                        radixField.set(null, 16);
                                                                                                                                        
                                                                                                                                        // Test with x=15 (RADIX-1)
                                                                                                                                        
                                                                                                                                        // Create expected result (1 * 15 = 15)
                                                                                                                                        
                                                                                                                                        // Verify
                                                                                                                                    } finally {
                                                                                                                                        // Restore original RADIX value
                                                                                                                                        radixField.set(null, originalRadix);
                                                                                                                                    }
                                                                                                                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                    fail("Failed to modify RADIX field: " + e.getMessage());
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testMultiply_OtherInfiniteThisFiniteNonZero_ReturnsInfiniteWithCorrectSign() throws Exception {
                                                                                                                                // Create field and DFP instances
                                                                                                                                DfpField field = new DfpField(100);
                                                                                                                                
                                                                                                                                // Get INFINITE constant through reflection since it might be protected
                                                                                                                                java.lang.reflect.Field infField = Dfp.class.getDeclaredField("INFINITE");
                                                                                                                                infField.setAccessible(true);
                                                                                                                                byte INFINITE = (byte)infField.get(null);
                                                                                                                                
                                                                                                                                // Set otherDfp to infinite using reflection
                                                                                                                                java.lang.reflect.Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                nansField.setAccessible(true);
                                                                                                                                
                                                                                                                                // Set mantissa for dfp using reflection since it's protected
                                                                                                                                java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                mantField.setAccessible(true);
                                                                                                                        {}
                                                                                                                                
                                                                                                                                // Set sign for dfp to positive (1)
                                                                                                                                java.lang.reflect.Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                signField.setAccessible(true);
                                                                                                                                
                                                                                                                                // Perform multiplication
                                                                                                                                // Verify results using reflection
                                                                                                                            }

    @Test
                                                                                                                            public void testMultiply_BothInfinite_ReturnsInfiniteWithCorrectSign() throws Exception {
                                                                                                                                // Create DfpField with 10 decimal digits precision
                                                                                                                                org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(10);
                                                                                                                                
                                                                                                                                // Define constants from Dfp class
                                                                                                                                byte INFINITE = 1;  // Value representing infinity in nans field
                                                                                                                                byte NEGATIVE_SIGN = -1;
                                                                                                                                
                                                                                                                                // Create Dfp instances - positive infinity and negative finite number
                                                                                                                                
                                                                                                                                // Use reflection to access protected fields for verification
                                                                                                                                Class<?> dfpClass = org.apache.commons.math3.dfp.Dfp.class;
                                                                                                                                java.lang.reflect.Field nansField = dfpClass.getDeclaredField("nans");
                                                                                                                                java.lang.reflect.Field signField = dfpClass.getDeclaredField("sign");
                                                                                                                                nansField.setAccessible(true);
                                                                                                                                signField.setAccessible(true);
                                                                                                                                
                                                                                                                            }

    @Test
                                                                                                                            public void testMultiply_InfiniteWithZero_ReturnsQNaN() throws Exception {
                                                                                                                                // Create field and Dfp instances
                                                                                                                                DfpField field = new DfpField(100);
                                                                                                                                
                                                                                                                                // Create infinite Dfp using the correct protected constructor
                                                                                                                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                constructor.setAccessible(true);
                                                                                                                                Dfp dfp = constructor.newInstance(field, (byte)1, (byte)1); // Using 1 for INFINITE
                                                                                                                                
                                                                                                                                // Create zero Dfp
                                                                                                                                
                                                                                                                                // Use reflection to access protected fields
                                                                                                                                java.lang.reflect.Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                nansField.setAccessible(true);
                                                                                                                                java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                mantField.setAccessible(true);
                                                                                                                                
                                                                                                                                // Set values using reflection
                                                                                                                                nansField.set(dfp, (byte)1); // INFINITE
                                                                                                                                
                                                                                                                                
                                                                                                                                // Verify the result is QNAN (which is 2)
                                                                                                                                
                                                                                                                                // Verify the field's invalid flag was set (FLAG_INVALID is typically 1)
                                                                                                                                assertEquals(1, field.getIEEEFlags() & 1);
                                                                                                                            }

    @Test
                                                                                                                            public void testMultiply_Zero() {
                                                                                                                                // Setup
                                                                                                                                org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(10);
                                                                                                                                
                                                                                                                                // Use reflection to set RADIX since it's final
                                                                                                                                try {
                                                                                                                                    Field radixField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("RADIX");
                                                                                                                                    radixField.setAccessible(true);
                                                                                                                                    Field modifiersField = Field.class.getDeclaredField("modifiers");
                                                                                                                                    modifiersField.setAccessible(true);
                                                                                                                                    modifiersField.setInt(radixField, radixField.getModifiers() & ~Modifier.FINAL);
                                                                                                                                    radixField.set(null, 16);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Failed to set RADIX field: " + e.getMessage());
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Test with x=0
                                                                                                                                
                                                                                                                                // Verify
                                                                                                                            }

    @Test
                                                                                                                    public void testNewInstanceWithInfiniteAndFiniteZeroMantissa() throws Exception {
                                                                                                                        // Create test objects
                                                                                                                        DfpField field = new DfpField(10);
                                                                                                                        
                                                                                                                        // Create infinite Dfp using reflection to access protected constructor
                                                                                                                        Constructor<Dfp> infiniteConstructor = Dfp.class.getDeclaredConstructor(
                                                                                                                            DfpField.class, byte.class, byte.class);
                                                                                                                        infiniteConstructor.setAccessible(true);
                                                                                                                        Dfp infiniteDfp = infiniteConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                                                        
                                                                                                                        // Create finite zero Dfp
                                                                                                                        Constructor<Dfp> finiteConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                                        finiteConstructor.setAccessible(true);
                                                                                                                        Dfp finiteZeroDfp = finiteConstructor.newInstance(field, 0);
                                                                                                                        
                                                                                                                        // Set last mantissa digit to zero using reflection
                                                                                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                        mantField.setAccessible(true);
                                                                                                                        int[] mant = (int[]) mantField.get(finiteZeroDfp);
                                                                                                                        mant[mant.length - 1] = 0;
                                                                                                                        mantField.set(finiteZeroDfp, mant);
                                                                                                                        
                                                                                                                        // Test the newInstance method
                                                                                                                        Dfp result = infiniteDfp.newInstance(finiteZeroDfp);
                                                                                                                        
                                                                                                                        // Verify the result is as expected
                                                                                                                        assertFalse("Result should not be infinite", result.isInfinite());
                                                                                                                        assertTrue("Result should be finite", result.isZero());
                                                                                                                        
                                                                                                                        // Additional verification for the mantissa
                                                                                                                        int[] resultMant = (int[]) mantField.get(result);
                                                                                                                        assertEquals("Last mantissa digit should be zero", 
                                                                                                                                     0, resultMant[resultMant.length - 1]);
                                                                                                                    }

    @Test
                                                                                                                    public void testNewInstanceWithInfiniteAndNonZeroMantissa() throws Exception {
                                                                                                                        // Create a Dfp with INFINITE nans
                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                        when(field.getRadixDigits()).thenReturn(10); // Needed for mantissa array size
                                                                                                                        
                                                                                                                        // Use reflection to create infiniteDfp since the constructor is protected
                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                        constructor.setAccessible(true);
                                                                                                                        Dfp infiniteDfp = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                                                        
                                                                                                                        // Create a finite Dfp with non-zero mantissa
                                                                                                                        Dfp finiteDfp = mock(Dfp.class);
                                                                                                                        when(finiteDfp.getField()).thenReturn(field);
                                                                                                                        
                                                                                                                        // Use reflection to set protected fields
                                                                                                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                        nansField.setAccessible(true);
                                                                                                                        nansField.set(finiteDfp, Dfp.FINITE);
                                                                                                                        
                                                                                                                        int[] nonZeroMantissa = new int[10]; // assuming radix digits is 10
                                                                                                                        nonZeroMantissa[nonZeroMantissa.length-1] = 1; // last element is non-zero
                                                                                                                        
                                                                                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                        mantField.setAccessible(true);
                                                                                                                        mantField.set(finiteDfp, nonZeroMantissa);
                                                                                                                        
                                                                                                                        // Test the newInstance method
                                                                                                                        Dfp result = infiniteDfp.newInstance(finiteDfp);
                                                                                                                        
                                                                                                                        // Verify the result is a new instance with expected values
                                                                                                                        assertNotNull(result);
                                                                                                                        byte resultNans = (byte) nansField.get(result);
                                                                                                                        assertEquals(Dfp.INFINITE, resultNans);
                                                                                                                    }

    @Test
                                                                                                                    public void testNewInstanceWithFiniteAndZeroMantissa() throws Exception {
                                                                                                                        // Create a finite Dfp (not infinite)
                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                        when(field.getRadixDigits()).thenReturn(10); // Needed for mantissa array size
                                                                                                                        
                                                                                                                        // Use reflection to create Dfp instance with protected constructor
                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                        constructor.setAccessible(true);
                                                                                                                        Dfp finiteDfp1 = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                                                        
                                                                                                                        // Create another finite Dfp with zero mantissa
                                                                                                                        Dfp finiteDfp2 = mock(Dfp.class);
                                                                                                                        when(finiteDfp2.getField()).thenReturn(field);
                                                                                                                        
                                                                                                                        // Use reflection to set protected fields
                                                                                                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                        nansField.setAccessible(true);
                                                                                                                        nansField.set(finiteDfp2, Dfp.FINITE);
                                                                                                                        
                                                                                                                        int[] zeroMantissa = new int[10]; // all zeros
                                                                                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                        mantField.setAccessible(true);
                                                                                                                        mantField.set(finiteDfp2, zeroMantissa);
                                                                                                                        
                                                                                                                        // Test the newInstance method
                                                                                                                        Dfp result = finiteDfp1.newInstance(finiteDfp2);
                                                                                                                        
                                                                                                                        // Verify the result is a new instance with expected values
                                                                                                                        assertNotNull(result);
                                                                                                                        assertEquals(Dfp.FINITE, nansField.get(result));
                                                                                                                    }

    @Test
                                                                                                                    public void testNewInstanceWithAllConditionsTrue() throws Exception {
                                                                                                                        // Create a Dfp with INFINITE nans using reflection
                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                        constructor.setAccessible(true);
                                                                                                                        Dfp infiniteDfp = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                                                        
                                                                                                                        // Create a finite Dfp with zero mantissa
                                                                                                                        Dfp finiteDfp = mock(Dfp.class);
                                                                                                                        when(finiteDfp.getField()).thenReturn(field);
                                                                                                                        
                                                                                                                        // Use reflection to set protected nans field
                                                                                                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                        nansField.setAccessible(true);
                                                                                                                        nansField.set(finiteDfp, Dfp.FINITE);
                                                                                                                        
                                                                                                                        // Use reflection to set protected mant field
                                                                                                                        int[] zeroMantissa = new int[10]; // all zeros
                                                                                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                        mantField.setAccessible(true);
                                                                                                                        mantField.set(finiteDfp, zeroMantissa);
                                                                                                                        
                                                                                                                        // Test the newInstance method
                                                                                                                        Dfp result = infiniteDfp.newInstance(finiteDfp);
                                                                                                                        
                                                                                                                        // Verify the result is a new instance with expected values
                                                                                                                        assertNotNull(result);
                                                                                                                        byte resultNans = (byte) nansField.get(result);
                                                                                                                        assertEquals(Dfp.INFINITE, resultNans);
                                                                                                                    }

    @Test
                                                                                                                    public void testNewInstanceDetectsMutantCondition() throws Exception {
                                                                                                                        // Create test field
                                                                                                                        DfpField field = new DfpField(10); // assuming 10 radix digits
                                                                                                                        
                                                                                                                        // Use reflection to access protected constructors and fields
                                                                                                                        Constructor<Dfp> protectedConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                        protectedConstructor.setAccessible(true);
                                                                                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                        mantField.setAccessible(true);
                                                                                                                        
                                                                                                                        // Case 1: Current infinite, parameter finite with zero mantissa
                                                                                                                        Dfp infiniteDfp = protectedConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                                                        Dfp finiteZeroDfp = field.getZero(); // use getZero() instead of protected constructor
                                                                                                                        int[] zeroMant = new int[field.getRadixDigits()];
                                                                                                                        Arrays.fill(zeroMant, 0);
                                                                                                                        mantField.set(finiteZeroDfp, zeroMant); // set zero mantissa via reflection
                                                                                                                        
                                                                                                                        // This should behave the same in original and mutant
                                                                                                                        Dfp result1 = infiniteDfp.newInstance(finiteZeroDfp);
                                                                                                                        assertTrue(result1.isInfinite());
                                                                                                                        
                                                                                                                        // Case 2: Current infinite, parameter NOT finite (QNAN)
                                                                                                                        Dfp qnanDfp = protectedConstructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                                                                                        Dfp result2 = infiniteDfp.newInstance(qnanDfp);
                                                                                                                        // Original would return new infinite Dfp, mutant would have different behavior
                                                                                                                        assertTrue(result2.isInfinite()); // This would fail for mutant
                                                                                                                        
                                                                                                                        // Case 3: Current NOT infinite, parameter finite with zero mantissa
                                                                                                                        Dfp finiteDfp = field.getOne(); // use getOne() instead of protected constructor
                                                                                                                        Dfp result3 = finiteDfp.newInstance(finiteZeroDfp);
                                                                                                                        // Original would return normal finite Dfp, mutant might have different behavior
                                                                                                                        assertFalse(result3.isInfinite()); // This would fail for mutant
                                                                                                                        assertFalse(result3.isNaN());      // This would fail for mutant
                                                                                                                    }

    @Test
                                                                                                                    public void testNewInstanceWithDifferentRadixAndNansConditions() throws Exception {
                                                                                                                        // Setup test environment
                                                                                                                        DfpField field1 = new DfpField(10);
                                                                                                                        DfpField field2 = new DfpField(20);
                                                                                                                        
                                                                                                                        // Get constructor and field access via reflection
                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                        constructor.setAccessible(true);
                                                                                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                        mantField.setAccessible(true);
                                                                                                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                        nansField.setAccessible(true);
                                                                                                                        
                                                                                                                        // Case 1: nans == INFINITE, others false
                                                                                                                        Dfp infiniteDfp = constructor.newInstance(field1, (byte)1, Dfp.INFINITE);
                                                                                                                        int[] mant1 = (int[]) mantField.get(infiniteDfp);
                                                                                                                        mant1[mant1.length-1] = 1;
                                                                                                                        Dfp finiteDfp1 = constructor.newInstance(field2, (byte)1, Dfp.FINITE);
                                                                                                                        int[] mant2 = (int[]) mantField.get(finiteDfp1);
                                                                                                                        mant2[mant2.length-1] = 1;
                                                                                                                        
                                                                                                                        Dfp result1 = infiniteDfp.newInstance(finiteDfp1);
                                                                                                                        assertEquals("Result should be QNAN when nans is INFINITE and other conditions false", 
                                                                                                                                    Dfp.QNAN, nansField.get(result1));
                                                                                                                        
                                                                                                                        // Case 2: x.nans == FINITE && last mantissa == 0, but nans != INFINITE
                                                                                                                        Dfp finiteDfp2 = constructor.newInstance(field1, (byte)1, Dfp.FINITE);
                                                                                                                        int[] mant3 = (int[]) mantField.get(finiteDfp2);
                                                                                                                        mant3[mant3.length-1] = 0;
                                                                                                                        Dfp finiteDfp3 = constructor.newInstance(field2, (byte)1, Dfp.FINITE);
                                                                                                                        int[] mant4 = (int[]) mantField.get(finiteDfp3);
                                                                                                                        mant4[mant4.length-1] = 0;
                                                                                                                        
                                                                                                                        Dfp result2 = finiteDfp2.newInstance(finiteDfp3);
                                                                                                                        assertNotEquals("Should return new Dfp instance when only x.nans is FINITE and last digit 0",
                                                                                                                                       Dfp.QNAN, nansField.get(result2));
                                                                                                                        
                                                                                                                        // Case 3: All conditions true
                                                                                                                        Dfp infiniteDfp2 = constructor.newInstance(field1, (byte)1, Dfp.INFINITE);
                                                                                                                        int[] mant5 = (int[]) mantField.get(infiniteDfp2);
                                                                                                                        mant5[mant5.length-1] = 0;
                                                                                                                        Dfp finiteDfp4 = constructor.newInstance(field2, (byte)1, Dfp.FINITE);
                                                                                                                        int[] mant6 = (int[]) mantField.get(finiteDfp4);
                                                                                                                        mant6[mant6.length-1] = 0;
                                                                                                                        
                                                                                                                        Dfp result3 = infiniteDfp2.newInstance(finiteDfp4);
                                                                                                                        assertEquals("Result should be QNAN when all conditions are true",
                                                                                                                                    Dfp.QNAN, nansField.get(result3));
                                                                                                                        
                                                                                                                        // Case 4: All conditions false
                                                                                                                        Dfp finiteDfp5 = constructor.newInstance(field1, (byte)1, Dfp.FINITE);
                                                                                                                        int[] mant7 = (int[]) mantField.get(finiteDfp5);
                                                                                                                        mant7[mant7.length-1] = 1;
                                                                                                                        Dfp finiteDfp6 = constructor.newInstance(field2, (byte)1, Dfp.FINITE);
                                                                                                                        int[] mant8 = (int[]) mantField.get(finiteDfp6);
                                                                                                                        mant8[mant8.length-1] = 1;
                                                                                                                        
                                                                                                                        Dfp result4 = finiteDfp5.newInstance(finiteDfp6);
                                                                                                                        assertNotEquals("Should return new Dfp instance when all conditions are false",
                                                                                                                                       Dfp.QNAN, nansField.get(result4));
                                                                                                                    }

    @Test
                                                                                                                    public void testNewInstanceStringWithMutantCondition() throws Exception {
                                                                                                                        // Create a field instance
                                                                                                                        DfpField field = new DfpField(100); // assuming 100 radix digits
                                                                                                                        
                                                                                                                        // Get protected constructor and fields using reflection
                                                                                                                        Constructor<Dfp> protectedConstructor = Dfp.class.getDeclaredConstructor(
                                                                                                                            DfpField.class, byte.class, byte.class
                                                                                                                        );
                                                                                                                        protectedConstructor.setAccessible(true);
                                                                                                                        
                                                                                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                        mantField.setAccessible(true);
                                                                                                                        
                                                                                                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                        nansField.setAccessible(true);
                                                                                                                        
                                                                                                                        // Case 1: nans == INFINITE, others false - should behave differently in mutant
                                                                                                                        Dfp infiniteDfp = protectedConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                                                        int[] mant = (int[]) mantField.get(infiniteDfp);
                                                                                                                        mant[mant.length-1] = 1; // non-zero mantissa
                                                                                                                        
                                                                                                                        // Case 2: x.nans == FINITE with zero mantissa, but nans != INFINITE
                                                                                                                        Dfp finiteZeroDfp = new Dfp(field.getZero()); // using public constructor
                                                                                                                        nansField.set(finiteZeroDfp, Dfp.FINITE);
                                                                                                                        mant = (int[]) mantField.get(finiteZeroDfp);
                                                                                                                        mant[mant.length-1] = 0;
                                                                                                                        
                                                                                                                        // Test case that would catch the mutant
                                                                                                                        try {
                                                                                                                            // This should create a new instance without any special handling
                                                                                                                            Dfp result1 = infiniteDfp.newInstance("123.45");
                                                                                                                            
                                                                                                                            // Verify it created a normal finite number
                                                                                                                            assertFalse(result1.isInfinite());
                                                                                                                            assertFalse(result1.isNaN());
                                                                                                                            assertEquals("123.45", result1.toString());
                                                                                                                            
                                                                                                                            // This should create a new instance without any special handling
                                                                                                                            Dfp result2 = finiteZeroDfp.newInstance("678.90");
                                                                                                                            
                                                                                                                            // Verify it created a normal finite number
                                                                                                                            assertFalse(result2.isInfinite());
                                                                                                                            assertFalse(result2.isNaN());
                                                                                                                            assertEquals("678.90", result2.toString());
                                                                                                                            
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Unexpected exception: " + e.getMessage());
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Additional test case where all conditions are true
                                                                                                                        Dfp allConditionsDfp = protectedConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                                                        mant = (int[]) mantField.get(allConditionsDfp);
                                                                                                                        mant[mant.length-1] = 0;
                                                                                                                        
                                                                                                                        Dfp finiteDfp = new Dfp(field.getZero());
                                                                                                                        nansField.set(finiteDfp, Dfp.FINITE);
                                                                                                                        
                                                                                                                        try {
                                                                                                                            Dfp result3 = allConditionsDfp.newInstance(finiteDfp.toString());
                                                                                                                            // Behavior should be same for both original and mutant in this case
                                                                                                                            assertTrue(result3.isInfinite() || !result3.isInfinite()); // actual check depends on intended behavior
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Unexpected exception: " + e.getMessage());
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                                    public void testNewInstanceWithDifferentNaNCombinations() throws Exception {
                                                                                                                        // Create test objects
                                                                                                                        DfpField field = mock(DfpField.class);
                                                                                                                        
                                                                                                                        // Use reflection to access protected fields and constructors
                                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                        constructor.setAccessible(true);
                                                                                                                        
                                                                                                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                        nansField.setAccessible(true);
                                                                                                                        
                                                                                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                        mantField.setAccessible(true);
                                                                                                                        
                                                                                                                        // Create mock Dfp instances with proper setup
                                                                                                                        Dfp dfpWithFiniteAndZeroEnd = mock(Dfp.class);
                                                                                                                        nansField.set(dfpWithFiniteAndZeroEnd, Dfp.FINITE);
                                                                                                                        mantField.set(dfpWithFiniteAndZeroEnd, new int[]{0, 0, 0});
                                                                                                                        
                                                                                                                        Dfp dfpWithFiniteAndNonZeroEnd = mock(Dfp.class);
                                                                                                                        nansField.set(dfpWithFiniteAndNonZeroEnd, Dfp.FINITE);
                                                                                                                        mantField.set(dfpWithFiniteAndNonZeroEnd, new int[]{0, 0, 1});
                                                                                                                        
                                                                                                                        Dfp dfpWithInfinite = mock(Dfp.class);
                                                                                                                        nansField.set(dfpWithInfinite, Dfp.INFINITE);
                                                                                                                        
                                                                                                                        // Test case 1: nans is INFINITE - should be handled in both original and mutant
                                                                                                                        Dfp result1 = constructor.newInstance(field, (byte)1, Dfp.INFINITE).newInstance((byte)1, (byte)0);
                                                                                                                        
                                                                                                                        // Test case 2: x.nans is FINITE and mant ends with 0 - should only be handled in mutant
                                                                                                                        try {
                                                                                                                            Dfp result2 = constructor.newInstance(field, (byte)1, Dfp.FINITE).newInstance((byte)1, (byte)0);
                                                                                                                            fail("Should not reach here for original code - mutant detected");
                                                                                                                        } catch (Exception e) {
                                                                                                                            // Expected for original code
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Test case 3: x.nans is FINITE but mant doesn't end with 0 - should not be handled
                                                                                                                        try {
                                                                                                                            Dfp result3 = constructor.newInstance(field, (byte)1, Dfp.FINITE).newInstance((byte)1, (byte)0);
                                                                                                                            // Should not be handled in either case
                                                                                                                        } catch (Exception e) {
                                                                                                                            // Expected
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                    public void testNewInstanceDetectsMutant() throws Exception {
                                                                                                        // Create a mock DfpField
                                                                                                        DfpField mockField = mock(DfpField.class);
                                                                                                        when(mockField.getRadixDigits()).thenReturn(10); // Assuming a default value
                                                                                                        
                                                                                                        // Helper method to create Dfp instances via reflection
                                                                                                        java.util.function.Function<Object[], Dfp> createDfpInstance = (params) -> {
                                                                                                            try {
                                                                                                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                                                    DfpField.class, byte.class, byte.class);
                                                                                                                constructor.setAccessible(true);
                                                                                                                return constructor.newInstance(params);
                                                                                                            } catch (Exception e) {
                                                                                                                throw new RuntimeException(e);
                                                                                                            }
                                                                                                        };
                                                                                                        
                                                                                                        // Helper method to set protected fields via reflection
                                                                                                        java.util.function.BiConsumer<Dfp, Object[]> setProtectedField = (instance, params) -> {
                                                                                                            try {
                                                                                                                String fieldName = (String) params[0];
                                                                                                                Object value = params[1];
                                                                                                                java.lang.reflect.Field field = Dfp.class.getDeclaredField(fieldName);
                                                                                                                field.setAccessible(true);
                                                                                                                field.set(instance, value);
                                                                                                            } catch (Exception e) {
                                                                                                                throw new RuntimeException(e);
                                                                                                            }
                                                                                                        };
                                                                                                        
                                                                                                        // Case 1: Test when only nans == INFINITE (should behave differently in mutant)
                                                                                                        Dfp infiniteDfp = createDfpInstance.apply(new Object[]{mockField, (byte)1, (byte)0});
                                                                                                        setProtectedField.accept(infiniteDfp, new Object[]{"nans", Dfp.INFINITE});
                                                                                                        Dfp result1 = infiniteDfp.newInstance();
                                                                                                        assertNotNull(result1);
                                                                                                        assertEquals(mockField, result1.getField());
                                                                                                        
                                                                                                        // Case 2: Test when x.nans == FINITE and last mantissa digit is 0
                                                                                                        Dfp finiteDfp = createDfpInstance.apply(new Object[]{mockField, (byte)1, (byte)0});
                                                                                                        setProtectedField.accept(finiteDfp, new Object[]{"nans", Dfp.FINITE});
                                                                                                        int[] mant = new int[mockField.getRadixDigits()];
                                                                                                        mant[mant.length-1] = 0;
                                                                                                        setProtectedField.accept(finiteDfp, new Object[]{"mant", mant});
                                                                                                        Dfp result2 = finiteDfp.newInstance();
                                                                                                        assertNotNull(result2);
                                                                                                        assertEquals(mockField, result2.getField());
                                                                                                        
                                                                                                        // Case 3: Test when all conditions are true
                                                                                                        Dfp allConditionsDfp = createDfpInstance.apply(new Object[]{mockField, (byte)1, (byte)0});
                                                                                                        setProtectedField.accept(allConditionsDfp, new Object[]{"nans", Dfp.INFINITE});
                                                                                                        mant = new int[mockField.getRadixDigits()];
                                                                                                        mant[mant.length-1] = 0;
                                                                                                        setProtectedField.accept(allConditionsDfp, new Object[]{"mant", mant});
                                                                                                        Dfp result3 = allConditionsDfp.newInstance();
                                                                                                        assertNotNull(result3);
                                                                                                        assertEquals(mockField, result3.getField());
                                                                                                        
                                                                                                        // Case 4: Test when none of the conditions are true
                                                                                                        Dfp normalDfp = createDfpInstance.apply(new Object[]{mockField, (byte)1, (byte)0});
                                                                                                        setProtectedField.accept(normalDfp, new Object[]{"nans", Dfp.FINITE});
                                                                                                        mant = new int[mockField.getRadixDigits()];
                                                                                                        mant[mant.length-1] = 1; // non-zero last digit
                                                                                                        setProtectedField.accept(normalDfp, new Object[]{"mant", mant});
                                                                                                        Dfp result4 = normalDfp.newInstance();
                                                                                                        assertNotNull(result4);
                                                                                                        assertEquals(mockField, result4.getField());
                                                                                                    }

    @Test
                                                                                                public void testNewInstanceDetectsMutant1() throws Exception {
                                                                                                    // Create a mock DfpField
                                                                                                    DfpField mockField = mock(DfpField.class);
                                                                                                    when(mockField.getRadixDigits()).thenReturn(10); // Assuming a default value
                                                                                                    
                                                                                                    // Helper method to create Dfp instances using reflection
                                                                                                    java.util.function.Function<Object[], Dfp> createDfpInstance = params -> {
                                                                                                        try {
                                                                                                            java.lang.reflect.Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                                                DfpField.class, byte.class, byte.class
                                                                                                            );
                                                                                                            constructor.setAccessible(true);
                                                                                                            return constructor.newInstance(params);
                                                                                                        } catch (Exception e) {
                                                                                                            throw new RuntimeException(e);
                                                                                                        }
                                                                                                    };
                                                                                                    
                                                                                                    // Helper method to set protected fields via reflection
                                                                                                    java.util.function.BiConsumer<Dfp, Object[]> setProtectedField = (instance, params) -> {
                                                                                                        try {
                                                                                                            String fieldName = (String) params[0];
                                                                                                            Object value = params[1];
                                                                                                            java.lang.reflect.Field field = Dfp.class.getDeclaredField(fieldName);
                                                                                                            field.setAccessible(true);
                                                                                                            field.set(instance, value);
                                                                                                        } catch (Exception e) {
                                                                                                            throw new RuntimeException(e);
                                                                                                        }
                                                                                                    };
                                                                                                    
                                                                                                    // Case 1: Test when only nans == INFINITE (should behave differently in mutant)
                                                                                                    Dfp infiniteDfp = createDfpInstance.apply(new Object[]{mockField, (byte)1, (byte)0});
                                                                                                    setProtectedField.accept(infiniteDfp, new Object[]{"nans", Dfp.INFINITE});
                                                                                                    Dfp result1 = infiniteDfp.newInstance();
                                                                                                    assertNotNull(result1);
                                                                                                    assertEquals(mockField, result1.getField());
                                                                                                    
                                                                                                    // Case 2: Test when x.nans == FINITE and last mantissa digit is 0
                                                                                                    Dfp finiteDfp = createDfpInstance.apply(new Object[]{mockField, (byte)1, (byte)0});
                                                                                                    setProtectedField.accept(finiteDfp, new Object[]{"nans", Dfp.FINITE});
                                                                                                    int[] mant = new int[mockField.getRadixDigits()];
                                                                                                    mant[mant.length-1] = 0;
                                                                                                    setProtectedField.accept(finiteDfp, new Object[]{"mant", mant});
                                                                                                    Dfp result2 = finiteDfp.newInstance();
                                                                                                    assertNotNull(result2);
                                                                                                    assertEquals(mockField, result2.getField());
                                                                                                    
                                                                                                    // Case 3: Test when all conditions are true
                                                                                                    Dfp allConditionsDfp = createDfpInstance.apply(new Object[]{mockField, (byte)1, (byte)0});
                                                                                                    setProtectedField.accept(allConditionsDfp, new Object[]{"nans", Dfp.INFINITE});
                                                                                                    mant = new int[mockField.getRadixDigits()];
                                                                                                    mant[mant.length-1] = 0;
                                                                                                    setProtectedField.accept(allConditionsDfp, new Object[]{"mant", mant});
                                                                                                    Dfp result3 = allConditionsDfp.newInstance();
                                                                                                    assertNotNull(result3);
                                                                                                    assertEquals(mockField, result3.getField());
                                                                                                    
                                                                                                    // Case 4: Test when none of the conditions are true
                                                                                                    Dfp normalDfp = createDfpInstance.apply(new Object[]{mockField, (byte)1, (byte)0});
                                                                                                    setProtectedField.accept(normalDfp, new Object[]{"nans", Dfp.FINITE});
                                                                                                    mant = new int[mockField.getRadixDigits()];
                                                                                                    mant[mant.length-1] = 1; // non-zero last digit
                                                                                                    setProtectedField.accept(normalDfp, new Object[]{"mant", mant});
                                                                                                    Dfp result4 = normalDfp.newInstance();
                                                                                                    assertNotNull(result4);
                                                                                                    assertEquals(mockField, result4.getField());
                                                                                                }

    @Test
                                                                                        public void testNewInstanceSignComparison() throws Exception {
                                                                                            // Create a field to use for testing
                                                                                            DfpField field = new DfpField(20); // Assuming 20 radix digits
                                                                                            
                                                                                            // Get the protected constructor
                                                                                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                            constructor.setAccessible(true);
                                                                                            
                                                                                            // Create test cases with same signs
                                                                                            Dfp positive1 = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                            Dfp positive2 = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                            Dfp negative1 = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                            Dfp negative2 = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                            
                                                                                            // Create test cases with different signs
                                                                                            Dfp mixed1 = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                            Dfp mixed2 = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                            
                                                                                            // Get the sign field using reflection
                                                                                            Field signField = Dfp.class.getDeclaredField("sign");
                                                                                            signField.setAccessible(true);
                                                                                            
                                                                                            // Test same signs - should return same instance (or equal)
                                                                                            Dfp resultSame1 = positive1.newInstance();
                                                                                            Dfp resultSame2 = negative1.newInstance();
                                                                                            assertEquals("Same signs should produce equal result", 1, signField.getByte(resultSame1));
                                                                                            assertEquals("Same signs should produce equal result", -1, signField.getByte(resultSame2));
                                                                                            
                                                                                            // Test different signs - should return different instance
                                                                                            Dfp resultDiff1 = mixed1.newInstance();
                                                                                            Dfp resultDiff2 = mixed2.newInstance();
                                                                                            assertNotEquals("Different signs should produce different results", 
                                                                                                           signField.getByte(resultDiff1), signField.getByte(resultDiff2));
                                                                                            
                                                                                            // Verify the sign comparison logic specifically
                                                                                            byte sign1 = signField.getByte(positive1);
                                                                                            byte sign2 = signField.getByte(positive2);
                                                                                            byte comparisonResultSame = (byte)((sign1 == sign2) ? 1 : -1);
                                                                                            assertEquals("Sign comparison for equal signs should return 1", 
                                                                                                         1, comparisonResultSame);
                                                                                            
                                                                                            sign1 = signField.getByte(mixed1);
                                                                                            sign2 = signField.getByte(mixed2);
                                                                                            byte comparisonResultDiff = (byte)((sign1 == sign2) ? 1 : -1);
                                                                                            assertEquals("Sign comparison for different signs should return -1", 
                                                                                                         -1, comparisonResultDiff);
                                                                                        }

    @Test
                                                                                        public void testNewInstanceSignHandling() throws Exception {
                                                                                            // Create test field
                                                                                            DfpField field = mock(DfpField.class);
                                                                                            
                                                                                            // Get constructor and field access
                                                                                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                            constructor.setAccessible(true);
                                                                                            Field signField = Dfp.class.getDeclaredField("sign");
                                                                                            signField.setAccessible(true);
                                                                                            
                                                                                            // Case 1: Both have same sign (positive)
                                                                                            Dfp originalSameSignPos = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                            Dfp paramSameSignPos = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                            Dfp resultSameSignPos = originalSameSignPos.newInstance(paramSameSignPos);
                                                                                            assertEquals("Same signs (positive) should result in positive", 1, signField.getByte(resultSameSignPos));
                                                                                            
                                                                                            // Case 2: Both have same sign (negative)
                                                                                            Dfp originalSameSignNeg = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                            Dfp paramSameSignNeg = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                            Dfp resultSameSignNeg = originalSameSignNeg.newInstance(paramSameSignNeg);
                                                                                            assertEquals("Same signs (negative) should result in positive", 1, signField.getByte(resultSameSignNeg));
                                                                                            
                                                                                            // Case 3: Different signs (original positive, param negative)
                                                                                            Dfp originalDiffSign1 = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                            Dfp paramDiffSign1 = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                            Dfp resultDiffSign1 = originalDiffSign1.newInstance(paramDiffSign1);
                                                                                            assertEquals("Different signs should result in negative", -1, signField.getByte(resultDiffSign1));
                                                                                            
                                                                                            // Case 4: Different signs (original negative, param positive)
                                                                                            Dfp originalDiffSign2 = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                            Dfp paramDiffSign2 = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                            Dfp resultDiffSign2 = originalDiffSign2.newInstance(paramDiffSign2);
                                                                                            assertEquals("Different signs should result in negative", -1, signField.getByte(resultDiffSign2));
                                                                                        }

    @Test
                                                                                        public void testNewInstanceSignHandling1() throws Exception {
                                                                                            // Create a field for Dfp instances
                                                                                            DfpField field = new DfpField(20); // Using 20 radix digits as an example
                                                                                            
                                                                                            // Get the protected constructor
                                                                                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                            constructor.setAccessible(true);
                                                                                            
                                                                                            // Get the protected sign field
                                                                                            Field signField = Dfp.class.getDeclaredField("sign");
                                                                                            signField.setAccessible(true);
                                                                                            
                                                                                            // Case 1: Both have same sign (positive)
                                                                                            Dfp positiveDfp1 = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                            Dfp positiveDfp2 = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                            Dfp result1 = positiveDfp1.newInstance(positiveDfp2);
                                                                                            assertEquals("Same positive signs should produce positive result", 1, signField.getByte(result1));
                                                                                            
                                                                                            // Case 2: Both have same sign (negative)
                                                                                            Dfp negativeDfp1 = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                            Dfp negativeDfp2 = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                            Dfp result2 = negativeDfp1.newInstance(negativeDfp2);
                                                                                            assertEquals("Same negative signs should produce positive result", 1, signField.getByte(result2));
                                                                                            
                                                                                            // Case 3: Different signs (first positive, second negative)
                                                                                            Dfp positiveDfp3 = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                            Dfp negativeDfp3 = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                            Dfp result3 = positiveDfp3.newInstance(negativeDfp3);
                                                                                            assertEquals("Different signs should produce negative result", -1, signField.getByte(result3));
                                                                                            
                                                                                            // Case 4: Different signs (first negative, second positive)
                                                                                            Dfp negativeDfp4 = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                            Dfp positiveDfp4 = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                            Dfp result4 = negativeDfp4.newInstance(positiveDfp4);
                                                                                            assertEquals("Different signs should produce negative result", -1, signField.getByte(result4));
                                                                                        }

    @Test
                                                                                        public void testNewInstanceSignHandling2() throws Exception {
                                                                                            // Create a field for Dfp instances
                                                                                            DfpField field = new DfpField(20); // Assuming 20 radix digits
                                                                                            
                                                                                            // Get protected constructor
                                                                                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                            constructor.setAccessible(true);
                                                                                            
                                                                                            // Get protected sign field
                                                                                            Field signField = Dfp.class.getDeclaredField("sign");
                                                                                            signField.setAccessible(true);
                                                                                            
                                                                                            // Case 1: Same signs (both positive)
                                                                                            Dfp positiveDfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                            Dfp result1 = positiveDfp.newInstance(positiveDfp);
                                                                                            assertEquals("Same signs should produce positive result", 1, signField.get(result1));
                                                                                            
                                                                                            // Case 2: Same signs (both negative)
                                                                                            Dfp negativeDfp = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                            Dfp result2 = negativeDfp.newInstance(negativeDfp);
                                                                                            assertEquals("Same signs should produce negative result", -1, signField.get(result2));
                                                                                            
                                                                                            // Case 3: Different signs (original positive, parameter negative)
                                                                                            Dfp result3 = positiveDfp.newInstance(negativeDfp);
                                                                                            assertEquals("Different signs should produce negative result", -1, signField.get(result3));
                                                                                            
                                                                                            // Case 4: Different signs (original negative, parameter positive)
                                                                                            Dfp result4 = negativeDfp.newInstance(positiveDfp);
                                                                                            assertEquals("Different signs should produce positive result", 1, signField.get(result4));
                                                                                        }

    @Test
                                                                                        public void testNewInstanceSignHandling3() throws Exception {
                                                                                            // Create a field with default radix digits
                                                                                            DfpField field = new DfpField(10);
                                                                                            
                                                                                            // Get protected constructor
                                                                                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                            constructor.setAccessible(true);
                                                                                            
                                                                                            // Get protected sign field
                                                                                            Field signField = Dfp.class.getDeclaredField("sign");
                                                                                            signField.setAccessible(true);
                                                                                            
                                                                                            // Test case 1: Both positive (signs equal)
                                                                                            Dfp positiveDfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                            Dfp result1 = positiveDfp.newInstance(positiveDfp);
                                                                                            assertEquals("Sign should be positive when both source and target are positive", 
                                                                                                        1, signField.get(result1));
                                                                                            
                                                                                            // Test case 2: Both negative (signs equal)
                                                                                            Dfp negativeDfp = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                            Dfp result2 = negativeDfp.newInstance(negativeDfp);
                                                                                            assertEquals("Sign should be negative when both source and target are negative", 
                                                                                                        -1, signField.get(result2));
                                                                                            
                                                                                            // Test case 3: Different signs (source positive, target negative)
                                                                                            Dfp result3 = positiveDfp.newInstance(negativeDfp);
                                                                                            assertEquals("Sign should be negative when signs differ (positive source, negative target)", 
                                                                                                        -1, signField.get(result3));
                                                                                            
                                                                                            // Test case 4: Different signs (source negative, target positive)
                                                                                            Dfp result4 = negativeDfp.newInstance(positiveDfp);
                                                                                            assertEquals("Sign should be negative when signs differ (negative source, positive target)", 
                                                                                                        -1, signField.get(result4));
                                                                                        }

    @Test
                                                                                        public void testNewInstanceStringSignPropagation() throws Exception {
                                                                                            // Create test field
                                                                                            DfpField field = new DfpField(20); // assuming 20 digits precision
                                                                                            
                                                                                            // Get protected constructor
                                                                                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, String.class);
                                                                                            constructor.setAccessible(true);
                                                                                            
                                                                                            // Get protected sign field
                                                                                            Field signField = Dfp.class.getDeclaredField("sign");
                                                                                            signField.setAccessible(true);
                                                                                            
                                                                                            // Test case 1: Positive string with positive sign
                                                                                            Dfp positiveDfp = constructor.newInstance(field, "123.456");
                                                                                            Dfp result1 = positiveDfp.newInstance("789.012");
                                                                                            assertEquals("Positive from positive should keep positive sign", 
                                                                                                         1, signField.getInt(result1));
                                                                                            
                                                                                            // Test case 2: Negative string with negative sign
                                                                                            Dfp negativeDfp = constructor.newInstance(field, "-123.456");
                                                                                            Dfp result2 = negativeDfp.newInstance("-789.012");
                                                                                            assertEquals("Negative from negative should keep negative sign", 
                                                                                                         -1, signField.getInt(result2));
                                                                                            
                                                                                            // Test case 3: Positive string with negative sign
                                                                                            Dfp result3 = negativeDfp.newInstance("789.012");
                                                                                            assertEquals("Positive from negative should have positive sign", 
                                                                                                         1, signField.getInt(result3));
                                                                                            
                                                                                            // Test case 4: Negative string with positive sign
                                                                                            Dfp result4 = positiveDfp.newInstance("-789.012");
                                                                                            assertEquals("Negative from positive should have negative sign", 
                                                                                                         -1, signField.getInt(result4));
                                                                                            
                                                                                            // Test case 5: Special case - zero
                                                                                            Dfp zeroDfp = constructor.newInstance(field, "0");
                                                                                            Dfp result5 = zeroDfp.newInstance("0");
                                                                                            assertEquals("Zero from zero should keep positive sign", 
                                                                                                         1, signField.getInt(result5));
                                                                                        }

    @Test
                                                                                        public void testNewInstanceSignComparison1() throws Exception {
                                                                                            // Setup test field
                                                                                            DfpField field = new DfpField(10);
                                                                                            
                                                                                            // Get constructor and field access via reflection
                                                                                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                            constructor.setAccessible(true);
                                                                                            
                                                                                            Field signField = Dfp.class.getDeclaredField("sign");
                                                                                            signField.setAccessible(true);
                                                                                            Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                            nansField.setAccessible(true);
                                                                                            
                                                                                            // Test case 1: Same signs should produce positive result in original
                                                                                            Dfp sameSign1 = constructor.newInstance(field, (byte)1, Dfp.FINITE); // positive
                                                                                            Dfp sameSign2 = constructor.newInstance(field, (byte)1, Dfp.FINITE); // positive
                                                                                            Dfp resultSame = sameSign1.newInstance((byte)signField.get(sameSign1), (byte)nansField.get(sameSign2));
                                                                                            assertEquals("Same signs should produce positive result", 1, signField.get(resultSame));
                                                                                            
                                                                                            // Test case 2: Different signs should produce negative result in original
                                                                                            Dfp diffSign1 = constructor.newInstance(field, (byte)1, Dfp.FINITE);  // positive
                                                                                            Dfp diffSign2 = constructor.newInstance(field, (byte)-1, Dfp.FINITE); // negative
                                                                                            Dfp resultDiff = diffSign1.newInstance((byte)signField.get(diffSign1), (byte)nansField.get(diffSign2));
                                                                                            assertEquals("Different signs should produce negative result", -1, signField.get(resultDiff));
                                                                                        }

    @Test
                                                                                    public void testNewInstanceDfpSignHandling() throws Exception {
                                                                                        // Setup test field
                                                                                        DfpField field = new DfpField(10); // Using arbitrary radix digits
                                                                                        
                                                                                        // Create test cases for both same and different signs
                                                                                        // Case 1: Same signs (both positive)
                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                            DfpField.class, byte.class, byte.class);
                                                                                        constructor.setAccessible(true);
                                                                                        Dfp positiveDfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                        Dfp copiedPositive = positiveDfp.newInstance(positiveDfp);
                                                                                        Field signField = Dfp.class.getDeclaredField("sign");
                                                                                        signField.setAccessible(true);
                                                                                        assertEquals("Copied Dfp with same signs should have sign 1", 
                                                                                                    1, signField.getByte(copiedPositive));
                                                                                        
                                                                                        // Case 2: Same signs (both negative)
                                                                                        Dfp negativeDfp = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                        Dfp copiedNegative = negativeDfp.newInstance(negativeDfp);
                                                                                        assertEquals("Copied Dfp with same signs should have sign -1", 
                                                                                                    -1, signField.getByte(copiedNegative));
                                                                                        
                                                                                        // Case 3: Different signs (original positive, source negative)
                                                                                        Dfp originalPositive = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                        Dfp sourceNegative = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                        Dfp copiedDifferent1 = originalPositive.newInstance(sourceNegative);
                                                                                        assertEquals("Copied Dfp with different signs should have sign -1", 
                                                                                                    -1, signField.getByte(copiedDifferent1));
                                                                                        
                                                                                        // Case 4: Different signs (original negative, source positive)
                                                                                        Dfp originalNegative = constructor.newInstance(field, (byte)-1, Dfp.FINITE);
                                                                                        Dfp sourcePositive = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                        Dfp copiedDifferent2 = originalNegative.newInstance(sourcePositive);
                                                                                        assertEquals("Copied Dfp with different signs should have sign -1", 
                                                                                                    -1, signField.getByte(copiedDifferent2));
                                                                                    }

    @Test
                                                                            public void testNewInstanceWithDifferentNansValues() throws Exception {
                                                                                // Create a mock field
                                                                                DfpField mockField = mock(DfpField.class);
                                                                                when(mockField.getRadixDigits()).thenReturn(1); // Need to mock this as it's used in constructor
                                                                                
                                                                                // Get protected constructor
                                                                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                constructor.setAccessible(true);
                                                                                
                                                                                // Get protected nans field
                                                                                Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                nansField.setAccessible(true);
                                                                                
                                                                                // Test case 1: Current instance is FINITE
                                                                                Dfp finiteDfp = constructor.newInstance(mockField, (byte)1, (byte)Dfp.FINITE);
                                                                                Dfp newFiniteInstance = finiteDfp.newInstance();
                                                                                assertNotNull(newFiniteInstance);
                                                                                assertEquals(Dfp.FINITE, nansField.get(newFiniteInstance));
                                                                                
                                                                                // Test case 2: Current instance is INFINITE
                                                                                Dfp infiniteDfp = constructor.newInstance(mockField, (byte)1, (byte)Dfp.INFINITE);
                                                                                Dfp newInfiniteInstance = infiniteDfp.newInstance();
                                                                                assertNotNull(newInfiniteInstance);
                                                                                assertEquals(Dfp.INFINITE, nansField.get(newInfiniteInstance));
                                                                                
                                                                                // Test case 3: Current instance is QNAN
                                                                                Dfp nanDfp = constructor.newInstance(mockField, (byte)1, (byte)Dfp.QNAN);
                                                                                Dfp newNanInstance = nanDfp.newInstance();
                                                                                assertNotNull(newNanInstance);
                                                                                assertEquals(Dfp.QNAN, nansField.get(newNanInstance));
                                                                                
                                                                                // Verify that the field was used correctly in all cases
                                                                                verify(mockField, times(3)).getRadixDigits();
                                                                            }

    @Test
                                                                            public void testNewInstanceWithNonFiniteValues() throws Exception {
                                                                                // Create a mock field
                                                                                DfpField mockField = mock(DfpField.class);
                                                                                
                                                                                // Use reflection to access protected constructor
                                                                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                    DfpField.class, byte.class, byte.class);
                                                                                constructor.setAccessible(true);
                                                                                
                                                                                // Create a non-finite DFP (INFINITE)
                                                                                Dfp nonFiniteDfp = constructor.newInstance(mockField, (byte)1, Dfp.INFINITE);
                                                                                Dfp newInstance = nonFiniteDfp.newInstance();
                                                                                
                                                                                // Use reflection to access protected nans field
                                                                                Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                nansField.setAccessible(true);
                                                                                byte newInstanceNans = (byte) nansField.get(newInstance);
                                                                                
                                                                                // The original code would properly create a new instance
                                                                                // The mutant would fail to properly handle the non-finite case
                                                                                assertNotNull(newInstance);
                                                                                assertEquals(Dfp.INFINITE, newInstanceNans);
                                                                            }

    @Test
                                                                            public void testNewInstanceWithFiniteCurrentAndNonFiniteParameter() {
                                                                                // Create mock field
                                                                                DfpField mockField = mock(DfpField.class);
                                                                                
                                                                                // Create FINITE current object using protected constructor via reflection
                                                                                Dfp current;
                                                                                try {
                                                                                    Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
                                                                                    constructor.setAccessible(true);
                                                                                    current = constructor.newInstance(mockField, 1.0);
                                                                                } catch (Exception e) {
                                                                                    throw new RuntimeException("Failed to create Dfp instance", e);
                                                                                }
                                                                                
                                                                                // Create non-FINITE parameter (INFINITE) using protected constructor via reflection
                                                                                Dfp infiniteParam;
                                                                                try {
                                                                                    Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                    constructor.setAccessible(true);
                                                                                    infiniteParam = constructor.newInstance(mockField, (byte)1, Dfp.INFINITE);
                                                                                } catch (Exception e) {
                                                                                    throw new RuntimeException("Failed to create infinite Dfp instance", e);
                                                                                }
                                                                                
                                                                                // Call the method
                                                                                Dfp result = current.newInstance(infiniteParam);
                                                                                
                                                                                // Verify the result is not just a copy when parameter is non-FINITE
                                                                                // Access protected field via reflection
                                                                                try {
                                                                                    Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                    nansField.setAccessible(true);
                                                                                    byte resultNans = (byte) nansField.get(result);
                                                                                    assertEquals("Result should equal parameter's non-FINITE status",
                                                                                                Dfp.INFINITE, resultNans);
                                                                                } catch (Exception e) {
                                                                                    throw new RuntimeException("Failed to access nans field", e);
                                                                                }
                                                                            }

    @Test
                                                                            public void testNewInstanceWithDfpCatchesMutant() throws Exception {
                                                                                // Create a field for testing
                                                                                DfpField field = new DfpField(20); // assuming 20 radix digits
                                                                                
                                                                                // Get protected constructors via reflection
                                                                                Constructor<Dfp> doubleConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
                                                                                doubleConstructor.setAccessible(true);
                                                                                Constructor<Dfp> nanConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                nanConstructor.setAccessible(true);
                                                                                
                                                                                // Case 1: Both FINITE - should proceed normally
                                                                                Dfp finite1 = doubleConstructor.newInstance(field, 1.0);
                                                                                Dfp finite2 = doubleConstructor.newInstance(field, 2.0);
                                                                                Dfp result1 = finite1.newInstance(finite2);
                                                                                assertEquals(2.0, result1.toDouble(), 0.0001);
                                                                                
                                                                                // Case 2: this not FINITE, x FINITE - should be handled specially
                                                                                // This is the key case to catch the mutant
                                                                                Dfp nonFinite1 = nanConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                Dfp finite3 = doubleConstructor.newInstance(field, 3.0);
                                                                                Dfp result2 = nonFinite1.newInstance(finite3);
                                                                                assertTrue(result2.isInfinite()); // Should be infinite
                                                                                
                                                                                // Case 3: this FINITE, x not FINITE - should be handled specially
                                                                                Dfp finite4 = doubleConstructor.newInstance(field, 4.0);
                                                                                Dfp nonFinite2 = nanConstructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                                                Dfp result3 = finite4.newInstance(nonFinite2);
                                                                                assertTrue(result3.isNaN());
                                                                                
                                                                                // Case 4: Both not FINITE - should be handled specially
                                                                                Dfp nonFinite3 = nanConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                Dfp nonFinite4 = nanConstructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                                                Dfp result4 = nonFinite3.newInstance(nonFinite4);
                                                                                assertTrue(result4.isNaN()); // QNAN should take precedence
                                                                            }

    @Test
                                                                            public void testNewInstanceWithNonFiniteCurrentObject() throws Exception {
                                                                                // Create a mock field
                                                                                DfpField mockField = mock(DfpField.class);
                                                                                
                                                                                // Get the protected constructor using reflection
                                                                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                    DfpField.class, byte.class, byte.class);
                                                                                constructor.setAccessible(true);
                                                                                
                                                                                // Create current object with non-FINITE nans (INFINITE)
                                                                                Dfp current = constructor.newInstance(mockField, (byte)1, Dfp.INFINITE);
                                                                                
                                                                                // Create parameter with FINITE nans
                                                                                Dfp param = constructor.newInstance(mockField, (byte)1, Dfp.FINITE);
                                                                                
                                                                                // Call the method - in original, this should handle non-FINITE case
                                                                                // In mutant, it won't handle because nans == FINITE is false
                                                                                Dfp result = current.newInstance(param);
                                                                                
                                                                                // Verify the behavior difference
                                                                                // Original would handle non-FINITE case differently than mutant
                                                                                // We can check if the result is properly created despite the non-FINITE current object
                                                                                assertNotNull(result);
                                                                                assertEquals(mockField, result.getField());
                                                                                
                                                                                // Additional checks to ensure proper handling
                                                                                // In original, the non-FINITE status might be propagated
                                                                                // In mutant, it might treat it as FINITE incorrectly
                                                                                assertTrue("Original should handle non-FINITE current object properly", 
                                                                                           current.isInfinite() || result.isInfinite());
                                                                            }

    @Test
                                                                            public void testNewInstanceWithNonFiniteParameter() throws Exception {
                                                                                // Create a mock field
                                                                                DfpField mockField = mock(DfpField.class);
                                                                                
                                                                                // Get the protected constructor
                                                                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                    DfpField.class, byte.class, byte.class
                                                                                );
                                                                                constructor.setAccessible(true);
                                                                                
                                                                                // Create current object with FINITE nans
                                                                                Dfp current = constructor.newInstance(mockField, (byte)1, Dfp.FINITE);
                                                                                
                                                                                // Create parameter with non-FINITE nans (INFINITE)
                                                                                Dfp param = constructor.newInstance(mockField, (byte)1, Dfp.INFINITE);
                                                                                
                                                                                // Call the method - both original and mutant should handle this
                                                                                Dfp result = current.newInstance(param);
                                                                                
                                                                                // Verify the behavior
                                                                                assertNotNull(result);
                                                                                assertEquals(mockField, result.getField());
                                                                                assertTrue(result.isInfinite());
                                                                            }

    @Test
                                                                            public void testNewInstanceWithBothNonFinite() throws Exception {
                                                                                // Create a mock field
                                                                                DfpField mockField = mock(DfpField.class);
                                                                                
                                                                                // Get the protected constructor
                                                                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                    DfpField.class, byte.class, byte.class
                                                                                );
                                                                                constructor.setAccessible(true);
                                                                                
                                                                                // Create current object with non-FINITE nans (QNAN)
                                                                                Dfp current = constructor.newInstance(mockField, (byte)1, Dfp.QNAN);
                                                                                
                                                                                // Create parameter with non-FINITE nans (INFINITE)
                                                                                Dfp param = constructor.newInstance(mockField, (byte)1, Dfp.INFINITE);
                                                                                
                                                                                // Call the method - both original and mutant should handle this
                                                                                Dfp result = current.newInstance(param);
                                                                                
                                                                                // Verify the behavior
                                                                                assertNotNull(result);
                                                                                assertEquals(mockField, result.getField());
                                                                                assertTrue(result.isNaN()); // Should be QNAN
                                                                            }

    @Test
                                                                            public void testNewInstanceWithNonFiniteCurrentObject1() throws Exception {
                                                                                // Create a field mock
                                                                                DfpField field = mock(DfpField.class);
                                                                                
                                                                                // Create a finite Dfp object (input) using reflection to access protected constructor
                                                                                Constructor<Dfp> doubleConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
                                                                                doubleConstructor.setAccessible(true);
                                                                                Dfp finiteInput = doubleConstructor.newInstance(field, 1.0);
                                                                                
                                                                                // Create a non-finite current object (QNAN) using reflection
                                                                                Constructor<Dfp> nanConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                nanConstructor.setAccessible(true);
                                                                                Dfp nonFiniteCurrent = nanConstructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                                                
                                                                                // The original code should handle non-finite current object specially
                                                                                // The mutant will not handle it specially when input is finite
                                                                                Dfp result = nonFiniteCurrent.newInstance(finiteInput);
                                                                                
                                                                                // Verify the result is handled as a special case (should be QNAN)
                                                                                assertTrue(result.isNaN());
                                                                                
                                                                                // Additional verification that it's not just creating a copy
                                                                                assertNotEquals(finiteInput, result);
                                                                                
                                                                                // Verify the nans field is properly set using reflection
                                                                                Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                nansField.setAccessible(true);
                                                                                byte nansValue = (byte) nansField.get(result);
                                                                                assertEquals(Dfp.QNAN, nansValue);
                                                                            }

    @Test
                                                                            public void testNewInstanceWithNonFiniteDfp() throws Exception {
                                                                                // Create a mock DfpField
                                                                                DfpField field = mock(DfpField.class);
                                                                                when(field.getRadixDigits()).thenReturn(10); // arbitrary number
                                                                                
                                                                                // Get protected constructor for non-finite Dfp (NaN)
                                                                                Constructor<Dfp> nonFiniteConstructor = Dfp.class.getDeclaredConstructor(
                                                                                    DfpField.class, byte.class, byte.class);
                                                                                nonFiniteConstructor.setAccessible(true);
                                                                                Dfp nonFiniteDfp = nonFiniteConstructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                                                
                                                                                // Get protected constructor for finite Dfp from string
                                                                                Constructor<Dfp> stringConstructor = Dfp.class.getDeclaredConstructor(
                                                                                    DfpField.class, String.class);
                                                                                stringConstructor.setAccessible(true);
                                                                                Dfp finiteDfp = stringConstructor.newInstance(field, "1.23");
                                                                                
                                                                                // Test behavior when creating new instance from non-finite Dfp
                                                                                Dfp result1 = nonFiniteDfp.newInstance(finiteDfp);
                                                                                // Should preserve NaN status
                                                                                assertTrue(result1.isNaN());
                                                                                
                                                                                // Test behavior when creating new instance from finite Dfp with non-finite source
                                                                                Dfp result2 = finiteDfp.newInstance(nonFiniteDfp);
                                                                                // Should also preserve NaN status
                                                                                assertTrue(result2.isNaN());
                                                                                
                                                                                // The mutant would fail these tests because:
                                                                                // For result1: nans==QNAN (non-finite), x.nans==FINITE
                                                                                // Original: (true || false) -> executes block (correct)
                                                                                // Mutant: (false || false) -> skips block (wrong)
                                                                            }

    @Test
                                                                            public void testNewInstanceWithFiniteCurrentAndNonFiniteOther() {
                                                                                // Create a mock DfpField
                                                                                DfpField field = mock(DfpField.class);
                                                                                
                                                                                // Create a non-finite Dfp object to use as other
                                                                                Dfp nonFiniteDfp = mock(Dfp.class);
                                                                                when(nonFiniteDfp.isInfinite()).thenReturn(true);
                                                                                when(nonFiniteDfp.getField()).thenReturn(field);
                                                                                
                                                                                // Create test cases where current object is finite
                                                                                Dfp finiteDfp = mock(Dfp.class);
                                                                                when(finiteDfp.isInfinite()).thenReturn(false);
                                                                                when(finiteDfp.getField()).thenReturn(field);
                                                                                
                                                                                // Mock the field's newDfp method to return a specific value
                                                                                Dfp expectedResult = mock(Dfp.class);
                                                                                when(expectedResult.isInfinite()).thenReturn(true);
                                                                                when(field.newDfp(anyByte(), anyByte())).thenReturn(expectedResult);
                                                                                
                                                                                // Call the method - should trigger condition in both original and mutant
                                                                                Dfp result = finiteDfp.newInstance((byte)1, Dfp.INFINITE);
                                                                                
                                                                                // Verify the interaction
                                                                                verify(field).newDfp((byte)1, Dfp.INFINITE);
                                                                                
                                                                                // Additional assertion to ensure correct behavior
                                                                                assertEquals(expectedResult, result);
                                                                            }

    @Test
                                                                        public void testNewInstanceWithDifferentNaNStates() throws Exception {
                                                                            // Get QNAN and FINITE constants via reflection
                                                                            Class<?> dfpClass = Class.forName("org.apache.commons.math3.dfp.Dfp");
                                                                            byte QNAN = dfpClass.getField("QNAN").getByte(null);
                                                                            byte FINITE = dfpClass.getField("FINITE").getByte(null);
                                                                            
                                                                            // Setup fields with same radix digits
                                                                            DfpField field1 = mock(DfpField.class);
                                                                            when(field1.getRadixDigits()).thenReturn(10);
                                                                            DfpField field2 = mock(DfpField.class);
                                                                            when(field2.getRadixDigits()).thenReturn(10);
                                                                            
                                                                            // Get constructors via reflection
                                                                            Constructor<?> dfpConstructor = dfpClass.getDeclaredConstructor(
                                                                                DfpField.class, byte.class, byte.class);
                                                                            dfpConstructor.setAccessible(true);
                                                                            
                                                                            Constructor<?> dfpDoubleConstructor = dfpClass.getDeclaredConstructor(
                                                                                DfpField.class, double.class);
                                                                            dfpDoubleConstructor.setAccessible(true);
                                                                            
                                                                            // Case 1: Current is QNAN, input is FINITE - should trigger in original but not mutant
                                                                            Dfp dfp1 = (Dfp) dfpConstructor.newInstance(field1, (byte)1, QNAN);
                                                                            Dfp input1 = (Dfp) dfpDoubleConstructor.newInstance(field2, 1.0);
                                                                            Dfp result1 = dfp1.newInstance(input1);
                                                                            // Original would return QNAN, mutant would return copy
                                                                            Field nansField = dfpClass.getDeclaredField("nans");
                                                                            nansField.setAccessible(true);
                                                                            assertNotEquals("QNAN should be returned when current is QNAN", 
                                                                                            FINITE, nansField.getByte(result1));
                                                                            
                                                                            // Case 2: Current is FINITE, input is QNAN - should trigger in both
                                                                            Dfp dfp2 = (Dfp) dfpDoubleConstructor.newInstance(field1, 1.0);
                                                                            Dfp input2 = (Dfp) dfpConstructor.newInstance(field2, (byte)1, QNAN);
                                                                            Dfp result2 = dfp2.newInstance(input2);
                                                                            assertEquals("QNAN should be returned when input is QNAN", 
                                                                                         QNAN, nansField.getByte(result2));
                                                                            
                                                                            // Case 3: Both are FINITE - should not trigger
                                                                            Dfp dfp3 = (Dfp) dfpDoubleConstructor.newInstance(field1, 1.0);
                                                                            Dfp input3 = (Dfp) dfpDoubleConstructor.newInstance(field2, 1.0);
                                                                            Dfp result3 = dfp3.newInstance(input3);
                                                                            assertEquals("Should create normal copy when both are finite", 
                                                                                         FINITE, nansField.getByte(result3));
                                                                            
                                                                            // Case 4: Both are QNAN - should trigger in both
                                                                            Dfp dfp4 = (Dfp) dfpConstructor.newInstance(field1, (byte)1, QNAN);
                                                                            Dfp input4 = (Dfp) dfpConstructor.newInstance(field2, (byte)1, QNAN);
                                                                            Dfp result4 = dfp4.newInstance(input4);
                                                                            assertEquals("QNAN should be returned when both are QNAN", 
                                                                                         QNAN, nansField.getByte(result4));
                                                                        }

    @Test
                                                                        public void testNewInstanceWithNonFiniteCurrentAndFiniteOther() {
                                                                            // Create a mock DfpField
                                                                            DfpField field = mock(DfpField.class);
                                                                            
                                                                            // Create a finite Dfp object to use as other using reflection to access protected constructor
                                                                            Dfp finiteDfp;
                                                                            try {
                                                                                Constructor<Dfp> doubleConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
                                                                                doubleConstructor.setAccessible(true);
                                                                                finiteDfp = doubleConstructor.newInstance(field, 1.0);
                                                                            } catch (Exception e) {
                                                                                throw new RuntimeException("Failed to create finite Dfp instance", e);
                                                                            }
                                                                            
                                                                            // Create test cases where current object is non-finite (INFINITE)
                                                                            Dfp infiniteDfp;
                                                                            try {
                                                                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                    DfpField.class, byte.class, byte.class);
                                                                                constructor.setAccessible(true);
                                                                                infiniteDfp = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                            } catch (Exception e) {
                                                                                throw new RuntimeException("Failed to create infinite Dfp instance", e);
                                                                            }
                                                                            
                                                                            // Mock the field's newDfp method to return a specific value
                                                                            Dfp expectedResult;
                                                                            try {
                                                                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                    DfpField.class, byte.class, byte.class);
                                                                                constructor.setAccessible(true);
                                                                                expectedResult = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                            } catch (Exception e) {
                                                                                throw new RuntimeException("Failed to create expected Dfp instance", e);
                                                                            }
                                                                            
                                                                            when(field.newDfp(anyByte(), anyByte())).thenReturn(expectedResult);
                                                                            
                                                                            // Call the method - in original code this should trigger the condition
                                                                            // but in mutant it won't
                                                                            Dfp result = infiniteDfp.newInstance((byte)1, Dfp.FINITE);
                                                                            
                                                                            // Verify the interaction - should only happen in original code
                                                                            verify(field).newDfp((byte)1, Dfp.FINITE);
                                                                            
                                                                            // Additional assertion to ensure correct behavior
                                                                            assertEquals(expectedResult, result);
                                                                        }

    @Test
                                                                public void testNewInstanceWithNonFiniteCurrentAndFiniteParameter() throws Exception {
                                                                    // Create mock field
                                                                    DfpField mockField = mock(DfpField.class);
                                                                    
                                                                    // Use reflection to create non-FINITE current object (QNAN)
                                                                    Constructor<Dfp> protectedConstructor = Dfp.class.getDeclaredConstructor(
                                                                        DfpField.class, byte.class, byte.class
                                                                    );
                                                                    protectedConstructor.setAccessible(true);
                                                                    Dfp current = protectedConstructor.newInstance(mockField, (byte)1, (byte)1); // Using QNAN value (1)
                                                                    
                                                                    // Create FINITE parameter using available constructor
                                                                    Constructor<Dfp> doubleConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
                                                                    doubleConstructor.setAccessible(true);
                                                                    Dfp finiteParam = doubleConstructor.newInstance(mockField, 1.0);
                                                                    
                                                                    // Call the method
                                                                    Dfp result = current.newInstance(finiteParam);
                                                                    
                                                                    // Use reflection to verify nans field
                                                                    Field nansField = Dfp.class.getDeclaredField("nans");
                                                                    nansField.setAccessible(true);
                                                                    byte finiteParamNans = (byte) nansField.get(finiteParam);
                                                                    byte resultNans = (byte) nansField.get(result);
                                                                    
                                                                    // Verify the result is not just a copy when current is non-FINITE
                                                                    assertNotEquals("Result should not equal parameter when current is non-FINITE", 
                                                                                  finiteParamNans, resultNans);
                                                                    
                                                                    // Additional verification that the result is a QNAN like the current object
                                                                    assertEquals("Result should maintain current object's non-FINITE status",
                                                                                (byte)1, resultNans); // Using QNAN value (1)
                                                                }

    @Test
                                                            public void testNewInstanceWithBothFinite() {
                                                                // Create a mock field
                                                                DfpField mockField = mock(DfpField.class);
                                                                when(mockField.getRadixDigits()).thenReturn(4); // Need to mock this method call
                                                                
                                                                // Create current object with FINITE nans using reflection
                                                                Dfp current = null;
                                                                try {
                                                                    Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                    constructor.setAccessible(true);
                                                                    current = constructor.newInstance(mockField, (byte)1, (byte)0); // Using 0 for FINITE
                                                                } catch (Exception e) {
                                                                    fail("Failed to create Dfp instance via reflection");
                                                                }
                                                                
                                                                // Create parameter with FINITE nans using available constructor
                                                                Dfp param = null;
                                                                try {
                                                                    Constructor<Dfp> paramConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                    paramConstructor.setAccessible(true);
                                                                    param = paramConstructor.newInstance(mockField, (byte)1, (byte)0);
                                                                    
                                                                    Field mantField = Dfp.class.getDeclaredField("mant");
                                                                    mantField.setAccessible(true);
                                                                    int[] mantissa = new int[mockField.getRadixDigits()];
                                                                    mantissa[0] = 123;  // Simplified representation
                                                                    mantField.set(param, mantissa);
                                                                    
                                                                    Field expField = Dfp.class.getDeclaredField("exp");
                                                                    expField.setAccessible(true);
                                                                    expField.set(param, 0);
                                                                    
                                                                    Field nansField = Dfp.class.getDeclaredField("nans");
                                                                    nansField.setAccessible(true);
                                                                    nansField.set(param, (byte)0); // Using 0 for FINITE
                                                                } catch (Exception e) {
                                                                    fail("Failed to create and setup parameter Dfp instance via reflection");
                                                                }
                                                                
                                                                // Call the method - neither original nor mutant should handle specially
                                                                Dfp result = current.newInstance(param);
                                                                
                                                                // Verify the behavior
                                                                assertNotNull(result);
                                                                assertEquals(mockField, result.getField());
                                                                assertFalse(result.isInfinite());
                                                                assertFalse(result.isNaN());
                                                                assertEquals(123, result.intValue()); // Using intValue() instead of longValue()
                                                            }

    @Test
                                                    public void testNewInstanceWithInfiniteAndFiniteValues() throws Exception {
                                                        // Create test field
                                                        DfpField field = new DfpField(10); // assuming 10 digits
                                                        
                                                        // Get constructor for Dfp(DfpField, byte, byte)
                                                        Constructor<Dfp> infConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                        infConstructor.setAccessible(true);
                                                        
                                                        // Case 1: nans == INFINITE, others false - should behave differently in mutant
                                                        Dfp infiniteDfp = infConstructor.newInstance(field, (byte)1, (byte)Dfp.INFINITE);
                                                        
                                                        // Access mantissa array via reflection
                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                        mantField.setAccessible(true);
                                                        int[] mant = (int[]) mantField.get(infiniteDfp);
                                                        mant[mant.length-1] = 1; // non-zero last mantissa
                                                        
                                                        // Create finite dfp with non-zero last mantissa
                                                        Dfp finiteDfp = field.newDfp(1.0);
                                                        mant = (int[]) mantField.get(finiteDfp);
                                                        mant[mant.length-1] = 1;
                                                        
                                                        // Test case that catches the mutant
                                                        Dfp result1 = infiniteDfp.newInstance(finiteDfp);
                                                        
                                                        // Verify the new instance is properly created
                                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                                        nansField.setAccessible(true);
                                                        assertEquals(Dfp.INFINITE, nansField.get(result1));
                                                        
                                                        Field signField = Dfp.class.getDeclaredField("sign");
                                                        signField.setAccessible(true);
                                                        assertEquals(signField.get(infiniteDfp), signField.get(result1));
                                                        
                                                        assertArrayEquals((int[]) mantField.get(infiniteDfp), (int[]) mantField.get(result1));
                                                        
                                                        // Case 2: x.nans == FINITE and last mantissa is 0, but nans != INFINITE
                                                        Dfp finiteDfp2 = field.newDfp(1.0);
                                                        mant = (int[]) mantField.get(finiteDfp2);
                                                        mant[mant.length-1] = 0;
                                                        Dfp regularDfp = field.newDfp(2.0);
                                                        
                                                        Dfp result2 = regularDfp.newInstance(finiteDfp2);
                                                        assertEquals(Dfp.FINITE, nansField.get(result2));
                                                        assertEquals(signField.get(regularDfp), signField.get(result2));
                                                        assertArrayEquals((int[]) mantField.get(regularDfp), (int[]) mantField.get(result2));
                                                        
                                                        // Case 3: All conditions true
                                                        Dfp infiniteDfp2 = infConstructor.newInstance(field, (byte)1, (byte)Dfp.INFINITE);
                                                        Dfp finiteDfp3 = field.newDfp(1.0);
                                                        mant = (int[]) mantField.get(finiteDfp3);
                                                        mant[mant.length-1] = 0;
                                                        
                                                        Dfp result3 = infiniteDfp2.newInstance(finiteDfp3);
                                                        assertEquals(Dfp.INFINITE, nansField.get(result3));
                                                        assertEquals(signField.get(infiniteDfp2), signField.get(result3));
                                                        assertArrayEquals((int[]) mantField.get(infiniteDfp2), (int[]) mantField.get(result3));
                                                    }

    @Test
                                                    public void testNewInstanceWithMutantCondition() throws Exception {
                                                        // Create test field
                                                        DfpField field = new DfpField(20); // assuming 20 radix digits
                                                        
                                                        // Get protected constructor and field access
                                                        Constructor<Dfp> protectedConstructor = Dfp.class.getDeclaredConstructor(
                                                            DfpField.class, byte.class, byte.class);
                                                        protectedConstructor.setAccessible(true);
                                                        
                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                        mantField.setAccessible(true);
                                                        
                                                        // Case 1: nans == INFINITE, x.nans != FINITE
                                                        Dfp infiniteDfp = protectedConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                        Dfp nonFiniteDfp = protectedConstructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                        int[] nonFiniteMant = (int[]) mantField.get(nonFiniteDfp);
                                                        nonFiniteMant[nonFiniteMant.length-1] = 1; // ensure last mantissa digit not 0
                                                        Dfp result1 = infiniteDfp.newInstance(nonFiniteDfp);
                                                        // Original would not pass condition, mutant would
                                                        assertFalse(result1.isNaN()); // Verify behavior differs
                                                        
                                                        // Case 2: nans != INFINITE, x.nans == FINITE and last mantissa digit is 0
                                                        Dfp finiteDfp1 = protectedConstructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                        int[] finiteMant1 = (int[]) mantField.get(finiteDfp1);
                                                        finiteMant1[finiteMant1.length-1] = 0; // set last mantissa digit to 0
                                                        Dfp finiteDfp2 = protectedConstructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                        Dfp result2 = finiteDfp1.newInstance(finiteDfp2);
                                                        
                                                        // Case 3: nans == INFINITE, x.nans == FINITE, last mantissa digit is 0
                                                        Dfp infiniteDfp2 = protectedConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                        Dfp finiteDfp3 = protectedConstructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                        int[] finiteMant3 = (int[]) mantField.get(finiteDfp3);
                                                        finiteMant3[finiteMant3.length-1] = 0;
                                                        Dfp result3 = infiniteDfp2.newInstance(finiteDfp3);
                                                        
                                                        // Basic assertions
                                                        assertNotNull(result1);
                                                        assertNotNull(result2);
                                                        assertNotNull(result3);
                                                        
                                                        // Additional assertions to verify correct copying behavior
                                                        int[] result2Mant = (int[]) mantField.get(result2);
                                                        int[] finiteDfp2Mant = (int[]) mantField.get(finiteDfp2);
                                                        assertEquals(finiteDfp2Mant[finiteDfp2Mant.length-1], 
                                                                   result2Mant[result2Mant.length-1]);
                                                                   
                                                        int[] result3Mant = (int[]) mantField.get(result3);
                                                        int[] finiteDfp3Mant = (int[]) mantField.get(finiteDfp3);
                                                        assertEquals(finiteDfp3Mant[finiteDfp3Mant.length-1], 
                                                                   result3Mant[result3Mant.length-1]);
                                                    }

    @Test
                                                    public void testNewInstanceDetectsMutant2() throws Exception {
                                                        // Create test field
                                                        DfpField field = new DfpField(10); // assuming 10 radix digits
                                                        
                                                        // Get protected constructor and field access
                                                        Constructor<Dfp> dfpConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                        dfpConstructor.setAccessible(true);
                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                        mantField.setAccessible(true);
                                                        
                                                        // Case 1: Current is INFINITE, x is not FINITE (should behave differently)
                                                        Dfp infiniteDfp = dfpConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                        Dfp nanDfp = dfpConstructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                        int[] nonZeroMant = new int[field.getRadixDigits()];
                                                        nonZeroMant[nonZeroMant.length-1] = 1; // last digit not zero
                                                        mantField.set(nanDfp, nonZeroMant);
                                                        
                                                        // In original: shouldn't match condition
                                                        // In mutant: will match because first part of OR is true
                                                        Dfp result1 = infiniteDfp.newInstance(nanDfp);
                                                        assertFalse(result1.isNaN()); // Should remain INFINITE in original
                                                        
                                                        // Case 2: Current is FINITE, x is FINITE with last mantissa digit 0
                                                        Dfp finiteDfp = dfpConstructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                        Dfp finiteZeroEndDfp = dfpConstructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                        int[] zeroEndMant = new int[field.getRadixDigits()];
                                                        zeroEndMant[zeroEndMant.length-1] = 0; // last digit zero
                                                        mantField.set(finiteZeroEndDfp, zeroEndMant);
                                                        
                                                        // In original: shouldn't match condition (first part false)
                                                        // In mutant: will match because second part of OR is true
                                                        Dfp result2 = finiteDfp.newInstance(finiteZeroEndDfp);
                                                        assertFalse(result2.isNaN()); // Should remain FINITE in original
                                                        
                                                        // Case 3: Current is INFINITE, x is FINITE with last mantissa digit 0
                                                        // Should match in both original and mutant
                                                        Dfp result3 = infiniteDfp.newInstance(finiteZeroEndDfp);
                                                        assertFalse(result3.isNaN());
                                                    }

    @Test
                                                    public void testNewInstanceWithInfiniteDfp() throws Exception {
                                                        // Create test field
                                                        DfpField field = new DfpField(20); // assuming 20 digits
                                                        
                                                        // Use reflection to access protected constructor
                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                        constructor.setAccessible(true);
                                                        
                                                        // Case 1: Current infinite, x not finite (should behave differently)
                                                        Dfp infiniteDfp = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                        Dfp nanDfp = constructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                        Dfp result1 = infiniteDfp.newInstance(nanDfp);
                                                        // Original would not enter special case, mutant would
                                                        assertFalse(result1.isNaN()); // Should not be affected by the condition
                                                        
                                                        // Case 2: Current infinite, x finite with zero mantissa
                                                        Dfp zeroDfp = field.getZero();
                                                        // Use reflection to access protected mant field
                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                        mantField.setAccessible(true);
                                                        int[] mant = (int[]) mantField.get(zeroDfp);
                                                        mant[mant.length-1] = 0; // Ensure last mantissa digit is 0
                                                        Dfp result2 = infiniteDfp.newInstance(zeroDfp);
                                                        // Both original and mutant should behave same here
                                                        assertTrue(result2.isInfinite());
                                                        
                                                        // Case 3: Current not infinite, x finite with zero mantissa
                                                        Dfp finiteDfp = field.getOne();
                                                        Dfp result3 = finiteDfp.newInstance(zeroDfp);
                                                        // Both should behave same here
                                                        assertTrue(result3.isZero());
                                                        
                                                        // Case 4: Current infinite, x finite with non-zero mantissa
                                                        Dfp oneDfp = field.getOne();
                                                        mant = (int[]) mantField.get(oneDfp);
                                                        mant[mant.length-1] = 1; // Ensure last mantissa digit is not 0
                                                        Dfp result4 = infiniteDfp.newInstance(oneDfp);
                                                        // Original would not enter special case, mutant would
                                                        assertFalse(result4.isInfinite()); // Should create copy, not preserve infinity
                                                    }

    @Test
                                                public void testNewInstanceWithMutantCondition1() throws Exception {
                                                    // Create a field with some radix digits
                                                    DfpField field = new DfpField(10);
                                                    
                                                    // Get protected constructor and fields using reflection
                                                    Constructor<Dfp> protectedConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                    protectedConstructor.setAccessible(true);
                                                    
                                                    // Get protected int constructor
                                                    Constructor<Dfp> intConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                    intConstructor.setAccessible(true);
                                                    
                                                    Field nansField = Dfp.class.getDeclaredField("nans");
                                                    nansField.setAccessible(true);
                                                    
                                                    Field mantField = Dfp.class.getDeclaredField("mant");
                                                    mantField.setAccessible(true);
                                                    
                                                    // Case 1: nans is INFINITE, x.nans is not FINITE (should only pass original)
                                                    Dfp infDfp = protectedConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                    Dfp qnanDfp = protectedConstructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                    Dfp result1 = infDfp.newInstance(qnanDfp);
                                                    // Original would not trigger special case, mutant would
                                                    assertNotEquals(Dfp.QNAN, nansField.get(result1));
                                                    
                                                    // Case 2: x.nans is FINITE and mantissa is zero, but nans is not INFINITE
                                                    Dfp finiteDfp = intConstructor.newInstance(field, 0);
                                                    Dfp finiteZeroDfp = intConstructor.newInstance(field, 0);
                                                    int[] mant = (int[]) mantField.get(finiteZeroDfp);
                                                    mant[mant.length-1] = 0;
                                                    mantField.set(finiteZeroDfp, mant);
                                                    Dfp result2 = finiteDfp.newInstance(finiteZeroDfp);
                                                    // Both original and mutant should behave same here
                                                    assertEquals(Dfp.FINITE, nansField.get(result2));
                                                    
                                                    // Case 3: All conditions met (nans INFINITE, x.nans FINITE, zero mantissa)
                                                    Dfp infDfp2 = protectedConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                    Dfp result3 = infDfp2.newInstance(finiteZeroDfp);
                                                    // Both should trigger special case
                                                    assertEquals(Dfp.QNAN, nansField.get(result3));
                                                    
                                                    // Case 4: None of conditions met
                                                    Dfp regularDfp = intConstructor.newInstance(field, 5);
                                                    Dfp regularDfp2 = intConstructor.newInstance(field, 3);
                                                    Dfp result4 = regularDfp.newInstance(regularDfp2);
                                                    // Both should behave same
                                                    assertEquals(Dfp.FINITE, nansField.get(result4));
                                                }

    @Test
                                                public void testNewInstanceStringWithMutantCondition1() throws Exception {
                                                    // Create test objects
                                                    DfpField field = new DfpField(20); // assuming reasonable radix digits
                                                    
                                                    // Use reflection to access protected constructor
                                                    Constructor<Dfp> protectedConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                    protectedConstructor.setAccessible(true);
                                                    
                                                    // Also get protected String constructor
                                                    Constructor<Dfp> stringConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, String.class);
                                                    stringConstructor.setAccessible(true);
                                                    
                                                    // Create infiniteDfp using reflection
                                                    Dfp infiniteDfp = protectedConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                    
                                                    // Create finiteZeroMantissaDfp using protected constructor via reflection
                                                    Dfp finiteZeroMantissaDfp = stringConstructor.newInstance(field, "1.000"); // creates finite with zero in last mantissa
                                                    
                                                    // Case 1: nans is INFINITE, others false - should only pass mutant
                                                    Dfp testDfp1 = protectedConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                    Field mantField = Dfp.class.getDeclaredField("mant");
                                                    mantField.setAccessible(true);
                                                    int[] mant1 = (int[]) mantField.get(testDfp1);
                                                    mant1[mant1.length-1] = 1; // non-zero last mantissa
                                                    Dfp result1 = testDfp1.newInstance("1.0");
                                                    assertFalse("Should not create new instance when only nans is INFINITE", 
                                                               result1.isInfinite());
                                                    
                                                    // Case 2: x.nans is FINITE and last mantissa is 0, but nans not INFINITE - should only pass mutant
                                                    Dfp testDfp2 = protectedConstructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                    int[] mant2 = (int[]) mantField.get(testDfp2);
                                                    mant2[mant2.length-1] = 0; // zero last mantissa
                                                    Dfp result2 = testDfp2.newInstance("1.0");
                                                    assertFalse("Should not create new instance when only x is FINITE with zero mantissa",
                                                               result2.isInfinite());
                                                    
                                                    // Case 3: All conditions true - both should pass
                                                    Dfp testDfp3 = infiniteDfp.newInstance("0.000");
                                                    assertTrue("Should create infinite instance when all conditions met",
                                                              testDfp3.isInfinite());
                                                    
                                                    // Case 4: All conditions false - both should fail
                                                    Dfp testDfp4 = protectedConstructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                    int[] mant4 = (int[]) mantField.get(testDfp4);
                                                    mant4[mant4.length-1] = 1; // non-zero last mantissa
                                                    Dfp result4 = testDfp4.newInstance("1.0");
                                                    assertFalse("Should not create new instance when no conditions met",
                                                               result4.isInfinite());
                                                }

    @Test
                                                public void testNewInstanceWithSignAndCodeDetectsMutant() throws Exception {
                                                    // Setup test objects
                                                    DfpField field = mock(DfpField.class);
                                                    when(field.getRadixDigits()).thenReturn(3); // Needed for mantissa array size
                                                    
                                                    // Use reflection to access protected constructor
                                                    Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                    constructor.setAccessible(true);
                                                    Dfp originalDfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                    
                                                    // Case 1: nans is INFINITE, other conditions false
                                                    // Should pass original but fail mutant
                                                    Dfp mockDfp = mock(Dfp.class);
                                                    when(field.newDfp(anyByte(), anyByte())).thenReturn(mockDfp);
                                                    
                                                    // Use reflection to set protected fields
                                                    Field nansField = Dfp.class.getDeclaredField("nans");
                                                    nansField.setAccessible(true);
                                                    nansField.set(mockDfp, Dfp.INFINITE);
                                                    
                                                    Field mantField = Dfp.class.getDeclaredField("mant");
                                                    mantField.setAccessible(true);
                                                    mantField.set(mockDfp, new int[]{1, 2, 3}); // last digit not 0
                                                    
                                                    Dfp result1 = originalDfp.newInstance((byte)1, Dfp.INFINITE);
                                                    assertNotNull(result1);
                                                    
                                                    // Case 2: nans is not INFINITE but x.nans is FINITE and last mantissa is 0
                                                    // Should fail original but pass mutant
                                                    Dfp x = mock(Dfp.class);
                                                    nansField.set(x, Dfp.FINITE);
                                                    mantField.set(x, new int[]{0, 0, 0}); // last digit is 0
                                                    
                                                    Dfp result2 = originalDfp.newInstance((byte)1, Dfp.FINITE);
                                                    // This assertion would fail for the mutant but pass for original
                                                    assertNotNull(result2);
                                                    
                                                    // Case 3: All conditions true - both should pass
                                                    nansField.set(mockDfp, Dfp.INFINITE);
                                                    mantField.set(mockDfp, new int[]{0, 0, 0});
                                                    
                                                    Dfp result3 = originalDfp.newInstance((byte)1, Dfp.INFINITE);
                                                    assertNotNull(result3);
                                                }

    @Test
                                            public void testNewInstanceWithDifferentNaNStates1() {
                                                // Create a field for testing
                                                DfpField field = new DfpField(10); // assuming 10 radix digits
                                                
                                                try {
                                                    // Case 1: Current instance is INFINITE, other conditions false
                                                    Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                    constructor.setAccessible(true);
                                                    Dfp infiniteDfp = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                    Dfp result1 = infiniteDfp.newInstance();
                                                    assertNotNull(result1);
                                                    assertEquals(field, result1.getField());
                                                    
                                                    // Case 2: Current instance is FINITE, but parameter meets other conditions
                                                    Dfp finiteDfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                    // Create a Dfp with FINITE nans and zero last mantissa digit
                                                    Dfp paramDfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                    
                                                    // Use reflection to set protected fields
                                                    Field mantField = Dfp.class.getDeclaredField("mant");
                                                    mantField.setAccessible(true);
                                                    int[] zeroMantissa = new int[field.getRadixDigits()];
                                                    zeroMantissa[zeroMantissa.length-1] = 0;
                                                    mantField.set(paramDfp, zeroMantissa);
                                                    
                                                    Field nansField = Dfp.class.getDeclaredField("nans");
                                                    nansField.setAccessible(true);
                                                    nansField.set(paramDfp, Dfp.FINITE);
                                                    
                                                    Dfp result2 = finiteDfp.newInstance(paramDfp);
                                                    assertNotNull(result2);
                                                    assertEquals(field, result2.getField());
                                                    
                                                    // Case 3: All conditions true
                                                    Dfp infiniteWithParam = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                    Dfp result3 = infiniteWithParam.newInstance(paramDfp);
                                                    assertNotNull(result3);
                                                    assertEquals(field, result3.getField());
                                                } catch (Exception e) {
                                                    fail("Reflection failed: " + e.getMessage());
                                                }
                                            }

    @Test
                                    public void testNewInstanceWithDifferentNanStates() throws Exception {
                                        // Create mock field
                                        DfpField mockField = mock(DfpField.class);
                                        
                                        // Get constructor and field access via reflection
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                        constructor.setAccessible(true);
                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                        nansField.setAccessible(true);
                                        
                                        byte FINITE = 0;  // Assuming FINITE is 0 based on common conventions
                                        byte INFINITE = 1; // Assuming INFINITE is 1 based on common conventions
                                        
                                        // Test case 1: Both finite
                                        Dfp finite1 = constructor.newInstance(mockField, (byte)1, FINITE);
                                        Dfp finite2 = finite1.newInstance();
                                        assertEquals(FINITE, nansField.getByte(finite2));
                                        
                                        // Test case 2: Original finite, new instance infinite
                                        Dfp finite3 = constructor.newInstance(mockField, (byte)1, FINITE);
                                        Dfp infinite1 = constructor.newInstance(mockField, (byte)1, INFINITE);
                                        // This would catch the mutant as the behavior differs for finite+infinite
                                        
                                        // Test case 3: Original infinite, new instance finite
                                        Dfp infinite2 = constructor.newInstance(mockField, (byte)1, INFINITE);
                                        Dfp finite4 = infinite2.newInstance();
                                        assertEquals(FINITE, nansField.getByte(finite4));
                                        
                                        // Test case 4: Both infinite (though newInstance should always create finite)
                                        Dfp infinite3 = constructor.newInstance(mockField, (byte)1, INFINITE);
                                        Dfp infinite4 = infinite3.newInstance();
                                        // This verifies newInstance always creates finite regardless of original
                                        assertEquals(FINITE, nansField.getByte(infinite4));
                                    }

    @Test
                                    public void testNewInstanceNanPropagation() throws Exception {
                                        DfpField mockField = mock(DfpField.class);
                                        
                                        // Get protected constructor
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                            DfpField.class, byte.class, byte.class
                                        );
                                        constructor.setAccessible(true);
                                        
                                        // Get protected nans field
                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                        nansField.setAccessible(true);
                                        
                                        // Test that newInstance never propagates NaN/infinite states
                                        Dfp qnan = constructor.newInstance(mockField, (byte)1, Dfp.QNAN);
                                        Dfp newQnan = qnan.newInstance();
                                        assertEquals(Dfp.FINITE, nansField.getByte(newQnan));
                                        
                                        Dfp snan = constructor.newInstance(mockField, (byte)1, Dfp.SNAN);
                                        Dfp newSnan = snan.newInstance();
                                        assertEquals(Dfp.FINITE, nansField.getByte(newSnan));
                                        
                                        Dfp infinite = constructor.newInstance(mockField, (byte)1, Dfp.INFINITE);
                                        Dfp newInfinite = infinite.newInstance();
                                        assertEquals(Dfp.FINITE, nansField.getByte(newInfinite));
                                    }

    @Test
                                    public void testNewInstanceWithNonFiniteCurrentObject2() throws Exception {
                                        // Create a mock DfpField
                                        DfpField field = mock(DfpField.class);
                                        when(field.getRadixDigits()).thenReturn(1); // Need to mock this for constructor
                                        
                                        // Use reflection to create current Dfp object that is not FINITE (INFINITE)
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                        constructor.setAccessible(true);
                                        Dfp current = constructor.newInstance(field, (byte)1, (byte)Dfp.INFINITE);
                                        
                                        // Create parameter Dfp object that is FINITE
                                        Dfp param = constructor.newInstance(field, (byte)1, (byte)Dfp.FINITE);
                                        when(param.getField()).thenReturn(field);
                                        
                                        // Call newInstance
                                        Dfp result = current.newInstance(param);
                                        
                                        // Verify behavior - should return a new Dfp with INFINITE status
                                        // Use reflection to access protected nans field
                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                        nansField.setAccessible(true);
                                        byte resultNans = (byte)nansField.get(result);
                                        assertEquals(Dfp.INFINITE, resultNans);
                                        
                                        // Additional verification that constructor was called correctly
                                        verify(field, times(1)).getRadixDigits();
                                    }

    @Test
                                    public void testNewInstanceWithNonFiniteParameter1() throws Exception {
                                        // Create a mock DfpField
                                        DfpField field = mock(DfpField.class);
                                        
                                        // Use reflection to access protected constructor
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                        constructor.setAccessible(true);
                                        
                                        // Create current Dfp object that is FINITE
                                        Dfp current = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                        
                                        // Create parameter Dfp object that is not FINITE (INFINITE)
                                        Dfp param = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                        when(param.getField()).thenReturn(field);
                                        
                                        // Call newInstance
                                        Dfp result = current.newInstance(param);
                                        
                                        // Use reflection to access protected nans field
                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                        nansField.setAccessible(true);
                                        byte resultNans = (byte) nansField.get(result);
                                        
                                        // Verify behavior - should return a new Dfp with INFINITE status
                                        assertEquals(Dfp.INFINITE, resultNans);
                                    }

    @Test
                                    public void testNewInstanceWithBothFinite1() throws Exception {
                                        // Create a mock DfpField
                                        DfpField field = mock(DfpField.class);
                                        
                                        // Use reflection to access protected constructor
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                        constructor.setAccessible(true);
                                        
                                        // Create current Dfp object that is FINITE
                                        Dfp current = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                        
                                        // Create parameter Dfp object that is FINITE
                                        Dfp param = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                        when(param.getField()).thenReturn(field);
                                        
                                        // Call newInstance
                                        Dfp result = current.newInstance(param);
                                        
                                        // Use reflection to access protected field nans
                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                        nansField.setAccessible(true);
                                        byte resultNans = (byte) nansField.get(result);
                                        
                                        // Verify behavior - should return a new Dfp with FINITE status
                                        assertEquals(Dfp.FINITE, resultNans);
                                    }

    @Test
                                    public void testNewInstanceWithNonFiniteCurrentObject3() throws Exception {
                                        // Create a mock field
                                        DfpField mockField = mock(DfpField.class);
                                        
                                        // Use reflection to access protected constructor
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                        constructor.setAccessible(true);
                                        
                                        // Create current object with non-FINITE state (INFINITE)
                                        Dfp current = constructor.newInstance(mockField, (byte)1, Dfp.INFINITE);
                                        
                                        // Create parameter with FINITE state
                                        Dfp param = constructor.newInstance(mockField, (byte)1, Dfp.FINITE);
                                        
                                        // Call the method
                                        Dfp result = current.newInstance(param);
                                        
                                        // Verify the result is a new instance with param's value
                                        assertNotSame(current, result);
                                        assertNotSame(param, result);
                                        
                                        // Use reflection to access protected nans field
                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                        nansField.setAccessible(true);
                                        byte resultNans = (byte) nansField.get(result);
                                        assertEquals(Dfp.FINITE, resultNans); // Should be FINITE
                                    }

    @Test
                                    public void testNewInstanceWithFiniteCurrentObject() throws Exception {
                                        // Create a mock field
                                        DfpField mockField = mock(DfpField.class);
                                        
                                        // Get the protected constructor
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                            DfpField.class, byte.class, byte.class
                                        );
                                        constructor.setAccessible(true);
                                        
                                        // Create current object with FINITE state
                                        Dfp current = constructor.newInstance(mockField, (byte)1, (byte)Dfp.FINITE);
                                        
                                        // Create parameter with FINITE state
                                        Dfp param = constructor.newInstance(mockField, (byte)1, (byte)Dfp.FINITE);
                                        
                                        // Call the method
                                        Dfp result = current.newInstance(param);
                                        
                                        // Verify the result is a new instance with param's value
                                        assertNotSame(current, result);
                                        assertNotSame(param, result);
                                        
                                        // Use reflection to check protected field
                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                        nansField.setAccessible(true);
                                        byte nansValue = (byte)nansField.get(result);
                                        assertEquals(Dfp.FINITE, nansValue);
                                    }

    @Test
                                    public void testNewInstanceWithNonFiniteParameter2() throws Exception {
                                        // Create a mock field
                                        DfpField mockField = mock(DfpField.class);
                                        
                                        // Use reflection to access protected constructor
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                        constructor.setAccessible(true);
                                        
                                        // Create current object with FINITE state
                                        Dfp current = constructor.newInstance(mockField, (byte)1, Dfp.FINITE);
                                        
                                        // Create parameter with non-FINITE state (INFINITE)
                                        Dfp param = constructor.newInstance(mockField, (byte)1, Dfp.INFINITE);
                                        
                                        // Call the method
                                        Dfp result = current.newInstance(param);
                                        
                                        // Verify the result is a new instance with param's value
                                        assertNotSame(current, result);
                                        assertNotSame(param, result);
                                        
                                        // Use reflection to access protected nans field
                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                        nansField.setAccessible(true);
                                        byte resultNans = (byte) nansField.get(result);
                                        assertEquals(Dfp.INFINITE, resultNans); // Should be INFINITE
                                    }

    @Test
                                    public void testNewInstanceWithNonFiniteThisAndFiniteParam() throws Exception {
                                        // Create a mock field
                                        DfpField mockField = mock(DfpField.class);
                                        
                                        // Use reflection to access protected constructor
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                        constructor.setAccessible(true);
                                        
                                        // Create non-FINITE this object (INFINITE)
                                        Dfp thisObj = constructor.newInstance(mockField, (byte)1, Dfp.INFINITE);
                                        
                                        // Create FINITE parameter object
                                        Dfp param = constructor.newInstance(mockField, (byte)1, Dfp.FINITE);
                                        
                                        // Use reflection to set exp field
                                        Field expField = Dfp.class.getDeclaredField("exp");
                                        expField.setAccessible(true);
                                        expField.setInt(param, 1); // Make it clearly finite
                                        
                                        // Call newInstance
                                        Dfp result = thisObj.newInstance(param);
                                        
                                        // Use reflection to verify nans field
                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                        nansField.setAccessible(true);
                                        byte resultNans = (byte) nansField.get(result);
                                        
                                        // Verify the result should have INFINITE (original would propagate non-FINITE state)
                                        // Mutant would create a FINITE copy instead
                                        assertEquals(Dfp.INFINITE, resultNans);
                                    }

    @Test
                                    public void testNewInstanceWithNonFiniteThisAndNonFiniteParam() throws Exception {
                                        // Create a mock field
                                        DfpField mockField = mock(DfpField.class);
                                        
                                        // Get the protected constructor
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                            DfpField.class, byte.class, byte.class
                                        );
                                        constructor.setAccessible(true);
                                        
                                        // Create non-FINITE this object (QNAN)
                                        Dfp thisObj = constructor.newInstance(mockField, (byte)1, Dfp.QNAN);
                                        
                                        // Create non-FINITE parameter object (INFINITE)
                                        Dfp param = constructor.newInstance(mockField, (byte)-1, Dfp.INFINITE);
                                        
                                        // Call newInstance
                                        Dfp result = thisObj.newInstance(param);
                                        
                                        // Use reflection to access protected nans field
                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                        nansField.setAccessible(true);
                                        byte resultNans = (byte) nansField.get(result);
                                        
                                        // Verify the result should have QNAN (original would propagate non-FINITE state)
                                        assertEquals(Dfp.QNAN, resultNans);
                                    }

    @Test
                                    public void testNewInstanceWithStringWhenCurrentIsInfiniteAndInputIsFinite() throws Exception {
                                        // Create a field mock
                                        DfpField field = mock(DfpField.class);
                                        when(field.getRadixDigits()).thenReturn(10); // arbitrary value
                                        
                                        // Use reflection to access protected constructor
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                        constructor.setAccessible(true);
                                        Dfp infiniteDfp = constructor.newInstance(field, (byte)1, Dfp.class.getDeclaredField("INFINITE").getByte(null));
                                        
                                        // Test creating new instance from finite string
                                        Dfp result = infiniteDfp.newInstance("123.45");
                                        
                                        // Use reflection to access protected nans field
                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                        nansField.setAccessible(true);
                                        byte resultNans = nansField.getByte(result);
                                        
                                        // Verify the mutant would fail this assertion
                                        assertEquals(Dfp.class.getDeclaredField("INFINITE").getByte(null), resultNans);
                                    }

    @Test
                                    public void testNewInstanceWithStringWhenCurrentIsFiniteAndInputIsFinite() throws Exception {
                                        // Create a field mock
                                        DfpField field = mock(DfpField.class);
                                        when(field.getRadixDigits()).thenReturn(10); // arbitrary value
                                        
                                        // Use reflection to access protected constructor
                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                        constructor.setAccessible(true);
                                        
                                        // Create a finite Dfp instance
                                        Dfp finiteDfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                        
                                        // Test creating new instance from finite string
                                        Dfp result = finiteDfp.newInstance("678.90");
                                        
                                        // Use reflection to access protected nans field
                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                        nansField.setAccessible(true);
                                        byte resultNans = (byte) nansField.get(result);
                                        
                                        // Verify the mutant would fail this assertion
                                        assertEquals(Dfp.FINITE, resultNans);
                                    }

    @Test
                                    public void testNewInstanceWithNonFiniteCurrentAndFiniteParameter1() {
                                        // Create a mock DfpField
                                        DfpField field = mock(DfpField.class);
                                        
                                        // Create test objects:
                                        // Current Dfp with non-finite value (INFINITE)
                                        Dfp infiniteDfp = mock(Dfp.class);
                                        when(infiniteDfp.getField()).thenReturn(field);
                                        when(infiniteDfp.isInfinite()).thenReturn(true);
                                        when(infiniteDfp.isNaN()).thenReturn(false);
                                        
                                        // Parameter Dfp with finite value
                                        Dfp finiteDfp = mock(Dfp.class);
                                        when(finiteDfp.getField()).thenReturn(field);
                                        when(finiteDfp.isInfinite()).thenReturn(false);
                                        when(finiteDfp.isNaN()).thenReturn(false);
                                        
                                        // Mock the behavior of field.newDfp()
                                        Dfp expectedResult = mock(Dfp.class);
                                        when(field.newDfp(anyByte(), anyByte())).thenReturn(expectedResult);
                                        
                                        // Test the behavior
                                        Dfp result = infiniteDfp.newInstance((byte)1, (byte)1);
                                        
                                        // Verify that field.newDfp() was called (which it should be in original code)
                                        // If mutant exists, this call wouldn't happen and test would fail
                                        verify(field).newDfp((byte)1, (byte)1);
                                        
                                        // Assert the result is as expected
                                        assertEquals(expectedResult, result);
                                    }

    @Test
                            public void testNewInstanceWithNonFiniteValues1() throws Exception {
                                // Create a mock field
                                DfpField field = mock(DfpField.class);
                                
                                // Get protected constants via reflection
                                Class<Dfp> dfpClass = Dfp.class;
                                Field infiniteField = dfpClass.getDeclaredField("INFINITE");
                                infiniteField.setAccessible(true);
                                byte INFINITE = infiniteField.getByte(null);
                                
                                Field qnanField = dfpClass.getDeclaredField("QNAN");
                                qnanField.setAccessible(true);
                                byte QNAN = qnanField.getByte(null);
                                
                                Field snanField = dfpClass.getDeclaredField("SNAN");
                                snanField.setAccessible(true);
                                byte SNAN = snanField.getByte(null);
                                
                                Field finiteField = dfpClass.getDeclaredField("FINITE");
                                finiteField.setAccessible(true);
                                byte FINITE = finiteField.getByte(null);
                                
                                // Get protected constructor
                                Constructor<Dfp> byteByteConstructor = dfpClass.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                byteByteConstructor.setAccessible(true);
                                
                                // Case 1: Current non-FINITE (INFINITE), parameter FINITE
                                Dfp infiniteDfp = byteByteConstructor.newInstance(field, (byte)1, INFINITE);
                                Dfp finiteParam = byteByteConstructor.newInstance(field, (byte)1, FINITE);
                                Dfp result1 = infiniteDfp.newInstance(finiteParam);
                                Field nansField = dfpClass.getDeclaredField("nans");
                                nansField.setAccessible(true);
                                assertFalse("Result should not be finite when original is infinite", 
                                            nansField.getByte(result1) == FINITE);
                                
                                // Case 2: Current FINITE, parameter non-FINITE (QNAN)
                                Dfp finiteDfp = byteByteConstructor.newInstance(field, (byte)1, FINITE);
                                Dfp nanParam = byteByteConstructor.newInstance(field, (byte)1, QNAN);
                                Dfp result2 = finiteDfp.newInstance(nanParam);
                                assertFalse("Result should not be finite when parameter is NaN", 
                                            nansField.getByte(result2) == FINITE);
                                
                                // Case 3: Both non-FINITE (INFINITE and SNAN)
                                Dfp infiniteDfp2 = byteByteConstructor.newInstance(field, (byte)1, INFINITE);
                                Dfp snanParam = byteByteConstructor.newInstance(field, (byte)1, SNAN);
                                Dfp result3 = infiniteDfp2.newInstance(snanParam);
                                assertFalse("Result should not be finite when both are non-finite", 
                                            nansField.getByte(result3) == FINITE);
                                
                                // Case 4: Both FINITE (normal case)
                                Dfp finiteDfp2 = byteByteConstructor.newInstance(field, (byte)1, FINITE);
                                Dfp finiteParam2 = byteByteConstructor.newInstance(field, (byte)1, FINITE);
                                Dfp result4 = finiteDfp2.newInstance(finiteParam2);
                                assertTrue("Result should be finite when both are finite", 
                                           nansField.getByte(result4) == FINITE);
                            }

    @Test
                    public void testNewInstanceWithNaN() throws Exception {
                        // Create a NaN Dfp instance using reflection
                        DfpField mockField = mock(DfpField.class);
                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                        constructor.setAccessible(true);
                        Dfp nanInstance = constructor.newInstance(mockField, (byte)1, Dfp.QNAN);
                        
                        // Test newInstance()
                        Dfp result = nanInstance.newInstance();
                        
                        // Verify a new instance was created with the same field
                        assertNotNull(result);
                        assertEquals(mockField, result.getField());
                        assertTrue(result.isNaN());
                    }

    @Test
                    public void testNewInstanceWithNaN1() throws Exception {
                        // Create a NaN Dfp instance using reflection
                        DfpField field = new DfpField(20);
                        
                        // Get the protected constructor
                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                            DfpField.class, byte.class, byte.class
                        );
                        constructor.setAccessible(true);
                        
                        // Create NaN instance
                        Dfp nanInstance = constructor.newInstance(field, (byte)1, Dfp.QNAN);
                        
                        // Test newInstance() with NaN
                        Dfp result = nanInstance.newInstance();
                        
                        // Verify the new instance is also NaN (original behavior)
                        assertTrue("New instance should be NaN when original is NaN", result.isNaN());
                    }

    @Test
                    public void testNewInstanceWithNaN2() throws Exception {
                        // Create a NaN Dfp instance using reflection
                        DfpField field = new DfpField(20);
                        
                        // Get the protected constructor
                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                            DfpField.class, byte.class, byte.class
                        );
                        constructor.setAccessible(true);
                        
                        // Create NaN instance
                        Dfp nanInstance = constructor.newInstance(field, (byte)1, Dfp.QNAN);
                        
                        // Test newInstance() with NaN
                        Dfp result = nanInstance.newInstance();
                        
                        // Verify the result is a new NaN instance
                        assertNotSame("Should return a new instance", nanInstance, result);
                        assertTrue("Result should be NaN", result.isNaN());
                    }

    @Test
                    public void testNewInstanceWithNonNaN() {
                        // Create a normal Dfp instance
                        DfpField field = new DfpField(20);
                        Dfp normalInstance = field.newDfp(12345L); // Using field's newDfp method instead of direct constructor
                        
                        // Test newInstance() with non-NaN
                        Dfp result = normalInstance.newInstance();
                        
                        // Verify the result is a new instance with same field
                        assertNotSame("Should return a new instance", normalInstance, result);
                        assertEquals("Should have same field", normalInstance.getField(), result.getField());
                        assertFalse("Result should not be NaN", result.isNaN());
                    }

    @Test
                    public void testNewInstance_NaNHandling() throws Exception {
                        // Create field
                        DfpField field = new DfpField(20); // assuming 20 radix digits
                        
                        // Create NaN Dfp object using reflection to access protected constructor
                        Constructor<Dfp> nanConstructor = Dfp.class.getDeclaredConstructor(
                            DfpField.class, byte.class, byte.class);
                        nanConstructor.setAccessible(true);
                        Dfp nanDfp = nanConstructor.newInstance(field, (byte)1, Dfp.QNAN);
                        
                        // Create normal Dfp object using reflection to access protected constructor
                        Constructor<Dfp> intConstructor = Dfp.class.getDeclaredConstructor(
                            DfpField.class, int.class);
                        intConstructor.setAccessible(true);
                        Dfp normalDfp = intConstructor.newInstance(field, 10); // value 10
                        
                        // Test NaN case
                        Dfp result1 = nanDfp.newInstance();
                        assertNull("For NaN object, newInstance should return null", result1);
                        
                        // Test non-NaN case
                        Dfp result2 = normalDfp.newInstance();
                        assertNotNull("For non-NaN object, newInstance should return new instance", result2);
                        assertEquals("New instance should have same field", normalDfp.getField(), result2.getField());
                        assertTrue("New instance should be zero", result2.isZero());
                    }

    @Test
                    public void testNewInstanceWithNaN3() {
                        // Create a DfpField instance
                        DfpField field = new DfpField(10); // Using 10 radix digits as an example
                        
                        // Test with explicit NaN using newInstance(String)
                        Dfp nanInstance = field.getZero().newInstance("NaN");
                        
                        // Verify the original behavior - should recognize NaN
                        assertTrue("Original should recognize NaN from string", nanInstance.isNaN());
                        
                        // Test with NaN produced by operation
                        Dfp zero = field.getZero();
                        Dfp infinity = field.getZero().newInstance("Infinity");
                        Dfp nanFromOperation = zero.divide(infinity); // Should produce NaN
                        
                        Dfp nanOpInstance = nanFromOperation.newInstance();
                        assertTrue("Original should recognize NaN from operation", nanOpInstance.isNaN());
                        
                        // The mutant would fail these tests because:
                        // 1. It would try to process "NaN" as a regular number
                        // 2. It would try to process operation NaN as a regular number
                        // Both cases should be properly identified as NaN in the original
                    }

    @Test
                public void testNewInstanceWithNaNCondition() throws Exception {
                    // Setup test objects
                    DfpField mockField = mock(DfpField.class);
                    Dfp mockDfp = mock(Dfp.class);
                    when(mockField.newDfp(anyByte(), anyByte())).thenReturn(mockDfp);
                    
                    // Get protected constructor using reflection
                    Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                    constructor.setAccessible(true);
                    
                    // Case 1: Test with NaN value (should create new instance in original)
                    Dfp nanInstance = constructor.newInstance(mockField, (byte)0, Dfp.QNAN);
                    when(nanInstance.isNaN()).thenReturn(true);
                    
                    // This should create new instance for original code, but not for mutant
                    Dfp result1 = nanInstance.newInstance((byte)1, (byte)Dfp.QNAN);
                    verify(mockField, times(1)).newDfp(anyByte(), anyByte());
                    assertSame(mockDfp, result1);
                    
                    // Case 2: Test with non-NaN value (should NOT create new instance in original)
                    Dfp nonNanInstance = constructor.newInstance(mockField, (byte)0, Dfp.FINITE);
                    when(nonNanInstance.isNaN()).thenReturn(false);
                    
                    // This should NOT create new instance for original code, but would for mutant
                    Dfp result2 = nonNanInstance.newInstance((byte)1, (byte)Dfp.FINITE);
                    verify(mockField, times(1)).newDfp(anyByte(), anyByte()); // Verify no additional calls
                    assertSame(mockDfp, result2); // Should still be same mock from first call
                    
                    // Reset mock for clearer verification
                    reset(mockField);
                    when(mockField.newDfp(anyByte(), anyByte())).thenReturn(mockDfp);
                    
                    // Repeat test with clear verification
                    Dfp result3 = nonNanInstance.newInstance((byte)1, (byte)Dfp.FINITE);
                    verify(mockField, never()).newDfp(anyByte(), anyByte()); // Should not be called for non-NaN in original
                }

    @Test
        public void testNewInstanceWithNonNaN2() {
            // Create a non-NaN Dfp instance using public methods
            DfpField field = new DfpField(10); // Assuming 10 decimal digits
            Dfp zero = field.getZero(); // Get zero instance
            Dfp nonNanInstance = zero.add(field.getOne()); // Create 1.0 by adding one to zero
            
            // Test newInstance()
            Dfp result = nonNanInstance.newInstance();
            
            // Verify a new instance was created with the same field
            assertNotNull(result);
            assertEquals(field, result.getField());
            assertFalse(result.isNaN());
        }

    @Test
        public void testNewInstanceWithNaN5() {
            // Create a NaN Dfp instance using reflection to access protected constructor
            DfpField field = new DfpField(20);
            Dfp nanInstance;
            try {
                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                constructor.setAccessible(true);
                nanInstance = constructor.newInstance(field, (byte)1, Dfp.QNAN);
            } catch (Exception e) {
                throw new RuntimeException("Failed to create NaN instance", e);
            }
            
            // Test newInstance() behavior with NaN
            Dfp result = nanInstance.newInstance();
            
            // Original behavior: should return null or not create new instance for NaN
            // Mutant behavior: would create new instance
            assertNull("newInstance() should return null for NaN values", result);
            
            // Create a non-NaN Dfp instance using reflection to access protected constructor
            Dfp temp;
            try {
                Constructor<Dfp> doubleConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
                doubleConstructor.setAccessible(true);
                temp = doubleConstructor.newInstance(field, 0.0);  // Start with zero
            } catch (Exception e) {
                throw new RuntimeException("Failed to create temporary instance", e);
            }
            
            temp = temp.newInstance(5.0);  // Using newInstance with double value
            Dfp normalInstance = new Dfp(temp); // Using public copy constructor
            
            // Test newInstance() behavior with non-NaN
            Dfp normalResult = normalInstance.newInstance();
            
            // Should create new instance for non-NaN
            assertNotNull("newInstance() should create new instance for non-NaN values", normalResult);
            assertEquals("New instance should have same value", normalInstance.toDouble(), normalResult.toDouble(), 0.0001);
        }

    @Test
    public void testNewInstanceWithNonNaN1() {
        // Create a non-NaN Dfp instance using public methods
        DfpField field = new DfpField(10); // Assuming 10 decimal digits
        Dfp nonNanInstance = field.newDfp(1.0); // Using public factory method
        
        // Test newInstance()
        Dfp result = nonNanInstance.newInstance();
        
        // Verify a new instance was created with the same field
        assertNotNull(result);
        assertEquals(field, result.getField());
        assertFalse(result.isNaN());
    }

    @Test
    public void testNewInstanceWithNaN4() {
        // Create a NaN Dfp instance using reflection to access protected constructor
        DfpField field = new DfpField(20);
        Dfp nanInstance;
        try {
            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
            constructor.setAccessible(true);
            nanInstance = constructor.newInstance(field, (byte)1, Dfp.QNAN);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create NaN instance", e);
        }
        
        // Test newInstance() behavior with NaN
        Dfp result = nanInstance.newInstance();
        
        // Original behavior: should return null or not create new instance for NaN
        // Mutant behavior: would create new instance
        assertNull("newInstance() should return null for NaN values", result);
        
        // Create a non-NaN Dfp instance using public constructor
        Dfp temp;
        try {
            Constructor<Dfp> tempConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
            tempConstructor.setAccessible(true);
            temp = tempConstructor.newInstance(field, 0.0);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create temporary instance", e);
        }
        temp = temp.newInstance(5.0);  // Using newInstance with double value
        Dfp normalInstance = new Dfp(temp); // Using public copy constructor
        
        // Test newInstance() behavior with non-NaN
        Dfp normalResult = normalInstance.newInstance();
        
        // Should create new instance for non-NaN
        assertNotNull("newInstance() should create new instance for non-NaN values", normalResult);
        assertEquals("New instance should have same value", normalInstance.toDouble(), normalResult.toDouble(), 0.0001);
    }


}
