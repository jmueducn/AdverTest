package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.util.Localizable;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.exception.NonMonotonousSequenceException;
 
public class MathUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                            public void testEquals_ExactlyEqualValues() {
                                                                assertTrue(MathUtils.equals(1.0, 1.0));
                                                                assertTrue(MathUtils.equals(0.0, 0.0));
                                                                assertTrue(MathUtils.equals(-1.0, -1.0));
                                                                assertTrue(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE));
                                                                assertTrue(MathUtils.equals(Double.MIN_VALUE, Double.MIN_VALUE));
                                                            }

    @Test
                                                            public void testEquals_WithinOneUlps() {
                                                                // Values that differ by exactly 1 ULP
                                                                double x = 1.0;
                                                                double y = Math.nextAfter(x, Double.POSITIVE_INFINITY);
                                                                assertTrue(MathUtils.equals(x, y));
                                                                
                                                                // Negative values
                                                                double a = -1.0;
                                                                double b = Math.nextAfter(a, Double.NEGATIVE_INFINITY);
                                                                assertTrue(MathUtils.equals(a, b));
                                                            }

    @Test
                                                            public void testEquals_OutsideOneUlps() {
                                                                // Values that differ by more than 1 ULP
                                                                double x = 1.0;
                                                                double y = Math.nextAfter(Math.nextAfter(x, Double.POSITIVE_INFINITY), Double.POSITIVE_INFINITY);
                                                                assertFalse(MathUtils.equals(x, y));
                                                                
                                                                // Negative values
                                                                double a = -1.0;
                                                                double b = Math.nextAfter(Math.nextAfter(a, Double.NEGATIVE_INFINITY), Double.NEGATIVE_INFINITY);
                                                                assertFalse(MathUtils.equals(a, b));
                                                            }

    @Test
                                                            public void testEquals_WithNaNValues() {
                                                                // NaN should not equal NaN in regular equals (without including NaN)
                                                                assertFalse(MathUtils.equals(Double.NaN, Double.NaN));
                                                            }

    @Test
                                                            public void testEquals_WithInfiniteValues() {
                                                                // Same infinities
                                                                assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY));
                                                                assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY));
                                                                
                                                                // Different infinities
                                                                assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY));
                                                                
                                                                // Infinity and regular number
                                                                assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, 1.0));
                                                                assertFalse(MathUtils.equals(1.0, Double.NEGATIVE_INFINITY));
                                                            }

    @Test
                                                            public void testEquals_WithSubnormalNumbers() {
                                                                // Subnormal numbers
                                                                double subnormal1 = Double.MIN_VALUE;
                                                                double subnormal2 = Math.nextAfter(subnormal1, 0.0);
                                                                assertTrue(MathUtils.equals(subnormal1, subnormal2));
                                                                
                                                                // Subnormal and normal
                                                                assertFalse(MathUtils.equals(subnormal1, 0.0));
                                                            }

    @Test
                                                            public void testEquals_WithZeroValues() {
                                                                // Positive and negative zero should be considered equal
                                                                assertTrue(MathUtils.equals(0.0, -0.0));
                                                                
                                                                // Zero and very small number
                                                                double tiny = Double.MIN_VALUE;
                                                                assertFalse(MathUtils.equals(0.0, tiny));
                                                            }

    @Test
                                                            public void testEquals_WithLargeValues() {
                                                                // Large values where 1 ULP is significant
                                                                double large1 = 1e20;
                                                                double large2 = Math.nextAfter(large1, Double.POSITIVE_INFINITY);
                                                                assertTrue(MathUtils.equals(large1, large2));
                                                                
                                                                double large3 = Math.nextAfter(large2, Double.POSITIVE_INFINITY);
                                                                assertFalse(MathUtils.equals(large1, large3));
                                                            }

    @Test
                                                            public void testEquals_ExactMatch() {
                                                                assertTrue(MathUtils.equals(1.0, 1.0, 0.0001));
                                                                assertTrue(MathUtils.equals(0.0, 0.0, 0.0001));
                                                                assertTrue(MathUtils.equals(-1.0, -1.0, 0.0001));
                                                            }

    @Test
                                                            public void testEquals_WithinEpsilon() {
                                                                assertTrue(MathUtils.equals(1.0, 1.00009, 0.0001));
                                                                assertTrue(MathUtils.equals(1.00009, 1.0, 0.0001));
                                                                assertTrue(MathUtils.equals(-1.0, -1.00009, 0.0001));
                                                                assertTrue(MathUtils.equals(0.0, 0.00009, 0.0001));
                                                            }

    @Test
                                                            public void testEquals_OutsideEpsilon() {
                                                                assertFalse(MathUtils.equals(1.0, 1.00011, 0.0001));
                                                                assertFalse(MathUtils.equals(1.00011, 1.0, 0.0001));
                                                                assertFalse(MathUtils.equals(-1.0, -1.00011, 0.0001));
                                                                assertFalse(MathUtils.equals(0.0, 0.00011, 0.0001));
                                                            }

    @Test
                                                            public void testEquals_EdgeCases() {
                                                                // Large numbers
                                                                assertTrue(MathUtils.equals(1.0e20, 1.0000001e20, 1.0e13));
                                                                assertFalse(MathUtils.equals(1.0e20, 1.0000001e20, 1.0e12));
                                                                
                                                                // Small numbers
                                                                assertTrue(MathUtils.equals(1.0e-20, 1.0000001e-20, 1.0e-27));
                                                                assertFalse(MathUtils.equals(1.0e-20, 1.0000001e-20, 1.0e-28));
                                                            }

    @Test
                                                            public void testEquals_ZeroEpsilon() {
                                                                assertTrue(MathUtils.equals(1.0, 1.0, 0.0));
                                                                assertFalse(MathUtils.equals(1.0, 1.0000001, 0.0));
                                                            }

    @Test
                                                            public void testEquals_NaNValues() {
                                                                assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 0.0001));
                                                                assertFalse(MathUtils.equals(1.0, Double.NaN, 0.0001));
                                                                assertFalse(MathUtils.equals(Double.NaN, 1.0, 0.0001));
                                                            }

    @Test
                                                            public void testEquals_InfiniteValues() {
                                                                assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 0.0001));
                                                                assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, 0.0001));
                                                                assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 0.0001));
                                                                assertFalse(MathUtils.equals(1.0, Double.POSITIVE_INFINITY, 0.0001));
                                                                assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, 1.0, 0.0001));
                                                            }

    @Test
                                                            public void testEquals_UsingClassEpsilon() {
                                                                // Test with class's EPSILON constant
                                                                double smallValue = MathUtils.EPSILON / 2;
                                                                assertTrue(MathUtils.equals(1.0, 1.0 + smallValue, MathUtils.EPSILON));
                                                                assertFalse(MathUtils.equals(1.0, 1.0 + MathUtils.EPSILON * 1.1, MathUtils.EPSILON));
                                                            }

    @Test
                                                            public void testEquals_UsingSafeMin() {
                                                                // Test with very small numbers near SAFE_MIN
                                                                assertTrue(MathUtils.equals(MathUtils.SAFE_MIN, MathUtils.SAFE_MIN, 0.0));
                                                                assertTrue(MathUtils.equals(MathUtils.SAFE_MIN, MathUtils.SAFE_MIN * 1.0001, MathUtils.SAFE_MIN * 0.0002));
                                                            }

    @Test
                                                            public void testEquals_ExtremeEpsilonValues() {
                                                                // Very large epsilon
                                                                assertTrue(MathUtils.equals(1.0, 100.0, 100.0));
                                                                assertFalse(MathUtils.equals(1.0, 101.0, 100.0));
                                                                
                                                                // Negative epsilon (should work same as positive)
                                                                assertTrue(MathUtils.equals(1.0, 1.00009, -0.0001));
                                                                assertFalse(MathUtils.equals(1.0, 1.00011, -0.0001));
                                                            }

    @Test
                                                            public void testEquals_ExactValues() {
                                                                assertTrue(MathUtils.equals(0.0, 0.0, 1));
                                                                assertTrue(MathUtils.equals(1.0, 1.0, 1));
                                                                assertTrue(MathUtils.equals(-1.0, -1.0, 1));
                                                                assertTrue(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE, 1));
                                                                assertTrue(MathUtils.equals(Double.MIN_VALUE, Double.MIN_VALUE, 1));
                                                            }

    @Test
                                                            public void testEquals_WithinUlps() {
                                                                // Test values that are very close but not exactly equal
                                                                double a = 1.23456789;
                                                                double b = a + Math.ulp(a) * 2; // 2 ULPs apart
                                                                assertTrue(MathUtils.equals(a, b, 2));
                                                                assertFalse(MathUtils.equals(a, b, 1));
                                                                
                                                                // Test with negative numbers
                                                                double c = -3.14159265;
                                                                double d = c - Math.ulp(c) * 3; // 3 ULPs apart
                                                                assertTrue(MathUtils.equals(c, d, 3));
                                                                assertFalse(MathUtils.equals(c, d, 2));
                                                            }

    @Test
                                                            public void testEquals_OutsideUlps() {
                                                                double a = 1.0;
                                                                double b = a + Math.ulp(a) * 10; // 10 ULPs apart
                                                                assertFalse(MathUtils.equals(a, b, 5));
                                                                assertTrue(MathUtils.equals(a, b, 10));
                                                            }

    @Test
                                                            public void testEquals_WithNaN() {
                                                                // NaN should never equal anything, including itself
                                                                assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 1));
                                                                assertFalse(MathUtils.equals(1.0, Double.NaN, 1));
                                                                assertFalse(MathUtils.equals(Double.NaN, 1.0, 1));
                                                            }

    @Test
                                                            public void testEquals_WithInfiniteValues1() {
                                                                // Same infinities should be equal
                                                                assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 1));
                                                                assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, 1));
                                                                
                                                                // Different infinities should not be equal
                                                                assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 1));
                                                                
                                                                // Infinity should not equal finite numbers
                                                                assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.MAX_VALUE, 1));
                                                                assertFalse(MathUtils.equals(Double.NEGATIVE_INFINITY, -Double.MAX_VALUE, 1));
                                                            }

    @Test
                                                            public void testEquals_ZeroAndNegativeZero() {
                                                                // +0.0 and -0.0 should be considered equal
                                                                assertTrue(MathUtils.equals(0.0, -0.0, 1));
                                                            }

    @Test
                                                            public void testEquals_ExtremeValues() {
                                                                // Test with very large values
                                                                double large1 = Double.MAX_VALUE;
                                                                double large2 = large1 - Math.ulp(large1) * 5;
                                                                assertTrue(MathUtils.equals(large1, large2, 5));
                                                                
                                                                // Test with very small values
                                                                double small1 = Double.MIN_VALUE;
                                                                double small2 = small1 + Math.ulp(small1) * 3;
                                                                assertTrue(MathUtils.equals(small1, small2, 3));
                                                            }

    @Test
                                                            public void testEquals_CrossingZero() {
                                                                // Test values that cross zero
                                                                double a = 1.0e-10;
                                                                double b = -1.0e-10;
                                                                assertFalse(MathUtils.equals(a, b, 100)); // Even with large maxUlps, they shouldn't be equal
                                                                
                                                                // But very close to zero on both sides should be equal
                                                                double c = Math.ulp(0.0);
                                                                double d = -Math.ulp(0.0);
                                                                assertTrue(MathUtils.equals(c, d, 1));
                                                            }

    @Test
                                                            public void testEquals_BothNull() {
                                                                assertTrue(MathUtils.equals(null, null));
                                                            }

    @Test
                                                            public void testEquals_FirstNullSecondNotNull() {
                                                                assertFalse(MathUtils.equals(null, new double[]{1.0}));
                                                            }

    @Test
                                                            public void testEquals_FirstNotNullSecondNull() {
                                                                assertFalse(MathUtils.equals(new double[]{1.0}, null));
                                                            }

    @Test
                                                            public void testEquals_DifferentLengths() {
                                                                double[] arr1 = {1.0, 2.0};
                                                                double[] arr2 = {1.0};
                                                                assertFalse(MathUtils.equals(arr1, arr2));
                                                            }

    @Test
                                                            public void testEquals_SameLengthDifferentElements() {
                                                                double[] arr1 = {1.0, 2.0};
                                                                double[] arr2 = {1.0, 3.0};
                                                                assertFalse(MathUtils.equals(arr1, arr2));
                                                            }

    @Test
                                                            public void testEquals_IdenticalArrays() {
                                                                double[] arr1 = {1.0, 2.0, 3.0};
                                                                double[] arr2 = {1.0, 2.0, 3.0};
                                                                assertTrue(MathUtils.equals(arr1, arr2));
                                                            }

    @Test
                                                            public void testEquals_EmptyArrays() {
                                                                double[] arr1 = {};
                                                                double[] arr2 = {};
                                                                assertTrue(MathUtils.equals(arr1, arr2));
                                                            }

    @Test
                                                            public void testEquals_WithNaNValues1() {
                                                                double[] arr1 = {Double.NaN, 1.0};
                                                                double[] arr2 = {Double.NaN, 1.0};
                                                                // Regular equals should return false for NaN values
                                                                assertFalse(MathUtils.equals(arr1, arr2));
                                                            }

    @Test
                                                            public void testEquals_WithInfiniteValues2() {
                                                                double[] arr1 = {Double.POSITIVE_INFINITY, 1.0};
                                                                double[] arr2 = {Double.POSITIVE_INFINITY, 1.0};
                                                                assertTrue(MathUtils.equals(arr1, arr2));
                                                            }

    @Test
                                                            public void testEquals_WithNegativeZero() {
                                                                double[] arr1 = {0.0, -0.0};
                                                                double[] arr2 = {0.0, -0.0};
                                                                assertTrue(MathUtils.equals(arr1, arr2));
                                                            }

    @Test
                                                            public void testEquals_WithEpsilonDifference() {
                                                                double[] arr1 = {1.0, 2.0};
                                                                double[] arr2 = {1.0 + MathUtils.EPSILON/2, 2.0 - MathUtils.EPSILON/2};
                                                                // Should return true since difference is within EPSILON
                                                                assertTrue(MathUtils.equals(arr1, arr2));
                                                            }

    @Test
                                                            public void testEquals_WithLargeDifference() {
                                                                double[] arr1 = {1.0, 2.0};
                                                                double[] arr2 = {1.0 + MathUtils.EPSILON * 2, 2.0};
                                                                // Should return false since difference exceeds EPSILON
                                                                assertFalse(MathUtils.equals(arr1, arr2));
                                                            }

    @Test
                                                            public void testEquals_WithSingleElementArrays() {
                                                                double[] arr1 = {42.0};
                                                                double[] arr2 = {42.0};
                                                                assertTrue(MathUtils.equals(arr1, arr2));
                                                            }

    @Test
                                                            public void testEquals_WithVeryLargeArrays() {
                                                                int size = 10000;
                                                                double[] arr1 = new double[size];
                                                                double[] arr2 = new double[size];
                                                                for (int i = 0; i < size; i++) {
                                                                    arr1[i] = i;
                                                                    arr2[i] = i;
                                                                }
                                                                assertTrue(MathUtils.equals(arr1, arr2));
                                                            }

    @Test
                                                    public void testEquals_InvalidMaxUlps() {
                                                        // Setup expected exception rule
                                                        org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                                        exceptionRule.expect(IllegalArgumentException.class);
                                                        
                                                        // maxUlps must be > 0 and < NAN_GAP
                                                        MathUtils.equals(1.0, 1.0, 0); // maxUlps <= 0
                                                        
                                                        // We can't test maxUlps >= NAN_GAP directly since NAN_GAP is private
                                                        // But we can verify the method throws for negative maxUlps
                                                        exceptionRule.expect(IllegalArgumentException.class);
                                                        MathUtils.equals(1.0, 1.0, -1);
                                                    }

    @Test
                                                    public void testCosh() {
                                                        // Test x = 0 (should return 1)
                                                        assertEquals(1.0, MathUtils.cosh(0.0), MathUtils.EPSILON);
                                                        
                                                        // Test positive value
                                                        double x = 1.0;
                                                        double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                                        assertEquals(expected, MathUtils.cosh(x), MathUtils.EPSILON);
                                                        
                                                        // Test negative value (should be same as positive due to even function property)
                                                        assertEquals(expected, MathUtils.cosh(-x), MathUtils.EPSILON);
                                                        
                                                        // Test larger value
                                                        x = 5.0;
                                                        expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                                        assertEquals(expected, MathUtils.cosh(x), MathUtils.EPSILON);
                                                        
                                                        // Test very small value
                                                        x = 1e-10;
                                                        expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                                        assertEquals(expected, MathUtils.cosh(x), MathUtils.EPSILON);
                                                    }

    @Test
                                                    public void testCosh1() {
                                                        // Test at x=0 where cosh(0)=1 but mutant would return 0
                                                        assertEquals(1.0, MathUtils.cosh(0.0), 0.0001);
                                                        
                                                        // Test positive value
                                                        double x = 1.0;
                                                        double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                                        assertEquals(expected, MathUtils.cosh(x), 0.0001);
                                                        
                                                        // Test negative value (should be same as positive)
                                                        double xNeg = -1.0;
                                                        assertEquals(MathUtils.cosh(x), MathUtils.cosh(xNeg), 0.0001);
                                                        
                                                        // Test larger value where difference would be more pronounced
                                                        double xLarge = 5.0;
                                                        double expectedLarge = (Math.exp(xLarge) + Math.exp(-xLarge)) / 2.0;
                                                        assertEquals(expectedLarge, MathUtils.cosh(xLarge), 0.0001);
                                                        
                                                        // Test small positive value
                                                        double xSmall = 0.5;
                                                        double expectedSmall = (Math.exp(xSmall) + Math.exp(-xSmall)) / 2.0;
                                                        assertEquals(expectedSmall, MathUtils.cosh(xSmall), 0.0001);
                                                    }

    @Test
                                                public void testAddAndCheck_NegativeBoundaryNoOverflow() {
                                                    // Test case where a + b equals Long.MIN_VALUE exactly
                                                    long a = Long.MIN_VALUE + 1;
                                                    long b = -1;
                                                    
                                                    // This should pass in original implementation but fail if condition was mutated to <
                                                    long result = MathUtils.addAndCheck(a, b);
                                                    assertEquals(Long.MIN_VALUE, result);
                                                    
                                                    // Also test the symmetric case
                                                    result = MathUtils.addAndCheck(b, a);
                                                    assertEquals(Long.MIN_VALUE, result);
                                                }

    @Test(expected = ArithmeticException.class)
                                                public void testAddAndCheck_NegativeOverflow() {
                                                    // Test case that should overflow
                                                    long a = Long.MIN_VALUE;
                                                    long b = -1;
                                                    
                                                    // This should throw in both original and mutated versions
                                                    MathUtils.addAndCheck(a, b);
                                                }

    @Test
                                                public void testCosh2() {
                                                    double x = 1.0;
                                                    double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                                    double actual = MathUtils.cosh(x);
                                                    assertEquals(expected, actual, MathUtils.EPSILON);
                                                    
                                                    // Test with negative value (cosh is even function)
                                                    x = -1.0;
                                                    expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                                    actual = MathUtils.cosh(x);
                                                    assertEquals(expected, actual, MathUtils.EPSILON);
                                                    
                                                    // Test with zero
                                                    x = 0.0;
                                                    expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                                    actual = MathUtils.cosh(x);
                                                    assertEquals(expected, actual, MathUtils.EPSILON);
                                                }

    @Test
                                                public void testCosh3() {
                                                    // Test with x = 0 (cosh(0) should be 1)
                                                    assertEquals(1.0, MathUtils.cosh(0.0), MathUtils.EPSILON);
                                                    
                                                    // Test with positive value
                                                    double x1 = 1.0;
                                                    double expected1 = (Math.exp(x1) + Math.exp(-x1)) / 2.0;
                                                    assertEquals(expected1, MathUtils.cosh(x1), MathUtils.EPSILON);
                                                    
                                                    // Test with negative value
                                                    double x2 = -1.0;
                                                    double expected2 = (Math.exp(x2) + Math.exp(-x2)) / 2.0;
                                                    assertEquals(expected2, MathUtils.cosh(x2), MathUtils.EPSILON);
                                                    
                                                    // Test with larger value
                                                    double x3 = 5.0;
                                                    double expected3 = (Math.exp(x3) + Math.exp(-x3)) / 2.0;
                                                    assertEquals(expected3, MathUtils.cosh(x3), MathUtils.EPSILON);
                                                }

    @Test
                                                public void testCosh4() {
                                                    // Test cosh(0) = 1.0
                                                    assertEquals(1.0, MathUtils.cosh(0.0), 0.0);
                                                    
                                                    // Test cosh(1) = (e + 1/e)/2 ≈ 1.543080634815244
                                                    assertEquals(1.543080634815244, MathUtils.cosh(1.0), 1e-15);
                                                    
                                                    // Test cosh(-1) should be same as cosh(1)
                                                    assertEquals(MathUtils.cosh(1.0), MathUtils.cosh(-1.0), 0.0);
                                                    
                                                    // Test another value cosh(2) = (e² + 1/e²)/2 ≈ 3.7621956910836314
                                                    assertEquals(3.7621956910836314, MathUtils.cosh(2.0), 1e-15);
                                                }

    @Test
                                                public void testCosh5() {
                                                    // Test with 0 (cosh(0) should be 1)
                                                    assertEquals(1.0, MathUtils.cosh(0.0), 1e-15);
                                                    
                                                    // Test with 1 (cosh(1) ≈ 1.543080634815244)
                                                    assertEquals(1.543080634815244, MathUtils.cosh(1.0), 1e-15);
                                                    
                                                    // Test with -1 (should be same as cosh(1))
                                                    assertEquals(1.543080634815244, MathUtils.cosh(-1.0), 1e-15);
                                                    
                                                    // Test with a larger value (cosh(2) ≈ 3.7621956910836314)
                                                    assertEquals(3.7621956910836314, MathUtils.cosh(2.0), 1e-15);
                                                }

    @Test
                                            public void testCosh6() {
                                                // Test symmetry property (should hold for original but fail for mutant)
                                                double x = 1.5;
                                                assertEquals(MathUtils.cosh(x), MathUtils.cosh(-x), 1e-10);
                                                
                                                // Test known value (cosh(0) should be 1)
                                                assertEquals(1.0, MathUtils.cosh(0), 1e-10);
                                                
                                                // Test positive input
                                                double posInput = 2.0;
                                                double expectedPos = (Math.exp(posInput) + Math.exp(-posInput)) / 2;
                                                assertEquals(expectedPos, MathUtils.cosh(posInput), 1e-10);
                                                
                                                // Test negative input
                                                double negInput = -2.0;
                                                double expectedNeg = (Math.exp(negInput) + Math.exp(-negInput)) / 2;
                                                assertEquals(expectedNeg, MathUtils.cosh(negInput), 1e-10);
                                                
                                                // Test large value
                                                double largeInput = 50.0;
                                                double expectedLarge = (Math.exp(largeInput) + Math.exp(-largeInput)) / 2;
                                                assertEquals(expectedLarge, MathUtils.cosh(largeInput), 1e-10);
                                            }

    @Test
                                            public void testCosh7() {
                                                // Test with positive value
                                                double x = 1.0;
                                                double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                                double actual = MathUtils.cosh(x);
                                                assertEquals("cosh(1.0) should return correct value", expected, actual, 1e-10);
                                                
                                                // Test with negative value (should be same as positive due to cosh symmetry)
                                                x = -1.0;
                                                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                                actual = MathUtils.cosh(x);
                                                assertEquals("cosh(-1.0) should return same as cosh(1.0)", expected, actual, 1e-10);
                                                
                                                // Test with zero (both implementations would return same value)
                                                x = 0.0;
                                                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                                actual = MathUtils.cosh(x);
                                                assertEquals("cosh(0.0) should return 1.0", expected, actual, 1e-10);
                                                
                                                // Test with larger value
                                                x = 2.5;
                                                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                                actual = MathUtils.cosh(x);
                                                assertEquals("cosh(2.5) should return correct value", expected, actual, 1e-10);
                                            }

    @Test
                                            public void testCosh8() {
                                                // Test with negative value - this should catch the mutant
                                                double negativeInput = -1.0;
                                                double expectedNegative = (Math.exp(negativeInput) + Math.exp(-negativeInput)) / 2.0;
                                                assertEquals("Cosh of negative value incorrect", 
                                                             expectedNegative, 
                                                             MathUtils.cosh(negativeInput), 
                                                             1e-15);
                                                
                                                // Test with positive value for completeness
                                                double positiveInput = 1.0;
                                                double expectedPositive = (Math.exp(positiveInput) + Math.exp(-positiveInput)) / 2.0;
                                                assertEquals("Cosh of positive value incorrect",
                                                             expectedPositive,
                                                             MathUtils.cosh(positiveInput),
                                                             1e-15);
                                                
                                                // Test with zero - boundary case
                                                assertEquals("Cosh of zero should be 1",
                                                             1.0,
                                                             MathUtils.cosh(0.0),
                                                             0.0);
                                                
                                                // Test with large negative value
                                                double largeNegative = -100.0;
                                                double expectedLargeNegative = (Math.exp(largeNegative) + Math.exp(-largeNegative)) / 2.0;
                                                assertEquals("Cosh of large negative value incorrect",
                                                             expectedLargeNegative,
                                                             MathUtils.cosh(largeNegative),
                                                             1e-15);
                                            }

    @Test
                                        public void testCosh9() {
                                            // Test case 1: x = 0
                                            // cosh(0) = 1, mutant would return e^0 = 1 (same)
                                            // This case wouldn't catch the mutant
                                            assertEquals(1.0, MathUtils.cosh(0.0), 1e-10);
                                            
                                            // Test case 2: x = 1
                                            // cosh(1) ≈ 1.543080634815244
                                            // Mutant would return e^-1 ≈ 0.36787944117
                                            double x = 1.0;
                                            double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                            assertEquals(expected, MathUtils.cosh(x), 1e-10);
                                            
                                            // Test case 3: x = -1
                                            // cosh(-1) ≈ 1.543080634815244 (same as cosh(1))
                                            // Mutant would return e^1 ≈ 2.71828182846
                                            x = -1.0;
                                            expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                            assertEquals(expected, MathUtils.cosh(x), 1e-10);
                                            
                                            // Test case 4: x = 2.5
                                            // Larger value to show significant difference
                                            x = 2.5;
                                            expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                            assertEquals(expected, MathUtils.cosh(x), 1e-10);
                                        }

    @Test
                                        public void testCoshDetectsMutant() {
                                            // Test positive value where e^x and e^-x are different
                                            double x = 1.0;
                                            double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                            double actual = MathUtils.cosh(x);
                                            assertEquals("Cosh calculation is incorrect", expected, actual, 1e-10);
                                            
                                            // Test negative value to verify symmetry
                                            double negativeX = -1.0;
                                            assertEquals("Cosh should be symmetric", 
                                                         MathUtils.cosh(x), 
                                                         MathUtils.cosh(negativeX), 
                                                         1e-10);
                                            
                                            // Test zero case
                                            assertEquals("Cosh(0) should be 1", 
                                                         1.0, 
                                                         MathUtils.cosh(0.0), 
                                                         1e-10);
                                            
                                            // Test larger value to ensure proper behavior
                                            double largeX = 10.0;
                                            double expectedLarge = (Math.exp(largeX) + Math.exp(-largeX)) / 2.0;
                                            assertEquals("Cosh calculation for large x is incorrect", 
                                                         expectedLarge, 
                                                         MathUtils.cosh(largeX), 
                                                         1e-10);
                                        }

    @Test
                                        public void testCosh10() {
                                            // Test with positive value
                                            double x = 1.0;
                                            double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                            double actual = MathUtils.cosh(x);
                                            assertEquals("Cosh of positive value incorrect", expected, actual, 1e-15);
                                            
                                            // Test with negative value (should be same as positive due to symmetry)
                                            double xNeg = -1.0;
                                            assertEquals("Cosh should be symmetric", actual, MathUtils.cosh(xNeg), 1e-15);
                                            
                                            // Test with zero
                                            assertEquals("Cosh(0) should be 1", 1.0, MathUtils.cosh(0.0), 1e-15);
                                            
                                            // Test with larger value
                                            x = 5.0;
                                            expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                            actual = MathUtils.cosh(x);
                                            assertEquals("Cosh of larger value incorrect", expected, actual, 1e-10);
                                        }

    @Test
                                    public void testCosh11() {
                                        // Test with 0.0 - cosh(0) should be 1.0
                                        assertEquals(1.0, MathUtils.cosh(0.0), 1e-15);
                                        
                                        // Test with 1.0 - known value of cosh(1)
                                        double expectedCosh1 = (Math.exp(1.0) + Math.exp(-1.0)) / 2.0;
                                        assertEquals(expectedCosh1, MathUtils.cosh(1.0), 1e-15);
                                        
                                        // Test with -1.0 - cosh is even function
                                        assertEquals(expectedCosh1, MathUtils.cosh(-1.0), 1e-15);
                                        
                                        // Test with a larger value (2.0)
                                        double expectedCosh2 = (Math.exp(2.0) + Math.exp(-2.0)) / 2.0;
                                        assertEquals(expectedCosh2, MathUtils.cosh(2.0), 1e-15);
                                        
                                        // Test with a small value (0.5)
                                        double expectedCosh05 = (Math.exp(0.5) + Math.exp(-0.5)) / 2.0;
                                        assertEquals(expectedCosh05, MathUtils.cosh(0.5), 1e-15);
                                    }

    @Test
                                    public void testCosh12() {
                                        // Test at x = 0, where cosh(0) should be exactly 1.0
                                        assertEquals(1.0, MathUtils.cosh(0.0), 0.0);
                                        
                                        // Test at x = 1, where cosh(1) ≈ 1.543080634815244
                                        assertEquals(1.543080634815244, MathUtils.cosh(1.0), 1e-15);
                                        
                                        // Test at x = -1, where cosh(-1) should be same as cosh(1)
                                        assertEquals(MathUtils.cosh(1.0), MathUtils.cosh(-1.0), 0.0);
                                        
                                        // Test at x = 2, where cosh(2) ≈ 3.7621956910836314
                                        assertEquals(3.7621956910836314, MathUtils.cosh(2.0), 1e-15);
                                        
                                        // Test at a larger value x = 10, where cosh(10) ≈ 11013.232920103324
                                        assertEquals(11013.232920103324, MathUtils.cosh(10.0), 1e-11);
                                    }

    @Test
                            public void testAddAndCheckNegativeBoundary() {
                                // Test case where a + b exactly equals Long.MIN_VALUE
                                long a = Long.MIN_VALUE + 1;
                                long b = -1;
                                
                                // Should pass as Long.MIN_VALUE - (-1) == Long.MIN_VALUE + 1 == a
                                // So condition Long.MIN_VALUE - b <= a holds (they're equal)
                                long result = MathUtils.addAndCheck(a, b);
                                assertEquals(Long.MIN_VALUE, result);
                                
                                // Test another boundary case
                                a = Long.MIN_VALUE / 2;
                                b = Long.MIN_VALUE / 2 - 1;
                                try {
                                    MathUtils.addAndCheck(a, b);
                                    fail("Expected ArithmeticException");
                                } catch (ArithmeticException e) {
                                    // Expected
                                }
                                
                                // Test case where a = Long.MIN_VALUE and b = 0
                                result = MathUtils.addAndCheck(Long.MIN_VALUE, 0);
                                assertEquals(Long.MIN_VALUE, result);
                            }

    @Test
                            public void testCosh13() {
                                // Test with positive value
                                double x = 1.0;
                                double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                double actual = MathUtils.cosh(x);
                                assertEquals("Cosh calculation for positive value", expected, actual, 1e-10);
                                
                                // Test with negative value (should be same as positive due to even function property)
                                x = -1.0;
                                expected = (Math.exp(-x) + Math.exp(x)) / 2.0;
                                actual = MathUtils.cosh(x);
                                assertEquals("Cosh calculation for negative value", expected, actual, 1e-10);
                                
                                // Test with zero
                                x = 0.0;
                                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                actual = MathUtils.cosh(x);
                                assertEquals("Cosh calculation for zero", expected, actual, 1e-10);
                                
                                // Test with larger value
                                x = 2.5;
                                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                actual = MathUtils.cosh(x);
                                assertEquals("Cosh calculation for larger value", expected, actual, 1e-10);
                            }

    @Test
                            public void testCosh14() {
                                // Test x = 0 (cosh(0) should be 1)
                                double result1 = MathUtils.cosh(0.0);
                                assertEquals("cosh(0) should be 1", 1.0, result1, MathUtils.EPSILON);
                                
                                // Test x = 1 (cosh(1) ≈ 1.5430806348152437)
                                double result2 = MathUtils.cosh(1.0);
                                assertEquals(1.5430806348152437, result2, MathUtils.EPSILON);
                                
                                // Test x = -1 (should be same as x=1)
                                double result3 = MathUtils.cosh(-1.0);
                                assertEquals(result2, result3, MathUtils.EPSILON);
                                
                                // Test x = 2 (cosh(2) ≈ 3.7621956910836314)
                                double result4 = MathUtils.cosh(2.0);
                                assertEquals(3.7621956910836314, result4, MathUtils.EPSILON);
                                
                                // Test large x value (should be approximately e^x/2)
                                double x = 10.0;
                                double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                double result5 = MathUtils.cosh(x);
                                assertEquals(expected, result5, MathUtils.EPSILON);
                            }

    @Test
                            public void testCosh15() {
                                // Test cosh(0) which should be 1.0
                                assertEquals(1.0, MathUtils.cosh(0.0), 1e-10);
                                
                                // Test positive value
                                double x = 1.0;
                                double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                assertEquals(expected, MathUtils.cosh(x), 1e-10);
                                
                                // Test negative value
                                x = -1.0;
                                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                assertEquals(expected, MathUtils.cosh(x), 1e-10);
                                
                                // Test larger value
                                x = 2.5;
                                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                                assertEquals(expected, MathUtils.cosh(x), 1e-10);
                            }

    @Test
                        public void testCoshDetectsAdditionToMultiplicationMutant() {
                            // Test with positive value
                            double x = 1.0;
                            double expected = (Math.exp(x) + Math.exp(-x)) / 2.0; // Proper cosh calculation
                            double actual = MathUtils.cosh(x);
                            assertEquals("Cosh calculation for positive value", expected, actual, MathUtils.EPSILON);
                            
                            // Test with negative value
                            x = -1.0;
                            expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                            actual = MathUtils.cosh(x);
                            assertEquals("Cosh calculation for negative value", expected, actual, MathUtils.EPSILON);
                            
                            // Test with larger value
                            x = 5.0;
                            expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                            actual = MathUtils.cosh(x);
                            assertEquals("Cosh calculation for larger value", expected, actual, MathUtils.EPSILON);
                        }

    @Test
                        public void testCosh16() {
                            // Test with 0 - both implementations would return same result
                            assertEquals(1.0, MathUtils.cosh(0.0), 1e-10);
                            
                            // Test with positive value where we know expected result
                            // cosh(1) ≈ 1.543080634815244
                            assertEquals(1.543080634815244, MathUtils.cosh(1.0), 1e-10);
                            
                            // Test with negative value where we know expected result
                            // cosh(-1) ≈ 1.543080634815244 (same as cosh(1))
                            assertEquals(1.543080634815244, MathUtils.cosh(-1.0), 1e-10);
                            
                            // Test with larger value
                            // cosh(2) ≈ 3.7621956910836314
                            assertEquals(3.7621956910836314, MathUtils.cosh(2.0), 1e-10);
                        }

    @Test
            public void testAddAndCheck_NegativeBoundaryCase() {
                // Test case where a exactly equals (Long.MIN_VALUE - b)
                long a = Long.MIN_VALUE + 1;
                long b = -1;
                
                // Original behavior should allow this addition
                long expected = Long.MIN_VALUE;
                assertEquals(expected, MathUtils.addAndCheck(a, b));
                
                // Also test the symmetric case
                assertEquals(expected, MathUtils.addAndCheck(b, a));
                
                // Test the exact boundary case where a + b = Long.MIN_VALUE
                a = Long.MIN_VALUE;
                b = 0;
                expected = Long.MIN_VALUE;
                assertEquals(expected, MathUtils.addAndCheck(a, b));
            }

    @Test(expected = ArithmeticException.class)
            public void testAddAndCheck_NegativeOverflow1() {
                // Test case that should overflow
                long a = Long.MIN_VALUE;
                long b = -1;
                try {
                    // Use reflection to access the private method
                    Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, Localizable.class);
                    method.setAccessible(true);
                    Localizable pattern = LocalizedFormats.OVERFLOW_IN_ADDITION; // Using existing enum constant
                    method.invoke(null, a, b, pattern);
                } catch (InvocationTargetException e) {
                    if (e.getCause() instanceof ArithmeticException) {
                        throw (ArithmeticException) e.getCause();
                    }
                    throw new RuntimeException(e);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

    @Test
            public void testCosh17() {
                // Test with 0 - cosh(0) should be 1
                assertEquals(1.0, MathUtils.cosh(0.0), 1e-15);
                
                // Test with 1 - cosh(1) should be (e + 1/e)/2 ≈ 1.543080634815244
                assertEquals(1.543080634815244, MathUtils.cosh(1.0), 1e-15);
                
                // Test with -1 - cosh is even function, same result as positive
                assertEquals(1.543080634815244, MathUtils.cosh(-1.0), 1e-15);
                
                // Test with a larger value (2) - cosh(2) should be (e² + 1/e²)/2 ≈ 3.7621956910836314
                assertEquals(3.7621956910836314, MathUtils.cosh(2.0), 1e-15);
            }

    @Test
            public void testCosh18() {
                // Test case for x = 0
                // cosh(0) should be 1.0
                double x = 0.0;
                double expected = 1.0;
                double actual = MathUtils.cosh(x);
                assertEquals("cosh(0) should be 1.0", expected, actual, MathUtils.EPSILON);
                
                // Test case for x = 1
                // cosh(1) ≈ 1.543080634815244
                x = 1.0;
                expected = (Math.exp(1) + Math.exp(-1)) / 2.0; // ≈ 1.543080634815244
                actual = MathUtils.cosh(x);
                assertEquals("cosh(1) should be (e^1 + e^-1)/2", expected, actual, MathUtils.EPSILON);
                
                // Test case for x = -1
                // cosh is an even function, so cosh(-1) should equal cosh(1)
                x = -1.0;
                double expectedNegative = MathUtils.cosh(1.0);
                actual = MathUtils.cosh(x);
                assertEquals("cosh(-1) should equal cosh(1)", expectedNegative, actual, MathUtils.EPSILON);
                
                // Test case for x = 2
                // cosh(2) ≈ 3.7621956910836314
                x = 2.0;
                expected = (Math.exp(2) + Math.exp(-2)) / 2.0; // ≈ 3.7621956910836314
                actual = MathUtils.cosh(x);
                assertEquals("cosh(2) should be (e^2 + e^-2)/2", expected, actual, MathUtils.EPSILON);
            }

    @Test
            public void testAddAndCheckBasic() {
                // Test basic addition
                assertEquals(5, MathUtils.addAndCheck(2, 3));
                assertEquals(-1, MathUtils.addAndCheck(2, -3));
                assertEquals(0, MathUtils.addAndCheck(-2, 2));
            }

    @Test
            public void testAddAndCheckSymmetry() {
                // Test symmetry handling (a > b case)
                assertEquals(5, MathUtils.addAndCheck(3, 2));
                assertEquals(Long.MAX_VALUE, MathUtils.addAndCheck(Long.MAX_VALUE - 1, 1));
            }

    @Test
            public void testAddAndCheckPositiveOverflow() {
                // Test positive overflow
                thrown.expect(ArithmeticException.class);
                MathUtils.addAndCheck(Long.MAX_VALUE, 1);
            }

    @Test
            public void testAddAndCheckNegativeOverflow() {
                // Test negative overflow
                thrown.expect(ArithmeticException.class);
                MathUtils.addAndCheck(Long.MIN_VALUE, -1);
            }

    @Test
            public void testAddAndCheckBoundaryCases() {
                // Test boundary cases
                assertEquals(Long.MAX_VALUE, MathUtils.addAndCheck(Long.MAX_VALUE - 1, 1));
                assertEquals(Long.MIN_VALUE, MathUtils.addAndCheck(Long.MIN_VALUE + 1, -1));
                
                // Just below overflow
                assertEquals(Long.MAX_VALUE - 1, MathUtils.addAndCheck(Long.MAX_VALUE - 2, 1));
                assertEquals(Long.MIN_VALUE + 1, MathUtils.addAndCheck(Long.MIN_VALUE + 2, -1));
            }

    @Test
            public void testAddAndCheckBothNegative() {
                // Test both negative case
                assertEquals(-5, MathUtils.addAndCheck(-2, -3));
            }

    @Test
            public void testAddAndCheckOppositeSignsNoOverflow() {
                // Test opposite signs that don't cause overflow
                assertEquals(0, MathUtils.addAndCheck(Long.MAX_VALUE, -Long.MAX_VALUE));
                assertEquals(-1, MathUtils.addAndCheck(Long.MAX_VALUE, Long.MIN_VALUE));
            }

    @Test
        public void testEqualsOrderMattersForUlpsComparison() {
            // Test case where x and y are very close but not equal
            double x = 1.0000000000000002;  // Just above 1.0
            double y = 1.0;
            
            // The original equals(x,y,1) would return true because x is within 1 ulp of y
            // The mutated equals(y,x,1) would return false because y is not within 1 ulp of x
            // (due to how floating-point numbers are represented)
            
            // Verify the correct order matters by testing both directions
            assertTrue("x should equal y within 1 ulp", MathUtils.equals(x, y, 1));
            assertFalse("y should not equal x within 1 ulp", MathUtils.equals(y, x, 1));
            
            // This test will fail if the parameter order is swapped in the equals comparison
        }

    @Test
        public void testEqualsWithUlpsShouldBeOrderSensitive() {
            // Test case where x and y are very close but not equal
            double x = 1.0000000000000002;  // Just above 1.0
            double y = 1.0;
            
            // With original order (x,y), these should be considered equal within 1 ULP
            assertTrue(MathUtils.equals(x, y, 1));
            
            // If order is reversed (y,x), it might give different result
            // This will catch the mutant where parameter order is swapped
            assertTrue("Method should be order-insensitive for ULP comparison", 
                      MathUtils.equals(y, x, 1));
            
            // Additional edge case with NaN
            double nan = Double.NaN;
            assertFalse(MathUtils.equals(nan, y, 1));
            assertFalse(MathUtils.equals(y, nan, 1));
            
            // Test with values that are exactly 1 ULP apart
            double a = Double.longBitsToDouble(Double.doubleToLongBits(1.0) + 1);
            assertTrue(MathUtils.equals(1.0, a, 1));
            assertTrue(MathUtils.equals(a, 1.0, 1));
        }

    @Test
    public void testEqualsWithCloseNumbers() {
        // Test case where x and y are different but very close numbers
        // that should be considered equal within 1 ULP
        double x = Double.longBitsToDouble(Double.doubleToLongBits(1.0) + 1);
        double y = 1.0;
        
        // The original implementation would return equals(x, y, 1)
        // The mutant would return equals(y, x, 1)
        // While mathematically equivalent, we want to ensure the exact behavior is preserved
        
        // Test both orders to ensure consistency
        assertTrue(MathUtils.equals(x, y, 1));
        assertTrue(MathUtils.equals(y, x, 1));
        
        // Test with numbers that are 2 ULPs apart to ensure they're not equal
        double x2 = Double.longBitsToDouble(Double.doubleToLongBits(1.0) + 2);
        assertFalse(MathUtils.equals(x2, y, 1));
        assertFalse(MathUtils.equals(y, x2, 1));
        
        // Test with NaN values
        assertTrue(MathUtils.equals(Double.NaN, Double.NaN, 1));
        
        // Test with very small numbers near epsilon
        double small1 = Double.MIN_VALUE;
        double small2 = Double.longBitsToDouble(Double.doubleToLongBits(Double.MIN_VALUE) + 1);
        assertFalse(MathUtils.equals(small1, small2, 0)); // Not equal with 0 ULP tolerance
        assertTrue(MathUtils.equals(small1, small2, 1));  // Equal with 1 ULP tolerance
    }

}
