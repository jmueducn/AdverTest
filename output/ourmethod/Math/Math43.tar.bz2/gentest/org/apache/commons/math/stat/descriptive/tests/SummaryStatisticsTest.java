package gentest.org.apache.commons.math.stat.descriptive.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.descriptive.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.moment.GeometricMean;
import org.apache.commons.math.stat.descriptive.moment.Mean;
import org.apache.commons.math.stat.descriptive.moment.SecondMoment;
import org.apache.commons.math.stat.descriptive.moment.Variance;
import org.apache.commons.math.stat.descriptive.rank.Max;
import org.apache.commons.math.stat.descriptive.rank.Min;
import org.apache.commons.math.stat.descriptive.summary.Sum;
import org.apache.commons.math.stat.descriptive.summary.SumOfLogs;
import org.apache.commons.math.stat.descriptive.summary.SumOfSquares;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.Precision;
import org.apache.commons.math.util.FastMath;
 
public class SummaryStatisticsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                            public void testAddValue_IncrementsAllDefaultImplementations() {
                                                // Setup
                                                SummaryStatistics stats = new SummaryStatistics();
                                                double value = 5.0;
                                                
                                                // Execute
                                                stats.addValue(value);
                                                
                                                // Verify
                                                assertEquals(1, stats.getN());
                                                // Verify sum was incremented (default implementation)
                                                assertEquals(value, stats.getSum(), 0.0001);
                                                // Verify sum of squares was incremented
                                                assertEquals(value * value, stats.getSumsq(), 0.0001);
                                                // Verify min was updated
                                                assertEquals(value, stats.getMin(), 0.0001);
                                                // Verify max was updated
                                                assertEquals(value, stats.getMax(), 0.0001);
                                                // Verify sum of logs was updated
                                                assertEquals(Math.log(value), stats.getSumOfLogs(), 0.0001);
                                            }

    @Test
                                            public void testAddValue_WithOverriddenImplementations() {
                                                // Setup
                                                SummaryStatistics stats = new SummaryStatistics();
                                                double value = 10.0;
                                                
                                                // Mock all implementations that can be overridden
                                                StorelessUnivariateStatistic mockSum = mock(StorelessUnivariateStatistic.class);
                                                StorelessUnivariateStatistic mockSumsq = mock(StorelessUnivariateStatistic.class);
                                                StorelessUnivariateStatistic mockMin = mock(StorelessUnivariateStatistic.class);
                                                StorelessUnivariateStatistic mockMax = mock(StorelessUnivariateStatistic.class);
                                                StorelessUnivariateStatistic mockSumLog = mock(StorelessUnivariateStatistic.class);
                                                StorelessUnivariateStatistic mockGeoMean = mock(StorelessUnivariateStatistic.class);
                                                StorelessUnivariateStatistic mockMean = mock(StorelessUnivariateStatistic.class);
                                                StorelessUnivariateStatistic mockVariance = mock(StorelessUnivariateStatistic.class);
                                                
                                                // Set the mock implementations
                                                stats.setSumImpl(mockSum);
                                                stats.setSumsqImpl(mockSumsq);
                                                stats.setMinImpl(mockMin);
                                                stats.setMaxImpl(mockMax);
                                                stats.setSumLogImpl(mockSumLog);
                                                stats.setGeoMeanImpl(mockGeoMean);
                                                stats.setMeanImpl(mockMean);
                                                stats.setVarianceImpl(mockVariance);
                                                
                                                // Execute
                                                stats.addValue(value);
                                                
                                                // Verify all implementations were called
                                                verify(mockSum).increment(value);
                                                verify(mockSumsq).increment(value);
                                                verify(mockMin).increment(value);
                                                verify(mockMax).increment(value);
                                                verify(mockSumLog).increment(value);
                                                verify(mockGeoMean).increment(value);
                                                verify(mockMean).increment(value);
                                                verify(mockVariance).increment(value);
                                                
                                                // Verify n was incremented
                                                assertEquals(1, stats.getN());
                                            }

    @Test
                                            public void testAddValue_MultipleValues() {
                                                // Setup
                                                SummaryStatistics stats = new SummaryStatistics();
                                                double[] values = {2.5, 3.7, 1.2, 4.8};
                                                
                                                // Execute
                                                for (double value : values) {
                                                    stats.addValue(value);
                                                }
                                                
                                                // Verify
                                                assertEquals(values.length, stats.getN());
                                                // Verify sum
                                                double expectedSum = 0;
                                                for (double value : values) expectedSum += value;
                                                assertEquals(expectedSum, stats.getSum(), 0.0001);
                                                // Verify min
                                                assertEquals(1.2, stats.getMin(), 0.0001);
                                                // Verify max
                                                assertEquals(4.8, stats.getMax(), 0.0001);
                                            }

    @Test
                                            public void testAddValue_WithNaNValue() {
                                                // Setup
                                                SummaryStatistics stats = new SummaryStatistics();
                                                double nanValue = Double.NaN;
                                                
                                                // Execute
                                                stats.addValue(nanValue);
                                                
                                                // Verify
                                                assertEquals(1, stats.getN());
                                                assertTrue(Double.isNaN(stats.getSum()));
                                                assertTrue(Double.isNaN(stats.getSumsq()));
                                                assertTrue(Double.isNaN(stats.getMin()));
                                                assertTrue(Double.isNaN(stats.getMax()));
                                                assertTrue(Double.isNaN(stats.getSumOfLogs()));
                                            }

    @Test
                                            public void testAddValue_WithInfiniteValue() {
                                                // Setup
                                                SummaryStatistics stats = new SummaryStatistics();
                                                double posInf = Double.POSITIVE_INFINITY;
                                                double negInf = Double.NEGATIVE_INFINITY;
                                                
                                                // Execute and verify positive infinity
                                                stats.addValue(posInf);
                                                assertEquals(1, stats.getN());
                                                assertEquals(posInf, stats.getSum(), 0.0001);
                                                assertEquals(posInf, stats.getSumsq(), 0.0001);
                                                assertEquals(posInf, stats.getMax(), 0.0001);
                                                assertEquals(posInf, stats.getMin(), 0.0001);
                                                
                                                // Reset and test negative infinity
                                                stats.clear();
                                                stats.addValue(negInf);
                                                assertEquals(1, stats.getN());
                                                assertEquals(negInf, stats.getSum(), 0.0001);
                                                assertEquals(posInf, stats.getSumsq(), 0.0001); // square of infinity is positive infinity
                                                assertEquals(negInf, stats.getMax(), 0.0001);
                                                assertEquals(negInf, stats.getMin(), 0.0001);
                                            }

    @Test
                                            public void testAddValue_WithZeroValue() {
                                                // Setup
                                                SummaryStatistics stats = new SummaryStatistics();
                                                double zero = 0.0;
                                                
                                                // Execute
                                                stats.addValue(zero);
                                                
                                                // Verify
                                                assertEquals(1, stats.getN());
                                                assertEquals(0.0, stats.getSum(), 0.0001);
                                                assertEquals(0.0, stats.getSumsq(), 0.0001);
                                                assertEquals(0.0, stats.getMin(), 0.0001);
                                                assertEquals(0.0, stats.getMax(), 0.0001);
                                                // Sum of logs should be negative infinity for log(0)
                                                assertEquals(Double.NEGATIVE_INFINITY, stats.getSumOfLogs(), 0.0001);
                                            }

    @Test
                                            public void testAddValue_WithNegativeValue() {
                                                // Setup
                                                SummaryStatistics stats = new SummaryStatistics();
                                                double negativeValue = -3.5;
                                                
                                                // Execute
                                                stats.addValue(negativeValue);
                                                
                                                // Verify
                                                assertEquals(1, stats.getN());
                                                assertEquals(negativeValue, stats.getSum(), 0.0001);
                                                assertEquals(negativeValue * negativeValue, stats.getSumsq(), 0.0001);
                                                assertEquals(negativeValue, stats.getMin(), 0.0001);
                                                assertEquals(negativeValue, stats.getMax(), 0.0001);
                                                // Sum of logs should be NaN for negative values
                                                assertTrue(Double.isNaN(stats.getSumOfLogs()));
                                            }

    @Test
                                            public void testGetSummaryVarianceWithNonZeroValues() {
                                                // Create test object
                                                SummaryStatistics stats = new SummaryStatistics();
                                                
                                                // Add non-zero values (variance should be non-zero)
                                                stats.addValue(2.0);
                                                stats.addValue(4.0);
                                                stats.addValue(4.0);
                                                stats.addValue(4.0);
                                                stats.addValue(5.0);
                                                stats.addValue(5.0);
                                                stats.addValue(7.0);
                                                stats.addValue(9.0);
                                                
                                                // Get summary statistics
                                                StatisticalSummary summary = stats.getSummary();
                                                
                                                // Calculate expected variance manually
                                                double mean = (2+4+4+4+5+5+7+9)/8.0;
                                                double sumSq = Math.pow(2-mean,2) + 3*Math.pow(4-mean,2) + 
                                                               2*Math.pow(5-mean,2) + Math.pow(7-mean,2) + Math.pow(9-mean,2);
                                                double expectedVariance = sumSq / 7; // sample variance (n-1)
                                                
                                                // Verify variance is calculated correctly
                                                assertEquals("Variance should match expected calculation", 
                                                            expectedVariance, summary.getVariance(), 0.0001);
                                                
                                                // Also verify other statistics as they might be affected
                                                assertEquals(8L, summary.getN());
                                                assertEquals(2.0, summary.getMin(), 0.0001);
                                                assertEquals(9.0, summary.getMax(), 0.0001);
                                                assertEquals(mean, summary.getMean(), 0.0001);
                                            }

    @Test
                                        public void testGetSummaryVarianceWithAddedValues() {
                                            // Create a SummaryStatistics instance
                                            SummaryStatistics stats = new SummaryStatistics();
                                            
                                            // Add test values (these are chosen to produce known variance)
                                            stats.addValue(2.0);
                                            stats.addValue(4.0);
                                            stats.addValue(4.0);
                                            stats.addValue(4.0);
                                            stats.addValue(5.0);
                                            stats.addValue(5.0);
                                            stats.addValue(7.0);
                                            stats.addValue(9.0);
                                            
                                            // Calculate expected values manually
                                            double expectedMean = (2+4+4+4+5+5+7+9)/8.0; // 5.0
                                            double expectedSum = 40.0;
                                            long expectedN = 8;
                                            double expectedMin = 2.0;
                                            double expectedMax = 9.0;
                                            
                                            // Expected variance calculation:
                                            // sum of squares = 4 + 16 + 16 + 16 + 25 + 25 + 49 + 81 = 232
                                            // variance = (232 - (40^2)/8)/7 = (232 - 200)/7 = 32/7 ≈ 4.57142857
                                            double expectedVariance = 32.0/7.0;
                                            
                                            // Get the summary
                                            StatisticalSummary summary = stats.getSummary();
                                            
                                            // Verify all statistics
                                            assertEquals("Mean should match", expectedMean, summary.getMean(), 1e-10);
                                            assertEquals("Variance should match", expectedVariance, summary.getVariance(), 1e-10);
                                            assertEquals("N should match", expectedN, summary.getN());
                                            assertEquals("Max should match", expectedMax, summary.getMax(), 1e-10);
                                            assertEquals("Min should match", expectedMin, summary.getMin(), 1e-10);
                                            assertEquals("Sum should match", expectedSum, summary.getSum(), 1e-10);
                                            
                                            // The key assertion is the variance check - the mutant will fail this
                                            // because with -value, the second moment will be wrong, leading to wrong variance
                                        }

    @Test
                            public void testGetSummaryDetectsMeanDiscrepancy() {
                                // Create real SummaryStatistics and add some values
                                SummaryStatistics stats = new SummaryStatistics();
                                stats.addValue(1.0);
                                stats.addValue(2.0);
                                stats.addValue(3.0);
                                
                                // Get the original mean value
                                double originalMean = stats.getMean();
                                
                                // Mock the meanImpl to return a different value
                                StorelessUnivariateStatistic mockMeanImpl = mock(StorelessUnivariateStatistic.class);
                                when(mockMeanImpl.getResult()).thenReturn(originalMean + 1.0); // Different from real mean
                                stats.setMeanImpl(mockMeanImpl);
                                
                                // Call getSummary() - in original code this should detect the discrepancy
                                StatisticalSummary summary = stats.getSummary();
                                
                                // Verify the summary uses the correct mean value
                                // The mutant would use the mock value (originalMean+1) while original would use real mean
                                assertEquals(originalMean, summary.getMean(), 0.0001);
                                
                                // Additional verification that other stats are correct
                                assertEquals(3, summary.getN());
                                assertEquals(6.0, summary.getSum(), 0.0001);
                                assertEquals(3.0, summary.getMax(), 0.0001);
                                assertEquals(1.0, summary.getMin(), 0.0001);
                            }

    @Test
                    public void testGetSummaryDetectsVarianceImplDifference() throws Exception {
                        // Setup
                        SummaryStatistics stats = new SummaryStatistics();
                        
                        // Mock the variance and varianceImpl to return different values
                        StorelessUnivariateStatistic varianceImplMock = mock(StorelessUnivariateStatistic.class);
                        when(varianceImplMock.getResult()).thenReturn(5.0);
                        stats.setVarianceImpl(varianceImplMock);
                        
                        // Set different value for variance using reflection since it's protected
                        Variance varianceMock = mock(Variance.class);
                        when(varianceMock.getResult()).thenReturn(10.0);
                        Field varianceField = SummaryStatistics.class.getDeclaredField("variance");
                        varianceField.setAccessible(true);
                        varianceField.set(stats, varianceMock);
                        
                        // Mock other required values
                        StorelessUnivariateStatistic meanImplMock = mock(StorelessUnivariateStatistic.class);
                        when(meanImplMock.getResult()).thenReturn(2.0);
                        stats.setMeanImpl(meanImplMock);
                        
                        StorelessUnivariateStatistic nImplMock = mock(StorelessUnivariateStatistic.class);
                        when(nImplMock.getN()).thenReturn(10L);
                        Field nField = SummaryStatistics.class.getDeclaredField("n");
                        nField.setAccessible(true);
                        nField.set(stats, 10L);
                        
                        StorelessUnivariateStatistic maxImplMock = mock(StorelessUnivariateStatistic.class);
                        when(maxImplMock.getResult()).thenReturn(15.0);
                        stats.setMaxImpl(maxImplMock);
                        
                        StorelessUnivariateStatistic minImplMock = mock(StorelessUnivariateStatistic.class);
                        when(minImplMock.getResult()).thenReturn(1.0);
                        stats.setMinImpl(minImplMock);
                        
                        StorelessUnivariateStatistic sumImplMock = mock(StorelessUnivariateStatistic.class);
                        when(sumImplMock.getResult()).thenReturn(20.0);
                        stats.setSumImpl(sumImplMock);
                        
                        // Execute
                        StatisticalSummary result = stats.getSummary();
                        
                        // Verify - the variance in summary should come from varianceImpl (5.0) not variance (10.0)
                        // This assertion will fail with the mutant (which would use variance instead)
                        assertEquals(5.0, result.getVariance(), 0.0001);
                        
                        // Verify other values are correctly passed through
                        assertEquals(2.0, result.getMean(), 0.0001);
                        assertEquals(10L, result.getN());
                        assertEquals(15.0, result.getMax(), 0.0001);
                        assertEquals(1.0, result.getMin(), 0.0001);
                        assertEquals(20.0, result.getSum(), 0.0001);
                    }

    @Test
                    public void testGetSummaryDetectsSecondMomentMutation() {
                        // Create test data - simple dataset where variance is easy to compute manually
                        double[] values = {1.0, 2.0, 3.0};
                        
                        // Create summary statistics and add values
                        SummaryStatistics stats = new SummaryStatistics();
                        for (double value : values) {
                            stats.addValue(value);
                        }
                        
                        // Compute expected values manually
                        long expectedN = 3;
                        double expectedSum = 6.0;
                        double expectedMean = 2.0;
                        double expectedVariance = 1.0;  // sum of squared deviations / n
                        
                        // Get the summary
                        StatisticalSummary summary = stats.getSummary();
                        
                        // Verify all statistics
                        assertEquals("Count should match", expectedN, summary.getN());
                        assertEquals("Sum should match", expectedSum, summary.getSum(), 1e-10);
                        assertEquals("Mean should match", expectedMean, summary.getMean(), 1e-10);
                        assertEquals("Variance should match", expectedVariance, summary.getVariance(), 1e-10);
                        
                        // Also verify min and max
                        assertEquals("Min should match", 1.0, summary.getMin(), 1e-10);
                        assertEquals("Max should match", 3.0, summary.getMax(), 1e-10);
                    }

    @Test
                public void testGetSummaryVarianceWithSecondMoment() {
                    // Setup
                    SummaryStatistics stats = new SummaryStatistics();
                    
                    // Add test values that will produce known variance
                    stats.addValue(2.0);
                    stats.addValue(4.0);
                    stats.addValue(4.0);
                    stats.addValue(4.0);
                    stats.addValue(5.0);
                    stats.addValue(5.0);
                    stats.addValue(7.0);
                    stats.addValue(9.0);
                    
                    // Expected calculations:
                    // Mean = (2+4+4+4+5+5+7+9)/8 = 5.0
                    // Variance = sum((x-mean)^2)/n = (9+1+1+1+0+0+4+16)/8 = 32/8 = 4.0
                    
                    // Get summary and verify variance
                    StatisticalSummary summary = stats.getSummary();
                    
                    // Verify all summary values, especially variance which depends on second moment
                    assertEquals(8L, summary.getN());
                    assertEquals(40.0, summary.getSum(), 0.0001);
                    assertEquals(5.0, summary.getMean(), 0.0001);
                    assertEquals(4.0, summary.getVariance(), 0.0001);
                    assertEquals(2.0, summary.getStandardDeviation(), 0.0001);
                    assertEquals(9.0, summary.getMax(), 0.0001);
                    assertEquals(2.0, summary.getMin(), 0.0001);
                    
                    // If secondMoment wasn't properly updated, variance would be incorrect
                }

    @Test
    public void testGetSummaryDetectsMeanImplDifference() {
        // Create the object to test
        SummaryStatistics stats = new SummaryStatistics();
        
        // Mock the mean implementation to return a different value than the stored mean
        StorelessUnivariateStatistic mockMeanImpl = mock(StorelessUnivariateStatistic.class);
        when(mockMeanImpl.getResult()).thenReturn(5.0); // Mock returns 5.0
        
        // Set up the stats object
        stats.setMeanImpl(mockMeanImpl);
        // Use reflection to set the mean value since there's no setMean() method
        try {
            Field meanField = SummaryStatistics.class.getDeclaredField("mean");
            meanField.setAccessible(true);
            meanField.set(stats, 10.0); // Actual mean is 10.0
        } catch (Exception e) {
            fail("Failed to set mean field via reflection");
        }
        
        // This should trigger the original condition (meanImpl != mean) 
        // but mutant would only check (meanImpl != null)
        StatisticalSummary summary = stats.getSummary();
        
        // Verify the summary uses the correct mean value (should be 10.0, not 5.0)
        assertEquals(10.0, summary.getMean(), 0.0001);
        
        // Additional verification that mock was actually used
        verify(mockMeanImpl, atLeastOnce()).getResult();
    }


}
