package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.ConvergenceException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class UnivariateRealSolverUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                                                                                                                                                                                        public void testBracket_ConvergesWithinBounds() throws Exception {
                                                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                            when(function.value(anyDouble())).thenReturn(-1.0, 1.0); // First negative, then positive
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Test
                                                                                                                                                                                                                                                                                            double[] result = UnivariateRealSolverUtils.bracket(function, 0.5, 0.0, 1.0, 100);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                                                                                                                                            assertEquals(2, result.length);
                                                                                                                                                                                                                                                                                            assertTrue("Lower bound should be less than upper", result[0] < result[1]);
                                                                                                                                                                                                                                                                                            assertTrue("Should be within original bounds", result[0] >= 0.0 && result[1] <= 1.0);
                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                        public void testBracket_InitialAtLowerBound() throws Exception {
                                                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                            when(function.value(anyDouble())).thenReturn(-1.0, 1.0);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Test
                                                                                                                                                                                                                                                                                            double[] result = UnivariateRealSolverUtils.bracket(function, 0.0, 0.0, 1.0, 100);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                                                                                                                                            assertEquals(2, result.length);
                                                                                                                                                                                                                                                                                            assertTrue(result[0] >= 0.0 && result[1] <= 1.0);
                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                        public void testBracket_InitialAtUpperBound() throws Exception {
                                                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                            when(function.value(anyDouble())).thenReturn(1.0, -1.0);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Test
                                                                                                                                                                                                                                                                                            double[] result = UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 1.0, 100);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                                                                                                                                            assertEquals(2, result.length);
                                                                                                                                                                                                                                                                                            assertTrue(result[0] >= 0.0 && result[1] <= 1.0);
                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                        public void testBracket_AlreadyBracketed() throws Exception {
                                                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                            when(function.value(0.3)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                                            when(function.value(0.7)).thenReturn(1.0);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Test
                                                                                                                                                                                                                                                                                            double[] result = UnivariateRealSolverUtils.bracket(function, 0.5, 0.3, 0.7, 100);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                                                                                                                                            assertEquals(0.3, result[0], 0.0001);
                                                                                                                                                                                                                                                                                            assertEquals(0.7, result[1], 0.0001);
                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                        public void testBracket_SuccessfulBracketing() throws Exception {
                                                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                            when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                                            when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 1.0, 3.0, 100);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                                                                                                                                            assertEquals(2, result.length);
                                                                                                                                                                                                                                                                                            assertTrue(result[0] < result[1]);
                                                                                                                                                                                                                                                                                            assertTrue(function.value(result[0]) * function.value(result[1]) <= 0.0);
                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                        public void testBracket_RootAtLowerBound() throws Exception {
                                                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                            when(function.value(1.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                                                            when(function.value(1.1)).thenReturn(1.0);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 1.0, 3.0, 100);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            assertEquals(1.0, result[0], 0.0001);
                                                                                                                                                                                                                                                                                            assertTrue(result[1] > 1.0);
                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                        public void testBracket_RootAtUpperBound() throws Exception {
                                                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                            when(function.value(3.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                                                            when(function.value(2.9)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            double[] result = UnivariateRealSolverUtils.bracket(function, 2.5, 1.0, 3.0, 100);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            assertTrue(result[0] < 3.0);
                                                                                                                                                                                                                                                                                            assertEquals(3.0, result[1], 0.0001);
                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                        public void testBracket_MinimumIterationsNeeded() throws Exception {
                                                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                            // First iteration (a=1.5-1.0=0.5, b=1.5+1.0=2.5)
                                                                                                                                                                                                                                                                                            when(function.value(0.5)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                                            when(function.value(2.5)).thenReturn(1.0);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 0.0, 3.0, 100);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            assertEquals(0.5, result[0], 0.0001);
                                                                                                                                                                                                                                                                                            assertEquals(2.5, result[1], 0.0001);
                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                        public void testBracket_MaxIterationsReachedButSuccessful() throws Exception {
                                                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                            // Will find bracketing on last possible iteration
                                                                                                                                                                                                                                                                                            when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                                            when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 1.0, 2.0, 1);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                                                                                                                                            assertEquals(2, result.length);
                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                public void testBracket_MaxIterationsReached() throws Exception {
                                                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                    when(function.value(anyDouble())).thenReturn(-0.5); // Always negative
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    // Exception handling setup
                                                                                                                                                                                                                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                                                    exception.expect(org.apache.commons.math.ConvergenceException.class);
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    // Test - should throw exception
                                                                                                                                                                                                                                                                                    UnivariateRealSolverUtils.bracket(function, 0.5, 0.0, 1.0, 5);
                                                                                                                                                                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                                                                public void testBracket_ZeroIterations() throws Exception {
                                                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    // Test - zero iterations
                                                                                                                                                                                                                                                                                    UnivariateRealSolverUtils.bracket(function, 0.5, 0.0, 1.0, 0);
                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                public void testBracket_NullFunction() throws Exception {
                                                                                                                                                                                                                                                                                    org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                                                                                    exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                                    exception.expectMessage("function is null");
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    UnivariateRealSolverUtils.bracket(null, 1.0, 0.0, 2.0, 100);
                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                public void testBracket_InvalidMaxIterations() throws Exception {
                                                                                                                                                                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                                                    exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                                    exception.expectMessage("bad value for maximum iterations number: 0");
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 0);
                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                public void testBracket_InvalidBounds() throws Exception {
                                                                                                                                                                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                                                                        UnivariateRealSolverUtils.bracket(function, 1.0, 2.0, 2.0, 100);
                                                                                                                                                                                                                                                                                        fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                                                        assertEquals("invalid bracketing parameters", e.getMessage());
                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                public void testBracket_ConvergenceFailure() throws Exception {
                                                                                                                                                                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                    when(function.value(anyDouble())).thenReturn(1.0); // Always positive
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                                                    exception.expect(ConvergenceException.class);
                                                                                                                                                                                                                                                                                    exception.expectMessage("number of iterations");
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    UnivariateRealSolverUtils.bracket(function, 1.5, 1.0, 3.0, 100);
                                                                                                                                                                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                                                            public void testBracket_NullFunction1() throws Exception {
                                                                                                                                                                                                                                                                                // Test - null function
                                                                                                                                                                                                                                                                                UnivariateRealSolverUtils.bracket(null, 0.5, 0.0, 1.0, 100);
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                            public void testBracket_InitialOutsideBounds() throws Exception {
                                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                                                exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                                exception.expectMessage("invalid bracketing parameters");
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                UnivariateRealSolverUtils.bracket(function, -1.0, 0.0, 2.0, 100);
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testSolveWithFunctionZeroAtEndpoint() throws Exception {
                                                                                                                                                                                                                                                // Create a mock function that returns 0 at x0 and non-zero elsewhere
                                                                                                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                when(f.value(0.0)).thenReturn(0.0);  // f(x0) = 0
                                                                                                                                                                                                                                                when(f.value(1.0)).thenReturn(1.0);  // f(x1) = 1
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // The original method should recognize x0 as the solution immediately
                                                                                                                                                                                                                                                // The mutant would continue iterating
                                                                                                                                                                                                                                                double result = UnivariateRealSolverUtils.solve(f, 0.0, 1.0);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify the result is exactly x0 since f(x0) = 0
                                                                                                                                                                                                                                                assertEquals(0.0, result, 0.0);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify the function was evaluated at x0 (original behavior)
                                                                                                                                                                                                                                                verify(f, atLeastOnce()).value(0.0);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // For the mutant, it would continue evaluating beyond x0
                                                                                                                                                                                                                                                // So we verify it didn't evaluate at other points excessively
                                                                                                                                                                                                                                                verify(f, atMost(1)).value(anyDouble());
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testSolveWithFunctionZeroAtBothEndpoints() throws Exception {
                                                                                                                                                                                                                                                // Create a mock function that returns 0 at both endpoints
                                                                                                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                when(f.value(0.0)).thenReturn(0.0);  // f(x0) = 0
                                                                                                                                                                                                                                                when(f.value(1.0)).thenReturn(0.0);  // f(x1) = 0
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // The original method should return immediately (either endpoint is valid)
                                                                                                                                                                                                                                                // The mutant would continue iterating
                                                                                                                                                                                                                                                double result = UnivariateRealSolverUtils.solve(f, 0.0, 1.0);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify the result is either endpoint
                                                                                                                                                                                                                                                assertTrue(result == 0.0 || result == 1.0);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify minimal evaluations (original would stop after checking endpoints)
                                                                                                                                                                                                                                                verify(f, times(2)).value(anyDouble());
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                    public void testSolveWithFunctionValueExactlyZero() throws Exception {
                                                                                                                                                                                                                                        // Mock the UnivariateRealFunction to return 0 at one endpoint
                                                                                                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                        when(f.value(0.0)).thenReturn(0.0);  // f(x0) = 0
                                                                                                                                                                                                                                        when(f.value(1.0)).thenReturn(1.0);  // f(x1) = 1
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Mock the solver to return a dummy value when called
                                                                                                                                                                                                                                        UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                                                                                                                                                                                        when(solver.solve(f, 0.0, 1.0)).thenReturn(0.5);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Create and mock the factory to return our mocked solver
                                                                                                                                                                                                                                        UnivariateRealSolverFactory factory = mock(UnivariateRealSolverFactory.class);
                                                                                                                                                                                                                                        when(factory.newDefaultSolver()).thenReturn(solver);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Use reflection to set the factory field in UnivariateRealSolverUtils
                                                                                                                                                                                                                                        Field factoryField = UnivariateRealSolverUtils.class.getDeclaredField("factory");
                                                                                                                                                                                                                                        factoryField.setAccessible(true);
                                                                                                                                                                                                                                        factoryField.set(null, factory);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Call the method with absolute accuracy
                                                                                                                                                                                                                                        double result = UnivariateRealSolverUtils.solve(f, 0.0, 1.0, 0.0001);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Verify the solver was called correctly
                                                                                                                                                                                                                                        verify(solver).setAbsoluteAccuracy(0.0001);
                                                                                                                                                                                                                                        verify(solver).solve(f, 0.0, 1.0);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Assert the result
                                                                                                                                                                                                                                        assertEquals(0.5, result, 0.0001);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // The key assertion - verify the solver handles the zero case correctly
                                                                                                                                                                                                                                        // In the original code, fa*fb=0 would terminate the loop
                                                                                                                                                                                                                                        // In the mutated code, fa*fb=0 would continue the loop
                                                                                                                                                                                                                                        // We verify the solver was called exactly once (original behavior)
                                                                                                                                                                                                                                        verify(solver, times(1)).solve(f, 0.0, 1.0);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Reset the factory field to avoid affecting other tests
                                                                                                                                                                                                                                        factoryField.set(null, null);
                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                            public void testSolveIterationBoundary() throws Exception {
                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                when(f.value(anyDouble())).thenReturn(1.0); // Always return non-zero to force iterations
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                double x0 = 0.0;
                                                                                                                                                                                                                                double x1 = 1.0;
                                                                                                                                                                                                                                double absoluteAccuracy = 0.001;
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Mock the solver to track iterations
                                                                                                                                                                                                                                UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                                                                                                                                                                                when(solver.getAbsoluteAccuracy()).thenReturn(absoluteAccuracy);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Mock the factory to return our mocked solver
                                                                                                                                                                                                                                UnivariateRealSolverFactory factory = mock(UnivariateRealSolverFactory.class);
                                                                                                                                                                                                                                when(factory.newDefaultSolver()).thenReturn(solver);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Use reflection to set the factory field in UnivariateRealSolverUtils
                                                                                                                                                                                                                                Field factoryField = UnivariateRealSolverUtils.class.getDeclaredField("factory");
                                                                                                                                                                                                                                factoryField.setAccessible(true);
                                                                                                                                                                                                                                factoryField.set(null, factory);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Set maximum iterations to a known value (e.g., 100)
                                                                                                                                                                                                                                when(solver.getMaximalIterationCount()).thenReturn(100);
                                                                                                                                                                                                                                when(solver.getIterationCount()).thenReturn(100); // Simulate reaching max iterations
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                    UnivariateRealSolverUtils.solve(f, x0, x1, absoluteAccuracy);
                                                                                                                                                                                                                                    fail("Expected exception not thrown");
                                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                                    // Verify the solver was used correctly
                                                                                                                                                                                                                                    verify(solver).setAbsoluteAccuracy(absoluteAccuracy);
                                                                                                                                                                                                                                    verify(solver).solve(f, x0, x1);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // The key assertion - verify iteration count was checked
                                                                                                                                                                                                                                    // The mutant would allow one more iteration than the original
                                                                                                                                                                                                                                    verify(solver).getIterationCount();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Additional verification that we hit the iteration limit
                                                                                                                                                                                                                                    assertTrue(e.getMessage().contains("maximum iterations"));
                                                                                                                                                                                                                                } finally {
                                                                                                                                                                                                                                    // Reset the factory field to avoid affecting other tests
                                                                                                                                                                                                                                    factoryField.set(null, null);
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                        public void testSolveIterationBoundary1() throws Exception {
                                                                                                                                                                                                                            // Setup mock objects
                                                                                                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                            when(f.value(anyDouble())).thenReturn(1.0).thenReturn(-1.0);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Create mock solver
                                                                                                                                                                                                                            UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Mock the solver factory behavior using reflection
                                                                                                                                                                                                                            Field factoryField = UnivariateRealSolverUtils.class.getDeclaredField("DEFAULT_SOLVER");
                                                                                                                                                                                                                            factoryField.setAccessible(true);
                                                                                                                                                                                                                            UnivariateRealSolver originalSolver = (UnivariateRealSolver) factoryField.get(null);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                factoryField.set(null, solver);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Set up solver behavior
                                                                                                                                                                                                                                double expectedResult = 0.5;
                                                                                                                                                                                                                                when(solver.solve(any(UnivariateRealFunction.class), anyDouble(), anyDouble()))
                                                                                                                                                                                                                                    .thenReturn(expectedResult);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Test parameters
                                                                                                                                                                                                                                double x0 = 0.0;
                                                                                                                                                                                                                                double x1 = 1.0;
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Call the method
                                                                                                                                                                                                                                double result = UnivariateRealSolverUtils.solve(f, x0, x1);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Verify the result
                                                                                                                                                                                                                                assertEquals(expectedResult, result, 0.0001);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Verify the solver was called with correct parameters
                                                                                                                                                                                                                                verify(solver).solve(f, x0, x1);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Verify solver was called exactly once
                                                                                                                                                                                                                                verify(solver, times(1)).solve(any(UnivariateRealFunction.class), anyDouble(), anyDouble());
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Test boundary iteration behavior
                                                                                                                                                                                                                                UnivariateRealFunction boundaryFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                when(boundaryFunction.value(anyDouble()))
                                                                                                                                                                                                                                    .thenReturn(1.0)  // initial values
                                                                                                                                                                                                                                    .thenReturn(1.0)
                                                                                                                                                                                                                                    .thenReturn(0.5)   // converging
                                                                                                                                                                                                                                    .thenReturn(0.25)
                                                                                                                                                                                                                                    .thenReturn(0.125) // exactly at iteration limit
                                                                                                                                                                                                                                    .thenReturn(0.0);  // would be extra iteration
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                double boundaryResult = UnivariateRealSolverUtils.solve(boundaryFunction, x0, x1);
                                                                                                                                                                                                                                assertNotEquals(0.0, boundaryResult, 0.0001); // Should stop before reaching perfect 0.0
                                                                                                                                                                                                                            } finally {
                                                                                                                                                                                                                                // Restore original solver
                                                                                                                                                                                                                                factoryField.set(null, originalSolver);
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testSolveWithRootAtLowerBound() throws Exception {
                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                            double lowerBound = 2.0;
                                                                                                                                                                                                                            double upperBound = 5.0;
                                                                                                                                                                                                                            double absoluteAccuracy = 1e-6;
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Create a mock function that has root exactly at lower bound
                                                                                                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                            when(f.value(lowerBound)).thenReturn(0.0);
                                                                                                                                                                                                                            when(f.value(upperBound)).thenReturn(1.0); // Some positive value
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Mock the solver factory and solver
                                                                                                                                                                                                                            UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                                                                                                                                                                            when(solver.solve(f, lowerBound, upperBound)).thenReturn(lowerBound);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Replace the LazyHolder.FACTORY with our mock factory
                                                                                                                                                                                                                            UnivariateRealSolverFactory factory = mock(UnivariateRealSolverFactory.class);
                                                                                                                                                                                                                            when(factory.newDefaultSolver()).thenReturn(solver);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to inject our mock factory
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                java.lang.reflect.Field field = UnivariateRealSolverUtils.class.getDeclaredField("FACTORY");
                                                                                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                                                                                java.lang.reflect.Field modifiersField = java.lang.reflect.Field.class.getDeclaredField("modifiers");
                                                                                                                                                                                                                                modifiersField.setAccessible(true);
                                                                                                                                                                                                                                modifiersField.setInt(field, field.getModifiers() & ~java.lang.reflect.Modifier.FINAL);
                                                                                                                                                                                                                                field.set(null, factory);
                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                fail("Failed to inject mock factory");
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test
                                                                                                                                                                                                                            double result = UnivariateRealSolverUtils.solve(f, lowerBound, upperBound, absoluteAccuracy);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                            assertEquals("Should find root at lower bound", lowerBound, result, absoluteAccuracy);
                                                                                                                                                                                                                            verify(solver).setAbsoluteAccuracy(absoluteAccuracy);
                                                                                                                                                                                                                            verify(solver).solve(f, lowerBound, upperBound);
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                        public void testSolve_ShouldNotAcceptSolutionAtLowerBound() {
                                                                                                                                                                                                            // Create a mock function that has root exactly at lower bound (x0)
                                                                                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                            try {
                                                                                                                                                                                                                when(f.value(1.0)).thenReturn(0.0); // root at x=1.0
                                                                                                                                                                                                                when(f.value(1.5)).thenReturn(0.5); // positive value above root
                                                                                                                                                                                                            } catch (FunctionEvaluationException e) {
                                                                                                                                                                                                                fail("Unexpected FunctionEvaluationException");
                                                                                                                                                                                                            }
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Create and mock the solver directly
                                                                                                                                                                                                            UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                                                                                                                                                            try {
                                                                                                                                                                                                                when(solver.solve(eq(f), eq(1.0), eq(2.0))).thenReturn(1.0);
                                                                                                                                                                                                            } catch (ConvergenceException | FunctionEvaluationException e) {
                                                                                                                                                                                                                fail("Unexpected exception while setting up solver mock");
                                                                                                                                                                                                            }
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Use reflection to set the solver factory
                                                                                                                                                                                                            try {
                                                                                                                                                                                                                Field factoryField = UnivariateRealSolverUtils.class.getDeclaredField("FACTORY");
                                                                                                                                                                                                                factoryField.setAccessible(true);
                                                                                                                                                                                                                
                                                                                                                                                                                                                UnivariateRealSolverFactory mockFactory = mock(UnivariateRealSolverFactory.class);
                                                                                                                                                                                                                when(mockFactory.newDefaultSolver()).thenReturn(solver);
                                                                                                                                                                                                                factoryField.set(null, mockFactory);
                                                                                                                                                                                                                
                                                                                                                                                                                                                try {
                                                                                                                                                                                                                    double result = UnivariateRealSolverUtils.solve(f, 1.0, 2.0);
                                                                                                                                                                                                                    // If we get here, the mutant survived (accepted solution at lower bound)
                                                                                                                                                                                                                    fail("Should not accept solution exactly at lower bound");
                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                    // Expected behavior - original code should throw exception
                                                                                                                                                                                                                    assertTrue(e instanceof IllegalArgumentException);
                                                                                                                                                                                                                }
                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                                                                            }
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                            public void testSolveWithBoundaryConditions() throws Exception {
                                                                                                                                                                                                // Setup
                                                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                                                                                                                                                
                                                                                                                                                                                                // Use reflection to access and modify the DEFAULT_SOLVER field in UnivariateRealSolverUtils
                                                                                                                                                                                                Field solverField = UnivariateRealSolverUtils.class.getDeclaredField("DEFAULT_SOLVER");
                                                                                                                                                                                                solverField.setAccessible(true);
                                                                                                                                                                                                UnivariateRealSolver originalSolver = (UnivariateRealSolver) solverField.get(null);
                                                                                                                                                                                                
                                                                                                                                                                                                try {
                                                                                                                                                                                                    // Set our mock solver
                                                                                                                                                                                                    solverField.set(null, solver);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Test case where only left bound is valid (a > lowerBound but b >= upperBound)
                                                                                                                                                                                                    double x0 = 1.0;  // valid (assuming lowerBound is 0)
                                                                                                                                                                                                    double x1 = 10.0; // invalid (assuming upperBound is 10)
                                                                                                                                                                                                    double expected = 5.0;
                                                                                                                                                                                                    
                                                                                                                                                                                                    when(solver.solve(f, x0, x1)).thenReturn(expected);
                                                                                                                                                                                                    when(solver.getAbsoluteAccuracy()).thenReturn(0.001);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Exercise
                                                                                                                                                                                                    double result = UnivariateRealSolverUtils.solve(f, x0, x1, 0.001);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                    assertEquals(expected, result, 0.0001);
                                                                                                                                                                                                    verify(solver).setAbsoluteAccuracy(0.001);
                                                                                                                                                                                                    verify(solver).solve(f, x0, x1);
                                                                                                                                                                                                } finally {
                                                                                                                                                                                                    // Restore original solver
                                                                                                                                                                                                    solverField.set(null, originalSolver);
                                                                                                                                                                                                }
                                                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolveDetectsLogicalOperatorMutant() throws Exception {
                                                                                                                                                                // Import required classes
                                                                                                                                                                org.apache.commons.math.analysis.UnivariateRealFunction f = 
                                                                                                                                                                    new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                                                                                                                        @Override
                                                                                                                                                                        public double value(double x) {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                
                                                                                                                                                                // Create mock factory and solver
                                                                                                                                                                org.apache.commons.math.analysis.solvers.UnivariateRealSolverFactory factory = 
                                                                                                                                                                    new org.apache.commons.math.analysis.solvers.UnivariateRealSolverFactory() {
                                                                                                                                                                        @Override
                                                                                                                                                                        public org.apache.commons.math.analysis.solvers.UnivariateRealSolver newDefaultSolver() {
                                                                                                                                                                            return null;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public org.apache.commons.math.analysis.solvers.UnivariateRealSolver newBisectionSolver() {
                                                                                                                                                                            return null;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public org.apache.commons.math.analysis.solvers.UnivariateRealSolver newBrentSolver() {
                                                                                                                                                                            return null;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public org.apache.commons.math.analysis.solvers.UnivariateRealSolver newSecantSolver() {
                                                                                                                                                                            return null;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public org.apache.commons.math.analysis.solvers.UnivariateRealSolver newNewtonSolver() {
                                                                                                                                                                            return null;
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                
                                                                                                                                                                org.apache.commons.math.analysis.solvers.UnivariateRealSolver solver = 
                                                                                                                                                                    new org.apache.commons.math.analysis.solvers.UnivariateRealSolver() {
                                                                                                                                                                        @Override
                                                                                                                                                                        public double solve(double min, double max) throws org.apache.commons.math.FunctionEvaluationException {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public double solve(double min, double max, double startValue) throws org.apache.commons.math.FunctionEvaluationException {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public double solve(org.apache.commons.math.analysis.UnivariateRealFunction f, 
                                                                                                                                                                                          double min, double max, double startValue) throws org.apache.commons.math.FunctionEvaluationException {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public double solve(org.apache.commons.math.analysis.UnivariateRealFunction f, 
                                                                                                                                                                                          double min, double max) throws org.apache.commons.math.FunctionEvaluationException {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public double getAbsoluteAccuracy() {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        public int getEvaluations() {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public double getFunctionValueAccuracy() {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        public int getMaxEvaluations() {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public int getMaximalIterationCount() {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public int getIterationCount() {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public double getRelativeAccuracy() {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public double getResult() {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public double getFunctionValue() {
                                                                                                                                                                            return 0;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public void setAbsoluteAccuracy(double accuracy) {}
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public void setMaximalIterationCount(int count) {}
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public void setRelativeAccuracy(double accuracy) {}
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public void setFunctionValueAccuracy(double accuracy) {}
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public void resetFunctionValueAccuracy() {}
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public void resetRelativeAccuracy() {}
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public void resetAbsoluteAccuracy() {}
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public void resetMaximalIterationCount() {}
                                                                                                                                                                    };
                                                                                                                                                                
                                                                                                                                                                // Use reflection to set the factory instance
                                                                                                                                                                try {
                                                                                                                                                                    java.lang.reflect.Field factoryField = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.class.getDeclaredField("FACTORY");
                                                                                                                                                                    factoryField.setAccessible(true);
                                                                                                                                                                    factoryField.set(null, factory);
                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                    org.junit.Assert.fail("Failed to set factory field via reflection");
                                                                                                                                                                }
                                                                                                                                                                
                                                                                                                                                                // Setup test values where only one condition is true
                                                                                                                                                                double x0 = 0.0;
                                                                                                                                                                double x1 = 1.0;
                                                                                                                                                                double expectedResult = 0.5;
                                                                                                                                                                
                                                                                                                                                                // Mock the solver behavior
                                                                                                                                                                try {
                                                                                                                                                                    org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(f, x0, x1);
                                                                                                                                                                    org.junit.Assert.fail("Expected exception not thrown - mutant not detected");
                                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                                    // Verify the exception
                                                                                                                                                                    org.junit.Assert.assertTrue(e.getMessage() != null);
                                                                                                                                                                }
                                                                                                                                                                
                                                                                                                                                                // Additional test case where only the other condition is true
                                                                                                                                                                x0 = -1.0;
                                                                                                                                                                x1 = 2.0;
                                                                                                                                                                
                                                                                                                                                                double result = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(f, x0, x1);
                                                                                                                                                                org.junit.Assert.assertEquals(expectedResult, result, 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolveWithRootAtUpperBound() throws Exception {
                                                                                                                                                                // Create a mock function that has root exactly at upper bound (1.0)
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(0.5)).thenReturn(-1.0); // negative at midpoint
                                                                                                                                                                when(f.value(1.0)).thenReturn(0.0);  // exactly zero at upper bound
                                                                                                                                                                
                                                                                                                                                                // Test with interval that includes the root at upper bound
                                                                                                                                                                double x0 = 0.5;
                                                                                                                                                                double x1 = 1.0;
                                                                                                                                                                
                                                                                                                                                                // Call the method
                                                                                                                                                                double result = UnivariateRealSolverUtils.solve(f, x0, x1);
                                                                                                                                                                
                                                                                                                                                                // Verify the result is exactly the upper bound (1.0)
                                                                                                                                                                assertEquals(1.0, result, 0.0);
                                                                                                                                                                
                                                                                                                                                                // Verify the function was evaluated at expected points
                                                                                                                                                                verify(f).value(0.5);
                                                                                                                                                                verify(f).value(1.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                    public void testSolve_DetectsBoundaryConditionMutant() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        double x0 = 0.0;
                                                                                                                                                        double x1 = 1.0;  // upper bound
                                                                                                                                                        double absoluteAccuracy = 0.0001;
                                                                                                                                                        
                                                                                                                                                        // Create a function that has root exactly at upper bound
                                                                                                                                                        UnivariateRealFunction f = new UnivariateRealFunction() {
                                                                                                                                                            public double value(double x) {
                                                                                                                                                                if (x == x0) return -1.0;
                                                                                                                                                                if (x == x1) return 0.0;
                                                                                                                                                                return x - x1;  // linear function with root at x1
                                                                                                                                                            }
                                                                                                                                                        };
                                                                                                                                                        
                                                                                                                                                        // Test - the solver should find the root at the upper bound
                                                                                                                                                        double result = UnivariateRealSolverUtils.solve(f, x0, x1, absoluteAccuracy);
                                                                                                                                                        
                                                                                                                                                        // Verify - solution should be accepted at exact upper bound
                                                                                                                                                        assertEquals(x1, result, absoluteAccuracy);
                                                                                                                                                    }

    @Test
                                                                                                                                            public void testSolveDetectsNegativeFunctionValuesMutation() throws Exception {
                                                                                                                                                // Create a mock function that returns negative values at both endpoints
                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                when(f.value(anyDouble())).thenReturn(-1.0);
                                                                                                                                                
                                                                                                                                                // Mock the solver factory and solver
                                                                                                                                                UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                                                                                                when(solver.solve(any(UnivariateRealFunction.class), anyDouble(), anyDouble())).thenReturn(0.5);
                                                                                                                                                
                                                                                                                                                // Replace the LazyHolder.FACTORY with our mock factory
                                                                                                                                                UnivariateRealSolverFactory mockFactory = mock(UnivariateRealSolverFactory.class);
                                                                                                                                                when(mockFactory.newDefaultSolver()).thenReturn(solver);
                                                                                                                                                
                                                                                                                                                try {
                                                                                                                                                    // Use reflection to access the private LazyHolder class and replace the factory instance
                                                                                                                                                    Class<?>[] declaredClasses = UnivariateRealSolverUtils.class.getDeclaredClasses();
                                                                                                                                                    Class<?> lazyHolderClass = null;
                                                                                                                                                    for (Class<?> clazz : declaredClasses) {
                                                                                                                                                        if (clazz.getSimpleName().equals("LazyHolder")) {
                                                                                                                                                            lazyHolderClass = clazz;
                                                                                                                                                            break;
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    java.lang.reflect.Field field = lazyHolderClass.getDeclaredField("FACTORY");
                                                                                                                                                    field.setAccessible(true);
                                                                                                                                                    UnivariateRealSolverFactory originalFactory = (UnivariateRealSolverFactory) field.get(null);
                                                                                                                                                    field.set(null, mockFactory);
                                                                                                                                                    
                                                                                                                                                    // Test the method
                                                                                                                                                    double result = UnivariateRealSolverUtils.solve(f, 0.0, 1.0, 0.001);
                                                                                                                                                    
                                                                                                                                                    // Verify the solver was called with correct parameters
                                                                                                                                                    verify(solver).setAbsoluteAccuracy(0.001);
                                                                                                                                                    verify(solver).solve(f, 0.0, 1.0);
                                                                                                                                                    assertEquals(0.5, result, 0.0001);
                                                                                                                                                    
                                                                                                                                                    // Restore original factory
                                                                                                                                                    field.set(null, originalFactory);
                                                                                                                                                } catch (Exception e) {
                                                                                                                                                    fail("Exception occurred during test: " + e.getMessage());
                                                                                                                                                }
                                                                                                                                            }

    @Test
                                                                                                                                        public void testSolveDetectsNegativeFunctionValues() throws FunctionEvaluationException, ConvergenceException {
                                                                                                                                            // Create a mock function that returns negative values at both points
                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                            when(f.value(anyDouble())).thenReturn(-1.0);
                                                                                                                                            
                                                                                                                                            double x0 = 0.0;
                                                                                                                                            double x1 = 1.0;
                                                                                                                                            
                                                                                                                                            try {
                                                                                                                                                UnivariateRealSolverUtils.solve(f, x0, x1);
                                                                                                                                                // If we get here, the mutant survived (continued when it should have stopped)
                                                                                                                                                fail("Expected IllegalArgumentException for function values with same sign");
                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                // Original behavior would throw when both values are negative
                                                                                                                                                assertTrue(e.getMessage().contains("function values at endpoints"));
                                                                                                                                            }
                                                                                                                                        }

    @Test
                                                                                                                                        public void testSolveWithPositiveFunctionValues() {
                                                                                                                                            // Create a mock function that returns positive values at both points
                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                            try {
                                                                                                                                                when(f.value(anyDouble())).thenReturn(1.0);
                                                                                                                                            } catch (FunctionEvaluationException e) {
                                                                                                                                                fail("Mock setup failed");
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            double x0 = 0.0;
                                                                                                                                            double x1 = 1.0;
                                                                                                                                            
                                                                                                                                            try {
                                                                                                                                                UnivariateRealSolverUtils.solve(f, x0, x1);
                                                                                                                                                fail("Expected IllegalArgumentException for function values with same sign");
                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                assertTrue(e.getMessage().contains("function values at endpoints"));
                                                                                                                                            } catch (FunctionEvaluationException e) {
                                                                                                                                                fail("Unexpected FunctionEvaluationException");
                                                                                                                                            } catch (ConvergenceException e) {
                                                                                                                                                fail("Unexpected ConvergenceException");
                                                                                                                                            }
                                                                                                                                        }

    @Test
                                                                                                                                        public void testSolveWithMixedFunctionValues() throws FunctionEvaluationException, ConvergenceException {
                                                                                                                                            // Create a mock function that returns values with different signs
                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                            when(f.value(0.0)).thenReturn(-1.0);
                                                                                                                                            when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                            
                                                                                                                                            double x0 = 0.0;
                                                                                                                                            double x1 = 1.0;
                                                                                                                                            
                                                                                                                                            // This should work in both original and mutant cases
                                                                                                                                            // We can't verify the actual result since we're mocking the solver too,
                                                                                                                                            // but we can verify it doesn't throw the same-sign exception
                                                                                                                                            try {
                                                                                                                                                UnivariateRealSolverUtils.solve(f, x0, x1);
                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                fail("Should not throw exception for function values with different signs");
                                                                                                                                            }
                                                                                                                                        }

    @Test
                                                                                                                        public void testSolveRespectsMaximumIterations() throws Exception {
                                                                                                                            // Setup
                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                            when(f.value(anyDouble())).thenReturn(1.0).thenReturn(-1.0); // Values that would normally converge
                                                                                                                            
                                                                                                                            double x0 = 0.0;
                                                                                                                            double x1 = 1.0;
                                                                                                                            double absoluteAccuracy = 0.001;
                                                                                                                            
                                                                                                                            // Create a mock solver that would track iterations
                                                                                                                            UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                                                                            when(solver.getAbsoluteAccuracy()).thenReturn(absoluteAccuracy);
                                                                                                                            
                                                                                                                            // Test normal case
                                                                                                                            try {
                                                                                                                                // We'll test the actual solve method instead of mocking the factory
                                                                                                                                // This is more straightforward and avoids reflection complications
                                                                                                                                double result = UnivariateRealSolverUtils.solve(f, x0, x1, absoluteAccuracy);
                                                                                                                                
                                                                                                                                // Verify the solver behavior through the actual implementation
                                                                                                                                // We can't verify mock interactions here since we're not mocking the factory
                                                                                                                                
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Should not throw exception for normal case");
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Test edge case where maximum iterations would be reached
                                                                                                                            // We need to create a function that would cause maximum iterations to be exceeded
                                                                                                                            UnivariateRealFunction infiniteFunction = mock(UnivariateRealFunction.class);
                                                                                                                            when(infiniteFunction.value(anyDouble())).thenReturn(1.0); // Always return same value to prevent convergence
                                                                                                                            
                                                                                                                            try {
                                                                                                                                UnivariateRealSolverUtils.solve(infiniteFunction, x0, x1, absoluteAccuracy);
                                                                                                                                fail("Should throw MaxIterationsExceededException");
                                                                                                                            } catch (org.apache.commons.math.MaxIterationsExceededException e) {
                                                                                                                                // Expected behavior
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                                                                    public void testSolveDetectsIterationCountMutation() throws Exception {
                                                                                                                        // Create a mock function that requires multiple iterations to solve
                                                                                                                        org.apache.commons.math.analysis.UnivariateRealFunction f = mock(org.apache.commons.math.analysis.UnivariateRealFunction.class);
                                                                                                                        when(f.value(anyDouble())).thenReturn(1.0, 1.0, 1.0, 1.0, 1.0, -1.0);
                                                                                                                        
                                                                                                                        // Mock the solver factory and solver
                                                                                                                        org.apache.commons.math.analysis.solvers.UnivariateRealSolverFactory factory = mock(org.apache.commons.math.analysis.solvers.UnivariateRealSolverFactory.class);
                                                                                                                        org.apache.commons.math.analysis.solvers.UnivariateRealSolver solver = mock(org.apache.commons.math.analysis.solvers.UnivariateRealSolver.class);
                                                                                                                        
                                                                                                                        // Use reflection to set the factory field in UnivariateRealSolverUtils
                                                                                                                        Field factoryField = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.class.getDeclaredField("factory");
                                                                                                                        factoryField.setAccessible(true);
                                                                                                                        factoryField.set(null, factory);
                                                                                                                        
                                                                                                                        when(factory.newDefaultSolver()).thenReturn(solver);
                                                                                                                        
                                                                                                                        // Set up solver to track iterations
                                                                                                                        when(solver.solve(any(org.apache.commons.math.analysis.UnivariateRealFunction.class), anyDouble(), anyDouble(), anyInt()))
                                                                                                                            .thenAnswer(invocation -> {
                                                                                                                                int maxIterations = invocation.getArgument(3);
                                                                                                                                // Verify the solver would have run multiple iterations
                                                                                                                                assertTrue("Solver should require multiple iterations", maxIterations > 1);
                                                                                                                                return 0.5; // return some midpoint
                                                                                                                            });
                                                                                                                        
                                                                                                                        // Test the method
                                                                                                                        double result = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(f, 0.0, 1.0);
                                                                                                                        
                                                                                                                        // Verify the solver was called with proper parameters
                                                                                                                        verify(solver).solve(eq(f), eq(0.0), eq(1.0), anyInt());
                                                                                                                        
                                                                                                                        // This test would fail if the mutant was present because:
                                                                                                                        // Original: Would call solver with proper iteration count
                                                                                                                        // Mutant: Would either not call solver or call with wrong iteration logic
                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                    public void testSolveShouldResolveBoundaryConditions() throws Exception {
                                                                                                                        // Setup
                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                        when(f.value(anyDouble())).thenReturn(1.0); // Always return non-zero to force boundary check
                                                                                                                        
                                                                                                                        // These values should trigger the boundary check in original code
                                                                                                                        double x0 = Double.NaN;
                                                                                                                        double x1 = Double.POSITIVE_INFINITY;
                                                                                                                        double absoluteAccuracy = 1e-6;
                                                                                                                        
                                                                                                                        // This should throw IllegalArgumentException in original code
                                                                                                                        // But will pass with mutant since boundary check is disabled
                                                                                                                        UnivariateRealSolverUtils.solve(f, x0, x1, absoluteAccuracy);
                                                                                                                        
                                                                                                                        // If we get here, the mutant survived (bad)
                                                                                                                        fail("Expected IllegalArgumentException for invalid bounds");
                                                                                                                    }

    @Test
                                                                                                                    public void testSolveWithValidBounds() throws Exception {
                                                                                                                        // Setup valid test case that should work in both original and mutant
                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                        when(f.value(1.0)).thenReturn(0.0); // Root at x=1.0
                                                                                                                        when(f.value(0.5)).thenReturn(-0.5);
                                                                                                                        when(f.value(1.5)).thenReturn(0.5);
                                                                                                                        
                                                                                                                        double x0 = 0.5;
                                                                                                                        double x1 = 1.5;
                                                                                                                        double absoluteAccuracy = 1e-6;
                                                                                                                        
                                                                                                                        double result = UnivariateRealSolverUtils.solve(f, x0, x1, absoluteAccuracy);
                                                                                                                        
                                                                                                                        assertEquals(1.0, result, absoluteAccuracy);
                                                                                                                    }

    @Test
                                                                                                            public void testSolveShouldRespectBoundaryConditions() throws Exception {
                                                                                                                // Setup mock objects
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                                                                
                                                                                                                // Setup test values where both boundaries are violated
                                                                                                                double x0 = 0.0;  // a <= lowerBound
                                                                                                                double x1 = 2.0;  // b >= upperBound
                                                                                                                double lowerBound = 1.0;
                                                                                                                double upperBound = 1.0;
                                                                                                                
                                                                                                                // The original code would fail here because neither condition is true
                                                                                                                // But the mutant would proceed with (true) as the condition
                                                                                                                try {
                                                                                                                    UnivariateRealSolverUtils.solve(f, x0, x1);
                                                                                                                    // If we get here with the original code, the test should fail
                                                                                                                    fail("Expected IllegalArgumentException for violated boundary conditions");
                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                    // This is expected for the original code
                                                                                                                    assertTrue(e.getMessage().contains("boundary conditions"));
                                                                                                                }
                                                                                                                
                                                                                                                // Verify the solver was never called in original implementation
                                                                                                                verify(solver, never()).solve(any(), anyDouble(), anyDouble());
                                                                                                            }

    @Test
                                                                                                    public void testSolveWithExactRootAtEndpointDetectsMutant() throws Exception {
                                                                                                        // Create a mock function that returns 0 at x0 (root exactly at left endpoint)
                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                        when(f.value(0.0)).thenReturn(0.0);  // exact root at x0
                                                                                                        when(f.value(1.0)).thenReturn(1.0);  // non-root at x1
                                                                                                        
                                                                                                        // Mock the solver to verify behavior
                                                                                                        UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                                                        
                                                                                                        // Create a mock factory for solver creation
                                                                                                        UnivariateRealSolverFactory factory = mock(UnivariateRealSolverFactory.class);
                                                                                                        when(factory.newDefaultSolver()).thenReturn(solver);
                                                                                                        
                                                                                                        // Use reflection to inject the mock factory into UnivariateRealSolverUtils
                                                                                                        Field factoryField = UnivariateRealSolverUtils.class.getDeclaredField("factory");
                                                                                                        factoryField.setAccessible(true);
                                                                                                        factoryField.set(null, factory);
                                                                                                        
                                                                                                        // The original should recognize the exact root and not perform iterations
                                                                                                        // The mutant would continue trying to solve
                                                                                                        UnivariateRealSolverUtils.solve(f, 0.0, 1.0);
                                                                                                        
                                                                                                        // Verify the solver was called with correct parameters
                                                                                                        // The key assertion is that with exact root, the solver shouldn't do unnecessary work
                                                                                                        verify(solver, times(1)).solve(f, 0.0, 1.0);
                                                                                                        
                                                                                                        // Additional verification that would fail with the mutant:
                                                                                                        // The mutant would potentially call value() more times than necessary
                                                                                                        verify(f, atMost(2)).value(anyDouble());
                                                                                                        
                                                                                                        // Reset the factory to avoid affecting other tests
                                                                                                        factoryField.set(null, null);
                                                                                                    }

    @Test
                                                                                                public void testSolveWithRootAtEndpointDetectsFaFbZeroCase() throws FunctionEvaluationException, ConvergenceException {
                                                                                                    // Create a mock function that has root exactly at x0 (0.0)
                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                    when(f.value(0.0)).thenReturn(0.0);  // exact root at x0
                                                                                                    when(f.value(1.0)).thenReturn(1.0);  // positive at x1
                                                                                                    
                                                                                                    double x0 = 0.0;
                                                                                                    double x1 = 1.0;
                                                                                                    double absoluteAccuracy = 0.0001;
                                                                                                    
                                                                                                    // The solver should recognize the root at x0 immediately
                                                                                                    double result = UnivariateRealSolverUtils.solve(f, x0, x1, absoluteAccuracy);
                                                                                                    
                                                                                                    // Verify the result is exactly the root at x0
                                                                                                    assertEquals(0.0, result, 0.0);
                                                                                                    
                                                                                                    // For thoroughness, verify the function was evaluated at x0
                                                                                                    verify(f).value(0.0);
                                                                                                }

    @Test
                                                                                        public void testSolveIterationBoundary2() throws Exception {
                                                                                            // Setup mock objects
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                                            
                                                                                            // Use reflection to set the factory field since it's likely private
                                                                                            try {
                                                                                                Field factoryField = UnivariateRealSolverUtils.class.getDeclaredField("factory");
                                                                                                factoryField.setAccessible(true);
                                                                                                UnivariateRealSolverFactory originalFactory = (UnivariateRealSolverFactory) factoryField.get(null);
                                                                                                
                                                                                                // Create a mock factory that returns our mock solver
                                                                                                UnivariateRealSolverFactory mockFactory = mock(UnivariateRealSolverFactory.class);
                                                                                                when(mockFactory.newDefaultSolver()).thenReturn(solver);
                                                                                                factoryField.set(null, mockFactory);
                                                                                                
                                                                                                // Setup test values
                                                                                                double x0 = 0.0;
                                                                                                double x1 = 1.0;
                                                                                                double absoluteAccuracy = 0.001;
                                                                                                
                                                                                                // Mock solver behavior to track iterations
                                                                                                when(solver.solve(f, x0, x1)).thenAnswer(invocation -> {
                                                                                                    throw new IllegalStateException("Max iterations reached");
                                                                                                });
                                                                                                
                                                                                                try {
                                                                                                    UnivariateRealSolverUtils.solve(f, x0, x1, absoluteAccuracy);
                                                                                                    fail("Expected exception not thrown");
                                                                                                } catch (IllegalStateException e) {
                                                                                                    assertEquals("Max iterations reached", e.getMessage());
                                                                                                }
                                                                                                
                                                                                                // Verify solver was configured correctly
                                                                                                verify(solver).setAbsoluteAccuracy(absoluteAccuracy);
                                                                                                
                                                                                                // Restore original factory
                                                                                                factoryField.set(null, originalFactory);
                                                                                            } catch (Exception e) {
                                                                                                fail("Failed to setup test due to reflection error: " + e.getMessage());
                                                                                            }
                                                                                        }

    @Test
                                                                                    public void testSolveIterationBoundary3() throws Exception {
                                                                                        // Setup mock objects
                                                                                        org.apache.commons.math.analysis.UnivariateRealFunction f = mock(org.apache.commons.math.analysis.UnivariateRealFunction.class);
                                                                                        org.apache.commons.math.analysis.solvers.UnivariateRealSolver solver = mock(org.apache.commons.math.analysis.solvers.UnivariateRealSolver.class);
                                                                                        Object factory = mock(org.apache.commons.math.analysis.solvers.UnivariateRealSolverFactory.class);
                                                                                        
                                                                                        // Use reflection to set the factory field since LazyHolder is likely private
                                                                                        Class<?> utilsClass = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.class;
                                                                                        Class<?>[] declaredClasses = utilsClass.getDeclaredClasses();
                                                                                        Class<?> lazyHolderClass = null;
                                                                                        for (Class<?> clazz : declaredClasses) {
                                                                                            if (clazz.getSimpleName().equals("LazyHolder")) {
                                                                                                lazyHolderClass = clazz;
                                                                                                break;
                                                                                            }
                                                                                        }
                                                                                        
                                                                                        if (lazyHolderClass != null) {
                                                                                            Field factoryField = lazyHolderClass.getDeclaredField("FACTORY");
                                                                                            factoryField.setAccessible(true);
                                                                                            factoryField.set(null, factory);
                                                                                        }
                                                                                        
                                                                                        when(((org.apache.commons.math.analysis.solvers.UnivariateRealSolverFactory)factory).newDefaultSolver()).thenReturn(solver);
                                                                                        
                                                                                        // Test parameters
                                                                                        double x0 = 0.0;
                                                                                        double x1 = 1.0;
                                                                                        double expectedResult = 0.5;
                                                                                        
                                                                                        // Mock solver behavior
                                                                                        when(solver.solve(eq(f), eq(x0), eq(x1))).thenAnswer(invocation -> {
                                                                                            return expectedResult;
                                                                                        });
                                                                                        
                                                                                        // Call the method
                                                                                        double result = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(f, x0, x1);
                                                                                        
                                                                                        // Verify the result
                                                                                        assertEquals(expectedResult, result, 0.0001);
                                                                                        
                                                                                        // Verify the solver is called exactly once
                                                                                        verify(solver, times(1)).solve(f, x0, x1);
                                                                                    }

    @Test
                                                                            public void testSolveWithBoundaryConditions1() throws Exception {
                                                                                // Setup mock objects
                                                                                UnivariateRealSolver mockSolver = mock(UnivariateRealSolver.class);
                                                                                UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                
                                                                                double x0 = 0.0;
                                                                                double x1 = 1.0;
                                                                                double accuracy = 0.001;
                                                                                double expectedResult = 0.5;
                                                                                
                                                                                // Inject mock solver into utils (requires reflection since utils is static)
                                                                                Field solverField = UnivariateRealSolverUtils.class.getDeclaredField("solver");
                                                                                solverField.setAccessible(true);
                                                                                UnivariateRealSolver originalSolver = (UnivariateRealSolver) solverField.get(null);
                                                                                solverField.set(null, mockSolver);
                                                                                
                                                                                try {
                                                                                    // Case 1: Test where only a > lowerBound is true (b == upperBound)
                                                                                    when(mockSolver.solve(mockFunction, x0, x1)).thenReturn(expectedResult);
                                                                                    double result = UnivariateRealSolverUtils.solve(mockFunction, x0, x1, accuracy);
                                                                                    assertEquals(expectedResult, result, 0.0);
                                                                                    
                                                                                    // Case 2: Test where only b < upperBound is true (a == lowerBound)
                                                                                    result = UnivariateRealSolverUtils.solve(mockFunction, x0, x1, accuracy);
                                                                                    assertEquals(expectedResult, result, 0.0);
                                                                                    
                                                                                    // Case 3: Test where both conditions are true
                                                                                    result = UnivariateRealSolverUtils.solve(mockFunction, x0, x1, accuracy);
                                                                                    assertEquals(expectedResult, result, 0.0);
                                                                                    
                                                                                    // Verify the solver was properly configured
                                                                                    verify(mockSolver).setAbsoluteAccuracy(accuracy);
                                                                                    verify(mockSolver, times(3)).solve(mockFunction, x0, x1);
                                                                                } finally {
                                                                                    // Restore original solver
                                                                                    solverField.set(null, originalSolver);
                                                                                }
                                                                            }

    @Test
                                                                        public void testSolveBoundaryConditions() throws Exception {
                                                                            // Mock the dependencies
                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                            
                                                                            // Create a mock solver
                                                                            UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                            
                                                                            // Use reflection to set the factory field since it's likely private
                                                                            try {
                                                                                Field factoryField = UnivariateRealSolverUtils.class.getDeclaredField("FACTORY");
                                                                                factoryField.setAccessible(true);
                                                                                
                                                                                // Save the original factory to restore later
                                                                                Object originalFactory = factoryField.get(null);
                                                                                
                                                                                try {
                                                                                    // Create a mock factory that returns our mock solver
                                                                                    UnivariateRealSolverFactory mockFactory = mock(UnivariateRealSolverFactory.class);
                                                                                    when(mockFactory.newDefaultSolver()).thenReturn(solver);
                                                                                    factoryField.set(null, mockFactory);
                                                                                    
                                                                                    // Test case where only a > lowerBound is true
                                                                                    when(solver.solve(f, 1.1, 2.0)).thenReturn(1.5);
                                                                                    double result = UnivariateRealSolverUtils.solve(f, 1.1, 2.0);
                                                                                    assertEquals(1.5, result, 0.0001);
                                                                                    
                                                                                    // Test case where only b < upperBound is true
                                                                                    when(solver.solve(f, 0.9, 1.9)).thenReturn(1.4);
                                                                                    result = UnivariateRealSolverUtils.solve(f, 0.9, 1.9);
                                                                                    assertEquals(1.4, result, 0.0001);
                                                                                    
                                                                                    // Test case where both conditions are true
                                                                                    when(solver.solve(f, 1.1, 1.9)).thenReturn(1.5);
                                                                                    result = UnivariateRealSolverUtils.solve(f, 1.1, 1.9);
                                                                                    assertEquals(1.5, result, 0.0001);
                                                                                    
                                                                                    // Test case where neither condition is true
                                                                                    try {
                                                                                        UnivariateRealSolverUtils.solve(f, 0.9, 2.1);
                                                                                        fail("Should have thrown exception for out-of-bounds values");
                                                                                    } catch (IllegalArgumentException expected) {
                                                                                        // Expected behavior
                                                                                    }
                                                                                } finally {
                                                                                    // Restore original factory
                                                                                    factoryField.set(null, originalFactory);
                                                                                }
                                                                            } catch (Exception e) {
                                                                                fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testSolveDetectsBoundaryMutation() throws Exception {
                                                                            // Setup mock function that returns zero at upper bound (1.0)
                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                            when(f.value(0.5)).thenReturn(-1.0);
                                                                            when(f.value(1.0)).thenReturn(0.0);  // root at upper bound
                                                                            
                                                                            // Mock solver factory and solver
                                                                            UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                            when(solver.solve(f, 0.5, 1.0)).thenReturn(1.0);
                                                                            
                                                                            // Replace LazyHolder.FACTORY with our mock factory
                                                                            UnivariateRealSolverFactory mockFactory = mock(UnivariateRealSolverFactory.class);
                                                                            when(mockFactory.newDefaultSolver()).thenReturn(solver);
                                                                            
                                                                            try {
                                                                                // Use reflection to replace the factory with our mock
                                                                                Field field = UnivariateRealSolverUtils.class.getDeclaredField("FACTORY");
                                                                                field.setAccessible(true);
                                                                                Object oldFactory = field.get(null);
                                                                                field.set(null, mockFactory);
                                                                                
                                                                                // Test the method
                                                                                double result = UnivariateRealSolverUtils.solve(f, 0.5, 1.0, 0.001);
                                                                                
                                                                                // Verify the result is exactly the upper bound
                                                                                assertEquals(1.0, result, 0.0);
                                                                                
                                                                                // Verify solver was called with correct parameters
                                                                                verify(solver).setAbsoluteAccuracy(0.001);
                                                                                verify(solver).solve(f, 0.5, 1.0);
                                                                                
                                                                                // Restore original factory
                                                                                field.set(null, oldFactory);
                                                                            } catch (Exception e) {
                                                                                fail("Reflection operation failed: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                public void testSolveWithRootAtUpperBound1() throws FunctionEvaluationException, ConvergenceException {
                                                                    // Create a mock function that has root at upper bound (1.0)
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(0.0)).thenReturn(-1.0);
                                                                    when(f.value(1.0)).thenReturn(0.0); // root at upper bound
                                                                    
                                                                    // Test with interval that includes the root at upper bound
                                                                    double x0 = 0.0;
                                                                    double x1 = 1.0;
                                                                    
                                                                    // Call the method
                                                                    double result = UnivariateRealSolverUtils.solve(f, x0, x1);
                                                                    
                                                                    // Verify the result is the root (1.0)
                                                                    assertEquals(1.0, result, 0.0001);
                                                                    
                                                                    // Verify the function was evaluated at the bounds
                                                                    verify(f).value(0.0);
                                                                    verify(f).value(1.0);
                                                                }

    @Test
                                                                public void testSolveDetectsIterationCountMutation1() throws Exception {
                                                                    // Create a mock function that crosses zero between 0 and 1
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(0.0)).thenReturn(-1.0);
                                                                    when(f.value(1.0)).thenReturn(1.0);
                                                                    when(f.value(0.5)).thenReturn(0.0); // root at 0.5
                                                                    
                                                                    // Test with a small maximum iteration count that should still succeed
                                                                    double result = UnivariateRealSolverUtils.solve(f, 0.0, 1.0);
                                                                    
                                                                    // Verify the result is correct (should find root at 0.5)
                                                                    assertEquals(0.5, result, 0.0001);
                                                                    
                                                                    // The key test - if the mutant is present (numIterations > maximumIterations),
                                                                    // the solver would either:
                                                                    // 1. Not enter the loop at all (returning incorrect result)
                                                                    // 2. Throw exception if it somehow got into an infinite loop
                                                                    // Our assertion above would fail in case 1
                                                                    
                                                                    // Additional verification that function was evaluated properly
                                                                    verify(f, atLeastOnce()).value(0.0);
                                                                    verify(f, atLeastOnce()).value(1.0);
                                                                }

    @Test(expected = Exception.class)
                                                                public void testSolveFailsWhenExceedingMaxIterations() throws Exception {
                                                                    // Create a function that never crosses zero to force iteration limit
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(anyDouble())).thenReturn(1.0); // always positive
                                                                    
                                                                    // This should throw an exception when hitting max iterations
                                                                    // With the mutant, it might not throw (if numIterations starts at 0)
                                                                    UnivariateRealSolverUtils.solve(f, 0.0, 1.0);
                                                                }

    @Test(timeout = 1000) // timeout detects infinite loops
                                                                public void testSolveDetectsIterationCountMutation2() throws Exception {
                                                                    // Setup a function that requires multiple iterations to solve
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(anyDouble())).thenReturn(1.0, 1.0, 0.5, 0.1, -0.1); // Slowly converging
                                                                    
                                                                    // Mock solver factory and solver
                                                                    UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                                    when(solver.solve(any(UnivariateRealFunction.class), anyDouble(), anyDouble()))
                                                                        .thenCallRealMethod(); // Will use actual implementation
                                                                    
                                                                    // Replace LazyHolder.FACTORY with our mock factory
                                                                    UnivariateRealSolverFactory factory = mock(UnivariateRealSolverFactory.class);
                                                                    when(factory.newDefaultSolver()).thenReturn(solver);
                                                                    
                                                                    // Use reflection to inject our mock factory (since LazyHolder is presumably static)
                                                                    try {
                                                                        java.lang.reflect.Field field = UnivariateRealSolverUtils.class
                                                                            .getDeclaredField("FACTORY");
                                                                        field.setAccessible(true);
                                                                        Object originalFactory = field.get(null);
                                                                        field.set(null, factory);
                                                                        
                                                                        // Test parameters
                                                                        double x0 = 0.0;
                                                                        double x1 = 1.0;
                                                                        double accuracy = 0.001;
                                                                        
                                                                        // This should complete normally with original code
                                                                        // With mutant, it would either:
                                                                        // - Return immediately (if numIterations starts at 0)
                                                                        // - Run indefinitely (if numIterations starts > maximum)
                                                                        double result = UnivariateRealSolverUtils.solve(f, x0, x1, accuracy);
                                                                        
                                                                        // Verify solver was properly used
                                                                        verify(solver).setAbsoluteAccuracy(accuracy);
                                                                        verify(solver).solve(f, x0, x1);
                                                                        
                                                                        // Restore original factory
                                                                        field.set(null, originalFactory);
                                                                        
                                                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                        fail("Failed to inject mock factory: " + e.getMessage());
                                                                    }
                                                                }

    @Test
                                                    public void testSolveRespectsBoundaries() throws Exception {
                                                        // Setup mock function that has roots at -1, 0.5, and 2
                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                        when(f.value(-1.0)).thenReturn(0.0);
                                                        when(f.value(0.5)).thenReturn(0.0);
                                                        when(f.value(2.0)).thenReturn(0.0);
                                                        
                                                        // Setup mock solver that would find roots outside bounds if boundary check is disabled
                                                        UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                                        when(solver.solve(f, 0.0, 1.0)).thenReturn(0.5);  // valid solution
                                                        when(solver.getAbsoluteAccuracy()).thenReturn(1e-6);
                                                        
                                                        // Mock the factory to return our mock solver using reflection
                                                        UnivariateRealSolverFactory factory = mock(UnivariateRealSolverFactory.class);
                                                        when(factory.newDefaultSolver()).thenReturn(solver);
                                                        
                                                        // Use reflection to set the factory in UnivariateRealSolverUtils
                                                        Field factoryField = UnivariateRealSolverUtils.class.getDeclaredField("FACTORY");
                                                        factoryField.setAccessible(true);
                                                        Object originalFactory = factoryField.get(null);
                                                        factoryField.set(null, factory);
                                                        
                                                        try {
                                                            // Test with interval [0,1] - should only accept solution at 0.5
                                                            double result = UnivariateRealSolverUtils.solve(f, 0.0, 1.0, 1e-6);
                                                            
                                                            // Verify the solution is within bounds
                                                            assertTrue("Solution should be within bounds", result >= 0.0 && result <= 1.0);
                                                            
                                                            // Verify the solver was called with correct parameters
                                                            verify(solver).setAbsoluteAccuracy(1e-6);
                                                            verify(solver).solve(f, 0.0, 1.0);
                                                        } finally {
                                                            // Restore original factory
                                                            factoryField.set(null, originalFactory);
                                                        }
                                                    }

    @Test
                                                public void testSolveBoundaryCondition() throws Exception {
                                                    // Create mock objects
                                                    org.apache.commons.math.analysis.UnivariateRealFunction f = 
                                                        mock(org.apache.commons.math.analysis.UnivariateRealFunction.class);
                                                    
                                                    // Set up test values where both bounds are invalid
                                                    double invalidLower = 0.0;
                                                    double invalidUpper = 1.0;
                                                    
                                                    // Mock the solver to verify interactions
                                                    org.apache.commons.math.analysis.solvers.UnivariateRealSolver mockSolver = 
                                                        mock(org.apache.commons.math.analysis.solvers.UnivariateRealSolver.class);
                                                    
                                                    // Use reflection to set the default solver
                                                    Class<?> solverUtilsClass = Class.forName("org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils");
                                                    Field solverField = solverUtilsClass.getDeclaredField("defaultSolver");
                                                    solverField.setAccessible(true);
                                                    solverField.set(null, mockSolver);
                                                    
                                                    try {
                                                        // Call the method with invalid bounds
                                                        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(f, invalidLower, invalidUpper);
                                                        
                                                        // If we get here, the mutant survived (it proceeded when it shouldn't have)
                                                        fail("Expected IllegalArgumentException for invalid bounds");
                                                        
                                                    } catch (IllegalArgumentException e) {
                                                        // This is what we expect from the original code
                                                        // Verify the solver was NOT called
                                                        verify(mockSolver, never()).solve(
                                                            any(org.apache.commons.math.analysis.UnivariateRealFunction.class), 
                                                            anyDouble(), 
                                                            anyDouble());
                                                    } finally {
                                                        // Reset the default solver
                                                        solverField.set(null, null);
                                                    }
                                                }

    @Test
                                        public void testSolveWithExactZeroAtBoundary() throws Exception {
                                            // Create a mock function that returns zero at x=1.0
                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                            when(f.value(0.0)).thenReturn(-1.0);
                                            when(f.value(1.0)).thenReturn(0.0);  // exact zero at boundary
                                            when(f.value(0.5)).thenReturn(-0.5); // intermediate value
                                            
                                            // Mock the solver
                                            UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                            when(solver.solve(f, 0.0, 1.0)).thenReturn(1.0); // should return immediately when fb=0
                                            
                                            // Get the solver factory field from UnivariateRealSolverUtils
                                            Field factoryField = UnivariateRealSolverUtils.class.getDeclaredField("factory");
                                            factoryField.setAccessible(true);
                                            UnivariateRealSolverFactory originalFactory = (UnivariateRealSolverFactory) factoryField.get(null);
                                            
                                            try {
                                                // Create and set mock factory
                                                UnivariateRealSolverFactory mockFactory = mock(UnivariateRealSolverFactory.class);
                                                when(mockFactory.newDefaultSolver()).thenReturn(solver);
                                                factoryField.set(null, mockFactory);
                                                
                                                // Call the method
                                                double result = UnivariateRealSolverUtils.solve(f, 0.0, 1.0);
                                                
                                                // Verify behavior
                                                assertEquals(1.0, result, 0.0);
                                                verify(solver, times(1)).solve(f, 0.0, 1.0);
                                            } finally {
                                                // Reset the factory
                                                factoryField.set(null, originalFactory);
                                            }
                                        }

    @Test
                                        public void testSolveWithRootAtEndpointDetectsMutant() throws Exception {
                                            // Create a mock function that returns 0 at x0 and non-zero at x1
                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                            when(f.value(0.0)).thenReturn(0.0);  // root at x0
                                            when(f.value(1.0)).thenReturn(1.0);
                                            
                                            // Mock the solver factory and solver
                                            UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                            when(solver.solve(f, 0.0, 1.0)).thenReturn(0.0); // should return the root immediately
                                            
                                            // Use reflection to access and modify the private FACTORY field
                                            Class<?> lazyHolderClass = Class.forName("org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils$LazyHolder");
                                            Field factoryField = lazyHolderClass.getDeclaredField("FACTORY");
                                            factoryField.setAccessible(true);
                                            
                                            // Replace the LazyHolder.FACTORY with our mock
                                            UnivariateRealSolverFactory mockFactory = mock(UnivariateRealSolverFactory.class);
                                            when(mockFactory.newDefaultSolver()).thenReturn(solver);
                                            factoryField.set(null, mockFactory);
                                            
                                            // Call the method
                                            double result = UnivariateRealSolverUtils.solve(f, 0.0, 1.0, 0.0001);
                                            
                                            // Verify the result and behavior
                                            assertEquals(0.0, result, 0.0001);
                                            verify(solver).setAbsoluteAccuracy(0.0001);
                                            verify(solver).solve(f, 0.0, 1.0);
                                            
                                            // The key assertion - if the mutant survives, the solver would be called multiple times
                                            // Original behavior should call solve just once since we already have a root at endpoint
                                            verify(solver, times(1)).solve(f, 0.0, 1.0);
                                        }

    @Test
                                public void testSolveIterationBoundary4() throws Exception {
                                    // Setup test data
                                    double x0 = 0.0;
                                    double x1 = 1.0;
                                    double absoluteAccuracy = 0.001;
                                    
                                    // Mock the function and solver
                                    org.apache.commons.math.analysis.UnivariateRealFunction f = mock(org.apache.commons.math.analysis.UnivariateRealFunction.class);
                                    org.apache.commons.math.analysis.solvers.UnivariateRealSolver solver = mock(org.apache.commons.math.analysis.solvers.UnivariateRealSolver.class);
                                    
                                    // Setup mock behavior
                                    when(solver.getAbsoluteAccuracy()).thenReturn(absoluteAccuracy);
                                    
                                    // Create a solver factory that returns our mock solver
                                    org.apache.commons.math.analysis.solvers.UnivariateRealSolverFactory factory = mock(org.apache.commons.math.analysis.solvers.UnivariateRealSolverFactory.class);
                                    when(factory.newDefaultSolver()).thenReturn(solver);
                                    
                                    // Use reflection to inject our mock factory into LazyHolder
                                    try {
                                        Class<?> lazyHolderClass = Class.forName("org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils$LazyHolder");
                                        Field field = lazyHolderClass.getDeclaredField("FACTORY");
                                        field.setAccessible(true);
                                        field.set(null, factory);
                                    } catch (Exception e) {
                                        fail("Failed to inject mock factory");
                                    }
                                    
                                    // Test case where solution would require exactly maximumIterations
                                    when(solver.solve(f, x0, x1)).thenAnswer(invocation -> {
                                        // Simulate behavior at iteration boundary
                                        throw new org.apache.commons.math.MaxIterationsExceededException(100); // Assuming 100 is max
                                    });
                                    
                                    try {
                                        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(f, x0, x1, absoluteAccuracy);
                                        fail("Expected MaxIterationsExceededException");
                                    } catch (org.apache.commons.math.MaxIterationsExceededException e) {
                                        // Verify the exception contains the correct iteration count
                                        assertEquals(100, e.getMaxIterations());
                                    }
                                    
                                    // Verify solver was properly configured
                                    verify(solver).setAbsoluteAccuracy(absoluteAccuracy);
                                }

    @Test
                            public void testSolve_MaxIterationsBoundary() throws Exception {
                                // Create a mock function that will take exactly maximumIterations to converge
                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                
                                // Mock the solver to track iterations
                                UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                                
                                // Create a mock factory
                                UnivariateRealSolverFactory factory = mock(UnivariateRealSolverFactory.class);
                                when(factory.newDefaultSolver()).thenReturn(solver);
                                
                                // Use reflection to set the factory field in UnivariateRealSolverUtils
                                Field factoryField = UnivariateRealSolverUtils.class.getDeclaredField("factory");
                                factoryField.setAccessible(true);
                                factoryField.set(null, factory);
                                
                                // Setup test values
                                double x0 = 0.0;
                                double x1 = 1.0;
                                double expectedResult = 0.5;
                                
                                // Configure solver behavior
                                when(solver.solve(eq(f), eq(x0), eq(x1))).thenAnswer(invocation -> {
                                    // This would fail if mutant allows one extra iteration
                                    return expectedResult;
                                });
                                
                                // Call the method under test
                                double result = UnivariateRealSolverUtils.solve(f, x0, x1);
                                
                                // Verify the result
                                assertEquals(expectedResult, result, 0.0001);
                                
                                // Verify the solver was called exactly once (would fail if extra iteration occurs)
                                verify(solver, times(1)).solve(eq(f), eq(x0), eq(x1));
                            }

    @Test
                    public void testSolve_DetectsBoundaryConditionMutation() throws Exception {
                        // Create a mock function that has root exactly at lower bound (0.0)
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(0.0)).thenReturn(0.0);  // root at 0.0
                        when(f.value(1.0)).thenReturn(1.0);  // non-root at 1.0
                        
                        // Mock the solver
                        UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                        
                        // Mock the factory creation using reflection since LazyHolder isn't accessible
                        Field factoryField = UnivariateRealSolverUtils.class.getDeclaredField("FACTORY");
                        factoryField.setAccessible(true);
                        UnivariateRealSolverFactory factory = mock(UnivariateRealSolverFactory.class);
                        when(factory.newDefaultSolver()).thenReturn(solver);
                        factoryField.set(null, factory);
                        
                        // Set up the solver to return the boundary value (0.0)
                        when(solver.solve(eq(f), eq(0.0), eq(1.0))).thenReturn(0.0);
                        
                        // Call the method under test
                        double result = UnivariateRealSolverUtils.solve(f, 0.0, 1.0);
                        
                        // Verify the boundary value was correctly handled
                        assertNotEquals("Solver should not accept exact boundary value as solution", 
                                        0.0, result, 0.0001);
                        
                        // Verify the solver was called with correct parameters
                        verify(solver).solve(f, 0.0, 1.0);
                        
                        // Reset the factory field to avoid affecting other tests
                        factoryField.set(null, null);
                    }

    @Test
                    public void testSolveWithExactLowerBound() throws Exception {
                        // Setup test values where x0 is exactly at lower bound
                        double x0 = 0.0;
                        double x1 = 1.0;
                        double absoluteAccuracy = 0.0001;
                        
                        // Create mock objects
                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                        UnivariateRealSolver mockSolver = mock(UnivariateRealSolver.class);
                        
                        // Mock the solver's behavior
                        when(mockSolver.solve(mockFunction, x0, x1)).thenReturn(0.5);
                        
                        // The test should verify that with x0 exactly at lower bound,
                        // the method behaves correctly (either accepts or rejects based on original condition)
                        // This would catch the mutant where >= is used instead of >
                        
                        // For demonstration, we'll assume the original behavior should reject exact bounds
                        try {
                            UnivariateRealSolverUtils.solve(mockFunction, x0, x1, absoluteAccuracy);
                            fail("Expected IllegalArgumentException for exact lower bound");
                        } catch (IllegalArgumentException e) {
                            // This is the expected behavior for original code
                            // The mutant would not throw this exception
                            assertEquals("Invalid interval: lower bound equals minimum bound", e.getMessage());
                        }
                    }

    @Test
                    public void testSolveWithBoundaryConditions2() throws Exception {
                        // Test case specifically designed to catch the mutant
                        double lowerBound = Double.MIN_VALUE;
                        double upperBound = Double.MAX_VALUE;
                        double absoluteAccuracy = 0.0001;
                        
                        // Create a mock function that just returns 0
                        UnivariateRealFunction mockFunction = new UnivariateRealFunction() {
                            public double value(double x) {
                                return 0;
                            }
                        };
                        
                        // The original code with (a > lowerBound) would reject when a == lowerBound
                        // The mutant with (a >= lowerBound) would accept when a == lowerBound
                        
                        try {
                            UnivariateRealSolverUtils.solve(mockFunction, lowerBound, upperBound, absoluteAccuracy);
                            
                            // If we get here, the mutant behavior is present (accepted exact lower bound)
                            // We need to verify this is incorrect for the original specification
                            fail("Test should fail for mutant: Accepted exact lower bound when it should have been rejected");
                        } catch (IllegalArgumentException e) {
                            // This is the expected behavior for original code
                            assertTrue(e.getMessage().contains("Invalid interval"));
                        }
                    }

    @Test
            public void testSolve_ShouldNotAcceptSolutionAtUpperBound() throws Exception {
                // Define test variables
                double x0 = 0.0;
                double x1 = 1.0;
                double upperBoundSolution = x1; // Solution exactly at upper bound
                
                // Create mock objects
                UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                UnivariateRealSolver mockSolver = mock(UnivariateRealSolver.class);
                
                // Mock the solver to return the upper bound as solution
                when(mockSolver.solve(eq(mockFunction), eq(x0), eq(x1)))
                    .thenReturn(upperBoundSolution);
                
                // Set up the solver utils to use our mock solver
                // This requires reflection since the solver is typically set up internally
                try {
                    Field solverField = UnivariateRealSolverUtils.class.getDeclaredField("solver");
                    solverField.setAccessible(true);
                    solverField.set(null, mockSolver);
                } catch (Exception e) {
                    fail("Failed to set mock solver via reflection");
                }
                
                // This test should fail if the mutant is present, as it would accept the upper bound solution
                double result = UnivariateRealSolverUtils.solve(mockFunction, x0, x1);
                
                // The original implementation should not return the upper bound as solution
                // (assuming proper boundary checking in the original code)
                assertNotEquals("Solution should not be exactly at upper bound", 
                               x1, result, 0.0001);
            }

    @Test
            public void testSolve_DetectsUpperBoundMutation() throws Exception {
                // Setup
                double x0 = 0.0;
                double x1 = 1.0;
                double absoluteAccuracy = 0.0001;
                double expectedSolution = 1.0; // Solution at upper bound
                
                // Mock the function and solver
                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                UnivariateRealSolver solver = mock(UnivariateRealSolver.class);
                UnivariateRealSolverFactory factory = mock(UnivariateRealSolverFactory.class);
                
                // Use reflection to set the private FACTORY field
                Class<?> lazyHolderClass = Class.forName("org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils$LazyHolder");
                Field factoryField = lazyHolderClass.getDeclaredField("FACTORY");
                factoryField.setAccessible(true);
                factoryField.set(null, factory);
                
                // Mock the factory to return our mock solver
                when(factory.newDefaultSolver()).thenReturn(solver);
                
                // Configure solver to return solution at upper bound
                when(solver.solve(f, x0, x1)).thenReturn(expectedSolution);
                
                // Test
                double result = UnivariateRealSolverUtils.solve(f, x0, x1, absoluteAccuracy);
                
                // Verify the solver was called with correct parameters
                verify(solver).setAbsoluteAccuracy(absoluteAccuracy);
                verify(solver).solve(f, x0, x1);
                
                // This assertion would catch the mutant because:
                // Original code would work correctly when solution is at upper bound
                // Mutant might fail or behave differently at boundary
                assertEquals(expectedSolution, result, 0.0);
                
                // Additional verification that upper bound is properly handled
                // The mutant might incorrectly handle the case where solution is exactly at upper bound
                assertTrue(result == x1);
            }

    @Test
        public void testSolve_ShouldAcceptSolutionJustBelowUpperBound() throws Exception {
            double x0 = 0.0;
            double x1 = 1.0;
            double validSolution = x1 - 0.0001; // Solution just below upper bound
            
            // Create mock objects
            UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
            UnivariateRealSolver mockSolver = mock(UnivariateRealSolver.class);
            
            // Mock the solver to return a solution just below upper bound
            when(mockSolver.solve(eq(mockFunction), eq(x0), eq(x1)))
                .thenReturn(validSolution);
            
            // Use reflection to set the solver factory since it's private
            Field factoryField = UnivariateRealSolverUtils.class.getDeclaredField("factory");
            factoryField.setAccessible(true);
            UnivariateRealSolverFactory originalFactory = (UnivariateRealSolverFactory) factoryField.get(null);
            
            try {
                // Create a mock factory that returns our mock solver
                UnivariateRealSolverFactory mockFactory = mock(UnivariateRealSolverFactory.class);
                when(mockFactory.newDefaultSolver()).thenReturn(mockSolver);
                factoryField.set(null, mockFactory);
                
                double result = UnivariateRealSolverUtils.solve(mockFunction, x0, x1);
                
                // This should be accepted by both original and mutated code
                assertEquals("Solution just below upper bound should be accepted",
                            validSolution, result, 0.0001);
            } finally {
                // Restore original factory
                factoryField.set(null, originalFactory);
            }
        }

    @Test
        public void testSolveBoundaryCheck() throws Exception {
            // Create a mock function that has a root outside the given bounds
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(anyDouble())).thenReturn(1.0); // Never crosses zero in valid range
            
            // Set up test parameters
            double x0 = 0.0;
            double x1 = 1.0;
            
            try {
                // This should fail with original code since no root exists in bounds
                double result = UnivariateRealSolverUtils.solve(f, x0, x1);
                
                // If we get here, the boundary check was bypassed (mutant behavior)
                fail("Expected exception not thrown - mutant detected!");
            } catch (Exception e) {
                // Original code should throw an exception when no root found in bounds
                assertTrue(e instanceof IllegalArgumentException);
            }
        }

    @Test(expected = IllegalArgumentException.class)
        public void testSolveRespectsLowerBound() throws Exception {
            // Setup
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(anyDouble())).thenReturn(-1.0); // Always negative to force search left
            
            // This should try to solve outside lower bound
            // Original would throw due to bound check, mutant would allow
            UnivariateRealSolverUtils.solve(f, 1.0, 2.0, 0.001);
        }

    @Test(expected = IllegalArgumentException.class)
        public void testSolveRespectsUpperBound() throws Exception {
            // Setup
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(anyDouble())).thenReturn(1.0); // Always positive to force search right
            
            // This should try to solve outside upper bound
            // Original would throw due to bound check, mutant would allow
            UnivariateRealSolverUtils.solve(f, 1.0, 2.0, 0.001);
        }

    @Test
        public void testSolveWithinBounds() throws Exception {
            // Setup
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(1.5)).thenReturn(0.0); // Root at midpoint
            when(f.value(anyDouble())).thenReturn(1.0); // Non-root values
            
            // This should solve normally within bounds
            double result = UnivariateRealSolverUtils.solve(f, 1.0, 2.0, 0.001);
            assertEquals(1.5, result, 0.001);
        }

}
