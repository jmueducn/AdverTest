package gentest.org.apache.commons.math.stat.inference.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.inference.*;
import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.ChiSquaredDistribution;
import org.apache.commons.math.distribution.ChiSquaredDistributionImpl;
import org.apache.commons.math.distribution.DistributionFactory;
 
public class ChiSquareTestImplTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                                    public void testChiSquare_ValidInputs() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        double[] expected = {10.0, 20.0, 30.0};
                                                                                                                                        long[] observed = {12L, 18L, 32L};
                                                                                                                                        
                                                                                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                                                        
                                                                                                                                        // Verify the result is positive (as chi-square should always be)
                                                                                                                                        assertTrue(result > 0);
                                                                                                                                        // Verify the calculation with known expected value
                                                                                                                                        assertEquals(2.2, result, 0.0001);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_RescalingNeeded() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        double[] expected = {10.0, 20.0, 30.0};
                                                                                                                                        long[] observed = {24L, 36L, 64L}; // Sums don't match
                                                                                                                                        
                                                                                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                                                        
                                                                                                                                        assertTrue(result > 0);
                                                                                                                                        // Verify rescaling was applied by checking against known value
                                                                                                                                        assertEquals(2.2, result, 0.0001);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_ExpectedArrayTooShort() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        double[] expected = {10.0}; // Only 1 element
                                                                                                                                        long[] observed = {12L, 18L};
                                                                                                                                        
                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                        thrown.expectMessage("observed, expected array lengths incorrect");
                                                                                                                                        
                                                                                                                                        chiSquareTest.chiSquare(expected, observed);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_ArrayLengthMismatch() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        double[] expected = {10.0, 20.0};
                                                                                                                                        long[] observed = {12L, 18L, 20L}; // Different lengths
                                                                                                                                        
                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                        thrown.expectMessage("observed, expected array lengths incorrect");
                                                                                                                                        
                                                                                                                                        chiSquareTest.chiSquare(expected, observed);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_NegativeObservedValues() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        double[] expected = {10.0, 20.0, 30.0};
                                                                                                                                        long[] observed = {12L, -18L, 32L}; // Negative observed value
                                                                                                                                        
                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                        thrown.expectMessage("observed counts must be non-negative and expected counts must be postive");
                                                                                                                                        
                                                                                                                                        chiSquareTest.chiSquare(expected, observed);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_NonPositiveExpectedValues() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        double[] expected = {10.0, 0.0, 30.0}; // Zero expected value
                                                                                                                                        long[] observed = {12L, 18L, 32L};
                                                                                                                                        
                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                        thrown.expectMessage("observed counts must be non-negative and expected counts must be postive");
                                                                                                                                        
                                                                                                                                        chiSquareTest.chiSquare(expected, observed);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_ZeroObservedValues() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        double[] expected = {10.0, 20.0, 30.0};
                                                                                                                                        long[] observed = {0L, 0L, 0L}; // All zeros
                                                                                                                                        
                                                                                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                                                        
                                                                                                                                        // Should be sum of (expected[i]^2)/expected[i] = sum(expected)
                                                                                                                                        assertEquals(60.0, result, 0.0001);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_PerfectMatch() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        double[] expected = {10.0, 20.0, 30.0};
                                                                                                                                        long[] observed = {10L, 20L, 30L}; // Perfect match
                                                                                                                                        
                                                                                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                                                        
                                                                                                                                        // Should be 0 when observed exactly matches expected
                                                                                                                                        assertEquals(0.0, result, 0.0001);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_LargeArrays() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        double[] expected = new double[1000];
                                                                                                                                        long[] observed = new long[1000];
                                                                                                                                        
                                                                                                                                        // Fill arrays with simple pattern
                                                                                                                                        for (int i = 0; i < 1000; i++) {
                                                                                                                                            expected[i] = i + 1;
                                                                                                                                            observed[i] = i + 2;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                                                        
                                                                                                                                        // Verify it handles large arrays without error
                                                                                                                                        assertTrue(result > 0);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_WithMockedDistribution() {
                                                                                                                                        // Mock the ChiSquaredDistribution dependency
                                                                                                                                        ChiSquaredDistribution mockDist = mock(ChiSquaredDistribution.class);
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl(mockDist);
                                                                                                                                        
                                                                                                                                        double[] expected = {10.0, 20.0, 30.0};
                                                                                                                                        long[] observed = {12L, 18L, 32L};
                                                                                                                                        
                                                                                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                                                        
                                                                                                                                        // Verify the calculation is correct regardless of distribution
                                                                                                                                        assertEquals(2.2, result, 0.0001);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_2x2Table() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        long[][] counts = {{10, 20}, {30, 40}};
                                                                                                                                        
                                                                                                                                        // Expected calculations:
                                                                                                                                        // Row sums: 30, 70
                                                                                                                                        // Column sums: 40, 60
                                                                                                                                        // Total: 100
                                                                                                                                        // Expected values:
                                                                                                                                        // (30*40)/100=12, (30*60)/100=18
                                                                                                                                        // (70*40)/100=28, (70*60)/100=42
                                                                                                                                        // Chi-square components:
                                                                                                                                        // (10-12)²/12 + (20-18)²/18 + (30-28)²/28 + (40-42)²/42
                                                                                                                                        // = 4/12 + 4/18 + 4/28 + 4/42 ≈ 0.7936507
                                                                                                                                        
                                                                                                                                        double result = chiSquareTest.chiSquare(counts);
                                                                                                                                        assertEquals(0.7936507, result, 1e-6);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_3x2Table() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        long[][] counts = {{5, 10}, {15, 20}, {25, 30}};
                                                                                                                                        
                                                                                                                                        // Expected calculations:
                                                                                                                                        // Row sums: 15, 35, 55
                                                                                                                                        // Column sums: 45, 60
                                                                                                                                        // Total: 105
                                                                                                                                        // Expected values:
                                                                                                                                        // (15*45)/105≈6.4286, (15*60)/105≈8.5714
                                                                                                                                        // (35*45)/105=15, (35*60)/105=20
                                                                                                                                        // (55*45)/105≈23.5714, (55*60)/105≈31.4286
                                                                                                                                        // Chi-square calculation would be more complex...
                                                                                                                                        // We'll just verify it's positive and reasonable
                                                                                                                                        
                                                                                                                                        double result = chiSquareTest.chiSquare(counts);
                                                                                                                                        assertTrue(result > 0);
                                                                                                                                        assertTrue(result < 10); // Reasonable upper bound
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_WithZeroCounts() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        long[][] counts = {{0, 10}, {20, 0}};
                                                                                                                                        
                                                                                                                                        // Expected calculations:
                                                                                                                                        // Row sums: 10, 20
                                                                                                                                        // Column sums: 20, 10
                                                                                                                                        // Total: 30
                                                                                                                                        // Expected values:
                                                                                                                                        // (10*20)/30≈6.6667, (10*10)/30≈3.3333
                                                                                                                                        // (20*20)/30≈13.3333, (20*10)/30≈6.6667
                                                                                                                                        // Chi-square components would include some division by expected values
                                                                                                                                        
                                                                                                                                        double result = chiSquareTest.chiSquare(counts);
                                                                                                                                        assertTrue(result > 0);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_NonRectangularArrayThrowsException() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        long[][] counts = {{1, 2}, {3}}; // Jagged array
                                                                                                                                        
                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                        chiSquareTest.chiSquare(counts);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_1x1Table() {
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                        long[][] counts = {{5}};
                                                                                                                                        
                                                                                                                                        // Expected calculations:
                                                                                                                                        // Row sum: 5
                                                                                                                                        // Column sum: 5
                                                                                                                                        // Total: 5
                                                                                                                                        // Expected value: (5*5)/5 = 5
                                                                                                                                        // Chi-square component: (5-5)²/5 = 0
                                                                                                                                        
                                                                                                                                        double result = chiSquareTest.chiSquare(counts);
                                                                                                                                        assertEquals(0.0, result, 1e-6);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testChiSquare_WithMockedDistribution1() {
                                                                                                                                        // Mock the ChiSquaredDistribution
                                                                                                                                        ChiSquaredDistribution mockDist = mock(ChiSquaredDistribution.class);
                                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl(mockDist);
                                                                                                                                        
                                                                                                                                        long[][] counts = {{10, 20}, {30, 40}};
                                                                                                                                        double chiSquareValue = 0.7936507;
                                                                                                                                        
                                                                                                                                        // The actual chiSquare calculation should still work the same
                                                                                                                                        double result = chiSquareTest.chiSquare(counts);
                                                                                                                                        assertEquals(chiSquareValue, result, 1e-6);
                                                                                                                                        
                                                                                                                                        // Verify the distribution was set (though not used in this method)
                                                                                                                                        verify(mockDist, atLeastOnce()).getDegreesOfFreedom();
                                                                                                                                    }

    @Test
                                                                                                                            public void testChiSquareDetectsFirstElementMutation() {
                                                                                                                                // Arrange
                                                                                                                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                double[] expected = new double[]{1.0, 10.0, 10.0}; // First element is small
                                                                                                                                long[] observed = new long[]{5, 10, 10}; // First element differs significantly
                                                                                                                                
                                                                                                                                // Act
                                                                                                                                double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                                                
                                                                                                                                // Calculate expected value manually including first element
                                                                                                                                double sumExpected = 1.0 + 10.0 + 10.0;
                                                                                                                                double sumObserved = 5 + 10 + 10;
                                                                                                                                double ratio = sumObserved / sumExpected;
                                                                                                                                double expectedValue = 0.0;
                                                                                                                                expectedValue += Math.pow(5 - ratio * 1.0, 2) / (ratio * 1.0);
                                                                                                                                expectedValue += Math.pow(10 - ratio * 10.0, 2) / (ratio * 10.0);
                                                                                                                                expectedValue += Math.pow(10 - ratio * 10.0, 2) / (ratio * 10.0);
                                                                                                                                
                                                                                                                                // Assert
                                                                                                                                assertEquals("Chi-square value should include first element contribution", 
                                                                                                                                            expectedValue, result, 1E-10);
                                                                                                                            }

    @Test
                                                                                                                            public void testChiSquareDetectsRowLoopMutation() {
                                                                                                                                // Create a 2x2 contingency table where first row is significant
                                                                                                                                long[][] counts = new long[][] {
                                                                                                                                    {10, 20},  // This row will be skipped by the mutant
                                                                                                                                    {15, 15}
                                                                                                                                };
                                                                                                                                
                                                                                                                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                                
                                                                                                                                // Calculate expected chi-square value manually
                                                                                                                                // Row sums: 30, 30
                                                                                                                                // Column sums: 25, 35
                                                                                                                                // Total: 60
                                                                                                                                // Expected values:
                                                                                                                                // [0][0]: (30*25)/60 = 12.5
                                                                                                                                // [0][1]: (30*35)/60 = 17.5
                                                                                                                                // [1][0]: (30*25)/60 = 12.5
                                                                                                                                // [1][1]: (30*35)/60 = 17.5
                                                                                                                                // Chi-square contributions:
                                                                                                                                // [0][0]: (10-12.5)^2/12.5 = 0.5
                                                                                                                                // [0][1]: (20-17.5)^2/17.5 ≈ 0.357
                                                                                                                                // [1][0]: (15-12.5)^2/12.5 = 0.5
                                                                                                                                // [1][1]: (15-17.5)^2/17.5 ≈ 0.357
                                                                                                                                // Total expected chi-square: ~1.714
                                                                                                                                
                                                                                                                                double expectedChiSquare = 1.7142857142857142;
                                                                                                                                double actualChiSquare = chiSquareTest.chiSquare(counts);
                                                                                                                                
                                                                                                                                // Use delta of 0.0001 for floating point comparison
                                                                                                                                assertEquals("Chi-square value incorrect - mutant may have skipped first row", 
                                                                                                                                            expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                                            }

    @Test
                                                                                                                        public void testChiSquareWithRescalingDetectsRatioMutation() {
                                                                                                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                            
                                                                                                                            // Input where sums differ to force rescaling
                                                                                                                            double[] expected = {10.0, 20.0, 30.0};  // sum = 60.0
                                                                                                                            long[] observed = {15L, 25L, 35L};       // sum = 75.0
                                                                                                                            
                                                                                                                            // Calculate expected ratio and expected sumSq manually
                                                                                                                            double expectedRatio = 75.0 / 60.0;  // 1.25
                                                                                                                            double expectedSumSq = 0.0;
                                                                                                                            for (int i = 0; i < observed.length; i++) {
                                                                                                                                double dev = observed[i] - expectedRatio * expected[i];
                                                                                                                                expectedSumSq += dev * dev / (expectedRatio * expected[i]);
                                                                                                                            }
                                                                                                                            
                                                                                                                            // If ratio was mutated to 0.0, this would throw ArithmeticException (division by zero)
                                                                                                                            double actualSumSq = chiSquareTest.chiSquare(expected, observed);
                                                                                                                            
                                                                                                                            // Verify the calculation uses correct ratio (would fail if ratio was 0.0)
                                                                                                                            assertEquals(expectedSumSq, actualSumSq, 1E-10);
                                                                                                                            
                                                                                                                            // Additional check that result isn't zero/infinity/NaN which would indicate division problems
                                                                                                                            assertTrue(actualSumSq > 0);
                                                                                                                            assertFalse(Double.isInfinite(actualSumSq));
                                                                                                                            assertFalse(Double.isNaN(actualSumSq));
                                                                                                                        }

    @Test
                                                                                                                        public void testChiSquareNonZeroResult() {
                                                                                                                            // Setup
                                                                                                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                            long[][] counts = new long[][] {
                                                                                                                                {10, 20},
                                                                                                                                {30, 40}
                                                                                                                            };
                                                                                                                            
                                                                                                                            // Expected value calculated manually:
                                                                                                                            // Row sums: 30, 70
                                                                                                                            // Column sums: 40, 60
                                                                                                                            // Total: 100
                                                                                                                            // Expected values:
                                                                                                                            // [0][0]: (30*40)/100 = 12
                                                                                                                            // [0][1]: (30*60)/100 = 18
                                                                                                                            // [1][0]: (70*40)/100 = 28
                                                                                                                            // [1][1]: (70*60)/100 = 42
                                                                                                                            // Chi-square components:
                                                                                                                            // (10-12)²/12 = 0.333
                                                                                                                            // (20-18)²/18 = 0.222
                                                                                                                            // (30-28)²/28 = 0.143
                                                                                                                            // (40-42)²/42 = 0.095
                                                                                                                            // Sum: ~0.793
                                                                                                                            
                                                                                                                            // Action
                                                                                                                            double result = chiSquareTest.chiSquare(counts);
                                                                                                                            
                                                                                                                            // Assertion
                                                                                                                            assertNotEquals(0.0, result, 0.0001); // Should not be zero
                                                                                                                            assertEquals(0.793, result, 0.001); // Verify against manual calculation
                                                                                                                        }

    @Test
                                                                                                                    public void testChiSquareWithRescalingDetectsRatioMutant() {
                                                                                                                        // Setup
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        double[] expected = {10.0, 20.0, 30.0}; // Sum = 60.0
                                                                                                                        long[] observed = {15L, 25L, 35L};      // Sum = 75.0 (different from expected)
                                                                                                                        
                                                                                                                        // Expected calculation with correct ratio (1.0 initial value):
                                                                                                                        // ratio = 75.0/60.0 = 1.25
                                                                                                                        // For first element: dev = 15 - 1.25*10 = 2.5
                                                                                                                        // sumSq = (2.5^2)/(1.25*10) + ... = 0.5 + ...
                                                                                                                        // Complete manual calculation:
                                                                                                                        double manualSumSq = 0.0;
                                                                                                                        double ratio = 75.0 / 60.0;
                                                                                                                        for (int i = 0; i < observed.length; i++) {
                                                                                                                            double dev = observed[i] - ratio * expected[i];
                                                                                                                            manualSumSq += dev * dev / (ratio * expected[i]);
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Test - this will fail if ratio starts at 2.0 instead of 1.0
                                                                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                                        assertEquals(manualSumSq, result, 1E-10);
                                                                                                                        
                                                                                                                        // Additional assertion to directly catch the mutant
                                                                                                                        // With mutant's ratio=2.0 initial value, the first term would be:
                                                                                                                        // wrongRatio = 2.0 * (75.0/60.0) = 2.5
                                                                                                                        // wrongDev = 15 - 2.5*10 = -10
                                                                                                                        // wrongSumSq = (-10)^2/(2.5*10) = 4.0 for first term (vs correct 0.5)
                                                                                                                        // So we can add this check:
                                                                                                                        assertTrue("Mutant detected: incorrect ratio initialization", 
                                                                                                                                   Math.abs(result - manualSumSq) < 1E-10);
                                                                                                                    }

    @Test
                                                                                                                    public void testChiSquareWithKnownValues() {
                                                                                                                        // Arrange
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        long[][] counts = {{10, 10}, {20, 20}}; // Simple 2x2 contingency table
                                                                                                                        
                                                                                                                        // Manually calculated expected chi-square value
                                                                                                                        // Row sums: 20, 40
                                                                                                                        // Column sums: 30, 30
                                                                                                                        // Total: 60
                                                                                                                        // Expected values:
                                                                                                                        // [0][0]: (20*30)/60 = 10
                                                                                                                        // [0][1]: (20*30)/60 = 10
                                                                                                                        // [1][0]: (40*30)/60 = 20
                                                                                                                        // [1][1]: (40*30)/60 = 20
                                                                                                                        // Chi-square calculation:
                                                                                                                        // (10-10)²/10 + (10-10)²/10 + (20-20)²/20 + (20-20)²/20 = 0
                                                                                                                        
                                                                                                                        // Act
                                                                                                                        double result = chiSquareTest.chiSquare(counts);
                                                                                                                        
                                                                                                                        // Assert
                                                                                                                        assertEquals(0.0, result, 0.0001); // Should be exactly 0
                                                                                                                        // If ratio was mutated to 2.0, result would be 0*2=0, so this test wouldn't catch it
                                                                                                                        // Therefore we need a non-zero case
                                                                                                                        
                                                                                                                        // Second test case with non-zero expected value
                                                                                                                        long[][] counts2 = {{5, 15}, {10, 10}};
                                                                                                                        // Expected calculations:
                                                                                                                        // Row sums: 20, 20
                                                                                                                        // Column sums: 15, 25
                                                                                                                        // Total: 40
                                                                                                                        // Expected values:
                                                                                                                        // [0][0]: (20*15)/40 = 7.5
                                                                                                                        // [0][1]: (20*25)/40 = 12.5
                                                                                                                        // [1][0]: (20*15)/40 = 7.5
                                                                                                                        // [1][1]: (20*25)/40 = 12.5
                                                                                                                        // Chi-square:
                                                                                                                        // (5-7.5)²/7.5 + (15-12.5)²/12.5 + (10-7.5)²/7.5 + (10-12.5)²/12.5
                                                                                                                        // = 6.25/7.5 + 6.25/12.5 + 6.25/7.5 + 6.25/12.5
                                                                                                                        // ≈ 0.8333 + 0.5 + 0.8333 + 0.5 = 2.6666
                                                                                                                        
                                                                                                                        double result2 = chiSquareTest.chiSquare(counts2);
                                                                                                                        assertEquals(2.6666, result2, 0.0001);
                                                                                                                        // If ratio was 2.0, this would be 5.3332 and the assertion would fail
                                                                                                                    }

    @Test
                                                                                                                public void testChiSquareRescaleFalseWhenSumsEqual() {
                                                                                                                    // Setup
                                                                                                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                    double[] expected = new double[]{10.0, 20.0, 30.0};  // sum = 60.0
                                                                                                                    long[] observed = new long[]{10, 20, 30};           // sum = 60
                                                                                                                    
                                                                                                                    // Expected behavior: rescale should be false since sums are equal
                                                                                                                    // Mutated behavior: rescale will be true regardless
                                                                                                                    
                                                                                                                    // Calculate expected value without rescaling
                                                                                                                    double expectedSumSq = 0.0;
                                                                                                                    for (int i = 0; i < observed.length; i++) {
                                                                                                                        double dev = observed[i] - expected[i];
                                                                                                                        expectedSumSq += dev * dev / expected[i];
                                                                                                                    }
                                                                                                                    
                                                                                                                    // Execute
                                                                                                                    double actualSumSq = chiSquareTest.chiSquare(expected, observed);
                                                                                                                    
                                                                                                                    // Verify
                                                                                                                    assertEquals("Chi-square value should match expected calculation without rescaling", 
                                                                                                                                expectedSumSq, actualSumSq, 1E-10);
                                                                                                                    
                                                                                                                    // This will fail on the mutant because:
                                                                                                                    // 1. Mutant forces rescale=true
                                                                                                                    // 2. Will calculate using ratio=1.0 (sumObserved/sumExpected)
                                                                                                                    // 3. But still uses the rescaling branch which gives same numerical result in this case
                                                                                                                    // Therefore we need a more sensitive test
                                                                                                                    
                                                                                                                    // More sensitive test using values where rescaling would produce different results
                                                                                                                    double[] expected2 = new double[]{1.0, 2.0, 3.0};  // sum = 6.0
                                                                                                                    long[] observed2 = new long[]{2, 3, 1};            // sum = 6 (same)
                                                                                                                    
                                                                                                                    // Correct calculation without rescaling
                                                                                                                    double expectedSumSq2 = 0.0;
                                                                                                                    for (int i = 0; i < observed2.length; i++) {
                                                                                                                        double dev = observed2[i] - expected2[i];
                                                                                                                        expectedSumSq2 += dev * dev / expected2[i];
                                                                                                                    }
                                                                                                                    
                                                                                                                    // Mutant calculation with rescaling (ratio=1.0)
                                                                                                                    double mutantSumSq = 0.0;
                                                                                                                    for (int i = 0; i < observed2.length; i++) {
                                                                                                                        double dev = observed2[i] - 1.0 * expected2[i];  // ratio=1.0
                                                                                                                        mutantSumSq += dev * dev / (1.0 * expected2[i]);
                                                                                                                    }
                                                                                                                    
                                                                                                                    // While numerically same in this case, the execution path is different
                                                                                                                    // To really catch the mutant, we need to verify the rescale flag wasn't unnecessarily set
                                                                                                                    // Since we can't access the flag, we use a case where rescaling would matter
                                                                                                                    
                                                                                                                    // Test with values where sums are exactly equal but rescaling would give different results
                                                                                                                    double[] expected3 = new double[]{1.000001, 2.000001, 3.000001};  // sum ≈ 6.000003
                                                                                                                    long[] observed3 = new long[]{2, 3, 1};                           // sum = 6
                                                                                                                    
                                                                                                                    // Correct calculation should not rescale (difference < 10E-6)
                                                                                                                    double actualSumSq3 = chiSquareTest.chiSquare(expected3, observed3);
                                                                                                                    double expectedSumSq3 = 0.0;
                                                                                                                    for (int i = 0; i < observed3.length; i++) {
                                                                                                                        double dev = observed3[i] - expected3[i];
                                                                                                                        expectedSumSq3 += dev * dev / expected3[i];
                                                                                                                    }
                                                                                                                    
                                                                                                                    assertEquals("Should not rescale when sums are nearly equal", 
                                                                                                                                expectedSumSq3, actualSumSq3, 1E-10);
                                                                                                                }

    @Test
                                                                                                            public void testChiSquareWithRescale() throws MathException {
                                                                                                                // Setup
                                                                                                                ChiSquaredDistribution mockDistribution = mock(ChiSquaredDistribution.class);
                                                                                                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl(mockDistribution);
                                                                                                                
                                                                                                                // Test data - simple 2x2 contingency table
                                                                                                                long[][] counts = {{10, 20}, {30, 40}};
                                                                                                                
                                                                                                                // Expected unscaled chi-square value
                                                                                                                double expectedUnscaled = 1.5873015873015872;
                                                                                                                
                                                                                                                // When rescale is true, the result should be different
                                                                                                                double expectedScaled = expectedUnscaled * 2; // Example scaling factor
                                                                                                                
                                                                                                                // Mock the distribution to return scaled value when rescale is true
                                                                                                                when(mockDistribution.cumulativeProbability(expectedUnscaled)).thenReturn(0.9);
                                                                                                                when(mockDistribution.cumulativeProbability(expectedScaled)).thenReturn(0.8);
                                                                                                                
                                                                                                                // Test chiSquareTest method which likely uses the rescale flag
                                                                                                                double result = chiSquareTest.chiSquareTest(counts);
                                                                                                                
                                                                                                                // Verify the result shows the scaling effect
                                                                                                                // If rescale=true, it should use the scaled value (0.8)
                                                                                                                // If rescale=false (original), it would use 0.9
                                                                                                                assertEquals(0.8, result, 0.0001);
                                                                                                                
                                                                                                                // Verify interaction with distribution object
                                                                                                                verify(mockDistribution).cumulativeProbability(expectedScaled);
                                                                                                            }

    @Test
                                                                                                        public void testChiSquareRescalingAtThreshold() {
                                                                                                            // Setup
                                                                                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                            double[] expected = new double[]{1.0, 1.0 + 5E-6}; // sum = 2.0 + 5E-6
                                                                                                            long[] observed = new long[]{1, 1}; // sum = 2.0
                                                                                                            
                                                                                                            // Difference between sums is exactly 5E-6 (within 10E-6 threshold)
                                                                                                            // Original should NOT rescale, mutant SHOULD rescale
                                                                                                            
                                                                                                            // Calculate expected results for both cases
                                                                                                            // Case 1: No rescaling (original behavior)
                                                                                                            double expectedNoRescale = 0.0;
                                                                                                            for (int i = 0; i < observed.length; i++) {
                                                                                                                double dev = observed[i] - expected[i];
                                                                                                                expectedNoRescale += dev * dev / expected[i];
                                                                                                            }
                                                                                                            
                                                                                                            // Case 2: With rescaling (mutant behavior)
                                                                                                            double ratio = 2.0 / (2.0 + 5E-6);
                                                                                                            double expectedWithRescale = 0.0;
                                                                                                            for (int i = 0; i < observed.length; i++) {
                                                                                                                double dev = observed[i] - ratio * expected[i];
                                                                                                                expectedWithRescale += dev * dev / (ratio * expected[i]);
                                                                                                            }
                                                                                                            
                                                                                                            // Execute and verify
                                                                                                            double actual = chiSquareTest.chiSquare(expected, observed);
                                                                                                            
                                                                                                            // Original should match no-rescale calculation
                                                                                                            // Mutant would match with-rescale calculation
                                                                                                            assertEquals("Chi-square value should not rescale at exact threshold difference",
                                                                                                                        expectedNoRescale,
                                                                                                                        actual,
                                                                                                                        1E-10);
                                                                                                            
                                                                                                            // Additional verification that we're testing the right scenario
                                                                                                            double sumDiff = Math.abs((2.0 + 5E-6) - 2.0);
                                                                                                            assertEquals(5E-6, sumDiff, 1E-12); // Verify our test case setup
                                                                                                        }

    @Test
                                                                                                        public void testChiSquareWithPreciseDifference() {
                                                                                                            // Create a test case where the difference is exactly 10E-6
                                                                                                            long[][] counts = new long[][] {
                                                                                                                {1000000L, 1000000L},
                                                                                                                {1000000L, 1000000L + 1L}  // This creates a tiny difference
                                                                                                            };
                                                                                                            
                                                                                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                            double result = chiSquareTest.chiSquare(counts);
                                                                                                            
                                                                                                            // The exact expected value needs to be calculated, but we know it should be very small
                                                                                                            // The key is that with the mutation, the behavior changes when difference equals 10E-6
                                                                                                            double expected = 2.5E-13; // This is the approximate expected value
                                                                                                            
                                                                                                            // Assert with delta to account for floating point precision
                                                                                                            assertEquals(expected, result, 1E-14);
                                                                                                            
                                                                                                            // Additional test with values that would make difference exactly 10E-6
                                                                                                            long[][] edgeCounts = new long[][] {
                                                                                                                {100000L, 100000L},
                                                                                                                {100000L, 100001L}  // This should create difference close to 10E-6
                                                                                                            };
                                                                                                            
                                                                                                            double edgeResult = chiSquareTest.chiSquare(edgeCounts);
                                                                                                            double edgeExpected = 2.5E-11;
                                                                                                            assertEquals(edgeExpected, edgeResult, 1E-12);
                                                                                                        }

    @Test
                                                                                                    public void testChiSquareRescaleThreshold() {
                                                                                                        ChiSquareTestImpl chiSquare = new ChiSquareTestImpl();
                                                                                                        
                                                                                                        // Create inputs where sum difference is 5E-6 (between 10E-6 and 10E-5)
                                                                                                        double[] expected = new double[]{1.000000, 1.000000};
                                                                                                        long[] observed = new long[]{1_000_005, 999_995}; // sum diff = 10 (5E-6 per item)
                                                                                                        
                                                                                                        // Calculate expected results for both cases
                                                                                                        double originalResult = chiSquare.chiSquare(expected, observed);
                                                                                                        
                                                                                                        // Verify the rescaling occurred (original behavior)
                                                                                                        // With original threshold (10E-6), rescaling should happen
                                                                                                        // With mutant threshold (10E-5), rescaling shouldn't happen
                                                                                                        // We know rescaling happened if result is different from non-rescaled calculation
                                                                                                        
                                                                                                        // Manually calculate expected value with rescaling
                                                                                                        double sumExpected = 2.0;
                                                                                                        double sumObserved = 2_000_000L;
                                                                                                        double ratio = sumObserved / sumExpected;
                                                                                                        double expectedRescaled = 0.0;
                                                                                                        for (int i = 0; i < observed.length; i++) {
                                                                                                            double dev = observed[i] - ratio * expected[i];
                                                                                                            expectedRescaled += dev * dev / (ratio * expected[i]);
                                                                                                        }
                                                                                                        
                                                                                                        // Assert the result matches rescaled calculation (original behavior)
                                                                                                        assertEquals(expectedRescaled, originalResult, 1E-10);
                                                                                                        
                                                                                                        // If this test fails (gets non-rescaled result), it means the mutant survived
                                                                                                    }

    @Test
                                                                                                        public void testChiSquareWithPrecisionDifference() {
                                                                                                            // Create a test case where the difference is between 10E-6 and 10E-5
                                                                                                            long[][] counts = new long[][] {
                                                                                                                {1000000, 1000000},
                                                                                                                {1000000, 1000000 + 6} // Adding 6 creates a difference of ~9.99997E-7
                                                                                                            };
                                                                                                            
                                                                                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                            
                                                                                                            // Calculate the actual chi-square value
                                                                                                            double result = chiSquareTest.chiSquare(counts);
                                                                                                            
                                                                                                            // Verify the result is calculated properly
                                                                                                            // The exact expected value would need precise calculation, but we know it should be > 0
                                                                                                            assertTrue("Chi-square value should be positive for non-perfect fit", result > 0);
                                                                                                            
                                                                                                            // The key assertion is that the test doesn't throw an exception
                                                                                                            // (since the original code would throw when difference > 10E-6,
                                                                                                            // while mutant would only throw when > 10E-5)
                                                                                                            // This test will pass with original code but fail with mutant
                                                                                                        }

    @Test
                                                                                                public void testChiSquareRescalingBehavior() {
                                                                                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                    
                                                                                                    // Create inputs where sums are equal (difference < 10E-6)
                                                                                                    double[] expected = {10.0, 10.0, 10.0};  // Sum = 30.0
                                                                                                    long[] observed = {10L, 10L, 10L};       // Sum = 30.0
                                                                                                    
                                                                                                    // Calculate expected value without rescaling
                                                                                                    double expectedSumSq = 0.0;
                                                                                                    for (int i = 0; i < observed.length; i++) {
                                                                                                        double dev = observed[i] - expected[i];
                                                                                                        expectedSumSq += dev * dev / expected[i];
                                                                                                    }
                                                                                                    
                                                                                                    // Call method and assert
                                                                                                    double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                    
                                                                                                    // Original should match non-rescaled calculation
                                                                                                    // Mutant will use rescaling and produce different result
                                                                                                    assertEquals("Should not rescale when sums are equal", 
                                                                                                                 expectedSumSq, result, 1E-10);
                                                                                                    
                                                                                                    // Additional check to verify rescaling didn't happen
                                                                                                    // For original code, ratio should remain 1.0 (no rescale)
                                                                                                    // We can't directly check ratio, but we know correct sumSq should be 0
                                                                                                    // since all observed match expected exactly
                                                                                                    assertEquals(0.0, result, 1E-10);
                                                                                                }

    @Test
                                                                                            public void testChiSquareDetectsSumMismatch() {
                                                                                                // Create a new instance of the test class
                                                                                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                
                                                                                                // Create a 2x2 contingency table where row/column sums don't match totals
                                                                                                // This would normally be caught by the sum check that was mutated
                                                                                                long[][] counts = new long[][] {
                                                                                                    {10, 20},  // row sum = 30
                                                                                                    {30, 40}   // row sum = 70
                                                                                                };              // total should be 100, but calculations would be off
                                                                                                
                                                                                                try {
                                                                                                    // In the original code, this should throw an exception due to sum mismatch
                                                                                                    // The mutant would proceed with calculation despite the invalid input
                                                                                                    double result = chiSquareTest.chiSquare(counts);
                                                                                                    
                                                                                                    // If we reach this point (mutant case), force test failure
                                                                                                    fail("Mutant detected: Method should have thrown exception for sum mismatch but returned " + result);
                                                                                                } catch (IllegalArgumentException e) {
                                                                                                    // Expected behavior - test passes if exception is thrown
                                                                                                }
                                                                                            }

    @Test
                                                                                            public void testChiSquareValidInput() {
                                                                                                // Create instance of ChiSquareTestImpl
                                                                                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                
                                                                                                // Valid 2x2 contingency table where sums match
                                                                                                long[][] counts = new long[][] {
                                                                                                    {10, 20},  // row sum = 30
                                                                                                    {20, 30}   // row sum = 50
                                                                                                };              // total = 80, all calculations valid
                                                                                                
                                                                                                double result = chiSquareTest.chiSquare(counts);
                                                                                                
                                                                                                // Verify we get a valid chi-square value > 0
                                                                                                assertTrue("Result should be positive", result > 0);
                                                                                            }

    @Test
                                                                                        public void testChiSquareRescaleRatio() {
                                                                                            // Setup
                                                                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                            double[] expected = {10.0, 20.0, 30.0}; // sum = 60.0
                                                                                            long[] observed = {15L, 25L, 35L};       // sum = 75.0
                                                                                            // Difference (15.0) is > 10E-6, so rescaling will occur
                                                                                            
                                                                                            // Calculate expected value with correct ratio (75/60 = 1.25)
                                                                                            double correctRatio = 75.0 / 60.0;
                                                                                            double correctSumSq = 0.0;
                                                                                            for (int i = 0; i < observed.length; i++) {
                                                                                                double dev = observed[i] - correctRatio * expected[i];
                                                                                                correctSumSq += dev * dev / (correctRatio * expected[i]);
                                                                                            }
                                                                                            
                                                                                            // Calculate what mutated version would produce (ratio = 60/75 = 0.8)
                                                                                            double mutatedRatio = 60.0 / 75.0;
                                                                                            double mutatedSumSq = 0.0;
                                                                                            for (int i = 0; i < observed.length; i++) {
                                                                                                double dev = observed[i] - mutatedRatio * expected[i];
                                                                                                mutatedSumSq += dev * dev / (mutatedRatio * expected[i]);
                                                                                            }
                                                                                            
                                                                                            // Verify the actual result matches correct calculation, not mutated one
                                                                                            double actual = chiSquareTest.chiSquare(expected, observed);
                                                                                            assertEquals(correctSumSq, actual, 1E-10);
                                                                                            assertFalse(Math.abs(mutatedSumSq - actual) < 1E-10); // Ensure we're not getting mutated result
                                                                                        }

    @Test
                                                                                            public void testChiSquareDetectsRatioMutation() {
                                                                                                // Create a simple 2x2 contingency table
                                                                                                long[][] counts = {
                                                                                                    {10, 20},
                                                                                                    {30, 40}
                                                                                                };
                                                                                                
                                                                                                // Manually calculate expected values:
                                                                                                // Row sums: 30, 70
                                                                                                // Column sums: 40, 60
                                                                                                // Total: 100
                                                                                                // Expected values:
                                                                                                // [0][0]: (30*40)/100 = 12
                                                                                                // [0][1]: (30*60)/100 = 18
                                                                                                // [1][0]: (70*40)/100 = 28
                                                                                                // [1][1]: (70*60)/100 = 42
                                                                                                
                                                                                                // Calculate chi-square manually:
                                                                                                double expectedChiSquare = 
                                                                                                    Math.pow(10-12, 2)/12 + 
                                                                                                    Math.pow(20-18, 2)/18 + 
                                                                                                    Math.pow(30-28, 2)/28 + 
                                                                                                    Math.pow(40-42, 2)/42;
                                                                                                
                                                                                                // Create test instance
                                                                                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                
                                                                                                // Call method and assert
                                                                                                double actualChiSquare = chiSquareTest.chiSquare(counts);
                                                                                                assertEquals("Chi-square value should match expected calculation", 
                                                                                                            expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                
                                                                                                // The mutant would calculate wrong expected values (e.g., 100/(30*40) instead of (30*40)/100)
                                                                                                // leading to a different chi-square value that this test would catch
                                                                                            }

    @Test
                                                                                    public void testChiSquareRescalingDetectsDivisionMutation() {
                                                                                        // Setup
                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                        double[] expected = {10.0, 20.0, 30.0}; // Sum = 60
                                                                                        long[] observed = {15L, 25L, 35L};      // Sum = 75 (will trigger rescaling)
                                                                                        
                                                                                        // Expected ratio should be 75/60 = 1.25
                                                                                        // Mutant will use 75*60 = 4500 instead
                                                                                        
                                                                                        // Manually calculate expected chi-square value with correct ratio
                                                                                        double manualSumSq = 0.0;
                                                                                        double correctRatio = 75.0/60.0;
                                                                                        for (int i = 0; i < observed.length; i++) {
                                                                                            double dev = observed[i] - correctRatio * expected[i];
                                                                                            manualSumSq += dev * dev / (correctRatio * expected[i]);
                                                                                        }
                                                                                        
                                                                                        // Calculate with method
                                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                                        
                                                                                        // Verify - should match manual calculation
                                                                                        assertEquals(manualSumSq, result, 1E-10);
                                                                                        
                                                                                        // Additional verification that mutant would fail:
                                                                                        // Calculate what mutant would produce
                                                                                        double mutantRatio = 75.0 * 60.0;
                                                                                        double mutantSumSq = 0.0;
                                                                                        for (int i = 0; i < observed.length; i++) {
                                                                                            double dev = observed[i] - mutantRatio * expected[i];
                                                                                            mutantSumSq += dev * dev / (mutantRatio * expected[i]);
                                                                                        }
                                                                                        // Ensure our correct result doesn't match mutant's calculation
                                                                                        assertFalse(Math.abs(mutantSumSq - result) < 1E-10);
                                                                                    }

    @Test
                                                                                        public void testChiSquareDetectsDivisionMutant() {
                                                                                            // Create a simple 2x2 contingency table
                                                                                            long[][] counts = {
                                                                                                {10, 20},
                                                                                                {30, 40}
                                                                                            };
                                                                                            
                                                                                            // Manually calculate expected chi-square value
                                                                                            // Row sums: 30, 70
                                                                                            // Column sums: 40, 60
                                                                                            // Total: 100
                                                                                            // Expected values:
                                                                                            // [0][0]: (30*40)/100 = 12
                                                                                            // [0][1]: (30*60)/100 = 18
                                                                                            // [1][0]: (70*40)/100 = 28
                                                                                            // [1][1]: (70*60)/100 = 42
                                                                                            // Chi-square components:
                                                                                            // (10-12)^2/12 = 0.333
                                                                                            // (20-18)^2/18 = 0.222
                                                                                            // (30-28)^2/28 = 0.143
                                                                                            // (40-42)^2/42 = 0.095
                                                                                            // Total expected chi-square: ~0.793
                                                                                            
                                                                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                            double result = chiSquareTest.chiSquare(counts);
                                                                                            
                                                                                            // Assert with delta for floating point precision
                                                                                            assertEquals(0.793, result, 0.001);
                                                                                            
                                                                                            // The mutant would calculate:
                                                                                            // Expected values would be multiplied instead:
                                                                                            // [0][0]: 30*40 = 1200
                                                                                            // Which would lead to completely different chi-square components
                                                                                            // The assertion would fail for the mutant
                                                                                        }

    @Test
                                                                                public void testChiSquareDevInitialization() {
                                                                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                    
                                                                                    // Test case where observed exactly matches expected (should return 0)
                                                                                    double[] expected1 = {10.0, 20.0, 30.0};
                                                                                    long[] observed1 = {10L, 20L, 30L};
                                                                                    double result1 = chiSquareTest.chiSquare(expected1, observed1);
                                                                                    assertEquals(0.0, result1, 1e-10);  // Should be exactly 0
                                                                                    
                                                                                    // Test case with small deviations
                                                                                    double[] expected2 = {10.0, 20.0, 30.0};
                                                                                    long[] observed2 = {11L, 19L, 30L};
                                                                                    double result2 = chiSquareTest.chiSquare(expected2, observed2);
                                                                                    
                                                                                    // Calculate expected value manually
                                                                                    double expectedResult = 
                                                                                        Math.pow(11 - 10, 2)/10.0 + 
                                                                                        Math.pow(19 - 20, 2)/20.0 + 
                                                                                        Math.pow(30 - 30, 2)/30.0;
                                                                                    
                                                                                    assertEquals(expectedResult, result2, 1e-10);
                                                                                    
                                                                                    // Test case where rescaling is needed
                                                                                    double[] expected3 = {10.0, 20.0, 30.0};
                                                                                    long[] observed3 = {11L, 22L, 33L};  // Sums differ
                                                                                    double result3 = chiSquareTest.chiSquare(expected3, observed3);
                                                                                    
                                                                                    // Calculate expected value with rescaling
                                                                                    double ratio = 66.0/60.0;
                                                                                    double expectedResult3 = 
                                                                                        Math.pow(11 - ratio*10, 2)/(ratio*10) + 
                                                                                        Math.pow(22 - ratio*20, 2)/(ratio*20) + 
                                                                                        Math.pow(33 - ratio*30, 2)/(ratio*30);
                                                                                    
                                                                                    assertEquals(expectedResult3, result3, 1e-10);
                                                                                }

    @Test
                                                                                    public void testChiSquareWithSimpleContingencyTable() {
                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                        
                                                                                        // Simple 2x2 contingency table where we can manually compute expected value
                                                                                        long[][] counts = {
                                                                                            {10, 10},
                                                                                            {20, 20}
                                                                                        };
                                                                                        
                                                                                        // Manual calculation:
                                                                                        // Row sums: 20, 40
                                                                                        // Col sums: 30, 30
                                                                                        // Total: 60
                                                                                        // Expected values:
                                                                                        // (20*30)/60 = 10, (20*30)/60 = 10
                                                                                        // (40*30)/60 = 20, (40*30)/60 = 20
                                                                                        // Chi-square components:
                                                                                        // (10-10)²/10 + (10-10)²/10 + (20-20)²/20 + (20-20)²/20 = 0
                                                                                        
                                                                                        double expected = 0.0;
                                                                                        double actual = chiSquareTest.chiSquare(counts);
                                                                                        
                                                                                        // This will fail if sumSq was initialized to 1.0 instead of 0.0
                                                                                        assertEquals("Chi-square value should be exactly 0 for perfect fit", 
                                                                                                    expected, actual, 0.0001);
                                                                                    }

    @Test
                                                                                    public void testChiSquareWithNonZeroResult() {
                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                        
                                                                                        // 2x2 table that should produce known non-zero chi-square
                                                                                        long[][] counts = {
                                                                                            {5, 15},
                                                                                            {20, 10}
                                                                                        };
                                                                                        
                                                                                        // Manual calculation:
                                                                                        // Row sums: 20, 30
                                                                                        // Col sums: 25, 25
                                                                                        // Total: 50
                                                                                        // Expected values:
                                                                                        // (20*25)/50 = 10, (20*25)/50 = 10
                                                                                        // (30*25)/50 = 15, (30*25)/50 = 15
                                                                                        // Chi-square components:
                                                                                        // (5-10)²/10 + (15-10)²/10 + (20-15)²/15 + (10-15)²/15 ≈ 8.333
                                                                                        
                                                                                        double expected = 8.333333333333334;
                                                                                        double actual = chiSquareTest.chiSquare(counts);
                                                                                        
                                                                                        // This will fail if sumSq was initialized to 1.0 (would get 9.333)
                                                                                        assertEquals("Chi-square value should match manual calculation", 
                                                                                                    expected, actual, 0.0001);
                                                                                    }

    @Test
                                                                            public void testChiSquareSummationIncludesFirstElement() {
                                                                                // Setup
                                                                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                double[] expected = new double[]{1.0, 2.0}; // First element is non-zero
                                                                                long[] observed = new long[]{1L, 2L};       // First element is non-zero
                                                                                
                                                                                // Expected behavior: sums should be 3.0 (1.0 + 2.0)
                                                                                // Mutant behavior: sums will be 2.0 (skips first element)
                                                                                
                                                                                // Action
                                                                                double result = chiSquareTest.chiSquare(expected, observed);
                                                                                
                                                                                // Verification - the actual value isn't important for this test,
                                                                                // we just need to ensure the sums are calculated correctly
                                                                                // We can verify this by checking the result isn't what we'd get if first element was skipped
                                                                                
                                                                                // Expected result when processing all elements:
                                                                                // ratio = 1.0 (sums are equal)
                                                                                // sumSq = (1-1)²/1 + (2-2)²/2 = 0 + 0 = 0
                                                                                double expectedResult = 0.0;
                                                                                
                                                                                // If first element was skipped:
                                                                                // sumExpected = 2.0, sumObserved = 2.0
                                                                                // ratio = 1.0
                                                                                // sumSq = (2-2)²/2 = 0
                                                                                // In this simple case, the mutant would coincidentally give same result,
                                                                                // so we need a case where skipping first element affects the result
                                                                                
                                                                                // Better test case where skipping first element matters:
                                                                                expected = new double[]{2.0, 1.0}; // Different first element
                                                                                observed = new long[]{3L, 1L};
                                                                                
                                                                                // Original behavior:
                                                                                // sumExpected = 3.0, sumObserved = 4.0
                                                                                // ratio = 4.0/3.0
                                                                                // sumSq = (3-4/3*2)²/(4/3*2) + (1-4/3*1)²/(4/3*1) ≈ [calculate proper expected value]
                                                                                
                                                                                // Mutant behavior:
                                                                                // sumExpected = 1.0, sumObserved = 1.0
                                                                                // ratio = 1.0
                                                                                // sumSq = (1-1)²/1 = 0
                                                                                
                                                                                result = chiSquareTest.chiSquare(expected, observed);
                                                                                
                                                                                // Verify result is not what mutant would produce (0.0)
                                                                                assertNotEquals(0.0, result, 1e-10);
                                                                                
                                                                                // More precise verification:
                                                                                // Calculate expected value manually
                                                                                double manualSumExpected = 2.0 + 1.0;
                                                                                double manualSumObserved = 3.0 + 1.0;
                                                                                double manualRatio = manualSumObserved / manualSumExpected;
                                                                                double manualSumSq = Math.pow(3.0 - manualRatio*2.0, 2) / (manualRatio*2.0) +
                                                                                                    Math.pow(1.0 - manualRatio*1.0, 2) / (manualRatio*1.0);
                                                                                
                                                                                assertEquals(manualSumSq, result, 1e-10);
                                                                            }

    @Test
                                                                            public void testChiSquareDetectsFirstRowMutation() {
                                                                                // Create test data where first row contributes significantly
                                                                                long[][] counts = new long[][] {
                                                                                    {10, 20},  // First row - should be included
                                                                                    {30, 40}   // Second row
                                                                                };
                                                                                
                                                                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                
                                                                                // Manually calculate expected chi-square value including first row
                                                                                // Row sums: 30, 70
                                                                                // Column sums: 40, 60
                                                                                // Total: 100
                                                                                // Expected values:
                                                                                // (30*40)/100 = 12, (30*60)/100 = 18
                                                                                // (70*40)/100 = 28, (70*60)/100 = 42
                                                                                // Chi-square contributions:
                                                                                // (10-12)^2/12 = 0.333, (20-18)^2/18 = 0.222
                                                                                // (30-28)^2/28 = 0.143, (40-42)^2/42 = 0.095
                                                                                // Total expected chi-square: 0.333 + 0.222 + 0.143 + 0.095 ≈ 0.793
                                                                                
                                                                                double result = chiSquareTest.chiSquare(counts);
                                                                                
                                                                                // Assert with delta for floating point precision
                                                                                assertEquals(0.793, result, 0.001);
                                                                                
                                                                                // Additional check: verify first row is included by checking result is not zero
                                                                                assertTrue(result > 0.7);
                                                                                
                                                                                // This test will fail if the mutant skips the first row, 
                                                                                // as the result would be much smaller (only second row contributions)
                                                                            }

    @Test
                                                                        public void testChiSquareRescalingBehavior1() {
                                                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                            
                                                                            // Test case where rescaling should NOT occur (sums are equal)
                                                                            double[] expected = {10.0, 20.0, 30.0};
                                                                            long[] observed = {10L, 20L, 30L};
                                                                            
                                                                            // Calculate expected result without rescaling
                                                                            double expectedSumSq = 0.0;
                                                                            for (int i = 0; i < observed.length; i++) {
                                                                                double dev = observed[i] - expected[i];
                                                                                expectedSumSq += dev * dev / expected[i];
                                                                            }
                                                                            
                                                                            // Call the method and get actual result
                                                                            double actualSumSq = chiSquareTest.chiSquare(expected, observed);
                                                                            
                                                                            // Verify the result matches non-rescaled calculation
                                                                            assertEquals("Chi-square calculation should not use rescaling when sums are equal", 
                                                                                        expectedSumSq, actualSumSq, 1E-10);
                                                                            
                                                                            // The mutant would incorrectly use rescaling here, producing a different result
                                                                            // This assertion will fail for the mutant but pass for original code
                                                                        }

    @Test
                                                                        public void testChiSquareRescaleMutant() {
                                                                            // Create test data where rescaling would affect the result
                                                                            long[][] counts = {
                                                                                {10, 20, 30},
                                                                                {20, 10, 20}
                                                                            };
                                                                            
                                                                            // Create instance of the class under test
                                                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                            
                                                                            // Calculate expected result without rescaling (original behavior)
                                                                            // Since we can't access the original implementation, we'll use a known good value
                                                                            // For this specific input, the correct chi-square value should be approximately 6.349206
                                                                            double expectedChiSquare = 6.349206;
                                                                            
                                                                            // Calculate actual result (with mutant forcing rescale)
                                                                            double actualChiSquare = chiSquareTest.chiSquare(counts);
                                                                            
                                                                            // Assert that the result differs from expected (due to forced rescaling)
                                                                            // Using delta of 0.0001 for floating point comparison
                                                                            assertNotEquals("Mutant should be detected as it forces rescaling", 
                                                                                           expectedChiSquare, actualChiSquare, 0.0001);
                                                                            
                                                                            // Additional assertion to verify the mutant's behavior is actually different
                                                                            // We know rescaling would typically increase the chi-square value
                                                                            assertTrue("Mutant should produce larger value due to forced rescaling",
                                                                                      actualChiSquare > expectedChiSquare);
                                                                        }

    @Test
                                                                    public void testChiSquareRescaledCalculationDetectsSubtractionMutant() {
                                                                        // Setup
                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                        double[] expected = {10.0, 20.0, 30.0}; // Sum = 60
                                                                        long[] observed = {15L, 25L, 20L};      // Sum = 60 (but individual values differ)
                                                                        
                                                                        // The ratio will be 1.0 (60/60), but we need to force rescale=true
                                                                        // So we'll modify one expected value slightly to create small difference
                                                                        expected[0] = 10.00001; // Now sumExpected ≈ 60.00001
                                                                        
                                                                        // Calculate expected value manually
                                                                        double ratio = 60.0 / 60.00001;
                                                                        double expectedValue = 0.0;
                                                                        for (int i = 0; i < observed.length; i++) {
                                                                            double dev = observed[i] - ratio * expected[i];
                                                                            expectedValue += dev * dev / (ratio * expected[i]);
                                                                        }
                                                                        
                                                                        // Execute and verify
                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                        
                                                                        // The mutant would calculate using addition instead of subtraction,
                                                                        // so the result would be completely different
                                                                        assertEquals(expectedValue, result, 1E-10);
                                                                        
                                                                        // Additional verification with different values where observed < expected
                                                                        double[] expected2 = {10.0, 20.0, 30.0};
                                                                        long[] observed2 = {5L, 15L, 20L}; // One value below expected
                                                                        double ratio2 = 40.0 / 60.0;
                                                                        double expectedValue2 = 0.0;
                                                                        for (int i = 0; i < observed2.length; i++) {
                                                                            double dev = observed2[i] - ratio2 * expected2[i];
                                                                            expectedValue2 += dev * dev / (ratio2 * expected2[i]);
                                                                        }
                                                                        double result2 = chiSquareTest.chiSquare(expected2, observed2);
                                                                        assertEquals(expectedValue2, result2, 1E-10);
                                                                    }

    @Test
                                                                    public void testChiSquareDetectsSignChangeMutant() {
                                                                        // Setup - create a simple 2x2 contingency table
                                                                        long[][] counts = {
                                                                            {10, 20},
                                                                            {30, 40}
                                                                        };
                                                                        
                                                                        // Expected chi-square value calculated manually
                                                                        // For the given table:
                                                                        // Row sums: 30, 70
                                                                        // Column sums: 40, 60
                                                                        // Total: 100
                                                                        // Expected values:
                                                                        // [12, 18]
                                                                        // [28, 42]
                                                                        // Chi-square calculation:
                                                                        // (10-12)²/12 + (20-18)²/18 + (30-28)²/28 + (40-42)²/42 ≈ 0.7937
                                                                        
                                                                        double expectedChiSquare = 0.7936507936507936;
                                                                        double delta = 0.0000001; // tolerance for floating point comparison
                                                                        
                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                        double actualChiSquare = chiSquareTest.chiSquare(counts);
                                                                        
                                                                        // The mutant would calculate deviations as (observed + expected) instead of (observed - expected)
                                                                        // This would give completely wrong results like:
                                                                        // (10+12)²/12 + (20+18)²/18 + (30+28)²/28 + (40+42)²/42 ≈ 240.7937
                                                                        // So any reasonable test case should detect this
                                                                        
                                                                        assertEquals("Chi-square calculation should match expected value", 
                                                                                    expectedChiSquare, actualChiSquare, delta);
                                                                    }

    @Test
                                                                public void testChiSquareWithRescalingDetectsMutant() {
                                                                    // Setup
                                                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                    double[] expected = {10.0, 20.0, 30.0};  // Sum = 60
                                                                    long[] observed = {15L, 25L, 35L};       // Sum = 75 (different from expected)
                                                                    
                                                                    // This will force rescaling with ratio = 75/60 = 1.25
                                                                    // For first element:
                                                                    // Original: dev = 15 - 1.25*10 = 2.5
                                                                    // Mutant: dev = 15 - 10 = 5 (wrong)
                                                                    
                                                                    // Execute
                                                                    double result = chiSquareTest.chiSquare(expected, observed);
                                                                    
                                                                    // Verify - calculated expected value manually
                                                                    double ratio = 75.0/60.0;
                                                                    double expectedChiSquare = 0.0;
                                                                    expectedChiSquare += Math.pow(15 - ratio*10, 2) / (ratio*10);
                                                                    expectedChiSquare += Math.pow(25 - ratio*20, 2) / (ratio*20);
                                                                    expectedChiSquare += Math.pow(35 - ratio*30, 2) / (ratio*30);
                                                                    
                                                                    assertEquals("Chi-square value should match expected calculation", 
                                                                                expectedChiSquare, result, 1E-10);
                                                                }

    @Test
                                                                public void testChiSquareDetectsRatioMutation1() {
                                                                    // Setup - create a simple 2x2 contingency table
                                                                    long[][] counts = {{10, 20}, {30, 40}};
                                                                    
                                                                    // Expected chi-square value calculated manually with correct formula
                                                                    double expectedChiSquare = 0.4466; // rounded to 4 decimal places
                                                                    
                                                                    // Create test instance
                                                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                    
                                                                    // Calculate actual chi-square
                                                                    double actualChiSquare = chiSquareTest.chiSquare(counts);
                                                                    
                                                                    // Assert with delta to account for floating point precision
                                                                    assertEquals("Chi-square value should match expected calculation", 
                                                                                expectedChiSquare, actualChiSquare, 0.0001);
                                                                    
                                                                    // Additional assertion to ensure the value isn't inflated (which the mutant would do)
                                                                    assertTrue("Chi-square value should not be significantly larger than expected",
                                                                               actualChiSquare < expectedChiSquare * 1.1);
                                                                }

    @Test
                                                            public void testChiSquareRescaleAccumulation() {
                                                                // Setup
                                                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                double[] expected = {10.0, 20.0, 30.0}; // 3 elements to ensure accumulation
                                                                long[] observed = {12L, 18L, 35L}; // Different sums to trigger rescaling
                                                                
                                                                // Expected calculation:
                                                                // sumExpected = 10+20+30 = 60
                                                                // sumObserved = 12+18+35 = 65
                                                                // ratio = 65/60 ≈ 1.083333
                                                                // For each element:
                                                                // 1: (12 - 1.083333*10)^2/(1.083333*10) ≈ 0.076923
                                                                // 2: (18 - 1.083333*20)^2/(1.083333*20) ≈ 0.230769
                                                                // 3: (35 - 1.083333*30)^2/(1.083333*30) ≈ 0.769231
                                                                // Total sumSq ≈ 0.076923 + 0.230769 + 0.769231 ≈ 1.076923
                                                                
                                                                // Action
                                                                double result = chiSquareTest.chiSquare(expected, observed);
                                                                
                                                                // Assertion
                                                                assertEquals(1.076923, result, 0.0001); // Allowing small floating point difference
                                                                
                                                                // This test will fail with the mutant because:
                                                                // - Mutant will only keep last element's value (≈0.769231)
                                                                // - Original accumulates all values (≈1.076923)
                                                                // Difference is large enough to detect with this precision
                                                            }

    @Test
                                                                public void testChiSquareAccumulatesAllCells() {
                                                                    // Create a 2x2 contingency table where all cells contribute to chi-square
                                                                    long[][] counts = new long[][] {
                                                                        {10, 20},
                                                                        {30, 40}
                                                                    };
                                                                    
                                                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                    double result = chiSquareTest.chiSquare(counts);
                                                                    
                                                                    // Calculate expected value manually
                                                                    double total = 10 + 20 + 30 + 40;
                                                                    double[] rowSum = {10 + 20, 30 + 40};
                                                                    double[] colSum = {10 + 30, 20 + 40};
                                                                    
                                                                    double expected = 0.0;
                                                                    for (int row = 0; row < 2; row++) {
                                                                        for (int col = 0; col < 2; col++) {
                                                                            double e = (rowSum[row] * colSum[col]) / total;
                                                                            double diff = counts[row][col] - e;
                                                                            expected += (diff * diff) / e;
                                                                        }
                                                                    }
                                                                    
                                                                    // Verify the result matches the manually calculated expected value
                                                                    assertEquals(expected, result, 1e-10);
                                                                    
                                                                    // Additional check: verify result is not just the last cell's contribution
                                                                    double lastCellExpected = (rowSum[1] * colSum[1]) / total;
                                                                    double lastCellDiff = counts[1][1] - lastCellExpected;
                                                                    double lastCellContribution = (lastCellDiff * lastCellDiff) / lastCellExpected;
                                                                    assertTrue(result > lastCellContribution); // This will fail for the mutant
                                                                }

    @Test
                                                        public void testChiSquareWithRescalingDetectsSquaredDeviationMutant() {
                                                            // Setup
                                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                            double[] expected = {10.0, 20.0, 30.0};  // Sum = 60
                                                            long[] observed = {15L, 25L, 35L};       // Sum = 75 (will trigger rescaling)
                                                            
                                                            // Expected calculation:
                                                            // ratio = 75/60 = 1.25
                                                            // For first element:
                                                            // dev = 15 - 1.25*10 = 2.5
                                                            // correct term = (2.5)^2 / (1.25*10) = 6.25 / 12.5 = 0.5
                                                            // Similar calculations for other elements would give total sumSq
                                                            
                                                            // Calculate expected value (manually computed)
                                                            double expectedSumSq = 0.0;
                                                            double ratio = 75.0 / 60.0;
                                                            double[] devTerms = {
                                                                Math.pow(15 - ratio*10, 2) / (ratio*10),
                                                                Math.pow(25 - ratio*20, 2) / (ratio*20),
                                                                Math.pow(35 - ratio*30, 2) / (ratio*30)
                                                            };
                                                            for (double term : devTerms) {
                                                                expectedSumSq += term;
                                                            }
                                                            
                                                            // Execute
                                                            double actualSumSq = chiSquareTest.chiSquare(expected, observed);
                                                            
                                                            // Verify
                                                            assertEquals("Chi-square calculation with rescaling is incorrect", 
                                                                        expectedSumSq, actualSumSq, 1E-10);
                                                            
                                                            // This will fail on the mutant because:
                                                            // Mutant would calculate terms as (dev)/(ratio*expected[i]) 
                                                            // instead of (dev^2)/(ratio*expected[i])
                                                            // Resulting in completely different sumSq value
                                                        }

    @Test
                                                        public void testChiSquareDetectsSquaredDeviationMutation() {
                                                            // Create a simple 2x2 contingency table where observed != expected
                                                            long[][] counts = {
                                                                {10, 20},
                                                                {30, 40}
                                                            };
                                                            
                                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                            double result = chiSquareTest.chiSquare(counts);
                                                            
                                                            // Manually calculate expected chi-square value
                                                            // Row sums: 30, 70
                                                            // Column sums: 40, 60
                                                            // Total: 100
                                                            // Expected values:
                                                            // [0][0]: (30*40)/100 = 12
                                                            // [0][1]: (30*60)/100 = 18
                                                            // [1][0]: (70*40)/100 = 28
                                                            // [1][1]: (70*60)/100 = 42
                                                            // Chi-square components:
                                                            // (10-12)^2/12 = 0.333
                                                            // (20-18)^2/18 = 0.222
                                                            // (30-28)^2/28 = 0.143
                                                            // (40-42)^2/42 = 0.095
                                                            // Total expected chi-square: ~0.793
                                                            
                                                            // The mutant would calculate:
                                                            // (10-12)/12 = -0.167
                                                            // (20-18)/18 = 0.111
                                                            // (30-28)/28 = 0.071
                                                            // (40-42)/42 = -0.048
                                                            // Total mutant result: ~-0.033
                                                            
                                                            // Assert the correct squared calculation
                                                            assertEquals(0.793, result, 0.001);
                                                            
                                                            // The mutant would fail this assertion as it would return ~-0.033
                                                        }

    @Test
                                                    public void testChiSquareWithEqualSumsShouldNotUseRatio() {
                                                        // Setup - create inputs where sumExpected == sumObserved
                                                        double[] expected = new double[]{10.0, 20.0, 30.0}; // sum = 60.0
                                                        long[] observed = new long[]{10L, 20L, 30L};       // sum = 60.0
                                                        
                                                        // Create test instance
                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                        
                                                        // Calculate expected value manually
                                                        double expectedSumSq = 0.0;
                                                        for (int i = 0; i < observed.length; i++) {
                                                            double dev = observed[i] - expected[i];  // Correct calculation
                                                            expectedSumSq += dev * dev / expected[i];
                                                        }
                                                        
                                                        // Call method and assert
                                                        double actualSumSq = chiSquareTest.chiSquare(expected, observed);
                                                        
                                                        // This will fail on the mutant because it will multiply by ratio (1.0)
                                                        // even though rescale=false
                                                        assertEquals(expectedSumSq, actualSumSq, 1e-10);
                                                        
                                                        // Additional check - verify ratio multiplication would give different result
                                                        double mutatedSumSq = 0.0;
                                                        for (int i = 0; i < observed.length; i++) {
                                                            double dev = observed[i] - 1.0 * expected[i];  // Mutated calculation
                                                            mutatedSumSq += dev * dev / expected[i];
                                                        }
                                                        // This assertion confirms our test would catch the mutant
                                                        assertNotEquals(mutatedSumSq, actualSumSq, 1e-10);
                                                    }

    @Test
                                                        public void testChiSquareDetectsMutant() {
                                                            // Create a simple 2x2 contingency table
                                                            long[][] counts = {
                                                                {10, 20},
                                                                {30, 40}
                                                            };
                                                            
                                                            // Expected chi-square value calculated manually
                                                            double expectedChiSquare = 2.2222222222222223;
                                                            
                                                            // Create test instance
                                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                            
                                                            // Calculate actual chi-square
                                                            double actualChiSquare = chiSquareTest.chiSquare(counts);
                                                            
                                                            // Verify the result matches expected value with delta for floating point precision
                                                            assertEquals("Chi-square value should match expected calculation", 
                                                                        expectedChiSquare, 
                                                                        actualChiSquare, 
                                                                        0.000001);
                                                            
                                                            // The mutant would produce a different value due to the ratio scaling
                                                            // This assertion will fail if the mutant is present
                                                        }

    @Test
                                                public void testChiSquareNonRescaledCaseDetectsSubtractionMutant() {
                                                    // Setup - create inputs where sums are equal (rescale=false)
                                                    double[] expected = {10.0, 20.0, 30.0};
                                                    long[] observed = {10L, 20L, 30L};
                                                    
                                                    // Create test instance
                                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                    
                                                    // Calculate expected value manually
                                                    double manualSumSq = 0.0;
                                                    for (int i = 0; i < observed.length; i++) {
                                                        double dev = observed[i] - expected[i];
                                                        manualSumSq += dev * dev / expected[i];
                                                    }
                                                    
                                                    // Call method and get result
                                                    double result = chiSquareTest.chiSquare(expected, observed);
                                                    
                                                    // Assertions
                                                    // 1. Result should equal manually calculated value
                                                    assertEquals(manualSumSq, result, 1E-10);
                                                    // 2. Result should be positive (would fail with mutant)
                                                    assertTrue(result >= 0.0);
                                                    // 3. Specific value check (would fail with mutant)
                                                    assertEquals(0.0, result, 1E-10);
                                                }

    @Test
                                                public void testChiSquarePositiveResultDetectsSubtractionMutant() {
                                                    // Setup
                                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                    long[][] counts = new long[][] {
                                                        {10, 20},
                                                        {30, 40}
                                                    };
                                                    
                                                    // Expected value calculated manually:
                                                    // Row sums: 30, 70
                                                    // Column sums: 40, 60
                                                    // Total: 100
                                                    // Expected values:
                                                    // [0][0]: (30*40)/100 = 12
                                                    // [0][1]: (30*60)/100 = 18
                                                    // [1][0]: (70*40)/100 = 28
                                                    // [1][1]: (70*60)/100 = 42
                                                    // Chi-square components:
                                                    // (10-12)²/12 = 0.333
                                                    // (20-18)²/18 = 0.222
                                                    // (30-28)²/28 = 0.143
                                                    // (40-42)²/42 = 0.095
                                                    // Total expected chi-square: ~0.793
                                                    
                                                    // Execute
                                                    double result = chiSquareTest.chiSquare(counts);
                                                    
                                                    // Verify
                                                    // Original code should give positive value ~0.793
                                                    // Mutant would give negative value ~-0.793
                                                    assertTrue("Chi-square result must be positive", result > 0);
                                                    assertEquals(0.793, result, 0.001);
                                                    
                                                    // Additional check to ensure the value is in valid chi-square range
                                                    assertTrue(result < 100); // Reasonable upper bound for this input
                                                }

    @Test
                                            public void testChiSquareNonRescaledCaseDetectsSumMutation() {
                                                // Setup
                                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                double[] expected = new double[]{10.0, 20.0, 30.0}; // Sum = 60
                                                long[] observed = new long[]{10, 20, 30}; // Sum = 60 (no rescaling needed)
                                                
                                                // Calculate expected result manually
                                                double term1 = Math.pow(10 - 10, 2) / 10.0;
                                                double term2 = Math.pow(20 - 20, 2) / 20.0;
                                                double term3 = Math.pow(30 - 30, 2) / 30.0;
                                                double expectedSum = term1 + term2 + term3;
                                                
                                                // Execute
                                                double result = chiSquareTest.chiSquare(expected, observed);
                                                
                                                // Verify
                                                assertEquals("Chi-square sum should accumulate all terms", 
                                                            expectedSum, result, 1E-10);
                                                
                                                // Additional verification that we're testing the non-rescaled case
                                                double sumExpected = 10.0 + 20.0 + 30.0;
                                                double sumObserved = 10 + 20 + 30;
                                                assertTrue("Test should use non-rescaled case", 
                                                          Math.abs(sumExpected - sumObserved) <= 10E-6);
                                            }

    @Test
                                                public void testChiSquareDetectsAccumulationMutation() {
                                                    // Create a 2x2 contingency table where all cells have different values
                                                    long[][] counts = {
                                                        {10, 20},
                                                        {30, 40}
                                                    };
                                                    
                                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                    double result = chiSquareTest.chiSquare(counts);
                                                    
                                                    // Calculate expected value manually
                                                    double total = 10 + 20 + 30 + 40;
                                                    double[] rowSum = {10 + 20, 30 + 40};
                                                    double[] colSum = {10 + 30, 20 + 40};
                                                    
                                                    double expectedSumSq = 0.0;
                                                    for (int row = 0; row < 2; row++) {
                                                        for (int col = 0; col < 2; col++) {
                                                            double expected = (rowSum[row] * colSum[col]) / total;
                                                            double dev = counts[row][col] - expected;
                                                            expectedSumSq += (dev * dev) / expected;
                                                        }
                                                    }
                                                    
                                                    // This assertion will fail if the mutation is present
                                                    // because the mutant would only use the last cell's value (40)
                                                    assertEquals(expectedSumSq, result, 1e-10);
                                                    
                                                    // Additional check - verify it's not just the last cell's contribution
                                                    double lastCellExpected = (rowSum[1] * colSum[1]) / total;
                                                    double lastCellDev = counts[1][1] - lastCellExpected;
                                                    double lastCellContribution = (lastCellDev * lastCellDev) / lastCellExpected;
                                                    assertTrue(result > lastCellContribution); // Should be sum of all contributions
                                                }

    @Test
                                        public void testChiSquareWithoutRescaling() {
                                            // Setup
                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                            double[] expected = new double[]{10.0, 10.0, 10.0}; // Sum = 30
                                            long[] observed = new long[]{12, 8, 10}; // Sum = 30, deviations: +2, -2, 0
                                            
                                            // Expected calculation:
                                            // For first item: (12-10)²/10 = 4/10 = 0.4
                                            // Second item: (8-10)²/10 = 4/10 = 0.4
                                            // Third item: (10-10)²/10 = 0
                                            // Total expected: 0.4 + 0.4 + 0 = 0.8
                                            
                                            // Mutant would calculate:
                                            // (12-10)/10 + (8-10)/10 + (10-10)/10 = 0.2 + (-0.2) + 0 = 0
                                            
                                            // Execute
                                            double result = chiSquareTest.chiSquare(expected, observed);
                                            
                                            // Verify
                                            assertEquals(0.8, result, 1e-10); // Should fail on mutant (would get 0)
                                        }

    @Test
                                        public void testChiSquareDetectsSquaredTermMutation() {
                                            // Create a simple 2x2 contingency table where observed != expected
                                            long[][] counts = {
                                                {10, 20},
                                                {30, 40}
                                            };
                                            
                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                            
                                            // Calculate actual result
                                            double result = chiSquareTest.chiSquare(counts);
                                            
                                            // Manually calculate expected chi-square value with proper squaring
                                            double expected = 0.0;
                                            double total = 10 + 20 + 30 + 40;
                                            double[] rowSum = {10 + 20, 30 + 40};
                                            double[] colSum = {10 + 30, 20 + 40};
                                            
                                            for (int row = 0; row < 2; row++) {
                                                for (int col = 0; col < 2; col++) {
                                                    double e = (rowSum[row] * colSum[col]) / total;
                                                    double dev = counts[row][col] - e;
                                                    expected += (dev * dev) / e;
                                                }
                                            }
                                            
                                            // Calculate what mutant would produce (without squaring)
                                            double mutantExpected = 0.0;
                                            for (int row = 0; row < 2; row++) {
                                                for (int col = 0; col < 2; col++) {
                                                    double e = (rowSum[row] * colSum[col]) / total;
                                                    double dev = counts[row][col] - e;
                                                    mutantExpected += dev / e;
                                                }
                                            }
                                            
                                            // Verify result matches proper calculation (not mutant)
                                            assertEquals(expected, result, 1e-10);
                                            // Ensure the result is different from what mutant would produce
                                            assertNotEquals(mutantExpected, result, 1e-10);
                                        }

    @Test
                                    public void testChiSquareDetectsLastElementMutation() {
                                        // Setup
                                        ChiSquareTestImpl chiSquare = new ChiSquareTestImpl();
                                        double[] expected = new double[]{1.0, 2.0, 3.0};  // 3 elements
                                        long[] observed = new long[]{1, 2, 10};          // Last element differs significantly
                                        
                                        // Action
                                        double result = chiSquare.chiSquare(expected, observed);
                                        
                                        // Verification - calculate expected value manually
                                        double sumExpected = 1.0 + 2.0 + 3.0;
                                        double sumObserved = 1 + 2 + 10;
                                        double ratio = sumObserved / sumExpected;
                                        
                                        // Calculate what the correct sumSq should be including all elements
                                        double expectedSumSq = 0.0;
                                        for (int i = 0; i < observed.length; i++) {
                                            double dev = observed[i] - ratio * expected[i];
                                            expectedSumSq += dev * dev / (ratio * expected[i]);
                                        }
                                        
                                        // The mutant would skip the last element, so its result would be different
                                        assertEquals("Chi-square calculation should include all elements", 
                                                    expectedSumSq, result, 1E-10);
                                        
                                        // Additional check with different last element
                                        long[] observed2 = new long[]{1, 2, 20};  // Change only last element
                                        double result2 = chiSquare.chiSquare(expected, observed2);
                                        assertNotEquals("Changing last element should affect result", 
                                                       result, result2, 1E-10);
                                    }

    @Test
                                        public void testChiSquareDetectsMutantByCheckingLastElementContribution() {
                                            // Create a test instance
                                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                            
                                            // Create a 2x2 contingency table where the last element is significant
                                            long[][] counts = new long[][] {
                                                {10, 20},
                                                {30, 40}  // This is the last element that might be skipped by the mutant
                                            };
                                            
                                            // Calculate expected chi-square value manually
                                            // Row sums: 30, 70
                                            // Column sums: 40, 60
                                            // Total: 100
                                            // Expected values:
                                            // [0][0]: (30*40)/100 = 12
                                            // [0][1]: (30*60)/100 = 18
                                            // [1][0]: (70*40)/100 = 28
                                            // [1][1]: (70*60)/100 = 42
                                            // Chi-square contributions:
                                            // [0][0]: (10-12)²/12 = 0.333
                                            // [0][1]: (20-18)²/18 = 0.222
                                            // [1][0]: (30-28)²/28 = 0.143
                                            // [1][1]: (40-42)²/42 = 0.095
                                            // Total expected chi-square: ~0.333 + 0.222 + 0.143 + 0.095 = 0.793
                                            
                                            double result = chiSquareTest.chiSquare(counts);
                                            
                                            // Verify the result is approximately as expected (all elements contribute)
                                            assertEquals(0.793, result, 0.001);
                                            
                                            // Now test with modified last element to ensure it affects the result
                                            long[][] modifiedCounts = new long[][] {
                                                {10, 20},
                                                {30, 41}  // Changed last element
                                            };
                                            
                                            double modifiedResult = chiSquareTest.chiSquare(modifiedCounts);
                                            
                                            // The results should be different, proving the last element was included
                                            assertNotEquals(result, modifiedResult, 0.0001);
                                            
                                            // Additional test with single-row array to catch row loop mutation
                                            long[][] singleRowCounts = new long[][] {{5, 10, 15}};
                                            double singleRowResult = chiSquareTest.chiSquare(singleRowCounts);
                                            
                                            // Expected calculation for single row:
                                            // Row sums: 30
                                            // Column sums: 5, 10, 15
                                            // Total: 30
                                            // Expected values are equal to counts (perfect fit)
                                            // Chi-square should be 0
                                            assertEquals(0.0, singleRowResult, 0.0001);
                                        }

    @Test
                                public void testChiSquareRescalingDetectsRatioMutation() {
                                    // Setup
                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                    double[] expected = {10.0, 20.0, 30.0}; // sum = 60
                                    long[] observed = {15L, 25L, 35L};      // sum = 75 (different from expected)
                                    
                                    // Expected calculation:
                                    // Original ratio = 75/60 = 1.25
                                    // For each cell: (observed - ratio*expected)²/(ratio*expected)
                                    // Cell 0: (15 - 12.5)²/12.5 = 6.25/12.5 = 0.5
                                    // Cell 1: (25 - 25)²/25 = 0
                                    // Cell 2: (35 - 37.5)²/37.5 = 6.25/37.5 ≈ 0.166666
                                    // Total expected chi-square ≈ 0.5 + 0 + 0.166666 ≈ 0.666666
                                    
                                    // Mutated ratio would be 75+60=135, leading to completely wrong calculations
                                    
                                    // Execute
                                    double result = chiSquareTest.chiSquare(expected, observed);
                                    
                                    // Verify
                                    assertEquals(0.666666, result, 0.0001); // Allowing small delta for floating point
                                    
                                    // Additional verification that rescaling occurred
                                    assertNotEquals(1.0, result); // Simple check that result isn't trivial
                                }

    @Test
                                    public void testChiSquareDetectsRatioMutation2() {
                                        // Create a simple 2x2 contingency table
                                        long[][] counts = {
                                            {10, 20},
                                            {30, 40}
                                        };
                                        
                                        // Manually calculate expected chi-square value
                                        // Row sums: 30, 70
                                        // Column sums: 40, 60
                                        // Total: 100
                                        // Expected values:
                                        // [0][0]: (30*40)/100 = 12
                                        // [0][1]: (30*60)/100 = 18
                                        // [1][0]: (70*40)/100 = 28
                                        // [1][1]: (70*60)/100 = 42
                                        // Chi-square components:
                                        // (10-12)²/12 = 0.333
                                        // (20-18)²/18 = 0.222
                                        // (30-28)²/28 = 0.143
                                        // (40-42)²/42 = 0.095
                                        // Total expected chi-square: ~0.7937
                                        
                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                        double result = chiSquareTest.chiSquare(counts);
                                        
                                        // Verify with delta for floating point precision
                                        assertEquals(0.7937, result, 0.0001);
                                        
                                        // The mutant would calculate:
                                        // Expected values would be (rowSum + colSum) instead of (rowSum * colSum / total)
                                        // [0][0]: 30 + 40 = 70
                                        // [0][1]: 30 + 60 = 90
                                        // [1][0]: 70 + 40 = 110
                                        // [1][1]: 70 + 60 = 130
                                        // Chi-square components would be completely different
                                        // This would produce a result far from 0.7937, so the assertion would fail
                                    }

    @Test
                            public void testChiSquareWithRescalingDetectsRatioMutation1() {
                                // Setup
                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                double[] expected = {10.0, 20.0, 30.0};  // sum = 60
                                long[] observed = {15L, 25L, 35L};       // sum = 75 (different from expected)
                                
                                // Expected behavior (with division ratio):
                                // ratio = 75/60 = 1.25
                                // For first element: dev = (15 - 1.25*10) = 2.5
                                // contribution = 2.5²/(1.25*10) = 6.25/12.5 = 0.5
                                // Similar calculations for other elements...
                                // Expected total sumSq ≈ 0.5 + 0.2083 + 0.1389 ≈ 0.8472
                                
                                // Mutant behavior (with subtraction ratio):
                                // ratio = 75-60 = 15
                                // For first element: dev = (15 - 15*10) = -135
                                // contribution = (-135)²/(15*10) = 18225/150 = 121.5
                                // This will produce a completely different (and wrong) sumSq
                                
                                // Action
                                double result = chiSquareTest.chiSquare(expected, observed);
                                
                                // Assertion - verify correct calculation with division ratio
                                assertEquals(0.8472, result, 0.0001);
                                
                                // This assertion will fail with the mutant because:
                                // - The mutant's subtraction ratio produces much larger deviations
                                // - The resulting sumSq will be orders of magnitude larger
                                // - The delta (0.0001) is small enough to catch the difference
                            }

    @Test
                            public void testChiSquareDetectsDivisionMutant1() {
                                // Setup
                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                long[][] counts = {{10, 20}, {30, 40}}; // Simple 2x2 contingency table
                                
                                // Expected calculations:
                                // Row sums: 30, 70
                                // Column sums: 40, 60
                                // Total: 100
                                // Expected values:
                                // [0][0]: (30*40)/100 = 12
                                // [0][1]: (30*60)/100 = 18
                                // [1][0]: (70*40)/100 = 28
                                // [1][1]: (70*60)/100 = 42
                                // Chi-square components:
                                // (10-12)²/12 = 0.333
                                // (20-18)²/18 = 0.222
                                // (30-28)²/28 = 0.143
                                // (40-42)²/42 = 0.095
                                // Total expected chi-square: ~0.333 + 0.222 + 0.143 + 0.095 = 0.793
                                
                                // Action
                                double result = chiSquareTest.chiSquare(counts);
                                
                                // Assertion
                                // The mutant would calculate using subtraction instead of division, 
                                // resulting in completely different values (e.g., (10-12)²/(10-12) = 4/-2 = -2)
                                // So we expect the correct value to be approximately 0.793
                                assertEquals(0.793, result, 0.001);
                                
                                // Additional assertion to ensure it's not negative (which the mutant might produce)
                                assertTrue(result >= 0);
                            }

    @Test
                        public void testChiSquareWithRescalingDetectsSubtractionMutant() {
                            // Setup
                            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                            double[] expected = {10.0, 20.0, 30.0};  // Sum = 60
                            long[] observed = {15L, 25L, 35L};       // Sum = 75 (will trigger rescaling)
                            
                            // Calculate expected value manually
                            double ratio = 75.0 / 60.0;  // sumObserved / sumExpected
                            double expectedSumSq = 0.0;
                            for (int i = 0; i < observed.length; i++) {
                                double dev = observed[i] - ratio * expected[i];
                                expectedSumSq += dev * dev / (ratio * expected[i]);
                            }
                            
                            // Calculate with original method
                            double actualSumSq = chiSquareTest.chiSquare(expected, observed);
                            
                            // Assert - this will fail if the mutant is present
                            assertEquals(expectedSumSq, actualSumSq, 1E-10);
                            
                            // Additional check - verify the mutant would produce wrong result
                            double mutantSumSq = 0.0;
                            for (int i = 0; i < observed.length; i++) {
                                double dev = observed[i] * ratio * expected[i];  // Mutant version
                                mutantSumSq += dev * dev / (ratio * expected[i]);
                            }
                            assertNotEquals(mutantSumSq, actualSumSq, 1E-10);
                        }

    @Test
                            public void testChiSquareDetectsMutant1() {
                                // Create a simple 2x2 contingency table where we can manually calculate expected chi-square
                                long[][] counts = {
                                    {10, 20},
                                    {30, 40}
                                };
                                
                                // Manually calculate expected chi-square value
                                // Row sums: 30, 70
                                // Column sums: 40, 60
                                // Total: 100
                                // Expected values:
                                // [0][0]: (30*40)/100 = 12
                                // [0][1]: (30*60)/100 = 18
                                // [1][0]: (70*40)/100 = 28
                                // [1][1]: (70*60)/100 = 42
                                // Chi-square components:
                                // (10-12)²/12 = 0.333
                                // (20-18)²/18 = 0.222
                                // (30-28)²/28 = 0.143
                                // (40-42)²/42 = 0.095
                                // Total expected chi-square: ~0.7937
                                
                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                double result = chiSquareTest.chiSquare(counts);
                                
                                // Verify with delta for floating point precision
                                assertEquals(0.7937, result, 0.0001);
                                
                                // The mutant would calculate:
                                // (10*12)²/12 = 120
                                // (20*18)²/18 = 720
                                // (30*28)²/28 = 2520
                                // (40*42)²/42 = 6720
                                // Total: 10080 which is completely different
                                // So this test would fail for the mutant
                            }

    @Test
                    public void testChiSquareWithRescalingDetectsSubtractionMutant1() {
                        // Setup
                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                        double[] expected = {10.0, 20.0, 30.0}; // Sum = 60.0
                        long[] observed = {15L, 25L, 35L};      // Sum = 75.0 (needs rescaling)
                        
                        // Expected calculation with correct subtraction:
                        // ratio = 75/60 = 1.25
                        // For first element: (15 - 1.25*10)²/(1.25*10) = (2.5)²/12.5 = 0.5
                        // Second element: (25 - 1.25*20)²/(1.25*20) = 0
                        // Third element: (35 - 1.25*30)²/(1.25*30) ≈ (-2.5)²/37.5 ≈ 0.1667
                        // Expected sum ≈ 0.5 + 0 + 0.1667 ≈ 0.6667
                        
                        // With mutant division:
                        // For first element: (15/1.25*10) would be completely different
                        
                        // Action
                        double result = chiSquareTest.chiSquare(expected, observed);
                        
                        // Assertion - verify correct calculation with subtraction
                        // Using delta of 0.0001 for floating point comparison
                        assertEquals(0.6667, result, 0.0001);
                        
                        // Additional assertions to verify intermediate conditions
                        assertTrue(result > 0.6 && result < 0.7); // Check reasonable range
                    }

    @Test
                    public void testChiSquareDetectsSubtractionMutant() {
                        // Setup - create a simple 2x2 contingency table where we can calculate expected value manually
                        long[][] counts = {
                            {10, 20},
                            {30, 40}
                        };
                        
                        // Expected calculations:
                        // Row sums: 30, 70
                        // Column sums: 40, 60
                        // Total: 100
                        // Expected values:
                        // [0][0]: (30*40)/100 = 12
                        // [0][1]: (30*60)/100 = 18
                        // [1][0]: (70*40)/100 = 28
                        // [1][1]: (70*60)/100 = 42
                        // Chi-square components:
                        // (10-12)²/12 = 0.333
                        // (20-18)²/18 = 0.222
                        // (30-28)²/28 = 0.143
                        // (40-42)²/42 = 0.095
                        // Total expected chi-square: ~0.7937
                        
                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                        double result = chiSquareTest.chiSquare(counts);
                        
                        // The mutated version would calculate completely different values because:
                        // Instead of (observed - expected), it would do (observed / ratio * expected)
                        // For [0][0] it would be: (10 / ratio * 12) which is completely wrong
                        // So we expect the correct value to be ~0.7937, while mutant would give something else
                        
                        assertEquals(0.7937, result, 0.0001);
                        
                        // Additional assertion to ensure the value is in reasonable chi-square range
                        assertTrue(result > 0 && result < 100);
                    }

    @Test
                public void testChiSquareWithRescalingDetectsNaNmutant() {
                    // Setup
                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                    double[] expected = new double[]{10.0, 20.0, 30.0};
                    long[] observed = new long[]{12L, 18L, 32L}; // Sums differ (62 vs 60)
                    
                    // Execute
                    double result = chiSquareTest.chiSquare(expected, observed);
                    
                    // Verify - original should return valid chi-square value, mutant returns NaN
                    assertFalse("Result should not be NaN", Double.isNaN(result));
                    
                    // Additional verification of calculation correctness
                    // Expected calculations:
                    // sumExpected = 60, sumObserved = 62
                    // ratio = 62/60 ≈ 1.033333
                    // For first element: (12 - 1.033333*10)^2/(1.033333*10) ≈ (12-10.33333)^2/10.33333 ≈ 2.666667/10.33333 ≈ 0.25806
                    // Similar calculations for other elements
                    // Sum should be approximately 0.25806 + 0.58065 + 0.12903 ≈ 0.96774
                    assertEquals(0.96774, result, 0.0001);
                }

    @Test
                public void testChiSquareReturnsValidNumberNotNaN() {
                    // Setup
                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                    long[][] counts = {
                        {10, 20, 30},
                        {20, 30, 40}
                    };
                    
                    // Execute
                    double result = chiSquareTest.chiSquare(counts);
                    
                    // Verify
                    assertFalse("Chi-square result should not be NaN", Double.isNaN(result));
                    assertTrue("Chi-square result should be a positive number", result > 0);
                }

    @Test
            public void testChiSquareDevInitialization1() {
                // Setup
                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                double[] expected = new double[]{10.0, 10.0, 10.0};
                long[] observed = new long[]{10, 10, 10};
                
                // Expected result - all observed match expected, so chi-square should be 0
                double expectedResult = 0.0;
                
                // Execute
                double result = chiSquareTest.chiSquare(expected, observed);
                
                // Verify
                // The mutation would make result be infinity, so checking it's finite and equals 0
                assertTrue("Result should be finite", Double.isFinite(result));
                assertEquals("Chi-square value should be 0 when observed matches expected", 
                            expectedResult, result, 1e-10);
                
                // Additional test case where result should be small but non-zero
                long[] observed2 = new long[]{9, 10, 11};
                double result2 = chiSquareTest.chiSquare(expected, observed2);
                assertTrue("Result should be finite", Double.isFinite(result2));
                assertTrue("Chi-square value should be small but positive", 
                           result2 > 0 && result2 < 1.0);
            }

    @Test
            public void testChiSquareWithPerfectFitDetectsDevMutation() {
                // Create a perfect fit scenario where observed = expected
                // This should result in chi-square = 0, but mutant would return infinity
                long[][] counts = {{10, 10}, {10, 10}}; // Perfectly uniform distribution
                
                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                double result = chiSquareTest.chiSquare(counts);
                
                // Original should return 0, mutant would return infinity
                assertEquals(0.0, result, 0.0001);
            }

    @Test
            public void testChiSquareWithNonPerfectFit() {
                // Create a non-perfect fit scenario to test normal calculation
                long[][] counts = {{5, 15}, {10, 10}}; // Non-uniform distribution
                
                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                double result = chiSquareTest.chiSquare(counts);
                
                // Should return a positive finite value
                assertTrue(result > 0.0);
                assertTrue(Double.isFinite(result));
                
                // Verify the calculation is approximately correct
                // Expected values would be (rowSum*colSum)/total = (20*15)/40 = 7.5 for [0][1]
                // Chi-square contribution for [0][1] would be (15-7.5)^2/7.5 = 7.5
                // Similar calculations for other cells would give total chi-square > 7.5
                assertTrue(result > 7.5);
            }

    @Test
        public void testChiSquareWithFloatingPointPrecision() {
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            
            // Create test data where floating point addition order matters
            double[] expected = new double[]{1.0e-10, 1.0e10, 1.0e-10};
            long[] observed = new long[]{0, (long)1.0e10, 0};
            
            // Calculate expected result manually with forward iteration
            double sumExpected = 0d;
            double sumObserved = 0d;
            for (int i = 0; i < observed.length; i++) {
                sumExpected += expected[i];
                sumObserved += observed[i];
            }
            double ratio = sumObserved / sumExpected;
            double expectedSumSq = 0.0d;
            for (int i = 0; i < observed.length; i++) {
                double dev = ((double) observed[i] - ratio * expected[i]);
                expectedSumSq += dev * dev / (ratio * expected[i]);
            }
            
            // The mutated version (backward iteration) would produce slightly different result
            double actualSumSq = chiSquareTest.chiSquare(expected, observed);
            
            // Verify with delta to account for any minimal floating point differences
            assertEquals(expectedSumSq, actualSumSq, 1.0e-20);
            
            // Additional verification that the value is as expected
            // The first and third terms should be 1.0 since (0-1*1e-10)^2/(1*1e-10) = 1e-10
            // The middle term should be 0 since (1e10-1*1e10)^2/(1*1e10) = 0
            assertEquals(2.0, actualSumSq, 1.0e-10);
        }

    @Test
        public void testChiSquareWithAsymmetricMatrix() {
            // Setup
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            long[][] counts = new long[][] {
                {10, 20, 30},
                {15, 25, 35}
            };
            
            // Expected calculations
            double[] expectedRowSums = {60.0, 75.0};  // Sum of each row
            double[] expectedColSums = {25.0, 45.0, 65.0};  // Sum of each column
            double expectedTotal = 135.0;  // Total sum
            
            // Execute
            double result = chiSquareTest.chiSquare(counts);
            
            // Verify intermediate calculations would be different if processed in reverse order
            // For a 2x3 matrix, processing order matters for when sums are accumulated
            // We can't directly access the intermediate sums, but we can verify the final result
            // is exactly as expected for this specific input
            
            // Expected chi-square calculation:
            // Cell (0,0): expected = 60*25/135 = 11.111..., contribution = (10-11.111)^2/11.111 = 0.1111
            // Cell (0,1): expected = 60*45/135 = 20.0, contribution = 0.0
            // Cell (0,2): expected = 60*65/135 = 28.888..., contribution = (30-28.888)^2/28.888 = 0.0427
            // Cell (1,0): expected = 75*25/135 = 13.888..., contribution = (15-13.888)^2/13.888 = 0.0889
            // Cell (1,1): expected = 75*45/135 = 25.0, contribution = 0.0
            // Cell (1,2): expected = 75*65/135 = 36.111..., contribution = (35-36.111)^2/36.111 = 0.0342
            // Total chi-square = 0.1111 + 0.0 + 0.0427 + 0.0889 + 0.0 + 0.0342 = 0.2769
            
            double expectedChiSquare = 0.2769;
            assertEquals(expectedChiSquare, result, 0.0001);
            
            // Additional test with different matrix to ensure detection
            long[][] counts2 = new long[][] {
                {1, 0},
                {0, 1},
                {1, 1}
            };
            double result2 = chiSquareTest.chiSquare(counts2);
            // Expected calculations:
            // Total = 4
            // Cell (0,0): expected = 1*1/4 = 0.25, contribution = (1-0.25)^2/0.25 = 2.25
            // Cell (0,1): expected = 1*3/4 = 0.75, contribution = (0-0.75)^2/0.75 = 0.75
            // Cell (1,0): expected = 1*1/4 = 0.25, contribution = (0-0.25)^2/0.25 = 0.25
            // Cell (1,1): expected = 1*3/4 = 0.75, contribution = (1-0.75)^2/0.75 = 0.0833
            // Cell (2,0): expected = 2*1/4 = 0.5, contribution = (1-0.5)^2/0.5 = 0.5
            // Cell (2,1): expected = 2*3/4 = 1.5, contribution = (1-1.5)^2/1.5 = 0.1667
            // Total = 2.25 + 0.75 + 0.25 + 0.0833 + 0.5 + 0.1667 = 4.0
            assertEquals(4.0, result2, 0.0001);
        }

    @Test
    public void testChiSquareWithoutRescalingDetectsDivisionMutant() {
        // Setup - create inputs where sumExpected == sumObserved
        double[] expected = {2.0, 3.0, 5.0};  // Sum = 10
        long[] observed = {2L, 3L, 5L};       // Sum = 10
        
        // Manually calculate expected chi-square value
        // For each cell: (observed - expected)^2 / expected
        // (2-2)^2/2 = 0
        // (3-3)^2/3 = 0
        // (5-5)^2/5 = 0
        double expectedChiSquare = 0.0;
        
        // Create test instance
        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
        
        // Call method and assert
        double result = chiSquareTest.chiSquare(expected, observed);
        
        // The mutant would calculate:
        // (2-2)^2*2 = 0
        // (3-3)^2*3 = 0
        // (5-5)^2*5 = 0
        // So sum would still be 0 in this case - need different values
        
        // Let's try different values where the mutant would give different results
        expected = new double[]{1.0, 2.0, 3.0};  // Sum = 6
        observed = new long[]{2L, 3L, 1L};        // Sum = 6
        
        // Manual calculation:
        // (2-1)^2/1 = 1
        // (3-2)^2/2 = 0.5
        // (1-3)^2/3 ≈ 1.333
        expectedChiSquare = 1 + 0.5 + (4.0/3.0);  // ≈ 2.833
        
        // Mutant would calculate:
        // (2-1)^2*1 = 1
        // (3-2)^2*2 = 2
        // (1-3)^2*3 = 12
        // Sum = 15 (very different from 2.833)
        
        result = chiSquareTest.chiSquare(expected, observed);
        assertEquals(expectedChiSquare, result, 1E-10);
    }

    @Test
    public void testChiSquareCountsDetectsMultiplicationMutant() {
        // Setup - create a simple 2x2 contingency table
        long[][] counts = new long[][] {
            {10, 20},
            {30, 40}
        };
        
        // Expected chi-square value calculated manually:
        // Row sums: 30, 70
        // Column sums: 40, 60
        // Total: 100
        // Expected values:
        // [0][0]: 30*40/100 = 12
        // [0][1]: 30*60/100 = 18
        // [1][0]: 70*40/100 = 28
        // [1][1]: 70*60/100 = 42
        // Chi-square components:
        // (10-12)²/12 = 0.333
        // (20-18)²/18 = 0.222
        // (30-28)²/28 = 0.143
        // (40-42)²/42 = 0.095
        // Total expected chi-square: ~0.7937
        
        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
        double result = chiSquareTest.chiSquare(counts);
        
        // Verify with delta for floating point precision
        assertEquals(0.7937, result, 0.0001);
        
        // The mutant would calculate:
        // (10-12)²*12 = 48
        // (20-18)²*18 = 72
        // (30-28)²*28 = 112
        // (40-42)²*42 = 168
        // Total: 400 (completely different)
        // So this test would fail with the mutant
    }

}
