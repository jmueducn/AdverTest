package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.math.BigInteger;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.util.MathUtils;
 
public class FractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                    public void testCompareTo_WhenCurrentFractionIsSmaller() {
                                        Fraction fraction1 = new Fraction(1, 2);  // 1/2 = 0.5
                                        Fraction fraction2 = new Fraction(3, 4);  // 3/4 = 0.75
                                        
                                        assertTrue(fraction1.compareTo(fraction2) < 0);
                                        assertEquals(-1, fraction1.compareTo(fraction2));
                                    }

    @Test
                                    public void testCompareTo_WhenCurrentFractionIsLarger() {
                                        Fraction fraction1 = new Fraction(3, 4);  // 3/4 = 0.75
                                        Fraction fraction2 = new Fraction(1, 2);  // 1/2 = 0.5
                                        
                                        assertTrue(fraction1.compareTo(fraction2) > 0);
                                        assertEquals(1, fraction1.compareTo(fraction2));
                                    }

    @Test
                                    public void testCompareTo_WhenFractionsAreEqual() {
                                        Fraction fraction1 = new Fraction(1, 2);  // 1/2 = 0.5
                                        Fraction fraction2 = new Fraction(2, 4);  // 2/4 = 0.5 (reduced to 1/2)
                                        
                                        assertEquals(0, fraction1.compareTo(fraction2));
                                    }

    @Test
                                    public void testCompareTo_WithNegativeFractions() {
                                        Fraction fraction1 = new Fraction(-1, 2);  // -1/2 = -0.5
                                        Fraction fraction2 = new Fraction(1, 2);    // 1/2 = 0.5
                                        
                                        assertTrue(fraction1.compareTo(fraction2) < 0);
                                        assertTrue(fraction2.compareTo(fraction1) > 0);
                                    }

    @Test
                                    public void testCompareTo_WithBothNegativeFractions() {
                                        Fraction fraction1 = new Fraction(-1, 2);  // -1/2 = -0.5
                                        Fraction fraction2 = new Fraction(-1, 4);   // -1/4 = -0.25
                                        
                                        assertTrue(fraction1.compareTo(fraction2) < 0);
                                        assertTrue(fraction2.compareTo(fraction1) > 0);
                                    }

    @Test
                                    public void testCompareTo_WithLargeNumbers() {
                                        Fraction fraction1 = new Fraction(Integer.MAX_VALUE - 1, 1);
                                        Fraction fraction2 = new Fraction(Integer.MAX_VALUE, 1);
                                        
                                        assertTrue(fraction1.compareTo(fraction2) < 0);
                                        assertTrue(fraction2.compareTo(fraction1) > 0);
                                    }

    @Test
                                    public void testCompareTo_WithStaticConstants() {
                                        assertTrue(Fraction.ZERO.compareTo(Fraction.ONE) < 0);
                                        assertTrue(Fraction.ONE.compareTo(Fraction.TWO) < 0);
                                        assertTrue(Fraction.MINUS_ONE.compareTo(Fraction.ZERO) < 0);
                                        assertEquals(0, Fraction.ONE.compareTo(new Fraction(1, 1)));
                                    }

    @Test
                                    public void testCompareTo_WithNullParameter() {
                                        Fraction fraction = new Fraction(1, 2);
                                        
                                        thrown.expect(NullPointerException.class);
                                        thrown.expectMessage("Cannot compare to null");
                                        
                                        fraction.compareTo(null);
                                    }

    @Test
                                    public void testCompareTo_WithSameObject() {
                                        Fraction fraction = new Fraction(1, 2);
                                        assertEquals(0, fraction.compareTo(fraction));
                                    }

    @Test
                                    public void testCompareTo_WithEquivalentFractions() {
                                        Fraction fraction1 = new Fraction(2, 3);
                                        Fraction fraction2 = new Fraction(4, 6);
                                        Fraction fraction3 = new Fraction(8, 12);
                                        
                                        assertEquals(0, fraction1.compareTo(fraction2));
                                        assertEquals(0, fraction1.compareTo(fraction3));
                                        assertEquals(0, fraction2.compareTo(fraction3));
                                    }

    @Test
                                    public void testCompareTo_WithCrossMultiplicationEdgeCases() {
                                        // Test cases where cross multiplication might cause overflow if not using long
                                        Fraction fraction1 = new Fraction(Integer.MAX_VALUE, 1);
                                        Fraction fraction2 = new Fraction(1, Integer.MAX_VALUE);
                                        
                                        assertTrue(fraction1.compareTo(fraction2) > 0);
                                        assertTrue(fraction2.compareTo(fraction1) < 0);
                                    }

    @Test
                            public void testAbsWithZeroNumerator() {
                                // Create a fraction with numerator 0 (should be treated as non-negative)
                                Fraction zeroFraction = new Fraction(0, 1);
                                
                                // Call abs() - should return the same instance since 0 >= 0
                                Fraction result = zeroFraction.abs();
                                
                                // Verify it returns the same instance (not negated)
                                assertSame("abs() should return same instance for zero numerator", 
                                          zeroFraction, result);
                                
                                // Also verify the numerator is still 0
                                assertEquals("Numerator should remain 0", 
                                            0, result.getNumerator());
                                assertEquals("Denominator should remain unchanged", 
                                            1, result.getDenominator());
                            }

    @Test
                            public void testAbsWithNegativeNumerator() {
                                // Create a fraction with negative numerator
                                Fraction fraction = new Fraction(-3, 4);
                                
                                // Call abs()
                                Fraction result = fraction.abs();
                                
                                // Verify the result is positive (would fail with mutant)
                                assertTrue("Numerator should be positive after abs()", 
                                           result.getNumerator() > 0);
                                assertEquals("Numerator should be 3", 3, result.getNumerator());
                                assertEquals("Denominator should remain 4", 4, result.getDenominator());
                            }

    @Test
                            public void testAbsWithPositiveNumerator() {
                                // Create a fraction with positive numerator
                                Fraction fraction = new Fraction(3, 4);
                                
                                // Call abs()
                                Fraction result = fraction.abs();
                                
                                // Verify the result is the same object (identity comparison)
                                assertSame("Should return same instance for positive numerator", 
                                          fraction, result);
                            }

    @Test
                        public void testAbsWithPositiveNumerator1() {
                            // Create a fraction with positive numerator
                            Fraction fraction = new Fraction(3, 4);
                            
                            // Call abs() and verify it returns the same object (not negated)
                            Fraction result = fraction.abs();
                            assertSame("For positive numerator, abs() should return same object", 
                                      fraction, result);
                        }

    @Test
                        public void testAbsWithNegativeNumerator1() {
                            // Create a fraction with negative numerator
                            Fraction fraction = new Fraction(-3, 4);
                            
                            // Call abs() and verify it returns a different object (negated)
                            Fraction result = fraction.abs();
                            assertNotSame("For negative numerator, abs() should return different object", 
                                          fraction, result);
                            assertEquals("Numerator should be positive", 3, result.getNumerator());
                            assertEquals("Denominator should remain same", 4, result.getDenominator());
                        }

    @Test
                        public void testAbsWithZeroNumerator1() {
                            // Create a fraction with zero numerator (edge case)
                            Fraction fraction = new Fraction(0, 1);
                            
                            // Call abs() and verify it returns the same object
                            Fraction result = fraction.abs();
                            assertSame("For zero numerator, abs() should return same object", 
                                      fraction, result);
                        }

    @Test
                    public void testAbsWithNegativeFraction() {
                        // Create a negative fraction (numerator = -1, denominator = 2)
                        Fraction negativeFraction = new Fraction(-1, 2);
                        
                        // Call abs() - should return positive equivalent (1/2)
                        Fraction result = negativeFraction.abs();
                        
                        // Verify numerator is positive (should be 1)
                        assertEquals(1, result.getNumerator());
                        
                        // Verify denominator remains the same (should be 2)
                        assertEquals(2, result.getDenominator());
                        
                        // Verify the result is not the same object as original (unless cached)
                        assertNotSame(negativeFraction, result);
                    }

    @Test
            public void testAbsWithNegativeNumerator2() {
                // Create a fraction with negative numerator
                Fraction negativeFraction = new Fraction(-3, 4);
                
                // Call abs()
                Fraction result = negativeFraction.abs();
                
                // Verify the result is not null (would fail with mutant)
                assertNotNull("abs() should not return null for negative numerator", result);
                
                // Verify the result is the properly negated fraction
                assertEquals("Numerator should be positive", 3, result.getNumerator());
                assertEquals("Denominator should remain same", 4, result.getDenominator());
                
                // Additional check - verify it's equal to explicitly negated fraction
                Fraction expected = negativeFraction.negate();
                assertEquals("abs() should equal negate() for negative fractions", expected, result);
            }

    @Test
            public void testAbsReturnsNonNull() {
                // Test case for non-negative numerator
                Fraction positiveFraction = new Fraction(3, 4);
                Fraction resultPositive = positiveFraction.abs();
                assertNotNull("abs() should not return null for positive numerator", resultPositive);
                assertEquals(3, resultPositive.getNumerator());
                assertEquals(4, resultPositive.getDenominator());
                
                // Test case for negative numerator
                Fraction negativeFraction = new Fraction(-3, 4);
                Fraction resultNegative = negativeFraction.abs();
                assertNotNull("abs() should not return null for negative numerator", resultNegative);
                assertEquals(3, resultNegative.getNumerator());
                assertEquals(4, resultNegative.getDenominator());
                
                // Test case for zero numerator
                Fraction zeroFraction = new Fraction(0, 1);
                Fraction resultZero = zeroFraction.abs();
                assertNotNull("abs() should not return null for zero numerator", resultZero);
                assertEquals(0, resultZero.getNumerator());
                assertEquals(1, resultZero.getDenominator());
            }

    @Test
        public void testAbsWithNegativeNumeratorDetectsMutant() {
            // Create a fraction with negative numerator
            Fraction negativeFraction = new Fraction(-3, 4);
            
            // Call abs()
            Fraction result = negativeFraction.abs();
            
            // Verify the result is not the same object as original (should be new instance from negate())
            assertNotSame("abs() should return a new instance for negative numerator", 
                         negativeFraction, result);
            
            // Verify the numerator is positive
            assertTrue("Numerator should be positive after abs()", 
                      result.getNumerator() > 0);
            
            // Verify the value is correct (3/4)
            assertEquals("Numerator should be 3", 3, result.getNumerator());
            assertEquals("Denominator should be 4", 4, result.getDenominator());
        }

    @Test
        public void testAbsWithPositiveNumerator2() {
            // Create a fraction with positive numerator
            Fraction positiveFraction = new Fraction(3, 4);
            
            // Call abs()
            Fraction result = positiveFraction.abs();
            
            // Verify the result is the same object as original
            assertSame("abs() should return same instance for positive numerator", 
                      positiveFraction, result);
        }

}
