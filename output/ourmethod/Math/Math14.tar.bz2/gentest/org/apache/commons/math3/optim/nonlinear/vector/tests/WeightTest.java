package gentest.org.apache.commons.math3.optim.nonlinear.vector.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optim.nonlinear.vector.*;
import org.apache.commons.math3.optim.OptimizationData;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.DiagonalMatrix;
import org.apache.commons.math3.linear.NonSquareMatrixException;
 
public class WeightTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testConstructor_ValidWeights() {
                // Arrange
                double[] weights = {1.0, 2.0, 3.0};
                
                // Act
                Weight weight = new Weight(weights);
                
                // Assert
                RealMatrix matrix = weight.getWeight();
                assertNotNull(matrix);
                assertTrue(matrix instanceof DiagonalMatrix);
                assertEquals(1.0, matrix.getEntry(0, 0), 0.0001);
                assertEquals(2.0, matrix.getEntry(1, 1), 0.0001);
                assertEquals(3.0, matrix.getEntry(2, 2), 0.0001);
                assertEquals(0.0, matrix.getEntry(0, 1), 0.0001); // off-diagonal should be 0
            }

    @Test
            public void testConstructor_SingleWeight() {
                // Arrange
                double[] weights = {5.0};
                
                // Act
                Weight weight = new Weight(weights);
                
                // Assert
                RealMatrix matrix = weight.getWeight();
                assertEquals(1, matrix.getRowDimension());
                assertEquals(1, matrix.getColumnDimension());
                assertEquals(5.0, matrix.getEntry(0, 0), 0.0001);
            }

    @Test
            public void testConstructor_WithZeroWeight() {
                // Arrange
                double[] weights = {1.0, 0.0, 3.0};
                
                // Act
                Weight weight = new Weight(weights);
                
                // Assert
                RealMatrix matrix = weight.getWeight();
                assertEquals(0.0, matrix.getEntry(1, 1), 0.0001);
            }

    @Test
            public void testConstructor_WithNegativeWeight() {
                // Arrange
                double[] weights = {1.0, -2.0, 3.0};
                
                // Act
                Weight weight = new Weight(weights);
                
                // Assert
                RealMatrix matrix = weight.getWeight();
                assertEquals(-2.0, matrix.getEntry(1, 1), 0.0001);
            }

    @Test
            public void testGetWeight_ReturnsCorrectMatrix() {
                // Arrange
                double[] weights = {2.0, 4.0};
                Weight weight = new Weight(weights);
                
                // Act
                RealMatrix result = weight.getWeight();
                
                // Assert
                assertNotNull(result);
                assertEquals(2, result.getRowDimension());
                assertEquals(2, result.getColumnDimension());
                assertEquals(2.0, result.getEntry(0, 0), 0.0001);
                assertEquals(4.0, result.getEntry(1, 1), 0.0001);
                assertEquals(0.0, result.getEntry(0, 1), 0.0001);
                assertEquals(0.0, result.getEntry(1, 0), 0.0001);
            }

    @Test
            public void testConstructor_WithSquareMatrix_SuccessfullyCreatesObject() {
                // Arrange
                RealMatrix mockMatrix = mock(RealMatrix.class);
                when(mockMatrix.getColumnDimension()).thenReturn(3);
                when(mockMatrix.getRowDimension()).thenReturn(3);
                RealMatrix mockCopy = mock(RealMatrix.class);
                when(mockMatrix.copy()).thenReturn(mockCopy);
                
                // Act
                Weight weight = new Weight(mockMatrix);
                
                // Assert
                assertNotNull(weight);
                verify(mockMatrix).copy();
                // Verify the stored matrix is the copy we returned
                assertSame(mockCopy, weight.getWeight());
            }

    @Test
            public void testConstructor_WithNonSquareMatrix_ThrowsNonSquareMatrixException() {
                // Arrange
                RealMatrix mockMatrix = mock(RealMatrix.class);
                when(mockMatrix.getColumnDimension()).thenReturn(2);
                when(mockMatrix.getRowDimension()).thenReturn(3);
                
                // Expect exception
                thrown.expect(NonSquareMatrixException.class);
                thrown.expectMessage("3 != 2");
                
                // Act
                new Weight(mockMatrix);
            }

    @Test
            public void testConstructor_VerifiesDeepCopyIsStored() {
                // Arrange
                RealMatrix originalMatrix = mock(RealMatrix.class);
                when(originalMatrix.getColumnDimension()).thenReturn(2);
                when(originalMatrix.getRowDimension()).thenReturn(2);
                RealMatrix copiedMatrix = mock(RealMatrix.class);
                when(originalMatrix.copy()).thenReturn(copiedMatrix);
                
                // Act
                Weight weight = new Weight(originalMatrix);
                
                // Assert
                assertNotSame(originalMatrix, weight.getWeight());
                assertSame(copiedMatrix, weight.getWeight());
                verify(originalMatrix).copy();
            }

    @Test
            public void testConstructor_With1x1Matrix_AcceptsMinimumSquareMatrix() {
                // Arrange
                RealMatrix mockMatrix = mock(RealMatrix.class);
                when(mockMatrix.getColumnDimension()).thenReturn(1);
                when(mockMatrix.getRowDimension()).thenReturn(1);
                RealMatrix mockCopy = mock(RealMatrix.class);
                when(mockMatrix.copy()).thenReturn(mockCopy);
                
                // Act
                Weight weight = new Weight(mockMatrix);
                
                // Assert
                assertNotNull(weight);
                assertSame(mockCopy, weight.getWeight());
            }

    @Test
    public void testConstructor_EmptyArray() {
        // Arrange
        double[] weights = {};
        
        try {
            // Act
            new Weight(weights);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // Assert
            assertEquals("Weight array cannot be empty", e.getMessage());
        }
    }

    @Test
    public void testConstructor_NullInput() {
        // Arrange
        ExpectedException exceptionRule = ExpectedException.none();
        exceptionRule.expect(NullPointerException.class);
        exceptionRule.expectMessage("Weight array cannot be null");
        
        // Act & Assert
        new Weight((double[]) null);
    }

    @Test
    public void testConstructor_WithNullMatrix_ThrowsNullPointerException() {
        // Expect exception
        thrown.expect(NullPointerException.class);
        
        // Act - explicitly cast null to RealMatrix to specify which constructor to test
        new Weight((RealMatrix) null);
    }


}
