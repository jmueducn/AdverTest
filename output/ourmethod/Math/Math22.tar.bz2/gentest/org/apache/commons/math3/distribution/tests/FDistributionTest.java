package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.special.Beta;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
 
public class FDistributionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                    public void testIsSupportLowerBoundInclusive_WithDifferentDegreesOfFreedom() {
                                                                        // Test with typical degrees of freedom
                                                                        FDistribution dist1 = new FDistribution(5.0, 10.0);
                                                                        assertFalse(dist1.isSupportLowerBoundInclusive());
                                                                        
                                                                        // Test with equal degrees of freedom
                                                                        FDistribution dist2 = new FDistribution(7.5, 7.5);
                                                                        assertFalse(dist2.isSupportLowerBoundInclusive());
                                                                        
                                                                        // Test with large degrees of freedom
                                                                        FDistribution dist3 = new FDistribution(100.0, 200.0);
                                                                        assertFalse(dist3.isSupportLowerBoundInclusive());
                                                                        
                                                                        // Test with small degrees of freedom (just above minimum)
                                                                        FDistribution dist4 = new FDistribution(Double.MIN_VALUE * 2, Double.MIN_VALUE * 2);
                                                                        assertFalse(dist4.isSupportLowerBoundInclusive());
                                                                    }

    @Test
                                                                    public void testIsSupportLowerBoundInclusive_WithDifferentConstructors() {
                                                                        // Test with 2-arg constructor
                                                                        FDistribution dist1 = new FDistribution(3.0, 5.0);
                                                                        assertFalse(dist1.isSupportLowerBoundInclusive());
                                                                        
                                                                        // Test with 3-arg constructor
                                                                        FDistribution dist2 = new FDistribution(4.0, 6.0, 1e-12);
                                                                        assertFalse(dist2.isSupportLowerBoundInclusive());
                                                                        
                                                                        // Test with 4-arg constructor
                                                                        FDistribution dist3 = new FDistribution(new Well19937c(), 2.0, 8.0, 1e-12);
                                                                        assertFalse(dist3.isSupportLowerBoundInclusive());
                                                                    }

    @Test
                                                                    public void testIsSupportLowerBoundInclusive_ConsistencyCheck() {
                                                                        // Verify that the method consistently returns false for multiple calls
                                                                        FDistribution dist = new FDistribution(10.0, 20.0);
                                                                        for (int i = 0; i < 10; i++) {
                                                                            assertFalse(dist.isSupportLowerBoundInclusive());
                                                                        }
                                                                    }

    @Test
                                                            public void testGetDenominatorDegreesOfFreedom_StandardCase() {
                                                                double numeratorDof = 5.0;
                                                                double denominatorDof = 10.0;
                                                                double epsilon = 1e-15; // Define epsilon for floating-point comparison
                                                                FDistribution fDistribution = new FDistribution(numeratorDof, denominatorDof);
                                                                
                                                                assertEquals("Should return correct denominator degrees of freedom",
                                                                            denominatorDof, fDistribution.getDenominatorDegreesOfFreedom(), epsilon);
                                                            }

    @Test
                                                            public void testGetDenominatorDegreesOfFreedom_WithDifferentValues() {
                                                                double numeratorDof = 3.5;
                                                                double denominatorDof = 7.2;
                                                                double epsilon = 1e-15; // Define epsilon for floating-point comparison
                                                                FDistribution fDistribution = new FDistribution(numeratorDof, denominatorDof);
                                                                
                                                                assertEquals("Should return correct denominator degrees of freedom for non-integer values",
                                                                            denominatorDof, fDistribution.getDenominatorDegreesOfFreedom(), epsilon);
                                                            }

    @Test
                                                            public void testGetDenominatorDegreesOfFreedom_WithVerySmallValue() {
                                                                double numeratorDof = 1.0;
                                                                double denominatorDof = Double.MIN_VALUE;
                                                                double EPSILON = 1e-15; // Define epsilon for double comparison
                                                                FDistribution fDistribution = new FDistribution(numeratorDof, denominatorDof);
                                                                
                                                                assertEquals("Should handle very small denominator degrees of freedom",
                                                                            denominatorDof, fDistribution.getDenominatorDegreesOfFreedom(), EPSILON);
                                                            }

    @Test
                                                            public void testGetDenominatorDegreesOfFreedom_WithLargeValue() {
                                                                double numeratorDof = 100.0;
                                                                double denominatorDof = Double.MAX_VALUE;
                                                                double EPSILON = 1e-15; // Define epsilon for double comparison
                                                                FDistribution fDistribution = new FDistribution(numeratorDof, denominatorDof);
                                                                
                                                                assertEquals("Should handle very large denominator degrees of freedom",
                                                                            denominatorDof, fDistribution.getDenominatorDegreesOfFreedom(), EPSILON);
                                                            }

    @Test
                                                            public void testGetDenominatorDegreesOfFreedom_AfterConstructionWithRandomGenerator() {
                                                                // Test data
                                                                double numeratorDof = 8.0;
                                                                double denominatorDof = 15.0;
                                                                double inverseCumAccuracy = 1e-12;
                                                                double epsilon = 1e-15; // Define EPSILON for double comparison
                                                                
                                                                // Create FDistribution instance with random generator
                                                                FDistribution fDistribution = new FDistribution(new org.apache.commons.math3.random.Well19937c(), 
                                                                                                              numeratorDof, 
                                                                                                              denominatorDof, 
                                                                                                              inverseCumAccuracy);
                                                                
                                                                // Verify denominator degrees of freedom
                                                                assertEquals("Should return correct denominator degrees of freedom when using RandomGenerator constructor",
                                                                            denominatorDof, fDistribution.getDenominatorDegreesOfFreedom(), epsilon);
                                                            }

    @Test
                                                            public void testGetDenominatorDegreesOfFreedom_VerifyImmutable() {
                                                                double numeratorDof = 4.0;
                                                                double initialDenominatorDof = 8.0;
                                                                double epsilon = 1e-15; // Define epsilon for double comparison
                                                                FDistribution fDistribution = new FDistribution(numeratorDof, initialDenominatorDof);
                                                                
                                                                // Verify the value doesn't change over time
                                                                for (int i = 0; i < 10; i++) {
                                                                    assertEquals("Value should remain constant",
                                                                                initialDenominatorDof, fDistribution.getDenominatorDegreesOfFreedom(), epsilon);
                                                                }
                                                            }

    @Test
                                                            public void testGetDenominatorDegreesOfFreedom_EdgeCaseJustAboveZero() {
                                                                double numeratorDof = 1.0;
                                                                double denominatorDof = Double.MIN_VALUE * 2;
                                                                double EPSILON = 1e-15; // Define epsilon for double comparison
                                                                FDistribution fDistribution = new FDistribution(numeratorDof, denominatorDof);
                                                                
                                                                assertEquals("Should handle values just above zero",
                                                                            denominatorDof, fDistribution.getDenominatorDegreesOfFreedom(), EPSILON);
                                                            }

    @Test
                                                            public void testGetSolverAbsoluteAccuracy_DefaultConstructor() {
                                                                // Define test constants
                                                                double TEST_DF_NUM = 5.0;
                                                                double TEST_DF_DEN = 10.0;
                                                                double DEFAULT_ACCURACY = 1.0e-15;
                                                                
                                                                // Using constructor with default accuracy
                                                                FDistribution dist = new FDistribution(TEST_DF_NUM, TEST_DF_DEN);
                                                                
                                                                // Use reflection to access protected method
                                                                try {
                                                                    Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                                                                    method.setAccessible(true);
                                                                    double accuracy = (Double) method.invoke(dist);
                                                                    
                                                                    // Verify it returns the default accuracy
                                                                    assertEquals(DEFAULT_ACCURACY, accuracy, 0.0);
                                                                } catch (Exception e) {
                                                                    fail("Failed to access protected method: " + e.getMessage());
                                                                }
                                                            }

    @Test
                                                            public void testGetSolverAbsoluteAccuracy_CustomAccuracyConstructor() {
                                                                // Define test constants
                                                                double TEST_DF_NUM = 5.0;
                                                                double TEST_DF_DEN = 10.0;
                                                                double CUSTOM_ACCURACY = 1.0e-12;
                                                                
                                                                // Using constructor with custom accuracy
                                                                FDistribution dist = new FDistribution(TEST_DF_NUM, TEST_DF_DEN, CUSTOM_ACCURACY);
                                                                
                                                                // Use reflection to access protected method
                                                                try {
                                                                    Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                                                                    method.setAccessible(true);
                                                                    double accuracy = (Double) method.invoke(dist);
                                                                    
                                                                    // Verify it returns the custom accuracy
                                                                    assertEquals(CUSTOM_ACCURACY, accuracy, 0.0);
                                                                } catch (Exception e) {
                                                                    fail("Failed to access getSolverAbsoluteAccuracy method: " + e.getMessage());
                                                                }
                                                            }

    @Test
                                                            public void testGetSolverAbsoluteAccuracy_FullConstructor() {
                                                                // Define test constants
                                                                final double TEST_DF_NUM = 5.0;
                                                                final double TEST_DF_DEN = 10.0;
                                                                final double CUSTOM_ACCURACY = 1.0e-12;
                                                                
                                                                // Using full constructor with custom accuracy
                                                                FDistribution dist = new FDistribution(new Well19937c(), TEST_DF_NUM, TEST_DF_DEN, CUSTOM_ACCURACY);
                                                                
                                                                // Use reflection to access protected method
                                                                try {
                                                                    Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                                                                    method.setAccessible(true);
                                                                    double accuracy = (Double) method.invoke(dist);
                                                                    assertEquals(CUSTOM_ACCURACY, accuracy, 0.0);
                                                                } catch (Exception e) {
                                                                    fail("Failed to access getSolverAbsoluteAccuracy method: " + e.getMessage());
                                                                }
                                                            }

    @Test
                                                            public void testGetSolverAbsoluteAccuracy_EdgeCaseZeroAccuracy() throws Exception {
                                                                // Test with zero accuracy (edge case)
                                                                double zeroAccuracy = 0.0;
                                                                double testDfNum = 5.0;  // Define test numerator degrees of freedom
                                                                double testDfDen = 10.0; // Define test denominator degrees of freedom
                                                                FDistribution dist = new FDistribution(testDfNum, testDfDen, zeroAccuracy);
                                                                
                                                                // Use reflection to access protected method
                                                                Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                                                                method.setAccessible(true);
                                                                double result = (Double) method.invoke(dist);
                                                                
                                                                assertEquals(zeroAccuracy, result, 0.0);
                                                            }

    @Test
                                                            public void testGetSolverAbsoluteAccuracy_EdgeCaseLargeAccuracy() {
                                                                // Test with large accuracy value (edge case)
                                                                double largeAccuracy = 1.0;
                                                                double testDfNum = 5.0;  // Defined test numerator degrees of freedom
                                                                double testDfDen = 10.0; // Defined test denominator degrees of freedom
                                                                FDistribution dist = new FDistribution(testDfNum, testDfDen, largeAccuracy);
                                                                
                                                                // Use reflection to access protected method
                                                                try {
                                                                    Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                                                                    method.setAccessible(true);
                                                                    double accuracy = (Double) method.invoke(dist);
                                                                    assertEquals(largeAccuracy, accuracy, 0.0);
                                                                } catch (Exception e) {
                                                                    fail("Failed to access getSolverAbsoluteAccuracy method");
                                                                }
                                                            }

    @Test
                                                            public void testGetSolverAbsoluteAccuracy_ConstructorWithInvalidNumeratorDF() {
                                                                double TEST_DF_DEN = 2.0; // Defining denominator degrees of freedom
                                                                double CUSTOM_ACCURACY = 1.0e-12; // Defining custom accuracy value
                                                                thrown.expect(NotStrictlyPositiveException.class);
                                                                new FDistribution(-1.0, TEST_DF_DEN, CUSTOM_ACCURACY);
                                                            }

    @Test
                                                            public void testGetSolverAbsoluteAccuracy_ConstructorWithInvalidDenominatorDF() {
                                                                double TEST_DF_NUM = 5.0; // Example value for numerator degrees of freedom
                                                                double CUSTOM_ACCURACY = 1.0e-9; // Example value for custom accuracy
                                                                
                                                                thrown.expect(NotStrictlyPositiveException.class);
                                                                new FDistribution(TEST_DF_NUM, -1.0, CUSTOM_ACCURACY);
                                                            }

    @Test
                                                            public void testDensityDetectsAbsDenominatorMutant() {
                                                                // Create FDistribution with known parameters
                                                                double numeratorDof = 5.0;
                                                                double denominatorDof = 10.0;
                                                                FDistribution fd = new FDistribution(numeratorDof, denominatorDof);
                                                                
                                                                // Test with several x values
                                                                double x1 = 0.5;
                                                                double x2 = 1.0;
                                                                double x3 = 2.0;
                                                                
                                                                // Calculate expected density values (approximated)
                                                                // These values would normally come from known statistical tables or calculations
                                                                double expected1 = 0.736; // approximate expected value for x=0.5
                                                                double expected2 = 0.567; // approximate expected value for x=1.0
                                                                double expected3 = 0.230; // approximate expected value for x=2.0
                                                                
                                                                // Assert that the actual density values match expected (with delta for floating point)
                                                                assertEquals("Density calculation incorrect for x=0.5", 
                                                                    expected1, fd.density(x1), 0.001);
                                                                assertEquals("Density calculation incorrect for x=1.0", 
                                                                    expected2, fd.density(x2), 0.001);
                                                                assertEquals("Density calculation incorrect for x=2.0", 
                                                                    expected3, fd.density(x3), 0.001);
                                                                
                                                                // Additional assertion to specifically catch the abs(denominator) mutant
                                                                assertNotEquals("Density returned denominator value", 
                                                                    denominatorDof, fd.density(x1), 0.0001);
                                                                assertNotEquals("Density returned denominator value", 
                                                                    denominatorDof, fd.density(x2), 0.0001);
                                                                assertNotEquals("Density returned denominator value", 
                                                                    denominatorDof, fd.density(x3), 0.0001);
                                                            }

    @Test
                                                        public void testDensityReturnsPositiveInfinityAtBoundary() {
                                                            // Create F-distribution with small degrees of freedom
                                                            // to increase chance of infinite results
                                                            FDistribution fDist = new FDistribution(1.0, 1.0);
                                                            
                                                            // Test case where x approaches 0
                                                            double resultForZero = fDist.density(0.0);
                                                            assertTrue("Density at 0 should be positive infinity", 
                                                                      Double.isInfinite(resultForZero) && resultForZero > 0);
                                                            
                                                            // Test case where x approaches infinity
                                                            double resultForInfinity = fDist.density(Double.POSITIVE_INFINITY);
                                                            assertTrue("Density at infinity should be positive infinity", 
                                                                      Double.isInfinite(resultForInfinity) && resultForInfinity > 0);
                                                            
                                                            // Test case with very small positive x
                                                            double resultForEpsilon = fDist.density(Double.MIN_VALUE);
                                                            assertTrue("Density at MIN_VALUE should be positive", 
                                                                      resultForEpsilon > 0 || 
                                                                      (Double.isInfinite(resultForEpsilon) && resultForEpsilon > 0));
                                                        }

    @Test
                                                    public void testDensityReturnsPositiveInfinity() {
                                                        // Create FDistribution with very large degrees of freedom
                                                        // to potentially cause overflow in calculations
                                                        double largeNumerator = Double.MAX_VALUE / 2;
                                                        double largeDenominator = Double.MAX_VALUE / 2;
                                                        FDistribution fDist = new FDistribution(largeNumerator, largeDenominator);
                                                        
                                                        // Use a value that would likely cause overflow in the calculations
                                                        double x = Double.MAX_VALUE;
                                                        
                                                        // The original method should return POSITIVE_INFINITY in this case
                                                        // The mutant would return MAX_VALUE instead
                                                        double result = fDist.density(x);
                                                        
                                                        // Assert that the result is exactly POSITIVE_INFINITY
                                                        // This will fail if the mutant (returning MAX_VALUE) is present
                                                        assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                                        
                                                        // Additional check to ensure it's not MAX_VALUE
                                                        assertTrue(Double.isInfinite(result));
                                                        assertFalse(result == Double.MAX_VALUE);
                                                    }

    @Test
                                                public void testDensityForExtremeValues() {
                                                    // Create FDistribution with some degrees of freedom
                                                    double numeratorDF = 10.0;
                                                    double denominatorDF = 20.0;
                                                    FDistribution fDist = new FDistribution(numeratorDF, denominatorDF);
                                                    
                                                    // Test with very large x value that would likely cause overflow
                                                    double extremeX = Double.MAX_VALUE;
                                                    
                                                    // Calculate actual result
                                                    double result = fDist.density(extremeX);
                                                    
                                                    // Verify the result is either POSITIVE_INFINITY (original) or MIN_VALUE (mutant)
                                                    // This assertion will fail if the mutant is present (returning MIN_VALUE)
                                                    assertTrue("Density for extreme values should be infinite", 
                                                              Double.isInfinite(result) && result > 0);
                                                    
                                                    // Additional check to ensure it's not MIN_VALUE
                                                    assertNotEquals("Density should not be MIN_VALUE", 
                                                                   Double.MIN_VALUE, result, 0.0);
                                                }

    @Test
                                            public void testDensityReturnsInfinityForEdgeCase() {
                                                // Create FDistribution with very small degrees of freedom
                                                // which can lead to infinite density
                                                FDistribution dist = new FDistribution(1e-10, 1e-10);
                                                
                                                // Test with x value that should produce infinite density
                                                double result = dist.density(1.0);
                                                
                                                // The original code would return POSITIVE_INFINITY,
                                                // while the mutant returns 0.0
                                                assertEquals("Density should be infinite for this edge case", 
                                                            Double.POSITIVE_INFINITY, result, 0.0);
                                            }

    @Test
                                            public void testDensityReturnsInfinityForLargeX() {
                                                // Create FDistribution with moderate degrees of freedom
                                                FDistribution dist = new FDistribution(5.0, 10.0);
                                                
                                                // Test with very large x value that should produce infinite density
                                                double result = dist.density(Double.MAX_VALUE);
                                                
                                                assertEquals("Density should be infinite for very large x", 
                                                            Double.POSITIVE_INFINITY, result, 0.0);
                                            }

    @Test
                                        public void testDensityReturnsPositiveInfinity1() {
                                            // Create FDistribution with small degrees of freedom to increase chance of infinite results
                                            FDistribution fDist = new FDistribution(1.0, 1.0);
                                            
                                            // Test with x approaching 0 from the right
                                            double result1 = fDist.density(Double.MIN_VALUE);
                                            assertEquals("Density should be positive infinity for very small x", 
                                                Double.POSITIVE_INFINITY, result1, 0.0);
                                                
                                            // Test with x approaching infinity
                                            double result2 = fDist.density(Double.MAX_VALUE);
                                            assertEquals("Density should be positive infinity for very large x", 
                                                Double.POSITIVE_INFINITY, result2, 0.0);
                                                
                                            // Test with x where numerator*X + denominator might cause overflow
                                            double result3 = fDist.density(Double.MAX_VALUE / 2);
                                            assertEquals("Density should be positive infinity for boundary calculations", 
                                                Double.POSITIVE_INFINITY, result3, 0.0);
                                        }

    @Test
                                    public void testDensityReturnsPositiveInfinityForEdgeCase() {
                                        // Create F-distribution with numerator degrees of freedom <= 2
                                        // to trigger infinite density at x=0
                                        FDistribution fDist = new FDistribution(1.5, 5.0);
                                        
                                        // Test with very small x value approaching 0
                                        double x = Double.MIN_VALUE;
                                        
                                        // The correct implementation should return POSITIVE_INFINITY,
                                        // while the mutant returns MAX_VALUE
                                        double result = fDist.density(x);
                                        
                                        // Assert that the result is indeed positive infinity
                                        assertTrue("Density should be POSITIVE_INFINITY for this case", 
                                                  Double.isInfinite(result));
                                        
                                        // Additional check to ensure it's positive infinity
                                        assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                    }

    @Test
                                public void testDensityDetectsAbsMutant() {
                                    // Setup test with known values
                                    double numeratorDof = 5.0;
                                    double denominatorDof = 10.0;
                                    double x = 2.0;
                                    FDistribution fd = new FDistribution(numeratorDof, denominatorDof);
                                    
                                    // Calculate expected value manually using the original formula
                                    double nhalf = numeratorDof / 2;
                                    double mhalf = denominatorDof / 2;
                                    double logx = FastMath.log(x);
                                    double logn = FastMath.log(numeratorDof);
                                    double logm = FastMath.log(denominatorDof);
                                    double lognxm = FastMath.log(numeratorDof * x + denominatorDof);
                                    double expected = FastMath.exp(nhalf * logn + nhalf * logx - logx +
                                                                 mhalf * logm - nhalf * lognxm - mhalf * lognxm -
                                                                 Beta.logBeta(nhalf, mhalf));
                                    
                                    // Call the method and verify
                                    double actual = fd.density(x);
                                    assertEquals("Density calculation should match expected value", 
                                                expected, actual, 1e-10);
                                    
                                    // Additional check to ensure it's not just returning denominatorDof
                                    assertNotEquals("Density should not equal denominator degrees of freedom",
                                                  denominatorDof, actual, 1e-10);
                                }

    @Test
                            public void testDensityReturnsPositiveInfinity2() {
                                // Create an F-distribution with degrees of freedom that would cause
                                // the density to approach infinity at certain points
                                double numeratorDF = 1.0;
                                double denominatorDF = 1.0;
                                FDistribution fDist = new FDistribution(numeratorDF, denominatorDF);
                                
                                // Test a value where the density should be positive infinity
                                // (for F-distribution with df1=1 and df2=1, density approaches infinity as x->0+)
                                double x = 1e-10; // very small positive value
                                
                                double result = fDist.density(x);
                                
                                // Verify the result is positive infinity
                                assertEquals("Density should be positive infinity for this case", 
                                            Double.POSITIVE_INFINITY, result, 0.0);
                            }

    @Test
                        public void testDensityReturnsInfinityForEdgeCase1() {
                            // Create F-distribution with very small numerator degrees of freedom
                            // and moderate denominator degrees of freedom
                            FDistribution fd = new FDistribution(1e-300, 2.0);
                            
                            // Test with large x value that should trigger infinity
                            double result = fd.density(Double.MAX_VALUE);
                            
                            // The original implementation should return infinity
                            // This will catch the mutant that returns Double.MAX_VALUE instead
                            assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                            
                            // Additional check to ensure it's not just a very large finite number
                            assertTrue(Double.isInfinite(result));
                        }

    @Test
                        public void testDensityReturnsInfinityForAnotherEdgeCase() {
                            // Another combination that should produce infinity
                            FDistribution fd = new FDistribution(1.0, 1.0);
                            
                            // Test with extremely large x value
                            double result = fd.density(Double.MAX_VALUE);
                            
                            assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                            assertTrue(Double.isInfinite(result));
                        }

    @Test
                    public void testDensityForInfiniteCase() {
                        // Create F-distribution with degrees of freedom that could lead to infinite density
                        // Using df1=1 and df2=1 as these often produce extreme values
                        FDistribution fd = new FDistribution(1.0, 1.0);
                        
                        // Test with very small x value where density might approach infinity
                        double x = 1e-20;
                        double density = fd.density(x);
                        
                        // The original implementation would return POSITIVE_INFINITY in some cases,
                        // while the mutant returns MIN_VALUE. We test that the value is large (not MIN_VALUE)
                        assertTrue("Density should be significantly larger than MIN_VALUE", 
                                  density > Double.MIN_VALUE * 1000);
                        
                        // Additionally, test that the value is positive and finite
                        assertTrue("Density should be positive", density > 0);
                        assertTrue("Density should be finite", Double.isFinite(density));
                        
                        // Test another boundary case
                        x = 1e-10;
                        density = fd.density(x);
                        assertTrue("Density should be significantly larger than MIN_VALUE", 
                                  density > Double.MIN_VALUE * 1000);
                    }

    @Test
                    public void testDensityForNormalCase() {
                        // Test with more normal parameters where we can expect finite values
                        FDistribution fd = new FDistribution(5.0, 10.0);
                        double x = 1.0;
                        double density = fd.density(x);
                        
                        // Verify the value is reasonable and not MIN_VALUE
                        assertTrue("Density should be reasonable positive value", 
                                  density > 0.01 && density < 1.0);
                        assertNotEquals("Density should not be MIN_VALUE", 
                                       Double.MIN_VALUE, density, 0.0);
                    }

    @Test
                public void testDensityReturnsInfinityForEdgeCase2() {
                    // Create F-distribution with small degrees of freedom
                    // to increase chance of infinite result
                    FDistribution fd = new FDistribution(1.0, 1.0);
                    
                    // Test with x approaching 0 (left edge case)
                    double result1 = fd.density(Double.MIN_VALUE);
                    assertTrue("Density should be infinite for very small x", 
                               Double.isInfinite(result1));
                    
                    // Test with x approaching infinity (right edge case)
                    double result2 = fd.density(Double.MAX_VALUE);
                    assertTrue("Density should be infinite for very large x",
                               Double.isInfinite(result2));
                    
                    // Test with x where numerator*X + denominator would overflow
                    double result3 = fd.density(Double.MAX_VALUE / 2);
                    assertTrue("Density should be infinite when calculation would overflow",
                               Double.isInfinite(result3));
                }

    @Test
            public void testDensityReturnsPositiveInfinity3() {
                // Create F-distribution with degrees of freedom that will cause density to approach infinity
                // When numerator df is small and denominator df is large, density at x=0 tends to infinity
                FDistribution fDist = new FDistribution(1.0, 1000000.0);
                
                // Test very small x value that should produce positive infinity
                double result = fDist.density(1e-100);
                
                // Verify we get positive infinity, not negative infinity
                assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
            }

    @Test
        public void testDensityReturnsInfinityForExtremeValues() {
            // Create F-distribution with small degrees of freedom
            // to increase chance of overflow/infinity
            FDistribution fd = new FDistribution(1.0, 1.0);
            
            // Test with very large x value that should cause overflow
            double result = fd.density(Double.MAX_VALUE);
            
            // The original implementation should return infinity,
            // while the mutant returns Double.MAX_VALUE
            assertEquals("Density should return infinity for extreme values", 
                        Double.POSITIVE_INFINITY, result, 0.0);
        }

    @Test
        public void testDensityReturnsInfinityForBoundaryCase() {
            // Another test case with parameters that likely cause overflow
            FDistribution fd = new FDistribution(0.5, 0.5);
            
            // Using a large but not extreme x value
            double result = fd.density(1e300);
            
            // Verify we get infinity, not MAX_VALUE
            assertEquals("Density should return infinity for boundary case",
                        Double.POSITIVE_INFINITY, result, 0.0);
        }

}
