package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import org.apache.commons.math.util.MathUtils;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                    public void testEquals_Reflexive() {
                        Complex complex = new Complex(1.0, 2.0);
                        assertTrue(complex.equals(complex));
                    }

    @Test
                    public void testEquals_NullComparison() {
                        Complex complex = new Complex(1.0, 2.0);
                        assertFalse(complex.equals(null));
                    }

    @Test
                    public void testEquals_DifferentClass() {
                        Complex complex = new Complex(1.0, 2.0);
                        Object other = new Object();
                        assertFalse(complex.equals(other));
                    }

    @Test
                    public void testEquals_EqualValues() {
                        Complex complex1 = new Complex(1.0, 2.0);
                        Complex complex2 = new Complex(1.0, 2.0);
                        assertTrue(complex1.equals(complex2));
                    }

    @Test
                    public void testEquals_DifferentRealValues() {
                        Complex complex1 = new Complex(1.0, 2.0);
                        Complex complex2 = new Complex(3.0, 2.0);
                        assertFalse(complex1.equals(complex2));
                    }

    @Test
                    public void testEquals_DifferentImaginaryValues() {
                        Complex complex1 = new Complex(1.0, 2.0);
                        Complex complex2 = new Complex(1.0, 3.0);
                        assertFalse(complex1.equals(complex2));
                    }

    @Test
                    public void testEquals_BothNaN() {
                        Complex complex1 = Complex.NaN;
                        Complex complex2 = Complex.NaN;
                        assertTrue(complex1.equals(complex2));
                    }

    @Test
                    public void testEquals_OneNaN() {
                        Complex complex1 = Complex.NaN;
                        Complex complex2 = new Complex(1.0, 2.0);
                        assertFalse(complex1.equals(complex2));
                        assertFalse(complex2.equals(complex1));
                    }

    @Test
                    public void testEquals_WithInfinity() {
                        Complex complex1 = Complex.INF;
                        Complex complex2 = Complex.INF;
                        Complex complex3 = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                        assertTrue(complex1.equals(complex2));
                        assertTrue(complex1.equals(complex3));
                    }

    @Test
                    public void testEquals_WithSpecialConstants() {
                        Complex complex1 = Complex.ONE;
                        Complex complex2 = new Complex(1.0, 0.0);
                        Complex complex3 = Complex.ZERO;
                        Complex complex4 = new Complex(0.0, 0.0);
                        Complex complex5 = Complex.I;
                        Complex complex6 = new Complex(0.0, 1.0);
                
                        assertTrue(complex1.equals(complex2));
                        assertTrue(complex3.equals(complex4));
                        assertTrue(complex5.equals(complex6));
                        assertFalse(complex1.equals(complex3));
                    }

    @Test
                    public void testEquals_SymmetricProperty() {
                        Complex complex1 = new Complex(1.0, 2.0);
                        Complex complex2 = new Complex(1.0, 2.0);
                        assertTrue(complex1.equals(complex2));
                        assertTrue(complex2.equals(complex1));
                    }

    @Test
                    public void testEquals_TransitiveProperty() {
                        Complex complex1 = new Complex(1.0, 2.0);
                        Complex complex2 = new Complex(1.0, 2.0);
                        Complex complex3 = new Complex(1.0, 2.0);
                        assertTrue(complex1.equals(complex2));
                        assertTrue(complex2.equals(complex3));
                        assertTrue(complex1.equals(complex3));
                    }

    @Test
                    public void testEquals_ConsistentResults() {
                        Complex complex1 = new Complex(1.0, 2.0);
                        Complex complex2 = new Complex(1.0, 2.0);
                        Complex complex3 = new Complex(3.0, 4.0);
                
                        // Multiple calls should return same result
                        assertTrue(complex1.equals(complex2));
                        assertTrue(complex1.equals(complex2));
                        assertFalse(complex1.equals(complex3));
                        assertFalse(complex1.equals(complex3));
                    }

    @Test
                public void testAbsWithNaN() {
                    // Create a NaN complex number
                    Complex nanComplex = new Complex(Double.NaN, Double.NaN);
                    
                    // Verify the isNaN() method returns true (important for the test)
                    assertTrue(nanComplex.isNaN());
                    
                    // Test the abs() method
                    double result = nanComplex.abs();
                    
                    // The correct behavior should return NaN
                    assertTrue(Double.isNaN(result));
                    
                    // The mutant would return a calculated value instead of NaN
                    // This assertion will fail if the mutant is present
                }

    @Test
                public void testAbsWithOneComponentNaN() {
                    // Test cases where only one component is NaN
                    Complex realNaN = new Complex(Double.NaN, 1.0);
                    Complex imagNaN = new Complex(1.0, Double.NaN);
                    
                    assertTrue(Double.isNaN(realNaN.abs()));
                    assertTrue(Double.isNaN(imagNaN.abs()));
                }

    @Test
            public void testAbs_NormalCaseRealLarger() {
                Complex c = new Complex(3.0, 4.0);
                double result = c.abs();
                assertEquals(5.0, result, 0.0001);
            }

    @Test
            public void testAbs_NormalCaseImaginaryLarger() {
                Complex c = new Complex(4.0, 3.0);
                double result = c.abs();
                assertEquals(5.0, result, 0.0001);
            }

    @Test
            public void testAbs_ZeroReal() {
                Complex c = new Complex(0.0, 5.0);
                double result = c.abs();
                assertEquals(5.0, result, 0.0001);
            }

    @Test
            public void testAbs_ZeroImaginary() {
                Complex c = new Complex(5.0, 0.0);
                double result = c.abs();
                assertEquals(5.0, result, 0.0001);
            }

    @Test
            public void testAbs_NaN() {
                Complex c = Complex.NaN;
                double result = c.abs();
                assertTrue(Double.isNaN(result));
            }

    @Test
            public void testAbs_Infinite() {
                Complex c = Complex.INF;
                double result = c.abs();
                assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
            }

    @Test
            public void testAbs_VerySmallNumbers() {
                Complex c = new Complex(Double.MIN_VALUE, Double.MIN_VALUE);
                double result = c.abs();
                double expected = Math.sqrt(2) * Double.MIN_VALUE;
                assertEquals(expected, result, 0.0001);
            }

    @Test
            public void testAbs_VeryLargeNumbers() {
                Complex c = new Complex(Double.MAX_VALUE, Double.MAX_VALUE);
                double result = c.abs();
                double expected = Math.sqrt(2) * Double.MAX_VALUE;
                assertEquals(expected, result, 0.0001 * Double.MAX_VALUE);
            }

    @Test
    public void testAbsHandlesClassCastException() {
        // Create a complex number that would trigger the exception
        Complex complex = new Complex(1.0, 2.0) {
            @Override
            public boolean isNaN() {
                return false;
            }
            
            @Override
            public boolean isInfinite() {
                return false;
            }
            
            @Override
            public double getReal() {
                // This will throw ClassCastException when unboxed
                return (Double)(Object)"not a double";
            }
        };
        
        try {
            complex.abs();
            fail("Expected ClassCastException to be thrown");
        } catch (ClassCastException e) {
            // Test passes - correct exception was thrown
            assertTrue(true);
        } catch (RuntimeException e) {
            // This would catch the mutant behavior
            fail("Caught RuntimeException instead of ClassCastException");
        }
    }

}
