package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import java.math.BigDecimal;
 
public class BigMatrixImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                        public void testOperate_ValidInput_CorrectMultiplication() {
                                                                                                                                                                                                                            // Setup 2x2 matrix
                                                                                                                                                                                                                            BigDecimal[][] matrixData = {
                                                                                                                                                                                                                                {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                                                                                                                                                                {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                                                                                                                                                                            };
                                                                                                                                                                                                                            BigMatrixImpl matrix = new BigMatrixImpl(matrixData);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test vector
                                                                                                                                                                                                                            BigDecimal[] vector = {
                                                                                                                                                                                                                                new BigDecimal("5.0"), 
                                                                                                                                                                                                                                new BigDecimal("6.0")
                                                                                                                                                                                                                            };
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Expected result: [1*5 + 2*6, 3*5 + 4*6] = [17, 39]
                                                                                                                                                                                                                            BigDecimal[] expected = {
                                                                                                                                                                                                                                new BigDecimal("17.0"),
                                                                                                                                                                                                                                new BigDecimal("39.0")
                                                                                                                                                                                                                            };
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            BigDecimal[] result = matrix.operate(vector);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            assertArrayEquals(expected, result);
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testOperate_DecimalValues_CorrectPrecision() {
                                                                                                                                                                                                                            // Setup 2x2 matrix with decimal values
                                                                                                                                                                                                                            BigDecimal[][] matrixData = {
                                                                                                                                                                                                                                {new BigDecimal("0.1"), new BigDecimal("0.2")},
                                                                                                                                                                                                                                {new BigDecimal("0.3"), new BigDecimal("0.4")}
                                                                                                                                                                                                                            };
                                                                                                                                                                                                                            BigMatrixImpl matrix = new BigMatrixImpl(matrixData);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            BigDecimal[] vector = {
                                                                                                                                                                                                                                new BigDecimal("0.5"), 
                                                                                                                                                                                                                                new BigDecimal("0.6")
                                                                                                                                                                                                                            };
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Expected result: [0.1*0.5 + 0.2*0.6, 0.3*0.5 + 0.4*0.6] = [0.17, 0.39]
                                                                                                                                                                                                                            BigDecimal[] expected = {
                                                                                                                                                                                                                                new BigDecimal("0.17"),
                                                                                                                                                                                                                                new BigDecimal("0.39")
                                                                                                                                                                                                                            };
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            BigDecimal[] result = matrix.operate(vector);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            assertArrayEquals(expected, result);
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testOperate_LargeMatrix_CorrectResult() {
                                                                                                                                                                                                                            // Setup 1x1000 matrix (edge case for large matrices)
                                                                                                                                                                                                                            int size = 1000;
                                                                                                                                                                                                                            BigDecimal[][] matrixData = new BigDecimal[1][size];
                                                                                                                                                                                                                            BigDecimal[] vector = new BigDecimal[size];
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            for (int i = 0; i < size; i++) {
                                                                                                                                                                                                                                matrixData[0][i] = new BigDecimal(i + 1);
                                                                                                                                                                                                                                vector[i] = new BigDecimal("1.0");
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            BigMatrixImpl matrix = new BigMatrixImpl(matrixData);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Expected result: sum of 1..1000 = 1000*1001/2 = 500500
                                                                                                                                                                                                                            BigDecimal[] expected = {
                                                                                                                                                                                                                                new BigDecimal("500500")
                                                                                                                                                                                                                            };
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            BigDecimal[] result = matrix.operate(vector);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            assertArrayEquals(expected, result);
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                public void testOperate_VectorWrongLength_ThrowsException() {
                                                                                                                                                                                                                    // Setup exception expectation
                                                                                                                                                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                    exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                    exception.expectMessage("vector has wrong length");
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Setup 2x3 matrix
                                                                                                                                                                                                                    BigDecimal[][] matrixData = {
                                                                                                                                                                                                                        {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                                                                                                                                                                                                        {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                                                                                                                                                                                                    };
                                                                                                                                                                                                                    BigMatrixImpl matrix = new BigMatrixImpl(matrixData);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Vector with wrong length (2 instead of 3)
                                                                                                                                                                                                                    BigDecimal[] vector = {
                                                                                                                                                                                                                        new BigDecimal("1.0"), 
                                                                                                                                                                                                                        new BigDecimal("2.0")
                                                                                                                                                                                                                    };
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    matrix.operate(vector);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testOperate_ZeroMatrix_ReturnsZeroVector() {
                                                                                                                                                                                                                    // Setup 2x2 zero matrix
                                                                                                                                                                                                                    BigDecimal[][] matrixData = {
                                                                                                                                                                                                                        {BigDecimal.ZERO, BigDecimal.ZERO},
                                                                                                                                                                                                                        {BigDecimal.ZERO, BigDecimal.ZERO}
                                                                                                                                                                                                                    };
                                                                                                                                                                                                                    BigMatrixImpl matrix = new BigMatrixImpl(matrixData);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    BigDecimal[] vector = {
                                                                                                                                                                                                                        new BigDecimal("5.0"), 
                                                                                                                                                                                                                        new BigDecimal("6.0")
                                                                                                                                                                                                                    };
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    BigDecimal[] expected = {
                                                                                                                                                                                                                        BigDecimal.ZERO,
                                                                                                                                                                                                                        BigDecimal.ZERO
                                                                                                                                                                                                                    };
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    BigDecimal[] result = matrix.operate(vector);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    assertArrayEquals(expected, result);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testOperate_IdentityMatrix_ReturnsSameVector() {
                                                                                                                                                                                                                    // Define constants
                                                                                                                                                                                                                    final BigDecimal ONE = BigDecimal.ONE;
                                                                                                                                                                                                                    final BigDecimal ZERO = BigDecimal.ZERO;
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Setup 3x3 identity matrix
                                                                                                                                                                                                                    BigDecimal[][] matrixData = {
                                                                                                                                                                                                                        {ONE, ZERO, ZERO},
                                                                                                                                                                                                                        {ZERO, ONE, ZERO},
                                                                                                                                                                                                                        {ZERO, ZERO, ONE}
                                                                                                                                                                                                                    };
                                                                                                                                                                                                                    BigMatrixImpl matrix = new BigMatrixImpl(matrixData);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    BigDecimal[] vector = {
                                                                                                                                                                                                                        new BigDecimal("1.0"),
                                                                                                                                                                                                                        new BigDecimal("2.0"),
                                                                                                                                                                                                                        new BigDecimal("3.0")
                                                                                                                                                                                                                    };
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    BigDecimal[] result = matrix.operate(vector);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    assertArrayEquals(vector, result);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testOperate_ValidInput() {
                                                                                                                                                                                                                    // Create a matrix instance for testing
                                                                                                                                                                                                                    double[][] data = {{1.0, 2.0}, {3.0, 4.0}};
                                                                                                                                                                                                                    BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    double[] input = {1.5, 2.5};
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Mock the internal operate(BigDecimal[]) method to return expected result
                                                                                                                                                                                                                    BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                                                                                                                                    BigDecimal[] expectedResult = {new BigDecimal("6.5"), new BigDecimal("14.5")};
                                                                                                                                                                                                                    doReturn(expectedResult).when(spyMatrix).operate(any(BigDecimal[].class));
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    BigDecimal[] result = spyMatrix.operate(input);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    assertNotNull(result);
                                                                                                                                                                                                                    assertEquals(2, result.length);
                                                                                                                                                                                                                    verify(spyMatrix).operate(any(BigDecimal[].class));
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testOperate_EmptyArray() {
                                                                                                                                                                                                                    double[] emptyInput = {};
                                                                                                                                                                                                                    BigMatrixImpl matrix = new BigMatrixImpl();
                                                                                                                                                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                    matrix.operate(emptyInput);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testOperate_WithNaNValues() {
                                                                                                                                                                                                                    double[] inputWithNaN = {1.5, Double.NaN};
                                                                                                                                                                                                                    BigMatrixImpl matrix = new BigMatrixImpl(); // Initialize matrix
                                                                                                                                                                                                                    ExpectedException exception = ExpectedException.none(); // Initialize exception handler
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    exception.expect(NumberFormatException.class);
                                                                                                                                                                                                                    matrix.operate(inputWithNaN);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testOperate_WithInfiniteValues() {
                                                                                                                                                                                                                    // Initialize matrix with some data
                                                                                                                                                                                                                    double[][] data = {{1.0, 2.0}, {3.0, 4.0}};
                                                                                                                                                                                                                    BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    double[] inputWithInfinity = {1.5, Double.POSITIVE_INFINITY};
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Setup expected exception
                                                                                                                                                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                    exception.expect(NumberFormatException.class);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    matrix.operate(inputWithInfinity);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testOperate_DimensionMismatch() {
                                                                                                                                                                                                                    // Create a 3x3 matrix
                                                                                                                                                                                                                    BigDecimal[][] testData = {
                                                                                                                                                                                                                        {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                                                                                                                                                                                                        {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")},
                                                                                                                                                                                                                        {new BigDecimal("7.0"), new BigDecimal("8.0"), new BigDecimal("9.0")}
                                                                                                                                                                                                                    };
                                                                                                                                                                                                                    BigMatrixImpl matrix3x3 = new BigMatrixImpl(testData);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Try to operate with 2-element vector
                                                                                                                                                                                                                    double[] input = {1.0, 2.0};
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Set up expected exception
                                                                                                                                                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                    exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                    matrix3x3.operate(input);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                            public void testOperate_NullInput() {
                                                                                                                                                                                                                BigMatrixImpl matrix = new BigMatrixImpl();
                                                                                                                                                                                                                ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                exception.expect(NullPointerException.class);
                                                                                                                                                                                                                matrix.operate((BigDecimal[]) null);
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                            public void testOperate_PrecisionConversion() {
                                                                                                                                                                                                                // Create a test matrix
                                                                                                                                                                                                                BigMatrixImpl matrix = new BigMatrixImpl(new double[][]{{1.0, 2.0}, {3.0, 4.0}});
                                                                                                                                                                                                                
                                                                                                                                                                                                                double[] input = {1.23456789, 9.87654321};
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Mock the internal operate method
                                                                                                                                                                                                                BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                                                                                                                                BigDecimal[] expectedResult = {new BigDecimal("20.98765432"), new BigDecimal("43.20987654")};
                                                                                                                                                                                                                doReturn(expectedResult).when(spyMatrix).operate(any(BigDecimal[].class));
                                                                                                                                                                                                                
                                                                                                                                                                                                                BigDecimal[] result = spyMatrix.operate(input);
                                                                                                                                                                                                                
                                                                                                                                                                                                                assertNotNull(result);
                                                                                                                                                                                                                assertEquals(2, result.length);
                                                                                                                                                                                                                // Verify the conversion maintains precision
                                                                                                                                                                                                                verify(spyMatrix).operate(argThat((BigDecimal[] bdArray) -> 
                                                                                                                                                                                                                    bdArray[0].doubleValue() == 1.23456789 &&
                                                                                                                                                                                                                    bdArray[1].doubleValue() == 9.87654321
                                                                                                                                                                                                                ));
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                        public void testOperate_NullInput_ThrowsException() {
                                                                                                                                                                                                            ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                            
                                                                                                                                                                                                            BigDecimal one = new BigDecimal("1");
                                                                                                                                                                                                            BigDecimal zero = new BigDecimal("0");
                                                                                                                                                                                                            
                                                                                                                                                                                                            BigDecimal[][] matrixData = {
                                                                                                                                                                                                                {one, zero},
                                                                                                                                                                                                                {zero, one}
                                                                                                                                                                                                            };
                                                                                                                                                                                                            BigMatrixImpl matrix = new BigMatrixImpl(matrixData);
                                                                                                                                                                                                            
                                                                                                                                                                                                            exception.expect(NullPointerException.class);
                                                                                                                                                                                                            matrix.operate((BigDecimal[])null);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                        public void testCopyDetectsCoordinateValidationMutant() {
                                                                                                                                                                                                            // Create a 2x2 matrix for testing
                                                                                                                                                                                                            BigDecimal[][] testData = {
                                                                                                                                                                                                                {new BigDecimal("1"), new BigDecimal("2")},
                                                                                                                                                                                                                {new BigDecimal("3"), new BigDecimal("4")}
                                                                                                                                                                                                            };
                                                                                                                                                                                                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test that copy works with valid coordinates (original behavior)
                                                                                                                                                                                                            try {
                                                                                                                                                                                                                BigMatrix copy = matrix.copy();
                                                                                                                                                                                                                assertNotNull(copy);
                                                                                                                                                                                                                assertEquals(2, copy.getRowDimension());
                                                                                                                                                                                                                assertEquals(2, copy.getColumnDimension());
                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                fail("Valid copy operation should not throw exception");
                                                                                                                                                                                                            }
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test behavior with invalid coordinates
                                                                                                                                                                                                            try {
                                                                                                                                                                                                                // Try to get a row with invalid index (should throw exception)
                                                                                                                                                                                                                matrix.getRow(-1);
                                                                                                                                                                                                                fail("Should have thrown exception for invalid row");
                                                                                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                // Expected behavior for original code
                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                fail("Wrong exception type thrown for invalid row");
                                                                                                                                                                                                            }
                                                                                                                                                                                                            
                                                                                                                                                                                                            try {
                                                                                                                                                                                                                // Try to get a column with invalid index (should throw exception)
                                                                                                                                                                                                                matrix.getColumn(100);
                                                                                                                                                                                                                fail("Should have thrown exception for invalid column");
                                                                                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                // Expected behavior for original code
                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                fail("Wrong exception type thrown for invalid column");
                                                                                                                                                                                                            }
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                public void testGetColumnWithMutatedValidation() {
                                                                                                                                                                                                    // Create a test matrix with 2 rows and 2 columns
                                                                                                                                                                                                    BigDecimal[][] testData = {
                                                                                                                                                                                                        {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                                                                                                                                        {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                                                                                                                                                    };
                                                                                                                                                                                                    BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Test getting the first column (column 0)
                                                                                                                                                                                                    BigDecimal[] column0 = matrix.getColumn(0);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify the column data is correct
                                                                                                                                                                                                    assertEquals(2, column0.length);
                                                                                                                                                                                                    assertEquals(new BigDecimal("1.0"), column0[0]);
                                                                                                                                                                                                    assertEquals(new BigDecimal("3.0"), column0[1]);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Also test edge case of single column matrix
                                                                                                                                                                                                    BigDecimal[][] singleColumnData = {
                                                                                                                                                                                                        {new BigDecimal("1.0")},
                                                                                                                                                                                                        {new BigDecimal("2.0")}
                                                                                                                                                                                                    };
                                                                                                                                                                                                    BigMatrixImpl singleColumnMatrix = new BigMatrixImpl(singleColumnData);
                                                                                                                                                                                                    BigDecimal[] singleColumn = singleColumnMatrix.getColumn(0);
                                                                                                                                                                                                    
                                                                                                                                                                                                    assertEquals(2, singleColumn.length);
                                                                                                                                                                                                    assertEquals(new BigDecimal("1.0"), singleColumn[0]);
                                                                                                                                                                                                    assertEquals(new BigDecimal("2.0"), singleColumn[1]);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // The mutant would fail these tests because it validates column 1 instead of 0,
                                                                                                                                                                                                    // potentially causing incorrect validation when accessing column 0
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testCopyThrowsCorrectRowExceptionMessage() {
                                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                                    BigDecimal[][] testData = {
                                                                                                                                                                                                        {new BigDecimal("1"), new BigDecimal("2")},
                                                                                                                                                                                                        {new BigDecimal("3"), new BigDecimal("4")}
                                                                                                                                                                                                    };
                                                                                                                                                                                                    BigMatrixImpl matrix = new BigMatrixImpl(testData, false);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Mock behavior to throw exception when accessing invalid row
                                                                                                                                                                                                    BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                                                                                                                    when(spyMatrix.getEntry(anyInt(), anyInt())).thenThrow(
                                                                                                                                                                                                        new MatrixIndexException("illegal row argument"));
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Set expectation for exception
                                                                                                                                                                                                    thrown.expect(MatrixIndexException.class);
                                                                                                                                                                                                    thrown.expectMessage("illegal row argument");
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Trigger the exception
                                                                                                                                                                                                    spyMatrix.getEntry(2, 0); // Invalid row index
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                        public void testCopyWithNonSquareMatrixDetectsColumnDimensionMutant() {
                                                                                                                                                                                            // Create a non-square matrix (2 rows, 3 columns)
                                                                                                                                                                                            BigDecimal[][] testData = new BigDecimal[][] {
                                                                                                                                                                                                {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                                                                                                                                                                                                {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")}
                                                                                                                                                                                            };
                                                                                                                                                                                            BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                                                                                                            
                                                                                                                                                                                            // Make the copy
                                                                                                                                                                                            BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify dimensions - this would fail with the mutant
                                                                                                                                                                                            assertEquals("Row dimension should match", 
                                                                                                                                                                                                         original.getRowDimension(), copy.getRowDimension());
                                                                                                                                                                                            assertEquals("Column dimension should match", 
                                                                                                                                                                                                         original.getColumnDimension(), copy.getColumnDimension());
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify all elements are correctly copied
                                                                                                                                                                                            for (int i = 0; i < original.getRowDimension(); i++) {
                                                                                                                                                                                                for (int j = 0; j < original.getColumnDimension(); j++) {
                                                                                                                                                                                                    assertEquals("Element at [" + i + "][" + j + "] should match",
                                                                                                                                                                                                                 original.getEntry(i, j), copy.getEntry(i, j));
                                                                                                                                                                                                }
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            // Additional check that data array structure is correct
                                                                                                                                                                                            BigDecimal[][] copiedData = copy.getData();
                                                                                                                                                                                            assertEquals("Number of rows in data array should match", 
                                                                                                                                                                                                         original.getRowDimension(), copiedData.length);
                                                                                                                                                                                            assertEquals("Number of columns in first row should match", 
                                                                                                                                                                                                         original.getColumnDimension(), copiedData[0].length);
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                    public void testCopyPreservesColumnDimension() {
                                                                                                                                                                                        // Create a matrix with known dimensions (2x3)
                                                                                                                                                                                        BigDecimal[][] testData = {
                                                                                                                                                                                            {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                                                                                                                                                                                            {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")}
                                                                                                                                                                                        };
                                                                                                                                                                                        BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                                                                                                        
                                                                                                                                                                                        // Make a copy
                                                                                                                                                                                        BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                                                                                                                        
                                                                                                                                                                                        // Verify column dimension is preserved
                                                                                                                                                                                        assertEquals("Column dimension should be preserved in copy", 
                                                                                                                                                                                                    original.getColumnDimension(), 
                                                                                                                                                                                                    copy.getColumnDimension());
                                                                                                                                                                                        
                                                                                                                                                                                        // Additional check to ensure the data structure is intact
                                                                                                                                                                                        assertEquals("First column first row should match", 
                                                                                                                                                                                                    original.getEntry(0, 0), 
                                                                                                                                                                                                    copy.getEntry(0, 0));
                                                                                                                                                                                        assertEquals("Last column last row should match", 
                                                                                                                                                                                                    original.getEntry(1, 2), 
                                                                                                                                                                                                    copy.getEntry(1, 2));
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                public void testCopyDetectsColumnDimensionMutation() {
                                                                                                                                                                                    // Create a test matrix with known dimensions
                                                                                                                                                                                    BigDecimal[][] testData = {
                                                                                                                                                                                        {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                                                                                                                        {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                                                                                                                                    };
                                                                                                                                                                                    BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                                                                                                    
                                                                                                                                                                                    // Make a copy
                                                                                                                                                                                    BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify dimensions match
                                                                                                                                                                                    assertEquals("Row dimension should match", 
                                                                                                                                                                                                 original.getRowDimension(), copy.getRowDimension());
                                                                                                                                                                                    assertEquals("Column dimension should match", 
                                                                                                                                                                                                 original.getColumnDimension(), copy.getColumnDimension());
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify data integrity by checking last column values
                                                                                                                                                                                    for (int i = 0; i < original.getRowDimension(); i++) {
                                                                                                                                                                                        BigDecimal originalValue = original.getEntry(i, original.getColumnDimension() - 1);
                                                                                                                                                                                        BigDecimal copyValue = copy.getEntry(i, copy.getColumnDimension() - 1);
                                                                                                                                                                                        assertEquals("Last column values should match", originalValue, copyValue);
                                                                                                                                                                                    }
                                                                                                                                                                                    
                                                                                                                                                                                    // Try to access what would be the mutated column (should throw ArrayIndexOutOfBounds)
                                                                                                                                                                                    try {
                                                                                                                                                                                        copy.getEntry(0, original.getColumnDimension()); // This should be out of bounds
                                                                                                                                                                                        fail("Should have thrown ArrayIndexOutOfBoundsException for mutated column dimension");
                                                                                                                                                                                    } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                                                                        // Expected behavior
                                                                                                                                                                                    }
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testCopyDetectsMutatedLoopCondition() {
                                                                                                                                                                                    // Create a simple 1x1 matrix that would expose the boundary condition
                                                                                                                                                                                    BigDecimal[][] testData = {{BigDecimal.ONE}};
                                                                                                                                                                                    BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                                                                                                    
                                                                                                                                                                                    try {
                                                                                                                                                                                        // This should throw ArrayIndexOutOfBoundsException if the mutant is present
                                                                                                                                                                                        BigMatrix copy = original.copy();
                                                                                                                                                                                        
                                                                                                                                                                                        // If we get here, the original behavior is correct
                                                                                                                                                                                        // Verify the copy is not null and is a proper copy
                                                                                                                                                                                        assertNotNull(copy);
                                                                                                                                                                                        assertEquals(original.getRowDimension(), copy.getRowDimension());
                                                                                                                                                                                        assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                                                                                                                                                                                        assertEquals(original.getEntry(0, 0), copy.getEntry(0, 0));
                                                                                                                                                                                    } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                                                                        // This indicates the mutant was detected
                                                                                                                                                                                        fail("Mutant detected: copy operation threw ArrayIndexOutOfBoundsException");
                                                                                                                                                                                    }
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testCopyWithLargerMatrixDetectsMutant() {
                                                                                                                                                                                    // Create a 2x2 matrix for more thorough testing
                                                                                                                                                                                    BigDecimal[][] testData = {
                                                                                                                                                                                        {BigDecimal.ONE, BigDecimal.ZERO},
                                                                                                                                                                                        {BigDecimal.ZERO, BigDecimal.ONE}
                                                                                                                                                                                    };
                                                                                                                                                                                    BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                                                                                                    
                                                                                                                                                                                    try {
                                                                                                                                                                                        BigMatrix copy = original.copy();
                                                                                                                                                                                        
                                                                                                                                                                                        // Verify the copy is correct
                                                                                                                                                                                        assertNotNull(copy);
                                                                                                                                                                                        assertEquals(2, copy.getRowDimension());
                                                                                                                                                                                        assertEquals(2, copy.getColumnDimension());
                                                                                                                                                                                        for (int i = 0; i < 2; i++) {
                                                                                                                                                                                            for (int j = 0; j < 2; j++) {
                                                                                                                                                                                                assertEquals(original.getEntry(i, j), copy.getEntry(i, j));
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                                                                        fail("Mutant detected: copy operation threw ArrayIndexOutOfBoundsException");
                                                                                                                                                                                    }
                                                                                                                                                                                }

    @Test
                                                                                                                                                                    public void testCopyPreservesAllColumns() {
                                                                                                                                                                        // Create a 2x2 test matrix with distinct values in each column
                                                                                                                                                                        BigDecimal[][] testData = new BigDecimal[][] {
                                                                                                                                                                            {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                                                                                                            {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                                                                                                                        };
                                                                                                                                                                        
                                                                                                                                                                        BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                                                                                        BigMatrix copy = original.copy();
                                                                                                                                                                        
                                                                                                                                                                        // Verify all columns are preserved in the copy
                                                                                                                                                                        assertEquals("First column first row not preserved", 
                                                                                                                                                                            new BigDecimal("1.0"), copy.getEntry(0, 0));
                                                                                                                                                                        assertEquals("First column second row not preserved", 
                                                                                                                                                                            new BigDecimal("3.0"), copy.getEntry(1, 0));
                                                                                                                                                                        assertEquals("Second column first row not preserved", 
                                                                                                                                                                            new BigDecimal("2.0"), copy.getEntry(0, 1));
                                                                                                                                                                        assertEquals("Second column second row not preserved", 
                                                                                                                                                                            new BigDecimal("4.0"), copy.getEntry(1, 1));
                                                                                                                                                                        
                                                                                                                                                                        // Also verify dimensions match
                                                                                                                                                                        assertEquals("Row dimension mismatch", 
                                                                                                                                                                            original.getRowDimension(), copy.getRowDimension());
                                                                                                                                                                        assertEquals("Column dimension mismatch", 
                                                                                                                                                                            original.getColumnDimension(), copy.getColumnDimension());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testCopyMaintainsMatrixStructure() {
                                                                                                                                                                        // Create a non-square 2x3 test matrix
                                                                                                                                                                        BigDecimal[][] testData = {
                                                                                                                                                                            {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                                                                                                                                                                            {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")}
                                                                                                                                                                        };
                                                                                                                                                                        
                                                                                                                                                                        BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                                                                                        BigMatrixImpl copy = (BigMatrixImpl) original.copy();
                                                                                                                                                                        
                                                                                                                                                                        // Verify dimensions are maintained
                                                                                                                                                                        assertEquals(original.getRowDimension(), copy.getRowDimension());
                                                                                                                                                                        assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                                                                                                                                                                        
                                                                                                                                                                        // Verify exact values are in correct positions
                                                                                                                                                                        for (int i = 0; i < testData.length; i++) {
                                                                                                                                                                            for (int j = 0; j < testData[0].length; j++) {
                                                                                                                                                                                assertEquals(
                                                                                                                                                                                    "Value at position ["+i+"]["+j+"] should match",
                                                                                                                                                                                    original.getEntry(i, j),
                                                                                                                                                                                    copy.getEntry(i, j)
                                                                                                                                                                                );
                                                                                                                                                                            }
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        // Additional check: verify a specific value is in correct position
                                                                                                                                                                        // This would fail with the mutant as values would be transposed
                                                                                                                                                                        assertEquals(new BigDecimal("5"), copy.getEntry(1, 1));
                                                                                                                                                                    }

    @Test
                                                                                                                                                            public void testCopyPreservesDecimalPrecision() {
                                                                                                                                                                // Create a matrix with non-integer values
                                                                                                                                                                BigDecimal[][] testData = {
                                                                                                                                                                    {new BigDecimal("1.23"), new BigDecimal("4.56")},
                                                                                                                                                                    {new BigDecimal("7.89"), new BigDecimal("0.12")}
                                                                                                                                                                };
                                                                                                                                                                BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                                                                                
                                                                                                                                                                // Make a copy
                                                                                                                                                                BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                                                                                                
                                                                                                                                                                // Verify decimal precision is preserved in the copy
                                                                                                                                                                BigDecimal[][] copiedData = copy.getData();
                                                                                                                                                                assertEquals(1.23, copiedData[0][0].doubleValue(), 0.0001);
                                                                                                                                                                assertEquals(4.56, copiedData[0][1].doubleValue(), 0.0001);
                                                                                                                                                                assertEquals(7.89, copiedData[1][0].doubleValue(), 0.0001);
                                                                                                                                                                assertEquals(0.12, copiedData[1][1].doubleValue(), 0.0001);
                                                                                                                                                                
                                                                                                                                                                // Also verify the values are exactly equal as BigDecimals
                                                                                                                                                                assertEquals(new BigDecimal("1.23"), copiedData[0][0]);
                                                                                                                                                                assertEquals(new BigDecimal("4.56"), copiedData[0][1]);
                                                                                                                                                                assertEquals(new BigDecimal("7.89"), copiedData[1][0]);
                                                                                                                                                                assertEquals(new BigDecimal("0.12"), copiedData[1][1]);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testCopyPreservesDataValues() {
                                                                                                                                                                // Create original matrix with known values
                                                                                                                                                                BigDecimal[][] originalData = {
                                                                                                                                                                    {new BigDecimal("1.5"), new BigDecimal("2.5")},
                                                                                                                                                                    {new BigDecimal("3.5"), new BigDecimal("4.5")}
                                                                                                                                                                };
                                                                                                                                                                BigMatrixImpl original = new BigMatrixImpl(originalData);
                                                                                                                                                                
                                                                                                                                                                // Create copy
                                                                                                                                                                BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                                                                                                
                                                                                                                                                                // Verify dimensions match
                                                                                                                                                                assertEquals(original.getRowDimension(), copy.getRowDimension());
                                                                                                                                                                assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                                                                                                                                                                
                                                                                                                                                                // Verify all values are preserved in the copy
                                                                                                                                                                for (int i = 0; i < original.getRowDimension(); i++) {
                                                                                                                                                                    for (int j = 0; j < original.getColumnDimension(); j++) {
                                                                                                                                                                        assertEquals(
                                                                                                                                                                            original.getEntry(i, j).doubleValue(),
                                                                                                                                                                            copy.getEntry(i, j).doubleValue(),
                                                                                                                                                                            0.000001
                                                                                                                                                                        );
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                                
                                                                                                                                                                // Additional check using getDataAsDoubleArray
                                                                                                                                                                double[][] originalDoubleData = original.getDataAsDoubleArray();
                                                                                                                                                                double[][] copiedDoubleData = copy.getDataAsDoubleArray();
                                                                                                                                                                assertArrayEquals(originalDoubleData, copiedDoubleData);
                                                                                                                                                            }

    @Test
                                                                                                                                                        public void testCopyDetectsMutatedDoubleValue() {
                                                                                                                                                            // Create original matrix with known values
                                                                                                                                                            BigDecimal[][] originalData = {
                                                                                                                                                                {new BigDecimal("1.5"), new BigDecimal("2.5")},
                                                                                                                                                                {new BigDecimal("3.5"), new BigDecimal("4.5")}
                                                                                                                                                            };
                                                                                                                                                            BigMatrixImpl original = new BigMatrixImpl(originalData);
                                                                                                                                                            
                                                                                                                                                            // Create copy
                                                                                                                                                            BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                                                                                            
                                                                                                                                                            // Verify dimensions match
                                                                                                                                                            assertEquals(original.getRowDimension(), copy.getRowDimension());
                                                                                                                                                            assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                                                                                                                                                            
                                                                                                                                                            // Verify all values match exactly
                                                                                                                                                            for (int i = 0; i < original.getRowDimension(); i++) {
                                                                                                                                                                for (int j = 0; j < original.getColumnDimension(); j++) {
                                                                                                                                                                    assertEquals(original.getEntryAsDouble(i, j), copy.getEntryAsDouble(i, j), 0.000001);
                                                                                                                                                                    // The mutant will fail here because all values will be original + 1
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Also verify via getDataAsDoubleArray
                                                                                                                                                            double[][] originalDoubleData = original.getDataAsDoubleArray();
                                                                                                                                                            double[][] copyDoubleData = copy.getDataAsDoubleArray();
                                                                                                                                                            assertArrayEquals(originalDoubleData, copyDoubleData);
                                                                                                                                                        }

    @Test
                                                                                                                                            public void testCopyReturnsNonNullMatrix() {
                                                                                                                                                // Create a sample matrix
                                                                                                                                                BigDecimal[][] testData = {
                                                                                                                                                    {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                                                                                    {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                                                                                                };
                                                                                                                                                BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                                                                
                                                                                                                                                // Call the copy method - now using BigMatrix interface type
                                                                                                                                                BigMatrix copy = original.copy();
                                                                                                                                                
                                                                                                                                                // Verify the copy is not null (this would catch the mutant)
                                                                                                                                                assertNotNull("Copy should not be null", copy);
                                                                                                                                                
                                                                                                                                                // Additional checks to ensure proper copying behavior
                                                                                                                                                assertNotSame("Copy should be a different instance", original, copy);
                                                                                                                                                
                                                                                                                                                // Verify the content matches
                                                                                                                                                assertEquals("Row dimension should match", 
                                                                                                                                                    original.getRowDimension(), copy.getRowDimension());
                                                                                                                                                assertEquals("Column dimension should match", 
                                                                                                                                                    original.getColumnDimension(), copy.getColumnDimension());
                                                                                                                                                    
                                                                                                                                                for (int i = 0; i < original.getRowDimension(); i++) {
                                                                                                                                                    for (int j = 0; j < original.getColumnDimension(); j++) {
                                                                                                                                                        assertEquals("Matrix entry should match", 
                                                                                                                                                            original.getEntry(i, j), copy.getEntry(i, j));
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }

    @Test
                                                                                                                                            public void testCopyPreservesData() {
                                                                                                                                                // Create original matrix with test data
                                                                                                                                                BigDecimal[][] testData = {
                                                                                                                                                    {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                                                                                    {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                                                                                                };
                                                                                                                                                BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                                                                
                                                                                                                                                // Create copy
                                                                                                                                                BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                                                                                
                                                                                                                                                // Verify dimensions match
                                                                                                                                                assertEquals(original.getRowDimension(), copy.getRowDimension());
                                                                                                                                                assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                                                                                                                                                
                                                                                                                                                // Verify data matches
                                                                                                                                                for (int i = 0; i < original.getRowDimension(); i++) {
                                                                                                                                                    for (int j = 0; j < original.getColumnDimension(); j++) {
                                                                                                                                                        assertEquals(original.getEntry(i, j), copy.getEntry(i, j));
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Additional check using getData()
                                                                                                                                                assertArrayEquals(original.getData(), copy.getData());
                                                                                                                                            }

    @Test
                                                                                                                                        public void testCopyWithInvalidRowShouldNotThrowException() {
                                                                                                                                            // Create a test matrix
                                                                                                                                            BigDecimal[][] testData = {
                                                                                                                                                {new BigDecimal("1"), new BigDecimal("2")},
                                                                                                                                                {new BigDecimal("3"), new BigDecimal("4")}
                                                                                                                                            };
                                                                                                                                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                                                                                            
                                                                                                                                            // Force an invalid row access by mocking copyOut behavior
                                                                                                                                            // In original code, this should be handled properly
                                                                                                                                            try {
                                                                                                                                                BigMatrix copy = matrix.copy();
                                                                                                                                                assertNotNull(copy);
                                                                                                                                                // Verify the copy contains the same data
                                                                                                                                                BigDecimal[][] copiedData = ((BigMatrixImpl)copy).getData();
                                                                                                                                                assertArrayEquals(testData, copiedData);
                                                                                                                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                                fail("Original code should handle invalid coordinates properly");
                                                                                                                                            }
                                                                                                                                        }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                                                                                                        public void testMutatedCopyWithInvalidRowShouldThrowException() {
                                                                                                                                            // This test would catch the mutant by expecting an exception
                                                                                                                                            // when the mutated code processes invalid coordinates incorrectly
                                                                                                                                            
                                                                                                                                            // Create a test matrix
                                                                                                                                            BigDecimal[][] testData = {
                                                                                                                                                {new BigDecimal("1"), new BigDecimal("2")},
                                                                                                                                                {new BigDecimal("3"), new BigDecimal("4")}
                                                                                                                                            };
                                                                                                                                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                                                                                            
                                                                                                                                            // Mock the copyOut method to return data that would trigger invalid coordinate
                                                                                                                                            // In mutated code, this should throw ArrayIndexOutOfBoundsException
                                                                                                                                            matrix.copy();
                                                                                                                                        }

    @Test
                                                                                                                                    public void testCopyDetectsInvalidRowAtColumnZero() {
                                                                                                                                        // Create a test matrix with 2 rows and 2 columns
                                                                                                                                        BigDecimal[][] testData = new BigDecimal[2][2];
                                                                                                                                        testData[0][0] = BigDecimal.ONE;
                                                                                                                                        testData[0][1] = BigDecimal.ONE;
                                                                                                                                        testData[1][0] = null;  // Invalid at column 0
                                                                                                                                        testData[1][1] = BigDecimal.ONE;  // Valid at column 1
                                                                                                                                        
                                                                                                                                        // Create the original matrix
                                                                                                                                        BigMatrixImpl original = new BigMatrixImpl(testData, false);
                                                                                                                                        
                                                                                                                                        try {
                                                                                                                                            // Attempt to make a copy - should fail due to invalid coordinate at column 0
                                                                                                                                            original.copy();
                                                                                                                                            fail("Expected an exception to be thrown for invalid coordinate");
                                                                                                                                        } catch (Exception e) {
                                                                                                                                            // Verify the correct exception is thrown
                                                                                                                                            assertTrue("Expected exception for invalid coordinate", 
                                                                                                                                                      e instanceof IllegalArgumentException || 
                                                                                                                                                      e instanceof NullPointerException);
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        // If the test reaches here without failing, it means the mutant survived
                                                                                                                                        // because it only checks column 1 (which is valid) instead of column 0
                                                                                                                                    }

    @Test
                                                                                                                        public void testCopyWithInvalidRowThrowsCorrectException() {
                                                                                                                            // Setup
                                                                                                                            BigDecimal[][] testData = {{BigDecimal.ONE, BigDecimal.ZERO}, {BigDecimal.ZERO, BigDecimal.ONE}};
                                                                                                                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                                                                            
                                                                                                                            // Use reflection to access private copyOut method
                                                                                                                            try {
                                                                                                                                Method copyOutMethod = BigMatrixImpl.class.getDeclaredMethod("copyOut");
                                                                                                                                copyOutMethod.setAccessible(true);
                                                                                                                                
                                                                                                                                // Create a spy and make copyOut throw exception
                                                                                                                                BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                                                doThrow(new MatrixIndexException("illegal row argument")).when(spyMatrix).copy();
                                                                                                                                
                                                                                                                                // Expect exception
                                                                                                                                thrown.expect(MatrixIndexException.class);
                                                                                                                                thrown.expectMessage("illegal row argument");
                                                                                                                                
                                                                                                                                // Test
                                                                                                                                spyMatrix.copy();
                                                                                                                            } catch (NoSuchMethodException e) {
                                                                                                                                fail("Failed to access private copyOut method");
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                                                                        public void testCopyWithInvalidColumnThrowsCorrectException() {
                                                                                                                            // Setup
                                                                                                                            BigDecimal[][] testData = {{BigDecimal.ONE, BigDecimal.ZERO}, {BigDecimal.ZERO, BigDecimal.ONE}};
                                                                                                                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                                                                            
                                                                                                                            // Create a spy of the matrix
                                                                                                                            BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                                            
                                                                                                                            // Instead of trying to mock private copyOut(), we'll make the matrix throw exception when accessed
                                                                                                                            // We'll use doThrow to simulate the exception being thrown during the copy operation
                                                                                                                            doThrow(new MatrixIndexException("illegal column argument")).when(spyMatrix).getDataRef();
                                                                                                                            
                                                                                                                            // Expect exception
                                                                                                                            thrown.expect(MatrixIndexException.class);
                                                                                                                            thrown.expectMessage("illegal column argument");
                                                                                                                            
                                                                                                                            // Test
                                                                                                                            spyMatrix.copy();
                                                                                                                        }

    @Test
                                                                                                                        public void testCopyWithNonSquareMatrix() {
                                                                                                                            // Create a non-square matrix (2 rows, 3 columns)
                                                                                                                            BigDecimal[][] testData = new BigDecimal[][] {
                                                                                                                                {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                                                                                                                                {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")}
                                                                                                                            };
                                                                                                                            
                                                                                                                            BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                                            
                                                                                                                            // Test the copy
                                                                                                                            BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                                                            
                                                                                                                            // Verify dimensions are correctly copied
                                                                                                                            assertEquals("Row dimension should match original", 
                                                                                                                                         original.getRowDimension(), copy.getRowDimension());
                                                                                                                            assertEquals("Column dimension should match original", 
                                                                                                                                         original.getColumnDimension(), copy.getColumnDimension());
                                                                                                                            
                                                                                                                            // Verify all data is correctly copied
                                                                                                                            for (int i = 0; i < original.getRowDimension(); i++) {
                                                                                                                                for (int j = 0; j < original.getColumnDimension(); j++) {
                                                                                                                                    assertEquals("Data at [" + i + "][" + j + "] should match",
                                                                                                                                                original.getEntry(i, j),
                                                                                                                                                copy.getEntry(i, j));
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                                                                public void testCopyPreservesColumnDimension1() {
                                                                                                                    // Create a test matrix with known dimensions
                                                                                                                    BigDecimal[][] testData = {
                                                                                                                        {new BigDecimal("1"), new BigDecimal("2")},
                                                                                                                        {new BigDecimal("3"), new BigDecimal("4")}
                                                                                                                    };
                                                                                                                    BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                                    
                                                                                                                    // Make a copy
                                                                                                                    BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                                                    
                                                                                                                    // Verify column dimension is preserved
                                                                                                                    assertEquals("Column dimension should match original", 
                                                                                                                                original.getColumnDimension(), 
                                                                                                                                copy.getColumnDimension());
                                                                                                                    
                                                                                                                    // Additional verification that data matches
                                                                                                                    assertEquals("Data at [0][0] should match", 
                                                                                                                                original.getEntry(0, 0), 
                                                                                                                                copy.getEntry(0, 0));
                                                                                                                    assertEquals("Data at [1][1] should match", 
                                                                                                                                original.getEntry(1, 1), 
                                                                                                                                copy.getEntry(1, 1));
                                                                                                                }

    @Test
                                                                                                            public void testCopyDetectsArraySizeMutation() {
                                                                                                                // Create a test matrix with specific dimensions
                                                                                                                BigDecimal[][] testData = {
                                                                                                                    {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                                                    {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                                                                };
                                                                                                                BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                                
                                                                                                                // Make a copy
                                                                                                                BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                                                
                                                                                                                // Verify dimensions match exactly
                                                                                                                assertEquals("Row dimension should match", 
                                                                                                                             original.getRowDimension(), copy.getRowDimension());
                                                                                                                assertEquals("Column dimension should match", 
                                                                                                                             original.getColumnDimension(), copy.getColumnDimension());
                                                                                                                
                                                                                                                // Verify data integrity - this would fail if extra column was created
                                                                                                                BigDecimal[][] copiedData = copy.getData();
                                                                                                                for (int i = 0; i < original.getRowDimension(); i++) {
                                                                                                                    for (int j = 0; j < original.getColumnDimension(); j++) {
                                                                                                                        assertEquals("Data at [" + i + "][" + j + "] should match",
                                                                                                                                   original.getEntry(i, j), copiedData[i][j]);
                                                                                                                    }
                                                                                                                }
                                                                                                                
                                                                                                                // Additional check for array size in the internal representation
                                                                                                                // This would catch if copyOut() created an array with ncols+1
                                                                                                                BigDecimal[][] internalData = copy.getDataRef();
                                                                                                                assertEquals("Internal column count should match original", 
                                                                                                                             original.getColumnDimension(), internalData[0].length);
                                                                                                            }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                                                                            public void testCopyDetectsMutant() {
                                                                                                                // Create a non-empty matrix (1x1) to test column boundary
                                                                                                                BigDecimal[][] testData = new BigDecimal[][]{{BigDecimal.ONE}};
                                                                                                                BigMatrixImpl matrix = new BigMatrixImpl(testData, false);
                                                                                                                
                                                                                                                // If the mutant exists (i<=ncols), this will throw ArrayIndexOutOfBoundsException
                                                                                                                // when trying to access column 1 (0-based index would only go to 0)
                                                                                                                matrix.copy();
                                                                                                                
                                                                                                                // If no exception is thrown, the test will fail (original behavior)
                                                                                                            }

    @Test
                                                                                                            public void testCopyOriginalBehavior() {
                                                                                                                // Create a non-empty matrix (1x1) to verify original behavior
                                                                                                                BigDecimal[][] testData = new BigDecimal[][]{{BigDecimal.ONE}};
                                                                                                                BigMatrixImpl matrix = new BigMatrixImpl(testData, false);
                                                                                                                
                                                                                                                // Original behavior should complete without exception
                                                                                                                BigMatrix copy = matrix.copy();
                                                                                                                assertNotNull(copy);
                                                                                                                assertEquals(matrix.getRowDimension(), copy.getRowDimension());
                                                                                                                assertEquals(matrix.getColumnDimension(), copy.getColumnDimension());
                                                                                                            }

    @Test
                                                                                                    public void testCopyPreservesFirstColumnData() {
                                                                                                        // Create a 2x2 matrix with distinct values in each column
                                                                                                        BigDecimal[][] testData = {
                                                                                                            {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                                            {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                                                        };
                                                                                                        BigMatrixImpl original = new BigMatrixImpl(testData, false);
                                                                                                        
                                                                                                        // Make a copy
                                                                                                        BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                                        
                                                                                                        // Verify first column data was copied correctly
                                                                                                        assertEquals("First column first row not copied correctly", 
                                                                                                            new BigDecimal("1.0"), copy.getEntry(0, 0));
                                                                                                        assertEquals("First column second row not copied correctly",
                                                                                                            new BigDecimal("3.0"), copy.getEntry(1, 0));
                                                                                                        
                                                                                                        // Also verify second column as sanity check
                                                                                                        assertEquals("Second column first row not copied correctly",
                                                                                                            new BigDecimal("2.0"), copy.getEntry(0, 1));
                                                                                                        assertEquals("Second column second row not copied correctly",
                                                                                                            new BigDecimal("4.0"), copy.getEntry(1, 1));
                                                                                                    }

    @Test
                                                                                            public void testCopyPreservesMatrixStructure() {
                                                                                                // Create a non-square 2x3 matrix for testing
                                                                                                BigDecimal[][] testData = {
                                                                                                    {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                                                                                                    {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")}
                                                                                                };
                                                                                                
                                                                                                BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                                BigMatrix copy = original.copy();
                                                                                                
                                                                                                // Verify dimensions are preserved
                                                                                                assertEquals(original.getRowDimension(), copy.getRowDimension());
                                                                                                assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                                                                                                
                                                                                                // Verify all values are in their original positions
                                                                                                for (int row = 0; row < original.getRowDimension(); row++) {
                                                                                                    for (int col = 0; col < original.getColumnDimension(); col++) {
                                                                                                        assertEquals(
                                                                                                            original.getEntry(row, col),
                                                                                                            copy.getEntry(row, col)
                                                                                                        );
                                                                                                    }
                                                                                                }
                                                                                                
                                                                                                // Specifically check corner cases that would fail with transposed indices
                                                                                                assertEquals(new BigDecimal("1"), copy.getEntry(0, 0));
                                                                                                assertEquals(new BigDecimal("6"), copy.getEntry(1, 2));
                                                                                            }

    @Test
                                                                                        public void testCopyPreservesDecimalPrecision1() {
                                                                                            // Create a matrix with non-integer values
                                                                                            BigDecimal[][] testData = {
                                                                                                {new BigDecimal("1.5"), new BigDecimal("2.7")},
                                                                                                {new BigDecimal("3.1"), new BigDecimal("4.9")}
                                                                                            };
                                                                                            BigMatrixImpl original = new BigMatrixImpl(testData, false);
                                                                                            
                                                                                            // Make a copy
                                                                                            BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                            
                                                                                            // Verify decimal precision is preserved in the copy
                                                                                            // This will fail if mutation (intValue) is present
                                                                                            assertEquals(new BigDecimal("1.5"), copy.getEntry(0, 0));
                                                                                            assertEquals(new BigDecimal("2.7"), copy.getEntry(0, 1));
                                                                                            assertEquals(new BigDecimal("3.1"), copy.getEntry(1, 0));
                                                                                            assertEquals(new BigDecimal("4.9"), copy.getEntry(1, 1));
                                                                                            
                                                                                            // Also verify the data array directly
                                                                                            BigDecimal[][] copiedData = copy.getData();
                                                                                            assertEquals(new BigDecimal("1.5"), copiedData[0][0]);
                                                                                            assertEquals(new BigDecimal("2.7"), copiedData[0][1]);
                                                                                            assertEquals(new BigDecimal("3.1"), copiedData[1][0]);
                                                                                            assertEquals(new BigDecimal("4.9"), copiedData[1][1]);
                                                                                        }

    @Test
                                                                                        public void testCopyDetectsZeroValueMutant() {
                                                                                            // Create a 2x2 matrix with non-zero values
                                                                                            BigDecimal[][] testData = {
                                                                                                {new BigDecimal("1.5"), new BigDecimal("2.5")},
                                                                                                {new BigDecimal("3.5"), new BigDecimal("4.5")}
                                                                                            };
                                                                                            
                                                                                            BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                            
                                                                                            // Make a copy
                                                                                            BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                            
                                                                                            // Get the double array representations
                                                                                            double[][] originalDoubles = original.getDataAsDoubleArray();
                                                                                            double[][] copyDoubles = copy.getDataAsDoubleArray();
                                                                                            
                                                                                            // Verify dimensions match
                                                                                            assertEquals(originalDoubles.length, copyDoubles.length);
                                                                                            assertEquals(originalDoubles[0].length, copyDoubles[0].length);
                                                                                            
                                                                                            // Verify all values match (not zero)
                                                                                            for (int i = 0; i < originalDoubles.length; i++) {
                                                                                                for (int j = 0; j < originalDoubles[i].length; j++) {
                                                                                                    assertEquals("Value at ["+i+"]["+j+"] should match original", 
                                                                                                                 originalDoubles[i][j], copyDoubles[i][j], 0.0001);
                                                                                                }
                                                                                            }
                                                                                        }

    @Test
                                                                                public void testCopyDetectsMutatedDoubleValue1() {
                                                                                    // Create test data - using simple values that will clearly show the +1 mutation
                                                                                    BigDecimal[][] testData = {
                                                                                        {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                        {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                                    };
                                                                                    
                                                                                    // Create original matrix
                                                                                    BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                                    
                                                                                    // Make a copy
                                                                                    BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                                    
                                                                                    // Verify dimensions match
                                                                                    assertEquals(original.getRowDimension(), copy.getRowDimension());
                                                                                    assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                                                                                    
                                                                                    // Verify all values match exactly (this will fail with the mutant)
                                                                                    for (int i = 0; i < original.getRowDimension(); i++) {
                                                                                        for (int j = 0; j < original.getColumnDimension(); j++) {
                                                                                            assertEquals(
                                                                                                original.getEntry(i, j).doubleValue(),
                                                                                                copy.getEntry(i, j).doubleValue(),
                                                                                                0.000001 // delta for double comparison
                                                                                            );
                                                                                        }
                                                                                    }
                                                                                    
                                                                                    // Also verify the BigDecimal values match exactly
                                                                                    BigDecimal[][] originalData = original.getData();
                                                                                    BigDecimal[][] copyData = copy.getData();
                                                                                    for (int i = 0; i < originalData.length; i++) {
                                                                                        assertArrayEquals(originalData[i], copyData[i]);
                                                                                    }
                                                                                }

    @Test
                                                                        public void testCopyReturnsNewMatrixInstance() {
                                                                            // Setup test data
                                                                            BigDecimal[][] testData = {
                                                                                {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                            };
                                                                            
                                                                            // Create original matrix
                                                                            BigMatrixImpl original = new BigMatrixImpl(testData, false);
                                                                            
                                                                            // Test the copy method - now using BigMatrix interface type
                                                                            BigMatrix copy = original.copy();
                                                                            
                                                                            // Assertions to catch the mutant
                                                                            assertNotNull("Copy should not return null", copy);
                                                                            assertNotSame("Copy should be a different instance", original, copy);
                                                                            
                                                                            // Verify data matches
                                                                            assertEquals("Row dimension should match", 
                                                                                        original.getRowDimension(), copy.getRowDimension());
                                                                            assertEquals("Column dimension should match", 
                                                                                        original.getColumnDimension(), copy.getColumnDimension());
                                                                            
                                                                            // Verify all elements match
                                                                            for (int i = 0; i < original.getRowDimension(); i++) {
                                                                                for (int j = 0; j < original.getColumnDimension(); j++) {
                                                                                    assertEquals("Element at [" + i + "][" + j + "] should match",
                                                                                                original.getEntry(i, j),
                                                                                                copy.getEntry(i, j));
                                                                                }
                                                                            }
                                                                        }

    @Test
                                                                        public void testCopyReturnsMatrixWithSameData() {
                                                                            // Create original matrix with test data
                                                                            BigDecimal[][] testData = {
                                                                                {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                            };
                                                                            BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                            
                                                                            // Make a copy
                                                                            BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                                            
                                                                            // Verify the copy has the same data as original
                                                                            BigDecimal[][] originalData = original.getData();
                                                                            BigDecimal[][] copyData = copy.getData();
                                                                            
                                                                            assertEquals("Number of rows should match", 
                                                                                         originalData.length, copyData.length);
                                                                            
                                                                            for (int i = 0; i < originalData.length; i++) {
                                                                                assertEquals("Row " + i + " length should match",
                                                                                            originalData[i].length, copyData[i].length);
                                                                                
                                                                                for (int j = 0; j < originalData[i].length; j++) {
                                                                                    assertEquals("Element at [" + i + "][" + j + "] should match",
                                                                                               originalData[i][j], copyData[i][j]);
                                                                                }
                                                                            }
                                                                        }

    @Test
                                                                    public void testGetRowMatrixWithValidAndInvalidRows() {
                                                                        // Setup a 2x2 matrix for testing
                                                                        BigDecimal[][] testData = {
                                                                            {new BigDecimal("1"), new BigDecimal("2")},
                                                                            {new BigDecimal("3"), new BigDecimal("4")}
                                                                        };
                                                                        BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                        
                                                                        // Test valid row indices (0 and 1 for 2-row matrix)
                                                                        try {
                                                                            matrix.getRowMatrix(0);
                                                                            matrix.getRowMatrix(1);
                                                                        } catch (Exception e) {
                                                                            fail("Should not throw exception for valid row indices");
                                                                        }
                                                                        
                                                                        // Test invalid row indices
                                                                        try {
                                                                            matrix.getRowMatrix(-1);
                                                                            fail("Should have thrown exception for negative row index");
                                                                        } catch (IllegalArgumentException e) {
                                                                            // Expected
                                                                        }
                                                                        
                                                                        try {
                                                                            matrix.getRowMatrix(2);
                                                                            fail("Should have thrown exception for row index >= row dimension");
                                                                        } catch (IllegalArgumentException e) {
                                                                            // Expected
                                                                        }
                                                                    }

    @Test
                                                            public void testCopyWithSingleColumnMatrix() {
                                                                // Create a matrix with 1 column (only column index 0 is valid)
                                                                BigDecimal[][] testData = new BigDecimal[][] {
                                                                    {new BigDecimal("1")},
                                                                    {new BigDecimal("2")},
                                                                    {new BigDecimal("3")}
                                                                };
                                                                BigMatrixImpl original = new BigMatrixImpl(testData);
                                                                
                                                                // Test getting column 0 (should work in original, fail in mutant)
                                                                try {
                                                                    BigDecimal[] column0 = original.getColumn(0);
                                                                    assertNotNull(column0);
                                                                    assertEquals(3, column0.length);
                                                                    assertEquals(new BigDecimal("1"), column0[0]);
                                                                    assertEquals(new BigDecimal("2"), column0[1]);
                                                                    assertEquals(new BigDecimal("3"), column0[2]);
                                                                } catch (Exception e) {
                                                                    fail("Valid column access (0) should not throw exception");
                                                                }
                                                                
                                                                // Test copy operation
                                                                BigMatrix copy = original.copy();
                                                                assertNotNull(copy);
                                                                assertEquals(original.getRowDimension(), copy.getRowDimension());
                                                                assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                                                                
                                                                // Verify data integrity through column access
                                                                BigDecimal[] copiedColumn0 = ((BigMatrixImpl)copy).getColumn(0);
                                                                assertNotNull(copiedColumn0);
                                                                assertEquals(3, copiedColumn0.length);
                                                                assertEquals(new BigDecimal("1"), copiedColumn0[0]);
                                                                assertEquals(new BigDecimal("2"), copiedColumn0[1]);
                                                                assertEquals(new BigDecimal("3"), copiedColumn0[2]);
                                                                
                                                                // This would fail in the mutant because it checks column 1 instead of 0
                                                                // in isValidCoordinate()
                                                            }

    @Test
                                                            public void testCopyThrowsCorrectRowExceptionMessage1() {
                                                                // Setup - create a matrix with specific dimensions
                                                                int rows = 2;
                                                                int cols = 3;
                                                                BigMatrixImpl matrix = new BigMatrixImpl(rows, cols);
                                                                
                                                                // Set expectation for exception type and message
                                                                thrown.expect(MatrixIndexException.class);
                                                                thrown.expectMessage("illegal row argument");
                                                                
                                                                // Trigger the exception by accessing invalid row
                                                                // This would normally happen during copy if validation fails
                                                                // For testing purposes, we'll force an invalid row access
                                                                matrix.getRowMatrix(rows + 1); // Try to access non-existent row
                                                            }

    @Test
                                                    public void testCopyWithNonSquareMatrixDetectsColumnDimensionMutant1() {
                                                        // Create a non-square matrix (2x3)
                                                        BigDecimal[][] testData = {
                                                            {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                                                            {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")}
                                                        };
                                                        BigMatrixImpl original = new BigMatrixImpl(testData);
                                                        
                                                        // Make a copy
                                                        BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                        
                                                        // Verify dimensions are correct (would fail with mutant)
                                                        assertEquals("Row dimension should match original", 
                                                                     original.getRowDimension(), copy.getRowDimension());
                                                        assertEquals("Column dimension should match original", 
                                                                     original.getColumnDimension(), copy.getColumnDimension());
                                                        
                                                        // Verify all values were copied correctly
                                                        for (int i = 0; i < original.getRowDimension(); i++) {
                                                            for (int j = 0; j < original.getColumnDimension(); j++) {
                                                                assertEquals("Value at [" + i + "][" + j + "] should match",
                                                                             original.getEntry(i, j), copy.getEntry(i, j));
                                                            }
                                                        }
                                                    }

    @Test
                                                public void testCopyPreservesColumnDimension2() {
                                                    // Create a matrix with known dimensions (2 rows, 3 columns)
                                                    BigDecimal[][] testData = {
                                                        {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                                                        {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")}
                                                    };
                                                    BigMatrixImpl original = new BigMatrixImpl(testData);
                                                    
                                                    // Make a copy
                                                    BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                    
                                                    // Verify column dimension is preserved
                                                    assertEquals("Column dimension should be preserved in copy", 
                                                                original.getColumnDimension(), 
                                                                copy.getColumnDimension());
                                                    
                                                    // Also verify row dimension for completeness
                                                    assertEquals("Row dimension should be preserved in copy",
                                                                original.getRowDimension(),
                                                                copy.getRowDimension());
                                                    
                                                    // Verify data content for thoroughness
                                                    for (int i = 0; i < original.getRowDimension(); i++) {
                                                        for (int j = 0; j < original.getColumnDimension(); j++) {
                                                            assertEquals("Matrix data should be identical at [" + i + "][" + j + "]",
                                                                        original.getEntry(i, j),
                                                                        copy.getEntry(i, j));
                                                        }
                                                    }
                                                }

    @Test
                                                public void testCopyPreservesExactDimensions() {
                                                    // Create a 2x3 matrix
                                                    BigDecimal[][] originalData = {
                                                        {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                                                        {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")}
                                                    };
                                                    BigMatrixImpl original = new BigMatrixImpl(originalData);
                                                    
                                                    // Make a copy
                                                    BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                                    
                                                    // Verify dimensions are preserved exactly
                                                    assertEquals("Row dimension should match", 
                                                                original.getRowDimension(), 
                                                                copy.getRowDimension());
                                                    assertEquals("Column dimension should match", 
                                                                original.getColumnDimension(), 
                                                                copy.getColumnDimension());
                                                                
                                                    // Verify data integrity by checking a sample value
                                                    assertEquals("Data should be identical",
                                                                original.getEntry(1, 1),
                                                                copy.getEntry(1, 1));
                                                                
                                                    // Verify the copy can perform the same operations
                                                    BigDecimal[] vector = {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")};
                                                    BigDecimal[] originalResult = original.operate(vector);
                                                    BigDecimal[] copyResult = copy.operate(vector);
                                                    assertArrayEquals("Operation results should match",
                                                                     originalResult,
                                                                     copyResult);
                                                }

    @Test
                                            public void testCopyDoesNotThrowExceptionForValidMatrix() {
                                                // Create a simple 2x2 matrix
                                                BigDecimal[][] testData = {
                                                    {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                    {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                };
                                                
                                                // Create original matrix
                                                BigMatrixImpl original = new BigMatrixImpl(testData);
                                                
                                                // Test that copy operation doesn't throw exception
                                                try {
                                                    BigMatrix copy = original.copy();
                                                    assertNotNull("Copy should not be null", copy);
                                                    // Additional verification that the copy is correct
                                                    assertEquals("Row dimension should match", 
                                                                 original.getRowDimension(), copy.getRowDimension());
                                                    assertEquals("Column dimension should match", 
                                                                 original.getColumnDimension(), copy.getColumnDimension());
                                                } catch (ArrayIndexOutOfBoundsException e) {
                                                    fail("Copy operation threw ArrayIndexOutOfBoundsException - likely due to mutated loop condition");
                                                }
                                            }

    @Test
                                            public void testCopyHandlesSingleElementMatrix() {
                                                // Create a 1x1 matrix (minimum size)
                                                BigDecimal[][] testData = {{new BigDecimal("1.0")}};
                                                
                                                BigMatrixImpl original = new BigMatrixImpl(testData);
                                                
                                                try {
                                                    BigMatrix copy = original.copy();
                                                    assertNotNull(copy);
                                                    assertEquals(1, copy.getRowDimension());
                                                    assertEquals(1, copy.getColumnDimension());
                                                } catch (ArrayIndexOutOfBoundsException e) {
                                                    fail("Copy operation threw ArrayIndexOutOfBoundsException for 1x1 matrix");
                                                }
                                            }

    @Test
                                    public void testCopyPreservesAllColumns1() {
                                        // Create a 2x2 test matrix with distinct values in each column
                                        BigDecimal[][] testData = {
                                            {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                            {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                        };
                                        BigMatrixImpl original = new BigMatrixImpl(testData, false);
                                        
                                        // Make a copy
                                        BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                        
                                        // Verify all columns are preserved in the copy
                                        assertEquals("First column first row not copied correctly", 
                                            new BigDecimal("1.0"), copy.getEntry(0, 0));
                                        assertEquals("First column second row not copied correctly",
                                            new BigDecimal("3.0"), copy.getEntry(1, 0));
                                        assertEquals("Second column first row not copied correctly",
                                            new BigDecimal("2.0"), copy.getEntry(0, 1));
                                        assertEquals("Second column second row not copied correctly",
                                            new BigDecimal("4.0"), copy.getEntry(1, 1));
                                        
                                        // Additional check for column dimensions
                                        assertEquals("Column dimension mismatch", 
                                            original.getColumnDimension(), copy.getColumnDimension());
                                    }

    @Test
                                    public void testCopyMaintainsMatrixStructure1() {
                                        // Create a non-square test matrix (2x3)
                                        BigDecimal[][] testData = {
                                            {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                            {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                        };
                                        
                                        BigMatrixImpl original = new BigMatrixImpl(testData);
                                        BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                        
                                        // Verify dimensions are maintained (not transposed)
                                        assertEquals(2, copy.getRowDimension());
                                        assertEquals(3, copy.getColumnDimension());
                                        
                                        // Verify values are in correct positions (not transposed)
                                        assertEquals(new BigDecimal("1.0"), copy.getEntry(0, 0));
                                        assertEquals(new BigDecimal("2.0"), copy.getEntry(0, 1));
                                        assertEquals(new BigDecimal("3.0"), copy.getEntry(0, 2));
                                        assertEquals(new BigDecimal("4.0"), copy.getEntry(1, 0));
                                        assertEquals(new BigDecimal("5.0"), copy.getEntry(1, 1));
                                        assertEquals(new BigDecimal("6.0"), copy.getEntry(1, 2));
                                        
                                        // Also verify via double array representation
                                        double[][] doubleData = copy.getDataAsDoubleArray();
                                        assertEquals(1.0, doubleData[0][0], 0.0001);
                                        assertEquals(2.0, doubleData[0][1], 0.0001);
                                        assertEquals(3.0, doubleData[0][2], 0.0001);
                                        assertEquals(4.0, doubleData[1][0], 0.0001);
                                        assertEquals(5.0, doubleData[1][1], 0.0001);
                                        assertEquals(6.0, doubleData[1][2], 0.0001);
                                    }

    @Test
                                public void testCopyPreservesDecimalValues() {
                                    // Create a matrix with decimal values
                                    BigDecimal[][] testData = {
                                        {new BigDecimal("1.1"), new BigDecimal("2.2")},
                                        {new BigDecimal("3.3"), new BigDecimal("4.4")}
                                    };
                                    BigMatrixImpl original = new BigMatrixImpl(testData, false);
                                    
                                    // Make a copy
                                    BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                    
                                    // Verify decimal values are preserved in the copy
                                    assertEquals(new BigDecimal("1.1"), copy.getEntry(0, 0));
                                    assertEquals(new BigDecimal("2.2"), copy.getEntry(0, 1));
                                    assertEquals(new BigDecimal("3.3"), copy.getEntry(1, 0));
                                    assertEquals(new BigDecimal("4.4"), copy.getEntry(1, 1));
                                    
                                    // Also verify with values that would be different when truncated
                                    BigDecimal[][] preciseData = {
                                        {new BigDecimal("1.999"), new BigDecimal("2.001")}
                                    };
                                    original = new BigMatrixImpl(preciseData, false);
                                    copy = (BigMatrixImpl)original.copy();
                                    
                                    // These assertions would fail with the mutant
                                    assertEquals(new BigDecimal("1.999"), copy.getEntry(0, 0));
                                    assertEquals(new BigDecimal("2.001"), copy.getEntry(0, 1));
                                }

    @Test
                            public void testCopyPreservesDataValues1() {
                                // Create a sample matrix with non-zero values
                                BigDecimal[][] testData = {
                                    {new BigDecimal("1.5"), new BigDecimal("2.3")},
                                    {new BigDecimal("4.1"), new BigDecimal("5.7")}
                                };
                                
                                BigMatrixImpl original = new BigMatrixImpl(testData);
                                
                                // Make a copy
                                BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                                
                                // Verify the copy has the same values as original
                                assertEquals(original.getRowDimension(), copy.getRowDimension());
                                assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                                
                                for (int i = 0; i < original.getRowDimension(); i++) {
                                    for (int j = 0; j < original.getColumnDimension(); j++) {
                                        assertEquals(
                                            original.getEntry(i, j).doubleValue(),
                                            copy.getEntry(i, j).doubleValue(),
                                            0.000001 // delta for double comparison
                                        );
                                    }
                                }
                            }

    @Test
                    public void testCopyDetectsMutatedValues() {
                        // Create a sample matrix with known values
                        BigDecimal[][] testData = {
                            {new BigDecimal("1.0"), new BigDecimal("2.0")},
                            {new BigDecimal("3.0"), new BigDecimal("4.0")}
                        };
                        BigMatrixImpl original = new BigMatrixImpl(testData);
                        
                        // Make a copy
                        BigMatrixImpl copy = (BigMatrixImpl)original.copy();
                        
                        // Verify all values match exactly
                        for (int i = 0; i < original.getRowDimension(); i++) {
                            for (int j = 0; j < original.getColumnDimension(); j++) {
                                assertEquals("Matrix value at ["+i+"]["+j+"] should match", 
                                             original.getEntry(i, j), 
                                             copy.getEntry(i, j));
                            }
                        }
                        
                        // Also verify the double array representation
                        double[][] originalDoubles = original.getDataAsDoubleArray();
                        double[][] copyDoubles = copy.getDataAsDoubleArray();
                        for (int i = 0; i < originalDoubles.length; i++) {
                            for (int j = 0; j < originalDoubles[i].length; j++) {
                                assertEquals("Double value at ["+i+"]["+j+"] should match", 
                                             originalDoubles[i][j], 
                                             copyDoubles[i][j], 
                                             0.000001);
                            }
                        }
                    }

    @Test
            public void testCopyReturnsNonNull() {
                // Create a simple 2x2 matrix
                BigDecimal[][] testData = {
                    {new BigDecimal("1.0"), new BigDecimal("2.0")},
                    {new BigDecimal("3.0"), new BigDecimal("4.0")}
                };
                
                BigMatrixImpl original = new BigMatrixImpl(testData);
                
                // Call the copy method and cast to BigMatrixImpl
                BigMatrix copy = original.copy();
                
                // Assert the copy is not null (this would catch the mutant)
                assertNotNull("Copy should not be null", copy);
                
                // Additional checks to verify it's a proper copy
                assertNotSame("Copy should be a different instance", original, copy);
                assertEquals("Copy should have same dimensions", 
                           original.getRowDimension(), copy.getRowDimension());
                assertEquals("Copy should have same dimensions",
                           original.getColumnDimension(), copy.getColumnDimension());
                
                // Verify data equality
                for (int i = 0; i < original.getRowDimension(); i++) {
                    for (int j = 0; j < original.getColumnDimension(); j++) {
                        assertEquals("Data should be equal at position [" + i + "][" + j + "]",
                                   original.getEntry(i, j), copy.getEntry(i, j));
                    }
                }
            }

    @Test
    public void testCopyPreservesData1() {
        // Create original matrix with test data
        BigDecimal[][] testData = {
            {new BigDecimal("1.0"), new BigDecimal("2.0")},
            {new BigDecimal("3.0"), new BigDecimal("4.0")}
        };
        BigMatrixImpl original = new BigMatrixImpl(testData);
        
        // Create copy
        BigMatrixImpl copy = (BigMatrixImpl)original.copy();
        
        // Verify copy has same data as original
        BigDecimal[][] originalData = original.getData();
        BigDecimal[][] copyData = copy.getData();
        
        // Check dimensions
        assertEquals(originalData.length, copyData.length);
        assertEquals(originalData[0].length, copyData[0].length);
        
        // Check each element
        for (int i = 0; i < originalData.length; i++) {
            for (int j = 0; j < originalData[i].length; j++) {
                assertEquals(originalData[i][j], copyData[i][j]);
            }
        }
        
        // Also verify it's a deep copy by modifying original data and ensuring copy doesn't change
        originalData[0][0] = new BigDecimal("5.0");
        assertNotEquals(originalData[0][0], copyData[0][0]);
    }


}
