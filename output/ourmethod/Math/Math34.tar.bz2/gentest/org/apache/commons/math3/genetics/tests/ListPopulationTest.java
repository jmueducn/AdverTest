package gentest.org.apache.commons.math3.genetics.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.genetics.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
 
public class ListPopulationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                            public void testIterator_SingleChromosome() {
                                                                                                                                                // Arrange
                                                                                                                                                Chromosome mockChromosome = mock(Chromosome.class);
                                                                                                                                                List<Chromosome> chromosomes = Collections.singletonList(mockChromosome);
                                                                                                                                                ElitisticListPopulation population = new ElitisticListPopulation(chromosomes, 10, 0.1);
                                                                                                                                                
                                                                                                                                                // Act
                                                                                                                                                Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                                
                                                                                                                                                // Assert
                                                                                                                                                assertNotNull(iterator);
                                                                                                                                                assertTrue(iterator.hasNext());
                                                                                                                                                assertEquals(mockChromosome, iterator.next());
                                                                                                                                                assertFalse(iterator.hasNext());
                                                                                                                                            }

    @Test
                                                                                                                                    public void testIterator_EmptyPopulation() {
                                                                                                                                        // Arrange
                                                                                                                                        ListPopulation population = new ListPopulation(10) {
                                                                                                                                            // Anonymous subclass to make it concrete
                                                                                                                                            @Override
                                                                                                                                            public Iterator<Chromosome> iterator() {
                                                                                                                                                return getChromosomeList().iterator();
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            @Override
                                                                                                                                            public Population nextGeneration() {
                                                                                                                                                return new ListPopulation(getPopulationLimit()) {
                                                                                                                                                    @Override
                                                                                                                                                    public Iterator<Chromosome> iterator() {
                                                                                                                                                        return getChromosomeList().iterator();
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    public Population nextGeneration() {
                                                                                                                                                        return null; // Not used in test
                                                                                                                                                    }
                                                                                                                                                };
                                                                                                                                            }
                                                                                                                                        };
                                                                                                                                        
                                                                                                                                        // Act
                                                                                                                                        Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                        
                                                                                                                                        // Assert
                                                                                                                                        assertNotNull(iterator);
                                                                                                                                        assertFalse(iterator.hasNext());
                                                                                                                                    }

    @Test
                                                                                                                                    public void testIterator_RemoveWithoutNextShouldThrow() {
                                                                                                                                        // Arrange
                                                                                                                                        Chromosome mock1 = mock(Chromosome.class);
                                                                                                                                        List<Chromosome> chromosomes = Collections.singletonList(mock1);
                                                                                                                                        
                                                                                                                                        // Create concrete subclass of ListPopulation for testing
                                                                                                                                        ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                                                            @Override
                                                                                                                                            public Population nextGeneration() {
                                                                                                                                                return new ListPopulation(getPopulationLimit()) {
                                                                                                                                                    @Override
                                                                                                                                                    public Population nextGeneration() {
                                                                                                                                                        return null;
                                                                                                                                                    }
                                                                                                                                                };
                                                                                                                                            }
                                                                                                                                        };
                                                                                                                                        
                                                                                                                                        Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                        
                                                                                                                                        // Expect exception
                                                                                                                                        thrown.expect(IllegalStateException.class);
                                                                                                                                        
                                                                                                                                        // Act
                                                                                                                                        iterator.remove();
                                                                                                                                    }

    @Test
                                                                                                    public void testIterator_MultipleChromosomes() {
                                                                                                        // Arrange
                                                                                                        org.apache.commons.math3.genetics.Chromosome mock1 = new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                            @Override
                                                                                                            public double fitness() {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        };
                                                                                                        org.apache.commons.math3.genetics.Chromosome mock2 = new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                            @Override
                                                                                                            public double fitness() {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        };
                                                                                                        org.apache.commons.math3.genetics.Chromosome mock3 = new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                            @Override
                                                                                                            public double fitness() {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        };
                                                                                                        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
                                                                                                            java.util.Arrays.asList(mock1, mock2, mock3);
                                                                                                        
                                                                                                        org.apache.commons.math3.genetics.ListPopulation population = 
                                                                                                            new org.apache.commons.math3.genetics.ListPopulation(chromosomes, 10) {
                                                                                                                @Override
                                                                                                                public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                                                                    return new org.apache.commons.math3.genetics.ListPopulation(this.getPopulationLimit()) {
                                                                                                                        @Override
                                                                                                                        public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                                                                            return null;
                                                                                                                        }
                                                                                                                    };
                                                                                                                }
                                                                                                            };
                                                                                                        
                                                                                                        // Act
                                                                                                        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> iterator = population.iterator();
                                                                                                        
                                                                                                        // Assert
                                                                                                        org.junit.Assert.assertNotNull(iterator);
                                                                                                        org.junit.Assert.assertTrue(iterator.hasNext());
                                                                                                        org.junit.Assert.assertEquals(mock1, iterator.next());
                                                                                                        org.junit.Assert.assertTrue(iterator.hasNext());
                                                                                                        org.junit.Assert.assertEquals(mock2, iterator.next());
                                                                                                        org.junit.Assert.assertTrue(iterator.hasNext());
                                                                                                        org.junit.Assert.assertEquals(mock3, iterator.next());
                                                                                                        org.junit.Assert.assertFalse(iterator.hasNext());
                                                                                                    }

    @Test
                                                                                                    public void testIterator_VerifyIterationOrder() {
                                                                                                        // Arrange
                                                                                                        org.apache.commons.math3.genetics.Chromosome mock1 = new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                            @Override
                                                                                                            public double fitness() {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        };
                                                                                                        org.apache.commons.math3.genetics.Chromosome mock2 = new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                            @Override
                                                                                                            public double fitness() {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        };
                                                                                                        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
                                                                                                            java.util.Arrays.asList(mock1, mock2);
                                                                                                        org.apache.commons.math3.genetics.ListPopulation population = 
                                                                                                            new org.apache.commons.math3.genetics.ListPopulation(chromosomes, 10) {
                                                                                                                @Override
                                                                                                                public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                                                                    return null; // Simple implementation for test purposes
                                                                                                                }
                                                                                                            };
                                                                                                        
                                                                                                        // Act
                                                                                                        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> iterator = population.iterator();
                                                                                                        java.util.List<org.apache.commons.math3.genetics.Chromosome> iteratedChromosomes = 
                                                                                                            new java.util.ArrayList<>();
                                                                                                        while (iterator.hasNext()) {
                                                                                                            iteratedChromosomes.add(iterator.next());
                                                                                                        }
                                                                                                        
                                                                                                        // Assert
                                                                                                        org.junit.Assert.assertEquals(2, iteratedChromosomes.size());
                                                                                                        org.junit.Assert.assertEquals(mock1, iteratedChromosomes.get(0));
                                                                                                        org.junit.Assert.assertEquals(mock2, iteratedChromosomes.get(1));
                                                                                                    }

    @Test
                                                                                                    public void testIterator_RemoveOperation() {
                                                                                                        // Arrange
                                                                                                        org.apache.commons.math3.genetics.Chromosome mock1 = new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                            @Override
                                                                                                            public double fitness() {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        };
                                                                                                        org.apache.commons.math3.genetics.Chromosome mock2 = new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                            @Override
                                                                                                            public double fitness() {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        };
                                                                                                        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
                                                                                                            new java.util.ArrayList<>(java.util.Arrays.asList(mock1, mock2));
                                                                                                        org.apache.commons.math3.genetics.ListPopulation population = 
                                                                                                            new org.apache.commons.math3.genetics.ListPopulation(chromosomes, 10) {
                                                                                                                @Override
                                                                                                                public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                                                                    return new org.apache.commons.math3.genetics.ListPopulation(
                                                                                                                        new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>(), 
                                                                                                                        getPopulationLimit()) {
                                                                                                                            @Override
                                                                                                                            public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                                                                                return null;
                                                                                                                            }
                                                                                                                    };
                                                                                                                }
                                                                                                            };
                                                                                                        
                                                                                                        // Act
                                                                                                        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> iterator = population.iterator();
                                                                                                        iterator.next(); // move to first element
                                                                                                        iterator.remove();
                                                                                                        
                                                                                                        // Assert
                                                                                                        org.junit.Assert.assertEquals(1, population.getPopulationSize());
                                                                                                        org.junit.Assert.assertFalse(population.getChromosomes().contains(mock1));
                                                                                                    }

    @Test
                                                                                                public void testIterator_AfterModifyingPopulation() {
                                                                                                    // Arrange
                                                                                                    org.apache.commons.math3.genetics.Chromosome mock1 = new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                        @Override
                                                                                                        public double fitness() {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    };
                                                                                                    org.apache.commons.math3.genetics.Chromosome mock2 = new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                        @Override
                                                                                                        public double fitness() {
                                                                                                            return 0;
                                                                                                        }
                                                                                                    };
                                                                                                    
                                                                                                    java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = new java.util.ArrayList<>();
                                                                                                    chromosomes.add(mock1);
                                                                                                    
                                                                                                    org.apache.commons.math3.genetics.ListPopulation population = new org.apache.commons.math3.genetics.ListPopulation(chromosomes, 10) {
                                                                                                        @Override
                                                                                                        public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                                                            return new org.apache.commons.math3.genetics.ListPopulation(getPopulationLimit()) {
                                                                                                                @Override
                                                                                                                public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                                                                    return null;
                                                                                                                }
                                                                                                            };
                                                                                                        }
                                                                                                    };
                                                                                                    
                                                                                                    // Act - get iterator first
                                                                                                    java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> iterator = population.iterator();
                                                                                                    
                                                                                                    // Modify the population
                                                                                                    population.addChromosome(mock2);
                                                                                                    
                                                                                                    // Assert - iterator should reflect original state
                                                                                                    org.junit.Assert.assertTrue(iterator.hasNext());
                                                                                                    org.junit.Assert.assertEquals(mock1, iterator.next());
                                                                                                    org.junit.Assert.assertFalse(iterator.hasNext());
                                                                                                }

    @Test
                                                                                public void testIteratorReturnsBasicIteratorNotListIterator() {
                                                                                    // Setup test data
                                                                                    List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                                    chromosomes.add(mock(Chromosome.class));
                                                                                    chromosomes.add(mock(Chromosome.class));
                                                                                    
                                                                                    // Create population with test data using anonymous subclass that implements nextGeneration()
                                                                                    ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                        @Override
                                                                                        public Population nextGeneration() {
                                                                                            return new ListPopulation(new ArrayList<Chromosome>(), getPopulationLimit()) {
                                                                                                @Override
                                                                                                public Population nextGeneration() {
                                                                                                    return null; // Not used in this test
                                                                                                }
                                                                                            };
                                                                                        }
                                                                                    };
                                                                                    
                                                                                    // Get the iterator
                                                                                    Iterator<Chromosome> iterator = population.iterator();
                                                                                    
                                                                                    // Verify it's not a ListIterator
                                                                                    assertFalse("Iterator should not be a ListIterator", 
                                                                                               iterator instanceof java.util.ListIterator);
                                                                                    
                                                                                    // Verify basic iteration works
                                                                                    assertTrue(iterator.hasNext());
                                                                                    assertNotNull(iterator.next());
                                                                                }

    @Test
                                                            public void testIteratorBehavior() {
                                                                // Setup test data
                                                                List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                Chromosome mock1 = mock(Chromosome.class);
                                                                Chromosome mock2 = mock(Chromosome.class);
                                                                chromosomes.add(mock1);
                                                                chromosomes.add(mock2);
                                                                int populationLimit = 10;
                                                                
                                                                // Create population using anonymous subclass with implemented abstract method
                                                                ListPopulation population = new ListPopulation(chromosomes, populationLimit) {
                                                                    @Override
                                                                    public Population nextGeneration() {
                                                                        // Create a new anonymous subclass since ListPopulation is abstract
                                                                        return new ListPopulation(getPopulationLimit()) {
                                                                            @Override
                                                                            public Population nextGeneration() {
                                                                                return null;
                                                                            }
                                                                        };
                                                                    }
                                                                };
                                                                
                                                                // Get iterator from population
                                                                Iterator<Chromosome> iterator = population.iterator();
                                                                
                                                                // Test 1: Verify iteration order matches original list
                                                                List<Chromosome> iterated = new ArrayList<Chromosome>();
                                                                while (iterator.hasNext()) {
                                                                    iterated.add(iterator.next());
                                                                }
                                                                assertEquals("Iteration order should match original list", 
                                                                            chromosomes, iterated);
                                                                
                                                                // Test 2: Verify remove operation works (would fail with stream iterator)
                                                                iterator = population.iterator();
                                                                Chromosome first = iterator.next();
                                                                iterator.remove();
                                                                
                                                                assertFalse("Chromosome should be removed from population",
                                                                           population.getChromosomes().contains(first));
                                                                assertEquals("Population size should decrease after remove",
                                                                            chromosomes.size() - 1, population.getPopulationSize());
                                                                
                                                                // Test 3: Verify concurrent modification detection
                                                                iterator = population.iterator();
                                                                population.addChromosome(mock(Chromosome.class));
                                                                try {
                                                                    iterator.next();
                                                                    fail("Expected ConcurrentModificationException");
                                                                } catch (java.util.ConcurrentModificationException e) {
                                                                    // Expected behavior
                                                                }
                                                            }

    @Test
                                                public void testIteratorMaintainsOrder() {
                                                    // Setup test data
                                                    List<Chromosome> chromosomes = new ArrayList<>();
                                                    Chromosome c1 = mock(Chromosome.class);
                                                    Chromosome c2 = mock(Chromosome.class);
                                                    Chromosome c3 = mock(Chromosome.class);
                                                    chromosomes.add(c1);
                                                    chromosomes.add(c2);
                                                    chromosomes.add(c3);
                                                    
                                                    int populationLimit = 10;
                                                    
                                                    // Create concrete subclass for testing
                                                    class ConcreteListPopulation extends ListPopulation {
                                                        public ConcreteListPopulation(List<Chromosome> chromosomes, int populationLimit) {
                                                            super(chromosomes, populationLimit);
                                                        }
                                                        
                                                        @Override
                                                        public Population nextGeneration() {
                                                            // Simple implementation for testing purposes
                                                            return new ConcreteListPopulation(new ArrayList<Chromosome>(), getPopulationLimit());
                                                        }
                                                    }
                                                    
                                                    ListPopulation population = new ConcreteListPopulation(chromosomes, populationLimit);
                                                    
                                                    // Test iterator order
                                                    Iterator<Chromosome> iterator = population.iterator();
                                                    assertSame(c1, iterator.next());
                                                    assertSame(c2, iterator.next());
                                                    assertSame(c3, iterator.next());
                                                    assertFalse(iterator.hasNext());
                                                    
                                                    // Verify the iterator is not from parallel stream by checking thread characteristics
                                                    // (parallel stream iterators might behave differently in concurrent scenarios)
                                                    try {
                                                        iterator.remove();
                                                        // If we get here, it's a regular iterator (parallel stream iterator might fail)
                                                    } catch (Exception e) {
                                                        fail("Iterator should support remove operation");
                                                    }
                                                }

    @Test
                            public void testIteratorRemoval_shouldDetectStreamIteratorMutant() {
                                // Initialize test data
                                List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                Chromosome chr1 = new Chromosome() {
                                    @Override
                                    public double fitness() {
                                        return 0;
                                    }
                                };
                                chromosomes.add(chr1);
                                chromosomes.add(new Chromosome() {
                                    @Override
                                    public double fitness() {
                                        return 0;
                                    }
                                });
                                
                                // Create concrete implementation of ListPopulation for testing
                                ListPopulation population = new ListPopulation(chromosomes, 2) {
                                    @Override
                                    public Population nextGeneration() {
                                        // Return a new concrete instance instead of abstract ListPopulation
                                        return new ListPopulation(new ArrayList<Chromosome>(), getPopulationLimit()) {
                                            @Override
                                            public Population nextGeneration() {
                                                return null;
                                            }
                                        };
                                    }
                                };
                                
                                Iterator<Chromosome> iterator = population.iterator();
                                iterator.next();
                                
                                // Test removal behavior
                                iterator.remove();
                                
                                // Verify removal was effective
                                assertEquals(1, population.getPopulationSize());
                                assertFalse(population.getChromosomes().contains(chr1));
                                
                                // The stream iterator might behave differently on subsequent operations
                                try {
                                    iterator.remove(); // Second remove should fail
                                    fail("Expected IllegalStateException was not thrown");
                                } catch (IllegalStateException e) {
                                    // Expected for both implementations, but stream might fail differently
                                }
                            }

    @Test
                    public void testIterator_shouldDetectStreamIteratorMutant() {
                        // Setup test data
                        List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                        Chromosome chr1 = mock(Chromosome.class);
                        chromosomes.add(chr1);
                        Chromosome chr2 = mock(Chromosome.class);
                        chromosomes.add(chr2);
                        
                        // Create population with initial chromosomes
                        ListPopulation population = new ListPopulation(chromosomes, 10) {
                            // Implement abstract method nextGeneration
                            @Override
                            public Population nextGeneration() {
                                return new ListPopulation(new ArrayList<Chromosome>(), 10) {
                                    @Override
                                    public Population nextGeneration() {
                                        return null;
                                    }
                                };
                            }
                        };
                        
                        // Get iterator and verify initial state
                        Iterator<Chromosome> iterator = population.iterator();
                        assertTrue(iterator.hasNext());
                        assertEquals(chr1, iterator.next());
                        
                        // Modify underlying collection directly
                        Chromosome chr3 = mock(Chromosome.class);
                        population.addChromosome(chr3);
                        
                        // The behavior difference should be detectable here:
                        try {
                            // Original implementation using direct iterator would allow this
                            // Stream iterator would throw ConcurrentModificationException
                            iterator.next();
                            fail("Expected ConcurrentModificationException was not thrown");
                        } catch (java.util.ConcurrentModificationException e) {
                            // This is the expected behavior for the stream iterator mutant
                        }
                    }

    @Test
    public void testIteratorReturnsElementsInOriginalOrder() {
        // Setup test data
        List<Chromosome> chromosomes = new ArrayList<>();
        Chromosome c1 = mock(Chromosome.class);
        Chromosome c2 = mock(Chromosome.class);
        Chromosome c3 = mock(Chromosome.class);
        chromosomes.add(c1);
        chromosomes.add(c2);
        chromosomes.add(c3);
        
        int populationLimit = 10;
        ListPopulation population = new ListPopulation(chromosomes, populationLimit) {
            // Implement abstract method from Population class
            @Override
            public Population nextGeneration() {
                return new ListPopulation(new ArrayList<Chromosome>(), getPopulationLimit()) {
                    @Override
                    public Population nextGeneration() {
                        return null;
                    }
                };
            }
        };
        
        // Test iterator behavior
        Iterator<Chromosome> it = population.iterator();
        
        // Verify iteration order matches insertion order
        assertSame(c1, it.next());
        assertSame(c2, it.next());
        assertSame(c3, it.next());
        assertFalse(it.hasNext());
        
        // Verify the iterator is not from parallel stream by checking ordering consistency
        // This would fail with the mutant since parallel stream doesn't guarantee order
        List<Chromosome> iterated = new ArrayList<>();
        population.iterator().forEachRemaining(iterated::add);
        assertEquals(chromosomes, iterated);
    }


}
