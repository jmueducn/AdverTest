package gentest.org.apache.commons.math3.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.fraction.*;
import java.io.Serializable;
import java.math.BigInteger;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
 
public class FractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                public void testPercentageValue_WithWholeNumbers() {
                                                    // Test with ONE (1/1)
                                                    assertEquals(100.0, Fraction.ONE.percentageValue(), 0.0001);
                                                    
                                                    // Test with TWO (2/1)
                                                    assertEquals(200.0, Fraction.TWO.percentageValue(), 0.0001);
                                                    
                                                    // Test with ZERO (0/1)
                                                    assertEquals(0.0, Fraction.ZERO.percentageValue(), 0.0001);
                                                    
                                                    // Test with MINUS_ONE (-1/1)
                                                    assertEquals(-100.0, Fraction.MINUS_ONE.percentageValue(), 0.0001);
                                                }

    @Test
                                                public void testPercentageValue_WithCommonFractions() {
                                                    // Test with ONE_HALF (1/2)
                                                    assertEquals(50.0, Fraction.ONE_HALF.percentageValue(), 0.0001);
                                                    
                                                    // Test with ONE_QUARTER (1/4)
                                                    assertEquals(25.0, Fraction.ONE_QUARTER.percentageValue(), 0.0001);
                                                    
                                                    // Test with THREE_QUARTERS (3/4)
                                                    assertEquals(75.0, Fraction.THREE_QUARTERS.percentageValue(), 0.0001);
                                                    
                                                    // Test with ONE_THIRD (1/3)
                                                    assertEquals(33.3333, Fraction.ONE_THIRD.percentageValue(), 0.0001);
                                                    
                                                    // Test with TWO_THIRDS (2/3)
                                                    assertEquals(66.6666, Fraction.TWO_THIRDS.percentageValue(), 0.0001);
                                                }

    @Test
                                                public void testPercentageValue_WithFifths() {
                                                    // Test with ONE_FIFTH (1/5)
                                                    assertEquals(20.0, Fraction.ONE_FIFTH.percentageValue(), 0.0001);
                                                    
                                                    // Test with TWO_FIFTHS (2/5)
                                                    assertEquals(40.0, Fraction.TWO_FIFTHS.percentageValue(), 0.0001);
                                                    
                                                    // Test with THREE_FIFTHS (3/5)
                                                    assertEquals(60.0, Fraction.THREE_FIFTHS.percentageValue(), 0.0001);
                                                    
                                                    // Test with FOUR_FIFTHS (4/5)
                                                    assertEquals(80.0, Fraction.FOUR_FIFTHS.percentageValue(), 0.0001);
                                                }

    @Test
                                                public void testPercentageValue_WithCustomFractions() {
                                                    // Test with simple fraction 3/4
                                                    Fraction threeQuarters = new Fraction(3, 4);
                                                    assertEquals(75.0, threeQuarters.percentageValue(), 0.0001);
                                                    
                                                    // Test with fraction 7/8
                                                    Fraction sevenEighths = new Fraction(7, 8);
                                                    assertEquals(87.5, sevenEighths.percentageValue(), 0.0001);
                                                    
                                                    // Test with negative fraction -3/4
                                                    Fraction negativeThreeQuarters = new Fraction(-3, 4);
                                                    assertEquals(-75.0, negativeThreeQuarters.percentageValue(), 0.0001);
                                                }

    @Test
                                                public void testPercentageValue_WithDoubleConstructor() {
                                                    // Test with 0.5 (should be similar to ONE_HALF)
                                                    Fraction halfFromDouble = new Fraction(0.5);
                                                    assertEquals(50.0, halfFromDouble.percentageValue(), 0.0001);
                                                    
                                                    // Test with 0.3333 (should be similar to ONE_THIRD)
                                                    Fraction thirdFromDouble = new Fraction(1.0/3.0);
                                                    assertEquals(33.3333, thirdFromDouble.percentageValue(), 0.0001);
                                                    
                                                    // Test with 0.75 (should be similar to THREE_QUARTERS)
                                                    Fraction threeQuartersFromDouble = new Fraction(0.75);
                                                    assertEquals(75.0, threeQuartersFromDouble.percentageValue(), 0.0001);
                                                }

    @Test
                                                public void testPercentageValue_MockedDoubleValue() {
                                                    // Create a mock Fraction
                                                    Fraction mockFraction = mock(Fraction.class);
                                                    
                                                    // Set up the mock behavior
                                                    when(mockFraction.doubleValue()).thenReturn(0.1234);
                                                    when(mockFraction.percentageValue()).thenCallRealMethod();
                                                    
                                                    // Test the percentage calculation
                                                    assertEquals(12.34, mockFraction.percentageValue(), 0.0001);
                                                    
                                                    // Verify the interaction
                                                    verify(mockFraction).doubleValue();
                                                }

    @Test
                                            public void testAbsWithNegativeFractionDetectsMutant() {
                                                // Create a negative fraction (numerator negative, denominator positive)
                                                Fraction negativeFraction = new Fraction(-3, 4);
                                                
                                                // Call abs() which should negate the fraction
                                                Fraction result = negativeFraction.abs();
                                                
                                                // Verify numerator is now positive (original was -3)
                                                assertEquals(3, result.getNumerator());
                                                
                                                // This assertion will catch the mutant - denominator should remain unchanged (4)
                                                // Mutant would change denominator to denominator + i (where i is unknown)
                                                assertEquals(4, result.getDenominator());
                                                
                                                // Verify the fraction is indeed positive now
                                                assertTrue(result.getNumerator() >= 0);
                                            }

    @Test
                                            public void testAbsWithPositiveFraction() {
                                                // Create a positive fraction
                                                Fraction positiveFraction = new Fraction(3, 4);
                                                
                                                // Call abs() which should return the same fraction
                                                Fraction result = positiveFraction.abs();
                                                
                                                // Verify it's the same object (no negation occurred)
                                                assertSame(positiveFraction, result);
                                                
                                                // Verify numerator and denominator unchanged
                                                assertEquals(3, result.getNumerator());
                                                assertEquals(4, result.getDenominator());
                                            }

    @Test
                                            public void testAbsWithZero() {
                                                // Test with zero (should return same fraction)
                                                Fraction zero = Fraction.ZERO;
                                                Fraction result = zero.abs();
                                                
                                                // Verify it's the same object
                                                assertSame(zero, result);
                                                
                                                // Verify numerator is 0 and denominator is 1
                                                assertEquals(0, result.getNumerator());
                                                assertEquals(1, result.getDenominator());
                                            }

    @Test
                                        public void testAbsWithNegativeFractionDetectsMutant1() {
                                            // Create a negative fraction (numerator = -3, denominator = 4)
                                            Fraction negativeFraction = new Fraction(-3, 4);
                                            
                                            // Call abs() which should return new Fraction(3, 4) in original code
                                            Fraction result = negativeFraction.abs();
                                            
                                            // Verify numerator is properly negated (3)
                                            assertEquals(3, result.getNumerator());
                                            
                                            // Verify denominator remains unchanged (4)
                                            assertEquals(4, result.getDenominator());
                                            
                                            // Verify the fraction represents 0.75 (3/4) as double value
                                            assertEquals(0.75, result.doubleValue(), 0.0001);
                                        }

    @Test
                                        public void testAbsWithPositiveFraction1() {
                                            // Create a positive fraction (numerator = 3, denominator = 4)
                                            Fraction positiveFraction = new Fraction(3, 4);
                                            
                                            // Call abs() which should return the same fraction
                                            Fraction result = positiveFraction.abs();
                                            
                                            // Verify it returns the same instance (since numerator >= 0)
                                            assertSame(positiveFraction, result);
                                        }

    @Test
                                        public void testAbsWithZero1() {
                                            // Test with zero (should return same instance)
                                            Fraction zero = Fraction.ZERO;
                                            Fraction result = zero.abs();
                                            assertSame(zero, result);
                                        }

    @Test
                                public void testAbsWithNegativeFractionDetectsDenominatorMutation() {
                                    // Create a negative fraction (numerator negative, denominator positive)
                                    Fraction negativeFraction = new Fraction(-3, 5);
                                    
                                    // Call abs() which should negate the fraction
                                    Fraction result = negativeFraction.abs();
                                    
                                    // Verify numerator is now positive
                                    assertEquals(3, result.getNumerator());
                                    
                                    // This assertion will catch the mutant - original would have denominator 5,
                                    // but mutant would return denominator 4 (5-1)
                                    assertEquals(5, result.getDenominator());
                                    
                                    // Also verify the fraction value is correct
                                    assertEquals(0.6, result.doubleValue(), 0.0001);
                                }

    @Test
                                public void testAbsWithNegativeNumerator() {
                                    // Create a fraction with negative numerator and denominator with common divisor
                                    Fraction fraction = new Fraction(-4, 6);
                                    
                                    // Call abs() which should internally call negate()
                                    Fraction result = fraction.abs();
                                    
                                    // Verify the absolute value is correct
                                    assertEquals(4, result.getNumerator());
                                    assertEquals(6, result.getDenominator());
                                    
                                    // Also test with numerator that's a multiple of some number
                                    Fraction fraction2 = new Fraction(-9, 12);
                                    Fraction result2 = fraction2.abs();
                                    assertEquals(9, result2.getNumerator());
                                    assertEquals(12, result2.getDenominator());
                                }

    @Test
                                public void testAbsWithNegativeNumeratorNoCommonDivisor() {
                                    // Test with numerator and denominator having no common divisors
                                    Fraction fraction = new Fraction(-3, 7);
                                    Fraction result = fraction.abs();
                                    assertEquals(3, result.getNumerator());
                                    assertEquals(7, result.getDenominator());
                                }

    @Test
                                public void testAbsWithPositiveNumerator() {
                                    // Test that positive numerator returns same fraction
                                    Fraction fraction = new Fraction(5, 8);
                                    Fraction result = fraction.abs();
                                    assertSame(fraction, result); // Should return same instance
                                }

    @Test
                                public void testAbsWithZeroNumerator() {
                                    // Test that zero numerator returns same fraction
                                    Fraction fraction = new Fraction(0, 1);
                                    Fraction result = fraction.abs();
                                    assertSame(fraction, result); // Should return same instance
                                }

    @Test
                        public void testAbsWithNegativeFraction() {
                            // Create a negative fraction (numerator = -3, denominator = 4)
                            Fraction negativeFraction = new Fraction(-3, 4);
                            
                            // Call abs() which should negate the fraction
                            Fraction result = negativeFraction.abs();
                            
                            // Verify the numerator is now positive
                            assertEquals(3, result.getNumerator());
                            
                            // Verify the denominator remains unchanged
                            assertEquals(4, result.getDenominator());
                            
                            // Also verify the fraction is properly reduced if needed
                            Fraction negativeReducible = new Fraction(-2, 4);
                            Fraction reducedResult = negativeReducible.abs();
                            assertEquals(1, reducedResult.getNumerator());
                            assertEquals(2, reducedResult.getDenominator());
                        }

    @Test
                    public void testAbsWithNegativeFraction1() {
                        // Create a negative fraction (numerator = -1, denominator = 2)
                        Fraction negativeFraction = new Fraction(-1, 2);
                        
                        // Call abs() which should negate it
                        Fraction result = negativeFraction.abs();
                        
                        // Verify the result is positive (numerator sign)
                        assertTrue(result.getNumerator() > 0);
                        
                        // Verify the exact value is correct (1/2)
                        // This assertion would fail with the mutant since denominator would be wrong
                        assertEquals(1, result.getNumerator());
                        assertEquals(2, result.getDenominator());
                        
                        // Also verify it's not the same object reference (should be new instance)
                        assertNotSame(negativeFraction, result);
                    }

    @Test
                public void testAbsWithNegativeNumeratorDetectsMutant() {
                    // Create a fraction with negative numerator and denominator not equal to 1
                    Fraction negativeFraction = new Fraction(-3, 5);
                    
                    // Call abs() which should call negate() internally
                    Fraction result = negativeFraction.abs();
                    
                    // Verify the numerator is positive (absolute value)
                    assertEquals(3, result.getNumerator());
                    
                    // This assertion will catch the mutant - original would have denominator * 1 (5), 
                    // mutant would have denominator / 1 (5), but if 'i' was something else,
                    // this would catch the division vs multiplication difference
                    assertEquals(5, result.getDenominator());
                    
                    // Additional test case where denominator is not 1 and i is not 1
                    // (assuming negate() might be called with different parameters in some cases)
                    Fraction negativeFraction2 = new Fraction(-2, 3);
                    Fraction result2 = negativeFraction2.abs();
                    assertEquals(2, result2.getNumerator());
                    assertEquals(3, result2.getDenominator());
                }

    @Test
                public void testAbsWithNegativeFraction2() {
                    // Create a negative fraction (-1/2)
                    Fraction negativeFraction = new Fraction(-1, 2);
                    
                    // Call abs() - should return (1/2)
                    Fraction result = negativeFraction.abs();
                    
                    // Verify numerator is positive and correct
                    assertEquals(1, result.getNumerator());
                    
                    // Verify denominator remains unchanged
                    assertEquals(2, result.getDenominator());
                    
                    // Verify the whole fraction is correct
                    assertEquals(new Fraction(1, 2), result);
                }

    @Test
                public void testAbsWithPositiveFraction2() {
                    // Create a positive fraction (3/4)
                    Fraction positiveFraction = new Fraction(3, 4);
                    
                    // Call abs() - should return same fraction
                    Fraction result = positiveFraction.abs();
                    
                    // Verify it returns the same object (not a new one)
                    assertSame(positiveFraction, result);
                    
                    // Verify numerator and denominator unchanged
                    assertEquals(3, result.getNumerator());
                    assertEquals(4, result.getDenominator());
                }

    @Test
                public void testAbsWithZero2() {
                    // Test with zero (0/1)
                    Fraction zero = Fraction.ZERO;
                    
                    // Call abs() - should return same object
                    Fraction result = zero.abs();
                    
                    // Verify it returns the same object
                    assertSame(zero, result);
                }

    @Test
        public void testAbsWithNegativeFractionDetectsMutant2() {
            // Create a negative fraction (numerator = -1, denominator = 2)
            Fraction negativeFraction = new Fraction(-1, 2);
            
            // Call abs() which should negate the fraction
            Fraction result = negativeFraction.abs();
            
            // Verify the numerator is now positive
            assertEquals(1, result.getNumerator());
            
            // This assertion will catch the mutant:
            // Original code would keep denominator as 2 (just change sign)
            // Mutated code would change denominator to 2 + i (where i is some value)
            assertEquals(2, result.getDenominator());
            
            // Additional check for the complete fraction value
            assertEquals(0.5, result.doubleValue(), 0.0001);
        }

    @Test
        public void testAbsWithNegativeFraction3() {
            // Create a negative fraction (numerator = -3, denominator = 4)
            Fraction negativeFraction = new Fraction(-3, 4);
            
            // Call abs() which should internally use negate()
            Fraction result = negativeFraction.abs();
            
            // Verify the result is positive (3/4)
            assertEquals(3, result.getNumerator());
            assertEquals(4, result.getDenominator());
            
            // Also verify the original fraction wasn't modified
            assertEquals(-3, negativeFraction.getNumerator());
            assertEquals(4, negativeFraction.getDenominator());
        }

    @Test
        public void testAbsWithPositiveFraction3() {
            // Create a positive fraction (numerator = 2, denominator = 5)
            Fraction positiveFraction = new Fraction(2, 5);
            
            // Call abs() which should return the same object
            Fraction result = positiveFraction.abs();
            
            // Verify it's the same fraction (2/5)
            assertEquals(2, result.getNumerator());
            assertEquals(5, result.getDenominator());
            
            // Verify it's the same object reference (since no negation needed)
            assertSame(positiveFraction, result);
        }

}
