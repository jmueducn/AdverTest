package gentest.org.apache.commons.math.ode.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.ode.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver;
import org.apache.commons.math.analysis.solvers.UnivariateRealSolver;
import org.apache.commons.math.exception.DimensionMismatchException;
import org.apache.commons.math.exception.MathIllegalArgumentException;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.MaxCountExceededException;
import org.apache.commons.math.exception.NumberIsTooSmallException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.ode.events.EventHandler;
import org.apache.commons.math.ode.events.EventState;
import org.apache.commons.math.ode.sampling.AbstractStepInterpolator;
import org.apache.commons.math.ode.sampling.StepHandler;
import org.apache.commons.math.util.FastMath;
import org.apache.commons.math.util.Incrementor;
import org.apache.commons.math.util.Precision;
 
public class AbstractIntegratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                    public void testAcceptStep_EventRequestsReset() throws Exception {
                                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                                        org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                                                                                                                                                                                                            mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                                        when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                                                                                                        when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                                                                                                                        when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        org.apache.commons.math.ode.events.EventState eventState = 
                                                                                                                                                                                                                                                                                            mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                                                                                                                                                                                                                        when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                                        when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                                                                                                        when(eventState.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                                        when(eventState.reset(0.5, new double[]{1.05, 2.05})).thenReturn(true);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        Collection<org.apache.commons.math.ode.events.EventState> eventsStates = new ArrayList<>();
                                                                                                                                                                                                                                                                                        eventsStates.add(eventState);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.05, 2.05});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Initialize integrator and test data
                                                                                                                                                                                                                                                                                        org.apache.commons.math.ode.AbstractIntegrator integrator = 
                                                                                                                                                                                                                                                                                            new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                                                                                public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                                                    // dummy implementation for test
                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                            };
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        double[] y = new double[]{1.0, 2.0};
                                                                                                                                                                                                                                                                                        double[] yDot = new double[]{0.0, 0.0};
                                                                                                                                                                                                                                                                                        double tEnd = 1.0;
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to set private field if needed
                                                                                                                                                                                                                                                                                        Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                                                                                                                                        eventsStatesField.setAccessible(true);
                                                                                                                                                                                                                                                                                        eventsStatesField.set(integrator, eventsStates);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                                                                                                                                        statesInitializedField.setAccessible(true);
                                                                                                                                                                                                                                                                                        statesInitializedField.set(integrator, true);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to call protected method
                                                                                                                                                                                                                                                                                        Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                            "acceptStep", 
                                                                                                                                                                                                                                                                                            org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                                            double[].class, 
                                                                                                                                                                                                                                                                                            double[].class, 
                                                                                                                                                                                                                                                                                            double.class
                                                                                                                                                                                                                                                                                        );
                                                                                                                                                                                                                                                                                        acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                        double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                                        assertEquals(0.5, result, 1.0e-15);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        Field resetOccurredField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                                                                                                                                        resetOccurredField.setAccessible(true);
                                                                                                                                                                                                                                                                                        assertTrue((Boolean) resetOccurredField.get(integrator));
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        assertArrayEquals(new double[]{1.05, 2.05}, y, 1.0e-15);
                                                                                                                                                                                                                                                                                        verify(eventState).evaluateStep(interpolator);
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                            public void testAcceptStep_ReinitializesStatesWhenNotInitialized() throws Exception {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                                                                                                                                                                                    mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                                                                                when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                                                                                                when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                double[] y = new double[0];
                                                                                                                                                                                                                                                                double[] yDot = new double[0];
                                                                                                                                                                                                                                                                double tEnd = 1.0;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                Collection<org.apache.commons.math.ode.events.EventState> eventsStates = new ArrayList<>();
                                                                                                                                                                                                                                                                org.apache.commons.math.ode.events.EventState eventState = 
                                                                                                                                                                                                                                                                    mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                                                                                                                                                                                                eventsStates.add(eventState);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                org.apache.commons.math.ode.AbstractIntegrator integrator = 
                                                                                                                                                                                                                                                                    new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                        public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                            // dummy implementation for test
                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Use reflection to set private field
                                                                                                                                                                                                                                                                Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                                                                                                                statesInitializedField.setAccessible(true);
                                                                                                                                                                                                                                                                statesInitializedField.set(integrator, false);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                                                                                                                eventsStatesField.setAccessible(true);
                                                                                                                                                                                                                                                                eventsStatesField.set(integrator, eventsStates);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Use reflection to access protected method
                                                                                                                                                                                                                                                                Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                    "acceptStep", 
                                                                                                                                                                                                                                                                    org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double.class
                                                                                                                                                                                                                                                                );
                                                                                                                                                                                                                                                                acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                verify(eventState).reinitializeBegin(interpolator);
                                                                                                                                                                                                                                                                assertTrue((boolean) statesInitializedField.get(integrator));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testAcceptStep_LastStepWhenReachingTEnd() throws Exception {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                                                                                                                                                                                    mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                when(interpolator.getGlobalPreviousTime()).thenReturn(9.5);
                                                                                                                                                                                                                                                                when(interpolator.getGlobalCurrentTime()).thenReturn(10.0);
                                                                                                                                                                                                                                                                when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                                                                                when(interpolator.getInterpolatedState()).thenReturn(new double[]{2.0, 3.0});
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                double[] y = new double[2];
                                                                                                                                                                                                                                                                double[] yDot = new double[2];
                                                                                                                                                                                                                                                                double tEnd = 10.0;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                List<org.apache.commons.math.ode.sampling.StepHandler> stepHandlers = new ArrayList<org.apache.commons.math.ode.sampling.StepHandler>();
                                                                                                                                                                                                                                                                org.apache.commons.math.ode.sampling.StepHandler mockHandler = 
                                                                                                                                                                                                                                                                    mock(org.apache.commons.math.ode.sampling.StepHandler.class);
                                                                                                                                                                                                                                                                stepHandlers.add(mockHandler);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create integrator
                                                                                                                                                                                                                                                                org.apache.commons.math.ode.AbstractIntegrator integrator = 
                                                                                                                                                                                                                                                                    new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                        public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                            // dummy implementation
                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Set stepHandlers using reflection
                                                                                                                                                                                                                                                                Field field = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                                                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                                                                                                                field.set(integrator, stepHandlers);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                    "acceptStep", 
                                                                                                                                                                                                                                                                    org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double.class
                                                                                                                                                                                                                                                                );
                                                                                                                                                                                                                                                                acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                assertEquals(10.0, result, 1.0e-15);
                                                                                                                                                                                                                                                                verify(mockHandler).handleStep(interpolator, true);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                Field lastStepField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                                                                                                lastStepField.setAccessible(true);
                                                                                                                                                                                                                                                                assertTrue((Boolean) lastStepField.get(integrator));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testAcceptStep_NoEvents() throws Exception {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                                                                                                                                                                                    mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                                                                                when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                                                                                                when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                                                                                when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.1, 2.1});
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                double[] y = new double[2];
                                                                                                                                                                                                                                                                double[] yDot = new double[2];
                                                                                                                                                                                                                                                                double tEnd = 1.0;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                org.apache.commons.math.ode.AbstractIntegrator integrator = 
                                                                                                                                                                                                                                                                    new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                        public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                            // dummy implementation for test
                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Use reflection to access stepHandlers field
                                                                                                                                                                                                                                                                java.lang.reflect.Field stepHandlersField = 
                                                                                                                                                                                                                                                                    org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                                                                                                                                                                                                stepHandlersField.setAccessible(true);
                                                                                                                                                                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                                                java.util.Collection<org.apache.commons.math.ode.sampling.StepHandler> stepHandlers = 
                                                                                                                                                                                                                                                                    (java.util.Collection<org.apache.commons.math.ode.sampling.StepHandler>) stepHandlersField.get(integrator);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                org.apache.commons.math.ode.sampling.StepHandler mockHandler = 
                                                                                                                                                                                                                                                                    mock(org.apache.commons.math.ode.sampling.StepHandler.class);
                                                                                                                                                                                                                                                                stepHandlers.add(mockHandler);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Use reflection to access protected acceptStep method
                                                                                                                                                                                                                                                                java.lang.reflect.Method acceptStepMethod = 
                                                                                                                                                                                                                                                                    org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                        "acceptStep", 
                                                                                                                                                                                                                                                                        org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                        double[].class, 
                                                                                                                                                                                                                                                                        double[].class, 
                                                                                                                                                                                                                                                                        double.class
                                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                                acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                assertEquals(1.0, result, 1.0e-15);
                                                                                                                                                                                                                                                                verify(interpolator).setInterpolatedTime(1.0);
                                                                                                                                                                                                                                                                verify(mockHandler).handleStep(interpolator, false);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify boolean fields using reflection
                                                                                                                                                                                                                                                                java.lang.reflect.Field isLastStepField = 
                                                                                                                                                                                                                                                                    org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                                                                                                isLastStepField.setAccessible(true);
                                                                                                                                                                                                                                                                assertFalse(isLastStepField.getBoolean(integrator));
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                java.lang.reflect.Field resetOccurredField = 
                                                                                                                                                                                                                                                                    org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                                                                                                                resetOccurredField.setAccessible(true);
                                                                                                                                                                                                                                                                assertFalse(resetOccurredField.getBoolean(integrator));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testAcceptStepDetectsLastStepCondition() throws Exception {
                                                                                                                                                                // Create concrete integrator subclass
                                                                                                                                                                org.apache.commons.math.ode.AbstractIntegrator integrator = 
                                                                                                                                                                    new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                                                                                        @Override
                                                                                                                                                                        public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                                                                            // dummy implementation for test
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                
                                                                                                                                                                double[] y = new double[2];
                                                                                                                                                                double[] yDot = new double[2];
                                                                                                                                                                double tEnd = 10.0;
                                                                                                                                                                
                                                                                                                                                                // Mock interpolator
                                                                                                                                                                org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                                                                                    mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                                                when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                                                                
                                                                                                                                                                // Create an event state that will trigger stop
                                                                                                                                                                org.apache.commons.math.ode.events.EventState stoppingEvent = 
                                                                                                                                                                    mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                                                                                                when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                when(stoppingEvent.getEventTime()).thenReturn(0.5);
                                                                                                                                                                when(stoppingEvent.stop()).thenReturn(true); // This sets isLastStep to true
                                                                                                                                                                
                                                                                                                                                                // Use reflection to set private fields
                                                                                                                                                                java.lang.reflect.Field eventsStatesField = 
                                                                                                                                                                    org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                                                                                eventsStatesField.setAccessible(true);
                                                                                                                                                                eventsStatesField.set(integrator, java.util.Arrays.asList(stoppingEvent));
                                                                                                                                                                
                                                                                                                                                                java.lang.reflect.Field statesInitializedField = 
                                                                                                                                                                    org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                statesInitializedField.setAccessible(true);
                                                                                                                                                                statesInitializedField.set(integrator, false);
                                                                                                                                                                
                                                                                                                                                                java.lang.reflect.Field stepHandlersField = 
                                                                                                                                                                    org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                                                                                                stepHandlersField.setAccessible(true);
                                                                                                                                                                stepHandlersField.set(integrator, new java.util.ArrayList<>());
                                                                                                                                                                
                                                                                                                                                                // Use reflection to call protected method
                                                                                                                                                                java.lang.reflect.Method acceptStepMethod = 
                                                                                                                                                                    org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                        "acceptStep", 
                                                                                                                                                                        org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                                                                                        double[].class, 
                                                                                                                                                                        double[].class, 
                                                                                                                                                                        double.class
                                                                                                                                                                    );
                                                                                                                                                                acceptStepMethod.setAccessible(true);
                                                                                                                                                                double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                
                                                                                                                                                                // Verify - should return early at event time (0.5) due to stop condition
                                                                                                                                                                assertEquals(0.5, result, 1e-10);
                                                                                                                                                                
                                                                                                                                                                // Verify y was updated (wouldn't happen if mutant was active)
                                                                                                                                                                assertArrayEquals(new double[]{1.0, 2.0}, y, 1e-10);
                                                                                                                                                                
                                                                                                                                                                // Verify remaining events were processed (wouldn't happen if mutant was active)
                                                                                                                                                                verify(stoppingEvent).stepAccepted(0.5, new double[]{1.0, 2.0});
                                                                                                                                                            }

    @Test
                                                                                                                              public void testAcceptStep_ShouldNotReAddEventWhenEvaluateStepReturnsFalse() throws Exception {
                                                                                                                                  // Setup test data and mocks
                                                                                                                                  org.apache.commons.math.ode.AbstractIntegrator integrator = new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                                                      @Override
                                                                                                                                      public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                                          // dummy implementation for testing
                                                                                                                                      }
                                                                                                                                  };
                                                                                                                                  
                                                                                                                                  org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                  double[] y = new double[1];
                                                                                                                                  double[] yDot = new double[1];
                                                                                                                                  double tEnd = 10.0;
                                                                                                                                  
                                                                                                                                  // Setup initial times
                                                                                                                                  when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                  when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                  when(interpolator.isForward()).thenReturn(true);
                                                                                                                                  
                                                                                                                                  // Create a mock event that occurs once but not again
                                                                                                                                  org.apache.commons.math.ode.events.EventState event1 = mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                                                                  when(event1.evaluateStep(interpolator)).thenReturn(true).thenReturn(false);
                                                                                                                                  when(event1.getEventTime()).thenReturn(0.5);
                                                                                                                                  when(event1.stop()).thenReturn(false);
                                                                                                                                  when(event1.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                                  
                                                                                                                                  // Use reflection to set private fields
                                                                                                                                  try {
                                                                                                                                      java.lang.reflect.Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                      eventsStatesField.setAccessible(true);
                                                                                                                                      eventsStatesField.set(integrator, java.util.Collections.singletonList(event1));
                                                                                                                                      
                                                                                                                                      java.lang.reflect.Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                      statesInitializedField.setAccessible(true);
                                                                                                                                      statesInitializedField.set(integrator, true);
                                                                                                                                      
                                                                                                                                      java.lang.reflect.Field stepHandlersField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                                                                      stepHandlersField.setAccessible(true);
                                                                                                                                      stepHandlersField.set(integrator, new java.util.ArrayList<>());
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Reflection setup failed: " + e.getMessage());
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Mock interpolator responses
                                                                                                                                  when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                                                                                                                                  
                                                                                                                                  // Use reflection to call protected method
                                                                                                                                  try {
                                                                                                                                      java.lang.reflect.Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                          "acceptStep", 
                                                                                                                                          org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                                                          double[].class, 
                                                                                                                                          double[].class, 
                                                                                                                                          double.class
                                                                                                                                      );
                                                                                                                                      acceptStepMethod.setAccessible(true);
                                                                                                                                      double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                      
                                                                                                                                      // Verify behavior - event should only be processed once
                                                                                                                                      verify(event1, times(1)).stepAccepted(0.5, new double[]{1.0});
                                                                                                                                      verify(event1, times(1)).evaluateStep(interpolator);
                                                                                                                                      assertEquals(1.0, result, 0.0);
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Method invocation failed: " + e.getMessage());
                                                                                                                                  }
                                                                                                                              }

    @Test
                                                                                        public void testAcceptStepDetectsEvents() throws Exception {
                                                                                            // Setup test data
                                                                                            org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                            when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                            when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                            when(interpolator.isForward()).thenReturn(true);
                                                                                            
                                                                                            // Create an event state that should trigger
                                                                                            org.apache.commons.math.ode.events.EventState eventState = 
                                                                                                mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                            when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                            when(eventState.getEventTime()).thenReturn(0.5);
                                                                                            when(eventState.stop()).thenReturn(false);
                                                                                            when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                            
                                                                                            // Setup test object with proper implementation of abstract methods
                                                                                            org.apache.commons.math.ode.AbstractIntegrator integrator = 
                                                                                                new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                    @Override
                                                                                                    public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                        // Empty implementation for test
                                                                                                    }
                                                                                                };
                                                                                            
                                                                                            // Use reflection to set protected equations field
                                                                                            Field equationsField = org.apache.commons.math.ode.AbstractIntegrator.class
                                                                                                .getDeclaredField("equations");
                                                                                            equationsField.setAccessible(true);
                                                                                            equationsField.set(integrator, mock(org.apache.commons.math.ode.ExpandableStatefulODE.class));
                                                                                            
                                                                                            // Use reflection to set private fields since we can't access them directly
                                                                                            Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class
                                                                                                .getDeclaredField("eventStates");
                                                                                            eventsStatesField.setAccessible(true);
                                                                                            Collection<org.apache.commons.math.ode.events.EventState> eventsStates = new ArrayList<>();
                                                                                            eventsStates.add(eventState);
                                                                                            eventsStatesField.set(integrator, eventsStates);
                                                                                            
                                                                                            Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class
                                                                                                .getDeclaredField("statesInitialized");
                                                                                            statesInitializedField.setAccessible(true);
                                                                                            statesInitializedField.set(integrator, true);
                                                                                            
                                                                                            // Call method under test using reflection
                                                                                            Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class
                                                                                                .getDeclaredMethod(
                                                                                                    "acceptStep", 
                                                                                                    org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                    double[].class, 
                                                                                                    double[].class, 
                                                                                                    double.class
                                                                                                );
                                                                                            acceptStepMethod.setAccessible(true);
                                                                                            double[] y = new double[0];
                                                                                            double[] yDot = new double[0];
                                                                                            double result = (double) acceptStepMethod.invoke(
                                                                                                integrator, 
                                                                                                interpolator, 
                                                                                                y, 
                                                                                                yDot, 
                                                                                                1.0
                                                                                            );
                                                                                            
                                                                                            // Verify event was processed
                                                                                            verify(eventState).stepAccepted(0.5, any(double[].class));
                                                                                            verify(eventState).evaluateStep(interpolator);
                                                                                            
                                                                                            // Verify correct time is returned
                                                                                            assertEquals(1.0, result, 0.0);
                                                                                        }

    @Test
                                                                               public void testAcceptStep_ShouldNotSetLastStepWhenNotAtEndTime() throws Exception {
                                                                                   // Setup test data
                                                                                   double tEnd = 10.0;
                                                                                   double currentTime = 5.0; // Not equal to tEnd
                                                                                   double[] y = new double[1];
                                                                                   double[] yDot = new double[1];
                                                                                   
                                                                                   // Mock interpolator
                                                                                   org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                       mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                   when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                   when(interpolator.getGlobalCurrentTime()).thenReturn(currentTime);
                                                                                   when(interpolator.isForward()).thenReturn(true);
                                                                                   when(interpolator.getInterpolatedState()).thenReturn(new double[1]);
                                                                                   
                                                                                   // Create test integrator
                                                                                   org.apache.commons.math.ode.AbstractIntegrator integrator = 
                                                                                       new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                           @Override
                                                                                           public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                               // Empty implementation for abstract method
                                                                                           }
                                                                                       };
                                                                                   
                                                                                   // Set up empty event states that don't request stop using reflection
                                                                                   Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                   eventsStatesField.setAccessible(true);
                                                                                   eventsStatesField.set(integrator, new java.util.ArrayList<org.apache.commons.math.ode.events.EventState>());
                                                                                   
                                                                                   // Set statesInitialized to true to skip event initialization
                                                                                   Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                   statesInitializedField.setAccessible(true);
                                                                                   statesInitializedField.set(integrator, true);
                                                                                   
                                                                                   // Call the method using reflection
                                                                                   Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                       org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                   acceptStepMethod.setAccessible(true);
                                                                                   double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                   
                                                                                   // Verify behavior
                                                                                   assertEquals(currentTime, result, 0.0);
                                                                                   
                                                                                   // Check isLastStep using reflection
                                                                                   Field isLastStepField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                   isLastStepField.setAccessible(true);
                                                                                   boolean isLastStep = (boolean) isLastStepField.get(integrator);
                                                                                   assertFalse("isLastStep should be false when not at end time", isLastStep);
                                                                               }

    @Test
    public void testAcceptStepDetectsEventStop() throws Exception {
        // Setup test data and mocks
        AbstractIntegrator integrator = new AbstractIntegrator("test") {
            @Override
            public void integrate(ExpandableStatefulODE equations, double t) {
                // dummy implementation for test
            }
            
            @Override
            public void computeDerivatives(double t, double[] y, double[] yDot) {
                // dummy implementation for test
            }
        };
        
        AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
        when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
        when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
        when(interpolator.isForward()).thenReturn(true);
        
        // Create mock interpolated state
        when(interpolator.getInterpolatedState()).thenReturn(new double[0]);
        
        // Create an event state that would stop integration
        EventState stoppingEvent = mock(EventState.class);
        when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
        when(stoppingEvent.getEventTime()).thenReturn(0.5);
        when(stoppingEvent.stop()).thenReturn(true); // This should trigger stop
        
        // Set up integrator state
        Collection<EventState> eventsStates = new ArrayList<EventState>();
        eventsStates.add(stoppingEvent);
        
        // Use reflection to set private fields since they're not accessible
        Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
        eventsStatesField.setAccessible(true);
        eventsStatesField.set(integrator, eventsStates);
        
        Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
        statesInitializedField.setAccessible(true);
        statesInitializedField.set(integrator, false);
        
        // Initialize stepHandlers to empty list to avoid NPE
        Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
        stepHandlersField.setAccessible(true);
        stepHandlersField.set(integrator, new ArrayList<StepHandler>());
        
        // Test parameters
        double[] y = new double[0];
        double[] yDot = new double[0];
        double tEnd = 1.0;
        
        // Use reflection to call protected method
        Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
            "acceptStep", 
            AbstractStepInterpolator.class, 
            double[].class, 
            double[].class, 
            double.class
        );
        acceptStepMethod.setAccessible(true);
        double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
        
        // Verify the event time was returned
        assertEquals(0.5, result, 1e-10);
        
        // Verify isLastStep was set to true (would be false with the mutant)
        Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
        isLastStepField.setAccessible(true);
        assertTrue(isLastStepField.getBoolean(integrator));
        
        // Verify the event was processed
        verify(stoppingEvent).stepAccepted(0.5, any(double[].class));
        verify(stoppingEvent).stop();
    }

    @Test
    public void testAcceptStepDoesNotStopWhenNotLastStep() throws Exception {
        // Create concrete subclass of AbstractIntegrator
        AbstractIntegrator integrator = new AbstractIntegrator("test") {
            @Override
            public void integrate(ExpandableStatefulODE equations, double t) {
                // Empty implementation for test
            }
        };
        
        // Create mock interpolator
        org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
            mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
        double[] y = new double[2];
        double[] yDot = new double[2];
        double tEnd = 10.0;
        
        // Configure interpolator
        when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
        when(interpolator.getGlobalCurrentTime()).thenReturn(5.0);
        when(interpolator.isForward()).thenReturn(true);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
        
        // Use reflection to set private/protected fields
        Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
        stepHandlersField.setAccessible(true);
        stepHandlersField.set(integrator, new java.util.ArrayList<org.apache.commons.math.ode.sampling.StepHandler>());
        
        Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
        eventsStatesField.setAccessible(true);
        eventsStatesField.set(integrator, new java.util.ArrayList<org.apache.commons.math.ode.events.EventState>());
        
        Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
        isLastStepField.setAccessible(true);
        isLastStepField.set(integrator, false);
        
        Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
        statesInitializedField.setAccessible(true);
        statesInitializedField.set(integrator, true);
        
        // Get protected method via reflection
        Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
            "acceptStep",
            org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class,
            double[].class,
            double[].class,
            double.class
        );
        acceptStepMethod.setAccessible(true);
        
        // Call the method
        double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
        
        // Verify behavior
        assertEquals(5.0, result, 0.0);
        assertFalse((boolean) isLastStepField.get(integrator));
        assertArrayEquals(new double[2], y, 0.0);
        verify(interpolator, atLeastOnce()).setInterpolatedTime(anyDouble());
    }

    @Test
    public void testAcceptStep_ShouldNotStopWhenNoEventsRequestStop() throws Exception {
        // Setup test data and mocks
        AbstractIntegrator integrator = new AbstractIntegrator("test") {
            @Override
            public void integrate(ExpandableStatefulODE equations, double t) {
                // dummy implementation for test
            }
            
            @Override
            protected void sanityChecks(ExpandableStatefulODE equations, double t) {
                // dummy implementation for test
            }
            
            @Override
            public void computeDerivatives(double t, double[] y, double[] yDot) {
                // dummy implementation for test
            }
        };
        
        AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
        double[] y = new double[1];
        double[] yDot = new double[1];
        double tEnd = 10.0;
        
        // Configure interpolator
        when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
        when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
        when(interpolator.isForward()).thenReturn(true);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{0.0});
        
        // Create mock event states that don't request stop
        EventState eventState1 = mock(EventState.class);
        when(eventState1.evaluateStep(interpolator)).thenReturn(false);
        when(eventState1.stop()).thenReturn(false);
        
        EventState eventState2 = mock(EventState.class);
        when(eventState2.evaluateStep(interpolator)).thenReturn(false);
        when(eventState2.stop()).thenReturn(false);
        
        // Use reflection to set private fields
        Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
        eventsStatesField.setAccessible(true);
        Collection<EventState> eventsStates = new ArrayList<EventState>();
        eventsStates.add(eventState1);
        eventsStates.add(eventState2);
        eventsStatesField.set(integrator, eventsStates);
        
        Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
        statesInitializedField.setAccessible(true);
        statesInitializedField.set(integrator, true);
        
        // Initialize step handlers to empty list to avoid NPE
        Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
        stepHandlersField.setAccessible(true);
        stepHandlersField.set(integrator, new ArrayList<StepHandler>());
        
        // Execute using reflection to call protected method
        Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
            AbstractStepInterpolator.class, double[].class, double[].class, double.class);
        acceptStepMethod.setAccessible(true);
        double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
        
        // Verify using reflection to check protected field
        Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
        isLastStepField.setAccessible(true);
        boolean isLastStep = (boolean) isLastStepField.get(integrator);
        
        assertFalse("Integration should not stop when no events request stop", isLastStep);
        assertEquals(1.0, result, 1e-10);
        
        // Verify event states were processed
        verify(eventState1).stepAccepted(1.0, new double[]{0.0});
        verify(eventState2).stepAccepted(1.0, new double[]{0.0});
    }

    @Test
    public void testAcceptStep_ShouldNotAddEventWhenEvaluateStepReturnsFalse() {
        // Setup test data
        AbstractIntegrator integrator = new AbstractIntegrator("test") {
            @Override
            public void integrate(ExpandableStatefulODE equations, double t) {
                // Empty implementation for test purposes
            }
            
            @Override
            protected void sanityChecks(ExpandableStatefulODE equations, double t) {
                // Empty implementation for test purposes
            }
        };
        
        AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
        when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
        when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
        when(interpolator.isForward()).thenReturn(true);
        
        // Create mock EventState that returns false from evaluateStep
        EventState falseEvent = mock(EventState.class);
        when(falseEvent.evaluateStep(interpolator)).thenReturn(false);
        
        // Set up integrator state
        Collection<EventState> eventsStates = new ArrayList<EventState>();
        eventsStates.add(falseEvent);
        
        // Use reflection to set private fields since they're not accessible
        try {
            Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
            eventsStatesField.setAccessible(true);
            eventsStatesField.set(integrator, eventsStates);
            
            Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
            statesInitializedField.setAccessible(true);
            statesInitializedField.set(integrator, true);
        } catch (Exception e) {
            fail("Failed to set up test via reflection: " + e.getMessage());
        }
        
        // Test parameters
        double[] y = new double[0];
        double[] yDot = new double[0];
        double tEnd = 2.0;
        
        // Execute test using reflection to access protected method
        try {
            Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                "acceptStep", AbstractStepInterpolator.class, double[].class, double[].class, double.class);
            acceptStepMethod.setAccessible(true);
            double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
            
            // Verify - the falseEvent should not be processed
            verify(falseEvent, never()).getEventTime(); // Would be called if added to occuringEvents
            verify(falseEvent, times(1)).stepAccepted(anyDouble(), any(double[].class)); // Called at end for all events
            assertEquals(1.0, result, 1e-10); // Verify normal step completion
        } catch (Exception e) {
            fail("Failed to invoke acceptStep method: " + e.getMessage());
        }
    }

    @Test
    public void testAcceptStepDetectsStopRequestFromEventState() throws Exception {
        // Setup test data and mocks
        org.apache.commons.math.ode.AbstractIntegrator integrator = new org.apache.commons.math.ode.AbstractIntegrator("test") {
            @Override
            public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                // dummy implementation for test
            }
        };
        
        org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
        double[] y = new double[0];
        double[] yDot = new double[0];
        double tEnd = 10.0;
        
        // Setup event states - one that requests stop
        org.apache.commons.math.ode.events.EventState stoppingEvent = mock(org.apache.commons.math.ode.events.EventState.class);
        when(stoppingEvent.stop()).thenReturn(true);
        when(stoppingEvent.evaluateStep(any(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class))).thenReturn(false);
        when(stoppingEvent.getEventTime()).thenReturn(5.0);
        
        // Set up other event state that doesn't stop
        org.apache.commons.math.ode.events.EventState continuingEvent = mock(org.apache.commons.math.ode.events.EventState.class);
        when(continuingEvent.stop()).thenReturn(false);
        when(continuingEvent.evaluateStep(any(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class))).thenReturn(false);
        when(continuingEvent.getEventTime()).thenReturn(5.0);
        
        // Set up interpolator behavior
        when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
        when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
        when(interpolator.getInterpolatedState()).thenReturn(y);
        when(interpolator.isForward()).thenReturn(true);
        doNothing().when(interpolator).setSoftPreviousTime(anyDouble());
        doNothing().when(interpolator).setSoftCurrentTime(anyDouble());
        doNothing().when(interpolator).setInterpolatedTime(anyDouble());
        
        // Inject our test event states into the integrator using reflection
        java.lang.reflect.Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
        eventsStatesField.setAccessible(true);
        java.util.Collection<org.apache.commons.math.ode.events.EventState> eventsStates = new java.util.ArrayList<>();
        eventsStates.add(stoppingEvent);
        eventsStates.add(continuingEvent);
        eventsStatesField.set(integrator, eventsStates);
        
        // Set statesInitialized to true to skip initialization
        java.lang.reflect.Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
        statesInitializedField.setAccessible(true);
        statesInitializedField.set(integrator, true);
        
        // Initialize empty step handlers list to prevent NPE
        java.lang.reflect.Field stepHandlersField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("stepHandlers");
        stepHandlersField.setAccessible(true);
        stepHandlersField.set(integrator, new java.util.ArrayList<org.apache.commons.math.ode.sampling.StepHandler>());
        
        // Use reflection to call the protected acceptStep method
        java.lang.reflect.Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
            "acceptStep", 
            org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
            double[].class, 
            double[].class, 
            double.class
        );
        acceptStepMethod.setAccessible(true);
        acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
        
        // Verify isLastStep was set to true due to stoppingEvent
        java.lang.reflect.Field isLastStepField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("isLastStep");
        isLastStepField.setAccessible(true);
        boolean isLastStep = isLastStepField.getBoolean(integrator);
        
        assertTrue("Integration should stop when any EventState requests stop", isLastStep);
    }


}
