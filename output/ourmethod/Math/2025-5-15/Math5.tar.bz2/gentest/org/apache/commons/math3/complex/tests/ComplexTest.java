package gentest.org.apache.commons.math3.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathUtils;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testReciprocal_NaN() {
            // Test NaN case
            Complex nanComplex = new Complex(Double.NaN, Double.NaN);
            assertTrue(nanComplex.reciprocal().isNaN());
        }

    @Test
        public void testReciprocal_Zero() {
            // Test zero case (should return INF)
            Complex zeroComplex = new Complex(0.0, 0.0);
            assertEquals(Complex.INF, zeroComplex.reciprocal());
        }

    @Test
        public void testReciprocal_Infinite() {
            // Test infinite case (should return ZERO)
            Complex infComplex = new Complex(Double.POSITIVE_INFINITY, 0.0);
            assertEquals(Complex.ZERO, infComplex.reciprocal());
            
            Complex infComplex2 = new Complex(0.0, Double.POSITIVE_INFINITY);
            assertEquals(Complex.ZERO, infComplex2.reciprocal());
        }

    @Test
        public void testReciprocal_RealDominant() {
            // Test case where real part is larger than imaginary part
            Complex complex = new Complex(4.0, 2.0);
            Complex reciprocal = complex.reciprocal();
            
            // Expected: (4/(4²+2²), -2/(4²+2²)) = (4/20, -2/20) = (0.2, -0.1)
            assertEquals(0.2, reciprocal.getReal(), 1e-10);
            assertEquals(-0.1, reciprocal.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_ImaginaryDominant() {
            // Test case where imaginary part is larger than real part
            Complex complex = new Complex(2.0, 4.0);
            Complex reciprocal = complex.reciprocal();
            
            // Expected: (2/(2²+4²), -4/(2²+4²)) = (2/20, -4/20) = (0.1, -0.2)
            assertEquals(0.1, reciprocal.getReal(), 1e-10);
            assertEquals(-0.2, reciprocal.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_RealOnly() {
            // Test with only real part (imaginary = 0)
            Complex complex = new Complex(5.0, 0.0);
            Complex reciprocal = complex.reciprocal();
            
            assertEquals(0.2, reciprocal.getReal(), 1e-10);
            assertEquals(0.0, reciprocal.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_ImaginaryOnly() {
            // Test with only imaginary part (real = 0)
            Complex complex = new Complex(0.0, 5.0);
            Complex reciprocal = complex.reciprocal();
            
            assertEquals(0.0, reciprocal.getReal(), 1e-10);
            assertEquals(-0.2, reciprocal.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_One() {
            // Test reciprocal of ONE (should be ONE)
            assertEquals(Complex.ONE, Complex.ONE.reciprocal());
        }

    @Test
        public void testReciprocal_I() {
            // Test reciprocal of I (should be -I)
            Complex reciprocalI = Complex.I.reciprocal();
            assertEquals(0.0, reciprocalI.getReal(), 1e-10);
            assertEquals(-1.0, reciprocalI.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_SmallValues() {
            // Test with very small values
            Complex complex = new Complex(1e-20, 1e-30);
            Complex reciprocal = complex.reciprocal();
            
            // Expected behavior with very small numbers
            assertEquals(1e20, reciprocal.getReal(), 1e10);
            assertEquals(-1e10, reciprocal.getImaginary(), 1e0);
        }

    @Test
        public void testReciprocal_LargeValues() {
            // Test with very large values
            Complex complex = new Complex(1e20, 1e30);
            Complex reciprocal = complex.reciprocal();
            
            // Expected behavior with very large numbers
            assertEquals(1e-30, reciprocal.getReal(), 1e-40);
            assertEquals(-1e-20, reciprocal.getImaginary(), 1e-30);
        }

}
