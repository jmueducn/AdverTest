package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.special.Beta;
 
public class FDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                            public void testGetInitialDomain_DenominatorLessThan() throws Exception {
                                                FDistributionImpl fDistribution = new FDistributionImpl(5.0, 1.5);
                                                Method getInitialDomain = FDistributionImpl.class.getDeclaredMethod("getInitialDomain", double.class);
                                                getInitialDomain.setAccessible(true);
                                                double result = (Double) getInitialDomain.invoke(fDistribution, 0.5);
                                                assertEquals(1.0, result, 0.0001);
                                            }

    @Test
                                            public void testGetInitialDomain_DenominatorExactly() throws Exception {
                                                org.apache.commons.math.distribution.FDistributionImpl fDistribution = new org.apache.commons.math.distribution.FDistributionImpl(5.0, 2.0);
                                                
                                                // Use reflection to access protected method
                                                java.lang.reflect.Method method = org.apache.commons.math.distribution.FDistributionImpl.class
                                                        .getDeclaredMethod("getInitialDomain", double.class);
                                                method.setAccessible(true);
                                                double result = (Double) method.invoke(fDistribution, 0.5);
                                                
                                                assertEquals(1.0, result, 0.0001);
                                            }

    @Test
                                            public void testGetInitialDomain_DenominatorJustAbove() throws Exception {
                                                FDistributionImpl fDistribution = new FDistributionImpl(5.0, 2.0001);
                                                double expected = 2.0001 / (2.0001 - 2.0);
                                                
                                                // Use reflection to access protected method
                                                Method getInitialDomainMethod = FDistributionImpl.class.getDeclaredMethod("getInitialDomain", double.class);
                                                getInitialDomainMethod.setAccessible(true);
                                                double result = (Double) getInitialDomainMethod.invoke(fDistribution, 0.5);
                                                
                                                assertEquals(expected, result, 0.0001);
                                            }

    @Test
                                            public void testGetInitialDomain_DenominatorGreaterThan() throws Exception {
                                                FDistributionImpl fDistribution = new FDistributionImpl(5.0, 10.0);
                                                double expected = 10.0 / (10.0 - 2.0);
                                                
                                                // Use reflection to access protected method
                                                Method getInitialDomainMethod = FDistributionImpl.class.getDeclaredMethod("getInitialDomain", double.class);
                                                getInitialDomainMethod.setAccessible(true);
                                                double result = (Double) getInitialDomainMethod.invoke(fDistribution, 0.5);
                                                
                                                assertEquals(expected, result, 0.0001);
                                            }

    @Test
                                            public void testGetInitialDomain_VeryLargeDenominator() throws Exception {
                                                FDistributionImpl fDistribution = new FDistributionImpl(5.0, 1.0E20);
                                                double expected = 1.0E20 / (1.0E20 - 2.0);
                                                
                                                // Use reflection to access protected method
                                                Method getInitialDomainMethod = FDistributionImpl.class.getDeclaredMethod("getInitialDomain", double.class);
                                                getInitialDomainMethod.setAccessible(true);
                                                double result = (Double) getInitialDomainMethod.invoke(fDistribution, 0.5);
                                                
                                                assertEquals(expected, result, 0.0001);
                                            }

    @Test
                                            public void testGetInitialDomain_WithDifferentPValues() throws Exception {
                                                FDistributionImpl fDistribution = new FDistributionImpl(5.0, 10.0);
                                                double expected = 10.0 / (10.0 - 2.0);
                                                
                                                // Get the protected method using reflection
                                                Method getInitialDomain = FDistributionImpl.class.getDeclaredMethod("getInitialDomain", double.class);
                                                getInitialDomain.setAccessible(true);
                                                
                                                // p value shouldn't affect the result in this implementation
                                                assertEquals(expected, (Double)getInitialDomain.invoke(fDistribution, 0.0), 0.0001);
                                                assertEquals(expected, (Double)getInitialDomain.invoke(fDistribution, 0.5), 0.0001);
                                                assertEquals(expected, (Double)getInitialDomain.invoke(fDistribution, 1.0), 0.0001);
                                            }

    @Test
                                       public void testGetDomainUpperBound() throws Exception {
                                           // Create an instance with arbitrary degrees of freedom
                                           FDistributionImpl fDist = new FDistributionImpl(5.0, 10.0);
                                           
                                           // Get the protected method using reflection
                                           Method getDomainUpperBound = FDistributionImpl.class.getDeclaredMethod(
                                               "getDomainUpperBound", double.class);
                                           getDomainUpperBound.setAccessible(true);
                                           
                                           // Call the method and verify it returns MAX_VALUE
                                           double upperBound = (Double) getDomainUpperBound.invoke(fDist, 0.5); // p value doesn't matter
                                           
                                           // Assert the correct value is returned
                                           assertEquals("Upper bound should be Double.MAX_VALUE", 
                                                       Double.MAX_VALUE, upperBound, 0.0);
                                       }

    @Test
                                  public void testGetDomainUpperBound1() throws Exception {
                                      // Create an instance of FDistributionImpl with arbitrary degrees of freedom
                                      FDistributionImpl fDistribution = new FDistributionImpl(5.0, 10.0);
                                      
                                      // Get the protected method using reflection
                                      Method getDomainUpperBound = FDistributionImpl.class.getDeclaredMethod(
                                          "getDomainUpperBound", double.class);
                                      getDomainUpperBound.setAccessible(true);
                                      
                                      // Call the method under test
                                      double upperBound = (double) getDomainUpperBound.invoke(fDistribution, 0.5); // p value is arbitrary
                                      
                                      // Assert that the upper bound is Double.MAX_VALUE
                                      assertEquals("Upper bound of F-distribution domain should be Double.MAX_VALUE", 
                                                   Double.MAX_VALUE, upperBound, 0.0);
                                  }

    @Test
                             public void testGetDomainUpperBoundReturnsPositiveMaxValue() {
                                 // Arrange
                                 double numeratorDF = 5.0;
                                 double denominatorDF = 10.0;
                                 FDistributionImpl fDistribution = new FDistributionImpl(numeratorDF, denominatorDF);
                                 
                                 // Act
                                 double upperBound = 0;
                                 try {
                                     Method method = FDistributionImpl.class.getDeclaredMethod("getDomainUpperBound", double.class);
                                     method.setAccessible(true);
                                     upperBound = (Double) method.invoke(fDistribution, 0.5); // p value doesn't matter for this test
                                 } catch (Exception e) {
                                     fail("Failed to invoke getDomainUpperBound method: " + e.getMessage());
                                 }
                                 
                                 // Assert
                                 assertEquals("Upper bound should be Double.MAX_VALUE", 
                                             Double.MAX_VALUE, 
                                             upperBound, 
                                             0.0);
                                 assertTrue("Upper bound should be positive", 
                                           upperBound > 0);
                             }

    @Test
                        public void testGetDomainUpperBound2() throws Exception {
                            // Create test instance with arbitrary degrees of freedom
                            FDistributionImpl fDist = new FDistributionImpl(5.0, 10.0);
                            
                            // Get the protected method using reflection
                            Method getDomainUpperBound = FDistributionImpl.class.getDeclaredMethod(
                                "getDomainUpperBound", double.class);
                            getDomainUpperBound.setAccessible(true);
                            
                            // Test with positive value
                            double testP1 = 0.5;
                            assertEquals(Double.MAX_VALUE, 
                                (Double)getDomainUpperBound.invoke(fDist, testP1), 0.0);
                            
                            // Test with negative value
                            double testP2 = -1.0;
                            assertEquals(Double.MAX_VALUE, 
                                (Double)getDomainUpperBound.invoke(fDist, testP2), 0.0);
                            
                            // Test with zero
                            double testP3 = 0.0;
                            assertEquals(Double.MAX_VALUE, 
                                (Double)getDomainUpperBound.invoke(fDist, testP3), 0.0);
                            
                            // Test with very large value
                            double testP4 = Double.MAX_VALUE;
                            assertEquals(Double.MAX_VALUE, 
                                (Double)getDomainUpperBound.invoke(fDist, testP4), 0.0);
                        }

    @Test
                   public void testGetDomainUpperBound3() throws Exception {
                       // Create an instance of FDistributionImpl with arbitrary degrees of freedom
                       FDistributionImpl fDistribution = new FDistributionImpl(5.0, 10.0);
                       
                       // Use reflection to access the protected method
                       Method getDomainUpperBound = FDistributionImpl.class.getDeclaredMethod(
                           "getDomainUpperBound", double.class);
                       getDomainUpperBound.setAccessible(true);
                       
                       // Call the method under test
                       double upperBound = (double) getDomainUpperBound.invoke(fDistribution, 0.5);
                       
                       // Assert that the returned value is Double.MAX_VALUE
                       assertEquals(Double.MAX_VALUE, upperBound, 0.0);
                       
                       // Additional assertions to catch the NaN mutant
                       assertFalse(Double.isNaN(upperBound)); // Should not be NaN
                       assertTrue(Double.isFinite(upperBound)); // Should be finite (MAX_VALUE is finite)
                   }

    @Test
              public void testGetDomainUpperBoundReturnsMaxValue() {
                  // Arrange
                  FDistributionImpl fDistribution = new FDistributionImpl(5.0, 10.0);
                  
                  // Act
                  double upperBound = 0;
                  try {
                      Method method = FDistributionImpl.class.getDeclaredMethod("getDomainUpperBound", double.class);
                      method.setAccessible(true);
                      upperBound = (Double) method.invoke(fDistribution, 0.5);
                  } catch (Exception e) {
                      fail("Failed to invoke getDomainUpperBound method: " + e.getMessage());
                  }
                  
                  // Assert
                  assertEquals("Upper bound should be Double.MAX_VALUE", 
                             Double.MAX_VALUE, upperBound, 0.0);
                  assertTrue("Upper bound should be finite", 
                            Double.isFinite(upperBound));
              }

    @Test
         public void testGetDomainUpperBoundReturnsMaxValue1() {
             // Arrange
             double numeratorDF = 5.0;
             double denominatorDF = 10.0;
             FDistributionImpl fDistribution = new FDistributionImpl(numeratorDF, denominatorDF);
             
             // Act
             double upperBound = 0;
             try {
                 Method method = FDistributionImpl.class.getDeclaredMethod("getDomainUpperBound", double.class);
                 method.setAccessible(true);
                 upperBound = (Double) method.invoke(fDistribution, 0.5); // p value doesn't matter for this test
             } catch (Exception e) {
                 fail("Failed to access getDomainUpperBound method: " + e.getMessage());
             }
             
             // Assert
             assertEquals("Upper bound should be Double.MAX_VALUE", 
                         Double.MAX_VALUE, 
                         upperBound, 
                         0.0);
         }

    @Test
    public void testGetDomainUpperBoundReturnsFiniteValue() throws Exception {
        // Arrange
        FDistributionImpl fDistribution = new FDistributionImpl(5.0, 10.0);
        
        // Use reflection to access protected method
        Method method = FDistributionImpl.class.getDeclaredMethod("getDomainUpperBound", double.class);
        method.setAccessible(true);
        
        // Act
        double upperBound = (Double) method.invoke(fDistribution, 0.5);
        
        // Assert
        assertTrue("Upper bound should be a finite value", Double.isFinite(upperBound));
        assertEquals("Upper bound should be Double.MAX_VALUE", 
                    Double.MAX_VALUE, upperBound, 0.0);
    }


}
