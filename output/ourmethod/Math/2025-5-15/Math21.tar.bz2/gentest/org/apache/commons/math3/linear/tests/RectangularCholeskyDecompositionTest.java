package gentest.org.apache.commons.math3.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.linear.*;
import org.apache.commons.math3.util.FastMath;
 
public class RectangularCholeskyDecompositionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                public void testConstructorWithPositiveDefiniteMatrix() {
                    // Create a positive definite matrix (2x2)
                    double[][] data = {{4, 12}, {12, 37}};
                    RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                    
                    RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                    
                    // Verify rank is full (2)
                    assertEquals(2, decomposition.getRank());
                    
                    // Verify root matrix
                    RealMatrix root = decomposition.getRootMatrix();
                    assertEquals(2, root.getRowDimension());
                    assertEquals(2, root.getColumnDimension());
                    
                    // Verify decomposition: matrix should equal root * root.transpose()
                    RealMatrix reconstructed = root.multiply(root.transpose());
                    assertArrayEquals(data[0], reconstructed.getRow(0), 1.0e-10);
                    assertArrayEquals(data[1], reconstructed.getRow(1), 1.0e-10);
                }

 @Test
                public void testConstructorWithPositiveSemidefiniteMatrix() {
                    // Create a positive semi-definite matrix with rank 1 (2x2)
                    double[][] data = {{1, 2}, {2, 4}};
                    RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                    
                    RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                    
                    // Verify rank is 1
                    assertEquals(1, decomposition.getRank());
                    
                    // Verify root matrix has correct dimensions
                    RealMatrix root = decomposition.getRootMatrix();
                    assertEquals(2, root.getRowDimension());
                    assertEquals(1, root.getColumnDimension());
                    
                    // Verify decomposition
                    RealMatrix reconstructed = root.multiply(root.transpose());
                    assertArrayEquals(data[0], reconstructed.getRow(0), 1.0e-10);
                    assertArrayEquals(data[1], reconstructed.getRow(1), 1.0e-10);
                }

 @Test
                public void testConstructorWithNegativeDiagonalElement() {
                    // Create a matrix with negative diagonal element
                    double[][] data = {{4, 12}, {12, -1}};
                    RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                    
                    thrown.expect(NonPositiveDefiniteMatrixException.class);
                    thrown.expectMessage("not positive definite");
                    
                    new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                }

 @Test
                public void testConstructorWithZeroMatrix() {
                    // Create a zero matrix
                    double[][] data = {{0, 0}, {0, 0}};
                    RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                    
                    thrown.expect(NonPositiveDefiniteMatrixException.class);
                    thrown.expectMessage("not positive definite");
                    
                    new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                }

 @Test
                public void testConstructorWithSmallTolerance() {
                    // Create a matrix with very small diagonal element
                    double[][] data = {{1.0e-20, 0}, {0, 1}};
                    RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                    
                    // With strict tolerance, should throw exception
                    thrown.expect(NonPositiveDefiniteMatrixException.class);
                    new RectangularCholeskyDecomposition(matrix, 1.0e-30);
                }

 @Test
                public void testConstructorWithLargeMatrix() {
                    // Create a 4x4 positive definite matrix
                    double[][] data = {
                        {4, 0, 0, 0},
                        {0, 9, 0, 0},
                        {0, 0, 1, 0},
                        {0, 0, 0, 16}
                    };
                    RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                    
                    RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                    
                    assertEquals(4, decomposition.getRank());
                    RealMatrix root = decomposition.getRootMatrix();
                    
                    // Verify decomposition
                    RealMatrix reconstructed = root.multiply(root.transpose());
                    for (int i = 0; i < 4; i++) {
                        assertArrayEquals(data[i], reconstructed.getRow(i), 1.0e-10);
                    }
                }

 @Test
                public void testConstructorWithNonSquareMatrix() {
                    // Try to decompose a non-square matrix (should fail before our constructor)
                    double[][] data = {{1, 2, 3}, {4, 5, 6}};
                    RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                    
                    thrown.expect(NonSquareMatrixException.class);
                    new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                }

 @Test
                public void testGetRootMatrix() {
                    double[][] data = {{4, 12}, {12, 37}};
                    RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                    
                    RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                    RealMatrix root = decomposition.getRootMatrix();
                    
                    assertNotNull(root);
                    assertEquals(2, root.getRowDimension());
                    assertEquals(2, root.getColumnDimension());
                }

 @Test
                public void testGetRank() {
                    double[][] fullRankData = {{4, 12}, {12, 37}};
                    RealMatrix fullRankMatrix = MatrixUtils.createRealMatrix(fullRankData);
                    RectangularCholeskyDecomposition fullRankDecomp = new RectangularCholeskyDecomposition(fullRankMatrix, 1.0e-10);
                    assertEquals(2, fullRankDecomp.getRank());
                    
                    double[][] rank1Data = {{1, 2}, {2, 4}};
                    RealMatrix rank1Matrix = MatrixUtils.createRealMatrix(rank1Data);
                    RectangularCholeskyDecomposition rank1Decomp = new RectangularCholeskyDecomposition(rank1Matrix, 1.0e-10);
                    assertEquals(1, rank1Decomp.getRank());
                }

 @Test
                public void testConstructorWithPivotingNeeded() {
                    // Create matrix where pivoting will be needed (diagonal elements not in descending order)
                    double[][] data = {
                        {1, 0.5},
                        {0.5, 2}
                    };
                    RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                    
                    RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                    
                    assertEquals(2, decomposition.getRank());
                    RealMatrix root = decomposition.getRootMatrix();
                    RealMatrix reconstructed = root.multiply(root.transpose());
                    
                    assertArrayEquals(data[0], reconstructed.getRow(0), 1.0e-10);
                    assertArrayEquals(data[1], reconstructed.getRow(1), 1.0e-10);
                }

 @Test
       public void testFindMaxDiagonalElementSkipsCurrentRow() {
           // Create a test matrix where the diagonal elements are in descending order
           // This ensures the max element is always at position r
           double[][] testData = {
               {4.0, 1.0, 1.0},
               {1.0, 3.0, 1.0},
               {1.0, 1.0, 2.0}
           };
           RealMatrix matrix = MatrixUtils.createRealMatrix(testData);
           double small = 1e-10;
           
           // This should execute without exceptions
           RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
           
           // Verify the decomposition is correct
           RealMatrix root = decomposition.getRootMatrix();
           RealMatrix reconstructed = root.multiply(root.transpose());
           
           // The reconstruction should match the original matrix (within floating point precision)
           for (int i = 0; i < matrix.getRowDimension(); i++) {
               for (int j = 0; j < matrix.getColumnDimension(); j++) {
                   assertEquals(matrix.getEntry(i, j), reconstructed.getEntry(i, j), 1e-10);
               }
           }
           
           // Verify rank is correct (full rank in this case)
           assertEquals(3, decomposition.getRank());
           
           // The key test is that the decomposition worked correctly despite having
           // the max element at each r position - the mutant would have done extra
           // comparisons but the result should be the same
       }

 @Test
      public void testCholeskyDecompositionWithEqualDiagonalElements() {
          // Create a matrix with two equal diagonal elements
          double[][] data = {
              {4.0, 2.0, 1.0},
              {2.0, 4.0, 2.0},  // This diagonal element equals the first one
              {1.0, 2.0, 1.0}
          };
          RealMatrix matrix = MatrixUtils.createRealMatrix(data);
          double small = 1.0e-10;
          
          // Expected root matrix when using strict greater-than (original behavior)
          double[][] expectedRootData = {
              {2.0, 0.0},
              {1.0, 1.7320508075688772},
              {0.5, 0.8660254037844386}
          };
          RealMatrix expectedRoot = MatrixUtils.createRealMatrix(expectedRootData);
          
          // Perform the decomposition
          RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
          RealMatrix actualRoot = decomposition.getRootMatrix();
          
          // Verify the root matrix matches expected
          assertEquals(expectedRoot.getRowDimension(), actualRoot.getRowDimension());
          assertEquals(expectedRoot.getColumnDimension(), actualRoot.getColumnDimension());
          for (int i = 0; i < expectedRoot.getRowDimension(); i++) {
              for (int j = 0; j < expectedRoot.getColumnDimension(); j++) {
                  assertEquals(expectedRoot.getEntry(i, j), actualRoot.getEntry(i, j), 1.0e-10);
              }
          }
          
          // Verify rank
          assertEquals(2, decomposition.getRank());
      }

 @Test
     public void testRowSwappingWithNonOrderedDiagonals() {
         // Create a 3x3 matrix where diagonal elements are not in order
         double[][] data = {
             {4.0, 1.0, 1.0},  // diagonal element 4.0 (row 0)
             {1.0, 5.0, 1.0},  // diagonal element 5.0 (row 1) - should be first
             {1.0, 1.0, 3.0}   // diagonal element 3.0 (row 2)
         };
         RealMatrix matrix = MatrixUtils.createRealMatrix(data);
         double small = 1.0e-10;
         
         // Create decomposition - this is where the mutation would affect behavior
         RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
         
         // Get the resulting root matrix
         RealMatrix root = decomposition.getRootMatrix();
         
         // Verify the root matrix structure
         // With proper swapping, first column should come from original row 1 (max diagonal)
         assertEquals(5.0, root.getEntry(1, 0), 1.0e-10);  // sqrt(5.0) in position (1,0)
         assertEquals(1.0/Math.sqrt(5.0), root.getEntry(0, 0), 1.0e-10);  // transformed value
         assertEquals(1.0/Math.sqrt(5.0), root.getEntry(2, 0), 1.0e-10);  // transformed value
         
         // Verify rank (should be full rank for this positive definite matrix)
         assertEquals(3, decomposition.getRank());
     }

 @Test
    public void testRowSwappingDetectsMutant() {
        // Create a test matrix where row swapping is needed
        // Diagonal elements: [4, 9, 1] (9 should be first)
        double[][] data = {
            {4, 0, 0},
            {0, 9, 0},
            {0, 0, 1}
        };
        RealMatrix matrix = MatrixUtils.createRealMatrix(data);
        double small = 1e-10;
        
        // Perform decomposition
        RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
        RealMatrix root = decomposition.getRootMatrix();
        
        // Verify the root matrix has rows in correct order (max diagonal first)
        // Expected order after swap: row1 (9), row0 (4), row2 (1)
        assertEquals(3, root.getRowDimension());
        assertEquals(3, root.getColumnDimension());
        
        // Check first row (should be from original row 1)
        assertEquals(3.0, root.getEntry(0, 0), 1e-10);  // sqrt(9)
        assertEquals(0.0, root.getEntry(0, 1), 1e-10);
        assertEquals(0.0, root.getEntry(0, 2), 1e-10);
        
        // Check second row (should be from original row 0)
        assertEquals(2.0, root.getEntry(1, 0), 1e-10);  // sqrt(4)
        assertEquals(0.0, root.getEntry(1, 1), 1e-10);
        assertEquals(0.0, root.getEntry(1, 2), 1e-10);
        
        // Check third row (should be from original row 2)
        assertEquals(1.0, root.getEntry(2, 0), 1e-10);  // sqrt(1)
        assertEquals(0.0, root.getEntry(2, 1), 1e-10);
        assertEquals(0.0, root.getEntry(2, 2), 1e-10);
    }

 @Test
   public void testDiagonalElementExactlyEqualToSmall() {
       // Create a matrix with one diagonal element exactly equal to small
       double small = 1e-10;
       double[][] data = {
           {1.0, 0.0, 0.0},
           {0.0, small, 0.0},  // diagonal element exactly equals small
           {0.0, 0.0, 1.0}
       };
       RealMatrix matrix = MatrixUtils.createRealMatrix(data);
       
       // Original behavior: should process normally (element not considered small)
       // Mutated behavior: would treat this as small and potentially throw exception or change rank
       RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
       
       // Verify the rank is correct (should be 3 since all diagonal elements >= small)
       assertEquals(3, decomposition.getRank());
       
       // Verify we get a proper root matrix
       RealMatrix root = decomposition.getRootMatrix();
       assertNotNull(root);
       assertEquals(3, root.getRowDimension());
       assertEquals(3, root.getColumnDimension());
       
       // Verify the root matrix multiplied by its transpose gives original matrix
       RealMatrix reconstructed = root.multiply(root.transpose());
       for (int i = 0; i < 3; i++) {
           for (int j = 0; j < 3; j++) {
               assertEquals(data[i][j], reconstructed.getEntry(i, j), 1e-14);
           }
       }
   }

 @Test(timeout = 1000) // Add timeout to catch infinite loops
  public void testLoopTerminationWhenDiagonalElementsSmall() {
      // Create a matrix where some diagonal elements are below threshold
      double[][] data = {
          {1.0, 0.0, 0.0},
          {0.0, 0.000001, 0.0},  // Will be considered zero with small threshold
          {0.0, 0.0, 0.000001}   // Will be considered zero with small threshold
      };
      RealMatrix matrix = MatrixUtils.createRealMatrix(data);
      double small = 0.001;
      
      // This should terminate normally with the original code
      // With the mutant (loop=true), it would run indefinitely
      RectangularCholeskyDecomposition decomposition = 
          new RectangularCholeskyDecomposition(matrix, small);
      
      // Verify the rank is calculated correctly (only first row is above threshold)
      assertEquals(1, decomposition.getRank());
      
      // Verify root matrix has correct dimensions (order x rank)
      RealMatrix root = decomposition.getRootMatrix();
      assertEquals(3, root.getRowDimension());
      assertEquals(1, root.getColumnDimension());
  }

 @Test
 public void testCholeskyDecompositionDetectsSubtractionMutation() {
     // Create a positive definite matrix that will exercise the mutation point
     double[][] matrixData = {
         {4, 12, -16},
         {12, 37, -43},
         {-16, -43, 98}
     };
     RealMatrix matrix = MatrixUtils.createRealMatrix(matrixData);
     double small = 1.0e-10;
     
     // Perform the decomposition
     RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
     RealMatrix root = decomposition.getRootMatrix();
     
     // Verify specific values that would be affected by the mutation
     // The mutation would cause incorrect values in the root matrix
     assertEquals(2.0, root.getEntry(0, 0), 1.0e-15);
     assertEquals(6.0, root.getEntry(1, 0), 1.0e-15);
     assertEquals(-8.0, root.getEntry(2, 0), 1.0e-15);
     assertEquals(1.0, root.getEntry(1, 1), 1.0e-15);
     assertEquals(5.0, root.getEntry(2, 1), 1.0e-15);
     assertEquals(3.0, root.getEntry(2, 2), 1.0e-15);
     
     // Also verify the rank is correct
     assertEquals(3, decomposition.getRank());
 }

}
