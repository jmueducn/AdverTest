package gentest.org.apache.commons.math3.optimization.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.general.*;
import org.apache.commons.math3.analysis.DifferentiableMultivariateVectorFunction;
import org.apache.commons.math3.analysis.FunctionUtils;
import org.apache.commons.math3.analysis.differentiation.DerivativeStructure;
import org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableVectorFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.DiagonalMatrix;
import org.apache.commons.math3.linear.DecompositionSolver;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.QRDecomposition;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.optimization.OptimizationData;
import org.apache.commons.math3.optimization.InitialGuess;
import org.apache.commons.math3.optimization.Target;
import org.apache.commons.math3.optimization.Weight;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer;
import org.apache.commons.math3.optimization.PointVectorValuePair;
import org.apache.commons.math3.optimization.direct.BaseAbstractMultivariateVectorOptimizer;
import org.apache.commons.math3.util.FastMath;
 
public class AbstractLeastSquaresOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                         public void testSquareRoot_ZeroMatrix() throws Exception {
                                                                                                                                                                                             // Setup
                                                                                                                                                                                             DiagonalMatrix zeroMatrix = new DiagonalMatrix(new double[]{0.0, 0.0});
                                                                                                                                                                                             
                                                                                                                                                                                             // Create a concrete implementation of the abstract class
                                                                                                                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                 @Override
                                                                                                                                                                                                 protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                     return null; // Not needed for this test
                                                                                                                                                                                                 }
                                                                                                                                                                                             };
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to access the private squareRoot method
                                                                                                                                                                                             Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                             squareRootMethod.setAccessible(true);
                                                                                                                                                                                             
                                                                                                                                                                                             // Execute
                                                                                                                                                                                             RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, zeroMatrix);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify
                                                                                                                                                                                             assertTrue(result instanceof DiagonalMatrix);
                                                                                                                                                                                             assertEquals(0.0, result.getEntry(0, 0), 1e-15);
                                                                                                                                                                                             assertEquals(0.0, result.getEntry(1, 1), 1e-15);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                         public void testSquareRoot_NonDiagonalizableMatrix() throws Exception {
                                                                                                                                                                                             // Setup - a matrix that's not diagonalizable (defective)
                                                                                                                                                                                             org.apache.commons.math3.linear.RealMatrix defectiveMatrix = 
                                                                                                                                                                                                 new org.apache.commons.math3.linear.Array2DRowRealMatrix(new double[][]{{1, 1}, {0, 1}});
                                                                                                                                                                                             
                                                                                                                                                                                             // Create a concrete instance of the optimizer
                                                                                                                                                                                             org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                                                                                                 new org.apache.commons.math3.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to access private squareRoot method
                                                                                                                                                                                             java.lang.reflect.Method squareRootMethod = 
                                                                                                                                                                                                 org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                     .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                             squareRootMethod.setAccessible(true);
                                                                                                                                                                                             
                                                                                                                                                                                             // Execute - should still work as EigenDecomposition handles this case
                                                                                                                                                                                             org.apache.commons.math3.linear.RealMatrix result = 
                                                                                                                                                                                                 (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(optimizer, defectiveMatrix);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify by squaring the result
                                                                                                                                                                                             org.apache.commons.math3.linear.RealMatrix squared = result.multiply(result);
                                                                                                                                                                                             assertEquals(defectiveMatrix.getEntry(0, 0), squared.getEntry(0, 0), 1e-10);
                                                                                                                                                                                             assertEquals(defectiveMatrix.getEntry(0, 1), squared.getEntry(0, 1), 1e-10);
                                                                                                                                                                                             assertEquals(defectiveMatrix.getEntry(1, 0), squared.getEntry(1, 0), 1e-10);
                                                                                                                                                                                             assertEquals(defectiveMatrix.getEntry(1, 1), squared.getEntry(1, 1), 1e-10);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                     public void testSquareRoot_DiagonalMatrix() throws Exception {
                                                                                                                                                                                         // Setup
                                                                                                                                                                                         DiagonalMatrix diagonalMatrix = new DiagonalMatrix(new double[]{4.0, 9.0, 16.0});
                                                                                                                                                                                         
                                                                                                                                                                                         // Create a concrete optimizer subclass with all required methods
                                                                                                                                                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                             @Override
                                                                                                                                                                                             protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                                                 OptimizationData... optData) {
                                                                                                                                                                                                 return null; // dummy implementation
                                                                                                                                                                                             }
                                                                                                                                                                                             
                                                                                                                                                                                             @Override
                                                                                                                                                                                             protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                 return null; // dummy implementation
                                                                                                                                                                                             }
                                                                                                                                                                                         };
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to access private squareRoot method
                                                                                                                                                                                         Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                         squareRootMethod.setAccessible(true);
                                                                                                                                                                                         
                                                                                                                                                                                         // Execute
                                                                                                                                                                                         RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, diagonalMatrix);
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify
                                                                                                                                                                                         assertTrue(result instanceof DiagonalMatrix);
                                                                                                                                                                                         assertEquals(2.0, result.getEntry(0, 0), 1e-15);
                                                                                                                                                                                         assertEquals(3.0, result.getEntry(1, 1), 1e-15);
                                                                                                                                                                                         assertEquals(4.0, result.getEntry(2, 2), 1e-15);
                                                                                                                                                                                         assertEquals(0.0, result.getEntry(0, 1), 1e-15); // off-diagonal should be zero
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                     public void testSquareRoot_NonDiagonalMatrix() throws Exception {
                                                                                                                                                                                         // Setup - using a simple 2x2 matrix that we know the square root of
                                                                                                                                                                                         org.apache.commons.math3.linear.RealMatrix matrix = 
                                                                                                                                                                                             new org.apache.commons.math3.linear.Array2DRowRealMatrix(new double[][]{{5.0, 4.0}, {4.0, 5.0}});
                                                                                                                                                                                         
                                                                                                                                                                                         // Create an instance of a concrete subclass that implements required methods
                                                                                                                                                                                         org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                                                                                             new org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                 @Override
                                                                                                                                                                                                 protected PointVectorValuePair optimizeInternal(int maxEval, 
                                                                                                                                                                                                     org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableVectorFunction f,
                                                                                                                                                                                                     org.apache.commons.math3.optimization.OptimizationData... optData) {
                                                                                                                                                                                                     return null; // dummy implementation
                                                                                                                                                                                                 }
                                                                                                                                                                                                 
                                                                                                                                                                                                 @Override
                                                                                                                                                                                                 protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                     return null; // dummy implementation
                                                                                                                                                                                                 }
                                                                                                                                                                                             };
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to access private squareRoot method
                                                                                                                                                                                         java.lang.reflect.Method squareRootMethod = 
                                                                                                                                                                                             org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                 .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                         squareRootMethod.setAccessible(true);
                                                                                                                                                                                         
                                                                                                                                                                                         // Execute
                                                                                                                                                                                         org.apache.commons.math3.linear.RealMatrix result = 
                                                                                                                                                                                             (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify by squaring the result and comparing to original
                                                                                                                                                                                         org.apache.commons.math3.linear.RealMatrix squared = result.multiply(result);
                                                                                                                                                                                         assertEquals(matrix.getEntry(0, 0), squared.getEntry(0, 0), 1e-10);
                                                                                                                                                                                         assertEquals(matrix.getEntry(0, 1), squared.getEntry(0, 1), 1e-10);
                                                                                                                                                                                         assertEquals(matrix.getEntry(1, 0), squared.getEntry(1, 0), 1e-10);
                                                                                                                                                                                         assertEquals(matrix.getEntry(1, 1), squared.getEntry(1, 1), 1e-10);
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                 public void testSquareRoot_NegativeDiagonalElement() throws Exception {
                                                                                                                                                                                     // Setup
                                                                                                                                                                                     org.apache.commons.math3.linear.DiagonalMatrix matrix = 
                                                                                                                                                                                         new org.apache.commons.math3.linear.DiagonalMatrix(new double[]{4.0, -1.0});
                                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                         @Override
                                                                                                                                                                                         protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                             return null; // dummy implementation
                                                                                                                                                                                         }
                                                                                                                                                                                     };
                                                                                                                                                                                     
                                                                                                                                                                                     // Get the private method via reflection
                                                                                                                                                                                     Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                                                                                                                                                         "squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                     squareRootMethod.setAccessible(true);
                                                                                                                                                                                     
                                                                                                                                                                                     // Expect exception
                                                                                                                                                                                     ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                     exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                     
                                                                                                                                                                                     // Execute
                                                                                                                                                                                     squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                 public void testSquareRoot_NullInput() throws Exception {
                                                                                                                                                                                     // Setup exception rule
                                                                                                                                                                                     ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                     
                                                                                                                                                                                     // Setup optimizer with dummy implementations
                                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                         @Override
                                                                                                                                                                                         protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f,
                                                                                                                                                                                                 OptimizationData... optData) {
                                                                                                                                                                                             return null; // dummy implementation
                                                                                                                                                                                         }
                                                                                                                                                                                         
                                                                                                                                                                                         @Override
                                                                                                                                                                                         protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                             return null; // dummy implementation
                                                                                                                                                                                         }
                                                                                                                                                                                     };
                                                                                                                                                                                     
                                                                                                                                                                                     // Get the private squareRoot method via reflection
                                                                                                                                                                                     Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                     squareRootMethod.setAccessible(true);
                                                                                                                                                                                     
                                                                                                                                                                                     // Expect exception
                                                                                                                                                                                     exception.expect(org.apache.commons.math3.exception.NullArgumentException.class);
                                                                                                                                                                                     exception.expectMessage("matrix");
                                                                                                                                                                                     
                                                                                                                                                                                     // Execute
                                                                                                                                                                                     squareRootMethod.invoke(optimizer, (RealMatrix) null);
                                                                                                                                                                                 }

    @Test
                                                                                                                                             public void testSquareRoot_NonSquareMatrix() throws Exception {
                                                                                                                                                 // Setup
                                                                                                                                                 org.apache.commons.math3.linear.RealMatrix nonSquareMatrix = 
                                                                                                                                                     new org.apache.commons.math3.linear.Array2DRowRealMatrix(new double[2][3]);
                                                                                                                                                 
                                                                                                                                                 // Create a concrete subclass of AbstractLeastSquaresOptimizer
                                                                                                                                                 org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                                                     new org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                         @Override
                                                                                                                                                         protected org.apache.commons.math3.optimization.PointVectorValuePair optimizeInternal(
                                                                                                                                                             int maxEval,
                                                                                                                                                             org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableVectorFunction f,
                                                                                                                                                             org.apache.commons.math3.optimization.OptimizationData... optData) {
                                                                                                                                                             return null;
                                                                                                                                                         }
                                                                                                                                                         
                                                                                                                                                         @Override
                                                                                                                                                         protected org.apache.commons.math3.optimization.PointVectorValuePair doOptimize() {
                                                                                                                                                             return null;
                                                                                                                                                         }
                                                                                                                                                     };
                                                                                                                                                 
                                                                                                                                                 // Get the private squareRoot method via reflection
                                                                                                                                                 java.lang.reflect.Method squareRootMethod = 
                                                                                                                                                     org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                                                                         .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                 squareRootMethod.setAccessible(true);
                                                                                                                                                 
                                                                                                                                                 // Expect exception
                                                                                                                                                 org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                 exception.expect(org.apache.commons.math3.linear.NonSquareMatrixException.class);
                                                                                                                                                 
                                                                                                                                                 // Execute
                                                                                                                                                 squareRootMethod.invoke(optimizer, nonSquareMatrix);
                                                                                                                                             }

    @Test
                                                                                                                                        public void testComputeResidualsDetectsMutatedTargetArray() throws Exception {
                                                                                                                                            // Setup
                                                                                                                                            AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                @Override
                                                                                                                                                protected PointVectorValuePair doOptimize() {
                                                                                                                                                    return null; // Required abstract method implementation
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                @Override
                                                                                                                                                public double[] getTarget() { // Changed to public to match parent class
                                                                                                                                                    return new double[]{1.0, 2.0, 3.0};
                                                                                                                                                }
                                                                                                                                            };
                                                                                                                                            
                                                                                                                                            // The mutated version will use new double[0] instead of calling getTarget()
                                                                                                                                            // So with this input, original would work but mutant would throw exception
                                                                                                                                            double[] objectiveValue = new double[]{0.5, 1.5, 2.5};
                                                                                                                                            
                                                                                                                                            // Use reflection to access protected method
                                                                                                                                            Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                                                                                                                "computeResiduals", double[].class);
                                                                                                                                            computeResiduals.setAccessible(true);
                                                                                                                                            
                                                                                                                                            try {
                                                                                                                                                computeResiduals.invoke(optimizer, objectiveValue);
                                                                                                                                                // If we get here, the test fails (mutant not detected)
                                                                                                                                                fail("Expected DimensionMismatchException not thrown");
                                                                                                                                            } catch (InvocationTargetException e) {
                                                                                                                                                // Check if the cause is DimensionMismatchException
                                                                                                                                                if (!(e.getCause() instanceof DimensionMismatchException)) {
                                                                                                                                                    fail("Expected DimensionMismatchException but got " + e.getCause().getClass());
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }

    @Test
                                                                                                                               public void testComputeResiduals_DifferentLengths_ShouldThrowException() {
                                                                                                                                   // Setup
                                                                                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                       @Override
                                                                                                                                       protected PointVectorValuePair doOptimize() {
                                                                                                                                           return null; // dummy implementation
                                                                                                                                       }
                                                                                                                                   };
                                                                                                                                   try {
                                                                                                                                       // Use reflection to set the target field since it's protected
                                                                                                                                       Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("target");
                                                                                                                                       targetField.setAccessible(true);
                                                                                                                                       targetField.set(optimizer, new double[]{1.0, 2.0, 3.0}); // length 3
                                                                                                                                       
                                                                                                                                       double[] objectiveValue = new double[]{1.0, 2.0}; // length 2
                                                                                                                                       
                                                                                                                                       // Use reflection to call protected computeResiduals method
                                                                                                                                       Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                                                                                                           "computeResiduals", double[].class);
                                                                                                                                       computeResiduals.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Execute - should throw exception
                                                                                                                                       computeResiduals.invoke(optimizer, objectiveValue);
                                                                                                                                       fail("Expected DimensionMismatchException");
                                                                                                                                   } catch (DimensionMismatchException e) {
                                                                                                                                       // Expected
                                                                                                                                   } catch (InvocationTargetException e) {
                                                                                                                                       if (e.getCause() instanceof DimensionMismatchException) {
                                                                                                                                           // Expected
                                                                                                                                       } else {
                                                                                                                                           fail("Unexpected exception: " + e.getCause().getClass().getSimpleName());
                                                                                                                                       }
                                                                                                                                   } catch (Exception e) {
                                                                                                                                       fail("Unexpected exception: " + e.getClass().getSimpleName());
                                                                                                                                   }
                                                                                                                               }

    @Test
                                                                                                                               public void testComputeResiduals_SameLengths_ShouldNotThrowException() {
                                                                                                                                   // Setup
                                                                                                                                   double[] target = new double[]{1.0, 2.0, 3.0}; // length 3
                                                                                                                                   double[] objectiveValue = new double[]{1.5, 2.5, 3.5}; // length 3
                                                                                                                                   double[] expectedResiduals = new double[]{-0.5, -0.5, -0.5};
                                                                                                                                   
                                                                                                                                   // Create optimizer subclass that implements required methods
                                                                                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                       @Override
                                                                                                                                       protected PointVectorValuePair doOptimize() {
                                                                                                                                           return null; // dummy implementation
                                                                                                                                       }
                                                                                                                                   };
                                                                                                                                   
                                                                                                                                   try {
                                                                                                                                       // Set target field via reflection
                                                                                                                                       Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("target");
                                                                                                                                       targetField.setAccessible(true);
                                                                                                                                       targetField.set(optimizer, target);
                                                                                                                                       
                                                                                                                                       // Get and invoke computeResiduals method via reflection
                                                                                                                                       Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                                                                                                           "computeResiduals", double[].class);
                                                                                                                                       computeResidualsMethod.setAccessible(true);
                                                                                                                                       double[] result = (double[]) computeResidualsMethod.invoke(optimizer, objectiveValue);
                                                                                                                                       
                                                                                                                                       // Verify
                                                                                                                                       assertArrayEquals(expectedResiduals, result, 0.0001);
                                                                                                                                   } catch (Exception e) {
                                                                                                                                       fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                                   }
                                                                                                                               }

    @Test
                                                                                                                      public void testComputeResiduals_shouldThrowWhenObjectiveValueShorter() throws Exception {
                                                                                                                          // Setup
                                                                                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                              @Override
                                                                                                                              public double[] getTarget() {
                                                                                                                                  return new double[]{1.0, 2.0, 3.0}; // length 3
                                                                                                                              }
                                                                                                                              
                                                                                                                              @Override
                                                                                                                              protected PointVectorValuePair doOptimize() {
                                                                                                                                  return null; // dummy implementation
                                                                                                                              }
                                                                                                                          };
                                                                                                                          
                                                                                                                          double[] shortObjective = new double[]{1.0, 2.0}; // length 2
                                                                                                                          
                                                                                                                          // Exception verification
                                                                                                                          thrown.expect(DimensionMismatchException.class);
                                                                                                                          thrown.expectMessage("2 != 3");
                                                                                                                          
                                                                                                                          // Use reflection to access protected method
                                                                                                                          Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                                                                                              "computeResiduals", double[].class);
                                                                                                                          computeResiduals.setAccessible(true);
                                                                                                                          
                                                                                                                          // Test
                                                                                                                          computeResiduals.invoke(optimizer, shortObjective);
                                                                                                                      }

    @Test
                                                                                                                      public void testComputeResiduals_shouldNotThrowWhenLengthsMatch() throws Exception {
                                                                                                                          // Create mock optimizer
                                                                                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                              @Override
                                                                                                                              public double[] getTarget() {
                                                                                                                                  return new double[]{1.0, 2.0, 3.0}; // Same length as objective
                                                                                                                              }
                                                                                                                              
                                                                                                                              @Override
                                                                                                                              public PointVectorValuePair doOptimize() {
                                                                                                                                  return null;
                                                                                                                              }
                                                                                                                      
                                                                                                                              // Other abstract methods need to be implemented
                                                                                                                              @Override
                                                                                                                              public int getJacobianEvaluations() { return 0; }
                                                                                                                              @Override
                                                                                                                              protected void updateJacobian() {}
                                                                                                                              @Override
                                                                                                                              protected RealMatrix computeWeightedJacobian(double[] params) { return null; }
                                                                                                                              @Override
                                                                                                                              protected void updateResidualsAndCost() {}
                                                                                                                              @Override
                                                                                                                              protected double computeCost(double[] residuals) { return 0; }
                                                                                                                          };
                                                                                                                          
                                                                                                                          double[] properObjective = new double[]{1.0, 2.0, 3.0}; // length 3
                                                                                                                          
                                                                                                                          // Use reflection to access protected method
                                                                                                                          Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                                                                                              "computeResiduals", double[].class);
                                                                                                                          computeResiduals.setAccessible(true);
                                                                                                                          
                                                                                                                          // No exception expected
                                                                                                                          computeResiduals.invoke(optimizer, properObjective);
                                                                                                                      }

    @Test
                                                                                                                  public void testComputeResiduals_shouldThrowWhenObjectiveValueLonger() throws Exception {
                                                                                                                      // Setup
                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                          @Override
                                                                                                                          public PointVectorValuePair doOptimize() {
                                                                                                                              return null;
                                                                                                                          }
                                                                                                                          
                                                                                                                          @Override
                                                                                                                          public double[] getTarget() {
                                                                                                                              return new double[]{1.0, 2.0, 3.0}; // length 3
                                                                                                                          }
                                                                                                                      };
                                                                                                                      
                                                                                                                      double[] longObjective = new double[]{1.0, 2.0, 3.0, 4.0}; // length 4
                                                                                                                      
                                                                                                                      // Use reflection to access protected method
                                                                                                                      Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                                                                                          "computeResiduals", double[].class);
                                                                                                                      computeResiduals.setAccessible(true);
                                                                                                                      
                                                                                                                      // Test and verify exception
                                                                                                                      try {
                                                                                                                          computeResiduals.invoke(optimizer, longObjective);
                                                                                                                          fail("Expected DimensionMismatchException");
                                                                                                                      } catch (InvocationTargetException e) {
                                                                                                                          Throwable cause = e.getCause();
                                                                                                                          assertTrue(cause instanceof DimensionMismatchException);
                                                                                                                          assertEquals("4 != 3", cause.getMessage());
                                                                                                                      }
                                                                                                                  }

    @Test
                                                                                                     public void testComputeResiduals_DimensionMismatch() throws Exception {
                                                                                                         // Create a concrete subclass that implements required methods
                                                                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                             @Override
                                                                                                             protected PointVectorValuePair doOptimize() {
                                                                                                                 return null;
                                                                                                             }
                                                                                                             
                                                                                                             @Override
                                                                                                             protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, OptimizationData... optData) {
                                                                                                                 return null;
                                                                                                             }
                                                                                                             
                                                                                                             @Override
                                                                                                             public double[] getTarget() {
                                                                                                                 return new double[]{1.0, 2.0}; // length 2
                                                                                                             }
                                                                                                             
                                                                                                             @Override
                                                                                                             protected RealMatrix computeWeightedJacobian(double[] params) {
                                                                                                                 return null;
                                                                                                             }
                                                                                                             
                                                                                                             @Override
                                                                                                             protected void updateResidualsAndCost() {
                                                                                                                 // empty implementation
                                                                                                             }
                                                                                                         };
                                                                                                         
                                                                                                         double[] objectiveValue = new double[]{1.0}; // length 1
                                                                                                         
                                                                                                         // Use reflection to access protected method
                                                                                                         Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                                                                             "computeResiduals", double[].class);
                                                                                                         computeResiduals.setAccessible(true);
                                                                                                         
                                                                                                         try {
                                                                                                             computeResiduals.invoke(optimizer, objectiveValue);
                                                                                                             fail("Expected DimensionMismatchException");
                                                                                                         } catch (InvocationTargetException e) {
                                                                                                             Throwable cause = e.getCause();
                                                                                                             assertTrue(cause instanceof DimensionMismatchException);
                                                                                                             DimensionMismatchException dme = (DimensionMismatchException) cause;
                                                                                                             assertEquals("Wrong dimension in error message (expected objectiveValue length)", 
                                                                                                                 1, dme.getDimension());
                                                                                                             assertEquals("Wrong dimension in error message (expected target length)", 
                                                                                                                 2, dme.getArgument());
                                                                                                             throw dme;
                                                                                                         }
                                                                                                     }

    @Test
                                                                public void testComputeResiduals_DetectsArraySizeMutation() {
                                                                    // Setup test data
                                                                    final double[] target = {1.0, 2.0, 3.0};
                                                                    final double[] objectiveValue = {0.5, 1.5, 2.5};
                                                                    final double[] expectedResiduals = {0.5, 0.5, 0.5};
                                                                    
                                                                    // Create a concrete subclass to access protected method
                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                        @Override
                                                                        public int getJacobianEvaluations() { return 0; }
                                                                        @Override
                                                                        public double getRMS() { return 0; }
                                                                        @Override
                                                                        public double getChiSquare() { return 0; }
                                                                        @Override
                                                                        public RealMatrix getWeightSquareRoot() { return null; }
                                                                        @Override
                                                                        public double[][] getCovariances() { return null; }
                                                                        @Override
                                                                        public double[][] getCovariances(double threshold) { return null; }
                                                                        @Override
                                                                        public double[] guessParametersErrors() { return null; }
                                                                        @Override
                                                                        protected PointVectorValuePair doOptimize() {
                                                                            return null;
                                                                        }
                                                                        
                                                                        // Override the computeResiduals method for testing
                                                                        @Override
                                                                        protected double[] computeResiduals(double[] objectiveValue) {
                                                                            // Calculate residuals as target - objectiveValue
                                                                            double[] residuals = new double[target.length];
                                                                            for (int i = 0; i < target.length; i++) {
                                                                                residuals[i] = target[i] - objectiveValue[i];
                                                                            }
                                                                            return residuals;
                                                                        }
                                                                    };
                                                                    
                                                                    // Use reflection to set the target field since it's likely protected
                                                                    try {
                                                                        Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("target");
                                                                        targetField.setAccessible(true);
                                                                        targetField.set(optimizer, target);
                                                                    } catch (NoSuchFieldException e) {
                                                                        fail("Target field not found in AbstractLeastSquaresOptimizer: " + e.getMessage());
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set target field via reflection: " + e.getMessage());
                                                                    }
                                                                    
                                                                    // Execute the computeResiduals method using reflection
                                                                    double[] actualResiduals;
                                                                    try {
                                                                        Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                                            "computeResiduals", double[].class);
                                                                        computeResidualsMethod.setAccessible(true);
                                                                        actualResiduals = (double[]) computeResidualsMethod.invoke(optimizer, objectiveValue);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to invoke computeResiduals method via reflection: " + e.getMessage());
                                                                        return;
                                                                    }
                                                                    
                                                                    // Verify
                                                                    assertEquals("Residuals array should have same length as target", 
                                                                               target.length, actualResiduals.length);
                                                                    assertArrayEquals("Residuals should be correctly calculated", 
                                                                                     expectedResiduals, actualResiduals, 0.0001);
                                                                }

    @Test
                                                           public void testComputeResiduals_DetectsArrayBoundaryMutant() throws Exception {
                                                               // Setup test data
                                                               final double[] target = {1.0, 2.0, 3.0};
                                                               final double[] objectiveValue = {0.5, 1.5, 2.5};
                                                               
                                                               // Create mock of the class under test
                                                               AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                               
                                                               // Stub the getTarget method to return our test target
                                                               when(optimizer.getTarget()).thenReturn(target);
                                                               
                                                               // Get the protected computeResiduals method via reflection
                                                               Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class
                                                                       .getDeclaredMethod("computeResiduals", double[].class);
                                                               computeResidualsMethod.setAccessible(true);
                                                               
                                                               // Call the method via reflection
                                                               double[] residuals = (double[]) computeResidualsMethod.invoke(optimizer, objectiveValue);
                                                               
                                                               // Verify correct length
                                                               assertEquals(target.length, residuals.length);
                                                               
                                                               // Verify correct calculations
                                                               assertEquals(0.5, residuals[0], 0.0001);
                                                               assertEquals(0.5, residuals[1], 0.0001);
                                                               assertEquals(0.5, residuals[2], 0.0001);
                                                               
                                                               // The test will implicitly fail if ArrayIndexOutOfBoundsException is thrown
                                                               // which would happen with the mutated version
                                                           }

    @Test
                                                  public void testComputeResidualsDetectsFirstElementMutation() {
                                                      // Setup test data with non-zero first elements
                                                      final double[] target = {5.0, 3.0, 2.0};  // First element is non-zero
                                                      final double[] objectiveValue = {2.0, 1.0, 1.0};  // First element is non-zero
                                                      
                                                      // Create test subclass that exposes the protected method
                                                      class TestOptimizer extends AbstractLeastSquaresOptimizer {
                                                          public TestOptimizer() {
                                                              super(null);
                                                          }
                                                          
                                                          @Override
                                                          public double[] computeResiduals(double[] objectiveValue) {
                                                              return super.computeResiduals(objectiveValue);
                                                          }
                                                          
                                                          @Override
                                                          public double[] getTarget() {
                                                              return target;
                                                          }
                                                          
                                                          @Override
                                                          protected PointVectorValuePair doOptimize() {
                                                              // Dummy implementation since we're only testing computeResiduals
                                                              return null;
                                                          }
                                                      }
                                                      
                                                      // Create instance of our test optimizer
                                                      TestOptimizer optimizer = new TestOptimizer();
                                                      
                                                      // Execute
                                                      double[] residuals = optimizer.computeResiduals(objectiveValue);
                                                      
                                                      // Verify the first element was properly computed
                                                      assertEquals(3.0, residuals[0], 0.0001);  // 5.0 - 2.0 = 3.0
                                                      assertEquals(2.0, residuals[1], 0.0001);  // 3.0 - 1.0 = 2.0
                                                      assertEquals(1.0, residuals[2], 0.0001);  // 2.0 - 1.0 = 1.0
                                                      
                                                      // Verify array length
                                                      assertEquals(3, residuals.length);
                                                  }

    @Test
                                         public void testComputeResidualsCorrectCalculation() throws Exception {
                                             // Create optimizer instance with proper implementation of abstract methods
                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                 @Override
                                                 protected PointVectorValuePair doOptimize() {
                                                     return null; // Simple implementation just to satisfy the abstract method
                                                 }
                                             };
                                             
                                             // Set up target values using reflection (since getTarget() is used in computeResiduals)
                                             double[] target = new double[]{5.0, 1.0, 0.0, 2.5}; // These values make expectedResiduals correct
                                             Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("target");
                                             targetField.setAccessible(true);
                                             targetField.set(optimizer, target);
                                             
                                             // Test with values that will clearly show the difference between + and -
                                             double[] objectiveValue = new double[]{2.0, -1.0, 0.0, 2.5};
                                             double[] expectedResiduals = new double[]{3.0, -2.0, 0.0, 0.0};
                                             
                                             // Use reflection to call the protected computeResiduals method
                                             Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                 "computeResiduals", double[].class);
                                             computeResidualsMethod.setAccessible(true);
                                             double[] actualResiduals = (double[]) computeResidualsMethod.invoke(optimizer, objectiveValue);
                                             
                                             assertArrayEquals("Residuals should be target - objectiveValue", 
                                                              expectedResiduals, actualResiduals, 0.0001);
                                         }

    @Test(expected = DimensionMismatchException.class)
                                         public void testComputeResidualsDimensionMismatch() throws Exception {
                                             // Create a concrete subclass instance since AbstractLeastSquaresOptimizer is abstract
                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                 @Override
                                                 public double[] getTarget() {
                                                     return new double[]{1.0, 2.0, 3.0, 4.0}; // target length 4
                                                 }
                                                 
                                                 @Override
                                                 protected PointVectorValuePair doOptimize() {
                                                     return null; // dummy implementation
                                                 }
                                         
                                                 // Implement required abstract methods with dummy implementations
                                                 @Override
                                                 public int getJacobianEvaluations() { return 0; }
                                                 @Override
                                                 public double getRMS() { return 0; }
                                                 @Override
                                                 public double getChiSquare() { return 0; }
                                                 @Override
                                                 public RealMatrix getWeightSquareRoot() { return null; }
                                             };
                                             
                                             // Test with wrong array length
                                             double[] objectiveValue = new double[]{1.0, 2.0, 3.0}; // length 3 vs target length 4
                                             
                                             // Use reflection to access protected method
                                             Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                 "computeResiduals", double[].class);
                                             computeResiduals.setAccessible(true);
                                             computeResiduals.invoke(optimizer, objectiveValue);
                                         }

    @Test
                                         public void testComputeResidualsWithNegativeValues() {
                                             // Test with negative values to ensure proper sign handling
                                             double[] objectiveValue = new double[]{-2.0, 1.0, 0.0, -2.5};
                                             double[] expectedResiduals = new double[]{7.0, -4.0, 0.0, 5.0};
                                             
                                             // Create optimizer instance with proper initialization
                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                 // Implement abstract methods or provide dummy implementations
                                                 @Override
                                                 public int getJacobianEvaluations() { return 0; }
                                                 @Override
                                                 public double getRMS() { return 0; }
                                                 @Override
                                                 public double getChiSquare() { return 0; }
                                                 @Override
                                                 public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                    double[] target, double[] weights, double[] startPoint) {
                                                     return null;
                                                 }
                                                 @Override
                                                 protected PointVectorValuePair doOptimize() {
                                                     return null;
                                                 }
                                             };
                                             
                                             // Set target values using reflection
                                             try {
                                                 Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("target");
                                                 targetField.setAccessible(true);
                                                 targetField.set(optimizer, new double[]{5.0, -3.0, 0.0, 2.5});
                                                 
                                                 // Call computeResiduals using reflection since it's protected
                                                 Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                     "computeResiduals", double[].class);
                                                 computeResidualsMethod.setAccessible(true);
                                                 double[] actualResiduals = (double[]) computeResidualsMethod.invoke(optimizer, objectiveValue);
                                                 
                                                 assertArrayEquals("Residuals should correctly handle negative values", 
                                                                  expectedResiduals, actualResiduals, 0.0001);
                                             } catch (Exception e) {
                                                 fail("Failed to set target field or call computeResiduals: " + e.getMessage());
                                             }
                                         }

    @Test
                                         public void testComputeResidualsWithZeroValues() throws Exception {
                                             // Test with zero values to catch edge cases
                                             double[] objectiveValue = new double[]{0.0, 0.0, 0.0, 0.0};
                                             double[] expectedResiduals = new double[]{5.0, -3.0, 0.0, 2.5};
                                             
                                             // Create a concrete implementation or mock of the optimizer
                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                 @Override
                                                 public double[] getTarget() {
                                                     // Return target values that will produce the expected residuals
                                                     // Since residuals = target - objectiveValue, and objectiveValue is all zeros,
                                                     // target should equal expectedResiduals
                                                     return expectedResiduals.clone();
                                                 }
                                                 
                                                 @Override
                                                 protected PointVectorValuePair doOptimize() {
                                                     return null;
                                                 }
                                                 
                                                 // Implement other required abstract methods with empty implementations
                                                 @Override
                                                 public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                    double[] target, double[] weights, double[] startPoint) {
                                                     return null;
                                                 }
                                             };
                                             
                                             // Use reflection to access protected computeResiduals method
                                             Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                 "computeResiduals", double[].class);
                                             computeResidualsMethod.setAccessible(true);
                                             double[] actualResiduals = (double[]) computeResidualsMethod.invoke(optimizer, objectiveValue);
                                             
                                             assertArrayEquals("Residuals should correctly handle zero values", 
                                                              expectedResiduals, actualResiduals, 0.0001);
                                         }

    @Test
                                    public void testComputeResidualsDetectsSignMutation() throws Exception {
                                        // Create test instance - we'll use a concrete subclass since it's abstract
                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                            @Override
                                            protected PointVectorValuePair doOptimize() {
                                                return null; // dummy implementation
                                            }
                                            
                                            @Override
                                            public double[] getTarget() {
                                                return new double[]{1.0, 2.0, 3.0}; // sample target values
                                            }
                                        };
                                        
                                        // Test input with known differences
                                        double[] objectiveValues = new double[]{1.5, 2.5, 3.5};
                                        
                                        // Expected residuals: target - objective = [1.0-1.5, 2.0-2.5, 3.0-3.5] = [-0.5, -0.5, -0.5]
                                        double[] expectedResiduals = new double[]{-0.5, -0.5, -0.5};
                                        
                                        // Use reflection to access protected computeResiduals method
                                        Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                            "computeResiduals", double[].class);
                                        computeResidualsMethod.setAccessible(true);
                                        
                                        // Calculate actual residuals
                                        double[] actualResiduals = (double[]) computeResidualsMethod.invoke(optimizer, objectiveValues);
                                        
                                        // Verify array length
                                        assertEquals(expectedResiduals.length, actualResiduals.length);
                                        
                                        // Verify each residual value
                                        for (int i = 0; i < expectedResiduals.length; i++) {
                                            assertEquals("Residual at index " + i + " has incorrect sign", 
                                                        expectedResiduals[i], 
                                                        actualResiduals[i], 
                                                        1e-15);
                                        }
                                        
                                        // Additional test case with positive differences
                                        double[] objectiveValues2 = new double[]{0.5, 1.5, 2.5};
                                        double[] expectedResiduals2 = new double[]{0.5, 0.5, 0.5};
                                        double[] actualResiduals2 = (double[]) computeResidualsMethod.invoke(optimizer, objectiveValues2);
                                        
                                        for (int i = 0; i < expectedResiduals2.length; i++) {
                                            assertEquals("Residual at index " + i + " has incorrect sign", 
                                                        expectedResiduals2[i], 
                                                        actualResiduals2[i], 
                                                        1e-15);
                                        }
                                    }

    @Test
                               public void testComputeResidualsDetectsSubtractionMutant() throws Exception {
                                   // Create a test instance of the abstract class
                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                       @Override
                                       public double[] getTarget() {
                                           return new double[]{1.0, 2.0, 3.0};
                                       }
                               
                                       @Override
                                       protected PointVectorValuePair doOptimize() {
                                           return null; // dummy implementation
                                       }
                                   };
                                   
                                   // Set up test data where objective values are different from target
                                   double[] objectiveValues = new double[]{0.5, 1.5, 2.5};
                                   
                                   // Expected residuals should be target - objectiveValue
                                   double[] expectedResiduals = new double[]{0.5, 0.5, 0.5};
                                   
                                   // Use reflection to access protected method
                                   Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                       "computeResiduals", double[].class);
                                   computeResiduals.setAccessible(true);
                                   double[] actualResiduals = (double[]) computeResiduals.invoke(optimizer, objectiveValues);
                                   
                                   // Verify the results
                                   assertArrayEquals(expectedResiduals, actualResiduals, 0.0001);
                                   
                                   // Additional verification - check each element individually
                                   for (int i = 0; i < expectedResiduals.length; i++) {
                                       assertEquals("Residual at index " + i + " should be target - objectiveValue", 
                                           expectedResiduals[i], actualResiduals[i], 0.0001);
                                   }
                               }

    @Test
                      public void testComputeResiduals_ShouldReturnCorrectResiduals() {
                          // Setup test data
                          double[] targetValues = {10.0, 20.0, 30.0};
                          double[] objectiveValues = {8.0, 22.0, 28.0};
                          double[] expectedResiduals = {2.0, -2.0, 2.0};
                          
                          // Create a concrete subclass to access protected method
                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                              @Override
                              public int getJacobianEvaluations() { return 0; }
                              
                              @Override
                              public double getRMS() { return 0; }
                              
                              @Override
                              public double getChiSquare() { return 0; }
                              
                              @Override
                              public double[][] getCovariances() { return null; }
                              
                              @Override
                              public double[] getTarget() { return targetValues; }
                              
                              @Override
                              protected PointVectorValuePair doOptimize() {
                                  return null; // Dummy implementation for test
                              }
                          };
                          
                          // Execute
                          double[] actualResiduals;
                          try {
                              Method method = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                  "computeResiduals", double[].class);
                              method.setAccessible(true);
                              actualResiduals = (double[]) method.invoke(optimizer, objectiveValues);
                          } catch (Exception e) {
                              throw new RuntimeException("Failed to invoke computeResiduals", e);
                          }
                          
                          // Verify
                          assertNotNull("Returned residuals should not be null", actualResiduals);
                          assertEquals("Residuals array length should match target length", 
                                       targetValues.length, actualResiduals.length);
                          assertArrayEquals("Residuals should be calculated correctly", 
                                           expectedResiduals, actualResiduals, 0.0001);
                          
                          // Additional verification that would catch the mutant
                          assertNotEquals("Residuals array should not be empty", 
                                         0, actualResiduals.length);
                      }

    @Test
             public void testComputeResidualsDoesNotThrowNullPointerException() {
                 // Prepare test data
                 double[] objectiveValue = new double[]{0.5, 1.5, 2.5};
                 AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                     @Override
                     protected PointVectorValuePair doOptimize() {
                         return null;
                     }
             
                     @Override
                     public double[] getTarget() {
                         return new double[]{1.0, 2.0, 3.0}; // Mock target values
                     }
             
                     // Other required abstract methods (stubbed)
                     @Override
                     public int getJacobianEvaluations() { return 0; }
                     @Override
                     protected void updateJacobian() {}
                     @Override
                     protected RealMatrix computeWeightedJacobian(double[] params) { return null; }
                     @Override
                     protected void updateResidualsAndCost() {}
                 };
                 
                 try {
                     // Use reflection to access protected method
                     Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                         "computeResiduals", double[].class);
                     computeResiduals.setAccessible(true);
                     
                     double[] result = (double[]) computeResiduals.invoke(optimizer, objectiveValue);
                     assertNotNull("Residuals array should not be null", result);
                     assertEquals("Result length should match target length", 
                                 optimizer.getTarget().length, result.length);
                 } catch (NullPointerException e) {
                     fail("Method threw NullPointerException - mutant detected");
                 } catch (Exception e) {
                     fail("Unexpected exception: " + e.getMessage());
                 }
             }

    @Test
             public void testComputeResidualsWithInvalidLength() throws Exception {
                 // Create a subclass that implements required abstract methods
                 AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                     @Override
                     protected PointVectorValuePair doOptimize() {
                         return null;
                     }
                 };
                 
                 // Test with wrong array length
                 double[] objectiveValue = new double[]{0.5, 1.5};
                 
                 // Use reflection to access protected method
                 Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                     "computeResiduals", double[].class);
                 computeResiduals.setAccessible(true);
                 
                 try {
                     computeResiduals.invoke(optimizer, objectiveValue);
                     fail("Expected DimensionMismatchException");
                 } catch (InvocationTargetException e) {
                     assertTrue(e.getCause() instanceof DimensionMismatchException);
                 }
             }

    @Test
             public void testComputeResidualsCorrectCalculation1() throws Exception {
                 // Test correct calculation
                 double[] objectiveValue = new double[]{0.5, 1.5, 2.5};
                 double[] expected = new double[]{0.5, 0.5, 0.5};
                 
                 // Create optimizer instance and set up target values
                 AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                     @Override
                     public double[] getTarget() {
                         return new double[]{1.0, 2.0, 3.0};  // target values that will produce expected residuals
                     }
                     
                     @Override
                     public PointVectorValuePair doOptimize() {
                         return null;
                     }
             
                     // Implement other abstract methods as needed
                     @Override
                     public int getJacobianEvaluations() { return 0; }
                     @Override
                     protected void updateJacobian() {}
                     @Override
                     protected RealMatrix computeWeightedJacobian(double[] params) { return null; }
                     @Override
                     protected void updateResidualsAndCost() {}
                     @Override
                     protected double computeCost(double[] residuals) { return 0; }
                 };
                 
                 // Use reflection to access protected computeResiduals method
                 Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                     "computeResiduals", double[].class);
                 computeResiduals.setAccessible(true);
                 double[] result = (double[]) computeResiduals.invoke(optimizer, objectiveValue);
                 
                 assertArrayEquals("Residuals should be calculated correctly", 
                                  expected, result, 0.0001);
             }

    @Test
    public void testComputeResiduals_ShouldReturnCorrectDifferences() {
        // Setup test data
        double[] targetValues = {10.0, 20.0, 30.0};
        double[] objectiveValues = {8.0, 25.0, 30.0};
        double[] expectedResiduals = {2.0, -5.0, 0.0}; // target - objective
        
        // Create test subclass that exposes the protected method
        class TestOptimizer extends AbstractLeastSquaresOptimizer {
            public TestOptimizer() {
                super(null);
            }
            
            @Override
            public double[] computeResiduals(double[] objectiveValue) {
                return super.computeResiduals(objectiveValue);
            }
            
            @Override
            public double[] getTarget() {
                return targetValues;
            }
            
            @Override
            protected PointVectorValuePair doOptimize() {
                // Dummy implementation since we're only testing computeResiduals
                return new PointVectorValuePair(new double[0], new double[0]);
            }
        }
        
        // Create instance of our test subclass
        TestOptimizer optimizer = new TestOptimizer();
        
        // Execute
        double[] actualResiduals = optimizer.computeResiduals(objectiveValues);
        
        // Verify
        assertArrayEquals("Residuals should be target - objective values", 
                         expectedResiduals, actualResiduals, 0.0001);
        
        // Additional check to ensure we're not getting all zeros (which would pass if mutant was present)
        boolean allZeros = true;
        for (double residual : actualResiduals) {
            if (residual != 0.0) {
                allZeros = false;
                break;
            }
        }
        assertFalse("Residuals array should not be all zeros", allZeros);
    }


}
