package gentest.org.apache.commons.math3.genetics.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.genetics.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
 
public class ListPopulationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                          public void testIterator_RemoveOperation() {
                                                                                                                                              // Arrange
                                                                                                                                              List<Chromosome> chromosomes = new ArrayList<>();
                                                                                                                                              Chromosome c1 = mock(Chromosome.class);
                                                                                                                                              Chromosome c2 = mock(Chromosome.class);
                                                                                                                                              chromosomes.add(c1);
                                                                                                                                              chromosomes.add(c2);
                                                                                                                                              
                                                                                                                                              // Create concrete subclass for testing
                                                                                                                                              class ConcreteListPopulation extends ListPopulation {
                                                                                                                                                  ConcreteListPopulation(List<Chromosome> chromosomes, int populationLimit) {
                                                                                                                                                      super(chromosomes, populationLimit);
                                                                                                                                                  }
                                                                                                                                                  
                                                                                                                                                  @Override
                                                                                                                                                  public Population nextGeneration() {
                                                                                                                                                      // Simple implementation just for testing
                                                                                                                                                      return new ConcreteListPopulation(new ArrayList<Chromosome>(), this.getPopulationLimit());
                                                                                                                                                  }
                                                                                                                                              }
                                                                                                                                              
                                                                                                                                              ListPopulation population = new ConcreteListPopulation(chromosomes, 10);
                                                                                                                                              Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                              
                                                                                                                                              // Act & Assert
                                                                                                                                              assertTrue(iterator.hasNext());
                                                                                                                                              assertEquals(c1, iterator.next());
                                                                                                                                              iterator.remove();
                                                                                                                                              assertEquals(1, population.getPopulationSize());
                                                                                                                                              assertEquals(c2, population.getChromosomes().get(0));
                                                                                                                                          }

    @Test
                                                                                                                                      public void testIterator_EmptyPopulation() {
                                                                                                                                          // Arrange
                                                                                                                                          ListPopulation population = new ListPopulation(10) {
                                                                                                                                              // Anonymous subclass implementing all abstract methods
                                                                                                                                              @Override
                                                                                                                                              public List<Chromosome> getChromosomes() {
                                                                                                                                                  return new ArrayList<Chromosome>();
                                                                                                                                              }
                                                                                                                                              
                                                                                                                                              @Override
                                                                                                                                              public Population nextGeneration() {
                                                                                                                                                  return new ListPopulation(getPopulationLimit()) {
                                                                                                                                                      @Override
                                                                                                                                                      public List<Chromosome> getChromosomes() {
                                                                                                                                                          return new ArrayList<Chromosome>();
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      @Override
                                                                                                                                                      public Population nextGeneration() {
                                                                                                                                                          return null; // Not used in test
                                                                                                                                                      }
                                                                                                                                                  };
                                                                                                                                              }
                                                                                                                                              
                                                                                                                                              @Override
                                                                                                                                              public int getPopulationSize() {
                                                                                                                                                  return 0;
                                                                                                                                              }
                                                                                                                                              
                                                                                                                                              @Override
                                                                                                                                              public Chromosome getFittestChromosome() {
                                                                                                                                                  return null; // Not used in test
                                                                                                                                              }
                                                                                                                                          };
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertNotNull(iterator);
                                                                                                                                          assertFalse(iterator.hasNext());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testIterator_RemoveWithoutNextShouldFail() {
                                                                                                                                          // Arrange
                                                                                                                                          List<Chromosome> chromosomes = new ArrayList<>();
                                                                                                                                          chromosomes.add(mock(Chromosome.class));
                                                                                                                                          ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                                                              @Override
                                                                                                                                              public Population nextGeneration() {
                                                                                                                                                  return new ListPopulation(new ArrayList<Chromosome>(), getPopulationLimit()) {
                                                                                                                                                      @Override
                                                                                                                                                      public Population nextGeneration() {
                                                                                                                                                          return null;
                                                                                                                                                      }
                                                                                                                                                  };
                                                                                                                                              }
                                                                                                                                          };
                                                                                                                                          Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          thrown.expect(IllegalStateException.class);
                                                                                                                                          iterator.remove();
                                                                                                                                      }

    @Test
                                                                                                                                  public void testIterator_PopulatedPopulation() {
                                                                                                                                      // Arrange
                                                                                                                                      List<Chromosome> chromosomes = new ArrayList<>();
                                                                                                                                      chromosomes.add(mock(Chromosome.class));
                                                                                                                                      chromosomes.add(mock(Chromosome.class));
                                                                                                                                      
                                                                                                                                      // Create an anonymous subclass of ListPopulation with required method implementation
                                                                                                                                      ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                                                          @Override
                                                                                                                                          public Population nextGeneration() {
                                                                                                                                              // Dummy implementation for testing purposes
                                                                                                                                              return this;
                                                                                                                                          }
                                                                                                                                      };
                                                                                                                                      
                                                                                                                                      // Act
                                                                                                                                      Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                      
                                                                                                                                      // Assert
                                                                                                                                      assertNotNull(iterator);
                                                                                                                                      assertTrue(iterator.hasNext());
                                                                                                                                      assertEquals(chromosomes.get(0), iterator.next());
                                                                                                                                      assertTrue(iterator.hasNext());
                                                                                                                                      assertEquals(chromosomes.get(1), iterator.next());
                                                                                                                                      assertFalse(iterator.hasNext());
                                                                                                                                  }

    @Test
                                                                                                                              public void testIterator_ConcurrentModification() {
                                                                                                                                  // Arrange
                                                                                                                                  List<Chromosome> chromosomes = new ArrayList<>();
                                                                                                                                  chromosomes.add(mock(Chromosome.class));
                                                                                                                                  
                                                                                                                                  // Use concrete ListPopulation implementation
                                                                                                                                  ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                                                      @Override
                                                                                                                                      public Iterator<Chromosome> iterator() {
                                                                                                                                          return getChromosomeList().iterator();
                                                                                                                                      }
                                                                                                                                      @Override
                                                                                                                                      public Population nextGeneration() {
                                                                                                                                          return new ListPopulation(new ArrayList<Chromosome>(), getPopulationLimit()) {
                                                                                                                                              @Override
                                                                                                                                              public Iterator<Chromosome> iterator() {
                                                                                                                                                  return getChromosomeList().iterator();
                                                                                                                                              }
                                                                                                                                              @Override
                                                                                                                                              public Population nextGeneration() {
                                                                                                                                                  return null;
                                                                                                                                              }
                                                                                                                                          };
                                                                                                                                      }
                                                                                                                                  };
                                                                                                                                  
                                                                                                                                  Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                  
                                                                                                                                  // Modify the underlying list
                                                                                                                                  population.addChromosome(mock(Chromosome.class));
                                                                                                                                  
                                                                                                                                  // Assert
                                                                                                                                  try {
                                                                                                                                      iterator.hasNext();
                                                                                                                                      fail("Expected ConcurrentModificationException");
                                                                                                                                  } catch (java.util.ConcurrentModificationException e) {
                                                                                                                                      // Expected exception
                                                                                                                                  }
                                                                                                                              }

    @Test
                                                                                     public void testToStringUsesClassFieldNotLocalVariable() {
                                                                                         // Create a subclass that shadows the chromosomes field
                                                                                         class ShadowingListPopulation extends org.apache.commons.math3.genetics.ListPopulation {
                                                                                             private java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes; // shadowing field
                                                                                             
                                                                                             public ShadowingListPopulation(java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes, int limit) {
                                                                                                 super(chromosomes, limit);
                                                                                                 this.chromosomes = java.util.Arrays.asList(
                                                                                                     new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                         @Override
                                                                                                         public double fitness() { return 0; }
                                                                                                     }
                                                                                                 ); // different from super's chromosomes
                                                                                             }
                                                                                             
                                                                                             @Override
                                                                                             public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                                                 return null; // simple implementation to satisfy abstract method
                                                                                             }
                                                                                         }
                                                                                         
                                                                                         // Create test chromosomes using anonymous classes instead of Mockito
                                                                                         org.apache.commons.math3.genetics.Chromosome c1 = 
                                                                                             new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                 @Override
                                                                                                 public double fitness() { return 0; }
                                                                                             };
                                                                                         org.apache.commons.math3.genetics.Chromosome c2 = 
                                                                                             new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                 @Override
                                                                                                 public double fitness() { return 0; }
                                                                                             };
                                                                                         java.util.List<org.apache.commons.math3.genetics.Chromosome> originalChromosomes = java.util.Arrays.asList(c1, c2);
                                                                                         
                                                                                         // Create instance with shadowing
                                                                                         ShadowingListPopulation population = new ShadowingListPopulation(originalChromosomes, 10);
                                                                                         
                                                                                         // The toString() should use the super class's chromosomes, not the shadowed one
                                                                                         String expected = originalChromosomes.toString();
                                                                                         String actual = population.toString();
                                                                                         
                                                                                         assertEquals("toString() should use class field chromosomes, not any shadowed variable", 
                                                                                                    expected, actual);
                                                                                     }

    @Test
                                                                public void testToStringWithEmptyChromosomesList() {
                                                                    // Create empty list of chromosomes
                                                                    List<Chromosome> chromosomes = Collections.emptyList();
                                                                    
                                                                    // Create concrete subclass of ListPopulation for testing
                                                                    class TestPopulation extends ListPopulation {
                                                                        TestPopulation(List<Chromosome> chromosomes, int populationLimit) {
                                                                            super(chromosomes, populationLimit);
                                                                        }
                                                                        
                                                                        @Override
                                                                        public Population nextGeneration() {
                                                                            // Stub implementation for testing
                                                                            return new TestPopulation(Collections.emptyList(), getPopulationLimit());
                                                                        }
                                                                    }
                                                                    
                                                                    // Create ListPopulation with empty chromosomes using our concrete subclass
                                                                    ListPopulation population = new TestPopulation(chromosomes, 10);
                                                                    
                                                                    // Expected string representation of empty list
                                                                    String expected = chromosomes.toString();
                                                                    
                                                                    // Verify the toString() method returns the expected string
                                                                    assertEquals("toString() should return empty list string representation", 
                                                                                expected, population.toString());
                                                                }

    @Test
                                                                public void testToStringReturnsChromosomesStringRepresentation() {
                                                                    // Create mock chromosomes
                                                                    org.apache.commons.math3.genetics.Chromosome chromosome1 = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                                                    org.apache.commons.math3.genetics.Chromosome chromosome2 = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                                                    
                                                                    // Set up mock behavior for toString() of chromosomes
                                                                    when(chromosome1.toString()).thenReturn("Chromosome1");
                                                                    when(chromosome2.toString()).thenReturn("Chromosome2");
                                                                    
                                                                    // Create a list of chromosomes
                                                                    java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = java.util.Arrays.asList(chromosome1, chromosome2);
                                                                    
                                                                    // Create concrete ListPopulation implementation for testing
                                                                    org.apache.commons.math3.genetics.ListPopulation population = new org.apache.commons.math3.genetics.ListPopulation(chromosomes, 10) {
                                                                        @Override
                                                                        public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                            // Simple implementation just to satisfy the abstract method
                                                                            return new org.apache.commons.math3.genetics.ListPopulation(getPopulationLimit()) {
                                                                                @Override
                                                                                public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                                    return null;
                                                                                }
                                                                            };
                                                                        }
                                                                    };
                                                                    
                                                                    // Expected string representation (format may vary based on List.toString() implementation)
                                                                    String expected = chromosomes.toString();
                                                                    
                                                                    // Verify the toString() method returns the expected string
                                                                    assertEquals("toString() should return chromosomes list string representation", 
                                                                                expected, population.toString());
                                                                }

    @Test
                                                       public void testToStringReturnsChromosomesStringRepresentation1() {
                                                           // Create mock chromosomes
                                                           org.apache.commons.math3.genetics.Chromosome chromosome1 = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                                           org.apache.commons.math3.genetics.Chromosome chromosome2 = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                                           java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = java.util.Arrays.asList(chromosome1, chromosome2);
                                                           
                                                           // Set up mock behavior for toString of individual chromosomes
                                                           when(chromosome1.toString()).thenReturn("Chromosome1");
                                                           when(chromosome2.toString()).thenReturn("Chromosome2");
                                                           
                                                           // Create population with these chromosomes using anonymous subclass
                                                           int populationLimit = 10;
                                                           org.apache.commons.math3.genetics.ListPopulation population = 
                                                               new org.apache.commons.math3.genetics.ListPopulation(chromosomes, populationLimit) {
                                                                   @Override
                                                                   public Population nextGeneration() {
                                                                       return null; // Simple implementation for test
                                                                   }
                                                               };
                                                           
                                                           // Call toString and verify
                                                           String result = population.toString();
                                                           assertNotNull("toString() should not return null", result);
                                                           assertTrue("Result should contain chromosome representations", 
                                                                     result.contains("Chromosome1") && result.contains("Chromosome2"));
                                                       }

    @Test
                                              public void testToStringReturnsChromosomesStringRepresentation2() {
                                                  // Create mock chromosomes
                                                  Chromosome chromosome1 = mock(Chromosome.class);
                                                  Chromosome chromosome2 = mock(Chromosome.class);
                                                  
                                                  // Set up mock behavior
                                                  when(chromosome1.toString()).thenReturn("Chromosome1");
                                                  when(chromosome2.toString()).thenReturn("Chromosome2");
                                                  
                                                  // Create a list of chromosomes
                                                  List<Chromosome> chromosomes = new ArrayList<>();
                                                  chromosomes.add(chromosome1);
                                                  chromosomes.add(chromosome2);
                                                  
                                                  // Create concrete subclass of ListPopulation for testing
                                                  class TestPopulation extends ListPopulation {
                                                      public TestPopulation(List<Chromosome> chromosomes, int populationLimit) {
                                                          super(chromosomes, populationLimit);
                                                      }
                                                      
                                                      @Override
                                                      public Population nextGeneration() {
                                                          // Dummy implementation for testing purposes
                                                          return this;
                                                      }
                                                  }
                                                  
                                                  // Create population with the chromosomes
                                                  TestPopulation population = new TestPopulation(chromosomes, 10);
                                                  
                                                  // Get the expected string representation of chromosomes list
                                                  String expected = chromosomes.toString();
                                                  
                                                  // Verify the toString() returns chromosomes' string representation
                                                  assertEquals("toString() should return chromosomes list string representation", 
                                                              expected, 
                                                              population.toString());
                                                  
                                                  // Additional verification that it's not returning the population object's string
                                                  assertNotEquals("toString() should not return population object's string representation",
                                                                 population.getClass().getName() + "@" + Integer.toHexString(population.hashCode()),
                                                                 population.toString());
                                              }

    @Test
                 public void testToStringReturnsProperListRepresentation() {
                     // Create a concrete subclass of ListPopulation for testing
                     ListPopulation population = new ListPopulation(new ArrayList<Chromosome>(), 10) {
                         @Override
                         public Population nextGeneration() {
                             return null; // Simple implementation just to satisfy abstract method
                         }
                     };
                     
                     // Create mock chromosomes
                     Chromosome c1 = mock(Chromosome.class);
                     Chromosome c2 = mock(Chromosome.class);
                     
                     // Setup chromosome toString behavior
                     when(c1.toString()).thenReturn("Chromosome1");
                     when(c2.toString()).thenReturn("Chromosome2");
                     
                     // Create a list with the mock chromosomes
                     List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                     chromosomes.add(c1);
                     chromosomes.add(c2);
                     
                     // Set chromosomes to population
                     population.setChromosomes(chromosomes);
                     
                     // Call toString and verify format
                     String result = population.toString();
                     
                     // Should be in list format "[Chromosome1, Chromosome2]"
                     assertEquals("[Chromosome1, Chromosome2]", result);
                     
                     // Also verify it's not the array toString format (which would look like [Ljava.lang.Object;@hashcode)
                     assertFalse(result.matches("^\\[L.*@.*$"));
                 }

    @Test
    public void testIteratorReturnsStandardIteratorNotListIterator() {
        // Setup test data
        List<Chromosome> chromosomes = new ArrayList<Chromosome>();
        chromosomes.add(mock(Chromosome.class));
        chromosomes.add(mock(Chromosome.class));
        
        // Create concrete subclass of ListPopulation for testing
        class ConcreteListPopulation extends ListPopulation {
            public ConcreteListPopulation(List<Chromosome> chromosomes, int populationLimit) {
                super(chromosomes, populationLimit);
            }
            
            @Override
            public Population nextGeneration() {
                // Simple implementation just returning a new empty population
                return new ConcreteListPopulation(new ArrayList<Chromosome>(), getPopulationLimit());
            }
        }
        
        // Create population with test data
        ConcreteListPopulation population = new ConcreteListPopulation(chromosomes, 10);
        
        // Get iterator from population
        Iterator<Chromosome> iterator = population.iterator();
        
        // Verify it's not a ListIterator
        assertFalse("Iterator should not be a ListIterator", 
                   iterator instanceof java.util.ListIterator);
        
        // Verify standard iterator operations work
        assertTrue(iterator.hasNext());
        assertNotNull(iterator.next());
        
        // Verify ListIterator operations are not supported
        try {
            if (iterator instanceof java.util.ListIterator) {
                ((java.util.ListIterator<Chromosome>)iterator).previous();
                fail("Should have thrown UnsupportedOperationException");
            }
        } catch (UnsupportedOperationException e) {
            // Expected for standard Iterator
        }
    }


}
