package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                    public void testBinomialCoefficient_TypicalValues() {
                                        assertEquals(1, MathUtils.binomialCoefficient(5, 0));
                                        assertEquals(5, MathUtils.binomialCoefficient(5, 1));
                                        assertEquals(10, MathUtils.binomialCoefficient(5, 2));
                                        assertEquals(10, MathUtils.binomialCoefficient(5, 3));
                                        assertEquals(5, MathUtils.binomialCoefficient(5, 4));
                                        assertEquals(1, MathUtils.binomialCoefficient(5, 5));
                                    }

 @Test
                                    public void testBinomialCoefficient_Symmetry() {
                                        assertEquals(84, MathUtils.binomialCoefficient(9, 6));
                                        assertEquals(84, MathUtils.binomialCoefficient(9, 3));
                                        assertEquals(20058300, MathUtils.binomialCoefficient(28, 14));
                                    }

 @Test
                                    public void testBinomialCoefficient_EdgeCases() {
                                        assertEquals(1, MathUtils.binomialCoefficient(0, 0));
                                        assertEquals(1, MathUtils.binomialCoefficient(1, 0));
                                        assertEquals(1, MathUtils.binomialCoefficient(1, 1));
                                        assertEquals(1, MathUtils.binomialCoefficient(100, 0));
                                        assertEquals(100, MathUtils.binomialCoefficient(100, 1));
                                        assertEquals(100, MathUtils.binomialCoefficient(100, 99));
                                        assertEquals(1, MathUtils.binomialCoefficient(100, 100));
                                    }

 @Test
                                    public void testBinomialCoefficient_DifferentRanges() {
                                        // n <= 61
                                        assertEquals(15820024220L, MathUtils.binomialCoefficient(60, 30));
                                        
                                        // 61 < n <= 66
                                        assertEquals(118264581564861424L, MathUtils.binomialCoefficient(66, 33));
                                        
                                        // n > 66
                                        assertEquals(7219428434016265740L, MathUtils.binomialCoefficient(67, 33));
                                    }

 @Test
                                    public void testBinomialCoefficient_NLessThanK() {
                                        thrown.expect(IllegalArgumentException.class);
                                        thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
                                        MathUtils.binomialCoefficient(5, 6);
                                    }

 @Test
                                    public void testBinomialCoefficient_NegativeN() {
                                        thrown.expect(IllegalArgumentException.class);
                                        thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
                                        MathUtils.binomialCoefficient(-1, 0);
                                    }

 @Test
                                    public void testBinomialCoefficient_NegativeK() {
                                        thrown.expect(IllegalArgumentException.class);
                                        thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
                                        MathUtils.binomialCoefficient(5, -1);
                                    }

 @Test
                                    public void testBinomialCoefficient_LargeValues() {
                                        assertEquals(3535316142212174320L, MathUtils.binomialCoefficient(70, 35));
                                        assertEquals(161884603662657876L, MathUtils.binomialCoefficient(80, 5));
                                    }

 @Test
                                    public void testBinomialCoefficient_OverflowProtection() {
                                        // These values would overflow if not handled properly
                                        assertEquals(126410606437752L, MathUtils.binomialCoefficient(62, 31));
                                        assertEquals(244662670200L, MathUtils.binomialCoefficient(68, 34));
                                    }

 @Test
                                    public void testBinomialCoefficientDouble_EdgeCases() {
                                        // Test when n == k
                                        assertEquals(1.0, MathUtils.binomialCoefficientDouble(5, 5), 0.0);
                                        assertEquals(1.0, MathUtils.binomialCoefficientDouble(0, 0), 0.0);
                                        
                                        // Test when k == 0
                                        assertEquals(1.0, MathUtils.binomialCoefficientDouble(10, 0), 0.0);
                                        assertEquals(1.0, MathUtils.binomialCoefficientDouble(0, 0), 0.0);
                                        
                                        // Test when k == 1 or k == n-1
                                        assertEquals(5.0, MathUtils.binomialCoefficientDouble(5, 1), 0.0);
                                        assertEquals(5.0, MathUtils.binomialCoefficientDouble(5, 4), 0.0);
                                        assertEquals(100.0, MathUtils.binomialCoefficientDouble(100, 1), 0.0);
                                        assertEquals(100.0, MathUtils.binomialCoefficientDouble(100, 99), 0.0);
                                    }

 @Test
                                    public void testBinomialCoefficientDouble_SymmetricProperty() {
                                        // Test symmetric property (n choose k) == (n choose n-k)
                                        assertEquals(MathUtils.binomialCoefficientDouble(10, 3), 
                                                    MathUtils.binomialCoefficientDouble(10, 7), 0.0);
                                        assertEquals(MathUtils.binomialCoefficientDouble(20, 5), 
                                                    MathUtils.binomialCoefficientDouble(20, 15), 0.0);
                                        assertEquals(MathUtils.binomialCoefficientDouble(50, 10), 
                                                    MathUtils.binomialCoefficientDouble(50, 40), 0.0);
                                    }

 @Test
                                    public void testBinomialCoefficientDouble_SmallValues() {
                                        // Test small values (n < 67)
                                        assertEquals(10.0, MathUtils.binomialCoefficientDouble(5, 2), 0.0);
                                        assertEquals(35.0, MathUtils.binomialCoefficientDouble(7, 3), 0.0);
                                        assertEquals(210.0, MathUtils.binomialCoefficientDouble(10, 4), 0.0);
                                        assertEquals(252.0, MathUtils.binomialCoefficientDouble(10, 5), 0.0);
                                    }

 @Test
                                    public void testBinomialCoefficientDouble_LargeValues() {
                                        // Test large values (n >= 67)
                                        assertEquals(161700.0, MathUtils.binomialCoefficientDouble(100, 3), 0.0);
                                        assertEquals(3921225.0, MathUtils.binomialCoefficientDouble(50, 6), 0.0);
                                        assertEquals(190578024.0, MathUtils.binomialCoefficientDouble(100, 5), 0.0);
                                        
                                        // Test very large values with rounding
                                        assertEquals(1.4297029E8, MathUtils.binomialCoefficientDouble(100, 7), 1.0);
                                        assertEquals(2.5333847E8, MathUtils.binomialCoefficientDouble(100, 8), 1.0);
                                    }

 @Test
                                    public void testBinomialCoefficientDouble_BoundaryValues() {
                                        // Test boundary around n = 67
                                        assertEquals(2217471.0, MathUtils.binomialCoefficientDouble(66, 33), 0.0);
                                        assertEquals(4.5385834E18, MathUtils.binomialCoefficientDouble(67, 33), 1.0E12);
                                        
                                        // Test maximum values before potential overflow
                                        assertEquals(1.4297029E8, MathUtils.binomialCoefficientDouble(100, 7), 1.0);
                                        assertEquals(2.5333847E8, MathUtils.binomialCoefficientDouble(100, 8), 1.0);
                                    }

 @Test
                                    public void testBinomialCoefficientDouble_RoundingBehavior() {
                                        // Test that rounding is working correctly
                                        assertEquals(6.0, MathUtils.binomialCoefficientDouble(4, 2), 0.0);  // 6.0 exactly
                                        assertEquals(35.0, MathUtils.binomialCoefficientDouble(7, 3), 0.0); // 35.0 exactly
                                        
                                        // Test cases where rounding is needed
                                        double result = MathUtils.binomialCoefficientDouble(30, 15);
                                        assertEquals(1.5505736E8, result, 0.5); // Verify it's rounded to nearest integer
                                    }

 @Test
                                    public void testBinomialCoefficientLog_InvalidInput_NLessThanK() {
                                        thrown.expect(IllegalArgumentException.class);
                                        thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
                                        MathUtils.binomialCoefficientLog(5, 10);
                                    }

 @Test
                                    public void testBinomialCoefficientLog_InvalidInput_NegativeN() {
                                        thrown.expect(IllegalArgumentException.class);
                                        thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
                                        MathUtils.binomialCoefficientLog(-5, 2);
                                    }

 @Test
                                    public void testBinomialCoefficientLog_Consistency() {
                                        // Test that different methods produce consistent results near boundaries
                                        
                                        // Just below boundary for exact computation (n=66)
                                        double exact = MathUtils.binomialCoefficientLog(66, 33);
                                        double approx = Math.log(MathUtils.binomialCoefficientDouble(66, 33));
                                        assertEquals(exact, approx, 1e-10);
                                        
                                        // Just below boundary for double computation (n=1029)
                                        double doubleComp = MathUtils.binomialCoefficientLog(1029, 500);
                                        double logSum = 0;
                                        for (int i = 501; i <= 1029; i++) {
                                            logSum += Math.log(i);
                                        }
                                        for (int i = 2; i <= 529; i++) {
                                            logSum -= Math.log(i);
                                        }
                                        assertEquals(doubleComp, logSum, 1e-10);
                                    }

 @Test
                            public void testBinomialCoefficientDouble_InvalidInput_NegativeN() {
                                org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                exceptionRule.expect(IllegalArgumentException.class);
                                exceptionRule.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
                                MathUtils.binomialCoefficientDouble(-1, 0);
                            }

 @Test
                            public void testBinomialCoefficientDouble_InvalidInput_NLessThanK() {
                                try {
                                    MathUtils.binomialCoefficientDouble(5, 6);
                                    fail("Expected IllegalArgumentException");
                                } catch (IllegalArgumentException e) {
                                    assertEquals("must have n >= k for binomial coefficient (n,k)", e.getMessage());
                                }
                            }

 @Test
                            public void testBinomialCoefficientLog_BoundaryCases() {
                                final double DELTA = 1e-15; // Define delta for double comparisons
                                
                                // Case when k = 0
                                assertEquals(0.0, MathUtils.binomialCoefficientLog(10, 0), DELTA);
                                
                                // Case when k = n
                                assertEquals(0.0, MathUtils.binomialCoefficientLog(10, 10), DELTA);
                                
                                // Case when k = 1
                                assertEquals(Math.log(10), MathUtils.binomialCoefficientLog(10, 1), DELTA);
                                
                                // Case when k = n-1
                                assertEquals(Math.log(10), MathUtils.binomialCoefficientLog(10, 9), DELTA);
                            }

 @Test
                            public void testBinomialCoefficientLog_SmallN() {
                                // Define delta for floating point comparison
                                final double DELTA = 1e-15;
                                
                                // n < 67 - should use exact integer computation
                                double expected = Math.log(MathUtils.binomialCoefficient(10, 5));
                                assertEquals(expected, MathUtils.binomialCoefficientLog(10, 5), DELTA);
                                
                                expected = Math.log(MathUtils.binomialCoefficient(66, 33));
                                assertEquals(expected, MathUtils.binomialCoefficientLog(66, 33), DELTA);
                            }

 @Test
                            public void testBinomialCoefficientLog_MediumN() {
                                // Define delta for double comparison
                                final double DELTA = 1e-15;
                                
                                // 67 <= n < 1030 - should use binomialCoefficientDouble
                                double expected = Math.log(MathUtils.binomialCoefficientDouble(100, 50));
                                assertEquals(expected, MathUtils.binomialCoefficientLog(100, 50), DELTA);
                                
                                expected = Math.log(MathUtils.binomialCoefficientDouble(1029, 500));
                                assertEquals(expected, MathUtils.binomialCoefficientLog(1029, 500), DELTA);
                            }

 @Test
                            public void testBinomialCoefficientLog_LargeN() {
                                // Define delta for double comparisons
                                final double DELTA = 1e-15;
                                
                                // n >= 1030 - should use log sum approach
                                // Test with known values
                                double expected = 0.0; // log(1) = 0 for (1030,0) or (1030,1030)
                                assertEquals(expected, MathUtils.binomialCoefficientLog(1030, 0), DELTA);
                                assertEquals(expected, MathUtils.binomialCoefficientLog(1030, 1030), DELTA);
                                
                                // Test with k=1 and k=n-1
                                expected = Math.log(1030);
                                assertEquals(expected, MathUtils.binomialCoefficientLog(1030, 1), DELTA);
                                assertEquals(expected, MathUtils.binomialCoefficientLog(1030, 1029), DELTA);
                                
                                // Test general case - verify logarithmic properties
                                double logCnk = MathUtils.binomialCoefficientLog(2000, 1000);
                                double logCnMinusK = MathUtils.binomialCoefficientLog(2000, 1000);
                                assertEquals(logCnk, logCnMinusK, DELTA);
                                
                                // Verify that log(n choose k) = log(n choose (n-k))
                                logCnk = MathUtils.binomialCoefficientLog(1500, 200);
                                logCnMinusK = MathUtils.binomialCoefficientLog(1500, 1300);
                                assertEquals(logCnk, logCnMinusK, DELTA);
                            }

 @Test(expected = IllegalArgumentException.class)
                            public void testBinomialCoefficientLogWithZeroN() {
                                // This test should pass with original code but fail with mutated code
                                // n=0 is valid input for original but invalid for mutant
                                MathUtils.binomialCoefficientLog(0, 0);
                            }

 @Test
                            public void testBinomialCoefficientLogWithPositiveN() {
                                // Verify normal case works (n=1)
                                double result = MathUtils.binomialCoefficientLog(1, 0);
                                assertEquals(0.0, result, 0.0001);
                            }

 @Test(expected = IllegalArgumentException.class)
                            public void testBinomialCoefficientLogWithNegativeN() {
                                // Verify negative n throws exception (both original and mutant)
                                MathUtils.binomialCoefficientLog(-1, 0);
                            }

 @Test
                           public void testBinomialCoefficientLog_WhenNEqualsK_ShouldReturnZero() {
                               // Test case where n=k but k≠0
                               // Original would return 0, mutant would not
                               double result = MathUtils.binomialCoefficientLog(5, 5);
                               assertEquals(0.0, result, 0.0001);
                           }

 @Test
                           public void testBinomialCoefficientLog_WhenKEqualsZero_ShouldReturnZero() {
                               // Test case where k=0 but n≠k
                               // Original would return 0, mutant would not
                               double result = MathUtils.binomialCoefficientLog(5, 0);
                               assertEquals(0.0, result, 0.0001);
                           }

 @Test
                           public void testBinomialCoefficientLog_WhenNEqualsKEqualsZero_ShouldReturnZero() {
                               // Test case where n=k=0
                               // Both original and mutant would return 0
                               double result = MathUtils.binomialCoefficientLog(0, 0);
                               assertEquals(0.0, result, 0.0001);
                           }

 @Test
                          public void testBinomialCoefficientLog_kEquals() {
                              int n = 5;
                              int k = 1;
                              double expected = Math.log(n);
                              double actual = MathUtils.binomialCoefficientLog(n, k);
                              assertEquals("Should return log(n) when k=1", expected, actual, 0.0001);
                          }

 @Test
                          public void testBinomialCoefficientLog_kEqualsNMinus() {
                              int n = 5;
                              int k = 4; // n-1
                              double expected = Math.log(n);
                              double actual = MathUtils.binomialCoefficientLog(n, k);
                              assertEquals("Should return log(n) when k=n-1", expected, actual, 0.0001);
                          }

 @Test
                          public void testBinomialCoefficientLog_kEquals1AndNMinus() {
                              int n = 2;
                              int k = 1; // both k=1 and k=n-1
                              double expected = Math.log(n);
                              double actual = MathUtils.binomialCoefficientLog(n, k);
                              assertEquals("Should return log(n) when k=1 and k=n-1", expected, actual, 0.0001);
                          }

 @Test
                    public void testBinomialCoefficientLogForN() {
                        // Test with n=67 which is the boundary case affected by the mutation
                        int n = 67;
                        int k = 30; // Arbitrary value between 1 and n-1
                        
                        // Calculate expected value using the double approximation path (original behavior)
                        double expectedLogValue = Math.log(MathUtils.binomialCoefficientDouble(n, k));
                        
                        // Calculate actual value
                        double actualLogValue = MathUtils.binomialCoefficientLog(n, k);
                        
                        // Verify the value matches the double approximation path (original behavior)
                        // Using delta for floating point comparison
                        assertEquals(expectedLogValue, actualLogValue, 1e-10);
                        
                        // Additional verification: ensure the exact computation path would give a different result
                        double exactLogValue = Math.log(MathUtils.binomialCoefficient(n, k));
                        assertNotEquals(exactLogValue, actualLogValue, 1e-10);
                    }

 @Test
               public void testBinomialCoefficientLogForN1() {
                   // Test with n=1030 which is the boundary case for the mutation
                   int n = 1030;
                   int k = 515; // Middle value to avoid special cases
                   
                   try {
                       // Calculate expected value using log sum approach (original behavior)
                       double logSum = 0;
                       for (int i = k + 1; i <= n; i++) {
                           logSum += Math.log((double)i);
                       }
                       for (int i = 2; i <= n - k; i++) {
                           logSum -= Math.log((double)i);
                       }
                       
                       // Call the method and verify it uses log sum approach (original behavior)
                       double result = MathUtils.binomialCoefficientLog(n, k);
                       
                       // Verify the result matches log sum approach (not the double computation)
                       assertEquals(logSum, result, 1e-10);
                       
                       // If the mutant is present, it would use binomialCoefficientDouble instead
                       // and the result would differ from logSum
                   } catch (Exception e) {
                       fail("Unexpected exception: " + e.getMessage());
                   }
               }

 @Test
               public void testBinomialCoefficientLogForLargeN() {
                   // Test case where n >= 1030 to exercise the log sum calculation
                   int n = 1030;
                   int k = 10;
                   
                   // Calculate expected value manually
                   double expected = 0.0;
                   
                   // Calculate n!/k! part
                   for (int i = k + 1; i <= n; i++) {
                       expected += Math.log((double)i);
                   }
                   
                   // Divide by (n-k)! part
                   for (int i = 2; i <= n - k; i++) {
                       expected -= Math.log((double)i);
                   }
                   
                   // Call the method and get actual result
                   double actual = MathUtils.binomialCoefficientLog(n, k);
                   
                   // Verify the result is correct within reasonable epsilon
                   assertEquals("Binomial coefficient log for large n is incorrect", 
                               expected, actual, 1e-10);
                   
                   // Additional test case with different values
                   n = 2000;
                   k = 5;
                   expected = 0.0;
                   
                   for (int i = k + 1; i <= n; i++) {
                       expected += Math.log((double)i);
                   }
                   for (int i = 2; i <= n - k; i++) {
                       expected -= Math.log((double)i);
                   }
                   
                   actual = MathUtils.binomialCoefficientLog(n, k);
                   assertEquals("Binomial coefficient log for large n is incorrect", 
                               expected, actual, 1e-10);
               }

 @Test
          public void testBinomialCoefficientLogLargeN() {
              // Test case designed to catch the i=k+1 -> i=k mutation
              int n = 1030;
              int k = 2;
              
              // Calculate expected value using original logic
              double expected = 0;
              for (int i = k + 1; i <= n; i++) {
                  expected += Math.log((double)i);
              }
              for (int i = 2; i <= n - k; i++) {
                  expected -= Math.log((double)i);
              }
              
              // Calculate actual value
              double actual = MathUtils.binomialCoefficientLog(n, k);
              
              // Verify result (using delta for floating point comparison)
              assertEquals(expected, actual, 1e-10);
              
              // Additional verification - compare with binomialCoefficientDouble for smaller case
              // This helps ensure our test logic is correct
              int smallerN = 100;
              int smallerK = 2;
              double expectedSmall = Math.log(MathUtils.binomialCoefficientDouble(smallerN, smallerK));
              double actualSmall = MathUtils.binomialCoefficientLog(smallerN, smallerK);
              assertEquals(expectedSmall, actualSmall, 1e-10);
          }

 @Test
         public void testBinomialCoefficientLogDetectsMutatedLoopCondition() {
             // Test case where n = k+2 to ensure the loop runs at least twice
             // and we can detect if the last term is missing
             int n = 1030; // Force use of log sum calculation
             int k = 1028; // n - k = 2
             
             // Expected value calculation:
             // log(C(n,k)) = log(n!/(k!(n-k)!)) = log(n) + log(n-1) - log(2)
             double expected = Math.log(n) + Math.log(n-1) - Math.log(2);
             
             // Actual value from method
             double actual = MathUtils.binomialCoefficientLog(n, k);
             
             // Verify the result matches expected value with some tolerance
             assertEquals(expected, actual, 1e-10);
             
             // Another test case where difference would be more pronounced
             n = 1030;
             k = 500; // n - k = 530
             
             // Original method would include log(1030) in the sum
             // Mutated method would exclude it
             // The difference should be exactly log(1030)
             double original = MathUtils.binomialCoefficientLog(n, k);
             double mutated = 0;
             
             // Simulate the mutated behavior
             for (int i = k + 1; i < n; i++) {
                 mutated += Math.log(i);
             }
             for (int i = 2; i <= n - k; i++) {
                 mutated -= Math.log(i);
             }
             
             // Verify original method gives different result than mutated version
             assertNotEquals(mutated, original, 1e-10);
             // Verify the difference is exactly log(n)
             assertEquals(Math.log(n), original - mutated, 1e-10);
         }

 @Test
        public void testBinomialCoefficientLog_LargeN1() {
            // Test with n >= 1030 to hit the log summation path
            int n = 1030;
            int k = 515; // middle value to ensure significant calculation
            
            // Calculate expected value using alternative approach
            double expected = 0;
            // Calculate numerator: log(n!/k!) = sum(log(i)) for i from k+1 to n
            for (int i = k + 1; i <= n; i++) {
                expected += Math.log(i);
            }
            // Calculate denominator: log((n-k)!) = sum(log(i)) for i from 2 to n-k
            for (int i = 2; i <= n - k; i++) {
                expected -= Math.log(i);
            }
            
            // Call the method and verify
            double actual = MathUtils.binomialCoefficientLog(n, k);
            
            // The mutant would produce -expected instead of expected
            assertEquals("Log of binomial coefficient incorrect for large n", 
                        expected, actual, 1e-10);
            
            // Additional verification that result is positive (since binomial coefficients are >=1)
            assertTrue("Log of binomial coefficient should be positive", actual > 0);
        }

 @Test
           public void testBinomialCoefficientLogLargeN1() {
               // Test with n >= 1030 to trigger the logarithmic sum path
               int n = 1030;
               int k = 515; // middle value for maximum difference
               
               // Calculate expected value using natural log
               double expected = 0;
               for (int i = k + 1; i <= n; i++) {
                   expected += Math.log((double)i);
               }
               for (int i = 2; i <= n - k; i++) {
                   expected -= Math.log((double)i);
               }
               
               // Call the method and get actual value
               double actual = MathUtils.binomialCoefficientLog(n, k);
               
               // Verify the result is correct (with some tolerance for floating point)
               assertEquals("Natural logarithm calculation is incorrect", 
                           expected, actual, 1e-10);
               
               // Additional verification - the mutant would produce log10 instead of ln
               // So the mutant's result would be expected / Math.log(10)
               double mutantExpected = expected / Math.log(10);
               assertNotEquals("Test should fail if log10 was used instead of ln",
                              mutantExpected, actual, 1e-10);
           }

 @Test
      public void testBinomialCoefficientLog_LargeN2() {
          // Test case where n >= 1030 to trigger the log-sum path
          // and n-k > 1 to ensure the subtraction loop executes
          int n = 1030;
          int k = 1028;  // n-k = 2
          
          // Calculate expected value manually
          double expected = 0.0;
          // n!/k! part
          for (int i = k + 1; i <= n; i++) {
              expected += Math.log((double)i);
          }
          // (n-k)! part (original correct version starts from 2)
          for (int i = 2; i <= n - k; i++) {
              expected -= Math.log((double)i);
          }
          
          // The mutant would include an extra iteration with i=1 (log(1)=0)
          // but we want to verify the exact correct computation
          double actual = MathUtils.binomialCoefficientLog(n, k);
          
          // Verify the result matches exactly
          assertEquals("Incorrect log binomial coefficient for large n", 
                      expected, actual, 0.0);
          
          // Additional verification with known value
          // C(1030,1028) = C(1030,2) = 1030*1029/2
          double expectedKnown = Math.log(1030 * 1029 / 2.0);
          assertEquals("Incorrect log binomial coefficient compared to known value",
                      expectedKnown, actual, 1e-14);
      }

 @Test
         public void testBinomialCoefficientLog_LargeN_CatchesMutant() {
             // Test case where n-k = 2 (loop should run twice, mutant would run once)
             int n = 1032;  // Large enough to go to the final calculation path
             int k = 1030;  // n-k = 2
             
             // Expected calculation:
             // logSum = log(1031) + log(1032) - log(2)
             double expected = Math.log(1031) + Math.log(1032) - Math.log(2);
             
             // Actual calculation (mutant would subtract only log(2) but miss subtracting log(2) again)
             double actual = MathUtils.binomialCoefficientLog(n, k);
             
             // Verify with delta to account for floating point precision
             assertEquals("Should correctly calculate log of binomial coefficient for n-k=2", 
                         expected, actual, 1e-10);
             
             // Another test case where n-k = 3 (loop should run 3 times, mutant would run twice)
             n = 1033;
             k = 1030;  // n-k = 3
             
             // Expected calculation:
             // logSum = log(1031) + log(1032) + log(1033) - log(2) - log(3)
             expected = Math.log(1031) + Math.log(1032) + Math.log(1033) 
                      - Math.log(2) - Math.log(3);
             
             actual = MathUtils.binomialCoefficientLog(n, k);
             
             assertEquals("Should correctly calculate log of binomial coefficient for n-k=3", 
                         expected, actual, 1e-10);
         }

 @Test
        public void testBinomialCoefficientLogForLargeN1() {
            // Test with n=1030 (boundary case) and k=10
            // This will trigger the log-sum calculation path
            int n = 1030;
            int k = 10;
            
            // Calculate expected value using exact formula for smaller numbers
            // We'll use n=20, k=10 to verify the calculation approach
            int testN = 20;
            int testK = 10;
            double exactValue = Math.log(MathUtils.binomialCoefficient(testN, testK));
            
            // Calculate what we expect for n=1030, k=10 using the same approach
            // The method should use: log(n!/(k!(n-k)!)) = [sum log(i) for i=k+1 to n] - [sum log(i) for i=2 to n-k]
            double expectedLogSum = 0.0;
            
            // Calculate numerator: log((k+1)*...*n) = log(k+1) + ... + log(n)
            for (int i = k + 1; i <= n; i++) {
                expectedLogSum += Math.log(i);
            }
            
            // Calculate denominator: log((n-k)!) = log(1) + log(2) + ... + log(n-k)
            for (int i = 2; i <= n - k; i++) {
                expectedLogSum -= Math.log(i);
            }
            
            // Now test the actual method
            double actual = MathUtils.binomialCoefficientLog(n, k);
            
            // The mutant would add instead of subtract in the denominator calculation,
            // resulting in a much larger (incorrect) value
            assertEquals("Log of binomial coefficient incorrect for large n", 
                        expectedLogSum, actual, 1e-10);
            
            // Additional check - the result should be less than the mutant's result
            // since mutant adds the denominator terms instead of subtracting
            assertTrue(actual < expectedLogSum + 2 * (n - k) * Math.log(n));
        }

 @Test
   public void testBinomialCoefficientLog_DetectsLogBaseMutation() {
       // Test with n >= 1030 to reach the mutated code path
       int n = 1030;
       int k = 515;  // Middle value to ensure non-trivial calculation
       
       // Calculate expected value using natural log
       double expectedLogSum = 0;
       
       // n!/k! part
       for (int i = k + 1; i <= n; i++) {
           expectedLogSum += Math.log((double)i);
       }
       
       // divide by (n-k)! part (where mutation occurs)
       for (int i = 2; i <= n - k; i++) {
           expectedLogSum -= Math.log((double)i);
       }
       
       // Calculate actual value
       double actual = MathUtils.binomialCoefficientLog(n, k);
       
       // Verify the result matches expected natural log calculation
       // Using delta of 1e-10 to account for floating point precision
       assertEquals(expectedLogSum, actual, 1e-10);
       
       // Additional verification that the result is not what would be produced by log10
       // Calculate what the mutant would produce
       double mutantLogSum = 0;
       for (int i = k + 1; i <= n; i++) {
           mutantLogSum += Math.log((double)i);
       }
       for (int i = 2; i <= n - k; i++) {
           mutantLogSum -= Math.log10((double)i);
       }
       // Verify actual result is not equal to mutant's result
       assertNotEquals(mutantLogSum, actual, 1e-10);
   }

 @Test
  public void testBinomialCoefficientLogDetectsMutant() {
      // Test with n >= 1030 to trigger the log summation path
      int n = 1030;
      int k = 10;  // Small enough k to make difference noticeable
      
      // Calculate expected value manually
      double expected = 0.0;
      
      // Original calculation: sum log(i) for i from k+1 to n
      for (int i = k + 1; i <= n; i++) {
          expected += Math.log((double)i);
      }
      
      // Subtract sum log(i) for i from 2 to n-k
      for (int i = 2; i <= n - k; i++) {
          expected -= Math.log((double)i);
      }
      
      // Mutated calculation would give:
      double mutated = 0.0;
      for (int i = k + 1; i <= n; i++) {
          mutated += Math.log((double)(i + 1));
      }
      for (int i = 2; i <= n - k; i++) {
          mutated -= Math.log((double)i);
      }
      
      // The difference should be exactly log((n+1)/(k+1))
      double expectedDifference = Math.log((n + 1.0)/(k + 1.0));
      
      // Actual result from method
      double actual = MathUtils.binomialCoefficientLog(n, k);
      
      // Verify against expected value with tolerance
      assertEquals("Binomial coefficient log incorrect for large n", 
                  expected, actual, 1e-10);
      
      // Also verify that the actual result is not equal to the mutated version
      assertNotEquals("Test should detect the mutant", 
                     mutated, actual, 1e-10);
      
      // Verify the difference matches expected
      assertEquals("Difference should match expected mutation effect",
                  expectedDifference, mutated - actual, 1e-10);
  }

 @Test
 public void testBinomialCoefficientLog_LargeValues_DetectsMutant() {
     // Test case designed to detect the mutant in the log sum calculation
     // We choose n=1030 and k=2 to ensure we hit the log sum path
     // and have a significant (n-k) value where the mutant would show
     
     // Expected calculation:
     // Original: log(C(1030,2)) = log(1030*1029/2) = log(1030) + log(1029) - log(2)
     // Mutated would subtract log(3) instead of log(2) in the division part
     
     double expected = Math.log(1030) + Math.log(1029) - Math.log(2);
     double actual = MathUtils.binomialCoefficientLog(1030, 2);
     
     // The mutant would produce: Math.log(1030) + Math.log(1029) - Math.log(3)
     // which is about 13.8439 vs expected 13.9444
     assertEquals("Mutant not detected in log sum calculation", 
                 expected, actual, 1e-10);
     
     // Additional test case with larger difference
     // n=1030, k=1 should use the special case (returns log(n))
     // This ensures we're not always getting the same value
     assertEquals(Math.log(1030), MathUtils.binomialCoefficientLog(1030, 1), 1e-10);
     
     // Test case where n-k is larger to amplify the mutant effect
     double expected2 = 0;
     // Calculate expected sum: log(21) + log(22) + ... + log(1030) - log(2) - ... - log(1010)
     for (int i = 21; i <= 1030; i++) {
         expected2 += Math.log(i);
     }
     for (int i = 2; i <= 1010; i++) {
         expected2 -= Math.log(i);
     }
     double actual2 = MathUtils.binomialCoefficientLog(1030, 20);
     assertEquals("Mutant not detected in larger n-k case",
                 expected2, actual2, 1e-10);
 }

}
