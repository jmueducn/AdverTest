package gentest.org.apache.commons.math.optimization.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.general.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MaxEvaluationsExceededException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction;
import org.apache.commons.math.analysis.MultivariateMatrixFunction;
import org.apache.commons.math.exception.LocalizedFormats;
import org.apache.commons.math.linear.InvalidMatrixException;
import org.apache.commons.math.linear.LUDecompositionImpl;
import org.apache.commons.math.linear.MatrixUtils;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.optimization.OptimizationException;
import org.apache.commons.math.optimization.SimpleVectorialValueChecker;
import org.apache.commons.math.optimization.VectorialConvergenceChecker;
import org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer;
import org.apache.commons.math.optimization.VectorialPointValuePair;
 
public class AbstractLeastSquaresOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                   public void testGetRMS_NormalCase() throws Exception {
                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Set private rows field using reflection
                                                                                                                                                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                                                                                                                                       rowsField.set(optimizer, 4);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock getChiSquare() to return 16.0
                                                                                                                                                                                                                                                       when(optimizer.getChiSquare()).thenReturn(16.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock getRMS() to use the actual implementation
                                                                                                                                                                                                                                                       when(optimizer.getRMS()).thenCallRealMethod();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Test and verify
                                                                                                                                                                                                                                                       assertEquals(2.0, optimizer.getRMS(), 1e-10);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testGetRMS_ZeroChiSquare() throws Exception {
                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to set private rows field
                                                                                                                                                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                                                                                                                                       rowsField.set(optimizer, 10);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock chi square return value
                                                                                                                                                                                                                                                       when(optimizer.getChiSquare()).thenReturn(0.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Test and verify
                                                                                                                                                                                                                                                       assertEquals(0.0, optimizer.getRMS(), 1e-10);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testGetRMS_PreciseCalculation() throws Exception {
                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Set private rows field using reflection
                                                                                                                                                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                                                                                                                                       rowsField.setInt(optimizer, 3);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock getChiSquare() to return 7.5
                                                                                                                                                                                                                                                       when(optimizer.getChiSquare()).thenReturn(7.5);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock getRMS() to use the actual calculation
                                                                                                                                                                                                                                                       when(optimizer.getRMS()).thenCallRealMethod();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Test and verify
                                                                                                                                                                                                                                                       assertEquals(Math.sqrt(2.5), optimizer.getRMS(), 1e-10);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testGetChiSquare_StandardCase() throws Exception {
                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                           @Override
                                                                                                                                                                                                                                                           protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                                               return null;
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       };
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                                                                                                                                       rowsField.set(optimizer, 3);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                                       residualsField.setAccessible(true);
                                                                                                                                                                                                                                                       residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                                       residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                                       residualsWeightsField.set(optimizer, new double[]{0.5, 1.0, 1.5});
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Expected: (1² * 0.5) + (2² * 1.0) + (3² * 1.5) = 0.5 + 4 + 13.5 = 18.0
                                                                                                                                                                                                                                                       double expected = 18.0;
                                                                                                                                                                                                                                                       double actual = optimizer.getChiSquare();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       assertEquals(expected, actual, 0.0001);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testGetChiSquare_ZeroResiduals() throws Exception {
                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                           @Override
                                                                                                                                                                                                                                                           protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                                               return null;
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       };
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                                                                                                                                       rowsField.set(optimizer, 3);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                                       residualsField.setAccessible(true);
                                                                                                                                                                                                                                                       residualsField.set(optimizer, new double[]{0.0, 0.0, 0.0});
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                                       residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                                       residualsWeightsField.set(optimizer, new double[]{0.5, 1.0, 1.5});
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Expected: all terms should be zero
                                                                                                                                                                                                                                                       double expected = 0.0;
                                                                                                                                                                                                                                                       double actual = optimizer.getChiSquare();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       assertEquals(expected, actual, 0.0001);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testGetChiSquare_NegativeWeights() {
                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                           @Override
                                                                                                                                                                                                                                                           protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                                               return null;
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       };
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to set private fields since they're not accessible directly
                                                                                                                                                                                                                                                       try {
                                                                                                                                                                                                                                                           Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                                           rowsField.setAccessible(true);
                                                                                                                                                                                                                                                           rowsField.set(optimizer, 2);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                                           residualsField.setAccessible(true);
                                                                                                                                                                                                                                                           residualsField.set(optimizer, new double[]{2.0, 3.0});
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                                           weightsField.setAccessible(true);
                                                                                                                                                                                                                                                           weightsField.set(optimizer, new double[]{-1.0, -2.0});
                                                                                                                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                                                                                                                           fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Expected: (2² * -1) + (3² * -2) = -4 + -18 = -22.0
                                                                                                                                                                                                                                                       double expected = -22.0;
                                                                                                                                                                                                                                                       double actual = optimizer.getChiSquare();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       assertEquals(expected, actual, 0.0001);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testGetChiSquare_SingleElement() throws Exception {
                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                           @Override
                                                                                                                                                                                                                                                           protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                                               return null;
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       };
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Set private fields using reflection
                                                                                                                                                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                                                                                                                                       rowsField.set(optimizer, 1);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                                       residualsField.setAccessible(true);
                                                                                                                                                                                                                                                       residualsField.set(optimizer, new double[]{5.0});
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                                       residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                                       residualsWeightsField.set(optimizer, new double[]{2.0});
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Expected: 5² * 2 = 50.0
                                                                                                                                                                                                                                                       double expected = 50.0;
                                                                                                                                                                                                                                                       double actual = optimizer.getChiSquare();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       assertEquals(expected, actual, 0.0001);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testGetChiSquare_ZeroWeights() throws Exception {
                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                           @Override
                                                                                                                                                                                                                                                           protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                                               return null;
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       };
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                                                                                                                                       rowsField.set(optimizer, 3);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                                       residualsField.setAccessible(true);
                                                                                                                                                                                                                                                       residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                                       weightsField.setAccessible(true);
                                                                                                                                                                                                                                                       weightsField.set(optimizer, new double[]{0.0, 0.0, 0.0});
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Expected: all terms should be zero regardless of residuals
                                                                                                                                                                                                                                                       double expected = 0.0;
                                                                                                                                                                                                                                                       double actual = optimizer.getChiSquare();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       assertEquals(expected, actual, 0.0001);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testGetChiSquare_MixedPositiveNegativeResiduals() throws Exception {
                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                           @Override
                                                                                                                                                                                                                                                           protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                                               return null;
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       };
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                                                                                                                                       rowsField.set(optimizer, 4);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                                       residualsField.setAccessible(true);
                                                                                                                                                                                                                                                       residualsField.set(optimizer, new double[]{-2.0, -1.0, 1.0, 2.0});
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                                       residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                                       residualsWeightsField.set(optimizer, new double[]{1.0, 1.0, 1.0, 1.0});
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Expected: (-2)² + (-1)² + 1² + 2² = 4 + 1 + 1 + 4 = 10.0
                                                                                                                                                                                                                                                       double expected = 10.0;
                                                                                                                                                                                                                                                       double actual = optimizer.getChiSquare();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       assertEquals(expected, actual, 0.0001);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testGetChiSquare_EmptyArrays() throws Exception {
                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                           @Override
                                                                                                                                                                                                                                                           protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                                               return null;
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       };
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                                                                                                                                       rowsField.set(optimizer, 0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                                       residualsField.setAccessible(true);
                                                                                                                                                                                                                                                       residualsField.set(optimizer, new double[0]);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                                       residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                                       residualsWeightsField.set(optimizer, new double[0]);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Expected: sum of zero elements should be zero
                                                                                                                                                                                                                                                       double expected = 0.0;
                                                                                                                                                                                                                                                       double actual = optimizer.getChiSquare();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       assertEquals(expected, actual, 0.0001);
                                                                                                                                                                                                                                                   }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                                                                                                                                                                                                                   public void testGetChiSquare_ArraysLengthMismatch() throws Exception {
                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                           @Override
                                                                                                                                                                                                                                                           protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                                               return null;
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       };
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                                                                                                                                       rowsField.set(optimizer, 2);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                                       residualsField.setAccessible(true);
                                                                                                                                                                                                                                                       residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0}); // 3 elements
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                                       residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                                       residualsWeightsField.set(optimizer, new double[]{1.0, 2.0}); // 2 elements
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // This should throw ArrayIndexOutOfBoundsException when i=2
                                                                                                                                                                                                                                                       optimizer.getChiSquare();
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                               public void testGetRMS_NegativeChiSquare() {
                                                                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                                                                   AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Setup expected exception
                                                                                                                                                                                                                                                   ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                   exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                   exception.expectMessage("Chi-square cannot be negative");
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Use reflection to set private field 'rows'
                                                                                                                                                                                                                                                   try {
                                                                                                                                                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                                                                                                                                       rowsField.set(optimizer, 5);
                                                                                                                                                                                                                                                   } catch (Exception e) {
                                                                                                                                                                                                                                                       fail("Failed to set rows field via reflection");
                                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Mock chi-square to return negative value
                                                                                                                                                                                                                                                   when(optimizer.getChiSquare()).thenReturn(-25.0);
                                                                                                                                                                                                                                                   when(optimizer.getRMS()).thenCallRealMethod();
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Test
                                                                                                                                                                                                                                                   optimizer.getRMS();
                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                           public void testGetRMS_ZeroRows() throws Exception {
                                                                                                                                                                                                               // Setup
                                                                                                                                                                                                               org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                                                                                                                   new org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                       protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                           return null;
                                                                                                                                                                                                                       }
                                                                                                                                                                                                                   };
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Use reflection to set private rows field
                                                                                                                                                                                                               try {
                                                                                                                                                                                                                   java.lang.reflect.Field rowsField = org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                   rowsField.setAccessible(true);
                                                                                                                                                                                                                   rowsField.set(optimizer, 0);
                                                                                                                                                                                                               } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
                                                                                                                                                                                                                   throw new RuntimeException(e);
                                                                                                                                                                                                               }
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Test and verify exception
                                                                                                                                                                                                               try {
                                                                                                                                                                                                                   optimizer.getRMS();
                                                                                                                                                                                                                   org.junit.Assert.fail("Expected ArithmeticException");
                                                                                                                                                                                                               } catch (ArithmeticException e) {
                                                                                                                                                                                                                   org.junit.Assert.assertEquals("/ by zero", e.getMessage());
                                                                                                                                                                                                               }
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                       public void testGetChiSquareWithPreIncrementMutation() {
                                                                                                                                                                                                           // Setup test data
                                                                                                                                                                                                           int testRows = 3;
                                                                                                                                                                                                           double[] testResiduals = {1.0, 2.0, 3.0};
                                                                                                                                                                                                           double[] testWeights = {0.5, 1.0, 1.5};
                                                                                                                                                                                                           double expectedChiSquare = 0;
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Calculate expected value
                                                                                                                                                                                                           for (int i = 0; i < testRows; i++) {
                                                                                                                                                                                                               expectedChiSquare += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                                                                                                                                           }
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Create test instance using reflection since constructor is protected
                                                                                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                               @Override
                                                                                                                                                                                                               protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                   return null; // Not needed for this test
                                                                                                                                                                                                               }
                                                                                                                                                                                                           };
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Set protected fields using reflection
                                                                                                                                                                                                           try {
                                                                                                                                                                                                               Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                               residualsField.setAccessible(true);
                                                                                                                                                                                                               residualsField.set(optimizer, testResiduals);
                                                                                                                                                                                                               
                                                                                                                                                                                                               Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                               weightsField.setAccessible(true);
                                                                                                                                                                                                               weightsField.set(optimizer, testWeights);
                                                                                                                                                                                                               
                                                                                                                                                                                                               Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                               rowsField.setAccessible(true);
                                                                                                                                                                                                               rowsField.set(optimizer, testRows);
                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                               fail("Failed to set up test fields via reflection: " + e.getMessage());
                                                                                                                                                                                                           }
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Test the method
                                                                                                                                                                                                           double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify the result
                                                                                                                                                                                                           assertEquals("Chi-square calculation incorrect", 
                                                                                                                                                                                                                       expectedChiSquare, actualChiSquare, 1e-10);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Additional verification for edge case with zero rows
                                                                                                                                                                                                           try {
                                                                                                                                                                                                               Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                               rowsField.setAccessible(true);
                                                                                                                                                                                                               rowsField.set(optimizer, 0);
                                                                                                                                                                                                               
                                                                                                                                                                                                               assertEquals("Chi-square should be 0 for 0 rows", 
                                                                                                                                                                                                                           0.0, optimizer.getChiSquare(), 1e-10);
                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                               fail("Failed to test edge case: " + e.getMessage());
                                                                                                                                                                                                           }
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                     public void testGetChiSquareDetectsCostMutation() throws Exception {
                                                                                                                                                                                                         // Setup test data
                                                                                                                                                                                                         double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                                                                                                         double[] weights = {1.0, 1.0, 1.0};
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create a concrete subclass for testing
                                                                                                                                                                                                         class TestOptimizer extends AbstractLeastSquaresOptimizer {
                                                                                                                                                                                                             @Override
                                                                                                                                                                                                             protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                 return null; // Not needed for this test
                                                                                                                                                                                                             }
                                                                                                                                                                                                         }
                                                                                                                                                                                                         
                                                                                                                                                                                                         TestOptimizer optimizer = spy(new TestOptimizer());
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Use reflection to set protected fields
                                                                                                                                                                                                         Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                         rowsField.setAccessible(true);
                                                                                                                                                                                                         rowsField.set(optimizer, residuals.length);
                                                                                                                                                                                                         
                                                                                                                                                                                                         Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                         residualsField.setAccessible(true);
                                                                                                                                                                                                         residualsField.set(optimizer, residuals);
                                                                                                                                                                                                         
                                                                                                                                                                                                         Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                         weightsField.setAccessible(true);
                                                                                                                                                                                                         weightsField.set(optimizer, weights);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Calculate expected chiSquare value (sum of squared residuals)
                                                                                                                                                                                                         double expectedChiSquare = 0;
                                                                                                                                                                                                         for (int i = 0; i < residuals.length; i++) {
                                                                                                                                                                                                             expectedChiSquare += residuals[i] * residuals[i] * weights[i];
                                                                                                                                                                                                         }
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Call the method under test
                                                                                                                                                                                                         double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify chiSquare calculation is correct
                                                                                                                                                                                                         assertEquals(expectedChiSquare, actualChiSquare, 1e-10);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Use reflection to call protected method
                                                                                                                                                                                                         Method updateMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("updateResidualsAndCost");
                                                                                                                                                                                                         updateMethod.setAccessible(true);
                                                                                                                                                                                                         updateMethod.invoke(optimizer);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Use reflection to get cost field
                                                                                                                                                                                                         Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                                                                                                                         costField.setAccessible(true);
                                                                                                                                                                                                         double cost = costField.getDouble(optimizer);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify cost is sqrt(chiSquare) - this will fail if mutant is present
                                                                                                                                                                                                         assertEquals(Math.sqrt(expectedChiSquare), cost, 1e-10);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Alternative verification that would catch the mutant:
                                                                                                                                                                                                         // The mutant would make cost = chiSquare^2, which would be much larger
                                                                                                                                                                                                         assertTrue("Cost should be less than chiSquare (sqrt vs square)", 
                                                                                                                                                                                                                   cost < actualChiSquare);
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                public void testGetChiSquareCostTransformation() throws Exception {
                                                                                                                                                                                                    // Create a test instance using reflection since constructor is protected
                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                        @Override
                                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                            return null;
                                                                                                                                                                                                        }
                                                                                                                                                                                                    };
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Use reflection to set protected fields
                                                                                                                                                                                                    Class<?> optimizerClass = optimizer.getClass();
                                                                                                                                                                                                    java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                    rowsField.set(optimizer, 2);
                                                                                                                                                                                                    
                                                                                                                                                                                                    java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                                                                                    residualsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                    
                                                                                                                                                                                                    java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                                                                                    residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                    residualsWeightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                    
                                                                                                                                                                                                    java.lang.reflect.Field costField = optimizerClass.getDeclaredField("cost");
                                                                                                                                                                                                    costField.setAccessible(true);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Test case 1: cost is negative (should become NaN with sqrt, positive with abs)
                                                                                                                                                                                                    costField.set(optimizer, -4.0);
                                                                                                                                                                                                    double result1 = optimizer.getChiSquare();
                                                                                                                                                                                                    double costAfterTest1 = (Double)costField.get(optimizer);
                                                                                                                                                                                                    assertFalse("Cost should be transformed differently by sqrt vs abs", 
                                                                                                                                                                                                               Double.isNaN(costAfterTest1) == (costAfterTest1 == 4.0));
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Test case 2: cost between 0 and 1 (sqrt increases it, abs leaves it same)
                                                                                                                                                                                                    costField.set(optimizer, 0.25);
                                                                                                                                                                                                    double result2 = optimizer.getChiSquare();
                                                                                                                                                                                                    double costAfterTest2 = (Double)costField.get(optimizer);
                                                                                                                                                                                                    assertNotEquals("Cost transformation should differ between sqrt and abs",
                                                                                                                                                                                                                   0.5, costAfterTest2, 0.0001);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Test case 3: cost greater than 1 (sqrt decreases it, abs leaves it same)
                                                                                                                                                                                                    costField.set(optimizer, 4.0);
                                                                                                                                                                                                    double result3 = optimizer.getChiSquare();
                                                                                                                                                                                                    double costAfterTest3 = (Double)costField.get(optimizer);
                                                                                                                                                                                                    assertNotEquals("Cost transformation should differ between sqrt and abs",
                                                                                                                                                                                                                   2.0, costAfterTest3, 0.0001);
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                           public void testGetChiSquare() throws Exception {
                                                                                                                                                                                               // Setup test data
                                                                                                                                                                                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                   @Override
                                                                                                                                                                                                   protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                       return null; // dummy implementation
                                                                                                                                                                                                   }
                                                                                                                                                                                               };
                                                                                                                                                                                               
                                                                                                                                                                                               // Use reflection to access protected fields
                                                                                                                                                                                               Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                                                                                                                                               java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                                                                               java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                                                                                               java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                                                                               
                                                                                                                                                                                               rowsField.setAccessible(true);
                                                                                                                                                                                               residualsField.setAccessible(true);
                                                                                                                                                                                               residualsWeightsField.setAccessible(true);
                                                                                                                                                                                               
                                                                                                                                                                                               // Set up test scenario with 3 rows
                                                                                                                                                                                               rowsField.setInt(optimizer, 3);
                                                                                                                                                                                               residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                                                                                               residualsWeightsField.set(optimizer, new double[]{0.5, 1.0, 1.5});
                                                                                                                                                                                               
                                                                                                                                                                                               // Calculate expected value manually
                                                                                                                                                                                               double expected = 0;
                                                                                                                                                                                               expected += 1.0 * 1.0 * 0.5; // 0.5
                                                                                                                                                                                               expected += 2.0 * 2.0 * 1.0; // 4.0
                                                                                                                                                                                               expected += 3.0 * 3.0 * 1.5; // 13.5
                                                                                                                                                                                               // Total expected = 0.5 + 4.0 + 13.5 = 18.0
                                                                                                                                                                                               
                                                                                                                                                                                               // Test the method
                                                                                                                                                                                               double actual = optimizer.getChiSquare();
                                                                                                                                                                                               
                                                                                                                                                                                               // Verify the result
                                                                                                                                                                                               assertEquals("Chi-square calculation is incorrect", 
                                                                                                                                                                                                           18.0, actual, 0.0001);
                                                                                                                                                                                               
                                                                                                                                                                                               // Additional edge case: empty residuals
                                                                                                                                                                                               rowsField.setInt(optimizer, 0);
                                                                                                                                                                                               residualsField.set(optimizer, new double[0]);
                                                                                                                                                                                               residualsWeightsField.set(optimizer, new double[0]);
                                                                                                                                                                                               assertEquals("Empty residuals should return 0", 
                                                                                                                                                                                                           0.0, optimizer.getChiSquare(), 0.0);
                                                                                                                                                                                               
                                                                                                                                                                                               // Additional test: verify all rows are processed
                                                                                                                                                                                               rowsField.setInt(optimizer, 2);
                                                                                                                                                                                               residualsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                               residualsWeightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                               assertEquals("Should process all rows", 
                                                                                                                                                                                                           2.0, optimizer.getChiSquare(), 0.0);
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                       public void testEvaluationBoundaryCondition() {
                                                                                                                                                                                           // Setup test data
                                                                                                                                                                                           double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                                                                                           double[] weights = {1.0, 1.0, 1.0};
                                                                                                                                                                                           
                                                                                                                                                                                           // Create partial mock of the optimizer
                                                                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                               @Override
                                                                                                                                                                                               protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                   return null; // Not needed for this test
                                                                                                                                                                                               }
                                                                                                                                                                                           };
                                                                                                                                                                                           
                                                                                                                                                                                           // Set test data through reflection since fields are protected
                                                                                                                                                                                           try {
                                                                                                                                                                                               Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                               residualsField.setAccessible(true);
                                                                                                                                                                                               residualsField.set(optimizer, residuals);
                                                                                                                                                                                               
                                                                                                                                                                                               Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                               weightsField.setAccessible(true);
                                                                                                                                                                                               weightsField.set(optimizer, weights);
                                                                                                                                                                                               
                                                                                                                                                                                               Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                               rowsField.setAccessible(true);
                                                                                                                                                                                               rowsField.set(optimizer, residuals.length);
                                                                                                                                                                                               
                                                                                                                                                                                               // Set max evaluations to exactly the number of residuals
                                                                                                                                                                                               optimizer.setMaxEvaluations(residuals.length);
                                                                                                                                                                                               
                                                                                                                                                                                               // Reset evaluation counter
                                                                                                                                                                                               Field evalField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objectiveEvaluations");
                                                                                                                                                                                               evalField.setAccessible(true);
                                                                                                                                                                                               evalField.set(optimizer, 0);
                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                               fail("Failed to setup test via reflection: " + e.getMessage());
                                                                                                                                                                                           }
                                                                                                                                                                                           
                                                                                                                                                                                           // Calculate chi-square - this should increment evaluations
                                                                                                                                                                                           double result = optimizer.getChiSquare();
                                                                                                                                                                                           
                                                                                                                                                                                           // Verify number of evaluations
                                                                                                                                                                                           assertEquals("Should allow exactly maxEvaluations evaluations", 
                                                                                                                                                                                                       residuals.length, 
                                                                                                                                                                                                       optimizer.getEvaluations());
                                                                                                                                                                                           
                                                                                                                                                                                           // Verify chi-square calculation
                                                                                                                                                                                           double expected = 0;
                                                                                                                                                                                           for (int i = 0; i < residuals.length; i++) {
                                                                                                                                                                                               expected += residuals[i] * residuals[i] * weights[i];
                                                                                                                                                                                           }
                                                                                                                                                                                           assertEquals(expected, result, 1e-10);
                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                     public void testGetChiSquareDetectsNullPointMutation() {
                                                                                                                                                                                         // Setup test data
                                                                                                                                                                                         int rows = 3;
                                                                                                                                                                                         double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                                                                                         double[] residualsWeights = {0.5, 0.5, 0.5};
                                                                                                                                                                                         
                                                                                                                                                                                         // Create partial mock of the optimizer
                                                                                                                                                                                         AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                                         
                                                                                                                                                                                         // Setup mock behavior for getChiSquare to call real method
                                                                                                                                                                                         when(optimizer.getChiSquare()).thenCallRealMethod();
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to set private fields needed for calculation
                                                                                                                                                                                         try {
                                                                                                                                                                                             Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                             residualsField.setAccessible(true);
                                                                                                                                                                                             residualsField.set(optimizer, residuals);
                                                                                                                                                                                             
                                                                                                                                                                                             Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                             residualsWeightsField.setAccessible(true);
                                                                                                                                                                                             residualsWeightsField.set(optimizer, residualsWeights);
                                                                                                                                                                                             
                                                                                                                                                                                             Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                             rowsField.setAccessible(true);
                                                                                                                                                                                             rowsField.set(optimizer, rows);
                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                             fail("Failed to set private fields via reflection: " + e.getMessage());
                                                                                                                                                                                         }
                                                                                                                                                                                         
                                                                                                                                                                                         // Call the method and verify result
                                                                                                                                                                                         double result = optimizer.getChiSquare();
                                                                                                                                                                                         double expected = 1.0*1.0*0.5 + 2.0*2.0*0.5 + 3.0*3.0*0.5;
                                                                                                                                                                                         assertEquals(expected, result, 1e-10);
                                                                                                                                                                                     }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                public void testGetChiSquareWhenObjectiveLengthNotEqualsRows() {
                                                                                                                                                                                    // Setup
                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                        @Override
                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                            return null;
                                                                                                                                                                                        }
                                                                                                                                                                                    };
                                                                                                                                                                                    
                                                                                                                                                                                    int rows = 3;
                                                                                                                                                                                    double[] objective = new double[4]; // length doesn't match rows
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to set private fields since we can't mock abstract class directly
                                                                                                                                                                                    try {
                                                                                                                                                                                        Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                        rowsField.setAccessible(true);
                                                                                                                                                                                        rowsField.set(optimizer, rows);
                                                                                                                                                                                        
                                                                                                                                                                                        Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                                                                                                        objectiveField.setAccessible(true);
                                                                                                                                                                                        objectiveField.set(optimizer, objective);
                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                        fail("Failed to set fields via reflection: " + e.getMessage());
                                                                                                                                                                                    }
                                                                                                                                                                                    
                                                                                                                                                                                    // Test - should throw exception
                                                                                                                                                                                    optimizer.getChiSquare();
                                                                                                                                                                                }

    @Test
                                                                                                                                                                            public void testGetChiSquareWhenObjectiveLengthEqualsRows() {
                                                                                                                                                                                // Setup
                                                                                                                                                                                int rows = 3;
                                                                                                                                                                                double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                                                                                double[] residualsWeights = {0.5, 0.5, 0.5};
                                                                                                                                                                                double[] objective = new double[rows]; // length matches rows
                                                                                                                                                                                
                                                                                                                                                                                // Create mock optimizer
                                                                                                                                                                                AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                                
                                                                                                                                                                                // Setup mock behavior using reflection to set private fields
                                                                                                                                                                                try {
                                                                                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                                                                    residualsField.set(optimizer, residuals);
                                                                                                                                                                                    
                                                                                                                                                                                    Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                    residualsWeightsField.setAccessible(true);
                                                                                                                                                                                    residualsWeightsField.set(optimizer, residualsWeights);
                                                                                                                                                                                    
                                                                                                                                                                                    Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                                                                                                    objectiveField.setAccessible(true);
                                                                                                                                                                                    objectiveField.set(optimizer, objective);
                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                    fail("Failed to set private fields via reflection: " + e.getMessage());
                                                                                                                                                                                }
                                                                                                                                                                                
                                                                                                                                                                                // Test - should pass in original, fail in mutant
                                                                                                                                                                                double result = optimizer.getChiSquare();
                                                                                                                                                                                
                                                                                                                                                                                // Verify calculation (0.5*1² + 0.5*2² + 0.5*3² = 0.5 + 2 + 4.5 = 7.0)
                                                                                                                                                                                assertEquals(7.0, result, 0.0001);
                                                                                                                                                                            }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                                                                                                                                       public void testGetChiSquare_shouldThrowWhenObjectiveShorterThanRows() throws Exception {
                                                                                                                                                                           // Arrange
                                                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                               @Override
                                                                                                                                                                               protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                   return null;
                                                                                                                                                                               }
                                                                                                                                                                           };
                                                                                                                                                                           
                                                                                                                                                                           // Set rows to 3 (longer than objective array)
                                                                                                                                                                           Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                           rowsField.setAccessible(true);
                                                                                                                                                                           rowsField.setInt(optimizer, 3);
                                                                                                                                                                           
                                                                                                                                                                           // Set objective array (length 2)
                                                                                                                                                                           double[] objective = new double[2];
                                                                                                                                                                           Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                                                                                           objectiveField.setAccessible(true);
                                                                                                                                                                           objectiveField.set(optimizer, objective);
                                                                                                                                                                           
                                                                                                                                                                           // Initialize other required fields
                                                                                                                                                                           Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                           residualsField.setAccessible(true);
                                                                                                                                                                           residualsField.set(optimizer, new double[3]);
                                                                                                                                                                           
                                                                                                                                                                           Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                           residualsWeightsField.setAccessible(true);
                                                                                                                                                                           residualsWeightsField.set(optimizer, new double[3]);
                                                                                                                                                                           
                                                                                                                                                                           // Act
                                                                                                                                                                           optimizer.getChiSquare();
                                                                                                                                                                           
                                                                                                                                                                           // Assert - exception expected
                                                                                                                                                                       }

    @Test
                                                                                                                                                                       public void testGetChiSquare_shouldCalculateCorrectValue() throws Exception {
                                                                                                                                                                           // Arrange
                                                                                                                                                                           // Create a concrete subclass instance since AbstractLeastSquaresOptimizer is abstract
                                                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                               protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                   return null;
                                                                                                                                                                               }
                                                                                                                                                                           };
                                                                                                                                                                           
                                                                                                                                                                           // Initialize required fields using reflection
                                                                                                                                                                           double[] residuals = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                           double[] residualsWeights = new double[]{0.5, 0.5, 0.5};
                                                                                                                                                                           int rows = 3;
                                                                                                                                                                           
                                                                                                                                                                           Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                           residualsField.setAccessible(true);
                                                                                                                                                                           residualsField.set(optimizer, residuals);
                                                                                                                                                                           
                                                                                                                                                                           Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                           weightsField.setAccessible(true);
                                                                                                                                                                           weightsField.set(optimizer, residualsWeights);
                                                                                                                                                                           
                                                                                                                                                                           Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                           rowsField.setAccessible(true);
                                                                                                                                                                           rowsField.set(optimizer, rows);
                                                                                                                                                                           
                                                                                                                                                                           // Act
                                                                                                                                                                           double result = optimizer.getChiSquare();
                                                                                                                                                                           
                                                                                                                                                                           // Assert
                                                                                                                                                                           double expected = 1.0*1.0*0.5 + 2.0*2.0*0.5 + 3.0*3.0*0.5;
                                                                                                                                                                           assertEquals(expected, result, 0.0001);
                                                                                                                                                                       }

    @Test
                                                                                                                                                          public void testGetChiSquareThrowsExceptionWithCorrectPointWhenDimensionsMismatch() throws Exception {
                                                                                                                                                              // Arrange - create dimension mismatch
                                                                                                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                  @Override
                                                                                                                                                                  protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                      return null;
                                                                                                                                                                  }
                                                                                                                                                              };
                                                                                                                                                              
                                                                                                                                                              // Set private fields using reflection
                                                                                                                                                              Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                              rowsField.setAccessible(true);
                                                                                                                                                              rowsField.set(optimizer, 3); // 3 rows
                                                                                                                                                              
                                                                                                                                                              Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                              residualsField.setAccessible(true);
                                                                                                                                                              residualsField.set(optimizer, new double[]{0.1, 0.2}); // but only 2 residuals
                                                                                                                                                              
                                                                                                                                                              Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                              residualsWeightsField.setAccessible(true);
                                                                                                                                                              residualsWeightsField.set(optimizer, new double[]{1.0, 1.0, 1.0}); // 3 weights
                                                                                                                                                              
                                                                                                                                                              Field pointField = AbstractLeastSquaresOptimizer.class.getDeclaredField("point");
                                                                                                                                                              pointField.setAccessible(true);
                                                                                                                                                              double[] testPoint = new double[]{1.0, 2.0, 3.0}; // example test point
                                                                                                                                                              pointField.set(optimizer, testPoint);
                                                                                                                                                              
                                                                                                                                                              try {
                                                                                                                                                                  // Act
                                                                                                                                                                  optimizer.getChiSquare();
                                                                                                                                                                  fail("Expected DimensionMismatchException");
                                                                                                                                                              } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
                                                                                                                                                                  // Assert
                                                                                                                                                                  assertEquals("3 != 2", e.getMessage());
                                                                                                                                                              }
                                                                                                                                                          }

    @Test
                                                                                                                                                     public void testGetChiSquare1() throws Exception {
                                                                                                                                                         // Create a test instance by extending the abstract class
                                                                                                                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                             @Override
                                                                                                                                                             protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                 return null; // Not needed for this test
                                                                                                                                                             }
                                                                                                                                                         };
                                                                                                                                                         
                                                                                                                                                         // Use reflection to access protected fields
                                                                                                                                                         Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                                                                                                         java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                                         java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                                                         java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                                         
                                                                                                                                                         rowsField.setAccessible(true);
                                                                                                                                                         residualsField.setAccessible(true);
                                                                                                                                                         residualsWeightsField.setAccessible(true);
                                                                                                                                                         
                                                                                                                                                         // Test case 1: Empty case (should return 0)
                                                                                                                                                         rowsField.setInt(optimizer, 0);
                                                                                                                                                         residualsField.set(optimizer, new double[0]);
                                                                                                                                                         residualsWeightsField.set(optimizer, new double[0]);
                                                                                                                                                         assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                         
                                                                                                                                                         // Test case 2: Single residual with weight 1 (should return residual^2)
                                                                                                                                                         rowsField.setInt(optimizer, 1);
                                                                                                                                                         residualsField.set(optimizer, new double[]{2.0});
                                                                                                                                                         residualsWeightsField.set(optimizer, new double[]{1.0});
                                                                                                                                                         assertEquals(4.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                         
                                                                                                                                                         // Test case 3: Multiple residuals with different weights
                                                                                                                                                         rowsField.setInt(optimizer, 3);
                                                                                                                                                         residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                                                         residualsWeightsField.set(optimizer, new double[]{0.5, 1.0, 1.5});
                                                                                                                                                         double expected = 1.0*1.0*0.5 + 2.0*2.0*1.0 + 3.0*3.0*1.5;
                                                                                                                                                         assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                     }

    @Test
                                                                                                                                                     public void testGetChiSquareDetectsInitializationMutant() {
                                                                                                                                                         // Create a test instance by mocking the abstract class
                                                                                                                                                         AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class, 
                                                                                                                                                             CALLS_REAL_METHODS);
                                                                                                                                                         
                                                                                                                                                         // Set up test data
                                                                                                                                                         int testRows = 3;
                                                                                                                                                         double[] testResiduals = {1.0, 2.0, 3.0};
                                                                                                                                                         double[] testWeights = {0.5, 1.0, 1.5};
                                                                                                                                                         
                                                                                                                                                         // Set protected fields using reflection
                                                                                                                                                         try {
                                                                                                                                                             java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                 .getDeclaredField("rows");
                                                                                                                                                             rowsField.setAccessible(true);
                                                                                                                                                             rowsField.set(optimizer, testRows);
                                                                                                                                                             
                                                                                                                                                             java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                 .getDeclaredField("residuals");
                                                                                                                                                             residualsField.setAccessible(true);
                                                                                                                                                             residualsField.set(optimizer, testResiduals);
                                                                                                                                                             
                                                                                                                                                             java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                 .getDeclaredField("residualsWeights");
                                                                                                                                                             weightsField.setAccessible(true);
                                                                                                                                                             weightsField.set(optimizer, testWeights);
                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                             fail("Failed to set up test fields via reflection");
                                                                                                                                                         }
                                                                                                                                                         
                                                                                                                                                         // Calculate expected value manually
                                                                                                                                                         double expected = 0.0; // Original starts from 0
                                                                                                                                                         for (int i = 0; i < testRows; i++) {
                                                                                                                                                             expected += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                                                                                         }
                                                                                                                                                         
                                                                                                                                                         // Test the method
                                                                                                                                                         double actual = optimizer.getChiSquare();
                                                                                                                                                         
                                                                                                                                                         // Assertion that will catch the mutant
                                                                                                                                                         assertEquals("Chi-square calculation should start from 0", 
                                                                                                                                                             expected, actual, 0.0001);
                                                                                                                                                         
                                                                                                                                                         // Additional assertion to specifically catch the -1 mutant
                                                                                                                                                         assertNotEquals("Should detect initialization mutant (-1)", 
                                                                                                                                                             expected - 1, actual, 0.0001);
                                                                                                                                                     }

    @Test
                                                                                                                                               public void testGetChiSquareDetectsSkippedFirstResidual() throws Exception {
                                                                                                                                                   // Setup test data where first residual makes significant contribution
                                                                                                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                       // Anonymous subclass to access protected members
                                                                                                                                                       @Override
                                                                                                                                                       protected VectorialPointValuePair doOptimize() {
                                                                                                                                                           return null; // Not needed for this test
                                                                                                                                                       }
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   // Use reflection to set protected fields
                                                                                                                                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                   rowsField.setAccessible(true);
                                                                                                                                                   rowsField.set(optimizer, 3);
                                                                                                                                                   
                                                                                                                                                   Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                   residualsField.setAccessible(true);
                                                                                                                                                   residualsField.set(optimizer, new double[]{10.0, 1.0, 1.0}); // First residual is large
                                                                                                                                                   
                                                                                                                                                   Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                   residualsWeightsField.setAccessible(true);
                                                                                                                                                   residualsWeightsField.set(optimizer, new double[]{1.0, 1.0, 1.0}); // Equal weights
                                                                                                                                                   
                                                                                                                                                   // Calculate expected value (including first residual)
                                                                                                                                                   double expectedChiSquare = 10.0 * 10.0 * 1.0  // First residual contribution
                                                                                                                                                                           + 1.0 * 1.0 * 1.0    // Second residual
                                                                                                                                                                           + 1.0 * 1.0 * 1.0;   // Third residual
                                                                                                                                                   
                                                                                                                                                   // Call method and assert
                                                                                                                                                   double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                                   assertEquals("Chi-square calculation should include first residual", 
                                                                                                                                                                expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                                                                   
                                                                                                                                                   // Additional check: verify the value is not what it would be if first residual was skipped
                                                                                                                                                   double mutatedExpected = 1.0 * 1.0 * 1.0 + 1.0 * 1.0 * 1.0; // Would be if i started at 1
                                                                                                                                                   assertNotEquals("Test should fail if first residual is skipped", 
                                                                                                                                                                  mutatedExpected, actualChiSquare, 0.0001);
                                                                                                                                               }

    @Test
                                                                                                                                          public void testGetChiSquareNormalCase() throws Exception {
                                                                                                                                              // Setup test data
                                                                                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                  @Override
                                                                                                                                                  protected VectorialPointValuePair doOptimize() {
                                                                                                                                                      return null;
                                                                                                                                                  }
                                                                                                                                              };
                                                                                                                                              
                                                                                                                                              // Set protected fields via reflection
                                                                                                                                              Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                              rowsField.setAccessible(true);
                                                                                                                                              rowsField.set(optimizer, 3);
                                                                                                                                              
                                                                                                                                              Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                              residualsField.setAccessible(true);
                                                                                                                                              residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                                              
                                                                                                                                              Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                              residualsWeightsField.setAccessible(true);
                                                                                                                                              residualsWeightsField.set(optimizer, new double[]{0.5, 1.0, 1.5});
                                                                                                                                              
                                                                                                                                              // Expected calculation: 1.0^2*0.5 + 2.0^2*1.0 + 3.0^2*1.5 = 0.5 + 4.0 + 13.5 = 18.0
                                                                                                                                              double expected = 18.0;
                                                                                                                                              double actual = optimizer.getChiSquare();
                                                                                                                                              
                                                                                                                                              assertEquals(expected, actual, 0.0001);
                                                                                                                                          }

    @Test
                                                                                                                                          public void testGetChiSquareEmptyArrays() throws Exception {
                                                                                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                  @Override
                                                                                                                                                  protected VectorialPointValuePair doOptimize() {
                                                                                                                                                      return null;
                                                                                                                                                  }
                                                                                                                                              };
                                                                                                                                              
                                                                                                                                              // Use reflection to set protected fields
                                                                                                                                              java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                              rowsField.setAccessible(true);
                                                                                                                                              rowsField.set(optimizer, 0);
                                                                                                                                              
                                                                                                                                              java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                              residualsField.setAccessible(true);
                                                                                                                                              residualsField.set(optimizer, new double[0]);
                                                                                                                                              
                                                                                                                                              java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                              weightsField.setAccessible(true);
                                                                                                                                              weightsField.set(optimizer, new double[0]);
                                                                                                                                              
                                                                                                                                              double expected = 0.0;
                                                                                                                                              double actual = optimizer.getChiSquare();
                                                                                                                                              
                                                                                                                                              assertEquals(expected, actual, 0.0001);
                                                                                                                                          }

    @Test
                                                                                                                                          public void testGetChiSquareDetectsMutant() {
                                                                                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                  @Override
                                                                                                                                                  protected VectorialPointValuePair doOptimize() {
                                                                                                                                                      return null;
                                                                                                                                                  }
                                                                                                                                                  
                                                                                                                                                  // This overrides the original method to simulate the mutant
                                                                                                                                                  @Override
                                                                                                                                                  public double getChiSquare() {
                                                                                                                                                      double chiSquare = 0;
                                                                                                                                                      for (int i = -1; i < rows; ++i) {  // Mutated version
                                                                                                                                                          final double residual = residuals[i];
                                                                                                                                                          chiSquare += residual * residual * residualsWeights[i];
                                                                                                                                                      }
                                                                                                                                                      return chiSquare;
                                                                                                                                                  }
                                                                                                                                              };
                                                                                                                                              
                                                                                                                                              // Use reflection to set protected fields
                                                                                                                                              try {
                                                                                                                                                  Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                  rowsField.setAccessible(true);
                                                                                                                                                  rowsField.set(optimizer, 1);
                                                                                                                                                  
                                                                                                                                                  Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                  residualsField.setAccessible(true);
                                                                                                                                                  residualsField.set(optimizer, new double[]{1.0});
                                                                                                                                                  
                                                                                                                                                  Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                  weightsField.setAccessible(true);
                                                                                                                                                  weightsField.set(optimizer, new double[]{1.0});
                                                                                                                                              } catch (Exception e) {
                                                                                                                                                  throw new RuntimeException("Failed to set test data via reflection", e);
                                                                                                                                              }
                                                                                                                                              
                                                                                                                                              // This should throw ArrayIndexOutOfBoundsException due to i=-1
                                                                                                                                              try {
                                                                                                                                                  optimizer.getChiSquare();
                                                                                                                                                  fail("Expected ArrayIndexOutOfBoundsException");
                                                                                                                                              } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                                  // Expected exception
                                                                                                                                              }
                                                                                                                                          }

    @Test
                                                                                                                                     public void testGetChiSquareShouldIncludeFirstElement() throws Exception {
                                                                                                                                         // Setup test data
                                                                                                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                             @Override
                                                                                                                                             protected VectorialPointValuePair doOptimize() {
                                                                                                                                                 return null; // dummy implementation
                                                                                                                                             }
                                                                                                                                         };
                                                                                                                                         
                                                                                                                                         // Use reflection to set protected fields
                                                                                                                                         Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                         rowsField.setAccessible(true);
                                                                                                                                         rowsField.set(optimizer, 2);
                                                                                                                                         
                                                                                                                                         Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                         residualsField.setAccessible(true);
                                                                                                                                         residualsField.set(optimizer, new double[]{5.0, 1.0}); // First residual is larger
                                                                                                                                         
                                                                                                                                         Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                         weightsField.setAccessible(true);
                                                                                                                                         weightsField.set(optimizer, new double[]{1.0, 1.0}); // Equal weights
                                                                                                                                         
                                                                                                                                         // Calculate expected value (should include both elements)
                                                                                                                                         double expected = (5.0 * 5.0 * 1.0) + (1.0 * 1.0 * 1.0); // 25 + 1 = 26
                                                                                                                                         
                                                                                                                                         // Verify the calculation includes both elements
                                                                                                                                         assertEquals("Chi-square calculation should include first element", 
                                                                                                                                                     expected, optimizer.getChiSquare(), 0.0001);
                                                                                                                                         
                                                                                                                                         // Additional test with different weights
                                                                                                                                         weightsField.set(optimizer, new double[]{2.0, 1.0}); // First weight is larger
                                                                                                                                         expected = (5.0 * 5.0 * 2.0) + (1.0 * 1.0 * 1.0); // 50 + 1 = 51
                                                                                                                                         assertEquals("Chi-square calculation should properly weight first element", 
                                                                                                                                                     expected, optimizer.getChiSquare(), 0.0001);
                                                                                                                                     }

    @Test
                                                                                                                                public void testGetChiSquareWithExactArraySizeShouldThrowWhenMutated() throws Exception {
                                                                                                                                    // Setup test with arrays exactly matching rows count
                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                        @Override
                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                            return null; // Required implementation
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    // Use reflection to set protected fields
                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                    rowsField.set(optimizer, 3);
                                                                                                                                    
                                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                    residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                                    
                                                                                                                                    Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                    weightsField.setAccessible(true);
                                                                                                                                    weightsField.set(optimizer, new double[]{1.0, 1.0, 1.0});
                                                                                                                                    
                                                                                                                                    // This should throw ArrayIndexOutOfBoundsException with mutated version
                                                                                                                                    optimizer.getChiSquare();
                                                                                                                                }

    @Test
                                                                                                                                public void testGetChiSquareWithLargerArraysShouldProcessExtraElementWhenMutated() throws Exception {
                                                                                                                                    // Setup test with arrays larger than rows count
                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                        @Override
                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                            return null; // Simple implementation for test
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    // Use reflection to set protected fields
                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                    rowsField.set(optimizer, 2);
                                                                                                                                    
                                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                    residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0}); // Extra element
                                                                                                                                    
                                                                                                                                    Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                    weightsField.setAccessible(true);
                                                                                                                                    weightsField.set(optimizer, new double[]{1.0, 1.0, 1.0}); // Extra element
                                                                                                                                    
                                                                                                                                    // Original should process first 2 elements: 1*1*1 + 2*2*1 = 5
                                                                                                                                    // Mutated would process all 3: 1*1*1 + 2*2*1 + 3*3*1 = 14
                                                                                                                                    double result = optimizer.getChiSquare();
                                                                                                                                    
                                                                                                                                    // Assert original behavior (should be 5)
                                                                                                                                    assertEquals(5.0, result, 0.0001);
                                                                                                                                    
                                                                                                                                    // If mutated, this assertion would fail as result would be 14
                                                                                                                                }

    @Test
                                                                                                                            public void testGetChiSquareDetectsResidualCalculationMutation() {
                                                                                                                                // Setup test data where (target - objective) != (target + objective)
                                                                                                                                double[] targetValues = {2.0, 3.0, 4.0};
                                                                                                                                double[] objective = {1.0, 1.0, 1.0};
                                                                                                                                double[] residualsWeights = {1.0, 1.0, 1.0}; // uniform weights for simplicity
                                                                                                                                int rows = targetValues.length;
                                                                                                                                
                                                                                                                                // Create partial mock of the class under test
                                                                                                                                AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                    @Override
                                                                                                                                    protected VectorialPointValuePair doOptimize() {
                                                                                                                                        return null; // not needed for this test
                                                                                                                                    }
                                                                                                                                };
                                                                                                                                
                                                                                                                                // Set protected fields via reflection
                                                                                                                                try {
                                                                                                                                    Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("targetValues");
                                                                                                                                    targetField.setAccessible(true);
                                                                                                                                    targetField.set(optimizer, targetValues);
                                                                                                                                    
                                                                                                                                    Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                                                    objectiveField.setAccessible(true);
                                                                                                                                    objectiveField.set(optimizer, objective);
                                                                                                                                    
                                                                                                                                    Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                    weightsField.setAccessible(true);
                                                                                                                                    weightsField.set(optimizer, residualsWeights);
                                                                                                                                    
                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                    rowsField.set(optimizer, rows);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Failed to set up test fields via reflection");
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Calculate expected chi-square (using correct residual calculation)
                                                                                                                                double expectedChiSquare = 0;
                                                                                                                                for (int i = 0; i < rows; i++) {
                                                                                                                                    double residual = targetValues[i] - objective[i];
                                                                                                                                    expectedChiSquare += residual * residual * residualsWeights[i];
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Get actual chi-square and verify
                                                                                                                                double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                assertEquals("Chi-square calculation should use target - objective for residuals", 
                                                                                                                                            expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                                                
                                                                                                                                // Additional verification that mutated version would fail
                                                                                                                                double mutatedChiSquare = 0;
                                                                                                                                for (int i = 0; i < rows; i++) {
                                                                                                                                    double residual = targetValues[i] + objective[i];
                                                                                                                                    mutatedChiSquare += residual * residual * residualsWeights[i];
                                                                                                                                }
                                                                                                                                assertNotEquals("Test should detect mutation by showing different results", 
                                                                                                                                               mutatedChiSquare, actualChiSquare, 0.0001);
                                                                                                                            }

    @Test
                                                                                                                           public void testGetChiSquareDetectsResidualSignMutation() {
                                                                                                                               // Setup test data that will reveal the mutation
                                                                                                                               int testRows = 2;
                                                                                                                               double[] targetValues = {5.0, 10.0};
                                                                                                                               double[] objective = {3.0, 12.0};
                                                                                                                               double[] residualsWeights = {1.0, -1.0}; // Negative weight to reveal sign change
                                                                                                                               
                                                                                                                               // Create instance of the class under test
                                                                                                                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                   @Override
                                                                                                                                   protected VectorialPointValuePair doOptimize() {
                                                                                                                                       return null; // dummy implementation
                                                                                                                                   }
                                                                                                                               };
                                                                                                                               
                                                                                                                               // Set protected fields using reflection
                                                                                                                               try {
                                                                                                                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                   rowsField.setAccessible(true);
                                                                                                                                   rowsField.set(optimizer, testRows);
                                                                                                                                   
                                                                                                                                   Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("targetValues");
                                                                                                                                   targetField.setAccessible(true);
                                                                                                                                   targetField.set(optimizer, targetValues);
                                                                                                                                   
                                                                                                                                   Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                                                   objectiveField.setAccessible(true);
                                                                                                                                   objectiveField.set(optimizer, objective);
                                                                                                                                   
                                                                                                                                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                   weightsField.setAccessible(true);
                                                                                                                                   weightsField.set(optimizer, residualsWeights);
                                                                                                                                   
                                                                                                                                   // Calculate expected chi-square value manually
                                                                                                                                   double expectedChiSquare = 0;
                                                                                                                                   for (int i = 0; i < testRows; i++) {
                                                                                                                                       double residual = targetValues[i] - objective[i];
                                                                                                                                       expectedChiSquare += residual * residual * residualsWeights[i];
                                                                                                                                   }
                                                                                                                                   
                                                                                                                                   // Call the method and verify result
                                                                                                                                   double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                   assertEquals("Chi-square calculation should be sensitive to residual sign with negative weights", 
                                                                                                                                               expectedChiSquare, actualChiSquare, 1e-10);
                                                                                                                                   
                                                                                                                               } catch (Exception e) {
                                                                                                                                   fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                               }
                                                                                                                           }

    @Test
                                                                                                                           public void testGetChiSquareDetectsResidualSignMutation1() {
                                                                                                                               // Setup test data that will reveal the mutation
                                                                                                                               int testRows = 2;
                                                                                                                               double[] targetValues = {5.0, 10.0};
                                                                                                                               double[] objective = {3.0, 8.0}; // Changed second objective to 8
                                                                                                                               double[] residualsWeights = {1.0, -1.0}; // Negative weight to reveal sign change
                                                                                                                               
                                                                                                                               // Create instance of the class under test
                                                                                                                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                   @Override
                                                                                                                                   protected VectorialPointValuePair doOptimize() {
                                                                                                                                       return null; // dummy implementation
                                                                                                                                   }
                                                                                                                               };
                                                                                                                               
                                                                                                                               // Set protected fields using reflection
                                                                                                                               try {
                                                                                                                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                   rowsField.setAccessible(true);
                                                                                                                                   rowsField.set(optimizer, testRows);
                                                                                                                                   
                                                                                                                                   Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("targetValues");
                                                                                                                                   targetField.setAccessible(true);
                                                                                                                                   targetField.set(optimizer, targetValues);
                                                                                                                                   
                                                                                                                                   Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                                                   objectiveField.setAccessible(true);
                                                                                                                                   objectiveField.set(optimizer, objective);
                                                                                                                                   
                                                                                                                                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                   weightsField.setAccessible(true);
                                                                                                                                   weightsField.set(optimizer, residualsWeights);
                                                                                                                                   
                                                                                                                                   // Calculate expected chi-square value manually
                                                                                                                                   double expectedChiSquare = 0;
                                                                                                                                   for (int i = 0; i < testRows; i++) {
                                                                                                                                       double residual = targetValues[i] - objective[i];
                                                                                                                                       expectedChiSquare += residual * residual * residualsWeights[i];
                                                                                                                                   }
                                                                                                                                   
                                                                                                                                   // Call the method and verify result
                                                                                                                                   double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                   assertEquals("Chi-square calculation should be sensitive to residual sign with negative weights", 
                                                                                                                                               expectedChiSquare, actualChiSquare, 1e-10);
                                                                                                                                   
                                                                                                                               } catch (Exception e) {
                                                                                                                                   fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                               }
                                                                                                                           }

    @Test
                                                                                                                           public void testGetChiSquareDetectsResidualSignMutation2() {
                                                                                                                               // Setup test data that will reveal the mutation
                                                                                                                               int testRows = 2;
                                                                                                                               double[] targetValues = {5.0, 10.0};
                                                                                                                               double[] objective = {3.0, 8.0};
                                                                                                                               double[] residualsWeights = {2.0, -1.0}; // Different weights to reveal sign change
                                                                                                                               
                                                                                                                               // Create instance of the class under test
                                                                                                                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                   @Override
                                                                                                                                   protected VectorialPointValuePair doOptimize() {
                                                                                                                                       return null; // dummy implementation
                                                                                                                                   }
                                                                                                                               };
                                                                                                                               
                                                                                                                               // Set protected fields using reflection
                                                                                                                               try {
                                                                                                                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                   rowsField.setAccessible(true);
                                                                                                                                   rowsField.set(optimizer, testRows);
                                                                                                                                   
                                                                                                                                   Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("targetValues");
                                                                                                                                   targetField.setAccessible(true);
                                                                                                                                   targetField.set(optimizer, targetValues);
                                                                                                                                   
                                                                                                                                   Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                                                   objectiveField.setAccessible(true);
                                                                                                                                   objectiveField.set(optimizer, objective);
                                                                                                                                   
                                                                                                                                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                   weightsField.setAccessible(true);
                                                                                                                                   weightsField.set(optimizer, residualsWeights);
                                                                                                                                   
                                                                                                                                   // Calculate expected chi-square value manually
                                                                                                                                   double expectedChiSquare = 0;
                                                                                                                                   for (int i = 0; i < testRows; i++) {
                                                                                                                                       double residual = targetValues[i] - objective[i];
                                                                                                                                       expectedChiSquare += residual * residual * residualsWeights[i];
                                                                                                                                   }
                                                                                                                                   
                                                                                                                                   // Call the method and verify result
                                                                                                                                   double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                   assertEquals("Chi-square calculation should be sensitive to residual sign with negative weights", 
                                                                                                                                               expectedChiSquare, actualChiSquare, 1e-10);
                                                                                                                                   
                                                                                                                               } catch (Exception e) {
                                                                                                                                   fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                               }
                                                                                                                           }

    @Test
                                                                                                                          public void testGetChiSquareDetectsResidualZeroingMutant() {
                                                                                                                              // Setup test data
                                                                                                                              int testRows = 2;
                                                                                                                              double[] testResiduals = {1.5, 2.0}; // non-zero residuals
                                                                                                                              double[] testWeights = {1.0, 1.0}; // simple weights
                                                                                                                              
                                                                                                                              // Create test instance and set protected fields via reflection
                                                                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                  @Override
                                                                                                                                  protected VectorialPointValuePair doOptimize() {
                                                                                                                                      return null; // dummy implementation
                                                                                                                                  }
                                                                                                                              };
                                                                                                                              
                                                                                                                              try {
                                                                                                                                  // Set protected fields using reflection
                                                                                                                                  Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                  residualsField.setAccessible(true);
                                                                                                                                  residualsField.set(optimizer, testResiduals);
                                                                                                                                  
                                                                                                                                  Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                  weightsField.setAccessible(true);
                                                                                                                                  weightsField.set(optimizer, testWeights);
                                                                                                                                  
                                                                                                                                  Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                  rowsField.setAccessible(true);
                                                                                                                                  rowsField.set(optimizer, testRows);
                                                                                                                              } catch (Exception e) {
                                                                                                                                  fail("Failed to set up test fields via reflection");
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Calculate expected value manually
                                                                                                                              double expectedChiSquare = 0;
                                                                                                                              for (int i = 0; i < testRows; i++) {
                                                                                                                                  expectedChiSquare += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Test and assert
                                                                                                                              double actualChiSquare = optimizer.getChiSquare();
                                                                                                                              assertEquals("Chi-square calculation should use actual residuals", 
                                                                                                                                           expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                                              
                                                                                                                              // Additional assertion to specifically catch the mutant
                                                                                                                              assertNotEquals("Chi-square should not be zero with non-zero residuals", 
                                                                                                                                             0.0, actualChiSquare, 0.0001);
                                                                                                                          }

    @Test
                                                                                                                         public void testGetChiSquare_DetectsResidualMutation() {
                                                                                                                             // Setup test data
                                                                                                                             int rows = 2;
                                                                                                                             double[] residuals = new double[]{2.0, 3.0};
                                                                                                                             double[] residualsWeights = new double[]{1.0, 1.0};
                                                                                                                             
                                                                                                                             // Create a subclass to test the protected method
                                                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                 @Override
                                                                                                                                 protected VectorialPointValuePair doOptimize() {
                                                                                                                                     return null; // Not needed for this test
                                                                                                                                 }
                                                                                                                             };
                                                                                                                             
                                                                                                                             // Use reflection to set protected fields since they're not directly accessible
                                                                                                                             try {
                                                                                                                                 Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                 residualsField.setAccessible(true);
                                                                                                                                 residualsField.set(optimizer, residuals);
                                                                                                                                 
                                                                                                                                 Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                 weightsField.setAccessible(true);
                                                                                                                                 weightsField.set(optimizer, residualsWeights);
                                                                                                                                 
                                                                                                                                 Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                 rowsField.setAccessible(true);
                                                                                                                                 rowsField.set(optimizer, rows);
                                                                                                                             } catch (Exception e) {
                                                                                                                                 fail("Failed to set up test fields via reflection");
                                                                                                                             }
                                                                                                                             
                                                                                                                             // Create a thread that will modify residuals during calculation
                                                                                                                             Thread modifier = new Thread(() -> {
                                                                                                                                 try {
                                                                                                                                     // Small delay to try to hit during calculation
                                                                                                                                     Thread.sleep(10);
                                                                                                                                     residuals[0] = 5.0; // Modify the first residual
                                                                                                                                 } catch (InterruptedException e) {
                                                                                                                                     Thread.currentThread().interrupt();
                                                                                                                                 }
                                                                                                                             });
                                                                                                                             
                                                                                                                             modifier.start();
                                                                                                                             
                                                                                                                             // Calculate chi-square while residuals might be modified
                                                                                                                             double result = optimizer.getChiSquare();
                                                                                                                             
                                                                                                                             // Stop the modifier thread
                                                                                                                             modifier.interrupt();
                                                                                                                             
                                                                                                                             // Verify the calculation used original values (2^2*1 + 3^2*1 = 4 + 9 = 13)
                                                                                                                             // If mutant is present, it might use modified value (5^2*1 + 3^2*1 = 25 + 9 = 34)
                                                                                                                             assertEquals(13.0, result, 0.0001);
                                                                                                                         }

    @Test
                                                                                                                       public void testGetChiSquareDetectsIndexMutation() {
                                                                                                                           // Setup test data
                                                                                                                           int rows = 3;
                                                                                                                           int cols = 2;
                                                                                                                           double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                           double[] residualsWeights = {0.5, 1.0, 1.5};
                                                                                                                           
                                                                                                                           // Create partial mock of the optimizer
                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                               @Override
                                                                                                                               protected VectorialPointValuePair doOptimize() {
                                                                                                                                   return null;
                                                                                                                               }
                                                                                                                           };
                                                                                                                           
                                                                                                                           // Set protected fields using reflection
                                                                                                                           try {
                                                                                                                               Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                               rowsField.setAccessible(true);
                                                                                                                               rowsField.set(optimizer, rows);
                                                                                                                               
                                                                                                                               Field colsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cols");
                                                                                                                               colsField.setAccessible(true);
                                                                                                                               colsField.set(optimizer, cols);
                                                                                                                               
                                                                                                                               Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                               residualsField.setAccessible(true);
                                                                                                                               residualsField.set(optimizer, residuals);
                                                                                                                               
                                                                                                                               Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                               weightsField.setAccessible(true);
                                                                                                                               weightsField.set(optimizer, residualsWeights);
                                                                                                                           } catch (Exception e) {
                                                                                                                               fail("Failed to set up test fields via reflection");
                                                                                                                           }
                                                                                                                           
                                                                                                                           // Calculate expected value manually
                                                                                                                           double expected = 0;
                                                                                                                           for (int i = 0; i < rows; i++) {
                                                                                                                               expected += residuals[i] * residuals[i] * residualsWeights[i];
                                                                                                                           }
                                                                                                                           
                                                                                                                           // Test and verify
                                                                                                                           double actual = optimizer.getChiSquare();
                                                                                                                           assertEquals("Chi-square calculation should be correct", expected, actual, 1e-10);
                                                                                                                           
                                                                                                                           // Additional verification that all residuals were processed
                                                                                                                           // Calculate max possible value without using streams
                                                                                                                           double maxWeight = 0;
                                                                                                                           for (double weight : residualsWeights) {
                                                                                                                               if (weight > maxWeight) {
                                                                                                                                   maxWeight = weight;
                                                                                                                               }
                                                                                                                           }
                                                                                                                           double sumSquaredResiduals = 0;
                                                                                                                           for (double residual : residuals) {
                                                                                                                               sumSquaredResiduals += residual * residual;
                                                                                                                           }
                                                                                                                           double maxPossible = sumSquaredResiduals * maxWeight;
                                                                                                                           
                                                                                                                           assertTrue("Chi-square should be <= max possible value", actual <= maxPossible);
                                                                                                                           assertTrue("Chi-square should be >= min possible value", actual >= 0);
                                                                                                                       }

    @Test
                                                                                                                  public void testGetChiSquareDetectsIndexMutation1() throws Exception {
                                                                                                                      // Setup test data with multiple rows and varying residuals/weights
                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                          // Anonymous subclass for testing protected methods
                                                                                                                          @Override
                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                              return null;
                                                                                                                          }
                                                                                                                      };
                                                                                                                      
                                                                                                                      // Use reflection to set protected fields
                                                                                                                      Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                                                                      
                                                                                                                      // Set rows and cols
                                                                                                                      java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                      rowsField.setAccessible(true);
                                                                                                                      rowsField.set(optimizer, 3);
                                                                                                                      
                                                                                                                      java.lang.reflect.Field colsField = optimizerClass.getDeclaredField("cols");
                                                                                                                      colsField.setAccessible(true);
                                                                                                                      colsField.set(optimizer, 2);
                                                                                                                      
                                                                                                                      // Set residuals and weights
                                                                                                                      double[] testResiduals = new double[]{1.0, 2.0, 3.0};
                                                                                                                      double[] testWeights = new double[]{0.5, 1.0, 1.5};
                                                                                                                      
                                                                                                                      java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                      residualsField.setAccessible(true);
                                                                                                                      residualsField.set(optimizer, testResiduals);
                                                                                                                      
                                                                                                                      java.lang.reflect.Field weightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                      weightsField.setAccessible(true);
                                                                                                                      weightsField.set(optimizer, testWeights);
                                                                                                                      
                                                                                                                      // Calculate expected chi-square manually
                                                                                                                      double expected = 0;
                                                                                                                      for (int i = 0; i < 3; i++) {
                                                                                                                          expected += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                                                      }
                                                                                                                      
                                                                                                                      // Call method and verify
                                                                                                                      double actual = optimizer.getChiSquare();
                                                                                                                      assertEquals("Chi-square calculation should be correct", expected, actual, 0.0001);
                                                                                                                      
                                                                                                                      // Additional verification - mutation would cause wrong residuals to be used
                                                                                                                      double wrongValue = 3 * testResiduals[0] * testResiduals[0] * testWeights[0];
                                                                                                                      assertNotEquals("Should not use same residual for all calculations", 
                                                                                                                                     wrongValue, actual, 0.0001);
                                                                                                                  }

    @Test
                                                                                                              public void testGetChiSquareWithDifferentLoopIncrementStyles() {
                                                                                                                  // Setup test data
                                                                                                                  int testRows = 3;
                                                                                                                  double[] testResiduals = {1.0, 2.0, 3.0};
                                                                                                                  double[] testWeights = {0.5, 1.0, 1.5};
                                                                                                                  
                                                                                                                  // Create partial mock of the abstract class
                                                                                                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                      // Implement abstract methods
                                                                                                                      protected VectorialPointValuePair doOptimize() {
                                                                                                                          return null;
                                                                                                                      }
                                                                                                                  };
                                                                                                                  
                                                                                                                  // Set protected fields using reflection
                                                                                                                  try {
                                                                                                                      Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                      rowsField.setAccessible(true);
                                                                                                                      rowsField.set(optimizer, testRows);
                                                                                                                      
                                                                                                                      Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                      residualsField.setAccessible(true);
                                                                                                                      residualsField.set(optimizer, testResiduals);
                                                                                                                      
                                                                                                                      Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                      weightsField.setAccessible(true);
                                                                                                                      weightsField.set(optimizer, testWeights);
                                                                                                                  } catch (Exception e) {
                                                                                                                      fail("Failed to set up test fields via reflection");
                                                                                                                  }
                                                                                                                  
                                                                                                                  // Calculate expected value
                                                                                                                  double expected = 0;
                                                                                                                  for (int i = 0; i < testRows; i++) {
                                                                                                                      expected += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                                                  }
                                                                                                                  
                                                                                                                  // Test the method
                                                                                                                  double actual = optimizer.getChiSquare();
                                                                                                                  
                                                                                                                  // Verify the result
                                                                                                                  assertEquals("Chi-square calculation should be correct", 
                                                                                                                              expected, actual, 1e-10);
                                                                                                                  
                                                                                                                  // Additional verification for edge case with zero rows
                                                                                                                  try {
                                                                                                                      Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                      rowsField.setAccessible(true);
                                                                                                                      rowsField.set(optimizer, 0);
                                                                                                                      
                                                                                                                      double zeroResult = optimizer.getChiSquare();
                                                                                                                      assertEquals("Chi-square should be 0 with zero rows", 
                                                                                                                                  0.0, zeroResult, 1e-10);
                                                                                                                  } catch (Exception e) {
                                                                                                                      fail("Failed to test zero rows case");
                                                                                                                  }
                                                                                                              }

    @Test
                                                                                                            public void testGetChiSquareDetectsCostMutation1() throws Exception {
                                                                                                                // Setup test data
                                                                                                                AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                    @Override
                                                                                                                    protected VectorialPointValuePair doOptimize() {
                                                                                                                        return null; // dummy implementation
                                                                                                                    }
                                                                                                                };
                                                                                                                
                                                                                                                // Use reflection to set protected fields
                                                                                                                Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                                                                java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                rowsField.setAccessible(true);
                                                                                                                rowsField.set(optimizer, 2);
                                                                                                                
                                                                                                                java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                residualsField.setAccessible(true);
                                                                                                                residualsField.set(optimizer, new double[]{2.0, 3.0});
                                                                                                                
                                                                                                                java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                residualsWeightsField.setAccessible(true);
                                                                                                                residualsWeightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                
                                                                                                                // Calculate expected chi-square with proper sqrt cost
                                                                                                                double expectedCost = Math.sqrt(2.0*2.0*1.0 + 3.0*3.0*1.0); // sqrt(4 + 9) = sqrt(13) ≈ 3.6055
                                                                                                                double expectedChiSquare = 2.0*2.0*1.0 + 3.0*3.0*1.0; // 4 + 9 = 13
                                                                                                                
                                                                                                                // Manually set the cost to test both correct and mutated behavior
                                                                                                                // First test correct behavior (sqrt)
                                                                                                                java.lang.reflect.Field costField = optimizerClass.getDeclaredField("cost");
                                                                                                                costField.setAccessible(true);
                                                                                                                costField.set(optimizer, Math.sqrt(13.0));
                                                                                                                assertEquals(expectedChiSquare, optimizer.getChiSquare(), 1e-10);
                                                                                                                
                                                                                                                // Now test mutated behavior (pow 2)
                                                                                                                costField.set(optimizer, Math.pow(13.0, 2)); // mutated version would set cost to 169
                                                                                                                assertNotEquals(expectedChiSquare, optimizer.getChiSquare(), 1e-10);
                                                                                                                
                                                                                                                // Additional verification that the chi-square is independent of cost
                                                                                                                // (since the mutation shouldn't affect chi-square calculation directly)
                                                                                                                assertEquals(13.0, optimizer.getChiSquare(), 1e-10);
                                                                                                            }

    @Test
                                                                                                   public void testGetChiSquareDetectsSqrtToAbsMutation() throws Exception {
                                                                                                       // Create a concrete subclass for testing
                                                                                                       class TestOptimizer extends AbstractLeastSquaresOptimizer {
                                                                                                           private int rows;
                                                                                                           private double[] residuals;
                                                                                                           private double[] weights;
                                                                                                           private double cost;
                                                                                                           
                                                                                                           public TestOptimizer() {
                                                                                                               super();
                                                                                                           }
                                                                                                           
                                                                                                           @Override
                                                                                                           public double getChiSquare() {
                                                                                                               // Store the cost before calculation to test mutation
                                                                                                               cost = Math.sqrt(cost); // Original behavior (sqrt)
                                                                                                               // cost = Math.abs(cost); // Mutant behavior (abs)
                                                                                                               return super.getChiSquare();
                                                                                                           }
                                                                                                           
                                                                                                           @Override
                                                                                                           protected VectorialPointValuePair doOptimize() {
                                                                                                               // Dummy implementation for abstract method
                                                                                                               return null;
                                                                                                           }
                                                                                                           
                                                                                                           // These methods are not actually overriding anything in parent class,
                                                                                                           // but are needed for the test
                                                                                                           protected int getRows() {
                                                                                                               return rows;
                                                                                                           }
                                                                                                           
                                                                                                           protected double[] getResiduals() {
                                                                                                               return residuals;
                                                                                                           }
                                                                                                           
                                                                                                           protected double[] getWeights() {
                                                                                                               return weights;
                                                                                                           }
                                                                                                       }
                                                                                                       
                                                                                                       // Create test instance
                                                                                                       TestOptimizer optimizer = new TestOptimizer();
                                                                                                       
                                                                                                       // Set up test data with known values
                                                                                                       int testRows = 3;
                                                                                                       double[] testResiduals = {1.0, -2.0, 0.5};
                                                                                                       double[] testWeights = {1.0, 1.0, 1.0};
                                                                                                       
                                                                                                       // Set fields using reflection
                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                       rowsField.setAccessible(true);
                                                                                                       rowsField.set(optimizer, testRows);
                                                                                                       
                                                                                                       Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                       residualsField.setAccessible(true);
                                                                                                       residualsField.set(optimizer, testResiduals);
                                                                                                       
                                                                                                       Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weights");
                                                                                                       weightsField.setAccessible(true);
                                                                                                       weightsField.set(optimizer, testWeights);
                                                                                                       
                                                                                                       // Test case 1: Verify intermediate cost calculation
                                                                                                       // Original would calculate sqrt, mutant would calculate abs
                                                                                                       double testCost = 0.25; // Value between 0 and 1
                                                                                                       Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                       costField.setAccessible(true);
                                                                                                       costField.set(optimizer, testCost);
                                                                                                       
                                                                                                       // Calculate expected values
                                                                                                       double expectedChiSquare = 0; // 1*1*1 + (-2)*(-2)*1 + 0.5*0.5*1 = 1 + 4 + 0.25 = 5.25
                                                                                                       for (int i = 0; i < testRows; i++) {
                                                                                                           expectedChiSquare += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                                       }
                                                                                                       
                                                                                                       // Verify the chi-square calculation is correct
                                                                                                       assertEquals(expectedChiSquare, optimizer.getChiSquare(), 1e-10);
                                                                                                       
                                                                                                       // Verify the cost was processed with sqrt (not abs)
                                                                                                       // Original would have cost = sqrt(0.25) = 0.5
                                                                                                       // Mutant would have cost = abs(0.25) = 0.25
                                                                                                       assertEquals(0.5, costField.getDouble(optimizer), 1e-10);
                                                                                                       
                                                                                                       // Test case 2: Negative cost value
                                                                                                       testCost = -4.0;
                                                                                                       costField.set(optimizer, testCost);
                                                                                                       optimizer.getChiSquare(); // This should process the cost
                                                                                                       
                                                                                                       // Original would have cost = sqrt(-4) = NaN
                                                                                                       // Mutant would have cost = abs(-4) = 4
                                                                                                       assertTrue(Double.isNaN(costField.getDouble(optimizer)));
                                                                                                       
                                                                                                       // Test case 3: Cost > 1
                                                                                                       testCost = 9.0;
                                                                                                       costField.set(optimizer, testCost);
                                                                                                       optimizer.getChiSquare(); // This should process the cost
                                                                                                       
                                                                                                       // Original would have cost = sqrt(9) = 3
                                                                                                       // Mutant would have cost = abs(9) = 9
                                                                                                       assertEquals(3.0, costField.getDouble(optimizer), 1e-10);
                                                                                                   }

    @Test
                                                                                               public void testGetChiSquare2() {
                                                                                                   // Create a test instance using reflection since constructor is protected
                                                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                       @Override
                                                                                                       protected VectorialPointValuePair doOptimize() {
                                                                                                           return null; // dummy implementation
                                                                                                       }
                                                                                                   };
                                                                                                   
                                                                                                   // Set up test data using reflection to access protected fields
                                                                                                   try {
                                                                                                       // Case 1: Single row with positive values
                                                                                                       Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                       residualsField.setAccessible(true);
                                                                                                       residualsField.set(optimizer, new double[]{2.0});
                                                                                                       
                                                                                                       Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                       weightsField.setAccessible(true);
                                                                                                       weightsField.set(optimizer, new double[]{1.5});
                                                                                                       
                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                       rowsField.setAccessible(true);
                                                                                                       rowsField.setInt(optimizer, 1);
                                                                                                       
                                                                                                       assertEquals(6.0, optimizer.getChiSquare(), 0.0001); // 2.0^2 * 1.5 = 6.0
                                                                                                       
                                                                                                       // Case 2: Multiple rows with mixed values
                                                                                                       residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                       weightsField.set(optimizer, new double[]{2.0, 1.0, 0.5});
                                                                                                       rowsField.setInt(optimizer, 3);
                                                                                                       
                                                                                                       double expected = (1.0*1.0*2.0) + (2.0*2.0*1.0) + (3.0*3.0*0.5);
                                                                                                       assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                                                                                                       
                                                                                                       // Case 3: Edge case - zero residuals
                                                                                                       residualsField.set(optimizer, new double[]{0.0, 0.0});
                                                                                                       weightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                       rowsField.setInt(optimizer, 2);
                                                                                                       
                                                                                                       assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                                                                       
                                                                                                       // Case 4: Edge case - zero weights (should still work)
                                                                                                       residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                       weightsField.set(optimizer, new double[]{0.0, 0.0});
                                                                                                       rowsField.setInt(optimizer, 2);
                                                                                                       
                                                                                                       assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                                                                       
                                                                                                       // Case 5: Empty input (rows = 0)
                                                                                                       residualsField.set(optimizer, new double[0]);
                                                                                                       weightsField.set(optimizer, new double[0]);
                                                                                                       rowsField.setInt(optimizer, 0);
                                                                                                       
                                                                                                       assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                                                                       
                                                                                                   } catch (Exception e) {
                                                                                                       fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                   }
                                                                                               }

    @Test
                                                                                     public void testEvaluationCountingWithMaxEvaluations() {
                                                                                         // Setup test with mock function and small max evaluations
                                                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                             @Override
                                                                                             protected VectorialPointValuePair doOptimize() {
                                                                                                 // Force multiple evaluations
                                                                                                 try {
                                                                                                     updateResidualsAndCost();
                                                                                                 } catch (FunctionEvaluationException e) {
                                                                                                     fail("Unexpected FunctionEvaluationException");
                                                                                                 }
                                                                                                 return new VectorialPointValuePair(new double[0], new double[0], true);
                                                                                             }
                                                                                         };
                                                                                         
                                                                                         // Set small max evaluations to easily trigger the limit
                                                                                         final int smallMaxEvals = 3;
                                                                                         optimizer.setMaxEvaluations(smallMaxEvals);
                                                                                         
                                                                                         try {
                                                                                             // Use reflection to set protected fields
                                                                                             Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                             residualsField.setAccessible(true);
                                                                                             residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                             
                                                                                             Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                             weightsField.setAccessible(true);
                                                                                             weightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                             
                                                                                             Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                             rowsField.setAccessible(true);
                                                                                             rowsField.set(optimizer, 2);
                                                                                             
                                                                                             // This should trigger evaluation counting
                                                                                             optimizer.optimize(mock(DifferentiableMultivariateVectorialFunction.class), 
                                                                                                              new double[]{0, 0}, new double[]{1, 1}, new double[]{0, 0});
                                                                                             
                                                                                             // Verify exact evaluation count
                                                                                             assertEquals("Evaluation count should exactly match max evaluations", 
                                                                                                         smallMaxEvals, optimizer.getEvaluations());
                                                                                         } catch (Exception e) {
                                                                                             fail("Optimization should complete normally within evaluation limits");
                                                                                         }
                                                                                         
                                                                                         // Additional verification that we didn't exceed max evaluations
                                                                                         assertTrue("Evaluation count should not exceed max evaluations",
                                                                                                   optimizer.getEvaluations() <= smallMaxEvals);
                                                                                     }

    @Test
                                                                                public void testEvaluationBoundaryCondition1() throws Exception {
                                                                                    // Setup test with maxEvaluations = 1
                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                        @Override
                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                            return null; // dummy implementation
                                                                                        }
                                                                                    };
                                                                                    optimizer.setMaxEvaluations(1);
                                                                                    
                                                                                    // Get the protected incrementIterationsCounter method via reflection
                                                                                    Method incrementMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("incrementIterationsCounter");
                                                                                    incrementMethod.setAccessible(true);
                                                                                    
                                                                                    // Verify initial state
                                                                                    assertEquals(0, optimizer.getEvaluations());
                                                                                    
                                                                                    // First evaluation should work in both original and mutant
                                                                                    incrementMethod.invoke(optimizer);
                                                                                    assertEquals(1, optimizer.getEvaluations());
                                                                                    
                                                                                    // Second evaluation - this is where behavior differs
                                                                                    try {
                                                                                        incrementMethod.invoke(optimizer);
                                                                                        // Original allows this (1 < 1 is false)
                                                                                        // Mutant would throw exception here (1 >= 1 is true)
                                                                                    } catch (Exception e) {
                                                                                        fail("Original implementation should allow exactly maxEvaluations evaluations");
                                                                                    }
                                                                                    
                                                                                    // Verify we reached exactly maxEvaluations without exception
                                                                                    assertEquals(1, optimizer.getEvaluations());
                                                                                    
                                                                                    // Now test exactly at boundary
                                                                                    optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                        @Override
                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                            return null;
                                                                                        }
                                                                                    };
                                                                                    optimizer.setMaxEvaluations(2);
                                                                                    
                                                                                    // First two evaluations should work
                                                                                    incrementMethod.invoke(optimizer);
                                                                                    incrementMethod.invoke(optimizer);
                                                                                    assertEquals(2, optimizer.getEvaluations());
                                                                                    
                                                                                    // Third evaluation should fail in both
                                                                                    try {
                                                                                        incrementMethod.invoke(optimizer);
                                                                                        fail("Should have thrown exception when exceeding maxEvaluations");
                                                                                    } catch (Exception e) {
                                                                                        // Expected
                                                                                    }
                                                                                }

    @Test
                                                           public void testOptimizeDoesNotCallFunctionWithNull() throws Exception {
                                                               // Setup test data
                                                               double[] startPoint = {1.0, 2.0};
                                                               double[] target = {3.0, 4.0};
                                                               double[] weights = {1.0, 1.0};
                                                               
                                                               // Mock the function and its behavior
                                                               DifferentiableMultivariateVectorialFunction function = mock(DifferentiableMultivariateVectorialFunction.class);
                                                               when(function.value(startPoint)).thenReturn(new double[]{1.0, 1.0});
                                                               
                                                               // Create optimizer instance
                                                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                   @Override
                                                                   protected VectorialPointValuePair doOptimize() {
                                                                       return new VectorialPointValuePair(startPoint, new double[]{1.0, 1.0});
                                                                   }
                                                               };
                                                               
                                                               // Set required protected fields using reflection
                                                               Field pointField = AbstractLeastSquaresOptimizer.class.getDeclaredField("point");
                                                               pointField.setAccessible(true);
                                                               pointField.set(optimizer, startPoint);
                                                               
                                                               Field targetValuesField = AbstractLeastSquaresOptimizer.class.getDeclaredField("targetValues");
                                                               targetValuesField.setAccessible(true);
                                                               targetValuesField.set(optimizer, target);
                                                               
                                                               Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                               residualsWeightsField.setAccessible(true);
                                                               residualsWeightsField.set(optimizer, weights);
                                                               
                                                               Field functionField = AbstractLeastSquaresOptimizer.class.getDeclaredField("function");
                                                               functionField.setAccessible(true);
                                                               functionField.set(optimizer, function);
                                                               
                                                               // Execute optimization
                                                               VectorialPointValuePair result = optimizer.optimize(function, target, weights, startPoint);
                                                               
                                                               // Verify function was called with correct point, not null
                                                               verify(function).value(startPoint);
                                                               
                                                               // Verify results
                                                               assertNotNull(result);
                                                               assertArrayEquals(startPoint, result.getPoint(), 0.0001);
                                                               assertArrayEquals(new double[]{1.0, 1.0}, result.getValue(), 0.0001);
                                                           }

    @Test(expected = IllegalArgumentException.class)
                                                      public void testGetChiSquare_shouldThrowWhenLengthsDiffer() {
                                                          // Create mock optimizer
                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                              @Override
                                                              protected VectorialPointValuePair doOptimize() {
                                                                  return null;
                                                              }
                                                          };
                                                          
                                                          // Set up test data with mismatched lengths
                                                          try {
                                                              Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                              residualsField.setAccessible(true);
                                                              residualsField.set(optimizer, new double[3]); // rows=3
                                                              
                                                              Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                              residualsWeightsField.setAccessible(true);
                                                              residualsWeightsField.set(optimizer, new double[4]); // length 4
                                                              
                                                              // This should throw IllegalArgumentException
                                                              optimizer.getChiSquare();
                                                          } catch (NoSuchFieldException | IllegalAccessException e) {
                                                              fail("Failed to set up test via reflection: " + e.getMessage());
                                                          }
                                                      }

    @Test
                                                      public void testGetChiSquare_shouldPassWhenLengthsMatch() throws Exception {
                                                          // Create optimizer instance
                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                              protected VectorialPointValuePair doOptimize() {
                                                                  return null;
                                                              }
                                                          };
                                                          
                                                          // Set up test data using reflection
                                                          int rows = 3;
                                                          Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                          residualsField.setAccessible(true);
                                                          residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                          
                                                          Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                          weightsField.setAccessible(true);
                                                          weightsField.set(optimizer, new double[]{0.5, 0.5, 0.5});
                                                          
                                                          Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                          rowsField.setAccessible(true);
                                                          rowsField.set(optimizer, rows);
                                                          
                                                          // Calculate expected chi-square value
                                                          double expected = 1.0*1.0*0.5 + 2.0*2.0*0.5 + 3.0*3.0*0.5;
                                                          
                                                          // Verify calculation
                                                          assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                                                      }

    @Test
                                                 public void testGetChiSquareWithEqualLength() {
                                                     // Create a concrete implementation or mock of the optimizer
                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                         @Override
                                                         protected VectorialPointValuePair doOptimize() {
                                                             return null;
                                                         }
                                                     };
                                                     
                                                     // Initialize objective array
                                                     double[] objective = new double[3];
                                                     
                                                     try {
                                                         // Set objective field
                                                         java.lang.reflect.Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                         objectiveField.setAccessible(true);
                                                         objectiveField.set(optimizer, objective);
                                                         
                                                         // Set up residuals and weights (required for chi-square calculation)
                                                         java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                         residualsField.setAccessible(true);
                                                         residualsField.set(optimizer, new double[3]);
                                                         
                                                         java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                         weightsField.setAccessible(true);
                                                         weightsField.set(optimizer, new double[3]);
                                                         
                                                         double result = optimizer.getChiSquare();
                                                         // Just verify no exception is thrown
                                                         assertTrue(result >= 0);
                                                     } catch (Exception e) {
                                                         fail("Unexpected exception: " + e.getMessage());
                                                     }
                                                 }

    @Test
                                                 public void testGetChiSquareWithGreaterLength() {
                                                     // Create optimizer instance
                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                         @Override
                                                         protected VectorialPointValuePair doOptimize() {
                                                             return null;
                                                         }
                                                     };
                                                     
                                                     // Set objective length greater than rows (should fail)
                                                     double[] objective = new double[4];
                                                     double[] residuals = new double[3]; // Assuming rows = 3
                                                     double[] residualsWeights = new double[3];
                                                     
                                                     try {
                                                         // Set up the test scenario using reflection
                                                         java.lang.reflect.Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                         objectiveField.setAccessible(true);
                                                         objectiveField.set(optimizer, objective);
                                                         
                                                         java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                         residualsField.setAccessible(true);
                                                         residualsField.set(optimizer, residuals);
                                                         
                                                         java.lang.reflect.Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                         residualsWeightsField.setAccessible(true);
                                                         residualsWeightsField.set(optimizer, residualsWeights);
                                                         
                                                         java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                         rowsField.setAccessible(true);
                                                         rowsField.set(optimizer, 3); // Set rows to 3
                                                         
                                                         // This should throw ArrayIndexOutOfBoundsException
                                                         optimizer.getChiSquare();
                                                         fail("Expected ArrayIndexOutOfBoundsException");
                                                     } catch (ArrayIndexOutOfBoundsException e) {
                                                         // Expected exception
                                                     } catch (Exception e) {
                                                         fail("Unexpected exception: " + e.getMessage());
                                                     }
                                                 }

    @Test
                                                 public void testGetChiSquareWithSmallerLength() {
                                                     // Create a concrete instance of the optimizer
                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                         @Override
                                                         protected VectorialPointValuePair doOptimize() {
                                                             return null;
                                                         }
                                                     };
                                                     
                                                     // Set objective length smaller than rows (should fail in original but pass in mutant)
                                                     double[] objective = new double[2];
                                                     try {
                                                         java.lang.reflect.Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                         objectiveField.setAccessible(true);
                                                         objectiveField.set(optimizer, objective);
                                                         
                                                         // Set rows to a value larger than objective length
                                                         java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                         rowsField.setAccessible(true);
                                                         rowsField.set(optimizer, 3);
                                                         
                                                         optimizer.getChiSquare();
                                                         // If we get here, the mutant survived (no exception thrown)
                                                         fail("Expected IllegalArgumentException when objective.length < rows");
                                                     } catch (IllegalArgumentException e) {
                                                         // Expected in original code
                                                         throw e;
                                                     } catch (Exception e) {
                                                         fail("Unexpected exception: " + e.getMessage());
                                                     }
                                                 }

    @Test
                                            public void testGetChiSquareThrowsExceptionWithCorrectPointWhenDimensionsMismatch1() throws Exception {
                                                // Setup test data with dimensions mismatch
                                                AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                    @Override
                                                    protected VectorialPointValuePair doOptimize() {
                                                        return null;
                                                    }
                                                };
                                                
                                                // Use reflection to set protected fields
                                                Class<?> optimizerClass = optimizer.getClass();
                                                java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                rowsField.setAccessible(true);
                                                rowsField.set(optimizer, 2);
                                                
                                                java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                residualsField.setAccessible(true);
                                                residualsField.set(optimizer, new double[]{1.0}); // Only 1 element
                                                
                                                java.lang.reflect.Field weightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                weightsField.setAccessible(true);
                                                weightsField.set(optimizer, new double[]{1.0, 1.0}); // 2 elements
                                                
                                                final double[] expectedPoint = new double[]{1.0, 2.0};
                                                java.lang.reflect.Field pointField = optimizerClass.getDeclaredField("point");
                                                pointField.setAccessible(true);
                                                pointField.set(optimizer, expectedPoint);
                                                
                                                // Expect exception and verify its point parameter
                                                thrown.expect(FunctionEvaluationException.class);
                                                thrown.expectMessage(LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE.toString());
                                                thrown.expect(new org.hamcrest.BaseMatcher<FunctionEvaluationException>() {
                                                    @Override
                                                    public boolean matches(Object item) {
                                                        if (item instanceof FunctionEvaluationException) {
                                                            // Get point through reflection since FunctionEvaluationException doesn't have getPoint()
                                                            try {
                                                                java.lang.reflect.Field exPointField = item.getClass().getDeclaredField("point");
                                                                exPointField.setAccessible(true);
                                                                double[] point = (double[]) exPointField.get(item);
                                                                return point != null && point.length == 2 && point[0] == 1.0 && point[1] == 2.0;
                                                            } catch (Exception e) {
                                                                return false;
                                                            }
                                                        }
                                                        return false;
                                                    }
                                            
                                                    @Override
                                                    public void describeTo(org.hamcrest.Description description) {
                                                        description.appendText("FunctionEvaluationException with point [1.0, 2.0]");
                                                    }
                                                });
                                                
                                                // Trigger the method that should throw exception
                                                optimizer.getChiSquare();
                                            }

    @Test
                                       public void testGetChiSquareDetectsInitializationMutant1() {
                                           // Setup test data
                                           int testRows = 2;
                                           double[] testResiduals = {2.0, 3.0};  // residuals
                                           double[] testWeights = {1.0, 0.5};    // weights
                                           
                                           // Create instance and set test data
                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                               // Anonymous subclass for testing
                                               @Override
                                               protected VectorialPointValuePair doOptimize() {
                                                   return null; // Dummy implementation for testing
                                               }
                                           };
                                           
                                           // Use reflection to set protected fields for testing
                                           try {
                                               Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                               rowsField.setAccessible(true);
                                               rowsField.set(optimizer, testRows);
                                               
                                               Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                               residualsField.setAccessible(true);
                                               residualsField.set(optimizer, testResiduals);
                                               
                                               Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                               weightsField.setAccessible(true);
                                               weightsField.set(optimizer, testWeights);
                                           } catch (Exception e) {
                                               fail("Failed to set test data via reflection: " + e.getMessage());
                                           }
                                           
                                           // Calculate expected value manually: (2^2)*1 + (3^2)*0.5 = 4 + 4.5 = 8.5
                                           double expectedChiSquare = 8.5;
                                           
                                           // Call method and get result
                                           double actualChiSquare = optimizer.getChiSquare();
                                           
                                           // Assert - this will fail if chiSquare was initialized to 1 instead of 0
                                           assertEquals("Chi-square calculation incorrect - mutation not detected", 
                                                       expectedChiSquare, actualChiSquare, 0.0001);
                                       }

    @Test
                                  public void testGetChiSquareDetectsInitializationMutant2() throws Exception {
                                      // Create a partial mock of the abstract class
                                      AbstractLeastSquaresOptimizer optimizer = spy(AbstractLeastSquaresOptimizer.class);
                                      
                                      // Get the protected fields
                                      Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                      Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                      Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                      
                                      // Make the fields accessible
                                      rowsField.setAccessible(true);
                                      residualsField.setAccessible(true);
                                      residualsWeightsField.setAccessible(true);
                                      
                                      // Test case 1: Empty residuals (rows = 0)
                                      rowsField.set(optimizer, 0);
                                      residualsField.set(optimizer, new double[0]);
                                      residualsWeightsField.set(optimizer, new double[0]);
                                      assertEquals("Chi-square should be 0 for empty residuals", 0.0, optimizer.getChiSquare(), 0.0001);
                                      
                                      // Test case 2: Single residual
                                      rowsField.set(optimizer, 1);
                                      residualsField.set(optimizer, new double[]{2.0});
                                      residualsWeightsField.set(optimizer, new double[]{1.0});
                                      // Expected: 2^2 * 1 = 4
                                      assertEquals("Chi-square should be 4 for single residual", 4.0, optimizer.getChiSquare(), 0.0001);
                                      
                                      // Test case 3: Multiple residuals
                                      rowsField.set(optimizer, 3);
                                      residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                      residualsWeightsField.set(optimizer, new double[]{1.0, 0.5, 0.1});
                                      // Expected: 1^2*1 + 2^2*0.5 + 3^2*0.1 = 1 + 2 + 0.9 = 3.9
                                      assertEquals("Chi-square should be 3.9 for multiple residuals", 3.9, optimizer.getChiSquare(), 0.0001);
                                  }

    @Test
                              public void testGetChiSquareDetectsIndexMutation2() {
                                  // Setup test data - using 2 rows with non-zero residuals
                                  double[] residuals = {2.0, 3.0}; // First residual is 2.0
                                  double[] residualsWeights = {1.0, 1.0}; // Equal weights for simplicity
                                  
                                  // Create a partial mock of the class to test just this method
                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                      @Override
                                      protected VectorialPointValuePair doOptimize() {
                                          return null; // Not needed for this test
                                      }
                                  };
                                  
                                  // Use reflection to set protected fields for testing
                                  try {
                                      Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                      residualsField.setAccessible(true);
                                      residualsField.set(optimizer, residuals);
                                      
                                      Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                      weightsField.setAccessible(true);
                                      weightsField.set(optimizer, residualsWeights);
                                      
                                      Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                      rowsField.setAccessible(true);
                                      rowsField.set(optimizer, residuals.length);
                                  } catch (Exception e) {
                                      fail("Failed to set up test fields via reflection");
                                  }
                                  
                                  // Calculate expected value (2²*1 + 3²*1 = 4 + 9 = 13)
                                  double expected = 13.0;
                                  double actual = optimizer.getChiSquare();
                                  
                                  // Assert the full calculation including first element
                                  assertEquals("Chi-square calculation should include first residual", 
                                               expected, actual, 0.0001);
                                  
                                  // Additional check to ensure the test would fail if first element was skipped
                                  // (which would give just 3²*1 = 9)
                                  assertNotEquals("Test should fail if first residual is skipped", 
                                                 9.0, actual, 0.0001);
                              }

    @Test
                            public void testGetChiSquare_DetectsIndexMinusOneMutant() throws Exception {
                                // Setup test data
                                int testRows = 3;
                                double[] testResiduals = {1.0, 2.0, 3.0};
                                double[] testWeights = {0.5, 1.0, 1.5};
                                double expectedChiSquare = (1.0*1.0*0.5) + (2.0*2.0*1.0) + (3.0*3.0*1.5);
                                
                                // Create instance of the class under test
                                AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                    @Override
                                    protected VectorialPointValuePair doOptimize() {
                                        return null;
                                    }
                                };
                                
                                // Set private fields using reflection
                                Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                rowsField.setAccessible(true);
                                rowsField.set(optimizer, testRows);
                                
                                Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                residualsField.setAccessible(true);
                                residualsField.set(optimizer, testResiduals);
                                
                                Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                residualsWeightsField.setAccessible(true);
                                residualsWeightsField.set(optimizer, testWeights);
                                
                                // Execute and verify
                                double result = optimizer.getChiSquare();
                                assertEquals("Chi-square calculation should be correct", 
                                           expectedChiSquare, result, 0.0001);
                            }

    @Test
                       public void testGetChiSquareDetectsSkippedFirstRow() throws Exception {
                           // Setup test data where first residual makes significant contribution
                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                               @Override
                               protected VectorialPointValuePair doOptimize() {
                                   return null; // dummy implementation
                               }
                           };
                           
                           // Use reflection to set protected fields
                           Class<?> optimizerClass = optimizer.getClass();
                           java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                           rowsField.setAccessible(true);
                           rowsField.set(optimizer, 2);
                           
                           java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                           residualsField.setAccessible(true);
                           residualsField.set(optimizer, new double[]{10.0, 1.0}); // first residual is much larger
                           
                           java.lang.reflect.Field weightsField = optimizerClass.getDeclaredField("residualsWeights");
                           weightsField.setAccessible(true);
                           weightsField.set(optimizer, new double[]{1.0, 1.0}); // equal weights
                           
                           // Calculate expected value (including first row)
                           double expected = 10.0 * 10.0 * 1.0  // first row contribution
                                           + 1.0 * 1.0 * 1.0;    // second row contribution
                           
                           // Test will pass for original (101.0) but fail for mutant (1.0)
                           assertEquals("Chi-square calculation should include first row", 
                                       expected, optimizer.getChiSquare(), 0.0001);
                       }

    @Test
                  public void testGetChiSquareArrayBounds() throws Exception {
                      // Setup test data where rows equals array length
                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                          @Override
                          protected VectorialPointValuePair doOptimize() {
                              return null;
                          }
                      };
                      
                      // Use reflection to set protected fields
                      Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                      java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                      rowsField.setAccessible(true);
                      rowsField.set(optimizer, 2);
                      
                      java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                      residualsField.setAccessible(true);
                      residualsField.set(optimizer, new double[]{1.0, 2.0});
                      
                      java.lang.reflect.Field weightsField = optimizerClass.getDeclaredField("residualsWeights");
                      weightsField.setAccessible(true);
                      weightsField.set(optimizer, new double[]{0.5, 0.5});
                      
                      // Calculate expected chi-square value (only first 2 elements)
                      double expected = (1.0 * 1.0 * 0.5) + (2.0 * 2.0 * 0.5);
                      
                      // Test - should not throw exception and return correct value
                      assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                      
                      // For mutated version, this would throw ArrayIndexOutOfBoundsException
                      // when trying to access index 2 (rows = 2, arrays have length 2)
                  }

    @Test
                  public void testGetChiSquareDetectsResidualSignMutation3() {
                      // Create a test instance by mocking the abstract class
                      AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class, 
                          CALLS_REAL_METHODS);
                      
                      // Set up test data where subtraction and addition would produce different results
                      double[] targetValues = {5.0, 3.0};
                      double[] objective = {2.0, 1.0};
                      double[] weights = {1.0, 1.0}; // Using 1.0 weights for simplicity
                      int rows = 2;
                      
                      // Set the protected fields using reflection
                      try {
                          java.lang.reflect.Field targetField = AbstractLeastSquaresOptimizer.class
                              .getDeclaredField("targetValues");
                          targetField.setAccessible(true);
                          targetField.set(optimizer, targetValues);
                          
                          java.lang.reflect.Field objectiveField = AbstractLeastSquaresOptimizer.class
                              .getDeclaredField("objective");
                          objectiveField.setAccessible(true);
                          objectiveField.set(optimizer, objective);
                          
                          java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class
                              .getDeclaredField("residualsWeights");
                          weightsField.setAccessible(true);
                          weightsField.set(optimizer, weights);
                          
                          java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class
                              .getDeclaredField("rows");
                          rowsField.setAccessible(true);
                          rowsField.set(optimizer, rows);
                      } catch (Exception e) {
                          fail("Failed to set up test fields via reflection");
                      }
                      
                      // Calculate expected value with original behavior (subtraction)
                      double expectedChiSquare = 0;
                      for (int i = 0; i < rows; i++) {
                          double residual = targetValues[i] - objective[i];
                          expectedChiSquare += residual * residual * weights[i];
                      }
                      
                      // Test the method
                      double actualChiSquare = optimizer.getChiSquare();
                      
                      // Assert that the actual result matches the expected (subtraction-based) calculation
                      assertEquals("Chi-square calculation should use subtraction for residuals", 
                          expectedChiSquare, actualChiSquare, 1e-10);
                      
                      // The mutant would produce a different result:
                      // double mutantChiSquare = 0;
                      // for (int i = 0; i < rows; i++) {
                      //     double residual = targetValues[i] + objective[i];
                      //     mutantChiSquare += residual * residual * weights[i];
                      // }
                      // For our test data, mutant would produce (5+2)² + (3+1)² = 49 + 16 = 65
                      // While original produces (5-2)² + (3-1)² = 9 + 4 = 13
                      // So our test would fail if the mutant is present
                  }

    @Test
            public void testGetChiSquareDetectsResidualSignMutation4() {
                // Setup test data that will reveal the mutation
                int rows = 2;
                double[] targetValues = {5.0, 3.0};
                double[] objective = {3.0, 1.0};
                double[] residualsWeights = {-1.0, -1.0}; // Negative weights to make sign matter
                
                // Create concrete subclass implementing doOptimize()
                AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                    @Override
                    protected VectorialPointValuePair doOptimize() {
                        // Dummy implementation for test purposes
                        return null;
                    }
                };
                
                try {
                    // Set protected fields using reflection
                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                    rowsField.setAccessible(true);
                    rowsField.set(optimizer, rows);
                    
                    Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("targetValues");
                    targetField.setAccessible(true);
                    targetField.set(optimizer, targetValues);
                    
                    Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                    objectiveField.setAccessible(true);
                    objectiveField.set(optimizer, objective);
                    
                    Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                    weightsField.setAccessible(true);
                    weightsField.set(optimizer, residualsWeights);
                    
                    // Calculate expected value (original behavior)
                    double expectedChiSquare = 0;
                    for (int i = 0; i < rows; i++) {
                        double residual = targetValues[i] - objective[i];
                        expectedChiSquare += residual * residual * residualsWeights[i];
                    }
                    
                    // Test the method
                    double actualChiSquare = optimizer.getChiSquare();
                    
                    // Verify the result matches expected calculation
                    assertEquals("Chi-square calculation should be sensitive to residual sign with negative weights", 
                               expectedChiSquare, actualChiSquare, 1e-10);
                    
                } catch (Exception e) {
                    fail("Failed to set up test due to reflection error: " + e.getMessage());
                }
            }

    @Test
        public void testGetChiSquare_DetectsResidualZeroingMutant() {
            // Setup test data
            int testRows = 2;
            double[] testResiduals = {1.5, 2.0};  // Non-zero residuals
            double[] testWeights = {1.0, 1.0};    // Simple weights for easy verification
            
            // Create test instance (using anonymous subclass since class is abstract)
            AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                @Override
                protected VectorialPointValuePair doOptimize() {
                    return null; // Not needed for this test
                }
            };
            
            // Set protected fields needed for the test using reflection
            try {
                Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                residualsField.setAccessible(true);
                residualsField.set(optimizer, testResiduals);
                
                Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                weightsField.setAccessible(true);
                weightsField.set(optimizer, testWeights);
                
                Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                rowsField.setAccessible(true);
                rowsField.set(optimizer, testRows);
            } catch (Exception e) {
                fail("Failed to set up test fields via reflection: " + e.getMessage());
            }
            
            // Calculate expected value manually
            double expectedChiSquare = 0;
            for (int i = 0; i < testRows; i++) {
                expectedChiSquare += testResiduals[i] * testResiduals[i] * testWeights[i];
            }
            
            // Test and assert
            double actualChiSquare = optimizer.getChiSquare();
            assertEquals("Chi-square calculation should use actual residuals", 
                         expectedChiSquare, actualChiSquare, 0.0001);
            
            // Additional assertion to specifically catch the mutant
            assertNotEquals("Chi-square should not be zero with non-zero residuals", 
                           0.0, actualChiSquare, 0.0001);
        }

    @Test
       public void testGetChiSquareDetectsResidualAssignmentMutant() {
           // Setup test data
           int testRows = 2;
           double[] testResiduals = {2.0, 3.0};  // Non-zero residuals
           double[] testWeights = {1.0, 1.0};    // Simple weights for easy verification
           
           // Create test instance using reflection since constructor is protected
           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
               @Override
               protected VectorialPointValuePair doOptimize() {
                   return null;  // Not needed for this test
               }
           };
           
           // Set protected fields using reflection
           try {
               Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
               rowsField.setAccessible(true);
               rowsField.set(optimizer, testRows);
               
               Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
               residualsField.setAccessible(true);
               residualsField.set(optimizer, testResiduals);
               
               Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
               weightsField.setAccessible(true);
               weightsField.set(optimizer, testWeights);
           } catch (Exception e) {
               fail("Failed to set up test fields via reflection: " + e.getMessage());
           }
           
           // Calculate expected value (2^2*1 + 3^2*1 = 4 + 9 = 13)
           double expectedChiSquare = 13.0;
           
           // Call method and assert
           double actualChiSquare = optimizer.getChiSquare();
           assertEquals("Chi-square calculation should use correct residuals", 
                       expectedChiSquare, actualChiSquare, 0.0001);
           
           // Additional verification that residuals array wasn't modified
           try {
               double[] currentResiduals = (double[]) AbstractLeastSquaresOptimizer.class
                   .getDeclaredField("residuals")
                   .get(optimizer);
               assertArrayEquals("Residuals array should not be modified", 
                                testResiduals, currentResiduals, 0.0001);
           } catch (Exception e) {
               fail("Failed to verify residuals array: " + e.getMessage());
           }
       }

    @Test
      public void testGetChiSquareDetectsIndexMutation3() {
          // Setup test data
          int testRows = 3;
          int testCols = 2;
          double[] testResiduals = {1.0, 2.0, 3.0};
          double[] testWeights = {0.5, 1.0, 1.5};
          
          // Create instance and set protected fields via reflection
          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
              @Override
              protected VectorialPointValuePair doOptimize() {
                  return null;
              }
          };
          
          // Set protected fields
          try {
              Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
              rowsField.setAccessible(true);
              rowsField.set(optimizer, testRows);
              
              Field colsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cols");
              colsField.setAccessible(true);
              colsField.set(optimizer, testCols);
              
              Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
              residualsField.setAccessible(true);
              residualsField.set(optimizer, testResiduals);
              
              Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
              weightsField.setAccessible(true);
              weightsField.set(optimizer, testWeights);
          } catch (Exception e) {
              fail("Failed to set up test fields via reflection");
          }
          
          // Calculate expected value manually
          double expected = 0.0;
          for (int i = 0; i < testRows; i++) {
              expected += testResiduals[i] * testResiduals[i] * testWeights[i];
          }
          
          // Test and verify
          double actual = optimizer.getChiSquare();
          assertEquals("Chi-square calculation incorrect - mutation not detected", 
                      expected, actual, 0.0001);
          
          // Additional verification that weights were applied to correct residuals
          // This would fail if index was decremented instead of incremented
          assertNotEquals("Mutation not detected - weights may have been applied incorrectly",
                         testResiduals[0] * testResiduals[0] * testWeights[testWeights.length-1],
                         actual, 0.0001);
      }

    @Test
    public void testGetChiSquareDetectsIndexMutation4() throws Exception {
        // Setup test data with 2 rows and different residuals
        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
            // Anonymous subclass for testing protected methods
            @Override
            protected VectorialPointValuePair doOptimize() {
                return null;
            }
        };
        
        // Use reflection to set protected fields
        Class<?> optimizerClass = optimizer.getClass().getSuperclass();
        java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
        rowsField.setAccessible(true);
        rowsField.set(optimizer, 2);
        
        java.lang.reflect.Field colsField = optimizerClass.getDeclaredField("cols");
        colsField.setAccessible(true);
        colsField.set(optimizer, 1); // Important for the mutation case
        
        java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
        residualsField.setAccessible(true);
        residualsField.set(optimizer, new double[]{1.0, 2.0}); // Different residuals
        
        java.lang.reflect.Field weightsField = optimizerClass.getDeclaredField("residualsWeights");
        weightsField.setAccessible(true);
        weightsField.set(optimizer, new double[]{1.0, 1.0}); // Equal weights for simplicity
        
        // Calculate expected chi-square (1^2*1 + 2^2*1 = 1 + 4 = 5)
        double expected = 5.0;
        
        // Actual calculation
        double actual = optimizer.getChiSquare();
        
        // Assertion - mutant would return 2^2*1 + 2^2*1 = 8 (wrong)
        assertEquals("Chi-square calculation should properly accumulate all residuals", 
                    expected, actual, 0.0001);
        
        // Additional test with non-trivial weights
        weightsField.set(optimizer, new double[]{2.0, 3.0});
        expected = (1.0*1.0*2.0) + (2.0*2.0*3.0); // 2 + 12 = 14
        actual = optimizer.getChiSquare();
        assertEquals("Chi-square calculation should properly weight residuals", 
                    expected, actual, 0.0001);
    }


}
