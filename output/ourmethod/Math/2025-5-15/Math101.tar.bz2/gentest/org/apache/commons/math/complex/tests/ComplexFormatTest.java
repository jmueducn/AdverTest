package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.text.FieldPosition;
import java.text.Format;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Locale;
 
public class ComplexFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                              public void testParse_ValidComplexNumber() throws ParseException {
                                                                                                                  ComplexFormat format = new ComplexFormat();
                                                                                                                  Complex result = format.parse("1.23 + 4.56i");
                                                                                                                  
                                                                                                                  assertEquals(1.23, result.getReal(), 0.0001);
                                                                                                                  assertEquals(4.56, result.getImaginary(), 0.0001);
                                                                                                              }

    @Test
                                                                                                              public void testParse_ValidNegativeNumbers() throws ParseException {
                                                                                                                  ComplexFormat format = new ComplexFormat();
                                                                                                                  Complex result = format.parse("-1.23 - 4.56i");
                                                                                                                  
                                                                                                                  assertEquals(-1.23, result.getReal(), 0.0001);
                                                                                                                  assertEquals(-4.56, result.getImaginary(), 0.0001);
                                                                                                              }

    @Test
                                                                                                              public void testParse_RealOnly() throws ParseException {
                                                                                                                  ComplexFormat format = new ComplexFormat();
                                                                                                                  Complex result = format.parse("3.14");
                                                                                                                  
                                                                                                                  assertEquals(3.14, result.getReal(), 0.0001);
                                                                                                                  assertEquals(0.0, result.getImaginary(), 0.0001);
                                                                                                              }

    @Test
                                                                                                              public void testParse_ImaginaryOnly() throws ParseException {
                                                                                                                  ComplexFormat format = new ComplexFormat();
                                                                                                                  Complex result = format.parse("2.71i");
                                                                                                                  
                                                                                                                  assertEquals(0.0, result.getReal(), 0.0001);
                                                                                                                  assertEquals(2.71, result.getImaginary(), 0.0001);
                                                                                                              }

    @Test
                                                                                                              public void testParse_WithDifferentImaginaryCharacter() throws ParseException {
                                                                                                                  ComplexFormat format = new ComplexFormat("j");
                                                                                                                  Complex result = format.parse("1.0 + 2.0j");
                                                                                                                  
                                                                                                                  assertEquals(1.0, result.getReal(), 0.0001);
                                                                                                                  assertEquals(2.0, result.getImaginary(), 0.0001);
                                                                                                              }

    @Test
                                                                                                              public void testParse_WithWhitespace() throws ParseException {
                                                                                                                  ComplexFormat format = new ComplexFormat();
                                                                                                                  Complex result = format.parse("   1.0   +   2.0i   ");
                                                                                                                  
                                                                                                                  assertEquals(1.0, result.getReal(), 0.0001);
                                                                                                                  assertEquals(2.0, result.getImaginary(), 0.0001);
                                                                                                              }

    @Test
                                                                                                              public void testParse_EmptyString() throws ParseException {
                                                                                                                  ComplexFormat format = new ComplexFormat();
                                                                                                                  
                                                                                                                  thrown.expect(ParseException.class);
                                                                                                                  thrown.expectMessage("Unparseable complex number: \"\"");
                                                                                                                  format.parse("");
                                                                                                              }

    @Test
                                                                                                              public void testParse_InvalidFormat() throws ParseException {
                                                                                                                  ComplexFormat format = new ComplexFormat();
                                                                                                                  
                                                                                                                  thrown.expect(ParseException.class);
                                                                                                                  thrown.expectMessage("Unparseable complex number: \"abc\"");
                                                                                                                  format.parse("abc");
                                                                                                              }

    @Test
                                                                                                              public void testParse_InvalidComplexFormat() throws ParseException {
                                                                                                                  ComplexFormat format = new ComplexFormat();
                                                                                                                  
                                                                                                                  thrown.expect(ParseException.class);
                                                                                                                  thrown.expectMessage("Unparseable complex number: \"1.0 + abc\"");
                                                                                                                  format.parse("1.0 + abc");
                                                                                                              }

    @Test
                                                                                                              public void testParse_WithCustomNumberFormat() throws ParseException {
                                                                                                                  NumberFormat format = NumberFormat.getInstance();
                                                                                                                  format.setMaximumFractionDigits(2);
                                                                                                                  ComplexFormat complexFormat = new ComplexFormat(format);
                                                                                                                  
                                                                                                                  Complex result = complexFormat.parse("1,234.56 + 7,890.12i");
                                                                                                                  
                                                                                                                  assertEquals(1234.56, result.getReal(), 0.0001);
                                                                                                                  assertEquals(7890.12, result.getImaginary(), 0.0001);
                                                                                                              }

    @Test
                                                                                                              public void testParse_WithDifferentLocale() throws ParseException {
                                                                                                                  ComplexFormat format = ComplexFormat.getInstance(java.util.Locale.GERMAN);
                                                                                                                  Complex result = format.parse("1,23 + 4,56i");
                                                                                                                  
                                                                                                                  assertEquals(1.23, result.getReal(), 0.0001);
                                                                                                                  assertEquals(4.56, result.getImaginary(), 0.0001);
                                                                                                              }

    @Test
                                                                                                              public void testParse_WithParentheses() throws ParseException {
                                                                                                                  ComplexFormat format = new ComplexFormat();
                                                                                                                  Complex result = format.parse("(1.23 + 4.56i)");
                                                                                                                  
                                                                                                                  assertEquals(1.23, result.getReal(), 0.0001);
                                                                                                                  assertEquals(4.56, result.getImaginary(), 0.0001);
                                                                                                              }

    @Test
                                                                                                      public void testParse_ValidComplexNumberWithPlusSign() {
                                                                                                          // Create mock number format
                                                                                                          NumberFormat mockNumberFormat = mock(NumberFormat.class);
                                                                                                          
                                                                                                          // Create complex format with mock number format
                                                                                                          ComplexFormat complexFormat = new ComplexFormat(mockNumberFormat);
                                                                                                          
                                                                                                          // Set up test
                                                                                                          ParsePosition pos = new ParsePosition(0);
                                                                                                          when(mockNumberFormat.parse("3.5", pos)).thenReturn(3.5);
                                                                                                          when(mockNumberFormat.parse("2.1", pos)).thenReturn(2.1);
                                                                                                          
                                                                                                          // Execute test
                                                                                                          Complex result = complexFormat.parse("3.5 + 2.1i", pos);
                                                                                                          
                                                                                                          // Verify results
                                                                                                          assertEquals(3.5, result.getReal(), 0.0001);
                                                                                                          assertEquals(2.1, result.getImaginary(), 0.0001);
                                                                                                          assertEquals(9, pos.getIndex()); // Verify position after parsing
                                                                                                      }

    @Test
                                                                                                      public void testParse_ValidComplexNumberWithMinusSign() {
                                                                                                          // Create mock NumberFormat
                                                                                                          NumberFormat mockNumberFormat = mock(NumberFormat.class);
                                                                                                          
                                                                                                          // Create ComplexFormat with mock NumberFormat
                                                                                                          ComplexFormat complexFormat = new ComplexFormat(mockNumberFormat);
                                                                                                          
                                                                                                          // Initialize ParsePosition
                                                                                                          ParsePosition pos = new ParsePosition(0);
                                                                                                          
                                                                                                          // Set up mock behavior
                                                                                                          when(mockNumberFormat.parse("1.2", pos)).thenReturn(1.2);
                                                                                                          when(mockNumberFormat.parse("4.3", pos)).thenReturn(4.3);
                                                                                                          
                                                                                                          // Test parsing
                                                                                                          Complex result = complexFormat.parse("1.2 - 4.3i", pos);
                                                                                                          
                                                                                                          // Verify results
                                                                                                          assertEquals(1.2, result.getReal(), 0.0001);
                                                                                                          assertEquals(-4.3, result.getImaginary(), 0.0001);
                                                                                                      }

    @Test
                                                                                                      public void testParse_RealOnlyNumber() {
                                                                                                          // Setup mock objects
                                                                                                          NumberFormat mockNumberFormat = mock(NumberFormat.class);
                                                                                                          ComplexFormat complexFormat = new ComplexFormat(mockNumberFormat);
                                                                                                          
                                                                                                          ParsePosition pos = new ParsePosition(0);
                                                                                                          when(mockNumberFormat.parse("5.6", pos)).thenReturn(5.6);
                                                                                                          
                                                                                                          Complex result = complexFormat.parse("5.6", pos);
                                                                                                          
                                                                                                          assertEquals(5.6, result.getReal(), 0.0001);
                                                                                                          assertEquals(0.0, result.getImaginary(), 0.0001);
                                                                                                      }

    @Test
                                                                                                      public void testParse_InvalidRealNumber() {
                                                                                                          // Setup mock NumberFormat
                                                                                                          NumberFormat mockNumberFormat = mock(NumberFormat.class);
                                                                                                          
                                                                                                          // Create ComplexFormat with mock NumberFormat
                                                                                                          ComplexFormat complexFormat = new ComplexFormat(mockNumberFormat);
                                                                                                          
                                                                                                          // Setup test
                                                                                                          ParsePosition pos = new ParsePosition(0);
                                                                                                          when(mockNumberFormat.parse("abc", pos)).thenReturn(null);
                                                                                                          
                                                                                                          // Execute test
                                                                                                          Complex result = complexFormat.parse("abc + 2i", pos);
                                                                                                          
                                                                                                          // Verify results
                                                                                                          assertNull(result);
                                                                                                          assertEquals(0, pos.getIndex()); // Position should be reset
                                                                                                          assertTrue(pos.getErrorIndex() >= 0); // Error index should be set
                                                                                                      }

    @Test
                                                                                                      public void testParse_InvalidImaginaryNumber() {
                                                                                                          // Setup mocks
                                                                                                          NumberFormat mockNumberFormat = mock(NumberFormat.class);
                                                                                                          ComplexFormat complexFormat = new ComplexFormat(mockNumberFormat);
                                                                                                          
                                                                                                          ParsePosition pos = new ParsePosition(0);
                                                                                                          
                                                                                                          // Mock behavior - valid real number, invalid imaginary number
                                                                                                          when(mockNumberFormat.parse("3.0", pos)).thenReturn(3.0);
                                                                                                          when(mockNumberFormat.parse("xyz", pos)).thenReturn(null);
                                                                                                          
                                                                                                          // Test invalid imaginary number
                                                                                                          Complex result = complexFormat.parse("3.0 + xyzi", pos);
                                                                                                          
                                                                                                          // Verify
                                                                                                          assertNull(result);
                                                                                                          assertEquals(0, pos.getIndex()); // Position should be reset
                                                                                                      }

    @Test
                                                                                                      public void testParse_InvalidSignCharacter() {
                                                                                                          // Setup
                                                                                                          NumberFormat mockNumberFormat = mock(NumberFormat.class);
                                                                                                          ComplexFormat complexFormat = new ComplexFormat(mockNumberFormat);
                                                                                                          ParsePosition pos = new ParsePosition(0);
                                                                                                          
                                                                                                          // Mock behavior
                                                                                                          when(mockNumberFormat.parse("2.5", pos)).thenReturn(2.5);
                                                                                                          
                                                                                                          // Test invalid sign character (* instead of + or -)
                                                                                                          Complex result = complexFormat.parse("2.5 * 3.1i", pos);
                                                                                                          
                                                                                                          // Verify
                                                                                                          assertNull(result);
                                                                                                          assertEquals(0, pos.getIndex()); // Position should be reset
                                                                                                          assertTrue(pos.getErrorIndex() >= 0); // Error index should be set
                                                                                                      }

    @Test
                                                                                                      public void testParse_MissingImaginaryCharacter() {
                                                                                                          // Setup mock NumberFormat
                                                                                                          NumberFormat mockNumberFormat = mock(NumberFormat.class);
                                                                                                          ParsePosition pos = new ParsePosition(0);
                                                                                                          
                                                                                                          // Configure mock behavior
                                                                                                          when(mockNumberFormat.parse("1.0", pos)).thenReturn(1.0);
                                                                                                          when(mockNumberFormat.parse("2.0", pos)).thenReturn(2.0);
                                                                                                          
                                                                                                          // Create ComplexFormat with mock NumberFormat
                                                                                                          ComplexFormat complexFormat = new ComplexFormat(mockNumberFormat);
                                                                                                          
                                                                                                          // Test parsing string without imaginary character
                                                                                                          Complex result = complexFormat.parse("1.0 + 2.0", pos);
                                                                                                          
                                                                                                          // Verify results
                                                                                                          assertNull(result);
                                                                                                          assertEquals(0, pos.getIndex()); // Position should be reset
                                                                                                      }

    @Test
                                                                                                      public void testParse_WithWhitespace1() {
                                                                                                          // Setup mock NumberFormat
                                                                                                          NumberFormat mockNumberFormat = mock(NumberFormat.class);
                                                                                                          
                                                                                                          // Create ComplexFormat with mocked NumberFormat
                                                                                                          ComplexFormat complexFormat = new ComplexFormat(mockNumberFormat);
                                                                                                          
                                                                                                          // Setup parse position
                                                                                                          ParsePosition pos = new ParsePosition(0);
                                                                                                          
                                                                                                          // Mock the number parsing behavior
                                                                                                          when(mockNumberFormat.parse("4.2", pos)).thenReturn(4.2);
                                                                                                          when(mockNumberFormat.parse("1.7", pos)).thenReturn(1.7);
                                                                                                          
                                                                                                          // Test parsing with whitespace
                                                                                                          Complex result = complexFormat.parse("  4.2  -  1.7i  ", pos);
                                                                                                          
                                                                                                          // Verify results
                                                                                                          assertEquals(4.2, result.getReal(), 0.0001);
                                                                                                          assertEquals(-1.7, result.getImaginary(), 0.0001);
                                                                                                      }

    @Test
                                                                                                      public void testParse_EmptyString1() {
                                                                                                          ComplexFormat complexFormat = new ComplexFormat();
                                                                                                          ParsePosition pos = new ParsePosition(0);
                                                                                                          Complex result = complexFormat.parse("", pos);
                                                                                                          
                                                                                                          assertNull(result);
                                                                                                          assertEquals(0, pos.getIndex());
                                                                                                      }

    @Test
                                                                                                      public void testParse_NullString() {
                                                                                                          ComplexFormat complexFormat = new ComplexFormat();
                                                                                                          ParsePosition pos = new ParsePosition(0);
                                                                                                          ExpectedException thrown = ExpectedException.none();
                                                                                                          thrown.expect(NullPointerException.class);
                                                                                                          complexFormat.parse(null, pos);
                                                                                                      }

    @Test
                                                                                                      public void testParse_CustomImaginaryCharacter() {
                                                                                                          // Setup mock NumberFormat
                                                                                                          NumberFormat mockNumberFormat = mock(NumberFormat.class);
                                                                                                          
                                                                                                          // Create ComplexFormat with custom imaginary character "j"
                                                                                                          ComplexFormat complexFormat = new ComplexFormat("j", mockNumberFormat);
                                                                                                          
                                                                                                          // Setup parse position and mock behavior
                                                                                                          ParsePosition pos = new ParsePosition(0);
                                                                                                          when(mockNumberFormat.parse("3.0", pos)).thenReturn(3.0);
                                                                                                          when(mockNumberFormat.parse("4.0", pos)).thenReturn(4.0);
                                                                                                          
                                                                                                          // Test parsing
                                                                                                          Complex result = complexFormat.parse("3.0 + 4.0j", pos);
                                                                                                          
                                                                                                          // Verify results
                                                                                                          assertEquals(3.0, result.getReal(), 0.0001);
                                                                                                          assertEquals(4.0, result.getImaginary(), 0.0001);
                                                                                                      }

    @Test
                                                                                                      public void testParse_InvalidCustomImaginaryCharacter() {
                                                                                                          NumberFormat mockNumberFormat = mock(NumberFormat.class);
                                                                                                          ComplexFormat complexFormat = new ComplexFormat("j", mockNumberFormat);
                                                                                                          ParsePosition pos = new ParsePosition(0);
                                                                                                          
                                                                                                          when(mockNumberFormat.parse("1.5", pos)).thenReturn(1.5);
                                                                                                          when(mockNumberFormat.parse("2.5", pos)).thenReturn(2.5);
                                                                                                          
                                                                                                          Complex result = complexFormat.parse("1.5 + 2.5i", pos);
                                                                                                          
                                                                                                          assertNull(result);
                                                                                                          assertEquals(0, pos.getIndex());
                                                                                                      }

    @Test
                                                                                                  public void testParseWithInvalidSignShouldResetPositionIndex() {
                                                                                                      // Setup
                                                                                                      ComplexFormat format = new ComplexFormat();
                                                                                                      String source = "3.14x2.71i"; // 'x' is invalid sign
                                                                                                      ParsePosition pos = new ParsePosition(0);
                                                                                                      
                                                                                                      // Execute
                                                                                                      Complex result = format.parse(source, pos);
                                                                                                      
                                                                                                      // Verify
                                                                                                      assertNull("Should return null for invalid sign", result);
                                                                                                      assertEquals("Index should be reset to initial position", 0, pos.getIndex());
                                                                                                      assertEquals("Error index should be set to sign position", 4, pos.getErrorIndex());
                                                                                                  }

    @Test
                                                                                             public void testParseResetsPositionIndex() {
                                                                                                 // Setup
                                                                                                 ComplexFormat format = new ComplexFormat();
                                                                                                 String parseableSource = "1.0 + 2.0i";
                                                                                                 String unparseableSource = "invalid";
                                                                                                 
                                                                                                 // Test with parseable string
                                                                                                 ParsePosition pos1 = new ParsePosition(5); // non-zero initial index
                                                                                                 Complex result1 = format.parse(parseableSource, pos1);
                                                                                                 // Verify position was reset and advanced during parsing
                                                                                                 assertNotEquals(0, pos1.getIndex()); // Should have advanced from 0
                                                                                                 
                                                                                                 // Test with unparseable string
                                                                                                 ParsePosition pos2 = new ParsePosition(3); // non-zero initial index
                                                                                                 Complex result2 = format.parse(unparseableSource, pos2);
                                                                                                 // Verify parse failed by checking for null result and position not advanced
                                                                                                 assertNull(result2);
                                                                                                 assertEquals(0, pos2.getIndex()); // Position should be reset to 0
                                                                                                 
                                                                                                 // Additional test to explicitly check position reset
                                                                                                 ParsePosition pos3 = new ParsePosition(10);
                                                                                                 format.parse("3.0 - 4.0i", pos3);
                                                                                                 // If position was properly reset, it shouldn't start counting from 10
                                                                                                 assertTrue(pos3.getIndex() < 10); 
                                                                                             }

    @Test
                                                                                         public void testParseRestoresCorrectPositionOnInvalidImaginaryNumber() {
                                                                                             // Setup
                                                                                             ComplexFormat format = new ComplexFormat();
                                                                                             ParsePosition pos = new ParsePosition(5); // Start parsing at position 5
                                                                                             String source = "   123+abc"; // Valid real part but invalid imaginary
                                                                                             
                                                                                             // Execute
                                                                                             Complex result = format.parse(source, pos);
                                                                                             
                                                                                             // Verify
                                                                                             assertNull("Should return null for invalid input", result);
                                                                                             assertEquals("Position should be restored to initial index", 5, pos.getIndex());
                                                                                             assertNotEquals("Position should not be reset to 0", 0, pos.getIndex());
                                                                                             
                                                                                             // Additional verification for error index
                                                                                             int errorIndex = pos.getErrorIndex();
                                                                                             assertTrue("Error index should point to invalid part", 
                                                                                                        errorIndex > 5 && errorIndex < source.length());
                                                                                         }

    @Test
                                                                                    public void testParseWithNonZeroInitialPositionShouldPreserveErrorIndex() {
                                                                                        // Setup
                                                                                        ComplexFormat format = new ComplexFormat();
                                                                                        String invalidComplex = "invalid";  // Malformed complex number
                                                                                        
                                                                                        // Create a ParsePosition starting at non-zero index
                                                                                        ParsePosition pos = new ParsePosition(5);
                                                                                        
                                                                                        // Act
                                                                                        Complex result = format.parse(invalidComplex, pos);
                                                                                        
                                                                                        // Assert
                                                                                        if (result != null) {
                                                                                            fail("Expected parsing to fail but got: " + result);
                                                                                        }
                                                                                        // Original behavior would preserve initial index (5) in error index
                                                                                        // Mutant would set error index to 0
                                                                                        assertEquals("Error index should be initial position when parse fails", 
                                                                                                    5, pos.getErrorIndex());
                                                                                    }

    @Test
                                                                                public void testSuccessfulParse() throws ParseException {
                                                                                    // Setup
                                                                                    ComplexFormat format = new ComplexFormat();
                                                                                    String validSource = "1.0 + 2.0i";
                                                                                    
                                                                                    // Test with initial position 0
                                                                                    Complex result = format.parse(validSource);
                                                                                    assertNotNull(result);
                                                                                    assertEquals(1.0, result.getReal(), 0.0001);
                                                                                    assertEquals(2.0, result.getImaginary(), 0.0001);
                                                                                    
                                                                                    // Test with non-zero initial position
                                                                                    String sourceWithPrefix = "prefix 1.0 + 2.0i";
                                                                                    ParsePosition pos = new ParsePosition(7); // Start after "prefix "
                                                                                    result = format.parse(sourceWithPrefix, pos);
                                                                                    assertNotNull(result);
                                                                                    assertEquals(1.0, result.getReal(), 0.0001);
                                                                                    assertEquals(2.0, result.getImaginary(), 0.0001);
                                                                                    assertTrue(pos.getIndex() > 7); // Verify position advanced
                                                                                }

    @Test
                                                                                public void testParseInvalidRealNumberResetsToInitialIndex() {
                                                                                    // Setup
                                                                                    ComplexFormat format = new ComplexFormat();
                                                                                    String invalidComplex = "abc+2i"; // invalid real part
                                                                                    ParsePosition pos = new ParsePosition(2); // start parsing at index 2
                                                                                    int initialIndex = pos.getIndex(); // should be 2
                                                                                    
                                                                                    // Execute
                                                                                    Complex result = format.parse(invalidComplex, pos);
                                                                                    
                                                                                    // Verify
                                                                                    assertNull("Should return null for invalid input", result);
                                                                                    assertEquals("ParsePosition should be reset to initial index", 
                                                                                                 initialIndex, pos.getIndex());
                                                                                    assertNotEquals("ParsePosition should not be reset to 0", 
                                                                                                   0, pos.getIndex());
                                                                                    
                                                                                    // Additional verification for error index
                                                                                    assertTrue("Error index should be set", 
                                                                                               pos.getErrorIndex() >= 0);
                                                                                }

    @Test
                                                                               public void testParseWithZeroInitialPositionOnFailure() throws ParseException {
                                                                                   // Setup
                                                                                   ComplexFormat format = new ComplexFormat();
                                                                                   String invalidSource = "invalid";
                                                                                   
                                                                                   try {
                                                                                       format.parse(invalidSource);
                                                                                       fail("Expected ParseException");
                                                                                   } catch (ParseException e) {
                                                                                       // For position 0, both original and mutant behave the same
                                                                                       assertEquals(0, e.getErrorOffset());
                                                                                       assertTrue(e.getMessage().contains("Unparseable complex number"));
                                                                                   }
                                                                               }

    @Test
                                                                       public void testParseWithNonZeroInitialPositionOnFailure() {
                                                                           // Setup
                                                                           ComplexFormat format = new ComplexFormat();
                                                                           String invalidSource = "invalid";
                                                                           int initialPosition = 2;
                                                                           
                                                                           // Create ParsePosition starting at non-zero position
                                                                           ParsePosition pos = new ParsePosition(initialPosition);
                                                                           
                                                                           try {
                                                                               // This should throw an exception since source is invalid
                                                                               format.parse(invalidSource, pos);
                                                                               fail("Expected exception");
                                                                           } catch (Exception e) {
                                                                               // Verify the error index is correct
                                                                               if (e instanceof ParseException) {
                                                                                   assertEquals(initialPosition, ((ParseException)e).getErrorOffset());
                                                                               }
                                                                               
                                                                               // This is the key assertion to catch the mutant:
                                                                               // Original would keep initialPosition (2), mutant would set to 0
                                                                               assertEquals("ParsePosition index should remain at initial position on failure", 
                                                                                           initialPosition, pos.getIndex());
                                                                           }
                                                                       }

    @Test
                                                                   public void testParseInvalidInputPositionReset() {
                                                                       // Setup
                                                                       ComplexFormat format = new ComplexFormat();
                                                                       ParsePosition pos = new ParsePosition(0);
                                                                       
                                                                       // Test 1: Invalid real number (should reset position)
                                                                       String invalidReal = "abc+2i";
                                                                       pos.setIndex(0);
                                                                       Complex result1 = format.parse(invalidReal, pos);
                                                                       assertNull("Should return null for invalid real number", result1);
                                                                       assertEquals("Parse position should be reset to initial index for invalid real", 
                                                                                    0, pos.getIndex());
                                                                       
                                                                       // Test 2: Invalid sign character (should reset position)
                                                                       String invalidSign = "3x4i";
                                                                       pos.setIndex(0);
                                                                       Complex result2 = format.parse(invalidSign, pos);
                                                                       assertNull("Should return null for invalid sign", result2);
                                                                       assertEquals("Parse position should be reset to initial index for invalid sign", 
                                                                                    0, pos.getIndex());
                                                                       
                                                                       // Test 3: Invalid imaginary part (should reset position)
                                                                       String invalidImaginary = "3+abc";
                                                                       pos.setIndex(0);
                                                                       Complex result3 = format.parse(invalidImaginary, pos);
                                                                       assertNull("Should return null for invalid imaginary", result3);
                                                                       assertEquals("Parse position should be reset to initial index for invalid imaginary", 
                                                                                    0, pos.getIndex());
                                                                   }

    @Test
                                                              public void testParseWithInvalidStringShouldSetErrorIndexToZero() {
                                                                  // Setup
                                                                  ComplexFormat format = new ComplexFormat();
                                                                  String invalidComplex = "invalid_complex_string";
                                                                  
                                                                  try {
                                                                      // Exercise
                                                                      format.parse(invalidComplex);
                                                                      fail("Expected ParseException to be thrown");
                                                                  } catch (ParseException e) {
                                                                      // Verify
                                                                      assertEquals("Error index should be 0 for unparseable string", 0, e.getErrorOffset());
                                                                      assertTrue("Exception message should contain unparseable string", 
                                                                                e.getMessage().contains("Unparseable complex number"));
                                                                  }
                                                              }

    @Test
                                                          public void testParseRestoresCorrectPositionOnFailure() {
                                                              // Setup
                                                              ComplexFormat format = new ComplexFormat();
                                                              String source = "invalidComplex"; // Will fail parsing
                                                              ParsePosition pos = new ParsePosition(5); // Start from position 5
                                                              
                                                              // Execute
                                                              Complex result = format.parse(source, pos);
                                                              
                                                              // Verify
                                                              assertNull("Should return null for invalid input", result);
                                                              assertEquals("Position should be restored to initial index", 5, pos.getIndex());
                                                              assertNotEquals("Position should not be reset to 0", 0, pos.getIndex());
                                                          }

    @Test
                                                     public void testParseWithPartialFailureShouldPreserveErrorIndex() {
                                                         // Setup
                                                         ComplexFormat format = new ComplexFormat();
                                                         String invalidComplex = "1.0 + invalid"; // Valid start but invalid format
                                                         
                                                         // Test
                                                         try {
                                                             format.parse(invalidComplex);
                                                             fail("Expected ParseException");
                                                         } catch (java.text.ParseException e) {
                                                             // Verify the error index is not 0 (would be 0 for mutant)
                                                             assertTrue("Error index should reflect parsing progress", 
                                                                       e.getErrorOffset() > 0);
                                                             
                                                             // Additional verification of exception message
                                                             assertTrue("Exception message should contain original string",
                                                                       e.getMessage().contains(invalidComplex));
                                                         }
                                                     }

    @Test
                                                 public void testParseInvalidImaginaryNumberResetsPosition() {
                                                     // Setup
                                                     ComplexFormat format = new ComplexFormat();
                                                     String invalidComplex = "3+abc"; // Valid real but invalid imaginary part
                                                     ParsePosition pos = new ParsePosition(0);
                                                     
                                                     // First parse attempt (should fail)
                                                     Complex result = format.parse(invalidComplex, pos);
                                                     assertNull("Should return null for invalid input", result);
                                                     assertEquals("Parse position should be reset to initial index", 0, pos.getIndex());
                                                     
                                                     // Second parse attempt with valid input (to verify position was properly reset)
                                                     String validComplex = "5+6i";
                                                     result = format.parse(validComplex, pos);
                                                     assertNotNull("Should parse valid complex number", result);
                                                     assertEquals("Real part should be parsed correctly", 5.0, result.getReal(), 0.0001);
                                                     assertEquals("Imaginary part should be parsed correctly", 6.0, result.getImaginary(), 0.0001);
                                                 }

    @Test
                                                public void testParseResetsPosition() throws ParseException {
                                                    // Setup
                                                    ComplexFormat format = new ComplexFormat();
                                                    String validComplex = "1.0 + 2.0i";
                                                    String invalidComplex = "invalid";
                                                    
                                                    // First parse a valid complex number to advance the position
                                                    ParsePosition pos = new ParsePosition(0);
                                                    format.parse(validComplex, pos);
                                                    int advancedPosition = pos.getIndex();
                                                    
                                                    // Now test parsing an invalid string - position should be reset to 0
                                                    pos.setIndex(0); // Manually reset for test
                                                    Complex invalidResult = format.parse(invalidComplex, pos);
                                                    assertNull("Invalid complex should return null", invalidResult);
                                                    // Verify position was reset (original behavior)
                                                    // Mutant would leave position at advancedPosition
                                                    assertEquals("ParsePosition should be reset to 0 for new parse", 
                                                                 0, pos.getIndex());
                                                    
                                                    // Additional check: parse valid after invalid
                                                    Complex result = format.parse(validComplex, pos);
                                                    assertNotNull("Should be able to parse valid after invalid", result);
                                                    assertTrue("Position should advance for valid parse", pos.getIndex() > 0);
                                                }

    @Test
                                            public void testParseWithPositionAtStringLength() throws ParseException {
                                                // Setup
                                                ComplexFormat complexFormat = new ComplexFormat();
                                                String source = "1.0"; // Simple number that will be fully parsed
                                                
                                                // Test parsing
                                                Complex result = complexFormat.parse(source);
                                                
                                                // Verify - if mutation exists, this would throw ParseException
                                                // because the parse position would be at source.length() (3)
                                                // and the mutated condition would fail to handle this case
                                                assertNotNull(result);
                                                assertEquals(1.0, result.getReal(), 0.0001);
                                                assertEquals(0.0, result.getImaginary(), 0.0001);
                                                
                                                // Additional test with explicit parse position
                                                ParsePosition pos = new ParsePosition(0);
                                                Complex result2 = complexFormat.parse(source, pos);
                                                assertNotNull(result2);
                                                assertEquals(source.length(), pos.getIndex()); // Verify full string was parsed
                                            }

    @Test
                                            public void testParseWithImaginaryAtStringEnd() {
                                                // Setup
                                                ComplexFormat format = new ComplexFormat();
                                                ParsePosition pos = new ParsePosition(0);
                                                
                                                // Test case where imaginary part would be exactly at string end
                                                // This should fail in original but might pass in mutant
                                                String source = "1.0 + 2.0"; // Missing imaginary character at end
                                                
                                                // Execute
                                                Complex result = format.parse(source, pos);
                                                
                                                // Verify
                                                assertNull("Should return null for invalid input", result);
                                                assertEquals("Error index should be set", 6, pos.getErrorIndex());
                                                assertEquals("Position should be reset", 0, pos.getIndex());
                                                
                                                // Additional verification for exact boundary case
                                                pos.setIndex(0);
                                                source = "1.0 + 2.0i"; // Valid case for comparison
                                                Complex validResult = format.parse(source, pos);
                                                assertNotNull("Valid input should parse", validResult);
                                            }

    @Test
                                           public void testParseWithInvalidInputShouldResetParsePosition() throws Exception {
                                               // Setup
                                               ComplexFormat format = new ComplexFormat();
                                               String invalidComplex = "invalid_complex_string";
                                               
                                               // Execute and verify exception
                                               try {
                                                   format.parse(invalidComplex);
                                                   fail("Expected ParseException");
                                               } catch (ParseException e) {
                                                   // Expected
                                               }
                                               
                                               // Now test with ParsePosition to verify index reset
                                               ParsePosition pos = new ParsePosition(0);
                                               Complex result = format.parse(invalidComplex, pos);
                                               
                                               // Assertions
                                               assertNull("Result should be null for invalid input", result);
                                               assertEquals("ParsePosition index should be reset to 0 on failure", 
                                                            0, pos.getIndex());
                                               assertNotEquals("ParsePosition error index should be set", 
                                                              -1, pos.getErrorIndex());
                                           }

    @Test
                                           public void testParseInvalidRealNumberPositionReset() {
                                               // Setup
                                               ComplexFormat format = new ComplexFormat();
                                               String invalidInput = "abc+2i"; // Invalid real number
                                               ParsePosition pos = new ParsePosition(0);
                                               
                                               // Execute
                                               Complex result = format.parse(invalidInput, pos);
                                               
                                               // Verify
                                               assertNull("Should return null for invalid input", result);
                                               assertEquals("ParsePosition index should be reset to initial value (0)", 
                                                            0, pos.getIndex());
                                               assertNotEquals("ParsePosition index should not be initial+1 (mutant check)", 
                                                              1, pos.getIndex());
                                           }

    @Test
                                          public void testParseValidComplexNumber() throws ParseException {
                                              // Setup
                                              ComplexFormat format = new ComplexFormat();
                                              String validComplex = "1.0 + 2.0i";  // Valid complex number string
                                              
                                              // Test
                                              Complex result = format.parse(validComplex);
                                              
                                              // Verify
                                              assertNotNull("Should return a Complex object for valid input", result);
                                              assertEquals(1.0, result.getReal(), 0.0001);
                                              assertEquals(2.0, result.getImaginary(), 0.0001);
                                          }

    @Test(expected = ParseException.class)
                                          public void testParseInvalidComplexNumber() throws ParseException {
                                              // Setup
                                              ComplexFormat format = new ComplexFormat();
                                              String invalidComplex = "invalid";  // Invalid complex number string
                                              
                                              // Test - should throw ParseException
                                              format.parse(invalidComplex);
                                          }

    @Test
                                          public void testParseInvalidRealNumberResetsToInitialIndex1() {
                                              // Setup
                                              ComplexFormat format = new ComplexFormat();
                                              String invalidInput = "abc + 2i"; // Invalid real number
                                              ParsePosition pos = new ParsePosition(3); // Start parsing at position 3
                                              
                                              // Execute
                                              Complex result = format.parse(invalidInput, pos);
                                              
                                              // Verify
                                              assertNull("Should return null for invalid input", result);
                                              assertEquals("Parse position should be reset to initial index", 
                                                           3, pos.getIndex());
                                              assertNotEquals("Parse position should not be reset to 0", 
                                                             0, pos.getIndex());
                                          }

    @Test
                                          public void testParseInvalidSignResetsToInitialIndex() {
                                              // Setup
                                              ComplexFormat format = new ComplexFormat();
                                              String invalidInput = "1.23 x 2i"; // Invalid sign character 'x'
                                              ParsePosition pos = new ParsePosition(2); // Start parsing at position 2
                                              
                                              // Execute
                                              Complex result = format.parse(invalidInput, pos);
                                              
                                              // Verify
                                              assertNull("Should return null for invalid sign", result);
                                              assertEquals("Parse position should be reset to initial index", 
                                                           2, pos.getIndex());
                                              assertNotEquals("Parse position should not be reset to 0", 
                                                             0, pos.getIndex());
                                          }

    @Test
                                          public void testParseInvalidImaginaryResetsToInitialIndex() {
                                              // Setup
                                              ComplexFormat format = new ComplexFormat();
                                              String invalidInput = "1.23 + abc"; // Invalid imaginary number
                                              ParsePosition pos = new ParsePosition(1); // Start parsing at position 1
                                              
                                              // Execute
                                              Complex result = format.parse(invalidInput, pos);
                                              
                                              // Verify
                                              assertNull("Should return null for invalid imaginary", result);
                                              assertEquals("Parse position should be reset to initial index", 
                                                           1, pos.getIndex());
                                              assertNotEquals("Parse position should not be reset to 0", 
                                                             0, pos.getIndex());
                                          }

    @Test
                                          public void testParseMissingImaginaryCharResetsToInitialIndex() {
                                              // Setup
                                              ComplexFormat format = new ComplexFormat();
                                              String invalidInput = "1.23 + 2j"; // Wrong imaginary character
                                              ParsePosition pos = new ParsePosition(4); // Start parsing at position 4
                                              
                                              // Execute
                                              Complex result = format.parse(invalidInput, pos);
                                              
                                              // Verify
                                              assertNull("Should return null for missing imaginary char", result);
                                              assertEquals("Parse position should be reset to initial index", 
                                                           4, pos.getIndex());
                                              assertNotEquals("Parse position should not be reset to 0", 
                                                             0, pos.getIndex());
                                          }

    @Test
                                         public void testParseWithInvalidSignSetsCorrectErrorIndex() {
                                             // Setup
                                             ComplexFormat format = new ComplexFormat();
                                             String source = "1.23 x 4.56i"; // 'x' is invalid sign
                                             ParsePosition pos = new ParsePosition(0);
                                             
                                             // Execute
                                             Complex result = format.parse(source, pos);
                                             
                                             // Verify
                                             assertNull("Should return null for invalid sign", result);
                                             assertEquals("Index should be reset to initial position", 0, pos.getIndex());
                                             assertNotEquals("Error index should not be 0", 0, pos.getErrorIndex());
                                             assertEquals("Error index should point to invalid sign position", 
                                                          4, pos.getErrorIndex()); // 'x' is at position 4
                                         }

    @Test(expected = ParseException.class)
                                    public void testParseErrorIndexWhenParsingFails() throws ParseException {
                                        // Setup
                                        ComplexFormat format = new ComplexFormat();
                                        String invalidComplex = "1+2i+3"; // Invalid format that fails parsing after "1+2i"
                                        
                                        // Expected error index is where parsing fails (position 3 in this case)
                                        int expectedErrorIndex = 3;
                                        
                                        try {
                                            format.parse(invalidComplex);
                                            fail("Expected ParseException to be thrown");
                                        } catch (ParseException e) {
                                            // Verify the error index is correctly set to where parsing failed
                                            assertEquals("Error index should point to where parsing failed", 
                                                        expectedErrorIndex, e.getErrorOffset());
                                            throw e; // rethrow to satisfy @Test(expected)
                                        }
                                    }

    @Test
                                public void testParseInvalidInputsShouldReturnNullNotThrowException() {
                                    ComplexFormat format = new ComplexFormat();
                                    ParsePosition pos = new ParsePosition(0);
                                    
                                    // Test case 1: Invalid real number (should return null)
                                    try {
                                        Complex result1 = format.parse("abc+4i", pos);
                                        assertNull("Should return null for invalid real number", result1);
                                    } catch (RuntimeException e) {
                                        fail("Should return null for invalid real number, not throw exception");
                                    }
                                    
                                    // Reset position for next test
                                    pos.setIndex(0);
                                    
                                    // Test case 2: Invalid sign character (should return null)
                                    try {
                                        Complex result2 = format.parse("3x4i", pos);
                                        assertNull("Should return null for invalid sign character", result2);
                                    } catch (RuntimeException e) {
                                        fail("Should return null for invalid sign character, not throw exception");
                                    }
                                    
                                    // Reset position for next test
                                    pos.setIndex(0);
                                    
                                    // Test case 3: Missing imaginary character (should return null)
                                    try {
                                        Complex result3 = format.parse("3+4", pos);
                                        assertNull("Should return null for missing imaginary character", result3);
                                    } catch (RuntimeException e) {
                                        fail("Should return null for missing imaginary character, not throw exception");
                                    }
                                }

    @Test(expected = ParseException.class)
                               public void testParseInvalidStringThrowsParseException() throws ParseException {
                                   ComplexFormat complexFormat = new ComplexFormat();
                                   complexFormat.parse("invalid_complex_string");
                               }

    @Test
                               public void testParseValidStringReturnsComplex() throws ParseException {
                                   // Test normal functionality isn't broken
                                   ComplexFormat complexFormat = new ComplexFormat();
                                   Complex result = complexFormat.parse("1.0 + 2.0i");
                                   assertNotNull(result);
                                   assertEquals(1.0, result.getReal(), 0.0001);
                                   assertEquals(2.0, result.getImaginary(), 0.0001);
                               }

    @Test
                               public void testParseEmptyStringThrowsParseException() throws ParseException {
                                   ComplexFormat complexFormat = new ComplexFormat();
                                   try {
                                       complexFormat.parse("");
                                       fail("Expected ParseException for empty string");
                                   } catch (ParseException e) {
                                       // Expected behavior
                                   }
                               }

    @Test
                               public void testParseWhitespaceStringThrowsParseException() throws ParseException {
                                   ComplexFormat complexFormat = new ComplexFormat();
                                   try {
                                       complexFormat.parse("   ");
                                       fail("Expected ParseException for whitespace string");
                                   } catch (ParseException e) {
                                       // Expected behavior
                                   }
                               }

    @Test
                           public void testParseInvalidInputPositionReset1() {
                               // Setup
                               ComplexFormat format = new ComplexFormat();
                               String source = "invalid+3i";
                               ParsePosition pos = new ParsePosition(5); // Start at non-zero position
                               int initialIndex = pos.getIndex();
                               
                               // Mock dependencies to simulate invalid real number parsing
                               NumberFormat mockFormat = mock(NumberFormat.class);
                               when(mockFormat.parse(anyString(), any(ParsePosition.class))).thenReturn(null);
                               format.setRealFormat(mockFormat);
                               format.setImaginaryFormat(mockFormat);
                               
                               // Execute
                               Complex result = format.parse(source, pos);
                               
                               // Verify
                               assertNull("Should return null for invalid input", result);
                               assertEquals("ParsePosition should be reset to initial index", 
                                            initialIndex, pos.getIndex());
                               assertNotEquals("ParsePosition should not be reset to 0", 
                                              0, pos.getIndex());
                           }

    @Test
                      public void testParseWithNonZeroStartPositionShouldThrowWithCorrectErrorIndex() {
                          // Setup
                          ComplexFormat format = new ComplexFormat();
                          String invalidComplex = "invalid-complex-string";
                          int startPosition = 5;
                          ParsePosition pos = new ParsePosition(startPosition);
                          
                          try {
                              // Exercise
                              format.parse(invalidComplex, pos);
                              fail("Expected NumberFormatException");
                          } catch (NumberFormatException e) {
                              // Verify
                              assertEquals("Error index should match starting position when parsing fails", 
                                          startPosition, pos.getErrorIndex());
                          }
                      }

    @Test
                  public void testParsePositionAfterFailedParse() {
                      // Arrange
                      ComplexFormat complexFormat = new ComplexFormat();
                      String invalidComplexString = "invalid_complex_number";
                      ParsePosition parsePosition = new ParsePosition(0);
                      
                      // Act
                      Complex result = complexFormat.parse(invalidComplexString, parsePosition);
                      
                      // Assert
                      // Original code should keep index at 0, mutated code will increment to 1
                      assertEquals("Parse position should remain at 0 for failed parse", 
                                   0, parsePosition.getIndex());
                      assertNull("Result should be null for failed parse", result);
                  }

    @Test
                  public void testParseInvalidRealNumberPositionReset1() {
                      // Setup
                      ComplexFormat format = new ComplexFormat();
                      String invalidInput = "abc+2i"; // Invalid real number
                      ParsePosition pos = new ParsePosition(0);
                      int initialPosition = pos.getIndex();
                      
                      // Execute
                      Complex result = format.parse(invalidInput, pos);
                      
                      // Verify
                      assertNull("Should return null for invalid input", result);
                      assertEquals("Parse position should be reset to initial index on error", 
                                  initialPosition, pos.getIndex());
                      assertNotEquals("Test should detect mutant by checking position didn't increment", 
                                     initialPosition + 1, pos.getIndex());
                  }

    @Test(expected = ParseException.class)
             public void testParseWithInvalidStringShouldThrowException() throws ParseException {
                 // Arrange
                 ComplexFormat complexFormat = new ComplexFormat();
                 String invalidComplexString = "invalid_complex_number"; // This should fail parsing
                 
                 // Act & Assert
                 // This should throw ParseException in original code, but mutated version won't
                 complexFormat.parse(invalidComplexString);
             }

    @Test
         public void testParsePositionResetOnInvalidImaginaryNumber() {
             // Setup
             ComplexFormat format = new ComplexFormat();
             String source = "prefix 3+invalid"; // Invalid imaginary part
             ParsePosition pos = new ParsePosition(7); // Start parsing after "prefix "
             int initialIndex = pos.getIndex();
             
             // Execute
             Complex result = format.parse(source, pos);
             
             // Verify
             assertNull("Should return null for invalid input", result);
             assertEquals("ParsePosition should be reset to initial index", 
                         initialIndex, pos.getIndex());
             assertNotEquals("ParsePosition should not be reset to 0", 
                            0, pos.getIndex());
         }

    @Test
    public void testParseWithOffsetShouldSetCorrectErrorIndex() {
        // Setup
        ComplexFormat format = new ComplexFormat();
        String invalidComplex = "invalid";
        int startPos = 2; // Start parsing from position 2
        
        // Create a ParsePosition starting at position 2
        ParsePosition pos = new ParsePosition(startPos);
        
        // This should fail to parse since the string is invalid
        format.parse(invalidComplex, pos);
        
        // Verify the error index is set to the initial position (2)
        assertEquals("Error index should be set to initial parse position", 
                   startPos, pos.getErrorIndex());
    }


}
