package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.NonPositiveDefiniteMatrixException;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.SingularMatrixException;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;
 
public class MultivariateNormalDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                       public void testDensity_ValidInput() {
                                           // Setup test data
                                           double[] means = {1.0, 2.0};
                                           double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
                                           MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                                           
                                           // Test point near the mean
                                           double[] vals1 = {1.0, 2.0};
                                           double density1 = dist.density(vals1);
                                           assertTrue(density1 > 0); // Should be positive
                                           
                                           // Test point away from mean
                                           double[] vals2 = {2.0, 3.0};
                                           double density2 = dist.density(vals2);
                                           assertTrue(density2 > 0 && density2 < density1); // Should be less than at mean
                                           
                                           // Test point symmetric around mean
                                           double[] vals3 = {0.0, 1.0};
                                           double density3 = dist.density(vals3);
                                           assertEquals(density2, density3, 1e-10); // Should be equal due to symmetry
                                       }

    @Test
                                       public void testDensity_DimensionMismatch() {
                                           double[] means = {1.0, 2.0, 3.0};
                                           double[][] covariances = {{1.0, 0.5, 0.2}, {0.5, 1.0, 0.3}, {0.2, 0.3, 1.0}};
                                           MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                                           
                                           // Expect exception when input dimension doesn't match
                                           thrown.expect(DimensionMismatchException.class);
                                           thrown.expectMessage("3 != 2");
                                           
                                           double[] wrongDimVals = {1.0, 2.0}; // Should be 3D
                                           dist.density(wrongDimVals);
                                       }

    @Test
                                       public void testDensity_EdgeCases() {
                                           // Test with identity covariance matrix
                                           double[] means = {0.0, 0.0};
                                           double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
                                           MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                                           
                                           // Test at origin
                                           double[] vals1 = {0.0, 0.0};
                                           double expectedDensity = 1.0 / (2 * Math.PI); // For standard 2D normal
                                           assertEquals(expectedDensity, dist.density(vals1), 1e-10);
                                           
                                           // Test with large values (should be very small density)
                                           double[] vals2 = {10.0, 10.0};
                                           double density2 = dist.density(vals2);
                                           assertTrue(density2 > 0 && density2 < 1e-20);
                                       }

    @Test
                                       public void testDensity_SingularCovariance() {
                                           // Test with singular covariance matrix (determinant = 0)
                                           // This should have been caught in constructor, but testing edge case
                                           
                                           double[] means = {1.0, 1.0};
                                           double[][] covariances = {{1.0, 1.0}, {1.0, 1.0}}; // Singular matrix
                                           
                                           thrown.expect(NonPositiveDefiniteMatrixException.class);
                                           MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                                       }

    @Test
                               public void testDensity_WithMockedExponentTerm() throws Exception {
                                   // Setup test data
                                   double[] means = {1.0, 2.0};
                                   double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
                                   MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                                   
                                   // Use reflection to access and modify the private covarianceMatrixDeterminant field
                                   Field determinantField = MultivariateNormalDistribution.class.getDeclaredField("covarianceMatrixDeterminant");
                                   determinantField.setAccessible(true);
                                   determinantField.set(dist, 1.0);
                                   
                                   // Create a spy to verify behavior without mocking private methods
                                   MultivariateNormalDistribution spyDist = spy(dist);
                                   
                                   // Calculate expected value with known components
                                   double[] vals = {1.5, 2.5};
                                   double expected = FastMath.pow(2 * FastMath.PI, -1.0) * 1.0; // dim=2, det=1
                                   
                                   // Since we can't mock the private method, we'll test with the actual implementation
                                   // but we've set up the determinant to be 1.0 to simplify verification
                                   assertEquals(expected, spyDist.density(vals), 1e-10);
                               }

    @Test(expected = DimensionMismatchException.class)
                           public void testDensityWithWrongDimensionShouldThrowException() {
                               // Create a 2D normal distribution
                               double[] means = new double[]{0.0, 0.0};
                               double[][] covariances = new double[][]{{1.0, 0.0}, {0.0, 1.0}};
                               MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                               
                               // Test with input of wrong dimension (3 instead of 2)
                               double[] vals = new double[]{1.0, 2.0, 3.0};
                               dist.density(vals);
                               
                               // Should throw DimensionMismatchException for original code
                               // Mutated code would pass this test incorrectly
                           }

    @Test
                           public void testDensityWithCorrectDimensionShouldNotThrowException() {
                               // Create a 2D normal distribution
                               double[] means = new double[]{0.0, 0.0};
                               double[][] covariances = new double[][]{{1.0, 0.0}, {0.0, 1.0}};
                               MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                               
                               // Test with input of correct dimension (2)
                               double[] vals = new double[]{1.0, 2.0};
                               double density = dist.density(vals);
                               
                               // Verify we get a valid density value (exact value not important for this test)
                               assertTrue(density >= 0.0);
                           }

    @Test
                              public void testDensityThrowsExceptionWhenInputLengthMismatches() {
                                  // Setup: create a distribution with dimension 2
                                  double[] means = {0.0, 0.0};
                                  double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
                                  MultivariateNormalDistribution distribution = 
                                      new MultivariateNormalDistribution(means, covariances);
                                  
                                  // Expect exception when input length doesn't match dimension (2)
                                  thrown.expect(DimensionMismatchException.class);
                                  thrown.expectMessage("2"); // Expected dimension is 2
                                  
                                  // Test with input of length 3 (should throw exception)
                                  double[] invalidVals = {1.0, 2.0, 3.0};
                                  distribution.density(invalidVals);
                              }

    @Test
                              public void testDensityAcceptsCorrectLengthInput() {
                                  // Setup: create a distribution with dimension 2
                                  double[] means = {0.0, 0.0};
                                  double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
                                  MultivariateNormalDistribution distribution = 
                                      new MultivariateNormalDistribution(means, covariances);
                                  
                                  // Test with input of correct length (should not throw exception)
                                  double[] validVals = {1.0, 2.0};
                                  distribution.density(validVals);
                                  
                                  // If we get here, the test passes (no exception thrown)
                              }

    @Test(expected = DimensionMismatchException.class)
                        public void testDensityWithWrongDimensionShouldThrowException1() {
                            // Create input with wrong dimension (3 values for 2D distribution)
                            double[] vals = {1.0, 2.0, 3.0};
                            
                            // Create a 2D distribution
                            double[] means = {0.0, 0.0};
                            double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
                            MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
                            
                            // This should throw DimensionMismatchException in original code
                            // Mutant will return 0.0 instead, causing test to fail
                            distribution.density(vals);
                        }

    @Test
                        public void testDensityWithCorrectDimensionShouldNotThrowException1() {
                            // Create input with correct dimension
                            double[] vals = {1.0, 2.0};
                            
                            // Create distribution with matching dimension (2D)
                            double[] means = {0.0, 0.0};
                            double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
                            MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
                            
                            // This should not throw exception and return a valid density
                            double result = distribution.density(vals);
                            assertTrue("Should return positive density value", result > 0);
                        }

    @Test
                    public void testDensityWithKnownValues() {
                        // Setup test data with known expected results
                        double[] means = {1.0, 2.0};
                        double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
                        double[] vals = {1.5, 2.5};
                        
                        // Create the distribution
                        MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                        
                        // Calculate expected value manually
                        int dim = 2;
                        double covDet = 0.75; // determinant of [[1,0.5],[0.5,1]]
                        double exponentTerm = Math.exp(-0.5 * (0.25*0.25 + 0.25*0.25 - 2*0.5*0.25*0.25)/0.75);
                        double expected = Math.pow(2 * Math.PI, -0.5 * dim) * 
                                         Math.pow(covDet, -0.5) * 
                                         exponentTerm;
                        
                        // Test the density calculation
                        double actual = dist.density(vals);
                        
                        // Verify with delta to account for floating point precision
                        assertEquals(expected, actual, 1e-10);
                        
                        // Additional check: verify the mutant would produce a different result
                        double mutantValue = Math.pow(2 * Math.PI, -0.5 * dim) * 
                                            Math.pow(covDet, 0.5) * 
                                            exponentTerm;
                        assertNotEquals(mutantValue, actual, 1e-10);
                    }

    @Test
                  public void testDensityWithNonUnitCovarianceDetectsMutant() throws Exception {
                      // Setup test with known parameters where determinant != 1
                      double[] means = {0.0, 0.0};
                      double[][] covariances = {{2.0, 0.0}, {0.0, 2.0}}; // determinant = 4
                      MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                      
                      // Test point (should be valid)
                      double[] vals = {0.5, -0.5};
                      
                      // Calculate expected value manually
                      int dim = 2;
                      double expectedPart1 = FastMath.pow(2 * FastMath.PI, -0.5 * dim);
                      double expectedPart2 = FastMath.pow(4.0, -0.5); // Using actual determinant
                      
                      // Use reflection to access private getExponentTerm method
                      Method getExponentTermMethod = MultivariateNormalDistribution.class.getDeclaredMethod("getExponentTerm", double[].class);
                      getExponentTermMethod.setAccessible(true);
                      double exponentTerm = (double) getExponentTermMethod.invoke(dist, vals);
                      
                      double expected = expectedPart1 * expectedPart2 * exponentTerm;
                      
                      // Call method and assert
                      double actual = dist.density(vals);
                      assertEquals("Density calculation should use actual covariance determinant", 
                                  expected, actual, 1e-10);
                  }

    @Test
         public void testDensityDetectsExponentMutant() throws Exception {
             // Setup test data with known covariance matrix determinant
             double[] means = {0.0, 0.0};
             double[][] covariances = {{2.0, 0.0}, {0.0, 2.0}}; // determinant = 4
             MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
             
             // Input values - exact values don't matter much for this test
             double[] vals = {0.5, -0.5};
             
             // Use reflection to get the private getExponentTerm method
             Method getExponentTermMethod = MultivariateNormalDistribution.class
                     .getDeclaredMethod("getExponentTerm", double[].class);
             getExponentTermMethod.setAccessible(true);
             
             // Calculate the actual exponent term using reflection
             double exponentTerm = (double) getExponentTermMethod.invoke(dist, vals);
             
             // Calculate expected value manually using correct formula
             int dim = 2;
             double expected = FastMath.pow(2 * FastMath.PI, -0.5 * dim) * 
                              FastMath.pow(4.0, -0.5) * // 4 is determinant, -0.5 is correct exponent
                              exponentTerm; // actual exponent term
             
             // Get actual value
             double actual = dist.density(vals);
             
             // Assert with delta to account for floating point precision
             assertEquals(expected, actual, 1e-10);
             
             // The mutant would calculate FastMath.pow(4.0, -1.0) which would make actual != expected
         }

    @Test
    public void testDensityDetectsAbsMutant() throws Exception {
        // Setup test data with known values that would make getExponentTerm return negative
        double[] means = {0.0, 0.0};
        double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
        double[] testValues = {1.0, 1.0};
        
        // Create test instance
        MultivariateNormalDistribution distribution = new MultivariateNormalDistribution(means, covariances);
        
        // Calculate expected value without mutation
        double expected = FastMath.pow(2 * FastMath.PI, -0.5 * 2) * 
                         FastMath.pow(1.0, -0.5) * 
                         -0.5; // original exponent term
        
        // Calculate what mutated version would return
        double mutated = FastMath.pow(2 * FastMath.PI, -0.5 * 2) * 
                        FastMath.pow(1.0, -0.5) * 
                        Math.abs(-0.5); // mutated exponent term
        
        // Use reflection to get and modify the private exponent term
        Method getExponentTerm = MultivariateNormalDistribution.class.getDeclaredMethod("getExponentTerm", double[].class);
        getExponentTerm.setAccessible(true);
        
        // Create a spy to verify the method call
        MultivariateNormalDistribution spyDistribution = spy(distribution);
        
        // Mock the private method call using reflection
        when(spyDistribution.getClass().getDeclaredMethod("getExponentTerm", double[].class).invoke(spyDistribution, any(double[].class)))
            .thenReturn(-0.5);
        
        // Get actual result
        double actual = spyDistribution.density(testValues);
        
        // Verify the actual result matches expected (non-mutated) version
        // This assertion will fail if the mutation is present
        assertEquals("Density calculation should not use absolute value of exponent term", 
                    expected, actual, 1e-10);
        
        // Additional verification that our test case is valid
        assertNotEquals("Test case should show difference between original and mutated versions",
                       expected, mutated, 1e-10);
    }


}
