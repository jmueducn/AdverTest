package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class BrentSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                          public void testSolve_ConvergesToRoot() throws Exception {
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                              when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                              when(f.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                              when(f.value(1.75)).thenReturn(0.25);
                                                                                                                                                                              when(f.value(1.625)).thenReturn(-0.125);
                                                                                                                                                                              when(f.value(1.6875)).thenReturn(0.0625);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              double result = solver.solve(1.0, 2.0);
                                                                                                                                                                              
                                                                                                                                                                              // Should converge to approximately 1.6
                                                                                                                                                                              assertEquals(1.6, result, 0.1);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_AlreadyAtRoot() throws Exception {
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.5)).thenReturn(0.0);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              double result = solver.solve(1.5, 2.0);
                                                                                                                                                                              
                                                                                                                                                                              assertEquals(1.5, result, 0.0);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_MinEqualsMax() throws Exception {
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.0)).thenReturn(0.0);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              double result = solver.solve(1.0, 1.0);
                                                                                                                                                                              
                                                                                                                                                                              assertEquals(1.0, result, 0.0);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_WithInitialGuess() throws Exception {
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                              when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                              when(f.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                              when(f.value(1.75)).thenReturn(0.25);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                              
                                                                                                                                                                              assertEquals(1.6, result, 0.1);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_WithFunctionParameter() throws Exception {
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                              when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                              when(f.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                              when(f.value(1.75)).thenReturn(0.25);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver();
                                                                                                                                                                              double result = solver.solve(f, 1.0, 2.0);
                                                                                                                                                                              
                                                                                                                                                                              assertEquals(1.6, result, 0.1);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_WithFunctionParameterAndInitialGuess() throws Exception {
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                              when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                              when(f.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                              when(f.value(1.75)).thenReturn(0.25);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver();
                                                                                                                                                                              double result = solver.solve(f, 1.0, 2.0, 1.5);
                                                                                                                                                                              
                                                                                                                                                                              assertEquals(1.6, result, 0.1);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_RootBetweenMinAndInitial() throws Exception {
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                              when(f.value(1.5)).thenReturn(0.5);
                                                                                                                                                                              when(f.value(1.25)).thenReturn(-0.25);
                                                                                                                                                                              when(f.value(1.375)).thenReturn(0.125);
                                                                                                                                                                              when(f.value(1.3125)).thenReturn(-0.0625);
                                                                                                                                                                              when(f.value(1.34375)).thenReturn(0.03125);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                              
                                                                                                                                                                              // Should converge to root between 1.0 and 1.5
                                                                                                                                                                              assertTrue(result > 1.0 && result < 1.5);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_RootBetweenInitialAndMax() throws Exception {
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                              when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                              when(f.value(1.75)).thenReturn(-0.25);
                                                                                                                                                                              when(f.value(1.875)).thenReturn(0.375);
                                                                                                                                                                              when(f.value(1.8125)).thenReturn(0.0625);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                              
                                                                                                                                                                              // Should converge to root between 1.5 and 2.0
                                                                                                                                                                              assertTrue(result > 1.5 && result < 2.0);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_ConvergesWithinTolerance() throws Exception {
                                                                                                                                                                              // Setup mock function that crosses zero at x=2.0
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                              when(f.value(2.0)).thenReturn(0.0);
                                                                                                                                                                              when(f.value(3.0)).thenReturn(1.0);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              double result = solver.solve(f, 1.0, 3.0);
                                                                                                                                                                              
                                                                                                                                                                              assertEquals(2.0, result, 1e-6);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_ConvergesWithFunctionValueAccuracy() throws Exception {
                                                                                                                                                                              // Setup mock function with very small value at x=1.5
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.0)).thenReturn(-1e-8);
                                                                                                                                                                              when(f.value(1.5)).thenReturn(1e-10);  // Below functionValueAccuracy
                                                                                                                                                                              when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              double result = solver.solve(f, 1.0, 2.0);
                                                                                                                                                                              
                                                                                                                                                                              assertEquals(1.5, result, 1e-6);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_UsesBisectionWhenProgressIsSlow() throws Exception {
                                                                                                                                                                              // Setup mock function that would cause slow progress
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(0.0)).thenReturn(-1.0);
                                                                                                                                                                              when(f.value(0.5)).thenReturn(-0.9);
                                                                                                                                                                              when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              double result = solver.solve(f, 0.0, 1.0);
                                                                                                                                                                              
                                                                                                                                                                              // Should converge somewhere between 0.5 and 1.0
                                                                                                                                                                              assertTrue(result > 0.5 && result < 1.0);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_WithLinearInterpolation() throws Exception {
                                                                                                                                                                              // Setup case where x0 == x2 (linear interpolation case)
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                              when(f.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                              when(f.value(2.0)).thenReturn(0.0);
                                                                                                                                                                              when(f.value(2.5)).thenReturn(0.5);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              double result = solver.solve(f, 1.0, 2.5);
                                                                                                                                                                              
                                                                                                                                                                              assertEquals(2.0, result, 1e-6);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_WithInverseQuadraticInterpolation() throws Exception {
                                                                                                                                                                              // Setup case for inverse quadratic interpolation
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(0.0)).thenReturn(-1.0);
                                                                                                                                                                              when(f.value(0.5)).thenReturn(-0.5);
                                                                                                                                                                              when(f.value(1.0)).thenReturn(0.25);
                                                                                                                                                                              when(f.value(1.5)).thenReturn(1.0);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              double result = solver.solve(f, 0.0, 1.5);
                                                                                                                                                                              
                                                                                                                                                                              // Should find root between 0.5 and 1.0
                                                                                                                                                                              assertTrue(result > 0.5 && result < 1.0);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_WithVerySmallInterval() throws Exception {
                                                                                                                                                                              // Test with very small interval
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.999999)).thenReturn(-1e-10);
                                                                                                                                                                              when(f.value(2.000001)).thenReturn(1e-10);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              double result = solver.solve(f, 1.999999, 2.000001);
                                                                                                                                                                              
                                                                                                                                                                              assertEquals(2.0, result, 1e-6);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testSolve_WithRootAtEndpoint() throws Exception {
                                                                                                                                                                              // Test when root is exactly at one endpoint
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.0)).thenReturn(0.0);
                                                                                                                                                                              when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                              
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              double result = solver.solve(f, 1.0, 2.0);
                                                                                                                                                                              
                                                                                                                                                                              assertEquals(1.0, result, 0.0);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                  public void testSolve_InitialGuessIsRoot() throws Exception {
                                                                                                                                                                      // Define accuracy constant
                                                                                                                                                                      final double DEFAULT_ACCURACY = 1E-6;
                                                                                                                                                                      
                                                                                                                                                                      // Mock the function to return 0.0 at x=1.5 (root)
                                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                      when(f.value(1.5)).thenReturn(0.0);
                                                                                                                                                                      
                                                                                                                                                                      // Create solver with mocked function
                                                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                      
                                                                                                                                                                      // Solve with initial guess that is already a root
                                                                                                                                                                      double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                      
                                                                                                                                                                      // Verify the result is the initial guess (root)
                                                                                                                                                                      assertEquals(1.5, result, DEFAULT_ACCURACY);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testSolve_MinIsRoot() throws Exception {
                                                                                                                                                                      // Define test constants
                                                                                                                                                                      final double DEFAULT_ACCURACY = 1.0e-6;
                                                                                                                                                                      
                                                                                                                                                                      // Mock the function
                                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                      when(f.value(1.0)).thenReturn(0.0);
                                                                                                                                                                      when(f.value(1.5)).thenReturn(0.5);
                                                                                                                                                                      
                                                                                                                                                                      // Create solver and test
                                                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                      double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                      
                                                                                                                                                                      // Verify result
                                                                                                                                                                      assertEquals(1.0, result, DEFAULT_ACCURACY);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testSolve_MaxIsRoot() throws Exception {
                                                                                                                                                                      // Define accuracy constant
                                                                                                                                                                      final double DEFAULT_ACCURACY = 1E-6;
                                                                                                                                                                      
                                                                                                                                                                      // Mock the function
                                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                      when(f.value(2.0)).thenReturn(0.0);
                                                                                                                                                                      when(f.value(1.5)).thenReturn(0.5);
                                                                                                                                                                      
                                                                                                                                                                      // Create solver with default constructor
                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                      solver.setFunctionValueAccuracy(DEFAULT_ACCURACY);
                                                                                                                                                                      
                                                                                                                                                                      // Solve and verify
                                                                                                                                                                      double result = solver.solve(f, 1.0, 2.0, 1.5);
                                                                                                                                                                      assertEquals(2.0, result, DEFAULT_ACCURACY);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testSolve_WithDefaultConstructor() throws Exception {
                                                                                                                                                                      // Define test constants
                                                                                                                                                                      final double DEFAULT_ACCURACY = 1.0e-6;
                                                                                                                                                                      
                                                                                                                                                                      // Mock the function
                                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                      when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                      when(f.value(1.5)).thenReturn(0.5);
                                                                                                                                                                      when(f.value(1.25)).thenReturn(-0.5);
                                                                                                                                                                      when(f.value(1.375)).thenReturn(0.0);
                                                                                                                                                                      
                                                                                                                                                                      // Create solver and test
                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                      double result = solver.solve(f, 1.0, 1.5);
                                                                                                                                                                      
                                                                                                                                                                      // Verify result
                                                                                                                                                                      assertEquals(1.375, result, DEFAULT_ACCURACY);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testSolve_WithFunctionConstructor() throws Exception {
                                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                      when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                      when(f.value(1.5)).thenReturn(0.5);
                                                                                                                                                                      when(f.value(1.25)).thenReturn(-0.5);
                                                                                                                                                                      when(f.value(1.375)).thenReturn(0.0);
                                                                                                                                                                      
                                                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                      double result = solver.solve(1.0, 1.5);
                                                                                                                                                                      
                                                                                                                                                                      assertEquals(1.375, result, 1E-6);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testSolve_BracketingRoot() throws Exception {
                                                                                                                                                                      // Create mock function
                                                                                                                                                                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                      // Set up mock behavior
                                                                                                                                                                      when(mockFunction.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                      when(mockFunction.value(4.0)).thenReturn(2.0);
                                                                                                                                                                      
                                                                                                                                                                      // Create solver instance
                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                      
                                                                                                                                                                      // Test the solve method
                                                                                                                                                                      double result = solver.solve(mockFunction, 1.0, 4.0);
                                                                                                                                                                      
                                                                                                                                                                      // Verify the result is within the interval
                                                                                                                                                                      assertTrue(result >= 1.0 && result <= 4.0);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testSolve_MinIsRoot1() throws Exception {
                                                                                                                                                                      // Define test constants
                                                                                                                                                                      final double EPSILON = 1e-6;
                                                                                                                                                                      
                                                                                                                                                                      // Create mock function
                                                                                                                                                                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                      when(mockFunction.value(2.0)).thenReturn(0.0);
                                                                                                                                                                      when(mockFunction.value(5.0)).thenReturn(3.0);
                                                                                                                                                                      
                                                                                                                                                                      // Create solver instance
                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                      
                                                                                                                                                                      // Test case where min is exactly the root (yMin == 0)
                                                                                                                                                                      double result = solver.solve(mockFunction, 2.0, 5.0);
                                                                                                                                                                      assertEquals(2.0, result, EPSILON);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testSolve_MaxIsRoot1() throws Exception {
                                                                                                                                                                      // Define test constants
                                                                                                                                                                      final double EPSILON = 1e-6;
                                                                                                                                                                      
                                                                                                                                                                      // Create mock function
                                                                                                                                                                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                      when(mockFunction.value(1.0)).thenReturn(-2.0);
                                                                                                                                                                      when(mockFunction.value(3.0)).thenReturn(0.0);
                                                                                                                                                                      
                                                                                                                                                                      // Create solver instance
                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                      
                                                                                                                                                                      // Test case where max is exactly the root (yMax == 0)
                                                                                                                                                                      double result = solver.solve(mockFunction, 1.0, 3.0);
                                                                                                                                                                      assertEquals(3.0, result, EPSILON);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testSolve_CloseToZeroAtMin() throws Exception {
                                                                                                                                                                      // Define test constants
                                                                                                                                                                      final double EPSILON = 1e-10;
                                                                                                                                                                      
                                                                                                                                                                      // Create mock function
                                                                                                                                                                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                      
                                                                                                                                                                      // Create solver instance
                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                      
                                                                                                                                                                      // Set up mock behavior
                                                                                                                                                                      when(mockFunction.value(1.0)).thenReturn(1e-7); // within default accuracy
                                                                                                                                                                      when(mockFunction.value(3.0)).thenReturn(2.0);
                                                                                                                                                                      
                                                                                                                                                                      // Test the solver
                                                                                                                                                                      double result = solver.solve(mockFunction, 1.0, 3.0);
                                                                                                                                                                      
                                                                                                                                                                      // Verify result
                                                                                                                                                                      assertEquals(1.0, result, EPSILON);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testSolve_CloseToZeroAtMax() throws Exception {
                                                                                                                                                                      // Define test constants
                                                                                                                                                                      final double EPSILON = 1e-6;
                                                                                                                                                                      
                                                                                                                                                                      // Create mock function
                                                                                                                                                                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                      
                                                                                                                                                                      // Setup solver with default accuracy (1e-6)
                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                      
                                                                                                                                                                      // Configure mock behavior
                                                                                                                                                                      when(mockFunction.value(1.0)).thenReturn(-2.0);
                                                                                                                                                                      when(mockFunction.value(3.0)).thenReturn(-1e-7); // within default accuracy
                                                                                                                                                                      
                                                                                                                                                                      // Test and verify
                                                                                                                                                                      double result = solver.solve(mockFunction, 1.0, 3.0);
                                                                                                                                                                      assertEquals(3.0, result, EPSILON);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testSolve_InvalidInterval() throws Exception {
                                                                                                                                                                      // Setup
                                                                                                                                                                      org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                      org.apache.commons.math.analysis.solvers.BrentSolver solver = new org.apache.commons.math.analysis.solvers.BrentSolver();
                                                                                                                                                                      org.apache.commons.math.analysis.UnivariateRealFunction mockFunction = new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                                                                                                                          public double value(double x) {
                                                                                                                                                                              return x;
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      // Test case where min > max
                                                                                                                                                                      exception.expect(IllegalArgumentException.class);
                                                                                                                                                                      solver.solve(mockFunction, 5.0, 1.0);
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testSolve_EqualEndpoints() throws Exception {
                                                                                                                                                                      // Define test constants
                                                                                                                                                                      final double EPSILON = 1e-6;
                                                                                                                                                                      
                                                                                                                                                                      // Create mock function
                                                                                                                                                                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                      when(mockFunction.value(2.0)).thenReturn(0.0);
                                                                                                                                                                      
                                                                                                                                                                      // Create solver instance
                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                      
                                                                                                                                                                      // Test case where min == max and it's a root
                                                                                                                                                                      double result = solver.solve(mockFunction, 2.0, 2.0);
                                                                                                                                                                      assertEquals(2.0, result, EPSILON);
                                                                                                                                                                  }

    @Test(expected = MaxIterationsExceededException.class)
                                                                                                                                                              public void testSolve_ThrowsExceptionWhenMaxIterationsExceeded() throws Exception {
                                                                                                                                                                  // Setup oscillating function that won't converge
                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                  when(f.value(anyDouble())).thenReturn(1.0);  // Never crosses zero
                                                                                                                                                                  
                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                  solver.solve(0.0, 1.0);
                                                                                                                                                              }

    @Test
                                                                                                                                                          public void testSolve_NonBracketingInterval() throws Exception {
                                                                                                                                                              // Set up ExpectedException rule
                                                                                                                                                              ExpectedException exception = ExpectedException.none();
                                                                                                                                                              
                                                                                                                                                              // Set up mock function
                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                              when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                              when(f.value(2.0)).thenReturn(2.0);
                                                                                                                                                              
                                                                                                                                                              // Create solver
                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                              
                                                                                                                                                              // Get private message field via reflection
                                                                                                                                                              Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                                                                                                                                              field.setAccessible(true);
                                                                                                                                                              String expectedMessage = (String) field.get(null);
                                                                                                                                                              
                                                                                                                                                              // Set up expected exception
                                                                                                                                                              exception.expect(IllegalArgumentException.class);
                                                                                                                                                              exception.expectMessage(expectedMessage);
                                                                                                                                                              
                                                                                                                                                              // Test the method
                                                                                                                                                              solver.solve(1.0, 2.0);
                                                                                                                                                          }

    @Test
                                                                                                                                                          public void testSolve_NonBracketingInterval1() throws Exception {
                                                                                                                                                              // Mock the function
                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                              when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                              when(f.value(1.5)).thenReturn(0.5);
                                                                                                                                                              when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                              
                                                                                                                                                              // Get the private message field via reflection
                                                                                                                                                              Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                                                                                                                                              field.setAccessible(true);
                                                                                                                                                              String nonBracketingMessage = (String) field.get(null);
                                                                                                                                                              
                                                                                                                                                              // Set up expected exception
                                                                                                                                                              try {
                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                  solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                  fail("Expected IllegalArgumentException");
                                                                                                                                                              } catch (IllegalArgumentException e) {
                                                                                                                                                                  assertEquals(nonBracketingMessage, e.getMessage());
                                                                                                                                                              }
                                                                                                                                                          }

    @Test
                                                                                                                                                          public void testSolve_EqualEndpointsNotRoot() throws Exception {
                                                                                                                                                              // Test case where min == max but not a root
                                                                                                                                                              org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                              UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                              when(mockFunction.value(2.0)).thenReturn(1.0);
                                                                                                                                                              
                                                                                                                                                              BrentSolver solver = new BrentSolver();
                                                                                                                                                              exception.expect(IllegalArgumentException.class);
                                                                                                                                                              solver.solve(mockFunction, 2.0, 2.0);
                                                                                                                                                          }

    @Test
                                                                                                                                                      public void testSolve_WithFunctionParameterAndInvalidInterval() throws Exception {
                                                                                                                                                          // Setup mock function
                                                                                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                          when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                          when(f.value(2.0)).thenReturn(2.0);
                                                                                                                                                          
                                                                                                                                                          // Create solver with mock function
                                                                                                                                                          BrentSolver solver = new BrentSolver(f);
                                                                                                                                                          
                                                                                                                                                          // Get expected error message via reflection
                                                                                                                                                          Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                                                                                                                                          field.setAccessible(true);
                                                                                                                                                          String expectedMessage = (String) field.get(solver);
                                                                                                                                                          
                                                                                                                                                          // Test the solve method with invalid interval
                                                                                                                                                          try {
                                                                                                                                                              solver.solve(1.0, 2.0);
                                                                                                                                                              fail("Expected IllegalArgumentException");
                                                                                                                                                          } catch (IllegalArgumentException e) {
                                                                                                                                                              assertEquals(expectedMessage, e.getMessage());
                                                                                                                                                          }
                                                                                                                                                      }

    @Test
                                                                                                                                                      public void testSolve_NonBracketingInterval2() throws Exception {
                                                                                                                                                          // Setup
                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                          
                                                                                                                                                          // Test case where interval doesn't bracket a root (same signs)
                                                                                                                                                          when(mockFunction.value(1.0)).thenReturn(2.0);
                                                                                                                                                          when(mockFunction.value(3.0)).thenReturn(4.0);
                                                                                                                                                          
                                                                                                                                                          // Get private NON_BRACKETING_MESSAGE field via reflection
                                                                                                                                                          Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                                                                                                                                          field.setAccessible(true);
                                                                                                                                                          String nonBracketingMessage = (String) field.get(solver);
                                                                                                                                                          
                                                                                                                                                          // Expected exception
                                                                                                                                                          ExpectedException exception = ExpectedException.none();
                                                                                                                                                          exception.expect(IllegalArgumentException.class);
                                                                                                                                                          exception.expectMessage(nonBracketingMessage);
                                                                                                                                                          
                                                                                                                                                          // Test
                                                                                                                                                          solver.solve(mockFunction, 1.0, 3.0);
                                                                                                                                                      }

    @Test
                                                                                                                                                  public void testSolve_MinMax_BasicCase() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                      when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                      when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                      
                                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                                      double result = solver.solve(1.0, 2.0);
                                                                                                                                                      
                                                                                                                                                      // Should find root between 1 and 2
                                                                                                                                                      assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testSolve_MinMaxInitial_ValidRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                      when(f.value(0.0)).thenReturn(-1.0);
                                                                                                                                                      when(f.value(1.0)).thenReturn(0.5);
                                                                                                                                                      when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                      
                                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                                      double result = solver.solve(0.0, 2.0, 1.0);
                                                                                                                                                      
                                                                                                                                                      // Should find root between 0 and 2
                                                                                                                                                      assertTrue(result >= 0.0 && result <= 2.0);
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testSolve_WithFunctionParameter1() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                      when(f.value(-1.0)).thenReturn(-2.0);
                                                                                                                                                      when(f.value(1.0)).thenReturn(2.0);
                                                                                                                                                      
                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                      double result = solver.solve(f, -1.0, 1.0);
                                                                                                                                                      
                                                                                                                                                      // Should find root between -1 and 1
                                                                                                                                                      assertTrue(result >= -1.0 && result <= 1.0);
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testSolve_WithFunctionAndInitial() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                      when(f.value(-2.0)).thenReturn(-1.0);
                                                                                                                                                      when(f.value(0.0)).thenReturn(0.5);
                                                                                                                                                      when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                      
                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                      double result = solver.solve(f, -2.0, 2.0, 0.0);
                                                                                                                                                      
                                                                                                                                                      // Should find root between -2 and 2
                                                                                                                                                      assertTrue(result >= -2.0 && result <= 2.0);
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testSolve_MinEqualsMax1() {
                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                      try {
                                                                                                                                                          when(f.value(1.0)).thenReturn(0.0); // Exact root
                                                                                                                                                          
                                                                                                                                                          BrentSolver solver = new BrentSolver(f);
                                                                                                                                                          double result = solver.solve(1.0, 1.0);
                                                                                                                                                          
                                                                                                                                                          assertEquals(1.0, result, 0.0001);
                                                                                                                                                      } catch (FunctionEvaluationException e) {
                                                                                                                                                          fail("Unexpected FunctionEvaluationException: " + e.getMessage());
                                                                                                                                                      } catch (MaxIterationsExceededException e) {
                                                                                                                                                          fail("Unexpected MaxIterationsExceededException: " + e.getMessage());
                                                                                                                                                      }
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testSolve_VerySmallFunctionValues() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                      when(f.value(1.0)).thenReturn(-1e-10);
                                                                                                                                                      when(f.value(2.0)).thenReturn(1e-10);
                                                                                                                                                      
                                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                                      double result = solver.solve(1.0, 2.0);
                                                                                                                                                      
                                                                                                                                                      assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testSolve_ReversedMinMax() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                      when(f.value(2.0)).thenReturn(-1.0);
                                                                                                                                                      when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                      
                                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                                      double result = solver.solve(2.0, 1.0);
                                                                                                                                                      
                                                                                                                                                      assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testSolve_NonBracketing_ThrowsException() {
                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                      try {
                                                                                                                                                          when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                          when(f.value(2.0)).thenReturn(2.0);
                                                                                                                                                      } catch (FunctionEvaluationException e) {
                                                                                                                                                          fail("Unexpected FunctionEvaluationException");
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                      
                                                                                                                                                      try {
                                                                                                                                                          Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                                                                                                                                          field.setAccessible(true);
                                                                                                                                                          String message = (String) field.get(null);
                                                                                                                                                          
                                                                                                                                                          try {
                                                                                                                                                              solver.solve(f, 1.0, 2.0);
                                                                                                                                                              fail("Expected IllegalArgumentException");
                                                                                                                                                          } catch (IllegalArgumentException e) {
                                                                                                                                                              assertEquals(message, e.getMessage());
                                                                                                                                                          }
                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                          fail("Failed to access NON_BRACKETING_MESSAGE");
                                                                                                                                                      }
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testSolveClearsPreviousResult() throws Exception {
                                                                                                                                                      // Setup
                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                      when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                      when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                      when(f.value(1.5)).thenReturn(0.0);
                                                                                                                                                      
                                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                                      
                                                                                                                                                      // First solve operation
                                                                                                                                                      double firstResult = solver.solve(f, 1.0, 2.0, 1.5);
                                                                                                                                                      assertEquals(1.5, firstResult, 0.0001);
                                                                                                                                                      
                                                                                                                                                      // Change function behavior for second test
                                                                                                                                                      when(f.value(3.0)).thenReturn(-1.0);
                                                                                                                                                      when(f.value(4.0)).thenReturn(1.0);
                                                                                                                                                      when(f.value(3.5)).thenReturn(0.0);
                                                                                                                                                      
                                                                                                                                                      // Second solve operation with different parameters
                                                                                                                                                      double secondResult = solver.solve(f, 3.0, 4.0, 3.5);
                                                                                                                                                      
                                                                                                                                                      // Verify the second result is correct and not affected by first operation
                                                                                                                                                      assertEquals(3.5, secondResult, 0.0001);
                                                                                                                                                      
                                                                                                                                                      // If clearResult() was commented out, the second solve might be affected by 
                                                                                                                                                      // residual state from the first solve, causing this assertion to fail
                                                                                                                                                  }

    @Test
                                                                                                                                              public void testSolveWithoutClearResultShouldNotUseStaleResults() throws Exception {
                                                                                                                                                  // Create a mock function that returns different values on subsequent calls
                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                  when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                  when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                  when(f.value(3.0)).thenReturn(-1.0);
                                                                                                                                                  when(f.value(4.0)).thenReturn(1.0);
                                                                                                                                                  
                                                                                                                                                  // Create solver with the mock function
                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                  
                                                                                                                                                  // First call - should work normally
                                                                                                                                                  double firstResult = solver.solve(1.0, 2.0);
                                                                                                                                                  assertEquals(1.5, firstResult, 0.0001); // Expected approximate root
                                                                                                                                                  
                                                                                                                                                  // Second call with different interval - should not be affected by first call
                                                                                                                                                  double secondResult = solver.solve(3.0, 4.0);
                                                                                                                                                  assertEquals(3.5, secondResult, 0.0001); // Expected approximate root
                                                                                                                                                  
                                                                                                                                                  // Verify the mock was called correctly for both intervals
                                                                                                                                                  verify(f).value(1.0);
                                                                                                                                                  verify(f).value(2.0);
                                                                                                                                                  verify(f).value(3.0);
                                                                                                                                                  verify(f).value(4.0);
                                                                                                                                                  
                                                                                                                                                  // If clearResult() was commented out, the second solve might:
                                                                                                                                                  // 1. Use stale internal state from first solve
                                                                                                                                                  // 2. Not properly reset function evaluations
                                                                                                                                                  // 3. Return incorrect result based on previous computation
                                                                                                                                              }

    @Test
                                                                                                                                             public void testClearResultIsCalled() throws Exception {
                                                                                                                                                 // Create a mock function that returns known values
                                                                                                                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                 when(f.value(anyDouble())).thenReturn(1.0, -1.0); // First call returns 1.0, second returns -1.0
                                                                                                                                                 
                                                                                                                                                 // Create solver
                                                                                                                                                 BrentSolver solver = new BrentSolver(f);
                                                                                                                                                 
                                                                                                                                                 // Call solve - should clear any previous result
                                                                                                                                                 double result = solver.solve(0.0, 2.0, 1.0);
                                                                                                                                                 
                                                                                                                                                 // Verify that the result is computed properly (not a dummy value)
                                                                                                                                                 // Since we mocked f to return 1.0 and -1.0 for bracketing,
                                                                                                                                                 // the solver should find a root between them
                                                                                                                                                 assertTrue(result >= 0.0 && result <= 2.0);
                                                                                                                                                 
                                                                                                                                                 // Verify the function was called as expected
                                                                                                                                                 verify(f, atLeastOnce()).value(anyDouble());
                                                                                                                                             }

    @Test
                                                                                                                                         public void testSolveClearsPreviousResult1() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                             // Create mock function that returns different values for different inputs
                                                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                             when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                             when(f.value(2.0)).thenReturn(1.0);  // root at x=1.5 for first function
                                                                                                                                             when(f.value(3.0)).thenReturn(-2.0);
                                                                                                                                             when(f.value(4.0)).thenReturn(2.0);  // root at x=3.5 for second function
                                                                                                                                             
                                                                                                                                             BrentSolver solver = new BrentSolver();
                                                                                                                                             
                                                                                                                                             // First solve operation
                                                                                                                                             double firstRoot = solver.solve(f, 1.0, 2.0);
                                                                                                                                             assertEquals(1.5, firstRoot, 1e-6);
                                                                                                                                             
                                                                                                                                             // Change the mock behavior for second function
                                                                                                                                             when(f.value(1.0)).thenReturn(-3.0);
                                                                                                                                             when(f.value(2.0)).thenReturn(3.0);  // different root location now
                                                                                                                                             
                                                                                                                                             // Second solve operation - should not be affected by first operation
                                                                                                                                             double secondRoot = solver.solve(f, 1.0, 2.0);
                                                                                                                                             assertEquals(1.5, secondRoot, 1e-6);  // This would fail if clearResult() was commented out
                                                                                                                                             
                                                                                                                                             // Verify the mock was called with expected values
                                                                                                                                             verify(f, atLeastOnce()).value(1.0);
                                                                                                                                             verify(f, atLeastOnce()).value(2.0);
                                                                                                                                         }

    @Test
                                                                                                                                     public void testMultipleSolvesDontAffectEachOther() throws MaxIterationsExceededException, FunctionEvaluationException {
                                                                                                                                         // Create a simple linear function: f(x) = x - 2 (root at x=2)
                                                                                                                                         UnivariateRealFunction f = new UnivariateRealFunction() {
                                                                                                                                             public double value(double x) {
                                                                                                                                                 return x - 2;
                                                                                                                                             }
                                                                                                                                         };
                                                                                                                                         
                                                                                                                                         // Create solver with default parameters
                                                                                                                                         BrentSolver solver = new BrentSolver(f);
                                                                                                                                         
                                                                                                                                         // First solve - should find root at x=2
                                                                                                                                         double result1 = solver.solve(f, 1.0, 3.0);
                                                                                                                                         assertEquals(2.0, result1, 1e-6);
                                                                                                                                         
                                                                                                                                         // Second solve with different function - should find root at x=3
                                                                                                                                         UnivariateRealFunction f2 = new UnivariateRealFunction() {
                                                                                                                                             public double value(double x) {
                                                                                                                                                 return x - 3;
                                                                                                                                             }
                                                                                                                                         };
                                                                                                                                         
                                                                                                                                         // If clearResult() was called, this should work correctly
                                                                                                                                         // If mutant is present (clearResult() commented out), might get wrong result
                                                                                                                                         double result2 = solver.solve(f2, 2.0, 4.0);
                                                                                                                                         assertEquals(3.0, result2, 1e-6);
                                                                                                                                         
                                                                                                                                         // Third solve with original function but different interval
                                                                                                                                         // Should still find root at x=2
                                                                                                                                         double result3 = solver.solve(f, 0.0, 2.5);
                                                                                                                                         assertEquals(2.0, result3, 1e-6);
                                                                                                                                     }

    @Test
                                                                                                                                     public void testSolveWithExactFunctionValueAccuracy() throws Exception {
                                                                                                                                         // Setup
                                                                                                                                         double functionValueAccuracy = 1E-6;
                                                                                                                                         double exactValue = functionValueAccuracy; // Value exactly at accuracy threshold
                                                                                                                                         double min = 0.0;
                                                                                                                                         double max = 1.0;
                                                                                                                                         
                                                                                                                                         // Mock the function to return exactValue at some point
                                                                                                                                         UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                         when(f.value(anyDouble())).thenReturn(exactValue);
                                                                                                                                         
                                                                                                                                         // Create solver with known functionValueAccuracy
                                                                                                                                         BrentSolver solver = new BrentSolver(f);
                                                                                                                                         
                                                                                                                                         // Test
                                                                                                                                         double result = solver.solve(f, min, max);
                                                                                                                                         
                                                                                                                                         // Verify - the original should find a solution, mutant would not
                                                                                                                                         // We can't directly verify the internal condition, but we can check if it returns
                                                                                                                                         // a value within bounds (original would, mutant might not)
                                                                                                                                         assertTrue("Solution should be within bounds", result >= min && result <= max);
                                                                                                                                         
                                                                                                                                         // Additional verification - check function was called
                                                                                                                                         verify(f, atLeastOnce()).value(anyDouble());
                                                                                                                                     }

    @Test
                                                                                                                                 public void testSolve_DetectsFunctionValueExactlyAtAccuracy() throws Exception {
                                                                                                                                     // Setup
                                                                                                                                     double min = 1.0;
                                                                                                                                     double max = 2.0;
                                                                                                                                     double functionValueAccuracy = 1E-6;
                                                                                                                                     
                                                                                                                                     // Create mock function that returns exactly functionValueAccuracy at min
                                                                                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                     when(f.value(min)).thenReturn(functionValueAccuracy);
                                                                                                                                     when(f.value(max)).thenReturn(1.0); // Any positive value
                                                                                                                                     
                                                                                                                                     // Create solver with known functionValueAccuracy
                                                                                                                                     BrentSolver solver = new BrentSolver(f);
                                                                                                                                     // Need to set functionValueAccuracy - assuming it's inherited from parent class
                                                                                                                                     // This might require reflection to set the field if not accessible
                                                                                                                                     
                                                                                                                                     try {
                                                                                                                                         Field field = solver.getClass().getSuperclass().getDeclaredField("functionValueAccuracy");
                                                                                                                                         field.setAccessible(true);
                                                                                                                                         field.set(solver, functionValueAccuracy);
                                                                                                                                     } catch (Exception e) {
                                                                                                                                         fail("Failed to set functionValueAccuracy via reflection");
                                                                                                                                     }
                                                                                                                                     
                                                                                                                                     // Test
                                                                                                                                     double result = solver.solve(min, max);
                                                                                                                                     
                                                                                                                                     // Verify
                                                                                                                                     assertEquals(min, result, 0.0);
                                                                                                                                     
                                                                                                                                     // Additional verification that we took the first branch
                                                                                                                                     verify(f).value(min);
                                                                                                                                     verify(f).value(max);
                                                                                                                                 }

    @Test
                                                                                                                                public void testConvergenceWhenFunctionValueEqualsAccuracy() throws Exception {
                                                                                                                                    // Setup
                                                                                                                                    double functionValueAccuracy = 1e-6;
                                                                                                                                    double x0 = 0.0, x1 = 1.0, x2 = 2.0;
                                                                                                                                    double y0 = 1.0, y1 = functionValueAccuracy, y2 = -1.0; // y1 exactly equals accuracy
                                                                                                                                    
                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                    when(f.value(x0)).thenReturn(y0);
                                                                                                                                    when(f.value(x1)).thenReturn(y1);
                                                                                                                                    when(f.value(x2)).thenReturn(y2);
                                                                                                                                    
                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                    // Set accuracy thresholds through reflection since they're private in parent class
                                                                                                                                    Field relativeAccuracy = BrentSolver.class.getSuperclass().getDeclaredField("relativeAccuracy");
                                                                                                                                    relativeAccuracy.setAccessible(true);
                                                                                                                                    relativeAccuracy.set(solver, 1e-6);
                                                                                                                                    
                                                                                                                                    Field absoluteAccuracy = BrentSolver.class.getSuperclass().getDeclaredField("absoluteAccuracy");
                                                                                                                                    absoluteAccuracy.setAccessible(true);
                                                                                                                                    absoluteAccuracy.set(solver, 1e-6);
                                                                                                                                    
                                                                                                                                    Field fva = BrentSolver.class.getSuperclass().getDeclaredField("functionValueAccuracy");
                                                                                                                                    fva.setAccessible(true);
                                                                                                                                    fva.set(solver, functionValueAccuracy);
                                                                                                                                    
                                                                                                                                    // Test - using public solve method with min/max bounds
                                                                                                                                    double result = solver.solve(x0, x2);
                                                                                                                                    
                                                                                                                                    // Verify
                                                                                                                                    // Should converge immediately since y1 equals accuracy threshold
                                                                                                                                    assertEquals(x1, result, 0.0);
                                                                                                                                    
                                                                                                                                    // Verify the function was evaluated at least at x0, x1, x2
                                                                                                                                    verify(f, atLeastOnce()).value(x0);
                                                                                                                                    verify(f, atLeastOnce()).value(x1);
                                                                                                                                    verify(f, atLeastOnce()).value(x2);
                                                                                                                                }

    @Test
                                                                                                                            public void testSolveWithExactAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                // Setup
                                                                                                                                double functionValueAccuracy = 1E-6; // Default accuracy from constructor
                                                                                                                                double yInitial = functionValueAccuracy; // Exact boundary case
                                                                                                                                
                                                                                                                                // Mock the UnivariateRealFunction to return our test value
                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                when(f.value(anyDouble())).thenReturn(yInitial);
                                                                                                                                
                                                                                                                                // Create solver with default accuracy
                                                                                                                                BrentSolver solver = new BrentSolver();
                                                                                                                                
                                                                                                                                // Test parameters (values don't matter much since we control the function output)
                                                                                                                                double min = 0;
                                                                                                                                double max = 1;
                                                                                                                                double initial = 0.5;
                                                                                                                                
                                                                                                                                // Call the method - should return immediately since yInitial equals accuracy
                                                                                                                                double result = solver.solve(f, min, max, initial);
                                                                                                                                
                                                                                                                                // Verify the result equals the initial value (boundary case should return)
                                                                                                                                assertEquals(initial, result, 0.0);
                                                                                                                                
                                                                                                                                // Verify the function was called exactly once (would be called more if mutant wasn't caught)
                                                                                                                                verify(f, times(1)).value(initial);
                                                                                                                            }

    @Test
                                                                                                                            public void testSolve_InitialValueExactlyAtAccuracyThreshold() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                // Setup
                                                                                                                                double min = 0.0;
                                                                                                                                double max = 2.0;
                                                                                                                                double initial = 1.0;
                                                                                                                                double functionValueAccuracy = 1E-6; // Default accuracy from constructor
                                                                                                                                
                                                                                                                                // Create mock function that returns exactly the accuracy threshold at initial point
                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                when(f.value(initial)).thenReturn(functionValueAccuracy);
                                                                                                                                when(f.value(min)).thenReturn(1.0); // Any non-zero value
                                                                                                                                when(f.value(max)).thenReturn(1.0); // Any non-zero value
                                                                                                                                
                                                                                                                                // Create solver with default accuracy
                                                                                                                                BrentSolver solver = new BrentSolver();
                                                                                                                                
                                                                                                                                // Test
                                                                                                                                double result = solver.solve(f, min, max, initial);
                                                                                                                                
                                                                                                                                // Verify
                                                                                                                                // The original code should return initial point when yInitial exactly equals accuracy threshold
                                                                                                                                assertEquals(initial, result, 0.0);
                                                                                                                                
                                                                                                                                // Additional verification that we didn't proceed to other checks
                                                                                                                                verify(f, times(1)).value(initial);
                                                                                                                                verify(f, never()).value(min);
                                                                                                                                verify(f, never()).value(max);
                                                                                                                            }

    @Test
                                                                                                                            public void testBracketingConditionWithZeroValue() throws Exception {
                                                                                                                                // Create mock function that returns 0 at x=1.0
                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                when(f.value(0.0)).thenReturn(-1.0);
                                                                                                                                when(f.value(1.0)).thenReturn(0.0);
                                                                                                                                when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                
                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    // Test case where one of the values is exactly zero
                                                                                                                                    // Original should throw exception as it doesn't strictly bracket a root
                                                                                                                                    // Mutant would accept this case
                                                                                                                                    double result = solver.solve(f, 0.0, 2.0);
                                                                                                                                    
                                                                                                                                    // If we get here, the mutant survived - force test to fail
                                                                                                                                    fail("Expected IllegalArgumentException for non-bracketing condition");
                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                    // Original behavior - test passes
                                                                                                                                    assertTrue(e.getMessage().contains("function values at endpoints do not have different signs"));
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Additional test case where both values are zero
                                                                                                                                when(f.value(0.0)).thenReturn(0.0);
                                                                                                                                when(f.value(1.0)).thenReturn(0.0);
                                                                                                                                try {
                                                                                                                                    double result = solver.solve(f, 0.0, 1.0);
                                                                                                                                    fail("Expected IllegalArgumentException for non-bracketing condition");
                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                    assertTrue(e.getMessage().contains("function values at endpoints do not have different signs"));
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                       public void testSolveWithYInitialZeroShouldNotBracket() throws Exception {
                                                                                                                           // Setup
                                                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                                                           
                                                                                                                           // Mock function values
                                                                                                                           when(f.value(1.0)).thenReturn(0.0);  // yInitial = 0
                                                                                                                           when(f.value(0.0)).thenReturn(-2.0); // yMin = -2
                                                                                                                           
                                                                                                                           // Get the private NON_BRACKETING_MESSAGE field using reflection
                                                                                                                           Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                                                                                                           field.setAccessible(true);
                                                                                                                           String expectedMessage = (String) field.get(null);
                                                                                                                           
                                                                                                                           // Test the behavior through the public solve method
                                                                                                                           try {
                                                                                                                               solver.solve(f, 0.0, 2.0, 1.0);
                                                                                                                               // If we get here, the mutant survived (incorrectly accepted the bracket)
                                                                                                                               fail("Expected IllegalArgumentException for non-bracketing case");
                                                                                                                           } catch (IllegalArgumentException e) {
                                                                                                                               // Original behavior would throw exception since 0*-2 is not < 0
                                                                                                                               assertEquals(expectedMessage, e.getMessage());
                                                                                                                           }
                                                                                                                       }

    @Test
                                                                                                                       public void testSolveWithYMinZeroShouldNotBracket() throws Exception {
                                                                                                                           // Setup
                                                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                                                           
                                                                                                                           // Mock function values
                                                                                                                           when(f.value(1.0)).thenReturn(2.0);  // yInitial = 2
                                                                                                                           when(f.value(0.0)).thenReturn(0.0);  // yMin = 0
                                                                                                                           
                                                                                                                           // Test the behavior through the public solve method
                                                                                                                           try {
                                                                                                                               solver.solve(f, 0.0, 2.0, 1.0);
                                                                                                                               // If we get here, the mutant survived (incorrectly accepted the bracket)
                                                                                                                               fail("Expected IllegalArgumentException for non-bracketing case");
                                                                                                                           } catch (IllegalArgumentException e) {
                                                                                                                               // Original behavior would throw exception since 2*0 is not < 0
                                                                                                                               // Just verify the exception type since we can't access the private message
                                                                                                                           }
                                                                                                                       }

    @Test
                                                                                                                   public void testBracketingConditionWithZeroValue1() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                       // Create mock function that returns 0 at min point
                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                       when(f.value(0.0)).thenReturn(0.0);  // yMin = 0
                                                                                                                       when(f.value(1.0)).thenReturn(2.0);  // yInitial = 2
                                                                                                                       
                                                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                                                       
                                                                                                                       try {
                                                                                                                           // This should throw IllegalArgumentException in original code
                                                                                                                           // because yMin is 0 but condition is yInitial*yMin < 0
                                                                                                                           // Mutated code would proceed with yInitial*yMin <= 0
                                                                                                                           double result = solver.solve(0.0, 1.0, 1.0);
                                                                                                                           
                                                                                                                           // If we get here, the mutant survived
                                                                                                                           fail("Expected IllegalArgumentException when yMin is exactly 0");
                                                                                                                       } catch (IllegalArgumentException e) {
                                                                                                                           // Original behavior - test passes
                                                                                                                           assertTrue(e.getMessage().contains("function values at endpoints do not have different signs"));
                                                                                                                       }
                                                                                                                   }

    @Test
                                                                                                                   public void testBracketingConditionWithZeroInitialValue() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                       // Create mock function that returns 0 at initial point
                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                       when(f.value(0.0)).thenReturn(-1.0);  // yMin = -1
                                                                                                                       when(f.value(1.0)).thenReturn(0.0);   // yInitial = 0
                                                                                                                       
                                                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                                                       
                                                                                                                       try {
                                                                                                                           // This should throw IllegalArgumentException in original code
                                                                                                                           // because yInitial is 0 but condition is yInitial*yMin < 0
                                                                                                                           // Mutated code would proceed with yInitial*yMin <= 0
                                                                                                                           double result = solver.solve(0.0, 1.0, 1.0);
                                                                                                                           
                                                                                                                           // If we get here, the mutant survived
                                                                                                                           fail("Expected IllegalArgumentException when yInitial is exactly 0");
                                                                                                                       } catch (IllegalArgumentException e) {
                                                                                                                           // Original behavior - test passes
                                                                                                                           assertTrue(e.getMessage().contains("function values at endpoints do not have different signs"));
                                                                                                                       }
                                                                                                                   }

    @Test
                                                                                                                   public void testSolve_DetectsMutantWhenProductEqualsZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                       // Create a mock function that returns specific values
                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                       when(f.value(1.0)).thenReturn(0.0);  // initial point returns exactly zero
                                                                                                                       when(f.value(0.0)).thenReturn(2.0);  // min point returns positive
                                                                                                                       when(f.value(2.0)).thenReturn(-1.0); // max point returns negative
                                                                                                                       
                                                                                                                       // Create solver with tight accuracy to ensure 0.0 isn't considered accurate enough
                                                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                                                       solver.setFunctionValueAccuracy(1e-10);
                                                                                                                       
                                                                                                                       // Test case where yInitial is exactly 0 (but not within accuracy)
                                                                                                                       // and yMin is positive (so yInitial*yMin = 0)
                                                                                                                       double result = solver.solve(0.0, 2.0, 1.0);
                                                                                                                       
                                                                                                                       // Verify the method didn't take the mutated path
                                                                                                                       // The correct behavior should be to check yMax next, not enter the bracketing case
                                                                                                                       // Since yInitial is exactly 0, but not within accuracy, it should proceed to check yMax
                                                                                                                       // and eventually throw exception since yMin*yMax < 0 but initial doesn't bracket
                                                                                                                       
                                                                                                                       // We expect either:
                                                                                                                       // 1. The method proceeds to check yMax and throws exception (original behavior)
                                                                                                                       // 2. Or it incorrectly enters the bracketing case (mutant behavior)
                                                                                                                       
                                                                                                                       // Since we can't directly observe the path taken, we verify the end result
                                                                                                                       // In original code, this should throw exception because min and max bracket root
                                                                                                                       // but initial doesn't (since yInitial is 0)
                                                                                                                       // The mutant would incorrectly enter the bracketing case
                                                                                                                       
                                                                                                                       // Verify the result is not the initial guess (which would happen if mutant path taken)
                                                                                                                       assertNotEquals(1.0, result, 0.0);
                                                                                                                       
                                                                                                                       // Also verify the result is within expected bounds
                                                                                                                       assertTrue(result >= 0.0 && result <= 2.0);
                                                                                                                   }

    @Test
                                                                                                                   public void testSolveWithInitialAndMinProductZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                       // Create mock function
                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                       
                                                                                                                       // Setup mock behavior
                                                                                                                       when(f.value(1.0)).thenReturn(0.0);  // yInitial = 0
                                                                                                                       when(f.value(2.0)).thenReturn(3.0);  // yMin = 3
                                                                                                                       when(f.value(3.0)).thenReturn(-2.0); // yMax = -2
                                                                                                                       
                                                                                                                       // Create solver and set accuracy
                                                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                                                       solver.setFunctionValueAccuracy(1e-6);
                                                                                                                       
                                                                                                                       // Test the method - should use different path when yInitial*yMin == 0 vs < 0
                                                                                                                       double result = solver.solve(2.0, 3.0, 1.0);
                                                                                                                       
                                                                                                                       // Verify the result is correct (should find root between 2 and 3)
                                                                                                                       assertTrue(result >= 2.0 && result <= 3.0);
                                                                                                                       
                                                                                                                       // Verify the function was called with expected values
                                                                                                                       verify(f).value(1.0);
                                                                                                                       verify(f).value(2.0);
                                                                                                                       verify(f).value(3.0);
                                                                                                                   }

    @Test
                                                                                                                   public void testSolveWithMinZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                       // Create mock function
                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                       
                                                                                                                       // Setup mock behavior
                                                                                                                       when(f.value(1.0)).thenReturn(2.0);  // yInitial = 2
                                                                                                                       when(f.value(2.0)).thenReturn(0.0);  // yMin = 0
                                                                                                                       when(f.value(3.0)).thenReturn(-2.0); // yMax = -2
                                                                                                                       
                                                                                                                       // Create solver
                                                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                                                       solver.setFunctionValueAccuracy(1e-6);
                                                                                                                       
                                                                                                                       // Test the method - should return min since yMin is exactly 0
                                                                                                                       double result = solver.solve(2.0, 3.0, 1.0);
                                                                                                                       
                                                                                                                       // Verify the result
                                                                                                                       assertEquals(2.0, result, 1e-6);
                                                                                                                   }

    @Test
                                                                                                                   public void testSolveDetectsParameterSwapMutant() throws Exception {
                                                                                                                       // Create a mock function where f(min) ≠ f(initial)
                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                       when(f.value(0.0)).thenReturn(-1.0);  // min
                                                                                                                       when(f.value(1.0)).thenReturn(0.5);    // initial
                                                                                                                       when(f.value(2.0)).thenReturn(1.0);    // max
                                                                                                                       
                                                                                                                       // The function has a root between initial and max
                                                                                                                       when(f.value(1.5)).thenReturn(0.0);
                                                                                                                       
                                                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                                                       
                                                                                                                       // The original should find the root at 1.5
                                                                                                                       double result = solver.solve(0.0, 2.0, 1.0);
                                                                                                                       
                                                                                                                       // Verify the correct parameters would be passed to the private solve method
                                                                                                                       // The mutation would pass (0.0, f(0.0)) instead of (1.0, f(1.0)) as last params
                                                                                                                       // This would make the result incorrect since the bracketing would be wrong
                                                                                                                       assertEquals(1.5, result, 1e-6);
                                                                                                                       
                                                                                                                       // Verify the function was called with expected values
                                                                                                                       verify(f).value(0.0); // min
                                                                                                                       verify(f).value(1.0); // initial
                                                                                                                       verify(f).value(2.0); // max
                                                                                                                       verify(f).value(1.5); // solution
                                                                                                                   }

    @Test
                                                                                                               public void testSolveWithDifferentInitialPoints() throws Exception {
                                                                                                                   // Create a mock function that returns y = x^2 - 4 (root at x=2)
                                                                                                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                   when(f.value(anyDouble())).thenAnswer(inv -> {
                                                                                                                       double x = inv.getArgument(0);
                                                                                                                       return x * x - 4;
                                                                                                                   });
                                                                                                               
                                                                                                                   // Create solver with default settings
                                                                                                                   BrentSolver solver = new BrentSolver(f);
                                                                                                                   
                                                                                                                   // Set up test parameters where min ≠ initial
                                                                                                                   double min = 0.0;
                                                                                                                   double yMin = f.value(min);
                                                                                                                   double max = 5.0;
                                                                                                                   double yMax = f.value(max);
                                                                                                                   double initial = 1.0;
                                                                                                                   double yInitial = f.value(initial);
                                                                                                                   
                                                                                                                   try {
                                                                                                                       // This should throw MaxIterationsExceededException because we can't access private solve directly
                                                                                                                       // But we can test through public solve methods that call the private one
                                                                                                                       double result = solver.solve(f, min, max, initial);
                                                                                                                       
                                                                                                                       // Verify the result is correct (root at 2.0)
                                                                                                                       assertEquals(2.0, result, 1e-6);
                                                                                                                       
                                                                                                                       // The key verification is that with the mutation, the wrong initial points would be used,
                                                                                                                       // potentially causing different iteration paths or wrong results
                                                                                                                       // We can verify the mock interactions show correct points were used
                                                                                                                       verify(f, atLeastOnce()).value(initial);
                                                                                                                       verify(f, never()).value(min); // In original version, min shouldn't be used as x2
                                                                                                                       
                                                                                                                   } catch (MaxIterationsExceededException e) {
                                                                                                                       fail("Should not exceed max iterations for this simple function");
                                                                                                                   }
                                                                                                               }

    @Test
                                                                                                              public void testSolveWithInitialPoint_VerifiesCorrectParametersPassedToInternalSolve() throws Exception {
                                                                                                                  // Setup
                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                  when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                  when(f.value(4.0)).thenReturn(2.0);
                                                                                                                  when(f.value(2.0)).thenReturn(-0.5);
                                                                                                                  
                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                  
                                                                                                                  // Get private method via reflection
                                                                                                                  Method privateSolve = BrentSolver.class.getDeclaredMethod(
                                                                                                                      "solve", 
                                                                                                                      UnivariateRealFunction.class, 
                                                                                                                      double.class, double.class, 
                                                                                                                      double.class, double.class, 
                                                                                                                      double.class, double.class
                                                                                                                  );
                                                                                                                  privateSolve.setAccessible(true);
                                                                                                                  
                                                                                                                  // Stub the private method to return test value
                                                                                                                  BrentSolver spySolver = spy(solver);
                                                                                                                  when(privateSolve.invoke(
                                                                                                                      spySolver, 
                                                                                                                      any(UnivariateRealFunction.class),
                                                                                                                      anyDouble(), anyDouble(),
                                                                                                                      anyDouble(), anyDouble(),
                                                                                                                      anyDouble(), anyDouble()
                                                                                                                  )).thenReturn(3.0);
                                                                                                                  
                                                                                                                  // Test
                                                                                                                  double result = spySolver.solve(1.0, 4.0, 2.0);
                                                                                                                  
                                                                                                                  // Verify
                                                                                                                  assertEquals(3.0, result, 0.0001);
                                                                                                              }

    @Test
                                                                                                          public void testSolve_DetectsMutatedRecursiveCall() throws Exception {
                                                                                                              // Setup mock function with specific values
                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                              when(f.value(0.0)).thenReturn(1.0);  // yMin = 1.0
                                                                                                              when(f.value(1.0)).thenReturn(-0.5); // yInitial = -0.5
                                                                                                              when(f.value(2.0)).thenReturn(2.0);  // yMax = 2.0
                                                                                                              
                                                                                                              // Create spy of solver to verify recursive call
                                                                                                              BrentSolver solver = spy(new BrentSolver(f));
                                                                                                              
                                                                                                              // Call the public solve method
                                                                                                              solver.solve(f, 0.0, 2.0, 1.0);
                                                                                                              
                                                                                                              // Use reflection to access the private solve method
                                                                                                              Method privateSolve = BrentSolver.class.getDeclaredMethod(
                                                                                                                  "solve", 
                                                                                                                  UnivariateRealFunction.class, 
                                                                                                                  double.class, double.class, 
                                                                                                                  double.class, double.class, 
                                                                                                                  double.class, double.class
                                                                                                              );
                                                                                                              privateSolve.setAccessible(true);
                                                                                                              
                                                                                                              // Verify the recursive solve was called with correct parameters
                                                                                                              // Instead of direct verify, we'll check the behavior through reflection
                                                                                                              // and verify the final result is as expected
                                                                                                              
                                                                                                              // Additional assertion to ensure the test would fail with mutant
                                                                                                              // We can't directly verify private method calls, so we'll verify
                                                                                                              // the public behavior that would differ with the mutant
                                                                                                              double result = solver.solve(f, 0.0, 2.0, 1.0);
                                                                                                              assertFalse("Test should fail if mutant is present", 
                                                                                                                  Double.isNaN(result) || result == 0.0); // Adjust based on expected behavior
                                                                                                              
                                                                                                              // Alternative approach: verify interactions with the mock function
                                                                                                              verify(f, atLeastOnce()).value(1.0); // Verify initial value was used
                                                                                                              verify(f, never()).value(0.0); // Verify min value wasn't incorrectly used
                                                                                                          }

    @Test
                                                                                                      public void testSolveWithDifferentInitialAndMin() throws FunctionEvaluationException {
                                                                                                          // Create mock function that returns known values
                                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                          when(f.value(1.0)).thenReturn(-1.0);  // min
                                                                                                          when(f.value(2.0)).thenReturn(1.0);   // max
                                                                                                          when(f.value(1.5)).thenReturn(-0.5);  // initial
                                                                                                          
                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                          
                                                                                                          // Use reflection to access private solve method
                                                                                                          try {
                                                                                                              Method privateSolve = BrentSolver.class.getDeclaredMethod(
                                                                                                                  "solve", 
                                                                                                                  UnivariateRealFunction.class, 
                                                                                                                  double.class, double.class, 
                                                                                                                  double.class, double.class, 
                                                                                                                  double.class, double.class);
                                                                                                              privateSolve.setAccessible(true);
                                                                                                              
                                                                                                              // Test with min=1.0, max=2.0, initial=1.5
                                                                                                              double result = (double) privateSolve.invoke(
                                                                                                                  solver, 
                                                                                                                  f, 
                                                                                                                  1.5, -0.5,  // x0,y0 (initial)
                                                                                                                  2.0, 1.0,   // x1,y1 (max)
                                                                                                                  1.0, -1.0  // x2,y2 (min) - would be initial in original
                                                                                                              );
                                                                                                              
                                                                                                              // The actual assertion would depend on expected behavior,
                                                                                                              // but we know the mutant would behave differently when initial != min
                                                                                                              // So we can verify the method was called with expected parameters
                                                                                                              // This is a simplified version - in practice you'd need more precise verification
                                                                                                              
                                                                                                              // For demonstration, we'll assert it returns a value between min and max
                                                                                                              assertTrue("Result should be between min and max", 
                                                                                                                        result >= 1.0 && result <= 2.0);
                                                                                                              
                                                                                                          } catch (Exception e) {
                                                                                                              fail("Failed to test private solve method: " + e.getMessage());
                                                                                                          }
                                                                                                      }

    @Test
                                                                                                      public void testSolveParameterOrderWhenBracketingRoot() throws Exception {
                                                                                                          // Setup mock function that crosses zero between 2 and 3
                                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                          when(f.value(2.0)).thenReturn(-1.0);  // f(min) negative
                                                                                                          when(f.value(3.0)).thenReturn(1.0);   // f(max) positive
                                                                                                          when(f.value(2.5)).thenReturn(0.0);   // root at 2.5
                                                                                                          
                                                                                                          // Create solver with default accuracy settings
                                                                                                          BrentSolver solver = new BrentSolver(f);
                                                                                                          
                                                                                                          // Call solve with min=2, max=3
                                                                                                          double result = solver.solve(2.0, 3.0);
                                                                                                          
                                                                                                          // Verify the result is correct (should find root at 2.5)
                                                                                                          // The mutant would pass wrong parameter order to internal solver
                                                                                                          // which might affect convergence or return wrong result
                                                                                                          assertEquals(2.5, result, 0.0001);
                                                                                                          
                                                                                                          // Also verify the function was called with expected parameters
                                                                                                          verify(f).value(2.0);
                                                                                                          verify(f).value(3.0);
                                                                                                      }

    @Test
                                                                                                  public void testSolveWithSwappedMinMaxShouldProduceDifferentResult() throws Exception {
                                                                                                      // Create a mock function that has different behavior on left vs right side
                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                      when(f.value(-1.0)).thenReturn(-1.0);  // min point
                                                                                                      when(f.value(1.0)).thenReturn(1.0);   // max point
                                                                                                      when(f.value(0.0)).thenReturn(0.0);   // initial point (root)
                                                                                                      
                                                                                                      // The original method should find the root at 0.0 quickly
                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                      double result = solver.solve(f, -1.0, 1.0, 0.0);
                                                                                                      assertEquals(0.0, result, 1e-6);
                                                                                                      
                                                                                                      // Now test with swapped min/max - should still find the same root
                                                                                                      // If the mutant survives, it might produce a different result
                                                                                                      double resultSwapped = solver.solve(f, 1.0, -1.0, 0.0);
                                                                                                      assertEquals(0.0, resultSwapped, 1e-6);
                                                                                                      
                                                                                                      // Verify the function was called with expected values
                                                                                                      verify(f).value(-1.0);
                                                                                                      verify(f).value(1.0);
                                                                                                      verify(f).value(0.0);
                                                                                                  }

    @Test
                                                                                                 public void testSolveParameterOrder() {
                                                                                                     // Create a mock function that crosses zero between 1 and 3
                                                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                     try {
                                                                                                         when(f.value(1.0)).thenReturn(-1.0);  // f(1) = -1
                                                                                                         when(f.value(2.0)).thenReturn(0.0);   // f(2) = 0 (root)
                                                                                                         when(f.value(3.0)).thenReturn(1.0);   // f(3) = 1
                                                                                                     } catch (FunctionEvaluationException e) {
                                                                                                         fail("Mock setup failed: " + e.toString());
                                                                                                     }
                                                                                                     
                                                                                                     // Set up test parameters
                                                                                                     double min = 1.0;
                                                                                                     double yMin = -1.0;
                                                                                                     double max = 3.0;
                                                                                                     double yMax = 1.0;
                                                                                                     double initial = 2.0;
                                                                                                     double yInitial = 0.0;
                                                                                                     
                                                                                                     // Create solver and call private method via reflection
                                                                                                     BrentSolver solver = new BrentSolver();
                                                                                                     try {
                                                                                                         Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                             "solve", 
                                                                                                             UnivariateRealFunction.class, 
                                                                                                             double.class, double.class, 
                                                                                                             double.class, double.class, 
                                                                                                             double.class, double.class);
                                                                                                         solveMethod.setAccessible(true);
                                                                                                         
                                                                                                         double result = (double) solveMethod.invoke(
                                                                                                             solver, 
                                                                                                             f, min, yMin, max, yMax, initial, yInitial);
                                                                                                             
                                                                                                         // Verify the result is within [min,max] and close to the actual root (2.0)
                                                                                                         assertTrue("Result should be >= min", result >= min);
                                                                                                         assertTrue("Result should be <= max", result <= max);
                                                                                                         assertEquals("Should find the root at 2.0", 2.0, result, 1e-6);
                                                                                                         
                                                                                                     } catch (Exception e) {
                                                                                                         fail("Reflection failed: " + e.toString());
                                                                                                     }
                                                                                                 }

    @Test
                                                                                                 public void testSolveWithSwappedBoundsShouldFail() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                     // Create a mock function that returns different values for min and max
                                                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                     when(f.value(1.0)).thenReturn(-1.0);  // f(min) = -1
                                                                                                     when(f.value(3.0)).thenReturn(1.0);    // f(max) = 1
                                                                                                     when(f.value(2.0)).thenReturn(0.0);   // root at x=2
                                                                                                     
                                                                                                     // Create test parameters
                                                                                                     double min = 1.0;
                                                                                                     double max = 3.0;
                                                                                                     double initial = 2.0;
                                                                                                     
                                                                                                     // Create solver instance
                                                                                                     BrentSolver solver = new BrentSolver(f);
                                                                                                     
                                                                                                     // Call the public solve method which should delegate to private solve
                                                                                                     double result = solver.solve(min, max, initial);
                                                                                                     
                                                                                                     // Verify the result is within original bounds (not swapped)
                                                                                                     assertTrue("Result should be between min and max", 
                                                                                                               result >= min && result <= max);
                                                                                                     
                                                                                                     // Verify the function was called with correct bounds
                                                                                                     // This is important because the mutant would have swapped them
                                                                                                     verify(f).value(min);
                                                                                                     verify(f).value(max);
                                                                                                 }

    @Test
                                                                                                 public void testSolveParameterOrderWhenFullBrentAlgorithmNeeded() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                     // Setup
                                                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                     when(f.value(0.0)).thenReturn(1.0);  // yMin
                                                                                                     when(f.value(1.0)).thenReturn(-1.0); // yMax
                                                                                                     when(f.value(0.5)).thenReturn(0.5);  // yInitial
                                                                                                     
                                                                                                     BrentSolver solver = new BrentSolver(f);
                                                                                                     
                                                                                                     // Test - min=0, max=1, initial=0.5
                                                                                                     // Should call solve(f, 0, 1, 1, -1, 0.5, 0.5) in original
                                                                                                     // Mutant would call solve(f, 1, -1, 0, 1, 0.5, 0.5)
                                                                                                     double result = solver.solve(0, 1, 0.5);
                                                                                                     
                                                                                                     // Verify the correct parameter order was used by checking the solution
                                                                                                     // Since we can't directly observe the internal solve call, we verify the behavior
                                                                                                     // that would differ based on parameter order - the solution should be between 0 and 1
                                                                                                     assertTrue("Result should be within bounds", result >= 0 && result <= 1);
                                                                                                     
                                                                                                     // Additional verification that the solution is correct
                                                                                                     // The actual root in this case would be where the line from (0,1) to (1,-1) crosses 0
                                                                                                     // which is at x=0.5, but since we mocked f.value, we can't get the actual root
                                                                                                     // So we verify the mock interactions instead
                                                                                                     verify(f).value(0.0);  // min
                                                                                                     verify(f).value(1.0);  // max
                                                                                                     verify(f).value(0.5);  // initial
                                                                                                 }

    @Test
                                                                                                 public void testSolveClearsPreviousResult2() throws Exception {
                                                                                                     // Setup mock function that returns different values for different inputs
                                                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                     when(f.value(1.0)).thenReturn(-1.0);
                                                                                                     when(f.value(2.0)).thenReturn(1.0);  // Root at x=1.5 (first test)
                                                                                                     when(f.value(3.0)).thenReturn(-2.0);
                                                                                                     when(f.value(4.0)).thenReturn(2.0);  // Root at x=3.5 (second test)
                                                                                                     
                                                                                                     BrentSolver solver = new BrentSolver();
                                                                                                     
                                                                                                     // First solve call - root at 1.5
                                                                                                     double firstRoot = solver.solve(f, 1.0, 2.0);
                                                                                                     assertEquals(1.5, firstRoot, 0.0001);
                                                                                                     
                                                                                                     // Second solve call with different parameters - should be independent
                                                                                                     double secondRoot = solver.solve(f, 3.0, 4.0);
                                                                                                     assertEquals(3.5, secondRoot, 0.0001);
                                                                                                     
                                                                                                     // If clearResult() was commented out, the second solve might be affected by first call's state
                                                                                                     // This test would fail if clearResult() was not called between solves
                                                                                                 }

    @Test
                                                                                                 public void testSolveClearsPreviousResult3() throws Exception {
                                                                                                     // Setup mock function that returns different values for different calls
                                                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                     when(f.value(1.0)).thenReturn(-1.0);
                                                                                                     when(f.value(2.0)).thenReturn(1.0);
                                                                                                     when(f.value(1.5)).thenReturn(0.0);
                                                                                                     
                                                                                                     // First test case - should converge to 1.5
                                                                                                     BrentSolver solver = new BrentSolver(f);
                                                                                                     double result1 = solver.solve(1.0, 2.0);
                                                                                                     assertEquals(1.5, result1, 1e-6);
                                                                                                     
                                                                                                     // Change mock behavior for second test
                                                                                                     when(f.value(3.0)).thenReturn(-2.0);
                                                                                                     when(f.value(4.0)).thenReturn(2.0);
                                                                                                     when(f.value(3.5)).thenReturn(0.0);
                                                                                                     
                                                                                                     // Second test case - should converge to 3.5 and not be affected by first result
                                                                                                     double result2 = solver.solve(3.0, 4.0);
                                                                                                     assertEquals(3.5, result2, 1e-6);
                                                                                                     
                                                                                                     // Verify the second result is independent of first one
                                                                                                     assertNotEquals(result1, result2, 1e-6);
                                                                                                     
                                                                                                     // Verify function was called with expected values
                                                                                                     verify(f).value(1.0);
                                                                                                     verify(f).value(2.0);
                                                                                                     verify(f).value(1.5);
                                                                                                     verify(f).value(3.0);
                                                                                                     verify(f).value(4.0);
                                                                                                     verify(f).value(3.5);
                                                                                                 }

    @Test
                                                                                            public void testClearResultMutation() throws Exception {
                                                                                                // Create a mock function that returns different values on subsequent calls
                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                when(f.value(1.0)).thenReturn(-1.0);
                                                                                                when(f.value(2.0)).thenReturn(1.0);
                                                                                                when(f.value(3.0)).thenReturn(-2.0);
                                                                                                when(f.value(4.0)).thenReturn(2.0);
                                                                                                
                                                                                                // Create real solver instance with our mock function
                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                
                                                                                                // First call
                                                                                                double result1 = solver.solve(f, 1.0, 2.0);
                                                                                                assertEquals(1.5, result1, 0.0001);
                                                                                                
                                                                                                // Second call with different interval
                                                                                                double result2 = solver.solve(f, 3.0, 4.0);
                                                                                                assertEquals(3.5, result2, 0.0001);
                                                                                                
                                                                                                // Verify that the second result is different from first
                                                                                                // This would fail if clearResult() was commented out and state wasn't cleared
                                                                                                assertNotEquals(result1, result2, 0.0001);
                                                                                                
                                                                                                // Verify that the mock was called with correct parameters for second call
                                                                                                verify(f).value(3.0);
                                                                                                verify(f).value(4.0);
                                                                                            }

    @Test
                                                                                        public void testSolveClearsPreviousResult4() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                            // Create mock function that returns different values for testing
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(anyDouble())).thenReturn(-1.0, 1.0); // First call returns -1, second returns 1
                                                                                            
                                                                                            BrentSolver solver = new BrentSolver(f);
                                                                                            
                                                                                            // First solve call
                                                                                            double firstResult = solver.solve(f, 0, 2, 1);
                                                                                            
                                                                                            // Reset mock to verify second call is independent
                                                                                            reset(f);
                                                                                            when(f.value(anyDouble())).thenReturn(-2.0, 2.0); // Different values for second test
                                                                                            
                                                                                            // Second solve call - should be independent of first call
                                                                                            double secondResult = solver.solve(f, 0, 2, 1);
                                                                                            
                                                                                            // Verify the function was called fresh for second solve
                                                                                            // If clearResult() was skipped, the second solve might use cached values
                                                                                            verify(f, atLeastOnce()).value(1.0); // Verify fresh evaluation at initial point
                                                                                            // The exact assertions would depend on the solver's expected behavior,
                                                                                            // but the key point is verifying the second solve isn't affected by first
                                                                                        }

    @Test
                                                                                        public void testClearResultIsCalledAtStart() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                            // Setup mock function that returns different values on subsequent calls
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(anyDouble()))
                                                                                                .thenReturn(1.0)  // first call for initial
                                                                                                .thenReturn(-1.0) // first call for min
                                                                                                .thenReturn(2.0)  // first call for max
                                                                                                .thenReturn(0.0); // second call for initial (should be used if clearResult works)
                                                                                            
                                                                                            BrentSolver solver = new BrentSolver(f);
                                                                                            
                                                                                            // First call - should set some internal state
                                                                                            try {
                                                                                                solver.solve(0, 1, 0.5);
                                                                                                fail("Expected exception");
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                // expected - non bracketing
                                                                                            }
                                                                                            
                                                                                            // Change mock to return 0 at initial point on next call
                                                                                            when(f.value(0.5)).thenReturn(0.0);
                                                                                            
                                                                                            // Second call - should work if clearResult was called
                                                                                            double result = solver.solve(0, 1, 0.5);
                                                                                            assertEquals(0.5, result, 1e-6);
                                                                                            
                                                                                            // If clearResult wasn't called, it would use stale values and throw exception
                                                                                        }

    @Test
                                                                                        public void testSolveWithExactAccuracyThreshold() throws Exception {
                                                                                            // Setup
                                                                                            BrentSolver solver = new BrentSolver();
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            
                                                                                            // Set up test values where yInitial exactly equals functionValueAccuracy
                                                                                            double min = 0.0;
                                                                                            double max = 1.0;
                                                                                            double initial = 0.5;
                                                                                            double functionValueAccuracy = 1E-6; // Default accuracy in BrentSolver
                                                                                            double yInitial = functionValueAccuracy; // Exact equality case
                                                                                            
                                                                                            // Mock the function to return our test yInitial value
                                                                                            when(f.value(initial)).thenReturn(yInitial);
                                                                                            
                                                                                            try {
                                                                                                // Use reflection to access the private solve method
                                                                                                java.lang.reflect.Method method = BrentSolver.class.getDeclaredMethod(
                                                                                                    "solve", 
                                                                                                    UnivariateRealFunction.class, 
                                                                                                    double.class, 
                                                                                                    double.class, 
                                                                                                    double.class
                                                                                                );
                                                                                                method.setAccessible(true);
                                                                                                
                                                                                                // Call the method - original should return, mutant would continue
                                                                                                double result = (double) method.invoke(solver, f, min, max, initial);
                                                                                                
                                                                                                // Verify the result equals the initial value since we've hit the accuracy threshold
                                                                                                assertEquals(initial, result, 0.0);
                                                                                                
                                                                                            } catch (Exception e) {
                                                                                                fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testSolve_DetectsRootWhenFunctionValueEqualsAccuracy() throws Exception {
                                                                                            // Setup
                                                                                            double min = 1.0;
                                                                                            double max = 2.0;
                                                                                            double functionValueAccuracy = 1E-6;
                                                                                            double yMin = functionValueAccuracy; // Exactly equals accuracy
                                                                                            
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(min)).thenReturn(yMin);
                                                                                            when(f.value(max)).thenReturn(1.0); // Any positive value
                                                                                            
                                                                                            BrentSolver solver = new BrentSolver(f);
                                                                                            // Set functionValueAccuracy through reflection since it's inherited from parent
                                                                                            // This assumes the parent class has this field
                                                                                            try {
                                                                                                java.lang.reflect.Field field = solver.getClass().getSuperclass().getDeclaredField("functionValueAccuracy");
                                                                                                field.setAccessible(true);
                                                                                                field.set(solver, functionValueAccuracy);
                                                                                            } catch (Exception e) {
                                                                                                fail("Failed to set functionValueAccuracy through reflection");
                                                                                            }
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(min, max);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(min, result, 0.0);
                                                                                            verify(f).value(min);
                                                                                            verify(f).value(max);
                                                                                        }

    @Test
                                                                                   public void testSolve_ExactFunctionValueAccuracy() throws Exception {
                                                                                       // Setup
                                                                                       double functionValueAccuracy = 1E-6;
                                                                                       double x0 = 0.0, x1 = 1.0, x2 = 2.0;
                                                                                       double y0 = 1.0, y1 = functionValueAccuracy, y2 = -1.0; // y1 exactly equals accuracy
                                                                                       
                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                       when(f.value(x1)).thenReturn(y1);
                                                                                       
                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                       solver.setFunctionValueAccuracy(functionValueAccuracy);
                                                                                       
                                                                                       // Get the private solve method via reflection
                                                                                       Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                           "solve", 
                                                                                           UnivariateRealFunction.class, 
                                                                                           double.class, double.class, 
                                                                                           double.class, double.class, 
                                                                                           double.class, double.class
                                                                                       );
                                                                                       solveMethod.setAccessible(true);
                                                                                       
                                                                                       // Test
                                                                                       double result = (Double) solveMethod.invoke(
                                                                                           solver, 
                                                                                           f, x0, y0, x1, y1, x2, y2
                                                                                       );
                                                                                       
                                                                                       // Verify
                                                                                       assertEquals(x1, result, 0.0); // Should return x1 immediately
                                                                                       verify(f, times(1)).value(x1); // Should only evaluate function once
                                                                                   }

    @Test
                                                                               public void testSolveWithExactAccuracy1() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                   // Setup
                                                                                   final double accuracy = 1E-6; // Default functionValueAccuracy from constructor
                                                                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                   when(f.value(anyDouble())).thenReturn(accuracy); // Function returns exactly the accuracy value
                                                                                   
                                                                                   BrentSolver solver = new BrentSolver(f);
                                                                                   
                                                                                   // Test - should accept the solution when |yInitial| == functionValueAccuracy
                                                                                   double result = solver.solve(0.0, 1.0, 0.5);
                                                                                   
                                                                                   // Verify - in original version, this should return the initial value (0.5)
                                                                                   // In mutant version, it would continue searching and potentially return something else
                                                                                   assertEquals(0.5, result, 0.0);
                                                                                   
                                                                                   // Additional verification that function was evaluated at initial point
                                                                                   verify(f).value(0.5);
                                                                               }

    @Test
                                                                           public void testSolve_InitialValueExactlyAtAccuracyThreshold1() {
                                                                               // Setup
                                                                               double min = 0.0;
                                                                               double max = 2.0;
                                                                               double initial = 1.0;
                                                                               double functionValueAccuracy = 1e-6;
                                                                               
                                                                               // Create mock function that returns exactly the accuracy threshold at initial point
                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                               try {
                                                                                   when(f.value(initial)).thenReturn(functionValueAccuracy);
                                                                                   when(f.value(min)).thenReturn(-1.0);  // Some value to ensure not a root
                                                                                   when(f.value(max)).thenReturn(1.0);   // Some value to ensure not a root
                                                                               } catch (FunctionEvaluationException e) {
                                                                                   fail("Mock setup failed");
                                                                               }
                                                                               
                                                                               // Create solver with known functionValueAccuracy
                                                                               BrentSolver solver = new BrentSolver(f);
                                                                               // Need to set functionValueAccuracy - assuming it's inherited from parent class
                                                                               // This might require reflection if the field isn't accessible
                                                                               try {
                                                                                   Field field = solver.getClass().getSuperclass().getDeclaredField("functionValueAccuracy");
                                                                                   field.setAccessible(true);
                                                                                   field.set(solver, functionValueAccuracy);
                                                                               } catch (Exception e) {
                                                                                   fail("Failed to set functionValueAccuracy via reflection");
                                                                               }
                                                                               
                                                                               // Test
                                                                               double result = 0;
                                                                               try {
                                                                                   result = solver.solve(min, max, initial);
                                                                               } catch (MaxIterationsExceededException e) {
                                                                                   fail("Max iterations exceeded unexpectedly");
                                                                               } catch (FunctionEvaluationException e) {
                                                                                   fail("Function evaluation failed");
                                                                               }
                                                                               
                                                                               // Verify
                                                                               // Original code should return initial point since |yInitial| == functionValueAccuracy
                                                                               // Mutant would continue searching and return something else
                                                                               assertEquals("Should return initial point when function value equals accuracy threshold", 
                                                                                            initial, result, 0.0);
                                                                               
                                                                               // Verify mock interactions
                                                                               try {
                                                                                   verify(f).value(initial);
                                                                                   verify(f).value(min);
                                                                                   verify(f, never()).value(max);  // Shouldn't check max since initial was accepted
                                                                               } catch (FunctionEvaluationException e) {
                                                                                   fail("Mock verification failed");
                                                                               }
                                                                           }

    @Test
                                                                      public void testBracketingConditionWithZeroFunctionValue() throws Exception {
                                                                          // Create mock function that returns zero at x=1.0
                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                          when(f.value(0.0)).thenReturn(-1.0);
                                                                          when(f.value(1.0)).thenReturn(0.0);
                                                                          when(f.value(2.0)).thenReturn(1.0);
                                                                          
                                                                          // Create solver with default settings
                                                                          BrentSolver solver = new BrentSolver(f);
                                                                          
                                                                          try {
                                                                              // Test case where yMin is exactly zero (x=1.0, y=0.0)
                                                                              double result = solver.solve(f, 0.0, 2.0, 1.0);
                                                                              
                                                                              // Verify the result is correct (should be 1.0 where f(1.0)=0)
                                                                              assertEquals(1.0, result, 1e-6);
                                                                              
                                                                              // Also test case where yInitial is exactly zero
                                                                              result = solver.solve(f, -1.0, 1.0, 0.0);
                                                                              assertEquals(0.0, result, 1e-6);
                                                                              
                                                                              // Test case where yInitial*yMin < 0 (no zero values)
                                                                              when(f.value(-1.0)).thenReturn(-1.0);
                                                                              when(f.value(1.0)).thenReturn(1.0);
                                                                              result = solver.solve(f, -1.0, 1.0, 0.5);
                                                                              assertTrue("Result should be between -1 and 1", result >= -1.0 && result <= 1.0);
                                                                              
                                                                          } catch (Exception e) {
                                                                              fail("Should not throw exception for zero function value at endpoint");
                                                                          }
                                                                      }

    @Test
                                                                  public void testSolveWithZeroFunctionValueAtEndpointShouldNotBracket() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                      // Create a mock function that returns 0 at min and some value at initial
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(0.0)).thenReturn(0.0);  // yMin = 0
                                                                      when(f.value(1.0)).thenReturn(2.0);  // yInitial = 2
                                                                      
                                                                      BrentSolver solver = new BrentSolver();
                                                                      
                                                                      try {
                                                                          // Test with min=0 (y=0), initial=1 (y=2), max=2
                                                                          // yInitial * yMin = 0, which should NOT be considered bracketing
                                                                          // If mutant is present, it will incorrectly accept this case
                                                                          double result = solver.solve(f, 0.0, 2.0, 1.0);
                                                                          
                                                                          // If we get here, the mutant survived (wrong behavior)
                                                                          // We should verify the result is not just any value
                                                                          // Since the original would throw an exception, any result here means mutant survived
                                                                          fail("Expected IllegalArgumentException for non-bracketing condition");
                                                                      } catch (IllegalArgumentException e) {
                                                                          // Original behavior - expected exception
                                                                          assertTrue(e.getMessage().contains("function values at endpoints must have different signs"));
                                                                      }
                                                                  }

    @Test
                                                                  public void testSolveWithNegativeProductShouldBracket() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                      // Create a mock function with proper bracketing (negative product)
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(0.0)).thenReturn(-1.0);  // yMin = -1
                                                                      when(f.value(1.0)).thenReturn(2.0);   // yInitial = 2
                                                                      
                                                                      BrentSolver solver = new BrentSolver();
                                                                      
                                                                      try {
                                                                          // This case should be accepted by both original and mutant
                                                                          double result = solver.solve(f, 0.0, 2.0, 1.0);
                                                                          // No exception expected - test passes
                                                                      } catch (IllegalArgumentException e) {
                                                                          fail("Valid bracketing condition should not throw exception");
                                                                      }
                                                                  }

    @Test(expected = FunctionEvaluationException.class)
                                                                  public void testSolveWithZeroFunctionValueShouldThrowException() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                      // Setup
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(1.0)).thenReturn(0.0);  // yMin is zero
                                                                      when(f.value(2.0)).thenReturn(1.0);   // yInitial is positive
                                                                      
                                                                      BrentSolver solver = new BrentSolver(f);
                                                                      
                                                                      // This should throw exception because yMin is exactly 0
                                                                      // Original would throw (correct behavior), mutant would proceed
                                                                      solver.solve(f, 1.0, 3.0, 2.0);
                                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                                  public void testSolveWithBothZeroFunctionValuesShouldThrowException() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                      // Setup
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(1.0)).thenReturn(0.0);  // yMin is zero
                                                                      when(f.value(2.0)).thenReturn(0.0);  // yInitial is zero
                                                                      
                                                                      BrentSolver solver = new BrentSolver(f);
                                                                      
                                                                      // This should throw exception because both are zero
                                                                      // Original would throw (correct behavior), mutant would proceed
                                                                      solver.solve(f, 1.0, 3.0, 2.0);
                                                                  }

    @Test
                                                                  public void testSolve_DetectMutant_YInitialTimesYMinEqualsZero() throws FunctionEvaluationException {
                                                                      // Create a mock function where yMin is exactly 0 (but not within functionValueAccuracy)
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(0.0)).thenReturn(1.0);  // yInitial = 1.0
                                                                      when(f.value(1.0)).thenReturn(0.0);  // yMin = 0.0 (exactly)
                                                                      when(f.value(2.0)).thenReturn(-1.0); // yMax = -1.0
                                                                      
                                                                      // Create solver with tight accuracy to ensure 0.0 isn't considered "good enough"
                                                                      BrentSolver solver = new BrentSolver(f);
                                                                      solver.setFunctionValueAccuracy(1e-10);
                                                                      
                                                                      // Test case where yInitial*yMin = 0 (1.0 * 0.0 = 0)
                                                                      // Original code would proceed to check other conditions
                                                                      // Mutated code would take the early return path incorrectly
                                                                      try {
                                                                          double result = solver.solve(1.0, 2.0, 0.0);
                                                                          
                                                                          // Verify it didn't take the early return path (would return 1.0 if it did)
                                                                          // Instead should proceed to full algorithm and find root at 1.5 (midpoint)
                                                                          // Since we're mocking, we'll just verify it didn't return 1.0
                                                                          assertNotEquals(1.0, result, 0.0);
                                                                          
                                                                          // Also verify the full algorithm would be called by checking f was called with max value
                                                                          verify(f).value(2.0);
                                                                      } catch (Exception e) {
                                                                          fail("Should not throw exception for this case");
                                                                      }
                                                                  }

    @Test
                                                                  public void testSolveWithInitialValueExactlyZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                      // Create mock function that returns 0 at initial point and negative at min
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(1.0)).thenReturn(-1.0);
                                                                      when(f.value(2.0)).thenReturn(0.0);  // initial point is exactly zero
                                                                      when(f.value(3.0)).thenReturn(1.0);
                                                                      
                                                                      BrentSolver solver = new BrentSolver(f);
                                                                      
                                                                      // Test with initial point exactly at root (yInitial = 0)
                                                                      double result = solver.solve(1.0, 3.0, 2.0);
                                                                      
                                                                      // Should return the initial point directly (2.0) without going into internal solver
                                                                      assertEquals(2.0, result, 0.0001);
                                                                      
                                                                      // Verify the function was evaluated at the points we expect
                                                                      verify(f).value(1.0);
                                                                      verify(f).value(3.0);
                                                                      verify(f).value(2.0);
                                                                  }

    @Test
                                                                  public void testSolveWithMinValueExactlyZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                      // Create mock function that returns 0 at min and positive at max
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(0.0)).thenReturn(0.0);  // min is exactly zero
                                                                      when(f.value(1.0)).thenReturn(1.0);
                                                                      
                                                                      BrentSolver solver = new BrentSolver(f);
                                                                      
                                                                      // Test with min point exactly at root (yMin = 0)
                                                                      double result = solver.solve(0.0, 1.0);
                                                                      
                                                                      // Should return the min point directly (0.0) without going into internal solver
                                                                      assertEquals(0.0, result, 0.0001);
                                                                      
                                                                      // Verify the function was evaluated at the points we expect
                                                                      verify(f).value(0.0);
                                                                      verify(f).value(1.0);
                                                                  }

    @Test
                                                                  public void testBracketingConditionWithZeroValue2() throws Exception {
                                                                      // Create mock function that returns 0 at min and positive at max
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(0.0)).thenReturn(0.0);  // yMin = 0
                                                                      when(f.value(1.0)).thenReturn(1.0);  // yMax = 1
                                                                      
                                                                      BrentSolver solver = new BrentSolver();
                                                                      
                                                                      try {
                                                                          // This should pass in original version (0*1 = 0 is not > 0)
                                                                          // But fail in mutated version (0*1 = 0 is >= 0)
                                                                          solver.solve(f, 0.0, 1.0);
                                                                          
                                                                          // If we get here, the original version passed (correct)
                                                                          // We need to verify the behavior was correct
                                                                          // Since we can't easily verify the internal behavior, we'll assume
                                                                          // that if no exception was thrown, the bracketing was accepted
                                                                          // (which is correct for original, incorrect for mutant)
                                                                      } catch (IllegalArgumentException e) {
                                                                          // Mutant would throw exception because it thinks [0,1] is non-bracketing
                                                                          // when one value is zero
                                                                          fail("Original version should accept interval with one zero value");
                                                                      }
                                                                  }

    @Test
                                                                  public void testBracketingConditionWithOppositeSigns() throws Exception {
                                                                      // Test case where signs are opposite (valid bracketing)
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(-1.0)).thenReturn(-1.0);  // yMin = -1
                                                                      when(f.value(1.0)).thenReturn(1.0);    // yMax = 1
                                                                      
                                                                      BrentSolver solver = new BrentSolver();
                                                                      
                                                                      try {
                                                                          solver.solve(f, -1.0, 1.0);
                                                                          // Both original and mutant should accept this
                                                                      } catch (IllegalArgumentException e) {
                                                                          fail("Both versions should accept interval with opposite signs");
                                                                      }
                                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                                  public void testNonBracketingCondition() throws Exception {
                                                                      // Test case where both values are positive (invalid bracketing)
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(1.0)).thenReturn(1.0);    // yMin = 1
                                                                      when(f.value(2.0)).thenReturn(2.0);    // yMax = 2
                                                                      
                                                                      BrentSolver solver = new BrentSolver();
                                                                      solver.solve(f, 1.0, 2.0);
                                                                      // Both original and mutant should reject this
                                                                  }

    @Test
                                                                  public void testSolve_WhenYMinIsExactlyZero_ShouldReturnMin() throws Exception {
                                                                      // Setup
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(1.0)).thenReturn(0.0);  // yMin = 0
                                                                      when(f.value(2.0)).thenReturn(1.0);  // yMax = 1
                                                                      
                                                                      BrentSolver solver = new BrentSolver(f);
                                                                      solver.setFunctionValueAccuracy(1e-6);
                                                                      
                                                                      // Test
                                                                      double result = solver.solve(1.0, 2.0);
                                                                      
                                                                      // Verify
                                                                      assertEquals(1.0, result, 0.0);
                                                                  }

    @Test
                                                                  public void testSolve_WhenYMaxIsExactlyZero_ShouldReturnMax() throws Exception {
                                                                      // Setup
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(1.0)).thenReturn(-1.0);  // yMin = -1
                                                                      when(f.value(2.0)).thenReturn(0.0);   // yMax = 0
                                                                      
                                                                      BrentSolver solver = new BrentSolver(f);
                                                                      solver.setFunctionValueAccuracy(1e-6);
                                                                      
                                                                      // Test
                                                                      double result = solver.solve(1.0, 2.0);
                                                                      
                                                                      // Verify
                                                                      assertEquals(2.0, result, 0.0);
                                                                  }

    @Test
                                                                  public void testBracketingWithZeroValue() throws Exception {
                                                                      // Setup mock function
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(1.0)).thenReturn(1.0);  // yMin
                                                                      when(f.value(2.0)).thenReturn(0.0);  // yMax is zero
                                                                      
                                                                      BrentSolver solver = new BrentSolver(f);
                                                                      
                                                                      try {
                                                                          // This should work in original version (proceed with solving)
                                                                          // but mutant version would throw exception due to >= condition
                                                                          solver.solve(f, 1.0, 2.0);
                                                                          
                                                                          // If we get here, original behavior is correct
                                                                          // Verify the function was called at least once
                                                                          verify(f, atLeastOnce()).value(anyDouble());
                                                                      } catch (IllegalArgumentException e) {
                                                                          // If we get here, mutant was detected
                                                                          fail("Mutant detected: Original should proceed when one value is zero");
                                                                      }
                                                                  }

    @Test
                                                                  public void testBracketingWithBothPositive() throws Exception {
                                                                      // Setup mock function
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(1.0)).thenReturn(1.0);  // yMin
                                                                      when(f.value(2.0)).thenReturn(1.0);  // yMax
                                                                      
                                                                      BrentSolver solver = new BrentSolver(f);
                                                                      
                                                                      try {
                                                                          solver.solve(f, 1.0, 2.0);
                                                                          fail("Should throw exception when both values are positive");
                                                                      } catch (IllegalArgumentException e) {
                                                                          // Expected behavior for both original and mutant
                                                                          assertTrue(true);
                                                                      }
                                                                  }

    @Test
                                                                  public void testBracketingWithZeroAndZero() throws Exception {
                                                                      // Setup mock function
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(1.0)).thenReturn(0.0);  // yMin
                                                                      when(f.value(2.0)).thenReturn(0.0);  // yMax
                                                                      
                                                                      BrentSolver solver = new BrentSolver(f);
                                                                      
                                                                      try {
                                                                          solver.solve(f, 1.0, 2.0);
                                                                          // Both original and mutant should throw here
                                                                          fail("Should throw exception when both values are zero");
                                                                      } catch (IllegalArgumentException e) {
                                                                          // Expected behavior
                                                                          assertTrue(true);
                                                                      }
                                                                  }

    @Test
                                                         public void testSolveWithOneEndpointZeroShouldNotThrowException() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                             // Setup
                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                             when(f.value(1.0)).thenReturn(1.0);  // yMin = 1.0 (positive)
                                                             when(f.value(2.0)).thenReturn(0.0);  // yMax = 0.0
                                                             
                                                             BrentSolver solver = new BrentSolver(f);
                                                             
                                                             // Test - should not throw exception in original code
                                                             // Mutant would throw exception here due to >= condition
                                                             try {
                                                                 double result = solver.solve(f, 1.0, 2.0);
                                                                 // If we get here, the test passes (original behavior)
                                                                 // We can optionally assert the result is approximately the root (2.0)
                                                                 assertEquals(2.0, result, 1e-6);
                                                             } catch (IllegalArgumentException e) {
                                                                 // If exception is thrown, mutant is detected
                                                                 fail("Original code should accept interval with one endpoint zero");
                                                             }
                                                         }

    @Test
                                                         public void testSolveWithExactZeroEndpointShouldNotThrowException() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                             // Setup
                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                             when(f.value(1.0)).thenReturn(-1.0);  // yMin
                                                             when(f.value(2.0)).thenReturn(0.0);   // yMax (exactly zero)
                                                             when(f.value(1.5)).thenReturn(0.5);   // yInitial
                                                             
                                                             BrentSolver solver = new BrentSolver(f);
                                                             
                                                             // Test - should not throw exception in original, would throw in mutant
                                                             double result = solver.solve(f, 1.0, 2.0, 1.5);
                                                             
                                                             // Verify - original would return max (2.0) as solution
                                                             assertEquals(2.0, result, 0.0001);
                                                             
                                                             // Verify function was called with expected values
                                                             verify(f).value(1.0);
                                                             verify(f).value(2.0);
                                                             verify(f).value(1.5);
                                                         }

    @Test
                                                         public void testSolveWithExactZeroEndpointShouldThrowExceptionInMutant() throws Exception {
                                                             // This test simulates the mutant behavior where >= is used instead of >
                                                             // In reality, we can't test the mutant directly, but this shows what would happen
                                                             
                                                             // Setup same as above
                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                             when(f.value(1.0)).thenReturn(-1.0);
                                                             when(f.value(2.0)).thenReturn(0.0);   // yMax exactly zero
                                                             when(f.value(1.5)).thenReturn(0.5);
                                                             
                                                             // Get the private NON_BRACKETETING_MESSAGE field via reflection
                                                             Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                                             field.setAccessible(true);
                                                             String nonBracketingMsg = (String) field.get(null);
                                                             
                                                             // Create a mock solver that behaves like the mutant
                                                             BrentSolver solver = new BrentSolver(f) {
                                                                 @Override
                                                                 public double solve(UnivariateRealFunction f, double min, double max, double initial) throws FunctionEvaluationException {
                                                                     double yMin = f.value(min);
                                                                     double yMax = f.value(max);
                                                                     if (yMin * yMax >= 0) {  // Mutant condition
                                                                         throw MathRuntimeException.createIllegalArgumentException(
                                                                             nonBracketingMsg, min, max, yMin, yMax);
                                                                     }
                                                                     return max; // simplified for test
                                                                 }
                                                             };
                                                             
                                                             // This will throw exception in mutant behavior
                                                             solver.solve(f, 1.0, 2.0, 1.5);
                                                         }

    @Test
                                                         public void testSolveParameterOrderMattersForBracketing() throws Exception {
                                                             // Create a mock function that returns different values at min and max
                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                             when(f.value(1.0)).thenReturn(-1.0);  // yMin
                                                             when(f.value(2.0)).thenReturn(1.0);   // yMax
                                                             when(f.value(1.5)).thenReturn(0.5);   // yInitial
                                                             
                                                             BrentSolver solver = new BrentSolver();
                                                             
                                                             // Test with proper bracketing (f(min) and f(max) have opposite signs)
                                                             double result = solver.solve(f, 1.0, 2.0, 1.5);
                                                             
                                                             // The mutation would swap min and max, causing both function values to be positive
                                                             // which should throw an exception since bracketing condition is violated
                                                             // So we just verify that with correct parameters, we get a valid result
                                                             assertTrue("Should return a value between min and max", 
                                                                       result >= 1.0 && result <= 2.0);
                                                             
                                                             // Now verify the mock was called with correct parameter order
                                                             // This is the key assertion that would catch the mutant
                                                             verify(f).value(1.0);  // min
                                                             verify(f).value(2.0);  // max
                                                             verify(f).value(1.5);  // initial
                                                         }

    @Test
                                                         public void testSolveParameterOrderMatters() throws Exception {
                                                             // Create a mock function that behaves differently on left vs right side of root
                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                             when(f.value(1.0)).thenReturn(-2.0);  // min
                                                             when(f.value(2.0)).thenReturn(3.0);   // max
                                                             when(f.value(1.5)).thenReturn(0.5);   // initial
                                                             
                                                             // The function crosses zero between min and max
                                                             // The exact root location depends on how the solver uses the min/max values
                                                             // Since the mutation swaps min/max, the numerical path to solution will differ
                                                             
                                                             BrentSolver solver = new BrentSolver(f);
                                                             
                                                             // Call the public solve method which should delegate to private solve
                                                             double result = solver.solve(1.0, 2.0, 1.5);
                                                             
                                                             // Verify the function was called with expected values
                                                             // The key assertion is that the result is correct despite parameter order
                                                             // For a proper test, we'd need to know the expected root location
                                                             // Since we don't have the actual implementation, we'll verify it's in the interval
                                                             assertTrue("Result should be between min and max", result >= 1.0 && result <= 2.0);
                                                             
                                                             // More precise test would verify against known root of test function
                                                             // For this case, we can verify the function was called with proper parameters
                                                             verify(f, atLeastOnce()).value(1.0);
                                                             verify(f, atLeastOnce()).value(2.0);
                                                             verify(f, atLeastOnce()).value(1.5);
                                                             
                                                             // The mutation would cause different internal behavior that might lead to
                                                             // different iteration counts or slightly different numerical results
                                                             // A stronger test would compare against a known expected value
                                                             double expectedRoot = 1.8; // example expected value
                                                             double tolerance = 1e-6;
                                                             assertEquals("Root not found with expected accuracy", 
                                                                         expectedRoot, result, tolerance);
                                                         }

    @Test
                                                    public void testSolveWithBracketingIntervalDetectsParameterOrderMutant() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                        // Create a mock function that requires multiple iterations
                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                        
                                                        // Set up the mock behavior
                                                        when(f.value(1.0)).thenReturn(-1.0);  // yMin
                                                        when(f.value(3.0)).thenReturn(1.0);   // yMax
                                                        when(f.value(2.0)).thenReturn(0.5);   // yInitial
                                                        
                                                        // The function should be called with progressively smaller intervals
                                                        // in the correct order (1.0 to 3.0)
                                                        when(f.value(anyDouble())).thenAnswer(invocation -> {
                                                            double x = invocation.getArgument(0);
                                                            return x - 2.0;  // root at 2.0
                                                        });
                                                        
                                                        BrentSolver solver = new BrentSolver(f);
                                                        double result = solver.solve(1.0, 3.0, 2.0);
                                                        
                                                        // Verify the correct sequence of calls would be made
                                                        // The mutation would cause the solver to work backwards (3.0 to 1.0)
                                                        // First verify the initial checks
                                                        verify(f).value(1.0);
                                                        verify(f).value(2.0);
                                                        verify(f).value(3.0);
                                                        
                                                        // Then verify the solve method would be called with correct parameter order
                                                        // This is the key assertion that would fail with the mutant
                                                        // We can't directly verify the private solve method calls, but we can
                                                        // verify the final result and that the function was evaluated in the
                                                        // expected range
                                                        assertEquals(2.0, result, 1e-6);
                                                        
                                                        // Verify that values were evaluated in the expected range (1.0 to 3.0)
                                                        // The mutant would evaluate values between 3.0 and 1.0
                                                        verify(f, atLeastOnce()).value(argThat(x -> x >= 1.0 && x <= 3.0));
                                                    }

    @Test
                                                    public void testSolveParameterOrderAffectsResult() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                        // Create a mock function that is not symmetric and has different values at min and max
                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                        when(f.value(1.0)).thenReturn(-2.0);  // yMin
                                                        when(f.value(4.0)).thenReturn(3.0);   // yMax
                                                        
                                                        // The actual root is at x=2, but our mock will return values that make the solver work
                                                        when(f.value(anyDouble())).thenAnswer(inv -> {
                                                            double x = inv.getArgument(0);
                                                            return x - 2.0;  // root at x=2
                                                        });
                                                        
                                                        BrentSolver solver = new BrentSolver(f);
                                                        double result = solver.solve(1.0, 4.0);
                                                        
                                                        // Verify the result is correct (should find root at 2.0)
                                                        assertEquals(2.0, result, 1e-6);
                                                        
                                                        // Verify the function was called with expected parameters
                                                        // This ensures the solver used the correct parameter order
                                                        verify(f).value(1.0);  // min
                                                        verify(f).value(4.0);  // max
                                                        verify(f, atLeastOnce()).value(2.0);  // the root
                                                        
                                                        // The key verification - if parameters were swapped, the solver might not converge
                                                        // or take different number of steps. We verify it found the correct root.
                                                        // A mutant that swaps parameters would likely fail to find the correct root
                                                        // or take a different path to get there.
                                                    }

    @Test
                                                public void testSolveWithAsymmetricFunctionDetectsParameterOrderMutant() throws MaxIterationsExceededException {
                                                    // Create an asymmetric test function where f(1) = -1, f(3) = 1, root at 2
                                                    UnivariateRealFunction f = new UnivariateRealFunction() {
                                                        @Override
                                                        public double value(double x) throws FunctionEvaluationException {
                                                            return x - 2;  // Simple linear function with root at x=2
                                                        }
                                                    };
                                                    
                                                    BrentSolver solver = new BrentSolver();
                                                    
                                                    // Test with min=1, max=3, initial=2
                                                    double min = 1;
                                                    double max = 3;
                                                    double initial = 2;
                                                    double yMin = 0, yMax = 0, yInitial = 0;
                                                    try {
                                                        yMin = f.value(min);  // -1
                                                        yMax = f.value(max);  // 1
                                                        yInitial = f.value(initial);  // 0
                                                    } catch (FunctionEvaluationException e) {
                                                        fail("Function evaluation failed: " + e.getMessage());
                                                    }
                                                    
                                                    // The correct implementation should find the root at 2 immediately
                                                    double result = 0;
                                                    try {
                                                        result = solver.solve(f, min, max, initial);
                                                    } catch (FunctionEvaluationException e) {
                                                        fail("Function evaluation failed: " + e.getMessage());
                                                    }
                                                    
                                                    // Verify the result is correct (should be 2)
                                                    assertEquals(2.0, result, 1e-6);
                                                    
                                                    // Also verify with swapped min/max - should still work correctly
                                                    double swappedResult = 0;
                                                    try {
                                                        swappedResult = solver.solve(f, max, min, initial);
                                                    } catch (FunctionEvaluationException e) {
                                                        fail("Function evaluation failed: " + e.getMessage());
                                                    }
                                                    assertEquals(2.0, swappedResult, 1e-6);
                                                    
                                                    // Now test the private solve method's behavior through reflection
                                                    try {
                                                        Method privateSolve = BrentSolver.class.getDeclaredMethod(
                                                            "solve", 
                                                            UnivariateRealFunction.class, 
                                                            double.class, double.class, 
                                                            double.class, double.class, 
                                                            double.class, double.class
                                                        );
                                                        privateSolve.setAccessible(true);
                                                        
                                                        // Call with original parameter order
                                                        double originalOrderResult = (double) privateSolve.invoke(
                                                            solver, f, min, yMin, max, yMax, initial, yInitial
                                                        );
                                                        
                                                        // Call with swapped parameter order (like the mutant)
                                                        double swappedOrderResult = (double) privateSolve.invoke(
                                                            solver, f, max, yMax, min, yMin, initial, yInitial
                                                        );
                                                        
                                                        // Both should give same result for this symmetric case
                                                        assertEquals(originalOrderResult, swappedOrderResult, 1e-6);
                                                        
                                                        // Now test with asymmetric function that would reveal the mutant
                                                        UnivariateRealFunction asymmetricF = new UnivariateRealFunction() {
                                                            @Override
                                                            public double value(double x) throws FunctionEvaluationException {
                                                                return (x < 2) ? -1 : (x - 2);  // Flat on left, linear on right
                                                            }
                                                        };
                                                        
                                                        double asymYMin = 0, asymYMax = 0, asymYInitial = 0;
                                                        try {
                                                            asymYMin = asymmetricF.value(min);
                                                            asymYMax = asymmetricF.value(max);
                                                            asymYInitial = asymmetricF.value(initial);
                                                        } catch (FunctionEvaluationException e) {
                                                            fail("Function evaluation failed: " + e.getMessage());
                                                        }
                                                        
                                                        double correctResult = (double) privateSolve.invoke(
                                                            solver, asymmetricF, min, asymYMin, max, asymYMax, initial, asymYInitial
                                                        );
                                                        
                                                        double mutantResult = (double) privateSolve.invoke(
                                                            solver, asymmetricF, max, asymYMax, min, asymYMin, initial, asymYInitial
                                                        );
                                                        
                                                        // The mutant would give different results for asymmetric function
                                                        assertNotEquals("Mutant should be detected by asymmetric function test", 
                                                                       correctResult, mutantResult, 1e-6);
                                                        
                                                    } catch (Exception e) {
                                                        fail("Reflection failed: " + e.toString());
                                                    }
                                                }

    @Test
                                            public void testSolveClearsPreviousResults() throws Exception {
                                                // Setup mock function that returns different values for different inputs
                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                when(f.value(1.0)).thenReturn(-1.0);
                                                when(f.value(2.0)).thenReturn(1.0);  // root at x=1.5 (first test)
                                                when(f.value(3.0)).thenReturn(-1.0);
                                                when(f.value(4.0)).thenReturn(1.0);  // root at x=3.5 (second test)
                                                
                                                BrentSolver solver = new BrentSolver();
                                                
                                                // First solve call - should find root near 1.5
                                                double firstRoot = solver.solve(f, 1.0, 2.0);
                                                assertEquals(1.5, firstRoot, 0.0001);
                                                
                                                // Second solve call with different range - should find root near 3.5
                                                // If clearResult() was called, this should work correctly
                                                // If not (mutant case), might give wrong result based on first call's state
                                                double secondRoot = solver.solve(f, 3.0, 4.0);
                                                assertEquals(3.5, secondRoot, 0.0001);
                                                
                                                // Verify the mock was called with expected values
                                                verify(f).value(1.0);
                                                verify(f).value(2.0);
                                                verify(f).value(3.0);
                                                verify(f).value(4.0);
                                            }

    @Test
                                            public void testSolveClearsPreviousResult5() throws Exception {
                                                // Create mock function that returns different values for testing
                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                when(f.value(1.0)).thenReturn(-1.0);
                                                when(f.value(2.0)).thenReturn(1.0);
                                                when(f.value(1.5)).thenReturn(0.0);  // root at 1.5
                                                
                                                // First create solver and perform initial solve
                                                BrentSolver solver = new BrentSolver(f);
                                                double firstResult = solver.solve(f, 1.0, 2.0, 1.5);
                                                assertEquals(1.5, firstResult, 1e-6);
                                                
                                                // Change mock behavior for second test
                                                when(f.value(3.0)).thenReturn(-1.0);
                                                when(f.value(4.0)).thenReturn(1.0);
                                                when(f.value(3.5)).thenReturn(0.0);  // new root at 3.5
                                                
                                                // Perform second solve - should not be affected by first solve
                                                double secondResult = solver.solve(f, 3.0, 4.0, 3.5);
                                                assertEquals(3.5, secondResult, 1e-6);
                                                
                                                // If clearResult() was not called, the second solve might return the first result
                                                // or behave incorrectly due to stale internal state
                                            }

    @Test
                                            public void testSolveClearsPreviousResult6() throws Exception {
                                                // Create mock function that returns different values for different calls
                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                when(f.value(1.0)).thenReturn(0.0);  // root at 1.0 for first test
                                                when(f.value(2.0)).thenReturn(0.0);  // root at 2.0 for second test
                                                
                                                BrentSolver solver = new BrentSolver(f);
                                                
                                                // First call - should find root at 1.0
                                                double result1 = solver.solve(0.0, 3.0, 1.0);
                                                assertEquals(1.0, result1, 1e-6);
                                                
                                                // Second call - should find root at 2.0 independently
                                                double result2 = solver.solve(0.0, 3.0, 2.0);
                                                assertEquals(2.0, result2, 1e-6);
                                                
                                                // Verify that the second result isn't affected by first call
                                                // If clearResult() is commented out, the second result might be incorrect
                                                // or the method might use stale data from first computation
                                            }

    @Test
                                            public void testClearResultCalledBetweenSolveCalls() throws Exception {
                                                // Setup mock function that returns different values for different inputs
                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                when(f.value(0.0)).thenReturn(-1.0);
                                                when(f.value(1.0)).thenReturn(1.0);
                                                when(f.value(2.0)).thenReturn(-2.0);
                                                when(f.value(3.0)).thenReturn(3.0);
                                                
                                                // Create solver with mock function
                                                BrentSolver solver = new BrentSolver(f);
                                                
                                                // First solve call - should find root between 0 and 1
                                                double firstResult = solver.solve(0.0, 1.0);
                                                
                                                // Second solve call with different interval - should find root between 2 and 3
                                                // If clearResult() wasn't called, might be affected by first call's state
                                                double secondResult = solver.solve(2.0, 3.0);
                                                
                                                // Verify both results are correct and independent
                                                // The exact root values would depend on the solver implementation,
                                                // but we can verify they're within their respective intervals
                                                assertTrue("First result should be between 0 and 1", firstResult >= 0.0 && firstResult <= 1.0);
                                                assertTrue("Second result should be between 2 and 3", secondResult >= 2.0 && secondResult <= 3.0);
                                                
                                                // Additionally, verify they're not equal (would indicate state wasn't cleared)
                                                assertNotEquals("Results from different intervals should not be equal", 
                                                               firstResult, secondResult, 0.0001);
                                            }

    @Test
                                                public void testSolveClearsPreviousResult7() throws Exception {
                                                    // Setup mock function that returns different values for different inputs
                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                    when(f.value(1.0)).thenReturn(-1.0);
                                                    when(f.value(2.0)).thenReturn(1.0);  // Root at x=1.5
                                                    when(f.value(3.0)).thenReturn(-2.0);
                                                    when(f.value(4.0)).thenReturn(2.0);  // Root at x=3.5
                                                    
                                                    // Create solver with default accuracy settings
                                                    BrentSolver solver = new BrentSolver(f);
                                                    
                                                    // First solution - should find root at 1.5
                                                    double firstRoot = solver.solve(1.0, 2.0);
                                                    assertEquals(1.5, firstRoot, 0.0001);
                                                    
                                                    // Second solution - should find root at 3.5 independently
                                                    // If clearResult() was not called, this might be affected by previous solution
                                                    double secondRoot = solver.solve(3.0, 4.0);
                                                    assertEquals(3.5, secondRoot, 0.0001);
                                                    
                                                    // Verify the second solution wasn't affected by first solution's state
                                                    // This would fail if clearResult() was not called between solves
                                                    assertNotEquals(firstRoot, secondRoot, 0.0001);
                                                }

    @Test
                                               public void testBracketingCondition() throws Exception {
                                                   // Setup mock function
                                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                   
                                                   // Case 1: yInitial * yMin is negative (should be accepted)
                                                   when(f.value(1.0)).thenReturn(-1.0);
                                                   when(f.value(2.0)).thenReturn(1.0);
                                                   BrentSolver solver1 = new BrentSolver(f);
                                                   double result1 = solver1.solve(1.0, 2.0);
                                                   assertNotNull(result1);
                                                   
                                                   // Case 2: yInitial * yMin is positive (should be rejected)
                                                   when(f.value(1.0)).thenReturn(1.0);
                                                   when(f.value(2.0)).thenReturn(1.0);
                                                   BrentSolver solver2 = new BrentSolver(f);
                                                   try {
                                                       solver2.solve(1.0, 2.0);
                                                       fail("Should throw IllegalArgumentException for non-bracketing interval");
                                                   } catch (IllegalArgumentException e) {
                                                       // Expected
                                                   }
                                                   
                                                   // Case 3: yInitial * yMin is exactly zero (should be rejected in original)
                                                   when(f.value(1.0)).thenReturn(0.0);
                                                   when(f.value(2.0)).thenReturn(1.0);
                                                   BrentSolver solver3 = new BrentSolver(f);
                                                   try {
                                                       solver3.solve(1.0, 2.0);
                                                       fail("Should throw IllegalArgumentException when product is exactly zero");
                                                   } catch (IllegalArgumentException e) {
                                                       // Expected - this will catch the mutant if it accepts zero product
                                                   }
                                               }

    @Test
                                  public void testBracketingConditionWithZeroValue3() throws FunctionEvaluationException, MaxIterationsExceededException {
                                      // Create mock function that returns zero at min point
                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                      when(f.value(1.0)).thenReturn(0.0);  // yMin = 0
                                      when(f.value(2.0)).thenReturn(1.0);   // yInitial = 1
                                      
                                      BrentSolver solver = new BrentSolver(f);
                                      
                                      try {
                                          // This should throw IllegalArgumentException in original code
                                          // because yMin is zero (not proper bracketing)
                                          // But mutant will accept it (<= instead of <)
                                          solver.solve(1.0, 3.0, 2.0);
                                          fail("Expected IllegalArgumentException for zero value at min point");
                                      } catch (IllegalArgumentException e) {
                                          // Expected behavior for original code
                                          assertTrue(e.getMessage().contains("function values at endpoints must have different signs"));
                                      }
                                      
                                      // Also test case where yInitial is zero
                                      when(f.value(1.0)).thenReturn(1.0);   // yMin = 1
                                      when(f.value(2.0)).thenReturn(0.0);   // yInitial = 0
                                      
                                      try {
                                          solver.solve(1.0, 3.0, 2.0);
                                          fail("Expected IllegalArgumentException for zero value at initial point");
                                      } catch (IllegalArgumentException e) {
                                          // Expected behavior for original code
                                          assertTrue(e.getMessage().contains("function values at endpoints must have different signs"));
                                      }
                                  }

    @Test
                                  public void testProperBracketingCondition() throws FunctionEvaluationException, MaxIterationsExceededException {
                                      // Test proper bracketing case (opposite signs)
                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                      when(f.value(1.0)).thenReturn(-1.0);  // yMin = -1
                                      when(f.value(2.0)).thenReturn(1.0);   // yInitial = 1
                                      
                                      BrentSolver solver = new BrentSolver(f);
                                      
                                      try {
                                          // This should be accepted by both original and mutant
                                          solver.solve(1.0, 3.0, 2.0);
                                      } catch (IllegalArgumentException e) {
                                          fail("Valid bracketing condition should not throw exception");
                                      }
                                  }

    @Test
                                  public void testSolveDoesNotUseBracketingWhenProductIsZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                                      // Setup mock function with specific values
                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                      when(f.value(1.0)).thenReturn(0.0);  // initial guess returns exactly 0
                                      when(f.value(0.0)).thenReturn(2.0);  // min returns 2
                                      when(f.value(2.0)).thenReturn(-1.0); // max returns -1
                                      
                                      // Create solver with tight accuracy to ensure 0.0 isn't considered accurate enough
                                      BrentSolver solver = new BrentSolver(f);
                                      solver.setFunctionValueAccuracy(1e-10);
                                      
                                      // The test case where initial * min = 0 * 2 = 0
                                      // Original code should proceed to check max, mutated code would take the bracketing path
                                      double result = solver.solve(0.0, 2.0, 1.0);
                                      
                                      // Verify the result came from checking max (not from the bracketing path)
                                      // Since max * initial = -1 * 0 = 0, original would proceed to full Brent algorithm
                                      // We just need to verify it didn't take the first bracketing path
                                      // A proper implementation would return the max (2.0) since it's within accuracy,
                                      // but we mock it to return -1 to verify the path
                                      assertEquals(-1.0, result, 0.0);
                                      
                                      // Verify the mock interactions show it checked all points
                                      verify(f).value(1.0);
                                      verify(f).value(0.0);
                                      verify(f).value(2.0);
                                  }

    @Test
                                  public void testSolveWithInitialZeroDetectsMutant() throws FunctionEvaluationException, MaxIterationsExceededException {
                                      // Setup
                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                      when(f.value(0.0)).thenReturn(0.0);  // yInitial = 0
                                      when(f.value(1.0)).thenReturn(1.0);  // yMin = 1.0
                                      
                                      BrentSolver solver = new BrentSolver(f);
                                      
                                      // Test - this should behave differently with the mutant
                                      double result = solver.solve(1.0, 2.0, 0.0);
                                      
                                      // Verify - with original code, this would take one path, with mutant another
                                      // We can't see internal state, but we can verify the mock interactions
                                      verify(f).value(0.0);
                                      verify(f).value(1.0);
                                      
                                      // Additional assertion to catch the mutant's behavior
                                      // The mutant might return different results when yInitial is zero
                                      // This depends on the exact implementation of the solve method
                                      // Since we can't see the full implementation, we'll check it doesn't throw
                                      // an exception (which it might with the mutant)
                                      assertFalse(Double.isNaN(result));
                                  }

    @Test
                                  public void testSolveWithYMinZeroDetectsMutant() throws FunctionEvaluationException, MaxIterationsExceededException {
                                      // Setup
                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                      when(f.value(1.0)).thenReturn(0.0);  // yMin = 0
                                      when(f.value(2.0)).thenReturn(1.0);  // yMax = 1.0
                                      when(f.value(1.5)).thenReturn(0.5);  // initial = 1.5
                                      
                                      BrentSolver solver = new BrentSolver(f);
                                      
                                      // Test - this should behave differently with the mutant
                                      double result = solver.solve(1.0, 2.0, 1.5);
                                      
                                      // Verify - with original code, this would take one path, with mutant another
                                      verify(f).value(1.0);
                                      verify(f).value(2.0);
                                      verify(f).value(1.5);
                                      
                                      // The original would treat this as a bracketing case (sign < 0)
                                      // The mutant might treat it differently when yMin is exactly zero
                                      assertFalse(Double.isNaN(result));
                                  }

    @Test
                              public void testSolveWithYMinZeroShouldNotBracket1() {
                                  // Create a mock function that returns specific values
                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                  try {
                                      when(f.value(anyDouble())).thenReturn(1.0, 0.0); // yInitial = 1, yMin = 0
                                  } catch (FunctionEvaluationException e) {
                                      fail("Mock setup failed");
                                  }
                                  
                                  BrentSolver solver = new BrentSolver();
                                  String nonBracketingMessage = null;
                                  
                                  try {
                                      // Get the private NON_BRACKETING_MESSAGE field using reflection
                                      Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                      field.setAccessible(true);
                                      nonBracketingMessage = (String) field.get(solver);
                                      
                                      // This should throw an exception since yMin is zero but the mutated version would proceed
                                      try {
                                          solver.solve(f, 0.0, 1.0, 0.5);
                                          fail("Expected IllegalArgumentException for non-bracketing case");
                                      } catch (FunctionEvaluationException e) {
                                          fail("Unexpected FunctionEvaluationException");
                                      } catch (MaxIterationsExceededException e) {
                                          fail("Unexpected MaxIterationsExceededException");
                                      }
                                  } catch (IllegalArgumentException e) {
                                      // Verify the correct exception message
                                      assertTrue(e.getMessage().contains(nonBracketingMessage));
                                  } catch (NoSuchFieldException | IllegalAccessException e) {
                                      fail("Failed to access NON_BRACKETING_MESSAGE field via reflection");
                                  }
                              }

    @Test
                      public void testSolveWithYInitialZeroShouldNotBracket1() {
                          // Create a mock function that returns specific values
                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                          try {
                              doReturn(0.0).doReturn(1.0).when(f).value(anyDouble()); // yInitial = 0, yMin = 1
                          } catch (FunctionEvaluationException e) {
                              fail("Mock setup should not throw FunctionEvaluationException");
                          }
                          
                          BrentSolver solver = new BrentSolver();
                          
                          try {
                              // This should throw an exception since yInitial is zero but the mutated version would proceed
                              solver.solve(f, 0.0, 1.0, 0.5);
                              fail("Expected IllegalArgumentException for non-bracketing case");
                          } catch (IllegalArgumentException e) {
                              // Verify that an exception was thrown without checking the exact message
                              // since we can't access the private constant
                              assertTrue(e.getMessage() != null && !e.getMessage().isEmpty());
                          } catch (FunctionEvaluationException e) {
                              fail("Unexpected FunctionEvaluationException");
                          } catch (MaxIterationsExceededException e) {
                              fail("Unexpected MaxIterationsExceededException");
                          }
                      }

    @Test
                  public void testSolveWithProperBracketingShouldProceed() {
                      // Create a mock function that returns specific values
                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                      try {
                          when(f.value(anyDouble())).thenReturn(-1.0, 1.0); // yInitial = -1, yMin = 1
                      } catch (FunctionEvaluationException e) {
                          fail("Mock setup should not throw FunctionEvaluationException");
                      }
                      
                      BrentSolver solver = new BrentSolver();
                      
                      try {
                          // This should proceed normally as it's proper bracketing
                          solver.solve(f, 0.0, 1.0, 0.5);
                      } catch (FunctionEvaluationException e) {
                          fail("Should not throw FunctionEvaluationException for proper bracketing case");
                      } catch (MaxIterationsExceededException e) {
                          fail("Should not throw MaxIterationsExceededException for proper bracketing case");
                      } catch (IllegalArgumentException e) {
                          fail("Should not throw exception for proper bracketing case");
                      }
                  }

    @Test
                  public void testSolveDetectsOppositeSignBracketing() throws Exception {
                      // Setup mock function with opposite signs at endpoints
                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                      when(f.value(1.0)).thenReturn(-1.0);  // yMin = -1
                      when(f.value(2.0)).thenReturn(1.0);   // yMax = 1
                      
                      // Create solver and set accuracy threshold
                      BrentSolver solver = new BrentSolver(f);
                      // Set functionValueAccuracy to a small value (assuming inherited field)
                      // ReflectionTestUtils.setField(solver, "functionValueAccuracy", 1e-10);
                      
                      // Test - should attempt to solve since signs are opposite
                      double result = solver.solve(f, 1.0, 2.0);
                      
                      // Verify that the solve proceeded (we can't directly verify the private solve call,
                      // but we can verify the mock interactions)
                      verify(f, atLeast(2)).value(anyDouble()); // at least min and max
                      
                      // The mutant would not have proceeded to solve since it checks for >0 instead of <0
                  }

    @Test(expected = IllegalArgumentException.class)
                  public void testSolveThrowsWhenSameSignNotNearZero() throws Exception {
                      // Setup mock function with same signs at endpoints
                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                      when(f.value(1.0)).thenReturn(1.0);  // yMin = 1
                      when(f.value(2.0)).thenReturn(2.0);  // yMax = 2
                      
                      // Create solver
                      BrentSolver solver = new BrentSolver(f);
                      
                      // This should throw since signs are same and values not near zero
                      solver.solve(f, 1.0, 2.0);
                      
                      // The mutant would incorrectly attempt to solve in this case
                  }

    @Test(expected = IllegalArgumentException.class)
             public void testSolve_NonBracketingInterval_ThrowsException() throws Exception {
                 // Setup
                 BrentSolver solver = new BrentSolver();
                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                 
                 // Define test values where y0*y1 > 0 (same signs - invalid bracketing)
                 double x0 = 0.0;
                 double y0 = 1.0;  // positive
                 double x1 = 1.0;
                 double y1 = 2.0;  // positive
                 double x2 = 2.0;
                 double y2 = 3.0;  // positive
                 
                 // Mock function behavior
                 when(f.value(x0)).thenReturn(y0);
                 when(f.value(x1)).thenReturn(y1);
                 when(f.value(x2)).thenReturn(y2);
                 
                 // Get private solve method via reflection
                 Method solveMethod = BrentSolver.class.getDeclaredMethod(
                     "solve", 
                     UnivariateRealFunction.class, 
                     double.class, 
                     double.class, 
                     double.class, 
                     double.class, 
                     double.class, 
                     double.class
                 );
                 solveMethod.setAccessible(true);
                 
                 // Get private message field via reflection
                 Field messageField = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                 messageField.setAccessible(true);
                 String expectedMessage = (String) messageField.get(null);
                 
                 try {
                     // Invoke private solve method
                     solveMethod.invoke(solver, f, x0, y0, x1, y1, x2, y2);
                     fail("Expected IllegalArgumentException");
                 } catch (InvocationTargetException e) {
                     // Verify the correct exception was thrown
                     Throwable cause = e.getCause();
                     assertEquals(IllegalArgumentException.class, cause.getClass());
                     assertEquals(expectedMessage, cause.getMessage());
                     throw (IllegalArgumentException) cause;
                 }
             }

    @Test
         public void testBracketingConditionDetectsOppositeSigns() throws FunctionEvaluationException, MaxIterationsExceededException {
             // Setup - create mock function that returns values with opposite signs
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             when(f.value(anyDouble())).thenReturn(-1.0, 1.0); // first call returns -1, second returns 1
             
             BrentSolver solver = new BrentSolver(f);
             
             try {
                 // This should work in original (opposite signs) but throw in mutant
                 double result = solver.solve(0.0, 1.0, 0.5);
                 // If we get here in original, verify it's a reasonable result
                 assertTrue("Should return value between bounds", result >= 0.0 && result <= 1.0);
             } catch (IllegalArgumentException e) {
                 fail("Original should accept opposite signs but threw: " + e.getMessage());
             }
         }

    @Test(expected = IllegalArgumentException.class)
         public void testBracketingConditionRejectsSameSigns() throws FunctionEvaluationException, MaxIterationsExceededException {
             // Setup - create mock function that returns values with same signs
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             when(f.value(anyDouble())).thenReturn(1.0, 2.0); // both positive
             
             BrentSolver solver = new BrentSolver(f);
             
             // This should throw IllegalArgumentException when signs are same
             solver.solve(0.0, 1.0, 0.5);
         }

    @Test
         public void testSolveDetectsBracketingCondition() throws FunctionEvaluationException, MaxIterationsExceededException {
             // Create mock function
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             
             // Setup test case where yInitial and yMax have opposite signs
             // (yInitial = -1, yMax = 1)
             when(f.value(0.0)).thenReturn(-1.0);  // yInitial
             when(f.value(1.0)).thenReturn(1.0);   // yMax
             
             BrentSolver solver = new BrentSolver(f);
             
             try {
                 // This should work in original code (signs opposite)
                 double result = solver.solve(f, 0.0, 1.0, 0.0);
                 // If we get here, mutant wasn't caught (bad)
                 fail("Expected exception not thrown - mutant survived");
             } catch (IllegalArgumentException e) {
                 // Original code would not throw exception here
                 // Mutant would throw exception here (good)
                 assertTrue(e.getMessage().contains("function values at endpoints must have different signs"));
             }
         }

    @Test
         public void testSolveDetectsNonBracketingCondition() throws FunctionEvaluationException, MaxIterationsExceededException {
             // Create mock function
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             
             // Setup test case where yInitial and yMax have same signs
             // (yInitial = 1, yMax = 2)
             when(f.value(0.0)).thenReturn(1.0);  // yInitial
             when(f.value(1.0)).thenReturn(2.0);  // yMax
             
             BrentSolver solver = new BrentSolver(f);
             
             try {
                 // This should throw exception in original code (signs same)
                 double result = solver.solve(f, 0.0, 1.0, 0.0);
                 // If we get here with original code, test fails
                 // If we get here with mutant, mutant is detected (good)
                 // We need to verify the result is correct
                 assertNotNull(result);
             } catch (IllegalArgumentException e) {
                 // Original code would throw exception here (good)
                 // Mutant would not throw exception here (bad)
                 // So this catch block helps detect the mutant
                 assertTrue(e.getMessage().contains("function values at endpoints must have different signs"));
             }
         }

    @Test
         public void testSolveDetectsInitialMaxBracketingCondition() throws FunctionEvaluationException, MaxIterationsExceededException {
             // Create a mock function that returns:
             // - positive value at min (1.0)
             // - negative value at initial (2.0)
             // - positive value at max (3.0)
             // This setup means:
             // yMin * yInitial < 0 (would trigger first bracketing condition)
             // yInitial * yMax < 0 (would trigger second bracketing condition in original)
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             when(f.value(1.0)).thenReturn(1.0);   // yMin
             when(f.value(2.0)).thenReturn(-0.5);  // yInitial
             when(f.value(3.0)).thenReturn(1.0);   // yMax
             
             BrentSolver solver = new BrentSolver(f);
             solver.setFunctionValueAccuracy(0.0001);
             
             // The original code should recurse between initial and max (2.0 and 3.0)
             // The mutated code would skip this case since yInitial*yMax > 0 is false
             // We can verify this by checking if the solution is between initial and max
             double result = solver.solve(1.0, 3.0, 2.0);
             
             // Verify solution is between initial and max (since that's where the root is)
             assertTrue("Solution should be between initial and max", 
                        result >= 2.0 && result <= 3.0);
             
             // Also verify the solution is not the initial guess (since it wasn't exact)
             assertNotEquals(2.0, result, 0.0001);
         }

    @Test
         public void testSolveParameterOrderSensitivity() throws Exception {
             // Create a mock function that behaves differently at min and max
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             when(f.value(1.0)).thenReturn(-1.0);  // min
             when(f.value(4.0)).thenReturn(8.0);   // max
             when(f.value(2.5)).thenReturn(1.25);  // initial
             
             // Create solver instance
             BrentSolver solver = new BrentSolver(f);
             
             // Test with original parameter order (min=1, max=4)
             double result1 = solver.solve(f, 1.0, 4.0, 2.5);
             
             // Now test with swapped min/max (should be different if mutation exists)
             double result2 = solver.solve(f, 4.0, 1.0, 2.5);
             
             // The results should be equal regardless of parameter order
             // If mutation exists where min/max are swapped internally, this would fail
             assertEquals("Results should be equal regardless of parameter order", 
                         result1, result2, 1e-6);
             
             // Additional verification that the mock was called correctly
             verify(f, atLeastOnce()).value(1.0);
             verify(f, atLeastOnce()).value(4.0);
             verify(f, atLeastOnce()).value(2.5);
         }

    @Test
    public void testSolveWithCorrectBracketingDetectsMutant() throws FunctionEvaluationException, MaxIterationsExceededException {
        // Create a mock function that crosses zero between min and max
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        when(f.value(1.0)).thenReturn(-1.0);  // f(min) < 0
        when(f.value(4.0)).thenReturn(1.0);   // f(max) > 0
        when(f.value(2.5)).thenReturn(0.0);   // root at 2.5
        
        // Create solver and test
        BrentSolver solver = new BrentSolver(f);
        double min = 1.0;
        double max = 4.0;
        double initial = 2.0;
        
        // The original implementation should find the root at 2.5
        // The mutant would fail because it swaps min/max, breaking the bracketing condition
        double result = solver.solve(f, min, max, initial);
        
        // Verify the result is within the expected range
        assertTrue("Result should be between min and max", result >= min && result <= max);
        assertEquals("Should find the root at 2.5", 2.5, result, 1e-6);
        
        // Verify the function was called with correct parameters
        verify(f).value(1.0);
        verify(f).value(4.0);
        verify(f).value(2.5);
    }

    @Test
    public void testSolveDetectsParameterOrderMutant() throws FunctionEvaluationException, MaxIterationsExceededException {
        // Create a mock function that has a root at 2.0
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        when(f.value(1.0)).thenReturn(-1.0);  // min
        when(f.value(3.0)).thenReturn(1.0);   // max
        when(f.value(2.0)).thenReturn(0.0);   // root
        when(f.value(1.5)).thenReturn(-0.5);  // initial
        when(f.value(2.5)).thenReturn(0.5);   // other test points
        
        // Create solver with tight accuracy to ensure we detect the root
        BrentSolver solver = new BrentSolver(f);
        solver.setFunctionValueAccuracy(1e-10);
        
        // Test with interval that requires proper parameter ordering
        double result = solver.solve(f, 1.0, 3.0, 1.5);
        
        // Verify we found the root at 2.0
        assertEquals(2.0, result, 1e-6);
        
        // The key verification - check the parameter ordering in the private solve call
        // This would normally require verifying interactions with a spy,
        // but since we can't see the private method implementation, we rely on the result
        
        // Additional test with asymmetric function to be more sensitive to parameter order
        UnivariateRealFunction asymmetricF = mock(UnivariateRealFunction.class);
        when(asymmetricF.value(0.0)).thenReturn(-10.0);
        when(asymmetricF.value(10.0)).thenReturn(100.0);
        when(asymmetricF.value(5.0)).thenReturn(0.0);  // root
        when(asymmetricF.value(2.0)).thenReturn(-5.0); // initial
        
        solver = new BrentSolver(asymmetricF);
        result = solver.solve(asymmetricF, 0.0, 10.0, 2.0);
        assertEquals(5.0, result, 1e-6);
    }

    @Test
    public void testSolveWithSwappedParametersShouldGiveSameResult() throws FunctionEvaluationException, MaxIterationsExceededException {
        // Create a mock function that returns different values at min and max
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        when(f.value(1.0)).thenReturn(-1.0);  // yMin
        when(f.value(4.0)).thenReturn(2.0);   // yMax
        
        // The root is at x=2 (since f(x) = x-2)
        // With min=1, max=4, the solution should be 2 regardless of parameter order
        
        BrentSolver solver = new BrentSolver(f);
        double result = solver.solve(1.0, 4.0);
        
        // Verify the result is close to the expected root (2.0)
        assertEquals(2.0, result, 1e-6);
        
        // The mutation would swap min/max parameters in the internal solve call,
        // which might lead to different iteration paths or even wrong results
        // This test ensures the correct behavior is maintained
    }

    @Test
    public void testSolveWithSwappedMinMaxShouldFail() throws FunctionEvaluationException, MaxIterationsExceededException {
        // Create a mock function that has root at 2.0
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        when(f.value(1.0)).thenReturn(-1.0);  // min
        when(f.value(3.0)).thenReturn(1.0);   // max
        when(f.value(2.0)).thenReturn(0.0);   // root
        when(f.value(1.5)).thenReturn(-0.5);
        when(f.value(2.5)).thenReturn(0.5);
        
        BrentSolver solver = new BrentSolver(f);
        
        try {
            // The correct order should find the root at 2.0
            double result = solver.solve(1.0, 3.0, 2.0);
            assertEquals(2.0, result, 1e-6);
            
            // Now test with swapped min/max - this should fail if the mutant exists
            // because it will try to solve from (3.0,1.0) to (1.0,-1.0) which is invalid
            result = solver.solve(3.0, 1.0, 2.0);
            fail("Expected IllegalArgumentException for invalid bracket");
        } catch (IllegalArgumentException e) {
            // Expected behavior - the mutant would not throw this exception
            assertTrue(e.getMessage().contains("Function values at endpoints must have different signs"));
        }
    }


}
