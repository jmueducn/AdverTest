package gentest.org.apache.commons.math3.random.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.random.*;
import java.io.Serializable;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.util.FastMath;
 
public class BitsStreamGeneratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                                                                           public void testNextGaussian_StatisticalProperties() {
                                                                                                                                                               // Create a real generator (not mocked) for statistical testing
                                                                                                                                                               BitsStreamGenerator realGenerator = new BitsStreamGenerator() {
                                                                                                                                                                   private long seed = 12345L;
                                                                                                                                                                   
                                                                                                                                                                   @Override
                                                                                                                                                                   protected int next(int bits) {
                                                                                                                                                                       seed = (seed * 0x5DEECE66DL + 0xBL) & ((1L << 48) - 1);
                                                                                                                                                                       return (int)(seed >>> (48 - bits));
                                                                                                                                                                   }
                                                                                                                                                                   
                                                                                                                                                                   @Override
                                                                                                                                                                   public void setSeed(int seed) { this.seed = seed; }
                                                                                                                                                                   
                                                                                                                                                                   @Override
                                                                                                                                                                   public void setSeed(int[] seed) { this.seed = seed[0]; }
                                                                                                                                                                   
                                                                                                                                                                   @Override
                                                                                                                                                                   public void setSeed(long seed) { this.seed = seed; }
                                                                                                                                                               };
                                                                                                                                                               
                                                                                                                                                               int sampleSize = 10000;
                                                                                                                                                               double sum = 0;
                                                                                                                                                               double sumSquares = 0;
                                                                                                                                                               
                                                                                                                                                               for (int i = 0; i < sampleSize; i++) {
                                                                                                                                                                   double value = realGenerator.nextGaussian();
                                                                                                                                                                   sum += value;
                                                                                                                                                                   sumSquares += value * value;
                                                                                                                                                               }
                                                                                                                                                               
                                                                                                                                                               double mean = sum / sampleSize;
                                                                                                                                                               double variance = sumSquares / sampleSize - mean * mean;
                                                                                                                                                               
                                                                                                                                                               // Check if mean is approximately 0 (within 3 standard errors)
                                                                                                                                                               assertEquals(0.0, mean, 3.0 / Math.sqrt(sampleSize));
                                                                                                                                                               // Check if variance is approximately 1 (within reasonable bounds)
                                                                                                                                                               assertEquals(1.0, variance, 0.1);
                                                                                                                                                           }

 @Test
                                                                                                                                                   public void testSetSeed_Int_MinValue() {
                                                                                                                                                       // Create a concrete implementation for testing
                                                                                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                           private int lastIntSeed;
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {
                                                                                                                                                               this.lastIntSeed = seed;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {
                                                                                                                                                               // Not used in this test
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {
                                                                                                                                                               // Not used in this test
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0; // Not used in this test
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           public int getLastIntSeed() {
                                                                                                                                                               return lastIntSeed;
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       generator.setSeed(Integer.MIN_VALUE);
                                                                                                                                                       
                                                                                                                                                       // Use reflection to access the lastIntSeed field if getLastIntSeed() isn't available
                                                                                                                                                       try {
                                                                                                                                                           Field field = generator.getClass().getDeclaredField("lastIntSeed");
                                                                                                                                                           field.setAccessible(true);
                                                                                                                                                           assertEquals(Integer.MIN_VALUE, field.getInt(generator));
                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                           fail("Failed to access lastIntSeed field");
                                                                                                                                                       }
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testSetSeed_Int_Zero() {
                                                                                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                           // Implement abstract methods with minimal implementation
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {
                                                                                                                                                               // Empty implementation for test
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {
                                                                                                                                                               // Empty implementation for test
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {
                                                                                                                                                               // Empty implementation for test
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0; // Minimal implementation
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       generator.setSeed(0);
                                                                                                                                                       // Since we can't verify the seed directly, we'll verify that setting the seed
                                                                                                                                                       // doesn't throw an exception and the generator can still produce values
                                                                                                                                                       int value = generator.nextInt();
                                                                                                                                                       // Just verify we got some value (exact value not important for this test)
                                                                                                                                                       assertNotNull(value);
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testSetSeed_IntArray_Null() {
                                                                                                                                                       // Create a concrete implementation for testing
                                                                                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0;
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       // Setup expected exception
                                                                                                                                                       ExpectedException thrown = ExpectedException.none();
                                                                                                                                                       thrown.expect(NullPointerException.class);
                                                                                                                                                       
                                                                                                                                                       // Test the method
                                                                                                                                                       generator.setSeed((int[]) null);
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testSetSeed_IntArray_SingleElement() {
                                                                                                                                                       // Create a concrete implementation for testing
                                                                                                                                                       class ConcreteBitsStreamGenerator extends BitsStreamGenerator {
                                                                                                                                                           private int[] lastIntArraySeed;
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {
                                                                                                                                                               this.lastIntArraySeed = seed.clone();
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           public int[] getLastIntArraySeed() {
                                                                                                                                                               return lastIntArraySeed;
                                                                                                                                                           }
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       ConcreteBitsStreamGenerator generator = new ConcreteBitsStreamGenerator();
                                                                                                                                                       int[] seed = {42};
                                                                                                                                                       generator.setSeed(seed);
                                                                                                                                                       assertArrayEquals(seed, generator.getLastIntArraySeed());
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testSetSeed_Long_MinValue() {
                                                                                                                                                       // Create an anonymous subclass of BitsStreamGenerator for testing
                                                                                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                           private long lastLongSeed;
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {
                                                                                                                                                               this.lastLongSeed = seed;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           public long getLastLongSeed() {
                                                                                                                                                               return lastLongSeed;
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       generator.setSeed(Long.MIN_VALUE);
                                                                                                                                                       
                                                                                                                                                       // Use reflection to access the lastLongSeed field since it's likely private in the real implementation
                                                                                                                                                       try {
                                                                                                                                                           Field field = generator.getClass().getDeclaredField("lastLongSeed");
                                                                                                                                                           field.setAccessible(true);
                                                                                                                                                           long actualSeed = field.getLong(generator);
                                                                                                                                                           assertEquals(Long.MIN_VALUE, actualSeed);
                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                           fail("Failed to access seed field: " + e.getMessage());
                                                                                                                                                       }
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testSetSeed_WithLong() {
                                                                                                                                                       long seed = 123456789L;
                                                                                                                                                       // Create a concrete implementation (using Well19937c as an example)
                                                                                                                                                       BitsStreamGenerator generator = new Well19937c();
                                                                                                                                                       generator.setSeed(seed);
                                                                                                                                                       
                                                                                                                                                       // Verify the seed was set by checking generator behavior
                                                                                                                                                       // Since we can't directly access the seed, we'll verify consistent output
                                                                                                                                                       long firstRandom = generator.nextLong();
                                                                                                                                                       generator.setSeed(seed);
                                                                                                                                                       assertEquals(firstRandom, generator.nextLong());
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testSetSeed_WithMaxInt() throws Exception {
                                                                                                                                                       int seed = Integer.MAX_VALUE;
                                                                                                                                                       // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                                                                                       BitsStreamGenerator generator = new MersenneTwister();
                                                                                                                                                       
                                                                                                                                                       // Set the seed
                                                                                                                                                       generator.setSeed(seed);
                                                                                                                                                       
                                                                                                                                                       // Use reflection to access the lastIntSeed field if needed
                                                                                                                                                       Field lastIntSeedField = BitsStreamGenerator.class.getDeclaredField("lastIntSeed");
                                                                                                                                                       lastIntSeedField.setAccessible(true);
                                                                                                                                                       int actualSeed = lastIntSeedField.getInt(generator);
                                                                                                                                                       
                                                                                                                                                       assertEquals(seed, actualSeed);
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testSetSeed_WithMaxLong() {
                                                                                                                                                       long seed = Long.MAX_VALUE;
                                                                                                                                                       BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                                                                       generator.setSeed(seed);
                                                                                                                                                       
                                                                                                                                                       // Verify the setSeed method was called with the correct value
                                                                                                                                                       verify(generator).setSeed(seed);
                                                                                                                                                       
                                                                                                                                                       // If we need to verify internal state, we'd need to use reflection
                                                                                                                                                       // but since we're testing the abstract class, verifying the method call is sufficient
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testSetSeed_WithMinLong() {
                                                                                                                                                       // Create a concrete implementation for testing
                                                                                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                           private long lastSeed;
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {
                                                                                                                                                               this.lastSeed = seed;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           // Helper method to get the last seed for verification
                                                                                                                                                           public long getLastLongSeed() {
                                                                                                                                                               return lastSeed;
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       long seed = Long.MIN_VALUE;
                                                                                                                                                       generator.setSeed(seed);
                                                                                                                                                       
                                                                                                                                                       // Use reflection to access the last seed if getLastLongSeed() isn't available
                                                                                                                                                       try {
                                                                                                                                                           Field lastSeedField = generator.getClass().getDeclaredField("lastSeed");
                                                                                                                                                           lastSeedField.setAccessible(true);
                                                                                                                                                           long actualSeed = lastSeedField.getLong(generator);
                                                                                                                                                           assertEquals(seed, actualSeed);
                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                           fail("Failed to verify seed using reflection");
                                                                                                                                                       }
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testSetSeedWithLong() {
                                                                                                                                                       // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0;
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       // Test that method can be called without exception
                                                                                                                                                       generator.setSeed(0L);
                                                                                                                                                       generator.setSeed(Long.MAX_VALUE);
                                                                                                                                                       generator.setSeed(Long.MIN_VALUE);
                                                                                                                                                       generator.setSeed(123456789L);
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testSetSeedWithIntArrayValidInput() {
                                                                                                                                                       // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0;
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                   
                                                                                                                                                       // Test with various valid arrays
                                                                                                                                                       generator.setSeed(new int[]{1});
                                                                                                                                                       generator.setSeed(new int[]{1, 2, 3});
                                                                                                                                                       generator.setSeed(new int[]{Integer.MAX_VALUE, Integer.MIN_VALUE});
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testSetSeedWithIntArrayNullInput() {
                                                                                                                                                       // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {
                                                                                                                                                               if (seed == null) {
                                                                                                                                                                   throw new NullPointerException();
                                                                                                                                                               }
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0;
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       thrown.expect(NullPointerException.class);
                                                                                                                                                       generator.setSeed((int[])null);
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testSetSeedWithIntArrayEmptyInput() {
                                                                                                                                                       // Create a concrete implementation for testing
                                                                                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0;
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       // Define expected exception rule
                                                                                                                                                       ExpectedException thrown = ExpectedException.none();
                                                                                                                                                       thrown.expect(IllegalArgumentException.class);
                                                                                                                                                       generator.setSeed(new int[]{});
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testNextIntWithBound_ThrowsExceptionForNegativeBound() {
                                                                                                                                                       org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                                                                                       thrown.expect(IllegalArgumentException.class);
                                                                                                                                                       thrown.expectMessage("bound must be positive");
                                                                                                                                                       org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0;
                                                                                                                                                           }
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {}
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {}
                                                                                                                                                       };
                                                                                                                                                       generator.nextInt(-1);
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testNextFloat_ReturnsValueBetweenZeroAndOne() {
                                                                                                                                                       // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                           private int nextValue;
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return nextValue;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {}
                                                                                                                                                           
                                                                                                                                                           public void setNextValue(int value) {
                                                                                                                                                               this.nextValue = value;
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       // Set the next value to produce ~1.0f (0x3F800000 is the float bits for 1.0)
                                                                                                                                                       try {
                                                                                                                                                           Method setNextValue = generator.getClass().getMethod("setNextValue", int.class);
                                                                                                                                                           setNextValue.invoke(generator, 0x3F800000);
                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                           fail("Failed to set next value");
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       float result = generator.nextFloat();
                                                                                                                                                       assertTrue(result >= 0.0f && result < 1.0f);
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testNextDouble_ReturnsValueBetweenZeroAndOne() {
                                                                                                                                                       // Create a testable subclass of BitsStreamGenerator
                                                                                                                                                       class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                                                                                                                           private int nextValue;
                                                                                                                                                           
                                                                                                                                                           public void setNextValue(int value) {
                                                                                                                                                               this.nextValue = value;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return nextValue;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {}
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {}
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       // Create instance and set test values
                                                                                                                                                       TestableBitsStreamGenerator generator = new TestableBitsStreamGenerator();
                                                                                                                                                       // Simulate two 32-bit values that will form a 64-bit double
                                                                                                                                                       generator.setNextValue(0x3FF00000);
                                                                                                                                                       generator.setNextValue(0x00000000);
                                                                                                                                                       
                                                                                                                                                       double result = generator.nextDouble();
                                                                                                                                                       assertTrue(result >= 0.0 && result < 1.0);
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testNextGaussian_ReturnsNaNWhenFirstCall() {
                                                                                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0;
                                                                                                                                                           }
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {}
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {}
                                                                                                                                                       };
                                                                                                                                                       assertTrue(Double.isNaN(generator.nextGaussian()));
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testNextGaussian_ReturnsValueWhenSecondCall() {
                                                                                                                                                       // Create mock of BitsStreamGenerator
                                                                                                                                                       BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                                                                       
                                                                                                                                                       // Setup mock behavior
                                                                                                                                                       when(generator.nextGaussian())
                                                                                                                                                           .thenReturn(Double.NaN)  // First call returns NaN
                                                                                                                                                           .thenReturn(1.0);       // Second call returns a valid number
                                                                                                                                                       
                                                                                                                                                       // First call returns NaN and computes nextGaussian
                                                                                                                                                       generator.nextGaussian();
                                                                                                                                                       // Second call should return the computed value
                                                                                                                                                       double result = generator.nextGaussian();
                                                                                                                                                       assertFalse(Double.isNaN(result));
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testNextBytes_ThrowsExceptionForNullArray() {
                                                                                                                                                       // Create a concrete implementation of the abstract class for testing
                                                                                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0; // dummy implementation
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {}
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {}
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       try {
                                                                                                                                                           generator.nextBytes(null);
                                                                                                                                                           fail("Expected NullPointerException");
                                                                                                                                                       } catch (NullPointerException e) {
                                                                                                                                                           // Expected exception
                                                                                                                                                       }
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testClear_ResetsNextGaussian() {
                                                                                                                                                       // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                           @Override
                                                                                                                                                           protected int next(int bits) {
                                                                                                                                                               return 0; // simple implementation for testing
                                                                                                                                                           }
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int seed) {}
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(int[] seed) {}
                                                                                                                                                           @Override
                                                                                                                                                           public void setSeed(long seed) {}
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       // First call to nextGaussian computes a value
                                                                                                                                                       generator.nextGaussian();
                                                                                                                                                       // Clear should reset it
                                                                                                                                                       generator.clear();
                                                                                                                                                       assertTrue(Double.isNaN(generator.nextGaussian()));
                                                                                                                                                   }

 @Test
                                                                                                                                               public void testNextBytes_EmptyArray() {
                                                                                                                                                   // Create a concrete instance of the generator
                                                                                                                                                   BitsStreamGenerator generator = new Well19937c();
                                                                                                                                                   byte[] bytes = new byte[0];
                                                                                                                                                   generator.nextBytes(bytes);
                                                                                                                                                   assertEquals(0, bytes.length);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextBytes_SingleByte() {
                                                                                                                                                   // Create a concrete subclass that returns predictable values
                                                                                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           return 0x04030201; // Predictable value for testing
                                                                                                                                                       }
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {}
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   byte[] bytes = new byte[1];
                                                                                                                                                   generator.nextBytes(bytes);
                                                                                                                                                   // Verify the first byte of the random number is used
                                                                                                                                                   assertEquals(0x01, bytes[0] & 0xff);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextBytes_TwoBytes() {
                                                                                                                                                   // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                       private int counter = 0x0403; // Fixed value for testing
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           return counter;
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {}
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {}
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {}
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   byte[] bytes = new byte[2];
                                                                                                                                                   generator.nextBytes(bytes);
                                                                                                                                                   assertEquals(0x04, bytes[0] & 0xff);
                                                                                                                                                   assertEquals(0x03, bytes[1] & 0xff);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextBytes_ThreeBytes() {
                                                                                                                                                   // Create a mock of BitsStreamGenerator
                                                                                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                       private int callCount = 0;
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           // Return predictable values for testing
                                                                                                                                                           // First call will return 0x04030201 (for 4 bytes)
                                                                                                                                                           // Subsequent calls will return 0 (not used in this test)
                                                                                                                                                           return callCount++ == 0 ? 0x04030201 : 0;
                                                                                                                                                       }
                                                                                                                                               
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {}
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   byte[] bytes = new byte[3];
                                                                                                                                                   generator.nextBytes(bytes);
                                                                                                                                                   assertEquals(0x04, bytes[0] & 0xff);
                                                                                                                                                   assertEquals(0x03, bytes[1] & 0xff);
                                                                                                                                                   assertEquals(0x02, bytes[2] & 0xff);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextBytes_FourBytes() {
                                                                                                                                                   // Create a mock of BitsStreamGenerator
                                                                                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                       private int count = 0;
                                                                                                                                                       private final int[] values = {0x01020304}; // This will produce bytes 04, 03, 02, 01 when shifted
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           return values[count++];
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {}
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   byte[] bytes = new byte[4];
                                                                                                                                                   generator.nextBytes(bytes);
                                                                                                                                                   assertEquals(0x04, bytes[0] & 0xff);
                                                                                                                                                   assertEquals(0x03, bytes[1] & 0xff);
                                                                                                                                                   assertEquals(0x02, bytes[2] & 0xff);
                                                                                                                                                   assertEquals(0x01, bytes[3] & 0xff);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextBytes_FiveBytes() {
                                                                                                                                                   // Create a mock generator that returns predictable values
                                                                                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                       private int callCount = 0;
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           // First call returns 0x01020304, second call returns 0x04030201
                                                                                                                                                           return callCount++ == 0 ? 0x01020304 : 0x04030201;
                                                                                                                                                       }
                                                                                                                                               
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {}
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   byte[] bytes = new byte[5];
                                                                                                                                                   generator.nextBytes(bytes);
                                                                                                                                                   // First 4 bytes from the first 32-bit value (0x01020304)
                                                                                                                                                   assertEquals(0x04, bytes[0] & 0xff);
                                                                                                                                                   assertEquals(0x03, bytes[1] & 0xff);
                                                                                                                                                   assertEquals(0x02, bytes[2] & 0xff);
                                                                                                                                                   assertEquals(0x01, bytes[3] & 0xff);
                                                                                                                                                   // Fifth byte from the second 32-bit value (0x04030201)
                                                                                                                                                   assertEquals(0x01, bytes[4] & 0xff);  // Note: Fixed expected value from 0x04 to 0x01
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextBytes_LargeArray() {
                                                                                                                                                   // Create a concrete instance of the generator (using a simple anonymous class)
                                                                                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                       private int counter = 0;
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           // Return a predictable pattern for testing
                                                                                                                                                           return 0x04030201;
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {}
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   byte[] bytes = new byte[100];
                                                                                                                                                   generator.nextBytes(bytes);
                                                                                                                                                   
                                                                                                                                                   // Verify pattern repeats every 4 bytes
                                                                                                                                                   for (int i = 0; i < 100; i++) {
                                                                                                                                                       int expected = 0x04 - (i % 4);
                                                                                                                                                       if (expected < 0x01) expected = 0x04;
                                                                                                                                                       assertEquals(expected, bytes[i] & 0xff);
                                                                                                                                                   }
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextBytes_NullInput() {
                                                                                                                                                   // Create an anonymous subclass of BitsStreamGenerator for testing
                                                                                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           return 0; // dummy implementation
                                                                                                                                                       }
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {}
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   // Set up expected exception
                                                                                                                                                   ExpectedException thrown = ExpectedException.none();
                                                                                                                                                   thrown.expect(NullPointerException.class);
                                                                                                                                                   
                                                                                                                                                   // Test the method
                                                                                                                                                   generator.nextBytes(null);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextGaussian_FirstCallGeneratesNewPair() {
                                                                                                                                                   // Create a mock generator that extends BitsStreamGenerator
                                                                                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           return 0; // Not used in this test
                                                                                                                                                       }
                                                                                                                                               
                                                                                                                                                       @Override
                                                                                                                                                       public double nextDouble() {
                                                                                                                                                           return 0.5; // Fixed value for predictable results
                                                                                                                                                       }
                                                                                                                                               
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {}
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {}
                                                                                                                                                   };
                                                                                                                                               
                                                                                                                                                   // First call should generate new pair since nextGaussian is NaN initially
                                                                                                                                                   double firstValue = generator.nextGaussian();
                                                                                                                                                   
                                                                                                                                                   // With nextDouble() returning 0.5, we can calculate expected value:
                                                                                                                                                   // alpha = 2 * PI * 0.5 = PI
                                                                                                                                                   // r = sqrt(-2 * ln(0.5)) ≈ 1.1774100225154747
                                                                                                                                                   // firstValue = r * cos(PI) ≈ 1.17741 * -1 ≈ -1.17741
                                                                                                                                                   assertEquals(-1.1774100225154747, firstValue, 1e-10);
                                                                                                                                                   
                                                                                                                                                   // Verify nextGaussian was set to the second value of the pair
                                                                                                                                                   // nextGaussian = r * sin(PI) ≈ 1.17741 * 0 = 0
                                                                                                                                                   // We can't directly access nextGaussian, but we can verify behavior
                                                                                                                                                   double secondValue = generator.nextGaussian();
                                                                                                                                                   assertEquals(0.0, secondValue, 1e-10);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextGaussian_SubsequentCallUsesStoredValue() {
                                                                                                                                                   // Create a mock of the generator
                                                                                                                                                   BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                                                                   
                                                                                                                                                   // First call setup - generates pair and returns first value
                                                                                                                                                   when(generator.nextDouble())
                                                                                                                                                       .thenReturn(0.5)  // x value for first pair
                                                                                                                                                       .thenReturn(0.5); // y value for first pair
                                                                                                                                                   
                                                                                                                                                   // First call generates pair and returns first value
                                                                                                                                                   generator.nextGaussian();
                                                                                                                                                   
                                                                                                                                                   // Second call should return the stored second value (0.0 in this case)
                                                                                                                                                   double secondValue = generator.nextGaussian();
                                                                                                                                                   assertEquals(0.0, secondValue, 1e-10);
                                                                                                                                                   
                                                                                                                                                   // Third call setup - generates new pair again
                                                                                                                                                   when(generator.nextDouble())
                                                                                                                                                       .thenReturn(0.25)  // x value for second pair
                                                                                                                                                       .thenReturn(0.25); // y value for second pair
                                                                                                                                                   
                                                                                                                                                   // Third call should generate new pair again
                                                                                                                                                   double thirdValue = generator.nextGaussian();
                                                                                                                                                   assertEquals(-1.1774100225154747, thirdValue, 1e-10);
                                                                                                                                               }

 @Test(expected = ArithmeticException.class)
                                                                                                                                               public void testNextGaussian_WithOneRandomInput() {
                                                                                                                                                   BitsStreamGenerator oneGenerator = new BitsStreamGenerator() {
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) { return 0; }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {}
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {}
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {}
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public double nextDouble() {
                                                                                                                                                           return 1.0; // Will cause log(1) which is 0
                                                                                                                                                       }
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   oneGenerator.nextGaussian();
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextInt_ReturnsDifferentValues() {
                                                                                                                                                   // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                                                                                   BitsStreamGenerator generator = new Well19937c();
                                                                                                                                                   
                                                                                                                                                   // Verify that different values can be returned
                                                                                                                                                   generator.setSeed(42);
                                                                                                                                                   int firstCall = generator.nextInt();
                                                                                                                                                   
                                                                                                                                                   generator.setSeed(123);
                                                                                                                                                   int secondCall = generator.nextInt();
                                                                                                                                                   
                                                                                                                                                   assertNotEquals(firstCall, secondCall);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextInt_Proper32BitRange() {
                                                                                                                                                   // Verify that the returned values are proper 32-bit integers
                                                                                                                                                   // This is more of a sanity check since we control the next() method
                                                                                                                                                   
                                                                                                                                                   // Create a mock of BitsStreamGenerator
                                                                                                                                                   BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                                                                   
                                                                                                                                                   // Test with a value that would overflow 32 bits
                                                                                                                                                   when(generator.nextInt()).thenReturn(Integer.MIN_VALUE);
                                                                                                                                                   assertEquals(Integer.MIN_VALUE, generator.nextInt());
                                                                                                                                                   
                                                                                                                                                   when(generator.nextInt()).thenReturn(Integer.MAX_VALUE);
                                                                                                                                                   assertEquals(Integer.MAX_VALUE, generator.nextInt());
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextInt_WhenNIsNotPowerOfTwo() {
                                                                                                                                                   BitsStreamGenerator generator = spy(new BitsStreamGenerator() {
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           return bits == 31 ? 100 : 0; // return 100 when next(31) is called
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {
                                                                                                                                                           // empty implementation for test
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {
                                                                                                                                                           // empty implementation for test
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {
                                                                                                                                                           // empty implementation for test
                                                                                                                                                       }
                                                                                                                                                   });
                                                                                                                                               
                                                                                                                                                   // Test with n = 7 (not a power of two)
                                                                                                                                                   int result = generator.nextInt(7);
                                                                                                                                                   // 100 % 7 = 2
                                                                                                                                                   assertEquals(2, result);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextInt_WhenNIsOne() {
                                                                                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           return 12345; // any value will do since n=1
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {
                                                                                                                                                           // empty implementation for test
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {
                                                                                                                                                           // empty implementation for test
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {
                                                                                                                                                           // empty implementation for test
                                                                                                                                                       }
                                                                                                                                                   };
                                                                                                                                               
                                                                                                                                                   // 1 is a power of two, but result should always be 0
                                                                                                                                                   assertEquals(0, generator.nextInt(1));
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextInt_WhenNIsNegative() {
                                                                                                                                                   thrown.expect(NotStrictlyPositiveException.class);
                                                                                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           return 0;
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {
                                                                                                                                                           // empty implementation for test
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {
                                                                                                                                                           // empty implementation for test
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {
                                                                                                                                                           // empty implementation for test
                                                                                                                                                       }
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   generator.nextInt(-5);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextInt_WhenNIsZero() {
                                                                                                                                                   thrown.expect(NotStrictlyPositiveException.class);
                                                                                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           return 0;
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {
                                                                                                                                                           // No implementation needed for test
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {
                                                                                                                                                           // No implementation needed for test
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {
                                                                                                                                                           // No implementation needed for test
                                                                                                                                                       }
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   generator.nextInt(0);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextInt_RetryLogicWhenBitsValOverflows() {
                                                                                                                                                   BitsStreamGenerator generator = spy(new BitsStreamGenerator() {
                                                                                                                                                       private int callCount = 0;
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           if (bits == 31) {
                                                                                                                                                               // First call returns a value that would cause overflow
                                                                                                                                                               if (callCount++ == 0) {
                                                                                                                                                                   return Integer.MAX_VALUE;
                                                                                                                                                               }
                                                                                                                                                               // Second call returns a safe value
                                                                                                                                                               return 100;
                                                                                                                                                           }
                                                                                                                                                           return 0;
                                                                                                                                                       }
                                                                                                                                               
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {
                                                                                                                                                           // No-op for test
                                                                                                                                                       }
                                                                                                                                               
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {
                                                                                                                                                           // No-op for test
                                                                                                                                                       }
                                                                                                                                               
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {
                                                                                                                                                           // No-op for test
                                                                                                                                                       }
                                                                                                                                                   });
                                                                                                                                               
                                                                                                                                                   // Test with n = 100000 (large number to trigger retry)
                                                                                                                                                   int result = generator.nextInt(100000);
                                                                                                                                                   // Should use the second value (100 % 100000 = 100)
                                                                                                                                                   assertEquals(100, result);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testNextInt_EdgeCaseMaximumN() {
                                                                                                                                                   BitsStreamGenerator generator = spy(new BitsStreamGenerator() {
                                                                                                                                                       @Override
                                                                                                                                                       protected int next(int bits) {
                                                                                                                                                           return bits == 31 ? Integer.MAX_VALUE - 1 : 0;
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int seed) {
                                                                                                                                                           // empty implementation for test
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(int[] seed) {
                                                                                                                                                           // empty implementation for test
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       @Override
                                                                                                                                                       public void setSeed(long seed) {
                                                                                                                                                           // empty implementation for test
                                                                                                                                                       }
                                                                                                                                                   });
                                                                                                                                               
                                                                                                                                                   // Test with n = Integer.MAX_VALUE
                                                                                                                                                   int result = generator.nextInt(Integer.MAX_VALUE);
                                                                                                                                                   // (Integer.MAX_VALUE - 1) % Integer.MAX_VALUE = Integer.MAX_VALUE - 1
                                                                                                                                                   assertEquals(Integer.MAX_VALUE - 1, result);
                                                                                                                                               }

 @Test
                                                                                                           public void testNextLong_AllZerosAndOnes() {
                                                                                                               BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                               
                                                                                                               long result = generator.nextLong();
                                                                                                               
                                                                                                               assertEquals(0x00000000FFFFFFFFL, result);
                                                                                                           }

 @Test
                                                                                                           public void testClear_WhenNextGaussianIsAlreadyNaN() {
                                                                                                               // Arrange - nextGaussian is already NaN after construction
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) { return 0; }
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               };
                                                                                                               assertTrue(Double.isNaN(generator.nextGaussian()));
                                                                                                               
                                                                                                               // Act
                                                                                                               generator.clear();
                                                                                                               
                                                                                                               // Assert
                                                                                                               assertTrue(Double.isNaN(generator.nextGaussian()));
                                                                                                           }

 @Test
                                                                                                           public void testClear_WhenNextGaussianHasNormalValue() throws Exception {
                                                                                                               // Arrange - create a concrete generator instance and set a normal value using reflection
                                                                                                               BitsStreamGenerator generator = new Well19937c(); // Using a concrete subclass
                                                                                                               java.lang.reflect.Field field = generator.getClass().getSuperclass().getDeclaredField("nextGaussian");
                                                                                                               field.setAccessible(true);
                                                                                                               field.set(generator, 1.23);
                                                                                                               
                                                                                                               // Act
                                                                                                               generator.clear();
                                                                                                               
                                                                                                               // Assert - check the value was reset to NaN
                                                                                                               assertTrue(Double.isNaN((Double)field.get(generator)));
                                                                                                           }

 @Test
                                                                                                           public void testClear_WhenNextGaussianIsPositiveInfinity() throws Exception {
                                                                                                               // Arrange
                                                                                                               // Create a concrete subclass instance since BitsStreamGenerator is abstract
                                                                                                               BitsStreamGenerator generator = new MersenneTwister();
                                                                                                               java.lang.reflect.Field field = generator.getClass().getSuperclass().getDeclaredField("nextGaussian");
                                                                                                               field.setAccessible(true);
                                                                                                               field.set(generator, Double.POSITIVE_INFINITY);
                                                                                                               
                                                                                                               // Act
                                                                                                               generator.clear();
                                                                                                               
                                                                                                               // Assert
                                                                                                               assertTrue(Double.isNaN((Double)field.get(generator)));
                                                                                                           }

 @Test
                                                                                                           public void testClear_WhenNextGaussianIsNegativeInfinity() throws Exception {
                                                                                                               // Arrange
                                                                                                               // Create a concrete subclass instance since BitsStreamGenerator is abstract
                                                                                                               BitsStreamGenerator generator = new MersenneTwister();
                                                                                                               java.lang.reflect.Field field = generator.getClass().getSuperclass().getDeclaredField("nextGaussian");
                                                                                                               field.setAccessible(true);
                                                                                                               field.set(generator, Double.NEGATIVE_INFINITY);
                                                                                                               
                                                                                                               // Act
                                                                                                               generator.clear();
                                                                                                               
                                                                                                               // Assert
                                                                                                               assertTrue(Double.isNaN((Double)field.get(generator)));
                                                                                                           }

 @Test
                                                                                                           public void testClear_WhenNextGaussianIsZero() throws Exception {
                                                                                                               // Arrange
                                                                                                               BitsStreamGenerator generator = new MersenneTwister(); // Using concrete subclass
                                                                                                               java.lang.reflect.Field field = generator.getClass().getSuperclass().getDeclaredField("nextGaussian");
                                                                                                               field.setAccessible(true);
                                                                                                               field.set(generator, 0.0);
                                                                                                               
                                                                                                               // Act
                                                                                                               generator.clear();
                                                                                                               
                                                                                                               // Assert
                                                                                                               Object nextGaussianValue = field.get(generator);
                                                                                                               assertTrue(Double.isNaN((Double)nextGaussianValue));
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_Int_ValidValue() {
                                                                                                               // Create a concrete test implementation
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int lastIntSeed;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {
                                                                                                                       this.lastIntSeed = seed;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       throw new UnsupportedOperationException();
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {
                                                                                                                       throw new UnsupportedOperationException();
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       throw new UnsupportedOperationException();
                                                                                                                   }
                                                                                                                   
                                                                                                                   public int getLastIntSeed() {
                                                                                                                       return lastIntSeed;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               generator.setSeed(12345);
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_Int_MaxValue() {
                                                                                                               // Create a test implementation of BitsStreamGenerator
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int lastIntSeed;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {
                                                                                                                       this.lastIntSeed = seed;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       // Not used in this test
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {
                                                                                                                       // Not used in this test
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0; // Not used in this test
                                                                                                                   }
                                                                                                                   
                                                                                                                   public int getLastIntSeed() {
                                                                                                                       return lastIntSeed;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               generator.setSeed(Integer.MAX_VALUE);
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_IntArray_ValidValue() {
                                                                                                               // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int[] lastSeed;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       this.lastSeed = seed;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0;
                                                                                                                   }
                                                                                                                   
                                                                                                                   public int[] getLastIntArraySeed() {
                                                                                                                       return lastSeed;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               int[] seed = {1, 2, 3, 4};
                                                                                                               generator.setSeed(seed);
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_IntArray_EmptyArray() {
                                                                                                               // Create a simple test implementation of BitsStreamGenerator
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int[] lastSeed;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       this.lastSeed = seed;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0;
                                                                                                                   }
                                                                                                                   
                                                                                                                   public int[] getLastIntArraySeed() {
                                                                                                                       return lastSeed;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               int[] seed = new int[0];
                                                                                                               generator.setSeed(seed);
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_Long_ValidValue() {
                                                                                                               // Create concrete implementation for testing
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private long lastLongSeed;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {
                                                                                                                       // Not used in this test
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       // Not used in this test
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {
                                                                                                                       this.lastLongSeed = seed;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0; // Not used in this test
                                                                                                                   }
                                                                                                                   
                                                                                                                   public long getLastLongSeed() {
                                                                                                                       return lastLongSeed;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               generator.setSeed(123456789L);
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_Long_MaxValue() {
                                                                                                               // Create a test implementation of BitsStreamGenerator
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private long lastLongSeed;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {
                                                                                                                       this.lastLongSeed = seed;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0;
                                                                                                                   }
                                                                                                                   
                                                                                                                   public long getLastLongSeed() {
                                                                                                                       return lastLongSeed;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               generator.setSeed(Long.MAX_VALUE);
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_Long_Zero() {
                                                                                                               // Create anonymous subclass of BitsStreamGenerator for testing
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private long lastLongSeed;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {
                                                                                                                       // Empty implementation for test purposes
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       // Empty implementation for test purposes
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {
                                                                                                                       this.lastLongSeed = seed;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0;
                                                                                                                   }
                                                                                                                   
                                                                                                                   public long getLastLongSeed() {
                                                                                                                       return lastLongSeed;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               generator.setSeed(0L);
                                                                                                           }

 @Test
                                                                                                           public void testConstructor_InitializesNextGaussian() {
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0; // Dummy implementation for testing
                                                                                                                   }
                                                                                                           
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {
                                                                                                                       // Dummy implementation
                                                                                                                   }
                                                                                                           
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       // Dummy implementation
                                                                                                                   }
                                                                                                           
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {
                                                                                                                       // Dummy implementation
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               // The first call to nextGaussian() should return a value since the initial NaN triggers computation
                                                                                                               double value = generator.nextGaussian();
                                                                                                               // We can't directly test the initial NaN state through public API
                                                                                                               // This test would need to be redesigned to verify behavior rather than state
                                                                                                               assertTrue(!Double.isNaN(value)); // Just showing alternative approach
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_WithInt() {
                                                                                                               int seed = 12345;
                                                                                                               // Create a test implementation of BitsStreamGenerator
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int lastIntSeed;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {
                                                                                                                       this.lastIntSeed = seed;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       throw new UnsupportedOperationException();
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {
                                                                                                                       throw new UnsupportedOperationException();
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       throw new UnsupportedOperationException();
                                                                                                                   }
                                                                                                                   
                                                                                                                   public int getLastIntSeed() {
                                                                                                                       return lastIntSeed;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               generator.setSeed(seed);
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_WithIntArray() {
                                                                                                               // Create a mock of BitsStreamGenerator
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int[] lastSeed;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {
                                                                                                                       // Empty implementation for test
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       this.lastSeed = seed.clone();
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {
                                                                                                                       // Empty implementation for test
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0; // Simple implementation for test
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Helper method to get last seed for testing
                                                                                                                   public int[] getLastIntArraySeed() {
                                                                                                                       return lastSeed;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               int[] seed = {1, 2, 3, 4, 5};
                                                                                                               generator.setSeed(seed);
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_WithNullIntArray() {
                                                                                                               BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                               try {
                                                                                                                   generator.setSeed((int[])null);
                                                                                                                   fail("Expected NullPointerException");
                                                                                                               } catch (NullPointerException e) {
                                                                                                                   // expected
                                                                                                               }
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_WithEmptyIntArray() {
                                                                                                               // Create a concrete instance of the abstract class for testing
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int[] lastSeed;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {
                                                                                                                       // Empty implementation for abstract method
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       this.lastSeed = seed;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {
                                                                                                                       // Empty implementation for abstract method
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0; // Simple implementation for abstract method
                                                                                                                   }
                                                                                                                   
                                                                                                                   public int[] getLastIntArraySeed() {
                                                                                                                       return lastSeed;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               int[] seed = new int[0]; // Empty int array
                                                                                                               generator.setSeed(seed);
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_WithNegativeInt() {
                                                                                                               // Create a mock implementation of the abstract class
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int lastSeed;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {
                                                                                                                       this.lastSeed = seed;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       throw new UnsupportedOperationException();
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {
                                                                                                                       throw new UnsupportedOperationException();
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0;
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Helper method to verify seed was set
                                                                                                                   public int getLastSeed() {
                                                                                                                       return lastSeed;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               int seed = -12345;
                                                                                                               generator.setSeed(seed);
                                                                                                               
                                                                                                               // Verify the seed was set by checking through our mock's helper method
                                                                                                               // We need to cast to our anonymous class type to access getLastSeed()
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_WithMinInt() {
                                                                                                               // Create a concrete subclass of BitsStreamGenerator for testing
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int lastSeed;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {
                                                                                                                       this.lastSeed = seed;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       // Not used in this test
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {
                                                                                                                       // Not used in this test
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0; // Not used in this test
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Helper method to get the last seed
                                                                                                                   public int getLastIntSeed() {
                                                                                                                       return lastSeed;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               int seed = Integer.MIN_VALUE;
                                                                                                               generator.setSeed(seed);
                                                                                                           }

 @Test
                                                                                                           public void testSetSeed_WithZero() {
                                                                                                               // Create a concrete implementation of BitsStreamGenerator
                                                                                                               BitsStreamGenerator generator = new MersenneTwister();
                                                                                                               
                                                                                                               // Test integer seed
                                                                                                               generator.setSeed(0);
                                                                                                               int firstInt = generator.nextInt();
                                                                                                               generator.setSeed(0);
                                                                                                               int secondInt = generator.nextInt();
                                                                                                               assertEquals(firstInt, secondInt); // Same seed should produce same sequence
                                                                                                               
                                                                                                               // Test empty array seed
                                                                                                               generator.setSeed(new int[0]);
                                                                                                               firstInt = generator.nextInt();
                                                                                                               generator.setSeed(new int[0]);
                                                                                                               secondInt = generator.nextInt();
                                                                                                               assertEquals(firstInt, secondInt); // Same seed should produce same sequence
                                                                                                               
                                                                                                               // Test long seed
                                                                                                               generator.setSeed(0L);
                                                                                                               firstInt = generator.nextInt();
                                                                                                               generator.setSeed(0L);
                                                                                                               secondInt = generator.nextInt();
                                                                                                               assertEquals(firstInt, secondInt); // Same seed should produce same sequence
                                                                                                           }

 @Test
                                                                                                           public void testSetSeedWithInt() {
                                                                                                               // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {
                                                                                                                       // Empty implementation for testing
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       // Empty implementation for testing
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {
                                                                                                                       // Empty implementation for testing
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0; // Simple implementation for testing
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               // Test that method can be called without exception
                                                                                                               generator.setSeed(0);
                                                                                                               generator.setSeed(Integer.MAX_VALUE);
                                                                                                               generator.setSeed(Integer.MIN_VALUE);
                                                                                                               generator.setSeed(12345);
                                                                                                               
                                                                                                               // No assertions needed as we're testing it doesn't throw exceptions
                                                                                                           }

 @Test
                                                                                                           public void testConstructorInitializesNextGaussian() throws Exception {
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) { return 0; }
                                                                                                               };
                                                                                                               Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                                               nextGaussianField.setAccessible(true);
                                                                                                               double nextGaussianValue = nextGaussianField.getDouble(generator);
                                                                                                               assertTrue(Double.isNaN(nextGaussianValue));
                                                                                                           }

 @Test
                                                                                                           public void testNextBoolean_ReturnsTrueWhenNextBitIsOne() {
                                                                                                               // Create a testable implementation of BitsStreamGenerator
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int nextValue;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return nextValue;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                                   
                                                                                                                   public void setNextValue(int value) {
                                                                                                                       this.nextValue = value;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               // Set next value to 1 and test
                                                                                                               assertTrue(generator.nextBoolean());
                                                                                                           }

 @Test
                                                                                                           public void testNextBoolean_ReturnsFalseWhenNextBitIsZero() {
                                                                                                               // Create a testable implementation of BitsStreamGenerator
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int nextValue;
                                                                                                                   
                                                                                                                   public void setNextValue(int value) {
                                                                                                                       this.nextValue = value;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return nextValue;
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Implement other abstract methods with empty implementations
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               };
                                                                                                               
                                                                                                               // Set next value to 0 and verify nextBoolean returns false
                                                                                                               assertFalse(generator.nextBoolean());
                                                                                                           }

 @Test
                                                                                                           public void testNextInt_ReturnsCorrectValue() {
                                                                                                               // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int nextValue;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return nextValue;
                                                                                                                   }
                                                                                                               
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                                   
                                                                                                                   public void setNextValue(int value) {
                                                                                                                       this.nextValue = value;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               // Set the next value and verify
                                                                                                               assertEquals(0x12345678, generator.nextInt());
                                                                                                           }

 @Test
                                                                                                           public void testNextIntWithBound_ReturnsValueWithinRange() {
                                                                                                               // Create a mock of BitsStreamGenerator
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int nextValue;
                                                                                                                   
                                                                                                                   public void setNextValue(int value) {
                                                                                                                       this.nextValue = value;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return nextValue;
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Implement other abstract methods with empty implementations
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               };
                                                                                                               
                                                                                                               // Set the next value to return through our mock
                                                                                                               int result = generator.nextInt(100);
                                                                                                               assertTrue(result >= 0 && result < 100);
                                                                                                           }

 @Test
                                                                                                           public void testNextBytes_FillsArrayWithValues() {
                                                                                                               // Create a test subclass that exposes the protected next() method
                                                                                                               class TestGenerator extends BitsStreamGenerator {
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0x12345678; // Return fixed non-zero value
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               }
                                                                                                               
                                                                                                               // Use the concrete test subclass instead of mock
                                                                                                               BitsStreamGenerator generator = new TestGenerator();
                                                                                                               
                                                                                                               byte[] bytes = new byte[10];
                                                                                                               generator.nextBytes(bytes);
                                                                                                               
                                                                                                               // Verify at least some bytes were filled (exact values depend on implementation)
                                                                                                               boolean allZero = true;
                                                                                                               for (byte b : bytes) {
                                                                                                                   if (b != 0) {
                                                                                                                       allZero = false;
                                                                                                                       break;
                                                                                                                   }
                                                                                                               }
                                                                                                               assertFalse("Byte array should not be all zeros", allZero);
                                                                                                               
                                                                                                               // Can't verify protected method calls, but we can verify the effect through public methods
                                                                                                               // The fact that bytes are not all zeros confirms next() was called internally
                                                                                                           }

 @Test
                                                                                                           public void testNextBoolean_ReturnsTrueWhenNextIsNonZero() {
                                                                                                               // Arrange
                                                                                                               BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                               when(generator.nextBoolean()).thenReturn(true);
                                                                                                               
                                                                                                               // Act
                                                                                                               boolean result = generator.nextBoolean();
                                                                                                               
                                                                                                               // Assert
                                                                                                               assertTrue(result);
                                                                                                           }

 @Test
                                                                                                           public void testNextBoolean_ReturnsFalseWhenNextIsZero() {
                                                                                                               // Arrange
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0; // Always return 0 when next is called
                                                                                                                   }
                                                                                                           
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               };
                                                                                                               
                                                                                                               // Act
                                                                                                               boolean result = generator.nextBoolean();
                                                                                                               
                                                                                                               // Assert
                                                                                                               assertFalse(result);
                                                                                                           }

 @Test
                                                                                                           public void testNextBoolean_ConsistentlyReturnsCorrectValues() {
                                                                                                               // Arrange
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int nextValue;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return nextValue;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                                   
                                                                                                                   public void setNextReturnValue(int value) {
                                                                                                                       this.nextValue = value;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               // Set first value to 1
                                                                                                               boolean firstResult = generator.nextBoolean();
                                                                                                               
                                                                                                               // Set second value to 0
                                                                                                               boolean secondResult = generator.nextBoolean();
                                                                                                               
                                                                                                               // Assert
                                                                                                               assertTrue(firstResult);
                                                                                                               assertFalse(secondResult);
                                                                                                           }

 @Test
                                                                                                           public void testNextBytes_VerifyNextCalledCorrectly() {
                                                                                                               // Create a concrete subclass to test the abstract BitsStreamGenerator
                                                                                                               class TestGenerator extends BitsStreamGenerator {
                                                                                                                   private int nextCallCount = 0;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       nextCallCount++;
                                                                                                                       return 0; // dummy implementation
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                                   
                                                                                                                   public int getNextCallCount() {
                                                                                                                       return nextCallCount;
                                                                                                                   }
                                                                                                               }
                                                                                                               
                                                                                                               TestGenerator generator = new TestGenerator();
                                                                                                               BitsStreamGenerator spyGenerator = spy(generator);
                                                                                                               
                                                                                                               // Setup spy to call real method for nextBytes
                                                                                                               doCallRealMethod().when(spyGenerator).nextBytes(any(byte[].class));
                                                                                                               
                                                                                                               byte[] bytes = new byte[10];
                                                                                                               spyGenerator.nextBytes(bytes);
                                                                                                               
                                                                                                               // Verify next(32) was called 3 times (4+4+2 bytes) through the counter
                                                                                                               assertEquals(3, generator.getNextCallCount());
                                                                                                           }

 @Test
                                                                                                           public void testNextDouble_NormalCase() {
                                                                                                               // Create test subclass that exposes protected next(int) method
                                                                                                               class TestBitsStreamGenerator extends BitsStreamGenerator {
                                                                                                                   private int[] values;
                                                                                                                   private int index = 0;
                                                                                                                   
                                                                                                                   TestBitsStreamGenerator(int[] values) {
                                                                                                                       this.values = values;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return values[index++];
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               }
                                                                                                               
                                                                                                               // Create test generator with specific return values
                                                                                                               int[] values = {0x1FFFFFF, 0x1FFFFFF}; // max 26-bit values for high and low parts
                                                                                                               BitsStreamGenerator generator = new TestBitsStreamGenerator(values);
                                                                                                               
                                                                                                               double result = generator.nextDouble();
                                                                                                               
                                                                                                               // Verify the expected value: (2^52 - 1) * 2^-52 = 0.9999999999999999
                                                                                                               assertEquals(0.9999999999999999, result, 0.0);
                                                                                                           }

 @Test
                                                                                                           public void testNextDouble_MinimumValue() {
                                                                                                               // Create a test subclass that exposes the protected next() method
                                                                                                               class TestBitsStreamGenerator extends BitsStreamGenerator {
                                                                                                                   private int[] returnValues;
                                                                                                                   private int callCount = 0;
                                                                                                                   
                                                                                                                   TestBitsStreamGenerator(int[] returnValues) {
                                                                                                                       this.returnValues = returnValues;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return returnValues[callCount++];
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Implement abstract methods (empty implementations for testing)
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               }
                                                                                                               
                                                                                                               // Create test generator with predefined return values
                                                                                                               BitsStreamGenerator generator = new TestBitsStreamGenerator(new int[]{0, 0});
                                                                                                               
                                                                                                               double result = generator.nextDouble();
                                                                                                               
                                                                                                               // Verify the expected value: 0 * 2^-52 = 0.0
                                                                                                               assertEquals(0.0, result, 0.0);
                                                                                                           }

 @Test
                                                                                                           public void testNextDouble_RandomValue() {
                                                                                                               // Create a test subclass that exposes the protected next() method
                                                                                                               class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                                   @Override
                                                                                                                   public int next(int bits) {
                                                                                                                       return 0; // will be mocked
                                                                                                                   }
                                                                                                               }
                                                                                                               
                                                                                                               // Create mock generator using our testable subclass
                                                                                                               TestableBitsStreamGenerator generator = mock(TestableBitsStreamGenerator.class);
                                                                                                               
                                                                                                               // Setup mock behavior for next(26) calls
                                                                                                               when(generator.next(26))
                                                                                                                   .thenReturn(123456)  // arbitrary high part
                                                                                                                   .thenReturn(654321); // arbitrary low part
                                                                                                               
                                                                                                               double result = generator.nextDouble();
                                                                                                               
                                                                                                               // Calculate expected value
                                                                                                               long expectedBits = ((123456L << 26) | 654321L);
                                                                                                               double expectedValue = expectedBits * 0x1.0p-52d;
                                                                                                               
                                                                                                               assertEquals(expectedValue, result, 0.0);
                                                                                                           }

 @Test
                                                                                                           public void testNextDouble_MultipleCalls() {
                                                                                                               // Create mock generator using spy to handle protected method
                                                                                                               BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                               
                                                                                                               // Setup mock behavior for 3 calls using doReturn pattern for protected method
                                                                                                               
                                                                                                               // First call
                                                                                                               assertEquals(0.0, generator.nextDouble(), 0.0);
                                                                                                               
                                                                                                               // Second call
                                                                                                               long midValue = ((1L << 25) << 26) | (1L << 25);
                                                                                                               assertEquals(midValue * 0x1.0p-52d, generator.nextDouble(), 0.0);
                                                                                                               
                                                                                                               // Third call
                                                                                                               long maxValue = ((0xFFFFFFL << 26) | 0xFFFFFFL);
                                                                                                               assertEquals(maxValue * 0x1.0p-52d, generator.nextDouble(), 0.0);
                                                                                                           }

 @Test
                                                                                                           public void testNextDouble_RangeVerification() {
                                                                                                               // Create a test subclass that exposes the protected next() method
                                                                                                               class TestGenerator extends BitsStreamGenerator {
                                                                                                                   private int[] values;
                                                                                                                   private int index = 0;
                                                                                                                   
                                                                                                                   TestGenerator(int[] values) {
                                                                                                                       this.values = values;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return values[index++];
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               }
                                                                                                               
                                                                                                               // Test values: min case, min case, max case, max case, random case, random case
                                                                                                               int[] testValues = {0, 0, 0x1FFFFFF, 0x1FFFFFF, 123456, 654321};
                                                                                                               BitsStreamGenerator generator = new TestGenerator(testValues);
                                                                                                               
                                                                                                               // Min value
                                                                                                               double minResult = generator.nextDouble();
                                                                                                               assertTrue(minResult >= 0.0 && minResult < 1.0);
                                                                                                               
                                                                                                               // Max value
                                                                                                               double maxResult = generator.nextDouble();
                                                                                                               assertTrue(maxResult >= 0.0 && maxResult < 1.0);
                                                                                                               
                                                                                                               // Random value
                                                                                                               double randomResult = generator.nextDouble();
                                                                                                               assertTrue(randomResult >= 0.0 && randomResult < 1.0);
                                                                                                           }

 @Test
                                                                                                           public void testNextFloat_ZeroCase() {
                                                                                                               // Create a test subclass that exposes the protected next() method
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return 0; // Always return 0 for this test case
                                                                                                                   }
                                                                                                           
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               };
                                                                                                               
                                                                                                               // When next(23) returns 0, result should be 0.0f
                                                                                                               assertEquals(0.0f, generator.nextFloat(), 0.0f);
                                                                                                           }

 @Test
                                                                                                           public void testNextFloat_MaxValueCase() {
                                                                                                               // Create mock of BitsStreamGenerator
                                                                                                               BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                               
                                                                                                               // When next(23) returns maximum 23-bit value (2^23 - 1)
                                                                                                               // Result should be (2^23 - 1) * 2^-23 = 1.0f - 2^-23
                                                                                                               
                                                                                                               // Calculate expected value
                                                                                                               float expected = 1.0f - (1.0f / (float)(1 << 23));
                                                                                                               
                                                                                                               // Call the method and verify
                                                                                                               assertEquals(expected, generator.nextFloat(), 0.0f);
                                                                                                           }

 @Test
                                                                                                           public void testNextFloat_MiddleValueCase() {
                                                                                                               // Create a test implementation of BitsStreamGenerator
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       // Return the middle value (2^22) when 23 bits are requested
                                                                                                                       return bits == 23 ? (1 << 22) : 0;
                                                                                                                   }
                                                                                                           
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               };
                                                                                                               
                                                                                                               // Test a middle value (2^22)
                                                                                                               float expected = 0.5f;
                                                                                                               assertEquals(expected, generator.nextFloat(), 0.0f);
                                                                                                           }

 @Test
                                                                                                           public void testNextFloat_RandomValueCase() {
                                                                                                               // Create a test subclass that exposes the protected next(int) method
                                                                                                               class TestBitsStreamGenerator extends BitsStreamGenerator {
                                                                                                                   private int nextValue;
                                                                                                                   
                                                                                                                   public void setNextValue(int value) {
                                                                                                                       this.nextValue = value;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return nextValue;
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Need to implement abstract methods (empty implementations for testing)
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               }
                                                                                                               
                                                                                                               // Create instance of our test generator
                                                                                                               TestBitsStreamGenerator generator = new TestBitsStreamGenerator();
                                                                                                               
                                                                                                               // Test with a random 23-bit value (123456)
                                                                                                               generator.setNextValue(123456);
                                                                                                               float expected = 123456.0f / (float)(1 << 23);
                                                                                                               
                                                                                                               // Call the actual method and verify
                                                                                                               float actual = generator.nextFloat();
                                                                                                               assertEquals(expected, actual, 0.0001f);  // Using small delta for float comparison
                                                                                                           }

 @Test
                                                                                                           public void testNextFloat_EdgeCaseWithNegativeValue() throws Exception {
                                                                                                               // Create a concrete subclass to test the protected method
                                                                                                               class TestGenerator extends BitsStreamGenerator {
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return -1; // Return the negative value we want to test
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               }
                                                                                                               
                                                                                                               // Create instance of our test generator
                                                                                                               BitsStreamGenerator generator = new TestGenerator();
                                                                                                               
                                                                                                               // The result should be negative due to two's complement
                                                                                                               float expected = -1.0f / (float)(1 << 23);
                                                                                                               assertEquals(expected, generator.nextFloat(), 0.0f);
                                                                                                           }

 @Test
                                                                                                           public void testNextFloat_EdgeCaseWithLargeValue() {
                                                                                                               // Create a test subclass that exposes the protected next() method
                                                                                                               class TestBitsStreamGenerator extends BitsStreamGenerator {
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return (bits == 23) ? ((1 << 23) + 123) : 0;
                                                                                                                   }
                                                                                                               }
                                                                                                               
                                                                                                               // Create instance of our test generator
                                                                                                               BitsStreamGenerator generator = new TestBitsStreamGenerator();
                                                                                                               
                                                                                                               // Only the lower 23 bits should be used (123 in this case)
                                                                                                               float expected = 123.0f / (float)(1 << 23);
                                                                                                               assertEquals(expected, generator.nextFloat(), 0.0f);
                                                                                                           }

 @Test
                                                                                                           public void testNextFloat_ConsistencyCheck() {
                                                                                                               // Create mock generator
                                                                                                               BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                               
                                                                                                               // Verify that multiple calls with same input produce same output
                                                                                                               float firstCall = generator.nextFloat();
                                                                                                               float secondCall = generator.nextFloat();
                                                                                                               assertEquals(firstCall, secondCall, 0.0f);
                                                                                                           }

 @Test
                                                                                                           public void testNextInt_Returns32BitValue() {
                                                                                                               // Create a test instance of BitsStreamGenerator
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int nextValue;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return nextValue;
                                                                                                                   }
                                                                                                                   
                                                                                                                   public void setNextValue(int value) {
                                                                                                                       this.nextValue = value;
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               // Test with minimum 32-bit value
                                                                                                               assertEquals(Integer.MIN_VALUE, generator.nextInt());
                                                                                                               
                                                                                                               // Test with maximum 32-bit value
                                                                                                               assertEquals(Integer.MAX_VALUE, generator.nextInt());
                                                                                                               
                                                                                                               // Test with zero
                                                                                                               assertEquals(0, generator.nextInt());
                                                                                                               
                                                                                                               // Test with a typical positive value
                                                                                                               assertEquals(123456789, generator.nextInt());
                                                                                                               
                                                                                                               // Test with a typical negative value
                                                                                                               assertEquals(-987654321, generator.nextInt());
                                                                                                           }

 @Test
                                                                                                           public void testNextInt_CallsNextWith32Bits() {
                                                                                                               // Create a concrete subclass of BitsStreamGenerator with dummy implementations
                                                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                                   private int callCount = 0;
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       callCount++;
                                                                                                                       assertEquals(32, bits); // Verify the bits parameter is 32
                                                                                                                       return 0; // dummy implementation
                                                                                                                   }
                                                                                                           
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                           
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                           
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               };
                                                                                                               
                                                                                                               // Call nextInt which should internally call next(32)
                                                                                                               generator.nextInt();
                                                                                                               
                                                                                                               // The verification is done in the overridden next() method
                                                                                                           }

 @Test
                                                                                                           public void testNextInt_WhenNIsPowerOfTwo() {
                                                                                                               // Create a test subclass that exposes the protected next() method
                                                                                                               class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                                                                                   @Override
                                                                                                                   public int next(int bits) {
                                                                                                                       return 0; // default implementation
                                                                                                                   }
                                                                                                           
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {
                                                                                                                       // empty implementation
                                                                                                                   }
                                                                                                           
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {
                                                                                                                       // empty implementation
                                                                                                                   }
                                                                                                           
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {
                                                                                                                       // empty implementation
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Expose the protected method as public for testing
                                                                                                                   public int publicNext(int bits) {
                                                                                                                       return next(bits);
                                                                                                                   }
                                                                                                               }
                                                                                                               
                                                                                                               // Create a spy of our testable class
                                                                                                               TestableBitsStreamGenerator generator = spy(new TestableBitsStreamGenerator());
                                                                                                               
                                                                                                               // Mock the public method that calls the protected next()
                                                                                                               doReturn(2147483647).when(generator).publicNext(31); // Integer.MAX_VALUE
                                                                                                               
                                                                                                               // Test with n = 8 (which is a power of two)
                                                                                                               int result = generator.nextInt(8);
                                                                                                               // (2147483647 * 8) >> 31 = (17179869176) >> 31 = 7
                                                                                                               assertEquals(7, result);
                                                                                                           }

 @Test
                                                                                                           public void testNextLong_CombinesBitsCorrectly() {
                                                                                                               // Create a test subclass that exposes the protected next(int) method
                                                                                                               class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                                                                                   private int[] values;
                                                                                                                   private int index = 0;
                                                                                                                   
                                                                                                                   TestableBitsStreamGenerator(int... values) {
                                                                                                                       this.values = values;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return values[index++];
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               }
                                                                                                               
                                                                                                               // Create instance with predefined values
                                                                                                               BitsStreamGenerator generator = new TestableBitsStreamGenerator(0x12345678, 0x9ABCDEF0);
                                                                                                               
                                                                                                               // Call the method
                                                                                                               long result = generator.nextLong();
                                                                                                               
                                                                                                               // Verify the result
                                                                                                               assertEquals(0x123456789ABCDEF0L, result);
                                                                                                           }

 @Test
                                                                                                           public void testNextLong_MinimumValues() {
                                                                                                               BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                               
                                                                                                               long result = generator.nextLong();
                                                                                                               
                                                                                                               assertEquals(0L, result);
                                                                                                           }

 @Test
                                                                                                           public void testNextLong_MaximumValues() {
                                                                                                               // Create a test subclass that exposes the protected next method
                                                                                                               class TestBitsStreamGenerator extends BitsStreamGenerator {
                                                                                                                   private int[] values;
                                                                                                                   private int index = 0;
                                                                                                                   
                                                                                                                   TestBitsStreamGenerator(int[] values) {
                                                                                                                       this.values = values;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return values[index++];
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               }
                                                                                                               
                                                                                                               // Create instance with predefined values
                                                                                                               TestBitsStreamGenerator generator = new TestBitsStreamGenerator(new int[] {0xFFFFFFFF, 0xFFFFFFFF});
                                                                                                               
                                                                                                               // Call the method under test
                                                                                                               long result = generator.nextLong();
                                                                                                               
                                                                                                               // Verify the result
                                                                                                               assertEquals(0xFFFFFFFFFFFFFFFFL, result);
                                                                                                           }

 @Test
                                                                                                           public void testNextLong_NoBitLoss() {
                                                                                                               // Create a test subclass that exposes the protected next() method
                                                                                                               class TestBitsStreamGenerator extends BitsStreamGenerator {
                                                                                                                   private int[] values;
                                                                                                                   private int index = 0;
                                                                                                                   
                                                                                                                   TestBitsStreamGenerator(int[] values) {
                                                                                                                       this.values = values;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return values[index++];
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Implement abstract methods with empty implementations
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               }
                                                                                                               
                                                                                                               // Create test generator with predefined values
                                                                   {}
                                                                                                               
                                                                                                               // Test that no bits are lost during combination
                                                                                                               
                                                                                                           }

 @Test
                                                                                                           public void testNextLong_AllOnesAndZeros() {
                                                                                                               // Create a test subclass that exposes the protected next() method
                                                                                                               class TestBitsStreamGenerator extends BitsStreamGenerator {
                                                                                                                   private int[] values;
                                                                                                                   private int index = 0;
                                                                                                                   
                                                                                                                   TestBitsStreamGenerator(int... values) {
                                                                                                                       this.values = values;
                                                                                                                   }
                                                                                                                   
                                                                                                                   @Override
                                                                                                                   protected int next(int bits) {
                                                                                                                       return values[index++];
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Implement abstract methods with empty implementations
                                                                                                                   @Override
                                                                                                                   public void setSeed(int seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(int[] seed) {}
                                                                                                                   @Override
                                                                                                                   public void setSeed(long seed) {}
                                                                                                               }
                                                                                                               
                                                                                                               // Create instance with our test values
                                                                                                               
                                                                                                               
                                                                                                           }

 @Test
                                                                                                       public void testNextLong_ReturnsCorrectValue() {
                                                                                                           // Create a mock of BitsStreamGenerator
                                                                                                           
                                                                                                           // Stub the next() calls to return the two 32-bit values that will form the long
                                                                                                           
                                                                                                           // Verify the combined long value
                                                                                                       }

 @Test
                                                                   public void testNextLong_MixedPatterns() {
                                                                       // Create a test subclass that exposes the protected next() method
                                                                       class TestBitsStreamGenerator extends BitsStreamGenerator {
                                                                           @Override
                                                                           protected int next(int bits) {
                                                                               return bits; // Simple implementation for testing
                                                                           }
                                                                   
                                                                           @Override
                                                                           public void setSeed(int seed) {}
                                                                           
                                                                           @Override
                                                                           public void setSeed(int[] seed) {}
                                                                           
                                                                           @Override
                                                                           public void setSeed(long seed) {}
                                                                       }
                                                                   
                                                                       // Create instance of test generator
                                                                       TestBitsStreamGenerator generator = new TestBitsStreamGenerator();
                                                                       
                                                                       // Test with different bit patterns
                                                                       long result1 = generator.nextLong();
                                                                       long result2 = generator.nextLong();
                                                                       
                                                                       // Verify results are different (randomness)
                                                                       assertNotEquals(result1, result2);
                                                                       
                                                                       // Verify results are within valid long range
                                                                       assertTrue(result1 >= Long.MIN_VALUE && result1 <= Long.MAX_VALUE);
                                                                       assertTrue(result2 >= Long.MIN_VALUE && result2 <= Long.MAX_VALUE);
                                                                   }

}
