package gentest.org.apache.commons.math3.analysis.differentiation.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.analysis.differentiation.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;
 
public class DSCompilerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                           public void testAtan2_PositiveX() {
                                                               // Setup
                                                               DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                                                               double[] y = {1.0, 0.1, 0.01};
                                                               double[] x = {1.0, 0.1, 0.01};
                                                               double[] result = new double[3];
                                                               
                                                               // Test
                                                               compiler.atan2(y, 0, x, 0, result, 0);
                                                               
                                                               // Verify
                                                               assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-15);
                                                               assertEquals(-0.19803902718556855, result[1], 1e-15);
                                                               assertEquals(-0.01999866669333308, result[2], 1e-15);
                                                           }

 @Test
                                                           public void testAtan2_NegativeX_PositiveY() {
                                                               // Setup
                                                               DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                                                               double[] y = {1.0, 0.1, 0.01};
                                                               double[] x = {-1.0, -0.1, -0.01};
                                                               double[] result = new double[3];
                                                               
                                                               // Test
                                                               compiler.atan2(y, 0, x, 0, result, 0);
                                                               
                                                               // Verify
                                                               assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-15);
                                                               assertEquals(2.9435516326292246, result[1], 1e-15);
                                                               assertEquals(3.1215913276764666, result[2], 1e-15);
                                                           }

 @Test
                                                           public void testAtan2_NegativeX_NegativeY() {
                                                               // Setup
                                                               DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                                                               double[] y = {-1.0, -0.1, -0.01};
                                                               double[] x = {-1.0, -0.1, -0.01};
                                                               double[] result = new double[3];
                                                               
                                                               // Test
                                                               compiler.atan2(y, 0, x, 0, result, 0);
                                                               
                                                               // Verify
                                                               assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-15);
                                                               assertEquals(-2.9435516326292246, result[1], 1e-15);
                                                               assertEquals(-3.1215913276764666, result[2], 1e-15);
                                                           }

 @Test
                                                           public void testAtan2_SpecialCases() {
                                                               // Setup
                                                               DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                                                               double[] result = new double[3];
                                                               
                                                               // Test +0/+0
                                                               compiler.atan2(new double[]{0.0, 0.0, 0.0}, 0, new double[]{0.0, 0.0, 0.0}, 0, result, 0);
                                                               assertEquals(0.0, result[0], 1e-15);
                                                               
                                                               // Test +0/-0
                                                               compiler.atan2(new double[]{0.0, 0.0, 0.0}, 0, new double[]{-0.0, 0.0, 0.0}, 0, result, 0);
                                                               assertEquals(Math.PI, result[0], 1e-15);
                                                               
                                                               // Test -0/+0
                                                               compiler.atan2(new double[]{-0.0, 0.0, 0.0}, 0, new double[]{0.0, 0.0, 0.0}, 0, result, 0);
                                                               assertEquals(-0.0, result[0], 1e-15);
                                                               
                                                               // Test -0/-0
                                                               compiler.atan2(new double[]{-0.0, 0.0, 0.0}, 0, new double[]{-0.0, 0.0, 0.0}, 0, result, 0);
                                                               assertEquals(-Math.PI, result[0], 1e-15);
                                                           }

 @Test
                                                           public void testAtan2_InfinityCases() {
                                                               // Setup
                                                               DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                                                               double[] result = new double[3];
                                                               
                                                               // Test +Inf/+Inf
                                                               compiler.atan2(new double[]{Double.POSITIVE_INFINITY, 0.0, 0.0}, 0, 
                                                                             new double[]{Double.POSITIVE_INFINITY, 0.0, 0.0}, 0, result, 0);
                                                               assertEquals(Math.PI/4, result[0], 1e-15);
                                                               
                                                               // Test +Inf/-Inf
                                                               compiler.atan2(new double[]{Double.POSITIVE_INFINITY, 0.0, 0.0}, 0, 
                                                                             new double[]{Double.NEGATIVE_INFINITY, 0.0, 0.0}, 0, result, 0);
                                                               assertEquals(3*Math.PI/4, result[0], 1e-15);
                                                               
                                                               // Test -Inf/+Inf
                                                               compiler.atan2(new double[]{Double.NEGATIVE_INFINITY, 0.0, 0.0}, 0, 
                                                                             new double[]{Double.POSITIVE_INFINITY, 0.0, 0.0}, 0, result, 0);
                                                               assertEquals(-Math.PI/4, result[0], 1e-15);
                                                               
                                                               // Test -Inf/-Inf
                                                               compiler.atan2(new double[]{Double.NEGATIVE_INFINITY, 0.0, 0.0}, 0, 
                                                                             new double[]{Double.NEGATIVE_INFINITY, 0.0, 0.0}, 0, result, 0);
                                                               assertEquals(-3*Math.PI/4, result[0], 1e-15);
                                                           }

 @Test
                                                           public void testAtan2_WithOffsets() {
                                                               // Setup
                                                               DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                                                               double[] y = {0.0, 0.0, 1.0, 0.1, 0.01};
                                                               double[] x = {0.0, 0.0, 1.0, 0.1, 0.01};
                                                               double[] result = new double[5];
                                                               
                                                               // Test with offsets
                                                               compiler.atan2(y, 2, x, 2, result, 1);
                                                               
                                                               // Verify
                                                               assertEquals(0.0, result[0], 1e-15); // should be untouched
                                                               assertEquals(FastMath.atan2(y[2], x[2]), result[1], 1e-15);
                                                               assertEquals(-0.19803902718556855, result[2], 1e-15);
                                                               assertEquals(-0.01999866669333308, result[3], 1e-15);
                                                               assertEquals(0.0, result[4], 1e-15); // should be untouched
                                                           }

 @Test
                                                           public void testAtan2_ZeroX() {
                                                               // Setup
                                                               DSCompiler compiler = DSCompiler.getCompiler(1, 2); // Using public factory method
                                                               double[] y = {1.0, 0.1, 0.01};
                                                               double[] x = {0.0, 0.0, 0.0};
                                                               double[] result = new double[3];
                                                               
                                                               // Test
                                                               compiler.atan2(y, 0, x, 0, result, 0);
                                                               
                                                               // Verify
                                                               assertEquals(Math.PI/2, result[0], 1e-15);
                                                           }

 @Test
                                                           public void testAtan2_ZeroXNegativeY() {
                                                               // Setup
                                                               DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                                                               double[] y = {-1.0, -0.1, -0.01};
                                                               double[] x = {0.0, 0.0, 0.0};
                                                               double[] result = new double[3];
                                                               
                                                               // Test
                                                               compiler.atan2(y, 0, x, 0, result, 0);
                                                               
                                                               // Verify
                                                               assertEquals(-Math.PI/2, result[0], 1e-15);
                                                           }

 @Test
                                                       public void testAtan2DetectsYMutation() {
                                                           // Setup test data
                                                           DSCompiler compiler = DSCompiler.getCompiler(2, 2); // Using 2 parameters and order 2
                                                           double[] y = {3.0, 1.0, 0.5}; // Test y values
                                                           double[] x = {4.0, 0.0, 0.0};  // Test x values
                                                           double[] result = new double[compiler.getSize()];
                                                           
                                                           // Expected angle calculation (using correct y²)
                                                           double expectedAngle = FastMath.atan2(y[0], x[0]);
                                                           
                                                           // Call the method
                                                           compiler.atan2(y, 0, x, 0, result, 0);
                                                           
                                                           // Verify the result
                                                           assertEquals("Main angle value should match FastMath.atan2", 
                                                                        expectedAngle, result[0], 1e-15);
                                                           
                                                           // Verify the calculation depends on correct y² by checking derivatives
                                                           // If y² was wrong, these derivative values would be incorrect
                                                           double expectedDeriv1 = (x[0] / (x[0]*x[0] + y[0]*y[0])); // ∂atan2/∂y
                                                           assertEquals("First derivative wrt y should be correct",
                                                                        expectedDeriv1, result[1], 1e-15);
                                                           
                                                           double expectedDeriv2 = (-y[0] / (x[0]*x[0] + y[0]*y[0])); // ∂atan2/∂x
                                                           assertEquals("First derivative wrt x should be correct",
                                                                        expectedDeriv2, result[2], 1e-15);
                                                       }

 @Test
                                                      public void testAtan2DetectsAdditionMutation() {
                                                          // Setup test data
                                                          DSCompiler compiler = DSCompiler.getCompiler(1, 1); // 1 parameter, 1st order
                                                          double[] x = {3.0}; // x value
                                                          double[] y = {4.0}; // y value
                                                          double[] result = new double[compiler.getSize()];
                                                          
                                                          // Expected r² = x² + y² = 9 + 16 = 25
                                                          // With mutation, it would be x² - y² = 9 - 16 = -7 (wrong)
                                                          
                                                          // Call the method
                                                          compiler.atan2(y, 0, x, 0, result, 0);
                                                          
                                                          // Verify the final result would be wrong if addition was mutated to subtraction
                                                          // Correct atan2(4,3) ≈ 0.927295218
                                                          assertEquals(FastMath.atan2(4.0, 3.0), result[0], 1.0e-15);
                                                          
                                                          // Also test with negative x to cover both branches
                                                          x[0] = -3.0;
                                                          compiler.atan2(y, 0, x, 0, result, 0);
                                                          assertEquals(FastMath.atan2(4.0, -3.0), result[0], 1.0e-15);
                                                          
                                                          // Test with zeros
                                                          x[0] = 0.0;
                                                          y[0] = 0.0;
                                                          compiler.atan2(y, 0, x, 0, result, 0);
                                                          assertEquals(FastMath.atan2(0.0, 0.0), result[0], 1.0e-15);
                                                      }

 @Test
                                                     public void testAtan2DetectsRootNMutant() {
                                                         // Create test compiler instance (assuming parameters=1, order=1 for simplicity)
                                                         DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                         
                                                         // Test values where square root and cube root differ significantly
                                                         double[] x = {3.0};
                                                         double[] y = {4.0};
                                                         double[] result = new double[compiler.getSize()];
                                                         
                                                         // Calculate expected r (sqrt(3² + 4²) = 5)
                                                         double expectedR = 5.0;
                                                         // Mutant would calculate cube root (3√(3² + 4²) ≈ 3.684
                                                         
                                                         // Calculate expected atan2 result using correct formula
                                                         double expectedAtan2 = FastMath.atan2(y[0], x[0]);
                                                         
                                                         // Call the method
                                                         compiler.atan2(y, 0, x, 0, result, 0);
                                                         
                                                         // Verify the result matches FastMath.atan2 (which uses correct sqrt)
                                                         assertEquals("Result should match FastMath.atan2", 
                                                                     expectedAtan2, result[0], 1e-15);
                                                         
                                                         // Additional verification - check intermediate r calculation
                                                         // This requires access to tmp1 which holds r, but since it's local,
                                                         // we verify through the final result which depends on r
                                                         
                                                         // Test with negative x to cover both branches
                                                         x[0] = -3.0;
                                                         expectedAtan2 = FastMath.atan2(y[0], x[0]);
                                                         compiler.atan2(y, 0, x, 0, result, 0);
                                                         assertEquals("Result with negative x should match FastMath.atan2",
                                                                     expectedAtan2, result[0], 1e-15);
                                                     }

 @Test
                                                    public void testAtan2WithXEqualsZero() {
                                                        // Create test instance
                                                        DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Using minimal parameters and order
                                                        
                                                        // Test inputs where x=0
                                                        double[] y = new double[compiler.getSize()];
                                                        double[] x = new double[compiler.getSize()];
                                                        double[] result = new double[compiler.getSize()];
                                                        
                                                        // Set x=0 and y=1 (simple case)
                                                        y[0] = 1.0;
                                                        x[0] = 0.0;
                                                        
                                                        // Expected value is atan2(1,0) which should be π/2
                                                        double expected = FastMath.PI/2;
                                                        
                                                        // Call the method
                                                        compiler.atan2(y, 0, x, 0, result, 0);
                                                        
                                                        // Verify the result matches expected atan2 value
                                                        assertEquals(expected, result[0], 1e-15);
                                                        
                                                        // Additional verification for x=0, y=-1 case
                                                        y[0] = -1.0;
                                                        x[0] = 0.0;
                                                        expected = -FastMath.PI/2;
                                                        compiler.atan2(y, 0, x, 0, result, 0);
                                                        assertEquals(expected, result[0], 1e-15);
                                                        
                                                        // Edge case: x=0, y=0
                                                        y[0] = 0.0;
                                                        x[0] = 0.0;
                                                        expected = FastMath.atan2(0.0, 0.0); // Should be 0.0 per IEEE 754
                                                        compiler.atan2(y, 0, x, 0, result, 0);
                                                        assertEquals(expected, result[0], 1e-15);
                                                    }

 @Test
                                                  public void testAtan2DetectsDivideToMultiplyMutation() {
                                                      // Create test compiler with known parameters using public factory method
                                                      DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                                                      
                                                      // Test case 1: x >= 0 branch (45 degree angle)
                                                      double[] y1 = {1.0, 0, 0}; // y = 1
                                                      double[] x1 = {1.0, 0, 0}; // x = 1
                                                      double[] result1 = new double[compiler.getSize()];
                                                      compiler.atan2(y1, 0, x1, 0, result1, 0);
                                                      // Expected: atan2(1,1) = π/4 ≈ 0.785398
                                                      assertEquals(Math.PI/4, result1[0], 1e-10);
                                                      
                                                      // Test case 2: x < 0 branch (135 degree angle)
                                                      double[] y2 = {1.0, 0, 0}; // y = 1
                                                      double[] x2 = {-1.0, 0, 0}; // x = -1
                                                      double[] result2 = new double[compiler.getSize()];
                                                      compiler.atan2(y2, 0, x2, 0, result2, 0);
                                                      // Expected: atan2(1,-1) = 3π/4 ≈ 2.356194
                                                      assertEquals(3*Math.PI/4, result2[0], 1e-10);
                                                      
                                                      // Test case 3: Edge case (90 degree angle)
                                                      double[] y3 = {1.0, 0, 0}; // y = 1
                                                      double[] x3 = {0.0, 0, 0}; // x = 0
                                                      double[] result3 = new double[compiler.getSize()];
                                                      compiler.atan2(y3, 0, x3, 0, result3, 0);
                                                      // Expected: atan2(1,0) = π/2 ≈ 1.570796
                                                      assertEquals(Math.PI/2, result3[0], 1e-10);
                                                  }

 @Test
                                             public void testAtan2WithPositiveXDetectsMultiplicationFactorMutant() {
                                                 // Setup test data for x >= 0 case
                                                 DSCompiler compiler = DSCompiler.getCompiler(1, 1); // parameters=1, order=1
                                                 double[] y = new double[compiler.getSize()];
                                                 double[] x = new double[compiler.getSize()];
                                                 double[] result = new double[compiler.getSize()];
                                                 
                                                 // Use known values where atan2 is easily calculable
                                                 // atan2(1,1) should be π/4 (0.785398...)
                                                 y[0] = 1.0;  // y coordinate
                                                 x[0] = 1.0;  // x coordinate (positive)
                                                 
                                                 // Call the method
                                                 compiler.atan2(y, 0, x, 0, result, 0);
                                                 
                                                 // Verify the multiplication factor is exactly 2 (not 3)
                                                 // The first element should be π/4
                                                 assertEquals(Math.PI/4, result[0], 1e-10);
                                                 
                                                 // If there are more elements (for derivatives), verify they're also correctly multiplied by 2
                                                 for (int i = 1; i < result.length; i++) {
                                                     // The expected value would depend on derivative calculations,
                                                     // but we know they should be twice the atan result
                                                     // Since we don't have the derivative values, we'll just verify they're not 3x
                                                     assertNotEquals(3 * Math.atan(y[0]/(Math.sqrt(x[0]*x[0] + y[0]*y[0]) + x[0])), 
                                                                    result[i], 1e-10);
                                                 }
                                                 
                                                 // Another test case with different values to be thorough
                                                 y[0] = Math.sqrt(3);  // atan2(sqrt(3), 1) should be π/3 (1.047197...)
                                                 x[0] = 1.0;
                                                 compiler.atan2(y, 0, x, 0, result, 0);
                                                 assertEquals(Math.PI/3, result[0], 1e-10);
                                             }

 @Test
                                         public void testAtan2WithNegativeXShouldUseSubtraction() {
                                             // Create test instance (assuming parameters=1, order=1 for simplicity)
                                             DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                             
                                             // Test inputs where x is negative
                                             double[] y = {1.0};
                                             int yOffset = 0;
                                             double[] x = {-1.0};  // Negative x to trigger the mutated path
                                             int xOffset = 0;
                                             double[] result = new double[compiler.getSize()];
                                             int resultOffset = 0;
                                             
                                             // Calculate expected result manually
                                             double r = Math.sqrt(x[xOffset] * x[xOffset] + y[yOffset] * y[yOffset]);
                                             double expected = ((y[yOffset] <= 0) ? -FastMath.PI : FastMath.PI) - 
                                                               2 * Math.atan(y[yOffset] / (r - x[xOffset]));
                                             
                                             // Call the method
                                             compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                             
                                             // Verify the result matches expected calculation
                                             assertEquals("Result should match expected atan2 calculation", 
                                                         expected, result[resultOffset], 1e-10);
                                             
                                             // Additional verification that we're testing the right path
                                             assertTrue("x should be negative for this test", x[xOffset] < 0);
                                         }

 @Test
                                        public void testAtan2_DetectMutant_WhenXNegativeAndYZero() {
                                            // Setup
                                            DSCompiler compiler = DSCompiler.getCompiler(1, 1); // 1 parameter, order 1
                                            double[] y = new double[compiler.getSize()];
                                            double[] x = new double[compiler.getSize()];
                                            double[] result = new double[compiler.getSize()];
                                            
                                            // Set x negative and y zero to trigger the mutated branch with tmp2[0] == 0
                                            x[0] = -1.0; // x < 0
                                            y[0] = 0.0;  // y == 0
                                            
                                            // Expected result: atan2(0, -1) should be π (positive x-axis to negative x-axis)
                                            double expected = FastMath.PI;
                                            
                                            // Execute
                                            compiler.atan2(y, 0, x, 0, result, 0);
                                            
                                            // Verify
                                            // Original code would give π (correct), mutant would give -π (wrong)
                                            assertEquals("For x<0 and y=0, result should be π", 
                                                        expected, result[0], 1e-15);
                                            
                                            // Also verify other array elements are properly set
                                            for (int i = 1; i < result.length; i++) {
                                                assertEquals(0.0, result[i], 1e-15);
                                            }
                                        }

 @Test
                                      public void testAtan2NegativeXWithMultipleElements() {
                                          // Setup
                                          DSCompiler compiler = DSCompiler.getCompiler(1, 2); // parameters=1, order=2
                                          double[] y = new double[3];
                                          double[] x = new double[3];
                                          double[] result = new double[3];
                                          
                                          // Test case where x < 0 and array has multiple elements
                                          y[0] = 1.0;  // y coordinate
                                          x[0] = -1.0; // negative x coordinate
                                          y[1] = 0.5;  // derivative values
                                          y[2] = 0.25;
                                          x[1] = -0.5;
                                          x[2] = -0.25;
                                          
                                          // Expected results (manually calculated)
                                          double expectedFirstElement = FastMath.atan2(y[0], x[0]);
                                          double r = FastMath.sqrt(x[0]*x[0] + y[0]*y[0]);
                                          double expectedSecondElement = -2 * FastMath.atan(y[1] / (r - x[0]));
                                          double expectedThirdElement = -2 * FastMath.atan(y[2] / (r - x[0]));
                                          
                                          // Execute
                                          compiler.atan2(y, 0, x, 0, result, 0);
                                          
                                          // Verify
                                          assertEquals(expectedFirstElement, result[0], 1e-10);
                                          assertEquals(expectedSecondElement, result[1], 1e-10);  // This would fail with the mutant
                                          assertEquals(expectedThirdElement, result[2], 1e-10);    // This would fail with the mutant
                                      }

 @Test
                                  public void testAtan2_DetectsDoublingMutation() {
                                      // Setup test data
                                      DSCompiler compiler = mock(DSCompiler.class);
                                      when(compiler.getSize()).thenReturn(2);
                                      
                                      // Mock helper methods to control intermediate values
                                      doAnswer(invocation -> {
                                          double[] result = (double[]) invocation.getArguments()[4];
                                          result[0] = 25.0; // x^2 = 25
                                          result[1] = 0.0;
                                          return null;
                                      }).when(compiler).multiply(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
                                      
                                      doAnswer(invocation -> {
                                          double[] result = (double[]) invocation.getArguments()[4];
                                          result[0] = 144.0; // y^2 = 144
                                          result[1] = 0.0;
                                          return null;
                                      }).when(compiler).multiply(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
                                      
                                      doAnswer(invocation -> {
                                          double[] result = (double[]) invocation.getArguments()[4];
                                          result[0] = 169.0; // x^2 + y^2 = 169
                                          result[1] = 0.0;
                                          return null;
                                      }).when(compiler).add(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
                                      
                                      doAnswer(invocation -> {
                                          double[] result = (double[]) invocation.getArguments()[3];
                                          result[0] = 13.0; // r = sqrt(169) = 13
                                          result[1] = 0.0;
                                          return null;
                                      }).when(compiler).rootN(any(double[].class), anyInt(), anyInt(), any(double[].class), anyInt());
                                      
                                      doAnswer(invocation -> {
                                          double[] result = (double[]) invocation.getArguments()[4];
                                          result[0] = 18.0; // r + x = 13 + 5 = 18
                                          result[1] = 0.0;
                                          return null;
                                      }).when(compiler).add(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
                                      
                                      doAnswer(invocation -> {
                                          double[] result = (double[]) invocation.getArguments()[4];
                                          result[0] = 12.0/18.0; // y/(r+x) = 12/18
                                          result[1] = 0.0;
                                          return null;
                                      }).when(compiler).divide(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
                                      
                                      doAnswer(invocation -> {
                                          double[] result = (double[]) invocation.getArguments()[2];
                                          result[0] = 0.5880026; // atan(12/18) ~ 0.588 radians
                                          result[1] = 0.0;
                                          return null;
                                      }).when(compiler).atan(any(double[].class), anyInt(), any(double[].class), anyInt());
                                      
                                      // Input data (x=5, y=12)
                                      double[] x = new double[]{5.0, 0.0};
                                      double[] y = new double[]{12.0, 0.0};
                                      double[] result = new double[2];
                                      
                                      // Call method
                                      compiler.atan2(y, 0, x, 0, result, 0);
                                      
                                      // Verify results
                                      // Expected: 2 * atan(y/(r+x)) = 2 * 0.5880026 ≈ 1.176
                                      assertEquals(2 * 0.5880026, result[0], 1e-6);
                                      assertEquals(0.0, result[1], 1e-6);
                                      
                                      // This test will fail if the mutant is present because:
                                      // - Original code would return ~1.176 (correct)
                                      // - Mutant would return ~0.588 (incorrect)
                                  }

 @Test
                                 public void testAtan2WithNonZeroYToVerifyYSquaredCalculation() {
                                     // Setup test data
                                     DSCompiler compiler = DSCompiler.getCompiler(1, 1); // 1 parameter, 1st order
                                     double[] y = {3.0, 1.0}; // y value and its derivative
                                     double[] x = {4.0, 1.0}; // x value and its derivative
                                     double[] result = new double[2];
                                     
                                     // Expected angle for (4,3) is atan(3/4) ≈ 0.6435 radians
                                     double expectedAngle = Math.atan2(3.0, 4.0);
                                     
                                     // Call the method
                                     compiler.atan2(y, 0, x, 0, result, 0);
                                     
                                     // Verify the result
                                     assertEquals(expectedAngle, result[0], 1e-10);
                                     
                                     // Test with negative y to ensure y² is properly calculated
                                     y[0] = -3.0;
                                     expectedAngle = Math.atan2(-3.0, 4.0);
                                     compiler.atan2(y, 0, x, 0, result, 0);
                                     assertEquals(expectedAngle, result[0], 1e-10);
                                     
                                     // Test with x < 0 case to exercise both branches
                                     x[0] = -4.0;
                                     expectedAngle = Math.atan2(3.0, -4.0);
                                     compiler.atan2(y, 0, x, 0, result, 0);
                                     assertEquals(expectedAngle, result[0], 1e-10);
                                 }

 @Test
                                public void testAtan2DetectsAddToSubtractMutant() {
                                    // Create test compiler instance
                                    DSCompiler compiler = DSCompiler.getCompiler(2, 2); // Using 2 parameters and order 2
                                    
                                    // Test inputs where x² + y² ≠ x² - y²
                                    double[] x = {3.0, 0.0, 0.0}; // x = 3
                                    double[] y = {4.0, 0.0, 0.0}; // y = 4
                                    double[] result = new double[compiler.getSize()];
                                    
                                    // Expected atan2(4,3) ≈ 0.927295218
                                    double expected = FastMath.atan2(y[0], x[0]);
                                    
                                    // Call the method
                                    compiler.atan2(y, 0, x, 0, result, 0);
                                    
                                    // Verify the result matches expected atan2 value
                                    // The mutant would compute wrong r (sqrt(9-16) instead of sqrt(9+16)
                                    // leading to completely wrong angle calculation
                                    assertEquals(expected, result[0], 1.0e-15);
                                    
                                    // Also verify other array elements are properly set
                                    for (int i = 1; i < result.length; i++) {
                                        assertEquals(0.0, result[i], 0.0);
                                    }
                                }

 @Test
                              public void testAtan2DetectsRootNMutant1() {
                                  // Create test compiler with known parameters using public factory method
                                  DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                                  
                                  // Test values where square root and cube root differ significantly
                                  double[] y = {4.0, 0.0, 0.0};  // y coordinate
                                  double[] x = {-3.0, 0.0, 0.0}; // x coordinate (negative to test the mutated branch)
                                  double[] result = new double[3];
                                  
                                  // Calculate expected value using correct formula
                                  double expected = FastMath.atan2(y[0], x[0]);
                                  
                                  // Call the method
                                  compiler.atan2(y, 0, x, 0, result, 0);
                                  
                                  // The mutant will compute cube root instead of square root, making the result wrong
                                  // We check if the result matches FastMath.atan2 (which is used as final correct value)
                                  assertEquals("Mutant should be caught by comparing with correct atan2 value", 
                                             expected, result[0], 1e-15);
                                  
                                  // Additional check - verify the magnitude calculation would be wrong
                                  // With original code: r = sqrt(3² + 4²) = 5
                                  // With mutant: r = cbrt(3² + 4²) = cbrt(25) ≈ 2.924
                                  // This affects the denominator (r - x) which would be:
                                  // Original: 5 - (-3) = 8
                                  // Mutant: 2.924 - (-3) ≈ 5.924
                                  // Leading to different atan calculation
                              }

 @Test
                          public void testAtan2WithXEqualsZero1() {
                              // Setup test data for x=0 case
                              DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Using simplest case with 1 parameter and order 1
                              double[] y = new double[compiler.getSize()];
                              double[] x = new double[compiler.getSize()];
                              double[] result = new double[compiler.getSize()];
                              
                              // Set x=0 and y=1 (could be any non-zero y)
                              x[0] = 0.0;
                              y[0] = 1.0;
                              
                              // Call the method
                              compiler.atan2(y, 0, x, 0, result, 0);
                              
                              // Verify the result matches FastMath.atan2 for x=0 case
                              double expected = FastMath.atan2(y[0], x[0]);
                              assertEquals("Result should match FastMath.atan2 for x=0 case", 
                                          expected, result[0], 1e-15);
                              
                              // Also verify other elements in result array (if any)
                              for (int i = 1; i < result.length; i++) {
                                  assertEquals(0.0, result[i], 1e-15);
                              }
                          }

 @Test
                         public void testAtan2DetectsDivideToMultiplyMutant() {
                             // Setup test data for both cases (x >=0 and x < 0)
                             DSCompiler compiler = DSCompiler.getCompiler(1, 1); // 1 parameter, order 1
                             
                             // Case 1: x >= 0 (should compute 2*atan(y/(r+x)))
                             double[] y1 = {1.0};
                             double[] x1 = {1.0};
                             double[] result1 = new double[compiler.getSize()];
                             
                             // Case 2: x < 0 (should compute ±π - 2*atan(y/(r-x)))
                             double[] y2 = {1.0};
                             double[] x2 = {-1.0};
                             double[] result2 = new double[compiler.getSize()];
                             
                             // Expected values calculated manually
                             double expected1 = FastMath.atan2(1.0, 1.0);  // π/4
                             double expected2 = FastMath.atan2(1.0, -1.0); // 3π/4
                             
                             // Execute both cases
                             compiler.atan2(y1, 0, x1, 0, result1, 0);
                             compiler.atan2(y2, 0, x2, 0, result2, 0);
                             
                             // Assertions - these will fail if the divide was mutated to multiply
                             assertEquals(expected1, result1[0], 1e-10);
                             assertEquals(expected2, result2[0], 1e-10);
                             
                             // Additional test with different values to be thorough
                             double[] y3 = {2.0};
                             double[] x3 = {3.0};
                             double[] result3 = new double[compiler.getSize()];
                             double expected3 = FastMath.atan2(2.0, 3.0);
                             compiler.atan2(y3, 0, x3, 0, result3, 0);
                             assertEquals(expected3, result3[0], 1e-10);
                             
                             double[] y4 = {2.0};
                             double[] x4 = {-3.0};
                             double[] result4 = new double[compiler.getSize()];
                             double expected4 = FastMath.atan2(2.0, -3.0);
                             compiler.atan2(y4, 0, x4, 0, result4, 0);
                             assertEquals(expected4, result4[0], 1e-10);
                         }

 @Test
                       public void testAtan2PositiveXDetectsMultiplicationMutant() {
                           // Setup test data for x >= 0 case
                           DSCompiler compiler = DSCompiler.getCompiler(2, 2); // Using public factory method
                           double[] y = {1.0, 0.5, 0.25}; // Test values
                           double[] x = {1.0, 1.0, 1.0};  // All x >= 0
                           double[] result = new double[3]; // Result array
                           
                           // Calculate expected values manually
                           double r = Math.sqrt(x[0]*x[0] + y[0]*y[0]);
                           double expectedAtan = Math.atan(y[0]/(r + x[0]));
                           
                           // Call the method
                           compiler.atan2(y, 0, x, 0, result, 0);
                           
                           // Verify all array elements (except first which uses FastMath.atan2)
                           // Original should be 2*atan, mutant would be 3*atan
                           assertEquals(2 * expectedAtan, result[1], 1e-15);
                           assertEquals(2 * expectedAtan, result[2], 1e-15);
                           
                           // Also verify the first element uses FastMath.atan2
                           assertEquals(Math.atan2(y[0], x[0]), result[0], 1e-15);
                       }

 @Test
                   public void testAtan2_DetectsMutantWhenTmp2IsZero() {
                       // Setup
                       DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Using 1 parameter and order 1
                       double[] y = new double[compiler.getSize()];
                       double[] x = new double[compiler.getSize()];
                       double[] result = new double[compiler.getSize()];
                       
                       // Create a case where x is negative and y/(r-x) = 0
                       // This happens when y = 0 and x < 0
                       x[0] = -1.0;  // x is negative
                       y[0] = 0.0;   // y is zero
                       
                       // Expected value from original code (should use -PI when tmp2[0] = 0)
                       double expected = FastMath.PI; // Original would return PI for atan2(0, -1)
                       
                       // Test
                       compiler.atan2(y, 0, x, 0, result, 0);
                       
                       // Assert
                       assertEquals("Should detect mutant when tmp2[0] = 0", 
                                   expected, result[0], 1e-15);
                       
                       // Additional check to ensure we're testing the right case
                       // The intermediate value tmp2[0] should be exactly 0
                       double[] tmp1 = new double[compiler.getSize()];
                       double[] tmp2 = new double[compiler.getSize()];
                       compiler.multiply(x, 0, x, 0, tmp1, 0);
                       compiler.multiply(y, 0, y, 0, tmp2, 0);
                       compiler.add(tmp1, 0, tmp2, 0, tmp2, 0);
                       compiler.rootN(tmp2, 0, 2, tmp1, 0);
                       compiler.subtract(tmp1, 0, x, 0, tmp2, 0);
                       compiler.divide(y, 0, tmp2, 0, tmp1, 0);
                       compiler.atan(tmp1, 0, tmp2, 0);
                       assertEquals("tmp2[0] should be exactly 0 for this test case", 
                                   0.0, tmp2[0], 0.0);
                   }

 @Test
                 public void testAtan2NegativeXWithMultipleDerivatives() {
                     // Setup test data for x < 0 case with multiple derivatives
                     DSCompiler compiler = DSCompiler.getCompiler(1, 2); // parameters=1, order=2 (size=3)
                     double[] y = new double[3];
                     double[] x = new double[3];
                     double[] result = new double[3];
                     
                     // Set values that will make x < 0 and y != 0
                     x[0] = -1.0; // x coordinate
                     y[0] = 1.0;  // y coordinate
                     
                     // Set some derivative values (i > 0 elements)
                     x[1] = 0.5;  // first derivative of x
                     y[1] = 0.5;  // first derivative of y
                     x[2] = 0.25; // second derivative of x
                     y[2] = 0.25; // second derivative of y
                     
                     // Call the method
                     compiler.atan2(y, 0, x, 0, result, 0);
                     
                     // Verify the first element (i=0) is correct
                     assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-15);
                     
                     // Verify higher-order derivatives (i > 0) have negative coefficients
                     // This is where the mutant would fail - it would give positive values
                     assertTrue("First derivative should be negative", result[1] < 0);
                     assertTrue("Second derivative should be negative", result[2] < 0);
                     
                     // Additional verification: check the values are approximately correct
                     // Compute expected values manually or using reference implementation
                     double r = FastMath.sqrt(x[0]*x[0] + y[0]*y[0]);
                     double denom = r - x[0];
                     double atanTerm = FastMath.atan(y[0]/denom);
                     double expectedFirstDerivative = -2 * (y[1]/denom - y[0]*(x[1] - x[0]*x[1]/r)/(denom*denom + y[0]*y[0]));
                     assertEquals(expectedFirstDerivative, result[1], 1e-10);
                 }

 @Test
             public void testAtan2_DetectsDoublingMutation1() {
                 // Setup test data
                 DSCompiler compiler = mock(DSCompiler.class);
                 when(compiler.getSize()).thenReturn(2);
                 
                 double[] x = {1.0, 0.0};  // x >= 0 case
                 double[] y = {1.0, 0.0};
                 double[] result = new double[2];
                 
                 // Mock helper methods to control intermediate results
                 doAnswer(inv -> {
                     double[] tmp1 = (double[]) inv.getArguments()[4];
                     tmp1[0] = 1.0;  // x^2 = 1
                     tmp1[1] = 0.0;
                     return null;
                 }).when(compiler).multiply(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
                 
                 doAnswer(inv -> {
                     double[] tmp2 = (double[]) inv.getArguments()[4];
                     tmp2[0] = 1.0;  // y^2 = 1
                     tmp2[1] = 0.0;
                     return null;
                 }).when(compiler).multiply(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
                 
                 doAnswer(inv -> {
                     double[] tmp2 = (double[]) inv.getArguments()[4];
                     tmp2[0] = 2.0;  // x^2 + y^2 = 2
                     tmp2[1] = 0.0;
                     return null;
                 }).when(compiler).add(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
                 
                 doAnswer(inv -> {
                     double[] tmp1 = (double[]) inv.getArguments()[3];
                     tmp1[0] = Math.sqrt(2);  // r = sqrt(2)
                     tmp1[1] = 0.0;
                     return null;
                 }).when(compiler).rootN(any(double[].class), anyInt(), anyInt(), any(double[].class), anyInt());
                 
                 doAnswer(inv -> {
                     double[] tmp2 = (double[]) inv.getArguments()[4];
                     tmp2[0] = Math.sqrt(2) + 1;  // r + x
                     tmp2[1] = 0.0;
                     return null;
                 }).when(compiler).add(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
                 
                 doAnswer(inv -> {
                     double[] tmp1 = (double[]) inv.getArguments()[4];
                     tmp1[0] = y[0] / (Math.sqrt(2) + 1);  // y/(r+x)
                     tmp1[1] = 0.0;
                     return null;
                 }).when(compiler).divide(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
                 
                 doAnswer(inv -> {
                     double[] tmp2 = (double[]) inv.getArguments()[3];
                     double atanValue = Math.atan(y[0] / (Math.sqrt(2) + 1));
                     tmp2[0] = atanValue;  // atan(y/(r+x))
                     tmp2[1] = 0.0;
                     return null;
                 }).when(compiler).atan(any(double[].class), anyInt(), any(double[].class), anyInt());
                 
                 // Execute
                 compiler.atan2(y, 0, x, 0, result, 0);
                 
                 // Verify
                 double expectedAtan = Math.atan(y[0] / (Math.sqrt(2) + 1));
                 assertEquals(2 * expectedAtan, result[0], 1e-15);  // Should be doubled
                 assertEquals(0.0, result[1], 1e-15);
             }

 @Test
            public void testAtan2DetectsYSquaredCalculation() {
                // Setup test data
                DSCompiler compiler = DSCompiler.getCompiler(1, 1); // 1 parameter, order 1
                double[] y = {3.0, 1.0}; // y value and its derivative
                double[] x = {4.0, 1.0}; // x value and its derivative
                double[] result = new double[compiler.getSize()];
                
                // Expected result when y² is calculated correctly
                double expectedAngle = FastMath.atan2(y[0], x[0]);
                
                // Call the method
                compiler.atan2(y, 0, x, 0, result, 0);
                
                // Verify the main angle calculation
                assertEquals(expectedAngle, result[0], 1e-15);
                
                // Now test with negative x to cover the other branch
                double[] xNeg = {-4.0, 1.0};
                double expectedAngleNeg = FastMath.atan2(y[0], xNeg[0]);
                compiler.atan2(y, 0, xNeg, 0, result, 0);
                assertEquals(expectedAngleNeg, result[0], 1e-15);
                
                // Test with different y values to ensure y² affects result
                double[] y2 = {5.0, 1.0};
                double expectedAngle2 = FastMath.atan2(y2[0], x[0]);
                compiler.atan2(y2, 0, x, 0, result, 0);
                assertEquals(expectedAngle2, result[0], 1e-15);
                
                // Test with y=0 edge case
                double[] yZero = {0.0, 0.0};
                double expectedAngleZero = FastMath.atan2(yZero[0], x[0]);
                compiler.atan2(yZero, 0, x, 0, result, 0);
                assertEquals(expectedAngleZero, result[0], 1e-15);
            }

 @Test
          public void testAtan2DetectsRootNMutation() {
              // Create test compiler instance using public factory method (parameters=2, order=1)
              DSCompiler compiler = DSCompiler.getCompiler(2, 1);
              
              // Test data where x² + y² = 8 (2^3)
              // Square root of 8 is 2.828, cube root is 2.0
              // This will show difference between rootN with n=2 vs n=3
              double[] x = {2.0, 0.0};  // x = 2
              double[] y = {2.0, 0.0};  // y = 2
              double[] result = new double[compiler.getSize()];
              
              // Expected atan2(2,2) = π/4 ≈ 0.785398
              double expected = FastMath.PI / 4;
              
              // Test positive x case (first branch)
              compiler.atan2(y, 0, x, 0, result, 0);
              
              // Verify result matches expected atan2 calculation
              // The mutant using cube root would produce a different result
              assertEquals(expected, result[0], 1e-10);
              
              // Test negative x case (second branch)
              x[0] = -2.0;
              expected = FastMath.PI * 3 / 4;  // Expected atan2(2,-2) = 3π/4 ≈ 2.35619
              compiler.atan2(y, 0, x, 0, result, 0);
              assertEquals(expected, result[0], 1e-10);
              
              // Additional test with different values
              x[0] = 3.0;
              y[0] = 4.0;  // x² + y² = 25
              expected = FastMath.atan2(4.0, 3.0);  // ≈ 0.927295
              compiler.atan2(y, 0, x, 0, result, 0);
              assertEquals(expected, result[0], 1e-10);
          }

 @Test
      public void testAtan2WithXEqualsZero2() {
          // Create test instance (assuming parameters=1, order=1 for simplicity)
          DSCompiler compiler = DSCompiler.getCompiler(1, 1);
          
          // Test case where x=0, y=1 (should be π/2)
          double[] y = new double[compiler.getSize()];
          double[] x = new double[compiler.getSize()];
          double[] result = new double[compiler.getSize()];
          
          // Set x=0, y=1
          y[0] = 1.0;
          x[0] = 0.0;
          
          // Calculate atan2
          compiler.atan2(y, 0, x, 0, result, 0);
          
          // Verify result matches FastMath.atan2 (original behavior)
          assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1.0e-15);
          
          // Additional verification for the case where x=0, y=-1 (should be -π/2)
          y[0] = -1.0;
          x[0] = 0.0;
          compiler.atan2(y, 0, x, 0, result, 0);
          assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1.0e-15);
      }

 @Test
     public void testAtan2NegativeXDetectsDivideToMultiplyMutant() {
         // Setup
         DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Using simplest case with 1 parameter and order 1
         double[] y = new double[compiler.getSize()];
         double[] x = new double[compiler.getSize()];
         double[] result = new double[compiler.getSize()];
         
         // Choose values where x < 0 to trigger the mutated path
         // Using y=1, x=-1 which should give 3π/4 (2.35619 radians)
         y[0] = 1.0;
         x[0] = -1.0;
         
         // Expected value from standard Math.atan2
         double expected = FastMath.atan2(y[0], x[0]);
         
         // Execute
         compiler.atan2(y, 0, x, 0, result, 0);
         
         // Verify
         // The mutation would calculate y*(r-x) instead of y/(r-x), leading to completely wrong angle
         assertEquals(expected, result[0], 1e-10);
         
         // Also verify other array elements are properly set
         for (int i = 1; i < result.length; i++) {
             assertEquals(0.0, result[i], 1e-10);
         }
     }

 @Test
    public void testAtan2PositiveXDetectsMultiplicationMutant1() {
        // Setup test data for x >= 0 case
        DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Using simplest case with 1 parameter and order 1
        double[] y = new double[compiler.getSize()];
        double[] x = new double[compiler.getSize()];
        double[] result = new double[compiler.getSize()];
        
        // Use known values where we can compute expected result manually
        // Using x=1.0, y=1.0 which should give π/2 (45 degrees)
        x[0] = 1.0;
        y[0] = 1.0;
        
        // For derivatives (i > 0), set some non-zero values
        if (compiler.getSize() > 1) {
            x[1] = 0.5;
            y[1] = 0.5;
        }
        
        // Call the method
        compiler.atan2(y, 0, x, 0, result, 0);
        
        // Verify main value (i=0)
        double expectedMain = FastMath.atan2(y[0], x[0]);
        assertEquals("Main value should match FastMath.atan2", expectedMain, result[0], 1e-15);
        
        // Verify the multiplication factor for derivatives (i > 0)
        if (compiler.getSize() > 1) {
            double r = FastMath.hypot(x[0], y[0]);
            double expectedDerivative = 2 * FastMath.atan(y[1] / (r + x[1]));
            assertEquals("Derivative value should use correct multiplication factor (2*)", 
                        expectedDerivative, result[1], 1e-15);
        }
    }

 @Test
   public void testAtan2_DetectMutant_WhenXNegativeAndYZero1() {
       // Create a mock DSCompiler with size 1 for simplicity
       DSCompiler compiler = mock(DSCompiler.class);
       when(compiler.getSize()).thenReturn(1);
       
       // Setup test data where x < 0 and y = 0
       double[] x = new double[]{-1.0};
       double[] y = new double[]{0.0};
       double[] result = new double[1];
       
       // Mock the behavior of called methods to force tmp2[0] = 0
       doAnswer(invocation -> {
           double[] res = invocation.getArgument(4);
           res[0] = 1.0; // r = sqrt(x^2 + y^2) = 1.0
           return null;
       }).when(compiler).rootN(any(), anyInt(), anyInt(), any(), anyInt());
       
       doAnswer(invocation -> {
           double[] res = invocation.getArgument(4);
           res[0] = 2.0; // r - x = 1 - (-1) = 2
           return null;
       }).when(compiler).subtract(any(), anyInt(), any(), anyInt(), any(), anyInt());
       
       doAnswer(invocation -> {
           double[] res = invocation.getArgument(4);
           res[0] = 0.0; // y / (r - x) = 0 / 2 = 0
           return null;
       }).when(compiler).divide(any(), anyInt(), any(), anyInt(), any(), anyInt());
       
       doAnswer(invocation -> {
           double[] res = invocation.getArgument(2);
           res[0] = 0.0; // atan(0) = 0
           return null;
       }).when(compiler).atan(any(), anyInt(), any(), anyInt());
       
       // Execute the method
       compiler.atan2(y, 0, x, 0, result, 0);
       
       // Verify the result - original would return -π, mutant would return +π
       // Since we want to catch the mutant, we assert it should be -π
       assertEquals(-FastMath.PI, result[0], 0.0001);
       
       // Also verify the interactions
       verify(compiler).rootN(any(), anyInt(), anyInt(), any(), anyInt());
       verify(compiler).subtract(any(), anyInt(), any(), anyInt(), any(), anyInt());
       verify(compiler).divide(any(), anyInt(), any(), anyInt(), any(), anyInt());
       verify(compiler).atan(any(), anyInt(), any(), anyInt());
   }

 @Test
  public void testAtan2NegativeXWithMultipleElements1() {
      // Setup
      DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Using simplest case with 1 parameter and order 1
      double[] y = new double[2];
      double[] x = new double[2];
      double[] result = new double[2];
      
      // Values where x < 0 to trigger the else branch
      y[0] = 1.0;  // y coordinate
      x[0] = -1.0; // negative x coordinate
      y[1] = 0.5;  // derivative value
      x[1] = -0.5; // derivative value
      
      // Expected results
      double expectedFirst = FastMath.atan2(y[0], x[0]); // Special handling for first element
      double expectedSecond = -2 * FastMath.atan(y[1] / (FastMath.sqrt(x[0]*x[0] + y[0]*y[0]) - x[0]));
      
      // Test
      compiler.atan2(y, 0, x, 0, result, 0);
      
      // Assertions
      assertEquals("First element should match FastMath.atan2", expectedFirst, result[0], 1e-15);
      assertEquals("Subsequent elements should be properly negated", expectedSecond, result[1], 1e-15);
      
      // Additional check to specifically catch the mutant
      assertTrue("Second element should be negative when x is negative", result[1] < 0);
  }

 @Test
 public void testAtan2_DetectsDoublingMutation_WhenXIsPositive() {
     // Setup test data
     DSCompiler compiler = mock(DSCompiler.class);
     when(compiler.getSize()).thenReturn(2);
     
     double[] x = {1.0, 0.0};  // x >= 0 case
     double[] y = {1.0, 0.0};
     double[] result = new double[2];
     
     // Mock helper methods to control intermediate results
     doAnswer(invocation -> {
         double[] res = (double[]) invocation.getArguments()[4];
         res[0] = 1.0; // x^2 = 1
         res[1] = 0.0;
         return null;
     }).when(compiler).multiply(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
     
     doAnswer(invocation -> {
         double[] res = (double[]) invocation.getArguments()[4];
         res[0] = 1.0; // y^2 = 1
         res[1] = 0.0;
         return null;
     }).when(compiler).multiply(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
     
     doAnswer(invocation -> {
         double[] res = (double[]) invocation.getArguments()[4];
         res[0] = 2.0; // x^2 + y^2 = 2
         res[1] = 0.0;
         return null;
     }).when(compiler).add(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
     
     doAnswer(invocation -> {
         double[] res = (double[]) invocation.getArguments()[3];
         res[0] = Math.sqrt(2); // r = sqrt(2)
         res[1] = 0.0;
         return null;
     }).when(compiler).rootN(any(double[].class), anyInt(), anyInt(), any(double[].class), anyInt());
     
     doAnswer(invocation -> {
         double[] res = (double[]) invocation.getArguments()[4];
         res[0] = Math.sqrt(2) + 1; // r + x
         res[1] = 0.0;
         return null;
     }).when(compiler).add(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
     
     doAnswer(invocation -> {
         double[] res = (double[]) invocation.getArguments()[4];
         res[0] = 1.0 / (Math.sqrt(2) + 1); // y/(r + x)
         res[1] = 0.0;
         return null;
     }).when(compiler).divide(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
     
     doAnswer(invocation -> {
         double[] res = (double[]) invocation.getArguments()[2];
         double atanValue = Math.atan(1.0 / (Math.sqrt(2) + 1));
         res[0] = atanValue; // atan(y/(r + x))
         res[1] = 0.0;
         return null;
     }).when(compiler).atan(any(double[].class), anyInt(), any(double[].class), anyInt());
     
     // Execute
     compiler.atan2(y, 0, x, 0, result, 0);
     
     // Verify - should be 2*atanValue
     double expected = 2 * Math.atan(1.0 / (Math.sqrt(2) + 1));
     assertEquals(expected, result[0], 1e-15);
     assertEquals(0.0, result[1], 1e-15);
     
     // Also verify the final fix with FastMath.atan2
     verify(compiler, times(1)).atan2(y, 0, x, 0, result, 0);
 }

}
