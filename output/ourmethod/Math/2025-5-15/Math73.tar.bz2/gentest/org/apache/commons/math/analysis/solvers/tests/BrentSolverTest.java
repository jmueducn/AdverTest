package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class BrentSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                              public void testSolve_TypicalCase() {
                                                                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Should find root between 1 and 2
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                              public void testSolve_MinEqualsMax_ZeroValue() throws Exception {
                                                                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                  when(f.value(1.5)).thenReturn(0.0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                  double result = solver.solve(1.5, 1.5);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  assertEquals(1.5, result, 0.0);
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                              public void testSolve_MinGreaterThanMax() throws Exception {
                                                                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                  when(f.value(2.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                  double result = solver.solve(2.0, 1.0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Should still find root between 1 and 2
                                                                                                                                                                                                                                                                  assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                              public void testSolve_VerySmallInterval() throws Exception {
                                                                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(-1e-10);
                                                                                                                                                                                                                                                                  when(f.value(1.0 + 1e-8)).thenReturn(1e-10);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                  double result = solver.solve(1.0, 1.0 + 1e-8);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  assertTrue(result >= 1.0 && result <= 1.0 + 1e-8);
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                              public void testSolve_WithDefaultConstructor() throws Exception {
                                                                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                  when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                                  double result = solver.solve(f, 1.0, 2.0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                              public void testSolve_ConvergesWithinTolerance() throws Exception {
                                                                                                                                                                                                                                                                  // Setup mock function that crosses zero at x=2.0
                                                                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                  when(f.value(3.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                  when(f.value(2.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                                  when(f.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                                                                                                                  when(f.value(2.5)).thenReturn(0.5);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                  double result = solver.solve(f, 1.0, 3.0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  assertEquals(2.0, result, 1e-6);
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                              public void testSolve_AlreadyAtSolution() throws Exception {
                                                                                                                                                                                                                                                                  // Setup mock function where one of the bounds is already the solution
                                                                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                                  when(f.value(3.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                  double result = solver.solve(f, 1.0, 3.0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  assertEquals(1.0, result, 1e-6);
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                              public void testSolve_LinearInterpolationCase() throws Exception {
                                                                                                                                                                                                                                                                  // Setup case that triggers linear interpolation path
                                                                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                  when(f.value(3.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                  when(f.value(2.0)).thenReturn(0.5);
                                                                                                                                                                                                                                                                  when(f.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                                                                                                                  when(f.value(1.75)).thenReturn(0.0); // Exact solution
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                  double result = solver.solve(f, 1.0, 3.0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  assertEquals(1.75, result, 1e-6);
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                              public void testSolve_InverseQuadraticInterpolationCase() throws Exception {
                                                                                                                                                                                                                                                                  // Setup case that triggers inverse quadratic interpolation path
                                                                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                  when(f.value(3.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                  when(f.value(2.0)).thenReturn(0.3);
                                                                                                                                                                                                                                                                  when(f.value(1.5)).thenReturn(-0.4);
                                                                                                                                                                                                                                                                  when(f.value(1.8)).thenReturn(-0.1);
                                                                                                                                                                                                                                                                  when(f.value(1.9)).thenReturn(0.0); // Exact solution
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                  double result = solver.solve(f, 1.0, 3.0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  assertEquals(1.9, result, 1e-6);
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                              public void testSolve_ForceBisectionCase() throws Exception {
                                                                                                                                                                                                                                                                  // Setup case that forces bisection
                                                                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                  when(f.value(3.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                  when(f.value(2.0)).thenReturn(0.9); // Close to upper bound
                                                                                                                                                                                                                                                                  when(f.value(1.5)).thenReturn(-0.1);
                                                                                                                                                                                                                                                                  when(f.value(1.75)).thenReturn(0.0); // Exact solution
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                  double result = solver.solve(f, 1.0, 3.0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  assertEquals(1.75, result, 1e-6);
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                              public void testSolve_WithFunctionValueAccuracy() throws Exception {
                                                                                                                                                                                                                                                                  // Setup case where y1 is within function value accuracy
                                                                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                  when(f.value(3.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                  when(f.value(2.0)).thenReturn(1e-7); // Within default function value accuracy
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                  double result = solver.solve(f, 1.0, 3.0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  assertEquals(2.0, result, 1e-6);
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_MinEqualsMax_NonZeroValue() throws Exception {
                                                                                                                                                                                                                                                          // Setup expected exception
                                                                                                                                                                                                                                                          ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Create mock function
                                                                                                                                                                                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          when(f.value(1.5)).thenReturn(0.5);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Expect exception
                                                                                                                                                                                                                                                          exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                          exception.expectMessage("function values at endpoints do not have different signs");
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Test
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                          solver.solve(1.5, 1.5);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_SameSignAtEndpoints() throws Exception {
                                                                                                                                                                                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                          when(f.value(2.0)).thenReturn(2.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                          exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                          exception.expectMessage("function values at endpoints do not have different signs");
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                          solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                                      }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                                      public void testSolve_FunctionThrowsException() throws Exception {
                                                                                                                                                                                                                                                          // Mock the function to throw exception
                                                                                                                                                                                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          when(f.value(anyDouble())).thenThrow(new IllegalArgumentException("Function error"));
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Test the solver - should throw the expected exception
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                          solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_WithFunctionAndRange_ConvergesToRoot() throws Exception {
                                                                                                                                                                                                                                                          // Create mock function
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          // Setup mock function that crosses zero at x=2.5
                                                                                                                                                                                                                                                          when(mockFunction.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(2.0)).thenReturn(-0.5);
                                                                                                                                                                                                                                                          when(mockFunction.value(3.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(2.5)).thenReturn(0.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Create solver instance
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Test and verify
                                                                                                                                                                                                                                                          double result = solver.solve(mockFunction, 1.0, 3.0);
                                                                                                                                                                                                                                                          assertEquals(2.5, result, 1E-6);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_WithFunctionAndRangeAndInitial_ConvergesToRoot() throws Exception {
                                                                                                                                                                                                                                                          // Create mock function
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Setup mock function that crosses zero at x=1.5
                                                                                                                                                                                                                                                          when(mockFunction.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.5)).thenReturn(0.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.25)).thenReturn(-0.5);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Create solver instance
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          double result = solver.solve(mockFunction, 1.0, 2.0, 1.25);
                                                                                                                                                                                                                                                          assertEquals(1.5, result, 1E-6);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_WithInvalidRange_ThrowsException() throws Exception {
                                                                                                                                                                                                                                                          // Setup mock function
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          when(mockFunction.value(anyDouble())).thenReturn(1.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Setup solver
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Setup expected exception
                                                                                                                                                                                                                                                          ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                          exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Test with invalid range (min == max)
                                                                                                                                                                                                                                                          solver.solve(mockFunction, 1.0, 1.0);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_WithFunctionConstructor_WorksCorrectly() throws Exception {
                                                                                                                                                                                                                                                          // Create mock function
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Setup mock function that crosses zero at x=0.5
                                                                                                                                                                                                                                                          when(mockFunction.value(0.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(0.5)).thenReturn(0.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          BrentSolver customSolver = new BrentSolver(mockFunction);
                                                                                                                                                                                                                                                          double result = customSolver.solve(0.0, 1.0);
                                                                                                                                                                                                                                                          assertEquals(0.5, result, 1E-6);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_WithRootAtBoundary_ReturnsBoundary() throws Exception {
                                                                                                                                                                                                                                                          // Create mock function
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          // Create solver instance
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Setup mock function with root at lower boundary
                                                                                                                                                                                                                                                          when(mockFunction.value(0.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          double result = solver.solve(mockFunction, 0.0, 1.0);
                                                                                                                                                                                                                                                          assertEquals(0.0, result, 1E-6);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Setup mock function with root at upper boundary
                                                                                                                                                                                                                                                          when(mockFunction.value(0.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          result = solver.solve(mockFunction, 0.0, 1.0);
                                                                                                                                                                                                                                                          assertEquals(1.0, result, 1E-6);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_WithFunctionThatThrows_PropagatesException() throws Exception {
                                                                                                                                                                                                                                                          // Setup mock function that throws when evaluated
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          when(mockFunction.value(anyDouble())).thenThrow(new ArithmeticException("Test exception"));
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Setup solver
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Setup exception expectation
                                                                                                                                                                                                                                                          ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                          exception.expect(ArithmeticException.class);
                                                                                                                                                                                                                                                          exception.expectMessage("Test exception");
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          solver.solve(mockFunction, 0.0, 1.0);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_InitialGuessIsRoot() throws Exception {
                                                                                                                                                                                                                                                          // Create mock function
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.5)).thenReturn(0.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Create solver instance
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          double result = solver.solve(mockFunction, 1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                          assertEquals(1.5, result, 0.0);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_MinIsRoot() throws Exception {
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          when(mockFunction.value(1.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.5)).thenReturn(1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(2.0)).thenReturn(2.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          double result = solver.solve(mockFunction, 1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                          assertEquals(1.0, result, 0.0);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_RootBetweenMinAndInitial() throws Exception {
                                                                                                                                                                                                                                                          // Create mock function
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.5)).thenReturn(1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(2.0)).thenReturn(2.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Create solver instance
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          double result = solver.solve(mockFunction, 1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                          // Should return a value between 1.0 and 1.5
                                                                                                                                                                                                                                                          assertTrue(result > 1.0 && result < 1.5);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_RootBetweenInitialAndMax() throws Exception {
                                                                                                                                                                                                                                                          // Create mock function
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.0)).thenReturn(-2.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.5)).thenReturn(-1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Create solver instance
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          double result = solver.solve(mockFunction, 1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                          // Should return a value between 1.5 and 2.0
                                                                                                                                                                                                                                                          assertTrue(result > 1.5 && result < 2.0);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_FullAlgorithmExecution() throws Exception {
                                                                                                                                                                                                                                                          // Create mock function
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Setup a function where root is not at endpoints or initial guess
                                                                                                                                                                                                                                                          when(mockFunction.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                                                                                                          when(mockFunction.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                          // Additional values needed for the full algorithm
                                                                                                                                                                                                                                                          when(mockFunction.value(anyDouble())).thenAnswer(invocation -> {
                                                                                                                                                                                                                                                              double x = invocation.getArgument(0, Double.class);
                                                                                                                                                                                                                                                              return x - 1.8;  // root at 1.8
                                                                                                                                                                                                                                                          });
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Create solver instance
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          double result = solver.solve(mockFunction, 1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                          assertEquals(1.8, result, 1e-6);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_WithFunctionValueAccuracy1() throws Exception {
                                                                                                                                                                                                                                                          // Setup mock function
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.0)).thenReturn(-1e-7);
                                                                                                                                                                                                                                                          when(mockFunction.value(1.5)).thenReturn(1e-8);  // within accuracy
                                                                                                                                                                                                                                                          when(mockFunction.value(2.0)).thenReturn(1e-7);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Create solver with appropriate accuracy
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                          // Set functionValueAccuracy through reflection since it's inherited from parent
                                                                                                                                                                                                                                                          Field fvaField = solver.getClass().getSuperclass().getDeclaredField("functionValueAccuracy");
                                                                                                                                                                                                                                                          fvaField.setAccessible(true);
                                                                                                                                                                                                                                                          fvaField.set(solver, 1e-6);  // standard accuracy
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          double result = solver.solve(mockFunction, 1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                          assertEquals(1.5, result, 0.0);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_BracketingInterval() throws Exception {
                                                                                                                                                                                                                                                          // Create mock function
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          // Set up mock behavior
                                                                                                                                                                                                                                                          when(mockFunction.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(4.0)).thenReturn(2.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Create solver instance
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Test case where function values have opposite signs at endpoints
                                                                                                                                                                                                                                                          double result = solver.solve(mockFunction, 1.0, 4.0);
                                                                                                                                                                                                                                                          assertFalse(Double.isNaN(result));
                                                                                                                                                                                                                                                          assertTrue(result >= 1.0 && result <= 4.0);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testSolve_MinIsRoot1() throws Exception {
                                                                                                                                                                                                                                                          // Test case where min is exactly the root
                                                                                                                                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                          when(mockFunction.value(2.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                          when(mockFunction.value(5.0)).thenReturn(3.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                          double result = solver.solve(mockFunction, 2.0, 5.0);
                                                                                                                                                                                                                                                          assertEquals(2.0, result, 0.0001);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                  public void testSolve_MaxIsRoot() throws Exception {
                                                                                                                                                                                                                                                      // Test case where max is exactly the root
                                                                                                                                                                                                                                                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                      when(mockFunction.value(1.0)).thenReturn(-2.0);
                                                                                                                                                                                                                                                      when(mockFunction.value(3.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                      double result = solver.solve(mockFunction, 1.0, 3.0);
                                                                                                                                                                                                                                                      assertEquals(3.0, result, 0.0001);
                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                  public void testSolve_MinCloseToZero() throws Exception {
                                                                                                                                                                                                                                                      // Define a simple test function where f(1.0) = 1E-7
                                                                                                                                                                                                                                                      UnivariateRealFunction f = new UnivariateRealFunction() {
                                                                                                                                                                                                                                                          public double value(double x) {
                                                                                                                                                                                                                                                              if (x == 1.0) return 1E-7;
                                                                                                                                                                                                                                                              return x - 2.0; // root at 2.0
                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Create solver with default accuracy
                                                                                                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Test case where min is very close to zero (within functionValueAccuracy)
                                                                                                                                                                                                                                                      // Function value at 1.0 is 1E-7 (very close to zero)
                                                                                                                                                                                                                                                      double result = solver.solve(f, 1.0, 5.0);
                                                                                                                                                                                                                                                      assertEquals(1.0, result, 0.0001);
                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                  public void testSolve_MaxCloseToZero() throws Exception {
                                                                                                                                                                                                                                                      // Test case where max is very close to zero (within functionValueAccuracy)
                                                                                                                                                                                                                                                      UnivariateRealFunction f = new UnivariateRealFunction() {
                                                                                                                                                                                                                                                          public double value(double x) {
                                                                                                                                                                                                                                                              // Function value at 5.0 is -1E-7 (very close to zero)
                                                                                                                                                                                                                                                              return x == 5.0 ? -1E-7 : x - 3.0; // simple linear function with root at 3.0
                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      double result = solver.solve(f, 1.0, 5.0);
                                                                                                                                                                                                                                                      assertEquals(5.0, result, 0.0001);
                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                  public void testSolve_ZeroLengthInterval() throws Exception {
                                                                                                                                                                                                                                                      // Test case where min equals max
                                                                                                                                                                                                                                                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                      when(mockFunction.value(2.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                      double result = solver.solve(mockFunction, 2.0, 2.0);
                                                                                                                                                                                                                                                      assertEquals(2.0, result, 0.0001);
                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                  public void testSolve_NonBracketingInterval() throws Exception {
                                                                                                                                                                                                                                                      // Setup mock function where interval doesn't bracket a root
                                                                                                                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                      when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                      when(f.value(3.0)).thenReturn(2.0);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                          solver.solve(1.0, 3.0);
                                                                                                                                                                                                                                                          fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                                                      } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                          // Verify the exception message contains the expected content
                                                                                                                                                                                                                                                          assertTrue(e.getMessage().contains("function values at endpoints do not have different signs"));
                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                  }

    @Test(expected = MaxIterationsExceededException.class)
                                                                                                                                                                                                                                                  public void testSolve_MaxIterationsExceeded() throws Exception {
                                                                                                                                                                                                                                                      // Setup mock function that converges very slowly
                                                                                                                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                      when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                      when(f.value(3.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                      // Return values that will cause slow convergence
                                                                                                                                                                                                                                                      when(f.value(anyDouble())).thenReturn(0.9);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                      solver.solve(1.0, 3.0);
                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                  public void testSolve_WithNonBracketingRange_ThrowsException() throws Exception {
                                                                                                                                                                                                                                                      // Setup mock function that doesn't cross zero in the range
                                                                                                                                                                                                                                                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                      when(mockFunction.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                      when(mockFunction.value(2.0)).thenReturn(2.0);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Initialize solver
                                                                                                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Get private message via reflection
                                                                                                                                                                                                                                                      Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                                                                                                                                                                                                                                      field.setAccessible(true);
                                                                                                                                                                                                                                                      String nonBracketingMessage = (String) field.get(null);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                          solver.solve(mockFunction, 1.0, 2.0);
                                                                                                                                                                                                                                                          fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                                                      } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                          assertEquals(nonBracketingMessage, e.getMessage());
                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                  public void testSolve_NonBracketingIntervalThrowsException() throws Exception {
                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                      when(mockFunction.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                      when(mockFunction.value(1.5)).thenReturn(1.5);
                                                                                                                                                                                                                                                      when(mockFunction.value(2.0)).thenReturn(2.0);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Expected exception
                                                                                                                                                                                                                                                      ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                      exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Test
                                                                                                                                                                                                                                                      solver.solve(mockFunction, 1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                  public void testSolve_InitialGuessOutsideIntervalThrowsException() throws Exception {
                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                      BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                                                      UnivariateRealFunction mockFunction = new UnivariateRealFunction() {
                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                          public double value(double x) {
                                                                                                                                                                                                                                                              return 0; // dummy implementation
                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Verify exception
                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                          solver.solve(mockFunction, 1.0, 2.0, 3.0);  // initial guess 3.0 is outside [1.0, 2.0]
                                                                                                                                                                                                                                                          fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                                                      } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                          // expected
                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                              public void testSolve_MaxIsRoot1() throws Exception {
                                                                                                                                                                                                                  // Test case where max is exactly the root
                                                                                                                                                                                                                  UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                  when(mockFunction.value(1.0)).thenReturn(-2.0);
                                                                                                                                                                                                                  when(mockFunction.value(3.0)).thenReturn(0.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                  double result = solver.solve(mockFunction, 1.0, 3.0);
                                                                                                                                                                                                                  assertEquals(3.0, result, 0.0001);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testSolve_NonBracketingInterval1() throws Exception {
                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                  UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Test case where interval doesn't bracket a root (both values same sign)
                                                                                                                                                                                                                  when(mockFunction.value(1.0)).thenReturn(2.0);
                                                                                                                                                                                                                  when(mockFunction.value(3.0)).thenReturn(4.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify exception
                                                                                                                                                                                                                  solver.solve(mockFunction, 1.0, 3.0);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testSolve_InvalidInterval() throws Exception {
                                                                                                                                                                                                                  // Test case where min > max
                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver();
                                                                                                                                                                                                                  UnivariateRealFunction mockFunction = new UnivariateRealFunction() {
                                                                                                                                                                                                                      public double value(double x) {
                                                                                                                                                                                                                          return x;
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                  };
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      solver.solve(mockFunction, 5.0, 1.0);
                                                                                                                                                                                                                      fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                      // Expected exception
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                          public void testSolveClearsResultBetweenCalls() throws Exception {
                                                                                                                                                                              // Setup mock function that returns different values each time
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(anyDouble()))
                                                                                                                                                                                  .thenReturn(1.0)  // First call for initial
                                                                                                                                                                                  .thenReturn(-1.0) // First call for min
                                                                                                                                                                                  .thenReturn(1.0)  // First call for max
                                                                                                                                                                                  .thenReturn(0.0)  // Second call for initial (exact solution)
                                                                                                                                                                                  .thenReturn(1.0)  // Second call for min
                                                                                                                                                                                  .thenReturn(1.0); // Second call for max
                                                                                                                                                                      
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              
                                                                                                                                                                              // First call - should bracket root between min and initial
                                                                                                                                                                              double firstResult = solver.solve(f, 0, 2, 1);
                                                                                                                                                                              
                                                                                                                                                                              // Second call - initial is exact solution (0.0)
                                                                                                                                                                              // If clearResult() was commented out, might return firstResult
                                                                                                                                                                              double secondResult = solver.solve(f, 0, 2, 1.5);
                                                                                                                                                                              
                                                                                                                                                                              // Verify second result is correct (should be 1.5)
                                                                                                                                                                              assertEquals("Solver should return exact solution when found", 
                                                                                                                                                                                          1.5, secondResult, 1e-6);
                                                                                                                                                                              
                                                                                                                                                                              // Verify function was called fresh for second solve
                                                                                                                                                                              verify(f, times(6)).value(anyDouble()); // 3 calls per solve
                                                                                                                                                                          }

    @Test
                                                                                                                                                                          public void testClearResultIsCalledBeforeEachSolve() throws Exception {
                                                                                                                                                                              // Setup mock function
                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                              when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                              when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                              when(f.value(3.0)).thenReturn(-1.0);
                                                                                                                                                                              when(f.value(4.0)).thenReturn(1.0);
                                                                                                                                                                              
                                                                                                                                                                              // Create solver with mock function
                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                              
                                                                                                                                                                              // First call - should return a root between 1 and 2
                                                                                                                                                                              double firstResult = solver.solve(1.0, 2.0);
                                                                                                                                                                              assertFalse(Double.isNaN(firstResult));
                                                                                                                                                                              
                                                                                                                                                                              // Second call - should return a root between 3 and 4
                                                                                                                                                                              // If clearResult() was commented out, this might be affected by previous call
                                                                                                                                                                              double secondResult = solver.solve(3.0, 4.0);
                                                                                                                                                                              assertFalse(Double.isNaN(secondResult));
                                                                                                                                                                              
                                                                                                                                                                              // Verify the results are different (as they should be for different intervals)
                                                                                                                                                                              assertNotEquals(firstResult, secondResult, 0.0001);
                                                                                                                                                                              
                                                                                                                                                                              // Verify the function was called with expected values
                                                                                                                                                                              verify(f).value(1.0);
                                                                                                                                                                              verify(f).value(2.0);
                                                                                                                                                                              verify(f).value(3.0);
                                                                                                                                                                              verify(f).value(4.0);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                 public void testSolveClearsPreviousResult() throws Exception {
                                                                                                                                                                     // Setup mock function that returns different values for different inputs
                                                                                                                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                     when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                     when(f.value(2.0)).thenReturn(1.0);  // root at x=1.5
                                                                                                                                                                     when(f.value(3.0)).thenReturn(-2.0);
                                                                                                                                                                     when(f.value(4.0)).thenReturn(2.0);  // root at x=3.5
                                                                                                                                                                     
                                                                                                                                                                     // Create solver with relaxed accuracy for testing
                                                                                                                                                                     BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                     
                                                                                                                                                                     // First solve operation
                                                                                                                                                                     double firstResult = solver.solve(1.0, 2.0);
                                                                                                                                                                     assertEquals(1.5, firstResult, 0.0001);
                                                                                                                                                                     
                                                                                                                                                                     // Second solve operation - should not be affected by first operation
                                                                                                                                                                     double secondResult = solver.solve(3.0, 4.0);
                                                                                                                                                                     assertEquals(3.5, secondResult, 0.0001);
                                                                                                                                                                     
                                                                                                                                                                     // If clearResult() was commented out, the second result might be affected by first operation's state
                                                                                                                                                                 }

    @Test
                                                                                                                                                             public void testSolveClearsPreviousResult1() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                 // Create mock function that returns different values on consecutive calls
                                                                                                                                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                 when(f.value(1.0)).thenReturn(-1.0, 1.0); // First call returns -1, second returns 1
                                                                                                                                                                 when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                 when(f.value(1.5)).thenReturn(0.0); // Root at 1.5
                                                                                                                                                                 
                                                                                                                                                                 BrentSolver solver = new BrentSolver();
                                                                                                                                                                 
                                                                                                                                                                 // First solve - should set some internal state
                                                                                                                                                                 double result1 = solver.solve(f, 1.0, 2.0);
                                                                                                                                                                 assertEquals(1.5, result1, 1e-6);
                                                                                                                                                                 
                                                                                                                                                                 // Second solve with different function behavior
                                                                                                                                                                 // If clearResult() was called, it should recompute properly
                                                                                                                                                                 // If clearResult() was not called (mutant), it might use stale values
                                                                                                                                                                 double result2 = solver.solve(f, 1.0, 2.0);
                                                                                                                                                                 assertEquals(1.5, result2, 1e-6);
                                                                                                                                                                 
                                                                                                                                                                 // Verify the function was called fresh for both solves
                                                                                                                                                                 verify(f, times(2)).value(1.0);
                                                                                                                                                                 verify(f, times(2)).value(2.0);
                                                                                                                                                                 verify(f, times(2)).value(1.5);
                                                                                                                                                             }

    @Test
                                                                                                                                                             public void testSolveClearsPreviousResults() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                 // Create mock function that returns x (root at 0)
                                                                                                                                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                 when(f.value(anyDouble())).thenAnswer(inv -> (Double)inv.getArguments()[0]);
                                                                                                                                                                 
                                                                                                                                                                 // Create solver instance
                                                                                                                                                                 BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                 
                                                                                                                                                                 // First solve call - find root between -1 and 1
                                                                                                                                                                 double firstResult = solver.solve(f, -1, 1, 0.5);
                                                                                                                                                                 assertEquals(0.0, firstResult, 1e-6);
                                                                                                                                                                 
                                                                                                                                                                 // Second solve call with same parameters should give same result
                                                                                                                                                                 // If clearResult() was skipped, internal state might affect this
                                                                                                                                                                 double secondResult = solver.solve(f, -1, 1, 0.5);
                                                                                                                                                                 assertEquals(0.0, secondResult, 1e-6);
                                                                                                                                                                 
                                                                                                                                                                 // Third solve call with different initial guess
                                                                                                                                                                 // Should still find the same root if state was cleared properly
                                                                                                                                                                 double thirdResult = solver.solve(f, -1, 1, -0.5);
                                                                                                                                                                 assertEquals(0.0, thirdResult, 1e-6);
                                                                                                                                                                 
                                                                                                                                                                 // If clearResult() was commented out, these assertions might fail
                                                                                                                                                                 // due to accumulated internal state
                                                                                                                                                             }

    @Test
                                                                                                                                                             public void testSolveWithExactAccuracy() throws Exception {
                                                                                                                                                                 // Setup
                                                                                                                                                                 double functionValueAccuracy = 1E-6; // Default accuracy from constructor
                                                                                                                                                                 double yInitial = functionValueAccuracy; // Exact boundary case
                                                                                                                                                                 double xInitial = 0.5; // Arbitrary x value
                                                                                                                                                                 
                                                                                                                                                                 // Mock the function to return our test value
                                                                                                                                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                 when(f.value(xInitial)).thenReturn(yInitial);
                                                                                                                                                                 
                                                                                                                                                                 // Create solver with default accuracy
                                                                                                                                                                 BrentSolver solver = new BrentSolver();
                                                                                                                                                                 
                                                                                                                                                                 // Call the method - should return xInitial when yInitial meets accuracy
                                                                                                                                                                 double result = solver.solve(f, 0.0, 1.0, xInitial);
                                                                                                                                                                 
                                                                                                                                                                 // Verify - original would return xInitial, mutant would continue searching
                                                                                                                                                                 assertEquals("Should accept solution when y equals accuracy exactly", 
                                                                                                                                                                             xInitial, result, 0.0);
                                                                                                                                                                 
                                                                                                                                                                 // Verify function was called with expected argument
                                                                                                                                                                 verify(f).value(xInitial);
                                                                                                                                                             }

    @Test
                                                                                                                                                             public void testSolve_DetectsFunctionValueExactlyAtAccuracy() throws Exception {
                                                                                                                                                                 // Setup
                                                                                                                                                                 double min = 1.0;
                                                                                                                                                                 double max = 2.0;
                                                                                                                                                                 double functionValueAccuracy = 1E-6;
                                                                                                                                                                 double yMin = functionValueAccuracy; // Exactly equal to accuracy
                                                                                                                                                                 
                                                                                                                                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                 when(f.value(min)).thenReturn(yMin);
                                                                                                                                                                 when(f.value(max)).thenReturn(1.0); // Doesn't matter as long as sign is same
                                                                                                                                                                 
                                                                                                                                                                 BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                 // Set functionValueAccuracy through reflection since it's inherited from parent
                                                                                                                                                                 java.lang.reflect.Field field = solver.getClass().getSuperclass()
                                                                                                                                                                     .getDeclaredField("functionValueAccuracy");
                                                                                                                                                                 field.setAccessible(true);
                                                                                                                                                                 field.setDouble(solver, functionValueAccuracy);
                                                                                                                                                                 
                                                                                                                                                                 // Test
                                                                                                                                                                 double result = solver.solve(min, max);
                                                                                                                                                                 
                                                                                                                                                                 // Verify
                                                                                                                                                                 assertEquals(min, result, 0.0);
                                                                                                                                                                 verify(f).value(min);
                                                                                                                                                             }

    @Test
                                                                                                                                                         public void testSolveWithExactFunctionValueAccuracy() throws Exception {
                                                                                                                                                             // Setup
                                                                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                             when(f.value(anyDouble())).thenReturn(1E-6); // Exactly matches default functionValueAccuracy
                                                                                                                                                             
                                                                                                                                                             BrentSolver solver = new BrentSolver(f);
                                                                                                                                                             
                                                                                                                                                             // Test data where y1 exactly equals functionValueAccuracy
                                                                                                                                                             double x0 = 0.0;
                                                                                                                                                             double y0 = 1.0;
                                                                                                                                                             double x1 = 1.0;
                                                                                                                                                             double y1 = 1E-6; // Exactly equals default functionValueAccuracy
                                                                                                                                                             double x2 = 2.0;
                                                                                                                                                             double y2 = 1.0;
                                                                                                                                                             
                                                                                                                                                             // Call the private method using reflection
                                                                                                                                                             Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                 "solve", 
                                                                                                                                                                 UnivariateRealFunction.class, 
                                                                                                                                                                 double.class, double.class, 
                                                                                                                                                                 double.class, double.class, 
                                                                                                                                                                 double.class, double.class);
                                                                                                                                                             solveMethod.setAccessible(true);
                                                                                                                                                             
                                                                                                                                                             // Verify it returns immediately (not throwing MaxIterationsExceededException)
                                                                                                                                                             double result = (double) solveMethod.invoke(
                                                                                                                                                                 solver, f, x0, y0, x1, y1, x2, y2);
                                                                                                                                                             
                                                                                                                                                             // Assert the result is x1 since y1 meets the exact accuracy threshold
                                                                                                                                                             assertEquals(x1, result, 0.0);
                                                                                                                                                             
                                                                                                                                                             // Additional verification that it didn't do unnecessary iterations
                                                                                                                                                             // (would throw MaxIterationsExceededException if mutant was present)
                                                                                                                                                         }

    @Test
                                                                                                                                                        public void testSolveWithExactFunctionValueAccuracy1() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                            // Setup
                                                                                                                                                            double functionValueAccuracy = 1E-6; // Default accuracy from constructor
                                                                                                                                                            double testValue = 0.5; // Arbitrary value within bounds
                                                                                                                                                            double exactAccuracyValue = functionValueAccuracy; // Value that exactly matches accuracy
                                                                                                                                                            
                                                                                                                                                            // Create mock function that returns exactly the accuracy threshold
                                                                                                                                                            UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                            when(mockFunction.value(testValue)).thenReturn(exactAccuracyValue);
                                                                                                                                                            
                                                                                                                                                            // Create solver with default accuracy (1E-6)
                                                                                                                                                            BrentSolver solver = new BrentSolver();
                                                                                                                                                            
                                                                                                                                                            // Test - should accept solution when |yInitial| exactly equals accuracy
                                                                                                                                                            double result = solver.solve(mockFunction, testValue - 1, testValue + 1, testValue);
                                                                                                                                                            
                                                                                                                                                            // Verify - should return the test value since it satisfies original condition
                                                                                                                                                            assertEquals(testValue, result, 0.0);
                                                                                                                                                            
                                                                                                                                                            // Additional verification that function was called with test value
                                                                                                                                                            verify(mockFunction).value(testValue);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testSolve_ExactFunctionValueAccuracyAtInitial() throws FunctionEvaluationException {
                                                                                                                                                            // Setup
                                                                                                                                                            double min = 0.0;
                                                                                                                                                            double max = 2.0;
                                                                                                                                                            double initial = 1.0;
                                                                                                                                                            double functionValueAccuracy = 1E-6;
                                                                                                                                                            
                                                                                                                                                            // Create a mock function that returns exactly functionValueAccuracy at initial point
                                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                            when(f.value(initial)).thenReturn(functionValueAccuracy);
                                                                                                                                                            when(f.value(min)).thenReturn(1.0);  // arbitrary value
                                                                                                                                                            when(f.value(max)).thenReturn(1.0);   // arbitrary value
                                                                                                                                                            
                                                                                                                                                            // Create solver with known functionValueAccuracy
                                                                                                                                                            BrentSolver solver = new BrentSolver();
                                                                                                                                                            // Need to set functionValueAccuracy to our known value - this might require reflection
                                                                                                                                                            // since it's likely inherited from a parent class
                                                                                                                                                            
                                                                                                                                                            try {
                                                                                                                                                                java.lang.reflect.Field field = solver.getClass().getSuperclass()
                                                                                                                                                                    .getDeclaredField("functionValueAccuracy");
                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                field.set(solver, functionValueAccuracy);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to set functionValueAccuracy via reflection");
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            double result = 0;
                                                                                                                                                            try {
                                                                                                                                                                result = solver.solve(f, min, max, initial);
                                                                                                                                                            } catch (MaxIterationsExceededException e) {
                                                                                                                                                                fail("Unexpected MaxIterationsExceededException");
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            // Original code should return initial point since yInitial equals functionValueAccuracy
                                                                                                                                                            // Mutated code would continue processing and return something else
                                                                                                                                                            assertEquals("Should return initial point when yInitial exactly equals functionValueAccuracy", 
                                                                                                                                                                        initial, result, 0.0);
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testImmediateConvergenceReportsZeroIterations() throws Exception {
                                                                                                                                                        // Setup mock function that returns small y1 value (immediate convergence)
                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                        when(f.value(anyDouble())).thenReturn(1.0, 1e-10); // y0=1.0, y1=very small
                                                                                                                                                        
                                                                                                                                                        // Create solver with tight accuracy settings
                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                        solver.setFunctionValueAccuracy(1e-8);
                                                                                                                                                        solver.setAbsoluteAccuracy(1e-10);
                                                                                                                                                        solver.setRelativeAccuracy(1e-10);
                                                                                                                                                        
                                                                                                                                                        // Call private solve method via reflection
                                                                                                                                                        Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                            "solve", 
                                                                                                                                                            UnivariateRealFunction.class, 
                                                                                                                                                            double.class, double.class, 
                                                                                                                                                            double.class, double.class, 
                                                                                                                                                            double.class, double.class);
                                                                                                                                                        solveMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Input values where y1 is already below accuracy threshold
                                                                                                                                                        double result = (double) solveMethod.invoke(
                                                                                                                                                            solver, 
                                                                                                                                                            f, 
                                                                                                                                                            0.0, 1.0,  // x0,y0
                                                                                                                                                            1.0, 1e-10, // x1,y1 (y1 is very small)
                                                                                                                                                            2.0, 2.0);  // x2,y2
                                                                                                                                                        
                                                                                                                                                        // Verify result is x1 (since we converged immediately)
                                                                                                                                                        assertEquals(1.0, result, 1e-12);
                                                                                                                                                        
                                                                                                                                                        // Verify iteration count is 0 (this will fail for the mutant)
                                                                                                                                                        // Note: This assumes the solver stores iterations in a field we can access
                                                                                                                                                        Field iterationsField = BrentSolver.class.getDeclaredField("iterationCount");
                                                                                                                                                        iterationsField.setAccessible(true);
                                                                                                                                                        int iterations = (int) iterationsField.get(solver);
                                                                                                                                                        assertEquals(0, iterations);
                                                                                                                                                    }

    @Test
                                                                                                                                               public void testSolveIterationCount() throws Exception {
                                                                                                                                                   // Create mock function that returns 0 at x=1.5 (root in middle of interval)
                                                                                                                                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                   when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                   when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                   when(f.value(1.5)).thenReturn(0.0);
                                                                                                                                                   
                                                                                                                                                   // Create spy of BrentSolver to verify setResult calls
                                                                                                                                                   BrentSolver solver = spy(new BrentSolver(f));
                                                                                                                                                   
                                                                                                                                                   // Call the method
                                                                                                                                                   double result = solver.solve(f, 1.0, 2.0);
                                                                                                                                                   
                                                                                                                                                   // Verify the actual result is correct
                                                                                                                                                   assertEquals(1.5, result, 0.0001);
                                                                                                                                               }

    @Test
                                                                                                                                           public void testSolve_WhenEndpointIsCloseToZero_ShouldSetResultWithZeroFunctionValue() throws Exception {
                                                                                                                                               // Setup
                                                                                                                                               double min = 1.0;
                                                                                                                                               double max = 2.0;
                                                                                                                                               double closeToZeroValue = 1e-7; // within default functionValueAccuracy (1E-6)
                                                                                                                                               
                                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                               when(f.value(min)).thenReturn(closeToZeroValue);
                                                                                                                                               when(f.value(max)).thenReturn(1.0); // arbitrary non-zero value
                                                                                                                                               
                                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                                               
                                                                                                                                               // Test
                                                                                                                                               double result = solver.solve(min, max);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertEquals(min, result, 0.0);
                                                                                                                                               // Verify the function value at the result is close to zero
                                                                                                                                               assertEquals(closeToZeroValue, f.value(result), 1e-6);
                                                                                                                                           }

    @Test
                                                                                                                                       public void testSolveShouldSetCorrectIterationCount() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                           // Setup
                                                                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                           when(f.value(anyDouble())).thenReturn(0.0); // Mock function that returns 0 for any input
                                                                                                                                           
                                                                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                                                                           double min = 0;
                                                                                                                                           double max = 10;
                                                                                                                                           double initial = 5;
                                                                                                                                           
                                                                                                                                           // Execute
                                                                                                                                           double result = solver.solve(f, min, max, initial);
                                                                                                                                           
                                                                                                                                           // Verify - since we don't have direct access to iteration count,
                                                                                                                                           // we'll verify the mock was called appropriate number of times
                                                                                                                                           // The exact number depends on Brent's method implementation,
                                                                                                                                           // but we know it should be more than 1 evaluation
                                                                                                                                           
                                                                                                                                           verify(f, atLeastOnce()).value(anyDouble());
                                                                                                                                           
                                                                                                                                           // Additional verification could be added if we had access to iteration count
                                                                                                                                           // For example, if there was a getIterationCount() method:
                                                                                                                                           // assertTrue(solver.getIterationCount() > 0);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testSolve_InitialGuessIsSolution_ShouldReturnZeroIterations() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                           // Create mock function that returns 0 for initial point (exact solution)
                                                                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                           when(f.value(1.5)).thenReturn(0.0); // initial is solution
                                                                                                                                           when(f.value(1.0)).thenReturn(-1.0); // min
                                                                                                                                           when(f.value(2.0)).thenReturn(1.0);  // max
                                                                                                                                           
                                                                                                                                           // Create solver with tight accuracy to catch exact solution
                                                                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                                                                           solver.setFunctionValueAccuracy(1e-12);
                                                                                                                                           
                                                                                                                                           // Call solve with initial guess that's already solution
                                                                                                                                           double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                           
                                                                                                                                           // Verify the result is correct and found immediately
                                                                                                                                           assertEquals(1.5, result, 1e-12);
                                                                                                                                           
                                                                                                                                           // Since we can't directly verify iteration count, we rely on the tight accuracy
                                                                                                                                           // to confirm it didn't perform any iterations (wouldn't be exact otherwise)
                                                                                                                                       }

    @Test
                                                                                                                                       public void testSolve_DetectsMutantWhenProductEqualsZero() throws Exception {
                                                                                                                                           // Setup
                                                                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                                                                           
                                                                                                                                           // Case where yInitial is exactly 0 (should return initial value in original)
                                                                                                                                           when(f.value(1.0)).thenReturn(0.0);  // yInitial = 0
                                                                                                                                           when(f.value(0.0)).thenReturn(-2.0); // yMin
                                                                                                                                           when(f.value(2.0)).thenReturn(3.0);  // yMax
                                                                                                                                           
                                                                                                                                           // The original would return initial (1.0) since yInitial is 0 (<= functionValueAccuracy)
                                                                                                                                           // The mutant would try to solve bracketed interval since yInitial*yMin <= 0
                                                                                                                                           double result = solver.solve(f, 0.0, 2.0, 1.0);
                                                                                                                                           
                                                                                                                                           // Verify original behavior - should return initial guess (1.0)
                                                                                                                                           // If mutant exists, it would return different value from solve() call
                                                                                                                                           assertEquals(1.0, result, 0.0001);
                                                                                                                                           
                                                                                                                                           // Alternative case where yMin is exactly 0
                                                                                                                                           when(f.value(1.0)).thenReturn(2.0);  // yInitial
                                                                                                                                           when(f.value(0.0)).thenReturn(0.0);  // yMin = 0
                                                                                                                                           when(f.value(2.0)).thenReturn(3.0);  // yMax
                                                                                                                                           
                                                                                                                                           // Original would check next condition (yInitial*yMax)
                                                                                                                                           // Mutant would take the first branch (yInitial*yMin <= 0)
                                                                                                                                           result = solver.solve(f, 0.0, 2.0, 1.0);
                                                                                                                                           
                                                                                                                                           // Original should proceed to check yInitial*yMax and throw exception since no bracket
                                                                                                                                           // So we expect an exception, but to make it simple we can verify the path
                                                                                                                                           // by checking if it tried to evaluate yMax (which mutant wouldn't do)
                                                                                                                                           verify(f).value(2.0);
                                                                                                                                       }

    @Test
                                                                                                                                  public void testBracketingWithZeroFunctionValue() throws Exception {
                                                                                                                                      // Create mock function that returns zero at x=1.0
                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                      when(f.value(0.0)).thenReturn(-1.0);
                                                                                                                                      when(f.value(1.0)).thenReturn(0.0);  // exact zero
                                                                                                                                      when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                      
                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                      
                                                                                                                                      // Test with bracketing where one point has exact zero value
                                                                                                                                      try {
                                                                                                                                          double result = solver.solve(f, 0.0, 2.0, 1.0);
                                                                                                                                          // If we get here, the mutant survived (<= condition passed)
                                                                                                                                          // Original version should throw exception for non-bracketing
                                                                                                                                          fail("Expected IllegalArgumentException for non-bracketing interval");
                                                                                                                                      } catch (IllegalArgumentException e) {
                                                                                                                                          // Original behavior - expected
                                                                                                                                          assertEquals("Function values at endpoints do not have different signs.", e.getMessage());
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      // Additional test case where product is exactly zero
                                                                                                                                      try {
                                                                                                                                          double result = solver.solve(f, 1.0, 2.0);
                                                                                                                                          // Original version should throw exception since f(1.0)*f(2.0) = 0*1 = 0
                                                                                                                                          fail("Expected IllegalArgumentException for non-bracketing interval");
                                                                                                                                      } catch (IllegalArgumentException e) {
                                                                                                                                          // Original behavior - expected
                                                                                                                                          assertEquals("Function values at endpoints do not have different signs.", e.getMessage());
                                                                                                                                      }
                                                                                                                                  }

    @Test
                                                                                                                              public void testBracketConditionWithZeroValues() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                  // Create mock function that returns 0 at initial point
                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                  when(f.value(1.0)).thenReturn(0.0);  // yInitial = 0
                                                                                                                                  when(f.value(0.0)).thenReturn(1.0);  // yMin = 1
                                                                                                                                  
                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                  
                                                                                                                                  try {
                                                                                                                                      // This should throw IllegalArgumentException in original code
                                                                                                                                      // because yInitial is 0 but condition is yInitial*yMin < 0
                                                                                                                                      // Mutated version would accept it (yInitial*yMin <= 0)
                                                                                                                                      solver.solve(0.0, 2.0, 1.0);
                                                                                                                                      fail("Expected IllegalArgumentException for zero function value");
                                                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                                                      // Expected behavior for original code
                                                                                                                                      assertTrue(e.getMessage().contains("function values at endpoints do not have different signs"));
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Test case where yMin is 0
                                                                                                                                  when(f.value(1.0)).thenReturn(1.0);  // yInitial = 1
                                                                                                                                  when(f.value(0.0)).thenReturn(0.0);  // yMin = 0
                                                                                                                                  
                                                                                                                                  try {
                                                                                                                                      solver.solve(0.0, 2.0, 1.0);
                                                                                                                                      fail("Expected IllegalArgumentException for zero function value");
                                                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                                                      // Expected behavior for original code
                                                                                                                                      assertTrue(e.getMessage().contains("function values at endpoints do not have different signs"));
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Test case where both are 0
                                                                                                                                  when(f.value(1.0)).thenReturn(0.0);  // yInitial = 0
                                                                                                                                  when(f.value(0.0)).thenReturn(0.0);  // yMin = 0
                                                                                                                                  
                                                                                                                                  try {
                                                                                                                                      solver.solve(0.0, 2.0, 1.0);
                                                                                                                                      fail("Expected IllegalArgumentException for zero function values");
                                                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                                                      // Expected behavior for original code
                                                                                                                                      assertTrue(e.getMessage().contains("function values at endpoints do not have different signs"));
                                                                                                                                  }
                                                                                                                              }

    @Test
                                                                                                                              public void testBracketingConditionWithZeroValues() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                  // Create a mock function that returns specific values
                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                  
                                                                                                                                  // Case 1: yInitial is exactly 0 (should not be considered valid bracketing)
                                                                                                                                  when(f.value(anyDouble())).thenReturn(1.0, 0.0, 2.0);
                                                                                                                                  try {
                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                      solver.solve(0, 1, 0.5); // initial point where f(initial) = 0
                                                                                                                                      fail("Should throw IllegalArgumentException when yInitial is 0");
                                                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                                                      assertTrue(e.getMessage().contains("function values at endpoints must have different signs"));
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Case 2: yMin is exactly 0 (should not be considered valid bracketing)
                                                                                                                                  when(f.value(anyDouble())).thenReturn(0.0, 1.0, 2.0);
                                                                                                                                  try {
                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                      solver.solve(0, 1, 0.5); // min point where f(min) = 0
                                                                                                                                      fail("Should throw IllegalArgumentException when yMin is 0");
                                                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                                                      assertTrue(e.getMessage().contains("function values at endpoints must have different signs"));
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Case 3: Valid bracketing (opposite signs, neither zero)
                                                                                                                                  when(f.value(anyDouble())).thenReturn(-1.0, 1.0, 0.5);
                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                  double result = solver.solve(0, 1, 0.5);
                                                                                                                                  // Just verify it doesn't throw exception for valid case
                                                                                                                                  assertNotNull(result);
                                                                                                                              }

    @Test
                                                                                                                              public void testSolveDetectsYInitialTimesYMinConditionMutant() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                  // Create mock function
                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                  
                                                                                                                                  // Case 1: yInitial * yMin == 0 (yMin == 0)
                                                                                                                                  when(f.value(1.0)).thenReturn(0.0);  // yMin = 0
                                                                                                                                  when(f.value(2.0)).thenReturn(1.0);  // yMax = 1
                                                                                                                                  
                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                  double result = solver.solve(1.0, 2.0, 1.5);  // initial = 1.5
                                                                                                                                  
                                                                                                                                  // Should return min value since yMin == 0
                                                                                                                                  assertEquals(1.0, result, 0.0001);
                                                                                                                                  
                                                                                                                                  // Case 2: yInitial * yMin == 0 (yInitial == 0)
                                                                                                                                  when(f.value(1.0)).thenReturn(-1.0);  // yMin = -1
                                                                                                                                  when(f.value(1.5)).thenReturn(0.0);   // yInitial = 0
                                                                                                                                  when(f.value(2.0)).thenReturn(1.0);   // yMax = 1
                                                                                                                                  
                                                                                                                                  result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                  
                                                                                                                                  // The mutant would potentially take a different path here
                                                                                                                                  // Original would only enter if yInitial * yMin < 0 (false in this case)
                                                                                                                                  // Mutant would enter if yInitial * yMin <= 0 (true in this case)
                                                                                                                                  // We verify the correct behavior by checking it doesn't throw exception
                                                                                                                                  assertFalse(Double.isNaN(result));
                                                                                                                                  
                                                                                                                                  // Case 3: yInitial * yMin < 0
                                                                                                                                  when(f.value(1.0)).thenReturn(-1.0);  // yMin = -1
                                                                                                                                  when(f.value(1.5)).thenReturn(0.5);   // yInitial = 0.5
                                                                                                                                  when(f.value(2.0)).thenReturn(1.0);   // yMax = 1
                                                                                                                                  
                                                                                                                                  result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                  
                                                                                                                                  // Both original and mutant should behave the same here
                                                                                                                                  assertFalse(Double.isNaN(result));
                                                                                                                              }

    @Test
                                                                                                                              public void testSolveDetectsYMaxMutation() throws Exception {
                                                                                                                                  // Setup mock function where f(max) is different from max
                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                  double min = 0;
                                                                                                                                  double max = 10;
                                                                                                                                  double yMax = 5; // f(max) is different from max
                                                                                                                                  
                                                                                                                                  // Stub the function behavior
                                                                                                                                  when(f.value(min)).thenReturn(-1.0);
                                                                                                                                  when(f.value(max)).thenReturn(yMax);
                                                                                                                                  
                                                                                                                                  // Create solver and call solve
                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                  double result = solver.solve(min, max);
                                                                                                                                  
                                                                                                                                  // Verify the result was computed using yMax (f(max)) not max
                                                                                                                                  // We can't directly access the private setResult, so we verify through the solve result
                                                                                                                                  // The key is that the result should reflect using f(max) in its computation
                                                                                                                                  // For Brent's method, the solution should be between min and max
                                                                                                                                  assertTrue("Result should be within bounds", result >= min && result <= max);
                                                                                                                                  
                                                                                                                                  // Additional verification that the function was evaluated at max
                                                                                                                                  verify(f).value(max);
                                                                                                                                  
                                                                                                                                  // If we had access to the internal state, we would verify setResult was called with yMax
                                                                                                                                  // Since we don't, we rely on the fact that using max instead of yMax would likely
                                                                                                                                  // produce a different result or fail to converge properly
                                                                                                                              }

    @Test
                                                                                                                              public void testSolveTracksFunctionValueAtMaxNotJustMax() throws Exception {
                                                                                                                                  // Create a mock function that returns different values
                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                  when(f.value(1.0)).thenReturn(2.0);  // f(min)
                                                                                                                                  when(f.value(3.0)).thenReturn(4.0);  // f(max)
                                                                                                                                  when(f.value(2.0)).thenReturn(0.0);  // root at initial guess
                                                                                                                                  
                                                                                                                                  // Create solver and call the method
                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                  double result = solver.solve(f, 1.0, 3.0, 2.0);
                                                                                                                                  
                                                                                                                                  // Verify the function was called with max (3.0)
                                                                                                                                  verify(f).value(3.0);
                                                                                                                                  
                                                                                                                                  // The key assertion - if the mutant uses max (3.0) instead of yMax (4.0),
                                                                                                                                  // this would fail because we expect the solver to track the function value
                                                                                                                                  // The exact assertion would depend on how the result is used,
                                                                                                                                  // but we can verify the proper behavior through the final result
                                                                                                                                  assertEquals(2.0, result, 1e-6);
                                                                                                                                  
                                                                                                                                  // Alternatively, if we had access to the solver's internal state,
                                                                                                                                  // we could verify that it stored the function value (4.0) not the x value (3.0)
                                                                                                                                  // This might require reflection or additional getter methods
                                                                                                                              }

    @Test
                                                                                                                          public void testMutant_setResultUsesYMaxInsteadOfMax() throws Exception {
                                                                                                                              // Create a mock function that returns specific values
                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                              when(f.value(anyDouble())).thenReturn(1.0, 0.5, 1E-8); // Last value is within accuracy
                                                                                                                              
                                                                                                                              // Create solver with tight accuracy settings
                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                              // Set accuracy thresholds that will make y1=1E-8 be considered converged
                                                                                                                              solver.setFunctionValueAccuracy(1E-7);
                                                                                                                              solver.setRelativeAccuracy(1E-10);
                                                                                                                              solver.setAbsoluteAccuracy(1E-10);
                                                                                                                              
                                                                                                                              // Initial points where y2 (1E-8) is better than y1 (0.5)
                                                                                                                              double x0 = 0.0, y0 = 1.0;
                                                                                                                              double x1 = 0.5, y1 = 0.5;
                                                                                                                              double x2 = 1.0, y2 = 1E-8;
                                                                                                                              
                                                                                                                              // Invoke private method using reflection
                                                                                                                              Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                  "solve", 
                                                                                                                                  UnivariateRealFunction.class, 
                                                                                                                                  double.class, double.class, 
                                                                                                                                  double.class, double.class, 
                                                                                                                                  double.class, double.class
                                                                                                                              );
                                                                                                                              solveMethod.setAccessible(true);
                                                                                                                              
                                                                                                                              // Test should complete in few iterations (not reach max)
                                                                                                                              double result = (double) solveMethod.invoke(solver, f, x0, y0, x1, y1, x2, y2);
                                                                                                                              
                                                                                                                              // Verify result is close to x2 since y2 was very small
                                                                                                                              assertEquals(1.0, result, 1E-6);
                                                                                                                              
                                                                                                                              // If mutant was present, it would have continued iterating until MaxIterationsExceededException
                                                                                                                              // because it would be comparing x-coordinate (1.0) against accuracy instead of y-value (1E-8)
                                                                                                                          }

    @Test
                                                                                                         public void testSolveWithYMaxCloseToZero() {
                                                                                                             // Setup
                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                             try {
                                                                                                                 when(f.value(1.0)).thenReturn(1.0);  // yMin
                                                                                                                 when(f.value(2.0)).thenReturn(1e-7); // yMax just within functionValueAccuracy (1e-6)
                                                                                                             } catch (FunctionEvaluationException e) {
                                                                                                                 fail("Unexpected FunctionEvaluationException during mock setup");
                                                                                                             }
                                                                                                             
                                                                                                             BrentSolver solver = new BrentSolver(f);
                                                                                                             solver.setFunctionValueAccuracy(1e-6);
                                                                                                             
                                                                                                             // Execute
                                                                                                             double result = Double.NaN;
                                                                                                             try {
                                                                                                                 result = solver.solve(1.0, 2.0);
                                                                                                             } catch (MaxIterationsExceededException e) {
                                                                                                                 fail("Unexpected MaxIterationsExceededException");
                                                                                                             } catch (FunctionEvaluationException e) {
                                                                                                                 fail("Unexpected FunctionEvaluationException");
                                                                                                             }
                                                                                                             
                                                                                                             // Verify
                                                                                                             assertEquals(2.0, result, 0.0);  // Should return max
                                                                                                             
                                                                                                             // Verify internal state through reflection
                                                                                                             try {
                                                                                                                 Field resultField = BrentSolver.class.getDeclaredField("result");
                                                                                                                 resultField.setAccessible(true);
                                                                                                                 double[] resultArray = (double[]) resultField.get(solver);
                                                                                                                 assertEquals(1e-7, resultArray[1], 1e-8); // Verify stored function value is yMax
                                                                                                             } catch (Exception e) {
                                                                                                                 fail("Failed to verify internal state due to reflection issues");
                                                                                                             }
                                                                                                         }

    @Test
                                                                                                         public void testSolve_DetectsMutantWhenMaxIsRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                             // Create a mock function that returns 0 at max (indicating max is a root)
                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                             when(f.value(anyDouble())).thenReturn(1.0); // default return
                                                                                                             when(f.value(5.0)).thenReturn(0.0); // max is root
                                                                                                             
                                                                                                             // Create solver
                                                                                                             BrentSolver solver = new BrentSolver(f);
                                                                                                             
                                                                                                             // Test parameters where max is a root
                                                                                                             double min = 1.0;
                                                                                                             double max = 5.0;
                                                                                                             double initial = 3.0;
                                                                                                             
                                                                                                             // Call the method and get result
                                                                                                             double result = solver.solve(f, min, max, initial);
                                                                                                             
                                                                                                             // Verify that the result is the max value (5.0) since it's a root
                                                                                                             assertEquals(5.0, result, 0.0);
                                                                                                             
                                                                                                             // Additional verification that initial wasn't returned as result
                                                                                                             assertNotEquals(3.0, result, 0.0);
                                                                                                         }

    @Test
                                                                                                         public void testSolveDetectsParameterMutation() throws Exception {
                                                                                                             // Create a mock function that has a root at 2.0
                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                             when(f.value(1.0)).thenReturn(-1.0);  // yMin
                                                                                                             when(f.value(3.0)).thenReturn(1.0);   // yMax
                                                                                                             when(f.value(1.5)).thenReturn(-0.5);  // yInitial (different from yMin)
                                                                                                             when(f.value(2.0)).thenReturn(0.0);   // root
                                                                                                             
                                                                                                             // Create solver instance
                                                                                                             BrentSolver solver = new BrentSolver(f);
                                                                                                             
                                                                                                             // Test parameters where min != initial
                                                                                                             double min = 1.0;
                                                                                                             double max = 3.0;
                                                                                                             double initial = 1.5;
                                                                                                             
                                                                                                             // The mutation would use (min,yMin) instead of (initial,yInitial) as last params
                                                                                                             // This should affect the convergence behavior
                                                                                                             double result = solver.solve(min, max, initial);
                                                                                                             
                                                                                                             // Verify the result is correct (should find root at 2.0)
                                                                                                             assertEquals(2.0, result, 1e-6);
                                                                                                             
                                                                                                             // Additionally, we could verify the function was called with expected parameters
                                                                                                             // This would require access to the private solve method or using reflection,
                                                                                                             // but the assertion on the result should be sufficient to detect the mutation
                                                                                                             // since using wrong parameters would likely lead to wrong result or no convergence
                                                                                                         }

    @Test
                                                                                                     public void testSolveWithInitialGuessDifferentFromMin() throws Exception {
                                                                                                         // Setup - create a function where the solution depends on initial guess
                                                                                                         UnivariateRealFunction f = new UnivariateRealFunction() {
                                                                                                             public double value(double x) {
                                                                                                                 if (x == 1.0) return -1.0;  // min
                                                                                                                 if (x == 3.0) return 1.0;   // max
                                                                                                                 if (x == 2.0) return -0.5; // initial
                                                                                                                 return x - 1.8;            // root at 1.8
                                                                                                             }
                                                                                                         };
                                                                                                         
                                                                                                         BrentSolver solver = new BrentSolver();
                                                                                                         
                                                                                                         // Test - the result should depend on using initial=2.0
                                                                                                         double result = solver.solve(f, 1.0, 3.0, 2.0);
                                                                                                         
                                                                                                         // Verify - the mutant would behave differently because it uses min instead of initial
                                                                                                         assertEquals(1.8, result, 0.0001);
                                                                                                     }

    @Test
                                                                                                     public void testSolveWithDifferentInitialPoints() throws Exception {
                                                                                                         // Create a mock function that returns x^2 - 4 (root at x=2)
                                                                                                         UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                         when(f.value(1.0)).thenReturn(-3.0);  // y at x=1
                                                                                                         when(f.value(3.0)).thenReturn(5.0);   // y at x=3
                                                                                                         when(f.value(2.0)).thenReturn(0.0);   // root at x=2
                                                                                                         when(f.value(1.5)).thenReturn(-1.75); // intermediate points
                                                                                                         when(f.value(2.5)).thenReturn(2.25);
                                                                                                         
                                                                                                         // Create solver with default settings
                                                                                                         BrentSolver solver = new BrentSolver();
                                                                                                         
                                                                                                         // Use reflection to access private solve method
                                                                                                         Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                             "solve", 
                                                                                                             UnivariateRealFunction.class, 
                                                                                                             double.class, double.class, 
                                                                                                             double.class, double.class,
                                                                                                             double.class, double.class);
                                                                                                         solveMethod.setAccessible(true);
                                                                                                         
                                                                                                         // Test with original parameters (initial point used twice)
                                                                                                         double result1 = (double) solveMethod.invoke(
                                                                                                             solver, f, 1.0, -3.0, 3.0, 5.0, 1.0, -3.0);
                                                                                                         
                                                                                                         // Test with mutated parameters (different min point)
                                                                                                         double result2 = (double) solveMethod.invoke(
                                                                                                             solver, f, 1.0, -3.0, 3.0, 5.0, 0.5, -3.75);
                                                                                                         
                                                                                                         // Verify results are different (mutant would produce different result)
                                                                                                         assertNotEquals("Mutant should produce different result", result1, result2, 0.0001);
                                                                                                         
                                                                                                         // Verify original version finds correct root
                                                                                                         assertEquals(2.0, result1, 0.0001);
                                                                                                     }

    @Test
                                                                                                    public void testSolveWithInitialGuessDifferentFromMin1() throws Exception {
                                                                                                        // Setup
                                                                                                        BrentSolver solver = new BrentSolver();
                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                        
                                                                                                        // Mock function values
                                                                                                        when(f.value(1.0)).thenReturn(-1.0);  // min
                                                                                                        when(f.value(3.0)).thenReturn(1.0);   // max
                                                                                                        when(f.value(2.0)).thenReturn(-0.5);  // initial
                                                                                                        
                                                                                                        // Since we can't mock private methods with standard Mockito,
                                                                                                        // we'll test the actual behavior and verify the result
                                                                                                        // The function values are set up to bracket a root (negative at min, positive at max)
                                                                                                        
                                                                                                        // Test
                                                                                                        double result = solver.solve(f, 1.0, 3.0, 2.0);
                                                                                                        
                                                                                                        // Verify
                                                                                                        // The actual result will depend on the solver's implementation
                                                                                                        // We just verify it's within the expected range
                                                                                                        assertTrue(result >= 1.0 && result <= 3.0);
                                                                                                        
                                                                                                        // Verify the function was called with expected values
                                                                                                        verify(f).value(1.0);
                                                                                                        verify(f).value(3.0);
                                                                                                        verify(f).value(2.0);
                                                                                                    }

    @Test
                                                                                                public void testSolveDetectsMutantUsingDifferentInitialAndMinValues() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                    // Create mock function that returns different values at min and initial points
                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                    when(f.value(1.0)).thenReturn(-1.0);  // min
                                                                                                    when(f.value(2.0)).thenReturn(1.0);   // initial
                                                                                                    when(f.value(3.0)).thenReturn(2.0);   // max
                                                                                                    
                                                                                                    // The function has root at 1.5 (between min and initial)
                                                                                                    when(f.value(1.5)).thenReturn(0.0);
                                                                                                    
                                                                                                    // Create solver instance
                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                    
                                                                                                    // Test the public solve method that would call the private mutated method
                                                                                                    double result = solver.solve(f, 1.0, 3.0, 2.0);
                                                                                                    
                                                                                                    // The correct result should be 1.5 (root between min and initial)
                                                                                                    // The mutant would use min's value instead of initial's, potentially finding wrong root
                                                                                                    assertEquals(1.5, result, 0.0001);
                                                                                                    
                                                                                                    // Verify the function was called with expected values
                                                                                                    verify(f).value(1.0);
                                                                                                    verify(f).value(2.0);
                                                                                                    verify(f).value(3.0);
                                                                                                    verify(f).value(1.5);
                                                                                                }

    @Test
                                                                                                public void testSolve_InitialMaxBracket_ShouldPassInitialAsBestGuess() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                    // Mock the function to return specific values
                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                    doReturn(-1.0).when(f).value(1.0);  // yMin
                                                                                                    doReturn(-0.5).when(f).value(2.0);  // yInitial
                                                                                                    doReturn(1.0).when(f).value(3.0);   // yMax
                                                                                                    
                                                                                                    // Create solver
                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                    
                                                                                                    // Call the method and verify result
                                                                                                    double result = solver.solve(f, 1.0, 3.0, 2.0);
                                                                                                    
                                                                                                    // Verify that the initial guess was used in the solution
                                                                                                    // Since yInitial (-0.5) is closer to zero than yMin (-1.0) or yMax (1.0),
                                                                                                    // the solution should be closer to the initial guess
                                                                                                    assertEquals(2.0, result, solver.getFunctionValueAccuracy());
                                                                                                    
                                                                                                    // Verify function was evaluated at expected points
                                                                                                    verify(f).value(1.0);
                                                                                                    verify(f).value(2.0);
                                                                                                    verify(f).value(3.0);
                                                                                                }

    @Test
                                                                                                public void testSolveWithExactRootAtEndpoint() throws Exception {
                                                                                                    // Create a mock function that returns 0 at min and positive at max
                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                    when(f.value(0.0)).thenReturn(0.0);  // exact root at min
                                                                                                    when(f.value(1.0)).thenReturn(1.0);  // positive at max
                                                                                                    
                                                                                                    BrentSolver solver = new BrentSolver();
                                                                                                    
                                                                                                    // Test with root exactly at min
                                                                                                    double result = solver.solve(f, 0.0, 1.0);
                                                                                                    assertEquals(0.0, result, 1e-6);
                                                                                                    
                                                                                                    // Create another mock function that returns 0 at max
                                                                                                    UnivariateRealFunction f2 = mock(UnivariateRealFunction.class);
                                                                                                    when(f2.value(0.0)).thenReturn(-1.0);  // negative at min
                                                                                                    when(f2.value(1.0)).thenReturn(0.0);   // exact root at max
                                                                                                    
                                                                                                    // Test with root exactly at max
                                                                                                    result = solver.solve(f2, 0.0, 1.0);
                                                                                                    assertEquals(1.0, result, 1e-6);
                                                                                                }

    @Test
                                                                                                public void testSolveWithOneEndpointExactlyZero() throws Exception {
                                                                                                    // Setup mock function
                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                    when(f.value(1.0)).thenReturn(1.0);  // yMin = 1.0
                                                                                                    when(f.value(2.0)).thenReturn(0.0);  // yMax = 0.0 (exactly zero)
                                                                                                    when(f.value(1.5)).thenReturn(0.5);   // yInitial = 0.5
                                                                                                    
                                                                                                    // Create solver with tight accuracy to detect zero
                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                    solver.setFunctionValueAccuracy(1e-12);
                                                                                                    
                                                                                                    try {
                                                                                                        // This should NOT throw an exception in original code
                                                                                                        double result = solver.solve(f, 1.0, 2.0, 1.5);
                                                                                                        
                                                                                                        // Verify it returns the zero endpoint (2.0)
                                                                                                        assertEquals(2.0, result, 1e-12);
                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                        // If we get here, the mutant was detected
                                                                                                        fail("Mutant detected: Exception thrown when one endpoint is exactly zero");
                                                                                                    }
                                                                                                }

    @Test
                                                                                           public void testSolveWithExactRootAtBoundary() throws Exception {
                                                                                               // Create a mock function that returns 0 at x=1.0 and positive/negative elsewhere
                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                               when(f.value(0.0)).thenReturn(-1.0);
                                                                                               when(f.value(1.0)).thenReturn(0.0);  // exact root
                                                                                               when(f.value(2.0)).thenReturn(1.0);
                                                                                               
                                                                                               // Create solver with default settings
                                                                                               BrentSolver solver = new BrentSolver();
                                                                                               
                                                                                               // Get the private solve method via reflection
                                                                                               Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                   "solve", 
                                                                                                   UnivariateRealFunction.class, 
                                                                                                   double.class, 
                                                                                                   double.class, 
                                                                                                   double.class, 
                                                                                                   double.class, 
                                                                                                   double.class, 
                                                                                                   double.class
                                                                                               );
                                                                                               solveMethod.setAccessible(true);
                                                                                               
                                                                                               // Test with x1 exactly at root (y1=0)
                                                                                               try {
                                                                                                   double result = (double) solveMethod.invoke(solver, f, 0.0, -1.0, 1.0, 0.0, 2.0, 1.0);
                                                                                                   // Original code should find the root at x=1.0
                                                                                                   assertEquals(1.0, result, 1e-6);
                                                                                               } catch (InvocationTargetException e) {
                                                                                                   if (e.getTargetException() instanceof IllegalArgumentException) {
                                                                                                       // Mutant would throw exception because yMin*yMax >= 0
                                                                                                       fail("Original code should accept exact root as valid bracketing");
                                                                                                   } else {
                                                                                                       throw e;
                                                                                                   }
                                                                                               }
                                                                                               
                                                                                               // Test with x0 exactly at root (y0=0)
                                                                                               try {
                                                                                                   double result = (double) solveMethod.invoke(solver, f, 1.0, 0.0, 0.0, -1.0, 2.0, 1.0);
                                                                                                   assertEquals(1.0, result, 1e-6);
                                                                                               } catch (InvocationTargetException e) {
                                                                                                   if (e.getTargetException() instanceof IllegalArgumentException) {
                                                                                                       fail("Original code should accept exact root as valid bracketing");
                                                                                                   } else {
                                                                                                       throw e;
                                                                                                   }
                                                                                               }
                                                                                           }

    @Test
                                                                                       public void testSolveWithOneEndpointZeroShouldNotThrowException() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                           // Create mock function that returns zero at min and positive at max
                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                           when(f.value(0.0)).thenReturn(0.0);  // yMin = 0
                                                                                           when(f.value(1.0)).thenReturn(1.0);  // yMax = 1
                                                                                           
                                                                                           BrentSolver solver = new BrentSolver();
                                                                                           
                                                                                           try {
                                                                                               // This should work in original (0 * 1 = 0 is not > 0)
                                                                                               // But mutant will reject (0 * 1 >= 0 is true)
                                                                                               double result = solver.solve(f, 0.0, 1.0);
                                                                                               
                                                                                               // If we get here with original, test passes
                                                                                               // Mutant would throw IllegalArgumentException
                                                                                               assertTrue(true);
                                                                                           } catch (IllegalArgumentException e) {
                                                                                               fail("Should accept interval where one endpoint is exactly zero");
                                                                                           }
                                                                                       }

    @Test(expected = IllegalArgumentException.class)
                                                                                       public void testSolveWithSameSignEndpointsShouldThrowException() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                           // Create mock function that returns positive at both ends
                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                           when(f.value(0.0)).thenReturn(1.0);  // yMin = 1
                                                                                           when(f.value(1.0)).thenReturn(2.0);  // yMax = 2
                                                                                           
                                                                                           BrentSolver solver = new BrentSolver();
                                                                                           
                                                                                           // Both original and mutant should reject this
                                                                                           solver.solve(f, 0.0, 1.0);
                                                                                       }

    @Test
                                                                                       public void testSolveWithBracketedRootShouldWork() {
                                                                                           // Create mock function that brackets root
                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                           try {
                                                                                               when(f.value(0.0)).thenReturn(-1.0);  // yMin = -1
                                                                                               when(f.value(1.0)).thenReturn(1.0);   // yMax = 1
                                                                                           } catch (FunctionEvaluationException e) {
                                                                                               fail("Mock setup failed");
                                                                                           }
                                                                                           
                                                                                           BrentSolver solver = new BrentSolver();
                                                                                           
                                                                                           try {
                                                                                               // Both original and mutant should accept this
                                                                                               double result = solver.solve(f, 0.0, 1.0);
                                                                                               assertTrue(true);
                                                                                           } catch (FunctionEvaluationException e) {
                                                                                               fail("Function evaluation failed");
                                                                                           } catch (IllegalArgumentException e) {
                                                                                               fail("Should accept interval that brackets root");
                                                                                           } catch (MaxIterationsExceededException e) {
                                                                                               fail("Max iterations exceeded");
                                                                                           }
                                                                                       }

    @Test
                                                                                       public void testSolveWithOneEndpointExactlyZero1() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                           // Setup
                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                           when(f.value(0.0)).thenReturn(0.0);  // yMin is exactly zero
                                                                                           when(f.value(1.0)).thenReturn(2.0);  // yMax is positive
                                                                                           
                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                           solver.setFunctionValueAccuracy(1e-6); // Assuming this setter exists
                                                                                           
                                                                                           // Test and verify
                                                                                           double result = solver.solve(0.0, 1.0);
                                                                                           
                                                                                           // Original behavior: should return 0.0 (the root)
                                                                                           // Mutated behavior: would enter first if block and potentially throw exception
                                                                                           assertEquals(0.0, result, 0.0);
                                                                                           
                                                                                           // Verify the function was called with the expected values
                                                                                           verify(f).value(0.0);
                                                                                           verify(f).value(1.0);
                                                                                       }

    @Test
                                                                                       public void testSolveWithBothEndpointsSameSignButOneExactlyZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                           // Setup - case where yMin is exactly zero and yMax is positive
                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                           when(f.value(0.0)).thenReturn(0.0);
                                                                                           when(f.value(1.0)).thenReturn(0.5);
                                                                                           
                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                           solver.setFunctionValueAccuracy(1e-6);
                                                                                           
                                                                                           // Test and verify
                                                                                           double result = solver.solve(0.0, 1.0);
                                                                                           
                                                                                           // Original behavior should return 0.0 (the root)
                                                                                           assertEquals(0.0, result, 0.0);
                                                                                       }

    @Test
                                                                                       public void testSolveDetectsSwappedBoundsMutant() throws Exception {
                                                                                           // Create a mock function that has a root between 2 and 4
                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                           when(f.value(2.0)).thenReturn(-1.0);  // f(min) is negative
                                                                                           when(f.value(4.0)).thenReturn(1.0);   // f(max) is positive
                                                                                           
                                                                                           // The function value at initial point (3.0) is negative
                                                                                           when(f.value(3.0)).thenReturn(-0.5);
                                                                                           
                                                                                           BrentSolver solver = new BrentSolver();
                                                                                           
                                                                                           // The original implementation should find a root between 2 and 4
                                                                                           double result = solver.solve(f, 2.0, 4.0, 3.0);
                                                                                           
                                                                                           // Verify the result is within the expected bounds
                                                                                           assertTrue("Root should be between min and max", result >= 2.0 && result <= 4.0);
                                                                                           
                                                                                           // The mutant would fail this test because it would evaluate with swapped bounds,
                                                                                           // potentially causing incorrect behavior or failing to find the root
                                                                                       }

    @Test
                                                                          public void testSolve_NonBracketingInterval_CorrectExceptionMessageOrder() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                              // Setup
                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                              when(f.value(1.0)).thenReturn(2.0);
                                                                              when(f.value(3.0)).thenReturn(4.0);
                                                                              
                                                                              BrentSolver solver = new BrentSolver(f);
                                                                              solver.setFunctionValueAccuracy(0.0001);
                                                                              
                                                                              // Expected exception message parts in correct order
                                                                              String expectedMin = "1.0";
                                                                              String expectedMax = "3.0";
                                                                              
                                                                              try {
                                                                                  // Test
                                                                                  solver.solve(1.0, 3.0);
                                                                                  fail("Expected IllegalArgumentException");
                                                                              } catch (IllegalArgumentException e) {
                                                                                  // Verify exception message contains parameters in correct order
                                                                                  String msg = e.getMessage();
                                                                                  assertTrue("Exception message should show min before max", 
                                                                                      msg.indexOf(expectedMin) < msg.indexOf(expectedMax));
                                                                                  throw e;
                                                                              }
                                                                          }

    @Test
                                                                          public void testSolve_NonBracketingParameters_ExceptionMessageCorrectOrder() {
                                                                              // Setup
                                                                              BrentSolver solver = new BrentSolver();
                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                              
                                                                              // Mock function values - both positive (non-bracketing condition)
                                                                              try {
                                                                                  when(f.value(1.0)).thenReturn(2.0);  // yMin
                                                                                  when(f.value(3.0)).thenReturn(4.0);  // yMax
                                                                                  when(f.value(2.0)).thenReturn(3.0);  // yInitial
                                                                                  
                                                                                  try {
                                                                                      // Get private NON_BRACKETING_MESSAGE field via reflection
                                                                                      Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                                                                      field.setAccessible(true);
                                                                                      String nonBracketingMessage = (String) field.get(null);
                                                                                      
                                                                                      // Exercise
                                                                                      solver.solve(f, 1.0, 3.0, 2.0);
                                                                                  } catch (IllegalArgumentException e) {
                                                                                      // Verify
                                                                                      String expectedMessage = String.format("function values at endpoints do not have different signs. Endpoints: [%1$f, %2$f]" +
                                                                                          " Values: [%3$f, %4$f]", 1.0, 3.0, 2.0, 4.0);
                                                                                      assertEquals("Exception message should show parameters in correct order", 
                                                                                                  expectedMessage, e.getMessage());
                                                                                      throw e;
                                                                                  } catch (FunctionEvaluationException e) {
                                                                                      fail("Unexpected FunctionEvaluationException: " + e.getMessage());
                                                                                  } catch (Exception e) {
                                                                                      fail("Unexpected exception: " + e.getMessage());
                                                                                  }
                                                                              } catch (FunctionEvaluationException e) {
                                                                                  fail("Mock setup should not throw FunctionEvaluationException");
                                                                              }
                                                                          }

    @Test
                                                                          public void testSolve_NonBracketingParameters_ErrorMessageCorrectOrder() throws FunctionEvaluationException {
                                                                              // Setup
                                                                              BrentSolver solver = new BrentSolver();
                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                              double min = 1.0;
                                                                              double max = 2.0;
                                                                              double yMin = 0.5;
                                                                              double yMax = 1.0;
                                                                              
                                                                              // Stub the function to return same-sign values
                                                                              when(f.value(min)).thenReturn(yMin);
                                                                              when(f.value(max)).thenReturn(yMax);
                                                                              
                                                                              String nonBracketingMessage = null;
                                                                              try {
                                                                                  // Get private NON_BRACKETING_MESSAGE field using reflection
                                                                                  Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                                                                  field.setAccessible(true);
                                                                                  nonBracketingMessage = (String) field.get(null);
                                                                              } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                  fail("Failed to access NON_BRACKETING_MESSAGE field: " + e.getMessage());
                                                                                  return;
                                                                              }
                                                                              
                                                                              try {
                                                                                  // Exercise
                                                                                  solver.solve(f, min, max);
                                                                                  fail("Expected IllegalArgumentException");
                                                                              } catch (IllegalArgumentException e) {
                                                                                  // Verify
                                                                                  String expectedMessage = String.format("%s (min=%s, max=%s, yMin=%s, yMax=%s)", 
                                                                                      nonBracketingMessage, min, max, yMin, yMax);
                                                                                  assertEquals("Exception message should show parameters in correct order", 
                                                                                      expectedMessage, e.getMessage());
                                                                                  throw e;
                                                                              } catch (MaxIterationsExceededException e) {
                                                                                  fail("Unexpected MaxIterationsExceededException: " + e.getMessage());
                                                                              }
                                                                          }

    @Test
                                                                      public void testSolve_NonBracketingCondition_ShouldThrowWithCorrectParameters() {
                                                                          // Setup function that doesn't bracket a root (both positive)
                                                                          UnivariateRealFunction f = new UnivariateRealFunction() {
                                                                              public double value(double x) throws FunctionEvaluationException {
                                                                                  return x * x + 1; // Always positive
                                                                              }
                                                                          };
                                                                          
                                                                          double min = -2.0;
                                                                          double max = 2.0;
                                                                          double yMin, yMax;
                                                                          try {
                                                                              yMin = f.value(min); // 5.0
                                                                              yMax = f.value(max); // 5.0
                                                                          } catch (FunctionEvaluationException e) {
                                                                              throw new RuntimeException("Unexpected FunctionEvaluationException", e);
                                                                          }
                                                                          
                                                                          BrentSolver solver = new BrentSolver();
                                                                          
                                                                          try {
                                                                              solver.solve(f, min, max);
                                                                              fail("Expected FunctionEvaluationException");
                                                                          } catch (FunctionEvaluationException e) {
                                                                              // Get the private message format using reflection
                                                                              String nonBracketingMessage;
                                                                              try {
                                                                                  Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                                                                  field.setAccessible(true);
                                                                                  nonBracketingMessage = (String) field.get(solver);
                                                                              } catch (Exception ex) {
                                                                                  throw new RuntimeException("Failed to access NON_BRACKETING_MESSAGE field", ex);
                                                                              }
                                                                              
                                                                              // Verify the exception contains the correct parameters in message
                                                                              String expectedMessage = String.format(nonBracketingMessage, 
                                                                                  min, max, yMin, yMax);
                                                                              assertEquals("Exception message should contain correct parameters", 
                                                                                  expectedMessage, e.getMessage());
                                                                          } catch (MaxIterationsExceededException e) {
                                                                              fail("Unexpected MaxIterationsExceededException: " + e.getMessage());
                                                                          }
                                                                      }

    @Test
                                                                  public void testSolveParameterOrder() throws Exception {
                                                                      // Create a mock function that has a root at x=2
                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                      when(f.value(1.0)).thenReturn(-1.0);  // f(min) = -1
                                                                      when(f.value(3.0)).thenReturn(1.0);   // f(max) = 1
                                                                      when(f.value(2.0)).thenReturn(0.0);   // root at x=2
                                                                      
                                                                      // Create solver instance
                                                                      BrentSolver solver = new BrentSolver(f);
                                                                      
                                                                      // Call the public solve method which should delegate to private solve
                                                                      // with min=1, max=3 (bracketing the root at 2)
                                                                      double result = solver.solve(1.0, 3.0);
                                                                      
                                                                      // Verify the result is close to the expected root
                                                                      assertEquals(2.0, result, 1e-6);
                                                                      
                                                                      // Verify the function was called with correct parameters
                                                                      // This is the key assertion that would catch the mutant
                                                                      verify(f).value(1.0);  // min
                                                                      verify(f).value(3.0);  // max
                                                                      verify(f).value(2.0);  // approximate root
                                                                  }

    @Test
                                                                 public void testSolveParameterOrderSensitivity() throws Exception {
                                                                     // Create a function with roots at 1 and 3 (asymmetric)
                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                     when(f.value(1.0)).thenReturn(0.0);
                                                                     when(f.value(3.0)).thenReturn(0.0);
                                                                     when(f.value(0.5)).thenReturn(-1.0);  // left of first root
                                                                     when(f.value(2.0)).thenReturn(1.0);   // between roots
                                                                     when(f.value(4.0)).thenReturn(1.0);   // right of second root
                                                                     
                                                                     BrentSolver solver = new BrentSolver();
                                                                     
                                                                     // Get the private solve method via reflection
                                                                     Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                         "solve", 
                                                                         UnivariateRealFunction.class, 
                                                                         double.class, double.class, 
                                                                         double.class, double.class, 
                                                                         double.class, double.class
                                                                     );
                                                                     solveMethod.setAccessible(true);
                                                                     
                                                                     // Test with min=0.5, max=2.0 (should find root at 1.0)
                                                                     double result1 = (Double) solveMethod.invoke(
                                                                         solver, 
                                                                         f, 
                                                                         0.5, f.value(0.5), 
                                                                         2.0, f.value(2.0), 
                                                                         1.5, f.value(1.5)
                                                                     );
                                                                     assertEquals(1.0, result1, 1e-6);
                                                                     
                                                                     // Test with min=2.0, max=4.0 (should find root at 3.0)
                                                                     double result2 = (Double) solveMethod.invoke(
                                                                         solver, 
                                                                         f, 
                                                                         2.0, f.value(2.0), 
                                                                         4.0, f.value(4.0), 
                                                                         3.0, f.value(3.0)
                                                                     );
                                                                     assertEquals(3.0, result2, 1e-6);
                                                                     
                                                                     // The mutant would incorrectly swap these brackets and potentially find wrong roots
                                                                     // or fail to converge properly
                                                                 }

    @Test
                                                 public void testSolveParameterOrderWhenBracketingFails() throws Exception {
                                                     // Setup mock function that forces execution path to reach the mutated line
                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                     when(f.value(anyDouble())).thenReturn(1.0, -1.0, 1.0); // yMin=1, yInitial=-1, yMax=1
                                                     
                                                     // Create spy to verify private method call
                                                     BrentSolver solver = spy(new BrentSolver(f));
                                                     
                                                     // Call the method with parameters that will exercise the mutated path
                                                     // min=0, max=2, initial=1
                                                     // yMin*yInitial < 0 but yInitial*yMax < 0 is false
                                                     // yMin*yMax > 0 is true (should throw exception but we're testing before that)
                                                     try {
                                                         solver.solve(0, 2, 1);
                                                     } catch (IllegalArgumentException e) {
                                                         // Expected to throw, but we want to verify the call before that
                                                     }
                                                     
                                                     // Use reflection to verify private method call
                                                     try {
                                                         Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                             "solve", 
                                                             UnivariateRealFunction.class, 
                                                             double.class, 
                                                             double.class, 
                                                             double.class, 
                                                             double.class, 
                                                             double.class, 
                                                             double.class
                                                         );
                                                         solveMethod.setAccessible(true);
                                                         
                                                         // Instead of verify(), we'll check if the method was called by checking the result
                                                         // or state changes. Since we can't verify private method calls directly,
                                                         // we'll just ensure the test exercises the path we want.
                                                         
                                                         // Alternative verification: check that the expected exception was thrown
                                                         // due to the bracketing failure
                                                         try {
                                                             solver.solve(0, 2, 1);
                                                             fail("Expected IllegalArgumentException");
                                                         } catch (IllegalArgumentException e) {
                                                             // Expected
                                                         }
                                                     } catch (NoSuchMethodException e) {
                                                         fail("Private solve method not found");
                                                     }
                                                 }

    @Test
                                             public void testSolveParameterOrder1() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                 // Create a mock function that returns different values at min and max
                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                 when(f.value(1.0)).thenReturn(-1.0);  // f(min) = -1
                                                 when(f.value(3.0)).thenReturn(1.0);   // f(max) = 1
                                                 when(f.value(2.0)).thenReturn(0.5);   // f(initial) = 0.5
                                                 
                                                 // Create solver and test
                                                 BrentSolver solver = new BrentSolver(f);
                                                 double result = solver.solve(1.0, 3.0, 2.0);
                                                 
                                                 // Verify the result is between min and max (should be near the root)
                                                 assertTrue("Result should be between min and max", result >= 1.0 && result <= 3.0);
                                                 
                                                 // Verify the function was called with correct parameters
                                                 // This is the key assertion that will catch the mutant
                                                 verify(f).value(1.0);  // min
                                                 verify(f).value(3.0);  // max
                                                 verify(f).value(2.0);  // initial
                                             }

    @Test
                                             public void testSolveWithAsymmetricFunctionDetectsParameterOrderMutant() throws MaxIterationsExceededException, FunctionEvaluationException {
                                                 // Create an asymmetric function where root finding is sensitive to parameter order
                                                 UnivariateRealFunction f = new UnivariateRealFunction() {
                                                     @Override
                                                     public double value(double x) {
                                                         // Asymmetric function: (x-2)^3 - 0.1*(x-2)
                                                         // Root at x≈2.316 when searching [1,3]
                                                         return Math.pow(x-2, 3) - 0.1*(x-2);
                                                     }
                                                 };
                                                 
                                                 BrentSolver solver = new BrentSolver(f);
                                                 double min = 1.0;
                                                 double max = 3.0;
                                                 
                                                 // Expected result (from original implementation)
                                                 double expected = solver.solve(min, max);
                                                 
                                                 // The mutant would give a different result because it swaps min/max parameters
                                                 // We need to verify the result is within acceptable tolerance
                                                 double actual = solver.solve(min, max);
                                                 
                                                 // The mutant would likely converge to a different value or fail to converge
                                                 assertEquals(expected, actual, 1e-6);
                                                 
                                                 // Additional verification - check if we got the expected root
                                                 // The actual root for this function in [1,3] is ≈2.316
                                                 double root = actual;
                                                 assertTrue(root > 2.3 && root < 2.32);
                                                 assertEquals(0.0, f.value(root), 1e-6);
                                             }

    @Test
                                         public void testSolveClearsPreviousResult2() throws Exception {
                                             // Create mock functions
                                             UnivariateRealFunction f1 = mock(UnivariateRealFunction.class);
                                             UnivariateRealFunction f2 = mock(UnivariateRealFunction.class);
                                             
                                             // Setup mock behaviors
                                             when(f1.value(anyDouble())).thenReturn(1.0);
                                             when(f2.value(anyDouble())).thenReturn(-1.0);
                                             
                                             // Create solver and perform first computation
                                             BrentSolver solver = new BrentSolver();
                                             double result1 = solver.solve(f1, 0.0, 1.0);
                                             
                                             // Now test if second computation is affected by first one
                                             double result2 = solver.solve(f2, 0.0, 1.0);
                                             
                                             // Verify that both computations used their respective functions
                                             // If clearResult() was not called, the second solve might use cached values from f1
                                             verify(f1, atLeastOnce()).value(anyDouble());
                                             verify(f2, atLeastOnce()).value(anyDouble());
                                             
                                             // Additional verification that results are different (as per our mock setup)
                                             assertNotEquals(result1, result2, 0.0001);
                                         }

    @Test
                                             public void testSolveClearsPreviousResult3() throws Exception {
                                                 // Setup mock function that returns different values for different inputs
                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                 when(f.value(1.0)).thenReturn(-1.0);
                                                 when(f.value(2.0)).thenReturn(1.0);
                                                 when(f.value(1.5)).thenReturn(0.0);
                                                 when(f.value(3.0)).thenReturn(-2.0);
                                                 when(f.value(4.0)).thenReturn(2.0);
                                                 when(f.value(3.5)).thenReturn(0.0);
                                         
                                                 BrentSolver solver = new BrentSolver(f);
                                                 
                                                 // First solve call
                                                 double result1 = solver.solve(f, 1.0, 2.0, 1.5);
                                                 assertEquals(1.5, result1, 1e-6);
                                                 
                                                 // Second solve call with different parameters
                                                 double result2 = solver.solve(f, 3.0, 4.0, 3.5);
                                                 assertEquals(3.5, result2, 1e-6);
                                                 
                                                 // If clearResult() was commented out, the second result might be affected by the first call
                                                 // This test would fail in that case
                                             }

    @Test
                                             public void testSolveClearsResultBetweenCalls1() throws Exception {
                                                 // Create a mock function that returns different values on subsequent calls
                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                 when(f.value(anyDouble()))
                                                     .thenReturn(1.0)  // First call for initial
                                                     .thenReturn(-1.0) // First call for min
                                                     .thenReturn(2.0)  // First call for max
                                                     .thenReturn(0.0)  // Second call for initial (exact solution)
                                                     .thenReturn(1.0)  // Second call for min
                                                     .thenReturn(1.0); // Second call for max
                                         
                                                 BrentSolver solver = new BrentSolver(f);
                                                 
                                                 // First call - should not find exact solution
                                                 double firstResult = solver.solve(0, 2, 1);
                                                 // The first call shouldn't find exact solution (function values are 1, -1, 2)
                                                 // So it should run the full algorithm and return some approximation
                                                 
                                                 // Second call - should find exact solution at initial point (function value = 0)
                                                 double secondResult = solver.solve(0, 2, 1);
                                                 
                                                 // Verify that the second call correctly found the exact solution at initial point
                                                 // If clearResult() was commented out, the second call might use stale results
                                                 // and not properly detect the exact solution at initial point
                                                 assertEquals(1.0, secondResult, 0.0);
                                                 
                                                 // Also verify the function was called the expected number of times
                                                 verify(f, times(6)).value(anyDouble());
                                             }

    @Test
                                             public void testClearResultIsCalledBetweenSolveCalls() throws Exception {
                                                 // Setup mock function that returns different values for different inputs
                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                 when(f.value(1.0)).thenReturn(-1.0);
                                                 when(f.value(2.0)).thenReturn(1.0);
                                                 when(f.value(3.0)).thenReturn(-2.0);
                                                 when(f.value(4.0)).thenReturn(2.0);
                                                 
                                                 // Create solver with mock function
                                                 BrentSolver solver = new BrentSolver(f);
                                                 
                                                 // First solve call - should find root between 1 and 2
                                                 double firstResult = solver.solve(1.0, 2.0);
                                                 
                                                 // Second solve call with different interval - should find root between 3 and 4
                                                 double secondResult = solver.solve(3.0, 4.0);
                                                 
                                                 // Verify results are independent
                                                 // If clearResult() was commented out, the second result might be affected by first call
                                                 assertNotEquals("Results should be different for different intervals", 
                                                                firstResult, secondResult, 0.0001);
                                                 
                                                 // Verify the results are in their expected ranges
                                                 assertTrue("First result should be between 1 and 2", 
                                                           firstResult >= 1.0 && firstResult <= 2.0);
                                                 assertTrue("Second result should be between 3 and 4", 
                                                           secondResult >= 3.0 && secondResult <= 4.0);
                                             }

    @Test
                                        public void testSolveClearsPreviousResult4() throws Exception {
                                            // Setup mock function
                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                            BrentSolver solver = new BrentSolver(function);
                                            
                                            // First setup - function crosses zero at x=1.5
                                            when(function.value(1.0)).thenReturn(-1.0);
                                            when(function.value(2.0)).thenReturn(1.0);
                                            when(function.value(1.5)).thenReturn(0.0);
                                            
                                            // First solution
                                            double firstResult = solver.solve(1.0, 2.0);
                                            assertEquals(1.5, firstResult, 1e-6);
                                            
                                            // Second setup - completely different function crossing at x=3.5
                                            when(function.value(3.0)).thenReturn(-1.0);
                                            when(function.value(4.0)).thenReturn(1.0);
                                            when(function.value(3.5)).thenReturn(0.0);
                                            
                                            // Second solution - should not be affected by first solution
                                            double secondResult = solver.solve(3.0, 4.0);
                                            assertEquals(3.5, secondResult, 1e-6);
                                            
                                            // If clearResult() was commented out, the second solution might be affected
                                            // by internal state from the first solution, causing this test to fail
                                        }

    @Test
                                        public void testSolveWithInitialGuessClearsPreviousResult() throws Exception {
                                            // Setup mock function
                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                            when(function.value(1.0)).thenReturn(-1.0);
                                            when(function.value(3.0)).thenReturn(1.0);
                                            when(function.value(2.0)).thenReturn(0.0);
                                            
                                            // Initialize solver
                                            BrentSolver solver = new BrentSolver(function);
                                            
                                            // First solution with initial guess
                                            double firstResult = solver.solve(1.0, 3.0, 2.0);
                                            assertEquals(2.0, firstResult, 1e-6);
                                            
                                            // Second setup
                                            when(function.value(5.0)).thenReturn(-1.0);
                                            when(function.value(7.0)).thenReturn(1.0);
                                            when(function.value(6.0)).thenReturn(0.0);
                                            
                                            // Second solution - should be independent
                                            double secondResult = solver.solve(5.0, 7.0, 6.0);
                                            assertEquals(6.0, secondResult, 1e-6);
                                        }

    @Test
                                        public void testSolveReportsZeroIterationsWhenInitialIsSolution() throws Exception {
                                            // Setup
                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                            when(f.value(anyDouble())).thenReturn(0.0); // Initial value is already solution
                                            
                                            BrentSolver solver = new BrentSolver(f);
                                            double min = 0.0;
                                            double max = 1.0;
                                            double initial = 0.5; // This is the solution
                                            
                                            // Execute
                                            double result = solver.solve(f, min, max, initial);
                                            
                                            // Verify - we need to check the iteration count was set to 0
                                            // Since we can't directly access the result object, we'll verify the mock interaction
                                            // This assumes setResult is called internally with the correct iteration count
                                            // In a real test, we might need to extend BrentSolver to expose the iteration count
                                            
                                            // Alternative approach: verify the result is correct and iteration count is minimal
                                            assertEquals(initial, result, 0.0001);
                                            // If we had access to the iteration count, we would assert it's 0
                                            // Since we can't, this test would need to be adjusted based on actual class implementation
                                            
                                            // More complete solution would require access to iteration count:
                                            // assertEquals(0, solver.getIterationCount());
                                        }

    @Test
                                    public void testImmediateConvergenceReportsZeroIterations1() throws Exception {
                                        // Setup - create a case where y1 is already within accuracy (immediate convergence)
                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                        when(f.value(anyDouble())).thenReturn(0.5).thenReturn(1e-7); // y1 will be within accuracy
                                        
                                        BrentSolver solver = new BrentSolver(f);
                                        
                                        // Use reflection to access private solve method
                                        Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                            "solve", 
                                            UnivariateRealFunction.class, 
                                            double.class, double.class, 
                                            double.class, double.class, 
                                            double.class, double.class
                                        );
                                        solveMethod.setAccessible(true);
                                        
                                        // Call with initial values where y1 is already accurate
                                        double x0 = 1.0, y0 = 0.5;
                                        double x1 = 2.0, y1 = 1e-7; // y1 within accuracy
                                        double x2 = 3.0, y2 = 0.5;
                                        
                                        // Execute
                                        double result = (double) solveMethod.invoke(
                                            solver, 
                                            f, x0, y0, x1, y1, x2, y2
                                        );
                                        
                                        // Verify the iteration count was properly set to 0
                                        // Assuming getIterationCount() exists or we can check via other means
                                        // This part depends on how the result is stored in BrentSolver
                                        // For this test, we'll assume we can access the last iteration count
                                        Field iterationField = BrentSolver.class.getDeclaredField("iterationCount");
                                        iterationField.setAccessible(true);
                                        int iterations = (int) iterationField.get(solver);
                                        
                                        assertEquals("Should report 0 iterations for immediate convergence", 0, iterations);
                                        assertEquals("Solution should be x1", x1, result, 1e-12);
                                    }

    @Test
                                   public void testInitialIterationCountIsZero() throws Exception {
                                       // Setup
                                       UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                       when(mockFunction.value(anyDouble())).thenReturn(0.0); // Mock root at any point
                                       
                                       BrentSolver solver = new BrentSolver(mockFunction);
                                       
                                       // Create a spy to verify internal method calls
                                       BrentSolver spySolver = spy(solver);
                                       
                                       // Test
                                       spySolver.solve(0.0, 1.0);
                                       
                                       // Verify that iteration count starts at 0
                                       // Since we can't directly verify setResult, we'll verify the initial state
                                       Field iterationCountField = BrentSolver.class.getDeclaredField("iterationCount");
                                       iterationCountField.setAccessible(true);
                                       int initialIterationCount = (int) iterationCountField.get(spySolver);
                                       assertEquals(0, initialIterationCount);
                                   }

    @Test
                               public void testSolve_InitialGuessIsRoot_ShouldReturnZeroIterations() throws FunctionEvaluationException, MaxIterationsExceededException {
                                   // Setup
                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                   when(f.value(anyDouble())).thenReturn(0.0); // initial guess is root
                                   
                                   BrentSolver solver = new BrentSolver(f);
                                   
                                   // Test parameters where initial guess is exactly the root
                                   double min = 0.0;
                                   double max = 10.0;
                                   double initial = 5.0; // this will be the root
                                   
                                   // Execute
                                   double result = solver.solve(min, max, initial);
                                   
                                   // Verify - we need to check both the result value and iteration count
                                   // Since we can't directly access the iteration count, we need to verify
                                   // the internal state through the result object or other means
                                   
                                   // Assuming the solver has a way to get the iteration count (this part may need adjustment
                                   // based on actual class implementation)
                                   assertEquals(5.0, result, 0.0001); // verify correct root value
                                   assertEquals(0, solver.getIterationCount()); // verify 0 iterations
                               }

    @Test
                               public void testSolve_DetectsSetResultIterationCountMutation() throws MaxIterationsExceededException, FunctionEvaluationException {
                                   // Setup
                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                   when(f.value(1.0)).thenReturn(1e-7);  // within default functionValueAccuracy (1E-6)
                                   when(f.value(2.0)).thenReturn(1.0);
                                   
                                   BrentSolver solver = new BrentSolver(f);
                                   
                                   // Need to access the iteration count - assuming parent class has getIterationCount()
                                   // or similar method. If not, we'd need to add instrumentation.
                                   // This is a limitation since we can't directly observe setResult's parameters
                                   
                                   // Alternative approach: test the return value matches the endpoint
                                   double result = solver.solve(1.0, 2.0);
                                   
                                   // Verify the correct endpoint is returned
                                   assertEquals(1.0, result, 0.0);
                                   
                                   // To actually catch the mutant, we'd need to verify the iteration count was set to 0
                                   // This would require either:
                                   // 1. Adding a getter for iteration count in the class
                                   // 2. Using reflection to check internal state
                                   // 3. Subclassing and overriding setResult to capture parameters
                                   
                                   // Since we can't modify the class, here's a reflection-based approach:
                                   try {
                                       Field iterationsField = BrentSolver.class.getSuperclass().getDeclaredField("iterationCount");
                                       iterationsField.setAccessible(true);
                                       int iterations = (int) iterationsField.get(solver);
                                       assertEquals(0, iterations);  // This will fail if mutant is present (would be 1)
                                   } catch (Exception e) {
                                       fail("Failed to access iteration count: " + e.getMessage());
                                   }
                               }

    @Test
                           public void testBracketingConditionWithZeroProduct() throws Exception {
                               // Create a mock function that returns 0 at some point
                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                               when(f.value(anyDouble())).thenReturn(1.0, 0.0); // yInitial=1.0, yMin=0.0
                               
                               BrentSolver solver = new BrentSolver(f);
                               
                               try {
                                   // Test with values that will make yInitial * yMin = 0
                                   double result = solver.solve(0.0, 1.0, 0.5);
                                   
                                   // If we get here, the mutant passed (which is bad)
                                   fail("Expected IllegalArgumentException for non-bracketing case");
                               } catch (IllegalArgumentException e) {
                                   // Original behavior should throw exception when product is exactly 0
                                   assertTrue(e.getMessage().contains("function values at endpoints must have different signs"));
                               }
                           }

    @Test
                           public void testBracketingConditionWithNegativeProduct() throws Exception {
                               // Create a mock function with proper bracketing (negative product)
                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                               when(f.value(anyDouble())).thenReturn(1.0, -1.0); // yInitial=1.0, yMin=-1.0
                               
                               BrentSolver solver = new BrentSolver(f);
                               
                               // This should pass in both original and mutated versions
                               double result = solver.solve(0.0, 1.0, 0.5);
                               // Just verify the method completes without exception
                               assertNotNull(result);
                           }

    @Test
                           public void testBracketingConditionWithPositiveProduct() throws Exception {
                               // Create a mock function with invalid bracketing (positive product)
                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                               when(f.value(anyDouble())).thenReturn(1.0, 1.0); // yInitial=1.0, yMin=1.0
                               
                               BrentSolver solver = new BrentSolver(f);
                               
                               try {
                                   solver.solve(0.0, 1.0, 0.5);
                                   fail("Expected IllegalArgumentException for non-bracketing case");
                               } catch (IllegalArgumentException e) {
                                   assertTrue(e.getMessage().contains("function values at endpoints must have different signs"));
                               }
                           }

    @Test
                          public void testSolveWithExactZeroShouldNotBracket() throws Exception {
                              // Create a mock function that returns 0 at min point
                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                              when(f.value(0.0)).thenReturn(0.0);  // yMin = 0
                              when(f.value(1.0)).thenReturn(1.0);  // yInitial = 1
                              
                              BrentSolver solver = new BrentSolver();
                              
                              try {
                                  // This should throw an exception because [0,1] doesn't bracket a root
                                  // (1*0 is not negative, just zero)
                                  solver.solve(f, 0.0, 2.0, 1.0);
                                  fail("Expected IllegalArgumentException for non-bracketing interval");
                              } catch (IllegalArgumentException e) {
                                  // We know the correct exception was thrown
                              }
                              
                              // Verify the function was evaluated at the expected points
                              verify(f).value(0.0);
                              verify(f).value(1.0);
                          }

    @Test
                      public void testSolveWithInitialValueZeroShouldNotConsiderAsBracketed() throws FunctionEvaluationException, MaxIterationsExceededException {
                          // Create a mock function that returns:
                          // - positive value at min
                          // - zero at initial point
                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                          when(f.value(1.0)).thenReturn(2.0);  // yMin = 2.0 (positive)
                          when(f.value(1.5)).thenReturn(0.0);  // yInitial = 0.0
                          
                          BrentSolver solver = new BrentSolver();
                          
                          try {
                              // This should throw an exception because the bracket isn't valid
                              // (since yInitial is zero but yMin is positive)
                              solver.solve(f, 1.0, 2.0, 1.5);
                              fail("Expected IllegalArgumentException for non-bracketing case");
                          } catch (IllegalArgumentException e) {
                              // Verify the correct exception is thrown
                              assertTrue(e.getMessage().contains("function values at endpoints do not have different signs"));
                          }
                          
                          // Verify the function was evaluated at the expected points
                          verify(f).value(1.0);
                          verify(f).value(1.5);
                      }

    @Test
                      public void testSolveDetectsMutantWhenYInitialIsZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                          // Create a mock function where:
                          // - f(initial) = 0 (exactly)
                          // - f(min) = 1 (positive)
                          // - f(max) = -1 (negative)
                          // functionValueAccuracy is set to 1e-6 (from constructor)
                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                          when(f.value(1.0)).thenReturn(1.0);  // min
                          when(f.value(2.0)).thenReturn(0.0);  // initial (exactly zero)
                          when(f.value(3.0)).thenReturn(-1.0); // max
                          
                          BrentSolver solver = new BrentSolver(f);
                          
                          // The original code should:
                          // 1. Check initial (2.0) - not within functionValueAccuracy (0.0 is not <= 1e-6)
                          // 2. Check min (1.0) - not within functionValueAccuracy
                          // 3. Check yInitial * yMin = 0 * 1 = 0 (original: <0 is false, mutant: <=0 is true)
                          //    Original would proceed to check max, mutant would take the first branch
                          
                          // With the mutant, it would incorrectly take the first branch
                          // So we test that it doesn't return the result from the first branch
                          double result = solver.solve(1.0, 3.0, 2.0);
                          
                          // Verify it didn't return the result from the first branch
                          // The correct behavior would be to eventually return max (3.0) since it's within accuracy
                          // or proceed to full Brent algorithm
                          // We just need to verify it's not the initial guess (2.0)
                          assertNotEquals(2.0, result, 0.0);
                          
                          // Additional verification that it went through the correct path
                          // It should have checked max value (3.0) which is within accuracy (-1.0 <= 1e-6 is false)
                          // Then proceed to full Brent algorithm
                          // We can verify the result is reasonable (between 1.0 and 3.0)
                          assertTrue(result >= 1.0 && result <= 3.0);
                      }

    @Test
                      public void testSolveWithInitialZeroDetectsMutant() throws FunctionEvaluationException, MaxIterationsExceededException {
                          // Setup
                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                          when(f.value(1.0)).thenReturn(0.0);  // yInitial = 0
                          when(f.value(2.0)).thenReturn(-1.0); // yMin = -1
                          
                          BrentSolver solver = new BrentSolver(f);
                          
                          // Test case where yInitial is zero (yInitial * yMin = 0)
                          double result = solver.solve(1.0, 2.0, 1.5); // initial = 1.5
                          
                          // Verify the behavior is correct (should handle zero case differently than negative case)
                          // The mutant would treat this the same as negative case (<= 0 vs < 0)
                          assertEquals(1.0, result, 0.0001);
                          
                          // Additional test case where yMin is zero
                          when(f.value(1.0)).thenReturn(1.0);
                          when(f.value(2.0)).thenReturn(0.0); // yMin = 0
                          result = solver.solve(1.0, 2.0, 1.5);
                          assertEquals(2.0, result, 0.0001);
                          
                          // Test case with negative product (both original and mutant should behave same)
                          when(f.value(1.0)).thenReturn(1.0);
                          when(f.value(2.0)).thenReturn(-1.0);
                          result = solver.solve(1.0, 2.0, 1.5);
                          // Should use solve() method rather than return endpoint
                          assertNotEquals(1.0, result, 0.0001);
                          assertNotEquals(2.0, result, 0.0001);
                      }

    @Test
                      public void testSolveMaintainsBracketingOrder() throws Exception {
                          // Setup test data
                          double min = 0.0;
                          double max = 1.0;
                          double initial = 0.5;
                          
                          // Mock the function to return specific values at min and max
                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                          when(f.value(min)).thenReturn(-1.0);  // yMin
                          when(f.value(max)).thenReturn(1.0);   // yMax
                          
                          // Create solver and call method
                          BrentSolver solver = new BrentSolver();
                          try {
                              solver.solve(f, min, max, initial);
                              
                              // Verify the function was called with correct parameters
                              verify(f).value(min);  // Should be called with min first
                              verify(f).value(max); // Then with max
                              
                              // If we reach here, the test passes (mutant would have failed)
                          } catch (IllegalArgumentException e) {
                              // The mutant might throw an exception due to reversed bracketing
                              fail("Method should not throw exception with proper bracketing");
                          }
                      }

    @Test
                 public void testSolve_NonBracketingParameters_ErrorMessageCorrect() throws FunctionEvaluationException, MaxIterationsExceededException {
                     // Setup
                     BrentSolver solver = new BrentSolver();
                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                     double min = 0.0;
                     double max = 1.0;
                     double yMin = 1.0;  // positive
                     double yMax = 2.0;  // positive (same sign)
                     
                     // Stub the function to return same-sign values
                     when(f.value(min)).thenReturn(yMin);
                     when(f.value(max)).thenReturn(yMax);
                     
                     try {
                         // Exercise
                         solver.solve(f, min, max);
                     } catch (IllegalArgumentException e) {
                         // Verify
                         String expectedMessage = String.format("Function values at endpoints do not have different signs." +
                             " Endpoints: [%f, %f]" +
                             " Values: [%f, %f]", min, max, yMin, yMax);
                         assertEquals("Error message should show parameters in correct order", 
                             expectedMessage, e.getMessage());
                         throw e;
                     }
                 }

    @Test(expected = IllegalArgumentException.class)
                 public void testSolve_NonBracketingCondition_ExceptionMessage() throws FunctionEvaluationException {
                     // Setup mock function that returns positive values at both endpoints
                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                     when(f.value(1.0)).thenReturn(2.0);  // yMin = 2.0
                     when(f.value(3.0)).thenReturn(4.0);  // yMax = 4.0
                     when(f.value(2.0)).thenReturn(3.0);  // yInitial = 3.0
                     
                     BrentSolver solver = new BrentSolver(f);
                     
                     try {
                         try {
                             solver.solve(1.0, 3.0, 2.0);  // min=1.0, max=3.0, initial=2.0
                         } catch (MaxIterationsExceededException e) {
                             fail("Unexpected MaxIterationsExceededException");
                         }
                     } catch (IllegalArgumentException e) {
                         // Verify exception message contains correct parameter order
                         String expectedMessagePattern = ".*function values at endpoints.*1.*3.*2.*4.*";
                         assertTrue("Exception message should contain min/max in correct order", 
                                   e.getMessage().matches(expectedMessagePattern));
                         throw e;  // rethrow to satisfy @Test(expected)
                     }
                 }

    @Test
                 public void testSolve_NonBracketingParametersOrder() throws FunctionEvaluationException {
                     // Setup
                     BrentSolver solver = new BrentSolver();
                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                     when(f.value(1.0)).thenReturn(2.0);
                     when(f.value(3.0)).thenReturn(4.0);
                     
                     try {
                         // Exercise
                         try {
                             solver.solve(f, 1.0, 3.0);
                         } catch (MaxIterationsExceededException e) {
                             fail("Unexpected MaxIterationsExceededException");
                         }
                     } catch (IllegalArgumentException e) {
                         // Verify
                         String message = e.getMessage();
                         assertTrue("Exception message should contain min first", 
                             message.contains("1.0") && message.indexOf("1.0") < message.indexOf("3.0"));
                         assertTrue("Exception message should contain yMin first",
                             message.contains("2.0") && message.indexOf("2.0") < message.indexOf("4.0"));
                         throw e;
                     }
                     fail("Expected IllegalArgumentException");
                 }

    @Test(expected = IllegalArgumentException.class)
             public void testSolve_NonBracketingCondition_ErrorMessageCorrect() throws FunctionEvaluationException, MaxIterationsExceededException {
                 // Setup
                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                 when(f.value(1.0)).thenReturn(2.0);  // yMin positive
                 when(f.value(2.0)).thenReturn(3.0);  // yMax positive - no root bracketed
                 
                 BrentSolver solver = new BrentSolver(f);
                 
                 try {
                     // Exercise - should throw exception since f(1)=2 and f(2)=3 don't bracket a root
                     solver.solve(1.0, 2.0);
                 } catch (IllegalArgumentException e) {
                     // Verify
                     String expectedMessage = String.format("NON_BRACKETING_MESSAGE, %g, %g, %g, %g", 
                         1.0, 2.0, 2.0, 3.0);
                     assertTrue("Exception message should contain correctly ordered parameters",
                               e.getMessage().contains(expectedMessage));
                     throw e; // rethrow to satisfy @Test(expected)
                 }
             }

    @Test
             public void testSolveWithProperBracketingDetectsMutant() throws Exception {
                 // Create a mock function that has root at 2.0
                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                 when(f.value(1.0)).thenReturn(-1.0);  // yMin
                 when(f.value(3.0)).thenReturn(1.0);   // yMax
                 when(f.value(2.0)).thenReturn(0.0);   // root
                 when(f.value(1.5)).thenReturn(-0.5);  // intermediate values
                 when(f.value(2.5)).thenReturn(0.5);   // intermediate values
                 
                 // Create solver with default accuracy settings
                 BrentSolver solver = new BrentSolver();
                 
                 // Test with proper bracketing (min=1.0, max=3.0)
                 double result = solver.solve(f, 1.0, 3.0);
                 
                 // Verify the result is close to the actual root (2.0)
                 assertEquals(2.0, result, 1e-6);
                 
                 // The mutant would have swapped min and max, which might still work mathematically
                 // but we can add additional verification of the convergence path
                 // by checking the number of iterations or intermediate values
                 
                 // Alternatively, test with a case where swapping would fail
                 UnivariateRealFunction f2 = mock(UnivariateRealFunction.class);
                 when(f2.value(1.0)).thenReturn(1.0);  // yMin positive
                 when(f2.value(3.0)).thenReturn(-1.0); // yMax negative
                 when(f2.value(2.0)).thenReturn(0.0);  // root
                 
                 // This should throw IllegalArgumentException due to non-bracketing condition
                 try {
                     solver.solve(f2, 3.0, 1.0);  // swapped min/max
                     fail("Expected IllegalArgumentException for non-bracketing condition");
                 } catch (IllegalArgumentException e) {
                     // Expected behavior
                     assertTrue(e.getMessage().contains("Function values at endpoints must have different signs"));
                 }
             }

    @Test
        public void testSolveWithMutatedParametersOrder() throws Exception {
            // Create a mock function that returns specific values
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(1.0)).thenReturn(2.0);   // yMin = 2.0
            when(f.value(1.5)).thenReturn(1.0);   // yInitial = 1.0
            when(f.value(2.0)).thenReturn(-1.0);  // yMax = -1.0
            
            // Create a spy to track the private solve method calls
            BrentSolver solver = spy(new BrentSolver(f));
            
            // Call the public solve method
            double result = solver.solve(1.0, 2.0, 1.5);
            
            // Get the private solve method via reflection
            Method privateSolve = BrentSolver.class.getDeclaredMethod(
                "solve", 
                UnivariateRealFunction.class, 
                double.class, 
                double.class, 
                double.class, 
                double.class, 
                double.class, 
                double.class
            );
            privateSolve.setAccessible(true);
            
            // Verify the private solve was called with correct parameter order
            // The expected call should be solve(f, min, yMin, max, yMax, initial, yInitial)
            verify(solver, times(1)).solve(eq(1.0), eq(2.0), eq(1.5));
            
            // Also verify the result is correct (though the mutation might not affect final result)
            assertEquals(1.5, result, 0.0001);
        }

    @Test
    public void testSolveWithCorrectBracketing() throws MaxIterationsExceededException, FunctionEvaluationException {
        // Create a simple quadratic function with root at x=2 (x^2 - 4)
        UnivariateRealFunction f = new UnivariateRealFunction() {
            @Override
            public double value(double x) {
                return x * x - 4;
            }
        };
        
        // Create solver instance
        BrentSolver solver = new BrentSolver(f);
        
        // Set up test case where min=1 (f(1)=-3) and max=3 (f(3)=5) bracket the root at 2
        double min = 1;
        double max = 3;
        double initial = 1.5; // initial guess
        
        // Expected root is 2
        double expectedRoot = 2.0;
        double tolerance = 1e-6;
        
        // Call the method
        double result = solver.solve(f, min, max, initial);
        
        // Verify the result is close to expected root
        assertEquals(expectedRoot, result, tolerance);
        
        // Also verify the function value at result is close to zero
        assertEquals(0.0, f.value(result), tolerance);
    }

    @Test
    public void testSolveWithSwappedBoundsShouldFail() throws FunctionEvaluationException, MaxIterationsExceededException {
        // Create a mock function that has different values at min and max
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        when(f.value(1.0)).thenReturn(-1.0);  // f(min) = -1
        when(f.value(4.0)).thenReturn(1.0);   // f(max) = 1
        when(f.value(2.5)).thenReturn(0.0);   // root at 2.5
        
        // Create solver instance
        BrentSolver solver = new BrentSolver(f);
        
        // Test the public solve method that calls the private method
        double result = solver.solve(1.0, 4.0, 2.0);
        
        // Verify the result is within original bounds (not swapped bounds)
        assertTrue("Result should be between min and max", 
            result >= 1.0 && result <= 4.0);
        
        // Additional verification that the function was evaluated correctly
        verify(f).value(1.0);  // min was evaluated
        verify(f).value(4.0);  // max was evaluated
    }

    @Test
    public void testSolveWithAsymmetricFunctionDetectsParameterSwapMutant() throws FunctionEvaluationException, MaxIterationsExceededException {
        // Create an asymmetric function mock (e.g., (x-2)(x-3) = x²-5x+6)
        // Root at x=2 and x=3, but behavior is different on either side
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        when(f.value(1.0)).thenReturn(2.0);   // f(1) = 2
        when(f.value(2.0)).thenReturn(0.0);   // f(2) = 0 (root)
        when(f.value(2.5)).thenReturn(-0.25); // f(2.5) = -0.25
        when(f.value(4.0)).thenReturn(2.0);   // f(4) = 2
        
        // Create solver with default accuracy settings
        BrentSolver solver = new BrentSolver(f);
        
        // Test interval [1,4] that brackets root at x=2
        // The mutated version would incorrectly pass [4,1] to internal solver
        double result = solver.solve(1.0, 4.0);
        
        // Verify the correct root was found (should be x=2)
        assertEquals(2.0, result, 1e-6);
        
        // Also verify the behavior is different if parameters were swapped
        // This assertion would fail if the mutant was present
        assertNotEquals(solver.solve(4.0, 1.0), result);
    }


}
