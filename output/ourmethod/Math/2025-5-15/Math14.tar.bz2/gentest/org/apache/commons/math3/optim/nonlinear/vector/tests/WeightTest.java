package gentest.org.apache.commons.math3.optim.nonlinear.vector.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optim.nonlinear.vector.*;
import org.apache.commons.math3.optim.OptimizationData;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.DiagonalMatrix;
import org.apache.commons.math3.linear.NonSquareMatrixException;
 
public class WeightTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testConstructor_ValidWeights() {
                double[] weights = {1.0, 2.0, 3.0};
                Weight weight = new Weight(weights);
                
                RealMatrix matrix = weight.getWeight();
                assertNotNull(matrix);
                assertTrue(matrix instanceof DiagonalMatrix);
                
                // Verify diagonal values
                assertEquals(1.0, matrix.getEntry(0, 0), 0.0001);
                assertEquals(2.0, matrix.getEntry(1, 1), 0.0001);
                assertEquals(3.0, matrix.getEntry(2, 2), 0.0001);
                
                // Verify non-diagonal values are 0
                assertEquals(0.0, matrix.getEntry(0, 1), 0.0001);
                assertEquals(0.0, matrix.getEntry(1, 2), 0.0001);
            }

    @Test
            public void testConstructor_SingleWeight() {
                double[] weights = {5.0};
                Weight weight = new Weight(weights);
                
                RealMatrix matrix = weight.getWeight();
                assertEquals(1, matrix.getRowDimension());
                assertEquals(1, matrix.getColumnDimension());
                assertEquals(5.0, matrix.getEntry(0, 0), 0.0001);
            }

    @Test
            public void testConstructor_EmptyArray() {
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("Weight array cannot be empty");
                new Weight(new double[0]);
            }

    @Test
            public void testConstructor_ZeroWeights() {
                double[] weights = {0.0, 0.0, 0.0};
                Weight weight = new Weight(weights);
                
                RealMatrix matrix = weight.getWeight();
                assertEquals(0.0, matrix.getEntry(0, 0), 0.0001);
                assertEquals(0.0, matrix.getEntry(1, 1), 0.0001);
                assertEquals(0.0, matrix.getEntry(2, 2), 0.0001);
            }

    @Test
            public void testConstructor_NegativeWeights() {
                double[] weights = {-1.0, -2.0, -3.0};
                Weight weight = new Weight(weights);
                
                RealMatrix matrix = weight.getWeight();
                assertEquals(-1.0, matrix.getEntry(0, 0), 0.0001);
                assertEquals(-2.0, matrix.getEntry(1, 1), 0.0001);
                assertEquals(-3.0, matrix.getEntry(2, 2), 0.0001);
            }

    @Test
            public void testGetWeight_ReturnsCorrectMatrix() {
                double[] weights = {1.5, 2.5};
                Weight weight = new Weight(weights);
                
                RealMatrix matrix = weight.getWeight();
                assertSame(matrix, weight.getWeight()); // Should return same instance
                assertEquals(1.5, matrix.getEntry(0, 0), 0.0001);
                assertEquals(2.5, matrix.getEntry(1, 1), 0.0001);
            }

    @Test
            public void testConstructor_ValidSquareMatrix() {
                // Arrange
                RealMatrix mockMatrix = mock(RealMatrix.class);
                when(mockMatrix.getColumnDimension()).thenReturn(3);
                when(mockMatrix.getRowDimension()).thenReturn(3);
                RealMatrix copiedMatrix = mock(RealMatrix.class);
                when(mockMatrix.copy()).thenReturn(copiedMatrix);
        
                // Act
                Weight weight = new Weight(mockMatrix);
        
                // Assert
                verify(mockMatrix).getColumnDimension();
                verify(mockMatrix).getRowDimension();
                verify(mockMatrix).copy();
                assertSame(copiedMatrix, weight.getWeight());
            }

    @Test
            public void testConstructor_NonSquareMatrix_ThrowsException() {
                // Arrange
                RealMatrix mockMatrix = mock(RealMatrix.class);
                when(mockMatrix.getColumnDimension()).thenReturn(3);
                when(mockMatrix.getRowDimension()).thenReturn(2);
                
                // Expect exception
                thrown.expect(NonSquareMatrixException.class);
                thrown.expectMessage("3 != 2");
        
                // Act
                new Weight(mockMatrix);
            }

    @Test
            public void testConstructor_MatrixCopyIsCalled() {
                // Arrange
                RealMatrix mockMatrix = mock(RealMatrix.class);
                when(mockMatrix.getColumnDimension()).thenReturn(2);
                when(mockMatrix.getRowDimension()).thenReturn(2);
                RealMatrix copiedMatrix = mock(RealMatrix.class);
                when(mockMatrix.copy()).thenReturn(copiedMatrix);
        
                // Act
                Weight weight = new Weight(mockMatrix);
        
                // Assert
                verify(mockMatrix).copy();
                assertSame(copiedMatrix, weight.getWeight());
            }

    @Test
    public void testConstructor_NullInput() {
        thrown.expect(NullPointerException.class);
        thrown.expectMessage("Weight array cannot be null");
        new Weight((double[]) null);
    }

    @Test
    public void testConstructor_NullMatrix_ThrowsNullPointerException() {
        // Expect exception
        thrown.expect(NullPointerException.class);
        
        // Act
        new Weight((RealMatrix) null);
    }


}
