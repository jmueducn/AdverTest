package gentest.org.apache.commons.math.optimization.fitting.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.fitting.*;
import java.util.Arrays;
import java.util.Comparator;
import org.apache.commons.math.analysis.function.Gaussian;
import org.apache.commons.math.analysis.ParametricUnivariateRealFunction;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NumberIsTooSmallException;
import org.apache.commons.math.exception.OutOfRangeException;
import org.apache.commons.math.exception.ZeroException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer;
import org.apache.commons.math.optimization.fitting.CurveFitter;
import org.apache.commons.math.optimization.fitting.WeightedObservedPoint;
 
public class GaussianFitterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                      public void testFitFunctionValue_SuccessfulCase() {
                                                                                                                                                          // Setup
                                                                                                                                                          DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                                                                                                                          GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                                                                          double[] initialGuess = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                          
                                                                                                                                                          // Get optimized parameters
                                                                                                                                                          double[] optimizedParams = fitter.fit(initialGuess);
                                                                                                                                                          
                                                                                                                                                          // Create the function separately
                                                                                                                                                          ParametricUnivariateRealFunction f = new Gaussian.Parametric();
                                                                                                                                                          double x = 5.0;
                                                                                                                                                          double[] params = new double[]{10.0, 2.0, 1.0}; // valid parameters
                                                                                                                                                          
                                                                                                                                                          // Should return normal Gaussian value
                                                                                                                                                          double result = f.value(x, params);
                                                                                                                                                          assertNotEquals(Double.POSITIVE_INFINITY, result, 0.0001);
                                                                                                                                                      }

    @Test
                                                                                                                                                      public void testFitFunctionValue_ExceptionCase() {
                                                                                                                                                          // Setup
                                                                                                                                                          DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                                                                                                                          GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                                                                          double[] initialGuess = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                          
                                                                                                                                                          // Test the anonymous function's value method with invalid parameters
                                                                                                                                                          ParametricUnivariateRealFunction f = new ParametricUnivariateRealFunction() {
                                                                                                                                                              private final ParametricUnivariateRealFunction g = new Gaussian.Parametric();
                                                                                                                                                              
                                                                                                                                                              public double value(double x, double[] p) {
                                                                                                                                                                  double v = Double.POSITIVE_INFINITY;
                                                                                                                                                                  try {
                                                                                                                                                                      v = g.value(x, p);
                                                                                                                                                                  } catch (NotStrictlyPositiveException e) {
                                                                                                                                                                      // Do nothing.
                                                                                                                                                                  }
                                                                                                                                                                  return v;
                                                                                                                                                              }
                                                                                                                                                              
                                                                                                                                                              public double[] gradient(double x, double[] p) {
                                                                                                                                                                  double[] v = { Double.POSITIVE_INFINITY,
                                                                                                                                                                                 Double.POSITIVE_INFINITY,
                                                                                                                                                                                 Double.POSITIVE_INFINITY };
                                                                                                                                                                  try {
                                                                                                                                                                      v = g.gradient(x, p);
                                                                                                                                                                  } catch (NotStrictlyPositiveException e) {
                                                                                                                                                                      // Do nothing.
                                                                                                                                                                  }
                                                                                                                                                                  return v;
                                                                                                                                                              }
                                                                                                                                                          };
                                                                                                                                                          
                                                                                                                                                          double x = 5.0;
                                                                                                                                                          double[] invalidParams = new double[]{10.0, -2.0, 1.0}; // negative sigma
                                                                                                                                                          
                                                                                                                                                          // Should return infinity when exception occurs
                                                                                                                                                          double result = f.value(x, invalidParams);
                                                                                                                                                          assertEquals(Double.POSITIVE_INFINITY, result, 0.0001);
                                                                                                                                                      }

    @Test
                                                                                                                                                      public void testFitFunctionGradient_ExceptionCase() {
                                                                                                                                                          // Setup
                                                                                                                                                          DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                                                                                                                          GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                                                                          double[] initialGuess = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                          
                                                                                                                                                          // Get the fitted parameters (this is what fit() actually returns)
                                                                                                                                                          double[] fittedParams = fitter.fit(initialGuess);
                                                                                                                                                          
                                                                                                                                                          // Test the anonymous function's gradient method with invalid parameters
                                                                                                                                                          // Create the function directly as it's defined in the tested method
                                                                                                                                                          ParametricUnivariateRealFunction f = new ParametricUnivariateRealFunction() {
                                                                                                                                                              private final ParametricUnivariateRealFunction g = new Gaussian.Parametric();
                                                                                                                                                              
                                                                                                                                                              public double value(double x, double[] p) {
                                                                                                                                                                  double v = Double.POSITIVE_INFINITY;
                                                                                                                                                                  try {
                                                                                                                                                                      v = g.value(x, p);
                                                                                                                                                                  } catch (NotStrictlyPositiveException e) {
                                                                                                                                                                      // Do nothing.
                                                                                                                                                                  }
                                                                                                                                                                  return v;
                                                                                                                                                              }
                                                                                                                                                              
                                                                                                                                                              public double[] gradient(double x, double[] p) {
                                                                                                                                                                  double[] v = { Double.POSITIVE_INFINITY,
                                                                                                                                                                                Double.POSITIVE_INFINITY,
                                                                                                                                                                                Double.POSITIVE_INFINITY };
                                                                                                                                                                  try {
                                                                                                                                                                      v = g.gradient(x, p);
                                                                                                                                                                  } catch (NotStrictlyPositiveException e) {
                                                                                                                                                                      // Do nothing.
                                                                                                                                                                  }
                                                                                                                                                                  return v;
                                                                                                                                                              }
                                                                                                                                                          };
                                                                                                                                                          
                                                                                                                                                          double x = 5.0;
                                                                                                                                                          double[] invalidParams = new double[]{10.0, -2.0, 1.0}; // negative sigma
                                                                                                                                                          
                                                                                                                                                          // Should return array of infinities when exception occurs
                                                                                                                                                          double[] gradient = f.gradient(x, invalidParams);
                                                                                                                                                          assertEquals(3, gradient.length);
                                                                                                                                                          for (double g : gradient) {
                                                                                                                                                              assertEquals(Double.POSITIVE_INFINITY, g, 0.0001);
                                                                                                                                                          }
                                                                                                                                                      }

    @Test
                                                                                                                                                      public void testFit_WithInvalidInitialGuessLength() {
                                                                                                                                                          // Setup
                                                                                                                                                          DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                                                                                                                          GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                                                                          
                                                                                                                                                          ExpectedException exception = ExpectedException.none();
                                                                                                                                                          exception.expect(IllegalArgumentException.class);
                                                                                                                                                          exception.expectMessage("Initial guess must contain 3 values");
                                                                                                                                                          
                                                                                                                                                          // Test with invalid initial guess length
                                                                                                                                                          fitter.fit(new double[]{1.0, 2.0}); // needs 3 parameters
                                                                                                                                                      }

    @Test
                                                                                                                                                  public void testFitFunctionGradient_SuccessfulCase() {
                                                                                                                                                      // Setup
                                                                                                                                                      DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                                                                                                                      GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                                                                      double[] initialGuess = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                      
                                                                                                                                                      // Create Gaussian function manually for testing
                                                                                                                                                      ParametricUnivariateRealFunction f = new ParametricUnivariateRealFunction() {
                                                                                                                                                          @Override
                                                                                                                                                          public double value(double x, double[] parameters) {
                                                                                                                                                              double a = parameters[0];
                                                                                                                                                              double b = parameters[1];
                                                                                                                                                              double c = parameters[2];
                                                                                                                                                              return a * Math.exp(-((x - b) * (x - b) / (2.0 * c * c)));
                                                                                                                                                          }
                                                                                                                                                  
                                                                                                                                                          @Override
                                                                                                                                                          public double[] gradient(double x, double[] parameters) {
                                                                                                                                                              double a = parameters[0];
                                                                                                                                                              double b = parameters[1];
                                                                                                                                                              double c = parameters[2];
                                                                                                                                                              double diff = x - b;
                                                                                                                                                              double z = Math.exp(-(diff * diff) / (2.0 * c * c));
                                                                                                                                                              return new double[] {
                                                                                                                                                                  z,
                                                                                                                                                                  a * z * diff / (c * c),
                                                                                                                                                                  a * z * diff * diff / (c * c * c)
                                                                                                                                                              };
                                                                                                                                                          }
                                                                                                                                                      };
                                                                                                                                                      
                                                                                                                                                      double x = 5.0;
                                                                                                                                                      double[] params = new double[]{10.0, 2.0, 1.0}; // valid parameters
                                                                                                                                                      
                                                                                                                                                      // Should return normal Gaussian gradient
                                                                                                                                                      double[] gradient = f.gradient(x, params);
                                                                                                                                                      assertEquals(3, gradient.length);
                                                                                                                                                      for (double g : gradient) {
                                                                                                                                                          assertNotEquals(Double.POSITIVE_INFINITY, g, 0.0001);
                                                                                                                                                      }
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testFit_WithValidObservations() {
                                                                                                                                                      // Setup
                                                                                                                                                      org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                                                                          new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                                                                      org.apache.commons.math.optimization.fitting.GaussianFitter fitter = 
                                                                                                                                                          new org.apache.commons.math.optimization.fitting.GaussianFitter(optimizer);
                                                                                                                                                      
                                                                                                                                                      // Add observations
                                                                                                                                                      fitter.addObservedPoint(1.0, 1.0, 1.0);
                                                                                                                                                      fitter.addObservedPoint(2.0, 2.0, 1.0);
                                                                                                                                                      fitter.addObservedPoint(3.0, 1.0, 1.0);
                                                                                                                                                      
                                                                                                                                                      // Execute
                                                                                                                                                      double[] result = fitter.fit();
                                                                                                                                                      
                                                                                                                                                      // Verify
                                                                                                                                                      org.junit.Assert.assertNotNull(result);
                                                                                                                                                      org.junit.Assert.assertEquals(3, result.length);
                                                                                                                                                      // We can't assert exact values since they depend on the optimization
                                                                                                                                                      // Just verify they are reasonable values
                                                                                                                                                      org.junit.Assert.assertTrue(result[0] > 0); // norm should be positive
                                                                                                                                                      org.junit.Assert.assertTrue(result[1] >= 1.0 && result[1] <= 3.0); // mean should be between min and max x
                                                                                                                                                      org.junit.Assert.assertTrue(result[2] > 0); // sigma should be positive
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testFit_WithEmptyObservations() {
                                                                                                                                                      // Setup
                                                                                                                                                      org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                                                                          new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                                                                      GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                                                                      
                                                                                                                                                      // Mock empty observations
                                                                                                                                                      org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] emptyObservations = 
                                                                                                                                                          new org.apache.commons.math.optimization.fitting.WeightedObservedPoint[0];
                                                                                                                                                      GaussianFitter spyFitter = spy(fitter);
                                                                                                                                                      when(spyFitter.getObservations()).thenReturn(emptyObservations);
                                                                                                                                                      
                                                                                                                                                      // Expect exception
                                                                                                                                                      thrown.expect(IllegalArgumentException.class);
                                                                                                                                                      thrown.expectMessage("No observations available");
                                                                                                                                                      
                                                                                                                                                      // Execute
                                                                                                                                                      spyFitter.fit();
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testFit_WhenOptimizationFails() {
                                                                                                                                                      // Setup
                                                                                                                                                      org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                                                                          new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                                                                      GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                                                                      
                                                                                                                                                      // Mock observations
                                                                                                                                                      org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] observations = {
                                                                                                                                                          new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                                                                          new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(2.0, 2.0, 1.0),
                                                                                                                                                          new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(3.0, 1.0, 1.0)
                                                                                                                                                      };
                                                                                                                                                      
                                                                                                                                                      GaussianFitter spyFitter = spy(fitter);
                                                                                                                                                      when(spyFitter.getObservations()).thenReturn(observations);
                                                                                                                                                      
                                                                                                                                                      // Mock ParameterGuesser
                                                                                                                                                      double[] mockGuess = {1.0, 2.0, 1.0};
                                                                                                                                                      org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser mockGuesser = 
                                                                                                                                                          mock(org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser.class);
                                                                                                                                                      when(mockGuesser.guess()).thenReturn(mockGuess);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to set the guesser since it's likely created internally
                                                                                                                                                      try {
                                                                                                                                                          Field guesserField = GaussianFitter.class.getDeclaredField("guesser");
                                                                                                                                                          guesserField.setAccessible(true);
                                                                                                                                                          guesserField.set(spyFitter, mockGuesser);
                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                          fail("Failed to set mock guesser via reflection");
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      // Mock fit to throw exception
                                                                                                                                                      when(spyFitter.fit(mockGuess)).thenThrow(new RuntimeException("Optimization failed"));
                                                                                                                                                      
                                                                                                                                                      // Expect exception
                                                                                                                                                      try {
                                                                                                                                                          spyFitter.fit();
                                                                                                                                                          fail("Expected RuntimeException");
                                                                                                                                                      } catch (RuntimeException e) {
                                                                                                                                                          assertEquals("Optimization failed", e.getMessage());
                                                                                                                                                      }
                                                                                                                                                  }

    @Test
                                                                                                                                              public void testFit_VerifyParameterGuesserCalled() {
                                                                                                                                                  // Setup
                                                                                                                                                  org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                                                                      new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                                                                  GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                                                                  
                                                                                                                                                  // Mock observations
                                                                                                                                                  WeightedObservedPoint[] observations = {
                                                                                                                                                      new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                                                                                      new WeightedObservedPoint(2.0, 2.0, 1.0)
                                                                                                                                                  };
                                                                                                                                                  
                                                                                                                                                  GaussianFitter spyFitter = spy(fitter);
                                                                                                                                                  
                                                                                                                                                  // Mock the internal behavior
                                                                                                                                                  doReturn(observations).when(spyFitter).getObservations();
                                                                                                                                                  
                                                                                                                                                  // Mock guess result
                                                                                                                                                  double[] mockGuess = {1.0, 1.5, 0.5};
                                                                                                                                                  doReturn(mockGuess).when(spyFitter).fit(any(double[].class));
                                                                                                                                                  
                                                                                                                                                  // Execute
                                                                                                                                                  double[] result = spyFitter.fit();
                                                                                                                                                  
                                                                                                                                                  // Verify that fit was called with some parameters (indirectly verifies guess was used)
                                                                                                                                                  verify(spyFitter).fit(any(double[].class));
                                                                                                                                                  
                                                                                                                                                  // Verify result
                                                                                                                                                  assertArrayEquals(mockGuess, result, 0.001);
                                                                                                                                              }

    @Test
                                                                                                                      public void testFit_WithNullInitialGuess() {
                                                                                                                          // Setup
                                                                                                                          org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer optimizer = 
                                                                                                                              new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                                          org.apache.commons.math.optimization.fitting.GaussianFitter fitter = 
                                                                                                                              new org.apache.commons.math.optimization.fitting.GaussianFitter(optimizer);
                                                                                                                          
                                                                                                                          try {
                                                                                                                              // Test with null initial guess
                                                                                                                              fitter.fit((double[])null);
                                                                                                                              org.junit.Assert.fail("Expected IllegalArgumentException");
                                                                                                                          } catch (IllegalArgumentException e) {
                                                                                                                              // Verify exception message
                                                                                                                              org.junit.Assert.assertEquals("Initial guess must not be null", e.getMessage());
                                                                                                                          }
                                                                                                                      }

    @Test
                                  public void testFit_WhenParameterGuesserFails() {
                                      // Setup
                                      org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                          new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                      org.apache.commons.math.optimization.fitting.GaussianFitter fitter = 
                                          new org.apache.commons.math.optimization.fitting.GaussianFitter(optimizer);
                                      
                                      // Mock observations with weight, x, y parameters
                                      org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] observations = {
                                          new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(1.0, 1.0, 1.0),
                                          new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(1.0, 2.0, 2.0)
                                      };
                                      
                                      // Create mock ParameterGuesser that throws exception
                                      org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser mockGuesser = 
                                          new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(
                                              new org.apache.commons.math.optimization.fitting.WeightedObservedPoint[0]) {
                                              @Override
                                              public double[] guess() {
                                                  throw new RuntimeException("Failed to guess parameters");
                                              }
                                          };
                                      
                                      // Use reflection to inject mock guesser
                                      try {
                                          java.lang.reflect.Field guesserField = org.apache.commons.math.optimization.fitting.GaussianFitter.class.getDeclaredField("guesser");
                                          guesserField.setAccessible(true);
                                          guesserField.set(fitter, mockGuesser);
                                      } catch (Exception e) {
                                          org.junit.Assert.fail("Failed to inject mock guesser via reflection");
                                      }
                                      
                                      // Add observations
                                      for (org.apache.commons.math.optimization.fitting.WeightedObservedPoint obs : observations) {
                                          fitter.addObservedPoint(obs);
                                      }
                                      
                                      // Expect exception
                                      try {
                                          fitter.fit();
                                          org.junit.Assert.fail("Expected OptimizationException");
                                      } catch (Exception e) {
                                          // Check if it's either OptimizationException or wrapped ConvergenceException
                                          if (e instanceof org.apache.commons.math.optimization.OptimizationException) {
                                              org.junit.Assert.assertTrue(e.getMessage().contains("Failed to guess parameters"));
                                          } else if (e instanceof org.apache.commons.math.ConvergenceException) {
                                              org.junit.Assert.assertTrue(e.getMessage().contains("Failed to guess parameters"));
                                          } else {
                                              org.junit.Assert.fail("Unexpected exception type: " + e.getClass().getName());
                                          }
                                      }
                                  }

    @Test
                                  public void testFitReturnsActualFittedParametersNotInitialGuess() {
                                      // Setup test data - simple Gaussian with known parameters
                                      double[] initialGuess = new double[]{1.0, 2.0, 3.0}; // arbitrary initial guess
                                      double[] expectedFit = new double[]{5.0, 2.5, 1.0}; // expected fitted parameters
                                      
                                      // Create mock optimizer that returns our expected fit
                                      DifferentiableMultivariateVectorialOptimizer mockOptimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                      GaussianFitter fitter = new GaussianFitter(mockOptimizer);
                                      
                                      // Setup some observed points that would produce our expected fit
                                      WeightedObservedPoint[] points = new WeightedObservedPoint[]{
                                          new WeightedObservedPoint(1.0, 1.0, 5.0),
                                          new WeightedObservedPoint(1.0, 2.0, 2.5),
                                          new WeightedObservedPoint(1.0, 3.0, 1.0)
                                      };
                                      
                                      // Add points to fitter
                                      for (WeightedObservedPoint point : points) {
                                          fitter.addObservedPoint(point);
                                      }
                                      
                                      // Perform the fit
                                      double[] result = fitter.fit(initialGuess);
                                      
                                      // Verify the result is different from initial guess
                                      assertNotEquals("Fit result should not equal initial guess", initialGuess[0], result[0], 0.0001);
                                      assertNotEquals("Fit result should not equal initial guess", initialGuess[1], result[1], 0.0001);
                                      assertNotEquals("Fit result should not equal initial guess", initialGuess[2], result[2], 0.0001);
                                      
                                      // Verify the result matches expected fit (within some tolerance)
                                      assertEquals("Fitted parameter 0 incorrect", expectedFit[0], result[0], 0.0001);
                                      assertEquals("Fitted parameter 1 incorrect", expectedFit[1], result[1], 0.0001);
                                      assertEquals("Fitted parameter 2 incorrect", expectedFit[2], result[2], 0.0001);
                                  }

    @Test
             public void testFitReturnsOptimizedParametersNotInitialGuess() {
                 // Setup
                 double[] initialGuess = new double[]{1.0, 2.0, 3.0};
                 double[] optimizedParams = new double[]{1.5, 2.5, 3.5};
                 
                 // Mock the dependencies
                 DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                 GaussianFitter fitter = spy(new GaussianFitter(optimizer));
                 
                 // Mock the fitter's behavior
                 doReturn(optimizedParams).when(fitter).fit(initialGuess);
                 
                 // Execute
                 double[] result = fitter.fit();
                 
                 // Verify
                 // This assertion will catch the mutant - if the method just returns guess,
                 // it will fail because we expect the optimized parameters
                 assertArrayEquals("Should return optimized parameters, not initial guess", 
                                 optimizedParams, result, 0.0001);
                 
                 // Additional verifications
                 verify(fitter).fit(initialGuess);  // Verify fit() was called with initial guess
             }

    @Test
             public void testFitDoesNotModifyOriginalGuessArray() throws Exception {
                 // Create test data
                 double[] initialGuess = new double[]{1.0, 2.0, 3.0};
                 double[] originalGuessCopy = initialGuess.clone();
                 
                 // Create a mock optimizer
                 DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                 
                 // Create the fitter
                 GaussianFitter fitter = new GaussianFitter(optimizer);
                 
                 // Call the fit method
                 double[] result = fitter.fit(initialGuess);
                 
                 // Verify the original guess array wasn't modified
                 assertArrayEquals("Original guess array should not be modified", 
                                  originalGuessCopy, initialGuess, 0.0001);
                 
                 // Additionally verify that if we modify the original array now,
                 // it doesn't affect any internal state (though this would be harder to test)
                 initialGuess[0] = 99.0;
                 // If the fitter stored the original array, this modification would affect it
                 // But we can't easily test that without exposing internal state
             }

    @Test
    public void testFitDoesNotModifyInputArray() {
        // Setup
        GaussianFitter fitter = new GaussianFitter(mock(DifferentiableMultivariateVectorialOptimizer.class));
        
        // Create sample data points for the guesser
        WeightedObservedPoint[] points = new WeightedObservedPoint[] {
            new WeightedObservedPoint(1.0, 1.0, 1.0),
            new WeightedObservedPoint(2.0, 2.0, 1.0),
            new WeightedObservedPoint(3.0, 3.0, 1.0)
        };
        
        // Create a real parameter guesser with the points
        GaussianFitter.ParameterGuesser guesser = new GaussianFitter.ParameterGuesser(points);
        
        // Mock the fit behavior - return a new array but also modify input
        double[] fitResult = new double[]{1.1, 2.1, 3.1};
        GaussianFitter spyFitter = spy(fitter);
        doAnswer(invocation -> {
            double[] input = (double[]) invocation.getArguments()[0];
            // Modify the input array to simulate mutation
            System.arraycopy(fitResult, 0, input, 0, input.length);
            return fitResult;
        }).when(spyFitter).fit(any(double[].class));
        
        // Execute
        double[] result = spyFitter.fit();
        
        // Verify
        // The original guess array should remain unchanged if clone was used
        // We can't verify the original guess array directly since we're not mocking the guesser,
        // but we can verify the fit was called with any array
        assertArrayEquals(fitResult, result, 0.0001);
        verify(spyFitter).fit(any(double[].class));
    }


}
