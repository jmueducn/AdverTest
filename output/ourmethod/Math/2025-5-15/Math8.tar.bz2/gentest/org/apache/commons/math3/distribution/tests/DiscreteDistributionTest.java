package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
import org.apache.commons.math3.util.MathArrays;
import org.apache.commons.math3.util.Pair;
 
public class DiscreteDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                             public void testSample_WithZeroProbabilityItems() {
                                                                 // Create mock RandomGenerator
                                                                 RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                 
                                                                 // Create sample list with zero probability items
                                                                 List<Pair<String, Double>> samples = new ArrayList<>();
                                                                 samples.add(new Pair<>("A", 0.0));
                                                                 samples.add(new Pair<>("B", 1.0));
                                                                 samples.add(new Pair<>("C", 0.0));
                                                                 
                                                                 // Create distribution with mock random
                                                                 DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                 
                                                                 // Should always return B regardless of random value
                                                                 when(mockRandom.nextDouble()).thenReturn(0.0);
                                                                 assertEquals("B", distribution.sample());
                                                                 
                                                                 when(mockRandom.nextDouble()).thenReturn(0.999);
                                                                 assertEquals("B", distribution.sample());
                                                             }

 @Test
                                                             public void testSample_NegativeSize_ThrowsException() {
                                                                 // Setup
                                                                 ExpectedException thrown = ExpectedException.none();
                                                                 List<Pair<Object, Double>> samples = new ArrayList<>();
                                                                 samples.add(new Pair<>("test", 1.0));
                                                                 DiscreteDistribution<Object> distribution = new DiscreteDistribution<>(samples);
                                                                 
                                                                 // Expect exception
                                                                 thrown.expect(NotStrictlyPositiveException.class);
                                                                 thrown.expectMessage("number of samples (-1)");
                                                                 
                                                                 // Test
                                                                 distribution.sample(-1);
                                                             }

 @Test
                                                             public void testSample_ZeroSize_ThrowsException() {
                                                                 // Setup
                                                                 ExpectedException thrown = ExpectedException.none();
                                                                 List<Pair<Object, Double>> samples = new ArrayList<>();
                                                                 samples.add(new Pair<>(new Object(), 1.0));
                                                                 DiscreteDistribution<Object> distribution = new DiscreteDistribution<>(samples);
                                                                 
                                                                 // Expect exception
                                                                 thrown.expect(NotStrictlyPositiveException.class);
                                                                 thrown.expectMessage("number of samples (0)");
                                                                 
                                                                 // Test
                                                                 distribution.sample(0);
                                                             }

 @Test
                                                             public void testSample_PositiveSize_ReturnsCorrectArraySize() {
                                                                 // Create mock RandomGenerator
                                                                 RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                 when(mockRandom.nextDouble()).thenReturn(0.1, 0.4, 0.8);
                                                                 
                                                                 // Create sample data for distribution
                                                                 List<Pair<String, Double>> samples = new ArrayList<>();
                                                                 samples.add(new Pair<>("A", 0.5));
                                                                 samples.add(new Pair<>("B", 0.3));
                                                                 samples.add(new Pair<>("C", 0.2));
                                                                 
                                                                 // Create distribution with mock random generator
                                                                 DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                 
                                                                 // Test the sample method
                                                                 Object[] result = distribution.sample(3);
                                                                 assertEquals(3, result.length);
                                                             }

 @Test
                                                             public void testSample_ContentsBasedOnProbability() {
                                                                 // Create mock RandomGenerator
                                                                 RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                 
                                                                 // Setup sample data with probabilities
                                                                 List<Pair<String, Double>> samples = new ArrayList<>();
                                                                 samples.add(new Pair<>("A", 0.3));
                                                                 samples.add(new Pair<>("B", 0.5));
                                                                 samples.add(new Pair<>("C", 0.2));
                                                                 
                                                                 // Create distribution with mock random generator
                                                                 DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                 
                                                                 // Mock random values to select specific samples
                                                                 // 0.1 < 0.3 -> select "A"
                                                                 // 0.4 between 0.3-0.8 -> select "B"
                                                                 // 0.9 > 0.8 -> select "C"
                                                                 when(mockRandom.nextDouble()).thenReturn(0.1, 0.4, 0.9);
                                                                 
                                                                 Object[] result = distribution.sample(3);
                                                                 assertArrayEquals(new Object[]{"A", "B", "C"}, result);
                                                             }

 @Test
                                                             public void testSample_SingleElement_ReturnsSingleElementArray() {
                                                                 // Create mock RandomGenerator
                                                                 RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                 when(mockRandom.nextDouble()).thenReturn(0.25);
                                                                 
                                                                 // Create sample data
                                                                 List<Pair<String, Double>> samples = new ArrayList<>();
                                                                 samples.add(new Pair<>("A", 0.3));
                                                                 samples.add(new Pair<>("B", 0.7));
                                                                 
                                                                 // Create distribution with mock random
                                                                 DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                 
                                                                 // Test sampling
                                                                 Object[] result = distribution.sample(1);
                                                                 assertEquals(1, result.length);
                                                                 assertEquals("A", result[0]); // 0.25 < 0.3 selects "A"
                                                             }

 @Test
                                                             public void testSample_CallsSampleMethodCorrectNumberOfTimes() {
                                                                 // Create mock RandomGenerator
                                                                 RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                 when(mockRandom.nextDouble()).thenReturn(0.1, 0.4, 0.8);
                                                                 
                                                                 // Create test samples
                                                                 List<Pair<String, Double>> samples = new ArrayList<>();
                                                                 samples.add(new Pair<>("A", 0.5));
                                                                 samples.add(new Pair<>("B", 0.5));
                                                                 
                                                                 // Create distribution with mock random generator
                                                                 DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                 
                                                                 // Test the sample method
                                                                 distribution.sample(3);
                                                                 
                                                                 // Verify nextDouble was called exactly 3 times
                                                                 verify(mockRandom, times(3)).nextDouble();
                                                             }

 @Test
                                                             public void testSample_LargeSampleSize_HandlesCorrectly() {
                                                                 // Create mock RandomGenerator
                                                                 RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                 when(mockRandom.nextDouble()).thenReturn(0.5); // Always return B
                                                                 
                                                                 // Create test samples (assuming B has probability > 0.5)
                                                                 List<Pair<String, Double>> samples = new ArrayList<>();
                                                                 samples.add(new Pair<>("A", 0.4));
                                                                 samples.add(new Pair<>("B", 0.6));
                                                                 
                                                                 // Create distribution with mock random generator
                                                                 DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                 
                                                                 // Test with a large sample size to ensure no performance issues
                                                                 Object[] result = distribution.sample(1000);
                                                                 assertEquals(1000, result.length);
                                                                 for (Object item : result) {
                                                                     assertEquals("B", item);
                                                                 }
                                                             }

 @Test
                                             public void testSample_SingleItem() {
                                                 java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = 
                                                     java.util.Arrays.asList(
                                                         new org.apache.commons.math3.util.Pair<>("A", 1.0)
                                                     );
                                                 org.apache.commons.math3.distribution.DiscreteDistribution<String> distribution = 
                                                     new org.apache.commons.math3.distribution.DiscreteDistribution<>(samples);
                                                 
                                                 // Should always return "A" regardless of random value
                                                 assertEquals("A", distribution.sample());
                                             }

 @Test
                                             public void testSample_WithCustomRandomGenerator() {
                                                 java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = java.util.Arrays.asList(
                                                     new org.apache.commons.math3.util.Pair<>("A", 0.5),
                                                     new org.apache.commons.math3.util.Pair<>("B", 0.5)
                                                 );
                                                 
                                                 // Declare distribution variable
                                                 org.apache.commons.math3.distribution.DiscreteDistribution<String> distribution = 
                                                     new org.apache.commons.math3.distribution.DiscreteDistribution<>(
                                                         new org.apache.commons.math3.random.Well19937c(12345L), samples);
                                                 
                                                 // With seed 12345, we know the first few values will be:
                                                 // 1st call: 0.722009654
                                                 // 2nd call: 0.208460157
                                                 assertEquals("B", distribution.sample()); // 0.722 > 0.5
                                                 assertEquals("A", distribution.sample()); // 0.208 < 0.5
                                             }

 @Test
                     public void testSample_EdgeCaseFloatingPointPrecision() {
                         // Import necessary classes inline since we're only showing the method
                         org.apache.commons.math3.random.RandomGenerator mockRandom = 
                             new org.apache.commons.math3.random.JDKRandomGenerator();
                         
                         // Create samples
                         java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = java.util.Arrays.asList(
                             new org.apache.commons.math3.util.Pair<>("A", 0.1),
                             new org.apache.commons.math3.util.Pair<>("B", 0.1),
                             new org.apache.commons.math3.util.Pair<>("C", 0.1),
                             new org.apache.commons.math3.util.Pair<>("D", 0.1),
                             new org.apache.commons.math3.util.Pair<>("E", 0.1),
                             new org.apache.commons.math3.util.Pair<>("F", 0.1),
                             new org.apache.commons.math3.util.Pair<>("G", 0.1),
                             new org.apache.commons.math3.util.Pair<>("H", 0.1),
                             new org.apache.commons.math3.util.Pair<>("I", 0.1),
                             new org.apache.commons.math3.util.Pair<>("J", 0.1)
                         );
                         
                         // Create distribution with proper generic type
                         org.apache.commons.math3.distribution.DiscreteDistribution<String> distribution = 
                             new org.apache.commons.math3.distribution.DiscreteDistribution<String>(mockRandom, samples);
                         
                         // Test case where floating point sum might be slightly less than 1.0
                         org.junit.Assert.assertEquals("J", distribution.sample());
                     }

 @Test
                 public void testSample_MultipleItems() {
                     // Mock setup
                     RandomGenerator mockRandom = mock(RandomGenerator.class);
                     DiscreteDistribution<String> distribution;
                     
                     // Test data setup
                     java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = java.util.Arrays.asList(
                         new org.apache.commons.math3.util.Pair<>("A", 0.3),
                         new org.apache.commons.math3.util.Pair<>("B", 0.3),
                         new org.apache.commons.math3.util.Pair<>("C", 0.4)
                     );
                     distribution = new DiscreteDistribution<>(mockRandom, samples);
                     
                     // Test first item selection
                     when(mockRandom.nextDouble()).thenReturn(0.0);
                     assertEquals("A", distribution.sample());
                     
                     // Test boundary between first and second item
                     when(mockRandom.nextDouble()).thenReturn(0.2999);
                     assertEquals("A", distribution.sample());
                     when(mockRandom.nextDouble()).thenReturn(0.3);
                     assertEquals("B", distribution.sample());
                     
                     // Test boundary between second and third item
                     when(mockRandom.nextDouble()).thenReturn(0.5999);
                     assertEquals("B", distribution.sample());
                     when(mockRandom.nextDouble()).thenReturn(0.6);
                     assertEquals("C", distribution.sample());
                     
                     // Test edge case near 1.0
                     when(mockRandom.nextDouble()).thenReturn(0.9999);
                     assertEquals("C", distribution.sample());
                 }

 @Test
             public void testSampleReturnsLastSingletonWhenRandomValueIsCloseToOne() {
                 // Setup test data
                 List<Pair<String, Double>> samples = new ArrayList<>();
                 samples.add(new Pair<>("A", 0.5));
                 samples.add(new Pair<>("B", 0.5));
                 
                 // Mock RandomGenerator to return 1.0
                 RandomGenerator mockRandom = mock(RandomGenerator.class);
                 when(mockRandom.nextDouble()).thenReturn(1.0);
                 
                 // Create DiscreteDistribution with mocked random
                 DiscreteDistribution<String> distribution = 
                     new DiscreteDistribution<>(mockRandom, samples);
                 
                 // Call sample() - should return last singleton ("B")
                 String result = distribution.sample();
                 
                 // Verify it returns the last singleton instead of null
                 assertNotNull("Method should not return null", result);
                 assertEquals("B", result);
                 
                 // Alternative test with random value just below 1.0
                 when(mockRandom.nextDouble()).thenReturn(0.9999999999999999);
                 result = distribution.sample();
                 assertNotNull("Method should not return null for values very close to 1.0", result);
                 assertEquals("B", result);
             }

 @Test
             public void testSampleIntDetectsNullReturnMutant() {
                 // Setup test data
                 List<Pair<String, Double>> samples = new ArrayList<>();
                 samples.add(new Pair<>("sample1", 0.5));
                 samples.add(new Pair<>("sample2", 0.5));
                 
                 // Create distribution instance
                 DiscreteDistribution<String> distribution = new DiscreteDistribution<>(samples);
                 
                 // Call method under test
                 int sampleSize = 10;
                 Object[] result = distribution.sample(sampleSize);
                 
                 // Verify results
                 assertEquals(sampleSize, result.length);
                 for (Object sample : result) {
                     assertNotNull("Sample should not be null - mutant detected", sample);
                 }
                 
                 // Additional verification that we got valid samples
                 for (Object sample : result) {
                     assertTrue(samples.stream().anyMatch(p -> p.getKey().equals(sample)));
                 }
             }

 @Test
            public void testSampleIntDetectsMiddleElementMutant() {
                // Setup test data with distinct values
                List<Pair<String, Double>> samples = new ArrayList<>();
                samples.add(new Pair<>("A", 1.0));
                samples.add(new Pair<>("B", 1.0));
                samples.add(new Pair<>("C", 1.0)); // Three distinct values
                
                // Create discrete distribution
                DiscreteDistribution<String> dist = new DiscreteDistribution<>(samples);
                
                // Call sample(int) with size 3
                Object[] result = dist.sample(3);
                
                // Verify we got 3 samples
                assertEquals(3, result.length);
                
                // The mutant would return the middle element (B) instead of last element (C)
                // So we check if any element is C (which the mutant wouldn't produce)
                boolean containsC = false;
                for (Object o : result) {
                    if ("C".equals(o)) {
                        containsC = true;
                        break;
                    }
                }
                assertTrue("Sample should contain last element C", containsC);
                
                // Also verify distribution contains all possible values
                // (Original would eventually produce all, mutant would never produce last)
                boolean containsA = false;
                boolean containsB = false;
                containsC = false;
                for (Object o : result) {
                    if ("A".equals(o)) containsA = true;
                    if ("B".equals(o)) containsB = true;
                    if ("C".equals(o)) containsC = true;
                }
                assertTrue("Sample should contain A", containsA);
                assertTrue("Sample should contain B", containsB);
                assertTrue("Sample should contain C", containsC);
            }

 @Test
           public void testFallbackReturnWhenRandomValueExceedsSum() {
               // Setup test data
               List<Pair<String, Double>> samples = new ArrayList<>();
               samples.add(new Pair<>("A", 0.3));
               samples.add(new Pair<>("B", 0.3));
               samples.add(new Pair<>("C", 0.3)); // Sum is 0.9 (less than 1.0)
               
               // Mock RandomGenerator to return 1.0 (forcing fallback case)
               RandomGenerator mockRandom = mock(RandomGenerator.class);
               when(mockRandom.nextDouble()).thenReturn(1.0);
               
               // Create instance with our mock and test data
               DiscreteDistribution<String> dist = new DiscreteDistribution<>(mockRandom, samples);
               
               // Test - original would return last element "C", mutant would return middle "B"
               String result = dist.sample();
               
               // Assert we get the last element (original behavior)
               assertEquals("C", result);
               
               // Additional check to ensure we're testing the fallback case
               // Calculate sum from input samples instead of accessing private field
               double sum = samples.stream().mapToDouble(Pair::getValue).sum();
               assertTrue(1.0 > sum); // Verify sum is less than 1.0
           }

 @Test
       public void testSampleWithRandomValueGreaterThanSum() {
           // Setup test data
           List<Pair<String, Double>> samples = new ArrayList<>();
           samples.add(new Pair<>("A", 0.3));
           samples.add(new Pair<>("B", 0.3));
           samples.add(new Pair<>("C", 0.4)); // Last element
           
           // Mock RandomGenerator to return 1.0 (greater than sum of probabilities)
           RandomGenerator mockRandom = mock(RandomGenerator.class);
           when(mockRandom.nextDouble()).thenReturn(1.0);
           
           // Create DiscreteDistribution with our mock random
           DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
           
           // The original method should return the last element ("C")
           // The mutant would return the second-to-last element ("B")
           String result = distribution.sample();
           
           // Assert that we get the last element
           assertEquals("C", result);
           
           // Additional verification that we're testing the right path
           verify(mockRandom).nextDouble();
       }

 @Test
       public void testSampleSizeDetectsMutant() {
           // Setup test data with at least 2 singletons
           List<Pair<String, Double>> samples = new ArrayList<>();
           samples.add(new Pair<>("first", 0.3));
           samples.add(new Pair<>("second", 0.7));
           
           // Mock RandomGenerator to always return 1.0 (which should pick last element)
           RandomGenerator mockRandom = mock(RandomGenerator.class);
           when(mockRandom.nextDouble()).thenReturn(1.0);
           
           // Create DiscreteDistribution with our test data
           DiscreteDistribution<String> dist = new DiscreteDistribution<>(mockRandom, samples);
           
           // Call the method under test
           int sampleSize = 5;
           Object[] result = dist.sample(sampleSize);
           
           // Verify the results - should all be "second" (last element)
           // If mutant is present, they would be "first" (second last element)
           assertEquals(sampleSize, result.length);
           for (Object sample : result) {
               assertEquals("second", sample);
           }
       }

 @Test
      public void testSampleWithFloatingPointPrecisionIssue() {
          // Setup test data with probabilities that might have floating point precision issues
          List<Pair<String, Double>> samples = new ArrayList<>();
          samples.add(new Pair<>("A", 0.1));
          samples.add(new Pair<>("B", 0.2));
          samples.add(new Pair<>("C", 0.3));
          samples.add(new Pair<>("D", 0.4)); // Sum is 1.0 in theory, but could be slightly less in practice
          
          // Mock the random generator to return a value greater than the sum of probabilities
          RandomGenerator mockRandom = mock(RandomGenerator.class);
          when(mockRandom.nextDouble()).thenReturn(0.9999999999); // Just below 1.0
          
          // Create the distribution with our mock random
          DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
          
          // The original code should return the last element ("D") as fallback
          // The mutant would return the first element ("A")
          assertEquals("D", distribution.sample());
      }

 @Test
     public void testSampleIntShouldReturnCorrectElements() {
         // Setup test data with multiple singletons
         java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = new java.util.ArrayList<>();
         samples.add(new org.apache.commons.math3.util.Pair<>("first", 0.3));
         samples.add(new org.apache.commons.math3.util.Pair<>("middle", 0.3));
         samples.add(new org.apache.commons.math3.util.Pair<>("last", 0.4));
         
         // Create DiscreteDistribution instance
         org.apache.commons.math3.distribution.DiscreteDistribution<String> dist = 
             new org.apache.commons.math3.distribution.DiscreteDistribution<>(samples);
         
         // Call the method under test
         Object[] result = dist.sample(100); // Large enough to likely get all elements
         
         // Verify we get all possible elements (would fail if mutant only returns first element)
         java.util.Set<Object> uniqueSamples = new java.util.HashSet<>(java.util.Arrays.asList(result));
         assertEquals(3, uniqueSamples.size());
         assertTrue(uniqueSamples.contains("first"));
         assertTrue(uniqueSamples.contains("middle"));
         assertTrue(uniqueSamples.contains("last"));
         
         // More specific test - verify we get the last element sometimes
         // (would always fail with mutant that only returns first element)
         boolean foundLast = false;
         for (Object sample : result) {
             if (sample.equals("last")) {
                 foundLast = true;
                 break;
             }
         }
         assertTrue("Should contain last element", foundLast);
     }

 @Test
 public void testSampleFallbackBehavior() {
     // Setup test data with probabilities that might have floating-point precision issues
     List<Pair<String, Double>> samples = new ArrayList<>();
     samples.add(new Pair<>("A", 0.1));
     samples.add(new Pair<>("B", 0.1));
     samples.add(new Pair<>("C", 0.1));
     samples.add(new Pair<>("D", 0.1));
     samples.add(new Pair<>("E", 0.1));
     samples.add(new Pair<>("F", 0.1));
     samples.add(new Pair<>("G", 0.1));
     samples.add(new Pair<>("H", 0.1));
     samples.add(new Pair<>("I", 0.1));
     samples.add(new Pair<>("J", 0.1)); // Sum should be 1.0 but might have precision issues
     
     // Mock random generator to return value very close to 1
     RandomGenerator mockRandom = mock(RandomGenerator.class);
     when(mockRandom.nextDouble()).thenReturn(0.9999999999999999);
     
     // Create DiscreteDistribution instance
     DiscreteDistribution<String> dist = new DiscreteDistribution<>(mockRandom, samples);
     
     // Test the behavior - should return last element without throwing exception
     String result = dist.sample();
     assertEquals("J", result); // Original would return "J", mutant would throw IndexOutOfBoundsException
 }

 @Test(expected = IndexOutOfBoundsException.class)
 public void testSampleMethodDetectsMutant() {
     // Setup test data
     List<Pair<String, Double>> samples = new ArrayList<>();
     samples.add(new Pair<>("A", 0.5));
     samples.add(new Pair<>("B", 0.5));
     
     // Create DiscreteDistribution with mock RandomGenerator
     RandomGenerator mockRandom = mock(RandomGenerator.class);
     // Make random.nextDouble() return value that would select last element
     when(mockRandom.nextDouble()).thenReturn(0.6);
     
     DiscreteDistribution<String> dist = new DiscreteDistribution<>(mockRandom, samples);
     
     // This should throw IndexOutOfBoundsException if mutant is present
     // because it tries to get(singletons.size()) instead of get(singletons.size()-1)
     dist.sample();
     
     // If no exception is thrown, the test will fail
     // If IndexOutOfBoundsException is thrown, the test passes (detects mutant)
 }

}
