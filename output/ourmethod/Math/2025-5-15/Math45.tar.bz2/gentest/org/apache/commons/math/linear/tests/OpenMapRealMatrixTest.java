package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import org.apache.commons.math.exception.NumberIsTooLargeException;
import org.apache.commons.math.util.OpenIntToDoubleHashMap;
 
public class OpenMapRealMatrixTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                      public void testConstructor_ValidDimensions() {
                          // Test normal valid dimensions
                          OpenMapRealMatrix matrix1 = new OpenMapRealMatrix(10, 20);
                          assertEquals(10, matrix1.getRowDimension());
                          assertEquals(20, matrix1.getColumnDimension());
                  
                          // Test minimum valid dimensions
                          OpenMapRealMatrix matrix2 = new OpenMapRealMatrix(1, 1);
                          assertEquals(1, matrix2.getRowDimension());
                          assertEquals(1, matrix2.getColumnDimension());
                  
                          // Test large but valid dimensions (product just below Integer.MAX_VALUE)
                          int maxDim = (int)Math.sqrt(Integer.MAX_VALUE) - 1;
                          OpenMapRealMatrix matrix3 = new OpenMapRealMatrix(maxDim, maxDim);
                          assertEquals(maxDim, matrix3.getRowDimension());
                          assertEquals(maxDim, matrix3.getColumnDimension());
                      }

 @Test
                      public void testConstructor_ZeroDimension() {
                          // Test zero rows
                          thrown.expect(IllegalArgumentException.class);
                          new OpenMapRealMatrix(0, 5);
                  
                          // Test zero columns
                          thrown.expect(IllegalArgumentException.class);
                          new OpenMapRealMatrix(5, 0);
                  
                          // Test both zero
                          thrown.expect(IllegalArgumentException.class);
                          new OpenMapRealMatrix(0, 0);
                      }

 @Test
                      public void testConstructor_NegativeDimension() {
                          // Test negative rows
                          thrown.expect(IllegalArgumentException.class);
                          new OpenMapRealMatrix(-1, 5);
                  
                          // Test negative columns
                          thrown.expect(IllegalArgumentException.class);
                          new OpenMapRealMatrix(5, -1);
                  
                          // Test both negative
                          thrown.expect(IllegalArgumentException.class);
                          new OpenMapRealMatrix(-1, -1);
                      }

 @Test
                      public void testConstructor_DimensionsExceedingMaxValue() {
                          // Test when product of dimensions equals MAX_VALUE
                          thrown.expect(NumberIsTooLargeException.class);
                          new OpenMapRealMatrix(Integer.MAX_VALUE, 1);
                  
                          // Test when product exceeds MAX_VALUE
                          thrown.expect(NumberIsTooLargeException.class);
                          new OpenMapRealMatrix(Integer.MAX_VALUE / 2 + 1, 2);
                  
                          // Test with very large dimensions
                          thrown.expect(NumberIsTooLargeException.class);
                          new OpenMapRealMatrix(Integer.MAX_VALUE, Integer.MAX_VALUE);
                      }

 @Test
                      public void testConstructor_InitializesEmptyEntries() {
                          OpenMapRealMatrix matrix = new OpenMapRealMatrix(5, 5);
                          
                          // Verify all entries are initialized to 0.0
                          for (int i = 0; i < 5; i++) {
                              for (int j = 0; j < 5; j++) {
                                  assertEquals(0.0, matrix.getEntry(i, j), 0.0);
                              }
                          }
                      }

 @Test
                      public void testConstructor_CopyMatrixWithEmptyEntries() {
                          // Setup
                          OpenMapRealMatrix original = new OpenMapRealMatrix(3, 4);
                          
                          // Exercise
                          OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                          
                          // Verify
                          assertEquals(original.getRowDimension(), copy.getRowDimension());
                          assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                          assertEquals(0.0, copy.getEntry(0, 0), 0.0);
                          assertEquals(0.0, copy.getEntry(2, 3), 0.0);
                      }

 @Test
                      public void testConstructor_CopyMatrixWithNonEmptyEntries() {
                          // Setup
                          OpenMapRealMatrix original = new OpenMapRealMatrix(2, 2);
                          original.setEntry(0, 0, 1.5);
                          original.setEntry(1, 1, -2.3);
                          
                          // Exercise
                          OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                          
                          // Verify
                          assertEquals(original.getRowDimension(), copy.getRowDimension());
                          assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                          assertEquals(1.5, copy.getEntry(0, 0), 0.0);
                          assertEquals(0.0, copy.getEntry(0, 1), 0.0);
                          assertEquals(0.0, copy.getEntry(1, 0), 0.0);
                          assertEquals(-2.3, copy.getEntry(1, 1), 0.0);
                      }

 @Test
                      public void testConstructor_CopyIsDeepCopy() {
                          // Setup
                          OpenMapRealMatrix original = new OpenMapRealMatrix(2, 2);
                          original.setEntry(0, 0, 5.0);
                          
                          // Exercise
                          OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                          original.setEntry(0, 0, 10.0); // Modify original after copy
                          
                          // Verify
                          assertEquals(5.0, copy.getEntry(0, 0), 0.0); // Copy should not change
                          assertEquals(10.0, original.getEntry(0, 0), 0.0);
                      }

 @Test
                      public void testConstructor_NullInput() {
                          // Setup exception expectation
                          thrown.expect(NullPointerException.class);
                          thrown.expectMessage("matrix must not be null");
                          
                          // Exercise
                          new OpenMapRealMatrix(null);
                      }

 @Test
                      public void testConstructor_CopySparseMatrix() {
                          // Setup
                          OpenMapRealMatrix original = new OpenMapRealMatrix(100, 100);
                          original.setEntry(99, 99, 99.99); // Only set one entry
                          
                          // Exercise
                          OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                          
                          // Verify
                          assertEquals(100, copy.getRowDimension());
                          assertEquals(100, copy.getColumnDimension());
                          assertEquals(99.99, copy.getEntry(99, 99), 0.0);
                          assertEquals(0.0, copy.getEntry(0, 0), 0.0);
                          assertEquals(0.0, copy.getEntry(50, 50), 0.0);
                      }

 @Test
              public void testConstructor_VerifyEntriesMapIsCopiedNotShared() throws Exception {
                  // Setup
                  OpenMapRealMatrix original = new OpenMapRealMatrix(3, 3);
                  original.setEntry(0, 0, 1.0); // Add an entry to ensure map is not empty
                  
                  // Exercise
                  OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                  
                  // Verify entries are the same but maps are different instances
                  Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                  entriesField.setAccessible(true);
                  
                  OpenIntToDoubleHashMap originalEntries = (OpenIntToDoubleHashMap) entriesField.get(original);
                  OpenIntToDoubleHashMap copyEntries = (OpenIntToDoubleHashMap) entriesField.get(copy);
                  
                  assertNotSame(originalEntries, copyEntries);
                  assertEquals(originalEntries.get(0), copyEntries.get(0), 0.0); // Verify same content
                  
                  // Modify original and verify copy is not affected
                  original.setEntry(0, 0, 2.0);
                  assertEquals(1.0, copyEntries.get(0), 0.0);
              }

 @Test
             public void testConstructorWithLargeDimensions() {
                 // These values are chosen so that:
                 // - As integers: 46342 * 46342 = Integer.MAX_VALUE + 1 (overflow)
                 // - As longs: 46342L * 46342L = 2147488276 (valid)
                 int largeDim = 46342;
                 
                 // Original behavior should throw exception because 46342*46342 >= Integer.MAX_VALUE
                 thrown.expect(NumberIsTooLargeException.class);
                 thrown.expectMessage("2147488276");
                 
                 // This will fail with the mutant because:
                 // - Mutant does integer multiplication: 46342*46342 = -2147479015 (overflow)
                 // - Comparison: -2147479015 >= Integer.MAX_VALUE is false
                 // - No exception thrown
                 new OpenMapRealMatrix(largeDim, largeDim);
             }

 @Test(expected = NumberIsTooLargeException.class)
         public void testConstructorWithLargeDimensions1() {
             // These dimensions are chosen so their product would overflow if not properly cast to long
             int largeRow = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
             int largeCol = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
             
             // This should throw NumberIsTooLargeException because lRow * lCol exceeds Integer.MAX_VALUE
             new OpenMapRealMatrix(largeRow, largeCol);
         }

 @Test
         public void testConstructorWithValidLargeDimensions() {
             // These dimensions are large but their product doesn't overflow
             int validLargeRow = (int) Math.sqrt(Integer.MAX_VALUE) - 1;
             int validLargeCol = (int) Math.sqrt(Integer.MAX_VALUE) - 1;
             
             // This should succeed
             OpenMapRealMatrix matrix = new OpenMapRealMatrix(validLargeRow, validLargeCol);
             assertEquals(validLargeRow, matrix.getRowDimension());
             assertEquals(validLargeCol, matrix.getColumnDimension());
         }

 @Test
            public void testConstructorSizeValidationWithDifferentDimensions() {
                // This test will catch the mutant because:
                // Original behavior: 50000 * 40000 = 2,000,000,000 (should pass)
                // Mutated behavior: 40000 * 40000 = 1,600,000,000 (would incorrectly pass)
                // Test passes for original, fails for mutant
                new OpenMapRealMatrix(50000, 40000);
            }

 @Test
            public void testConstructorThrowsWhenSizeExceedsMaxValue() {
                // This test ensures the size validation works
                // Original behavior: 50000 * 50000 = 2,500,000,000 > MAX_VALUE (should throw)
                // Mutated behavior: would also throw in this case
                thrown.expect(NumberIsTooLargeException.class);
                new OpenMapRealMatrix(50000, 50000);
            }

 @Test
            public void testConstructorWithDifferentDimensionsWhereMutantWouldFail() {
                // This test specifically targets the mutant
                // Original behavior: 46341 * 46340 = 2,147,441,940 (should throw)
                // Mutated behavior: 46340 * 46340 = 2,147,395,600 (would not throw)
                thrown.expect(NumberIsTooLargeException.class);
                new OpenMapRealMatrix(46341, 46340);
            }

 @Test
            public void testConstructorWithDifferentDimensions() {
                // Create a matrix with different row and column dimensions
                // where row*column is safe but column*column would overflow
                int safeRows = (int)Math.sqrt(Integer.MAX_VALUE) - 1;
                int safeCols = safeRows + 10000; // Make columns larger than rows
                
                // This should pass with original code but fail with mutant
                OpenMapRealMatrix matrix = new OpenMapRealMatrix(safeRows, safeCols);
                assertNotNull(matrix);
                assertEquals(safeRows, matrix.getRowDimension());
                assertEquals(safeCols, matrix.getColumnDimension());
            }

 @Test(expected = NumberIsTooLargeException.class)
            public void testConstructorWithLargeDimensions2() {
                // Create a matrix where both row*col and col*col would overflow
                int largeDim = (int)Math.sqrt(Integer.MAX_VALUE) + 1;
                new OpenMapRealMatrix(largeDim, largeDim);
            }

 @Test
            public void testConstructorWithSmallDimensions() {
                // Small dimensions case that should work for both original and mutant
                OpenMapRealMatrix matrix = new OpenMapRealMatrix(10, 20);
                assertNotNull(matrix);
                assertEquals(10, matrix.getRowDimension());
                assertEquals(20, matrix.getColumnDimension());
            }

 @Test
           public void testConstructorWithLargeDimensionsNoOverflow() {
               // These values are chosen so that:
               // - Without proper casting: 46342 * 46342 would overflow (2147487364 > Integer.MAX_VALUE)
               // - With proper casting: 46342L * 46342L = 2147487364L < Integer.MAX_VALUE (2147483647)
               // So the original code should accept it, but mutant would reject it
               
               int largeDimension = 46342;  // sqrt(Integer.MAX_VALUE) ~ 46340.95
               
               // Should not throw exception with original code
               OpenMapRealMatrix matrix = new OpenMapRealMatrix(largeDimension, largeDimension);
               
               // Verify dimensions were set correctly
               assertEquals(largeDimension, matrix.getRowDimension());
               assertEquals(largeDimension, matrix.getColumnDimension());
           }

 @Test
           public void testConstructorWithDimensionsCausingOverflow() {
               int veryLargeDimension = 50000;  // 50000 * 50000 will overflow even with long
               
               thrown.expect(NumberIsTooLargeException.class);
               new OpenMapRealMatrix(veryLargeDimension, veryLargeDimension);
           }

 @Test
           public void testConstructorWithLargeDimensions3() {
               // These dimensions will cause integer overflow if not properly cast to long first
               int largeDim = (int)Math.sqrt(Integer.MAX_VALUE) + 1;
               
               // The original code should handle this fine since it casts to long first
               OpenMapRealMatrix originalMatrix = new OpenMapRealMatrix(largeDim, largeDim);
               
               // Now test the copy constructor with this matrix
               OpenMapRealMatrix copiedMatrix = new OpenMapRealMatrix(originalMatrix);
               
               // Verify the copy was successful
               assertEquals(originalMatrix.getRowDimension(), copiedMatrix.getRowDimension());
               assertEquals(originalMatrix.getColumnDimension(), copiedMatrix.getColumnDimension());
           }

 @Test
           public void testConstructorWithVeryLargeDimensions() {
               // These dimensions would cause overflow if not properly cast to long
               int veryLargeRows = Integer.MAX_VALUE / 2 + 1;
               int veryLargeCols = 2;
               
               thrown.expect(NumberIsTooLargeException.class);
               // This should throw because (long)veryLargeRows * (long)veryLargeCols > Integer.MAX_VALUE
               new OpenMapRealMatrix(veryLargeRows, veryLargeCols);
           }

 @Test
          public void testConstructorSizeValidationWithDifferentDimensions1() {
              // Test case where rows < columns and their product is near MAX_VALUE
              // This would pass the mutated version but fail the original
              int largeSize = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
              int rows = largeSize - 1000;
              int columns = largeSize + 1000;
              
              // The original should throw exception since rows*columns > MAX_VALUE
              // The mutant would use rows*rows which might be < MAX_VALUE
              thrown.expect(NumberIsTooLargeException.class);
              thrown.expectMessage(Long.toString((long)rows * (long)columns));
              
              new OpenMapRealMatrix(rows, columns);
          }

 @Test
          public void testConstructorSizeValidationWithSquareMatrix() {
              // This test case would pass both original and mutant
              // Used to verify the test setup is correct
              int size = (int) Math.sqrt(Integer.MAX_VALUE) - 1;
              new OpenMapRealMatrix(size, size); // Should not throw
          }

 @Test
          public void testConstructorWithDifferentDimensionsBelowLimit() {
              // Test with different dimensions but product below limit
              // Should pass both original and mutant
              new OpenMapRealMatrix(3, 5); // Should not throw
          }

 @Test
          public void testConstructorWithDifferentDimensions1() {
              // Test with row > column
              try {
                  OpenMapRealMatrix matrix1 = new OpenMapRealMatrix(5, 3);
                  OpenMapRealMatrix copy1 = new OpenMapRealMatrix(matrix1);
                  assertEquals(5, copy1.getRowDimension());
                  assertEquals(3, copy1.getColumnDimension());
              } catch (NumberIsTooLargeException e) {
                  fail("Should not throw exception for valid dimensions");
              }
      
              // Test with column > row
              try {
                  OpenMapRealMatrix matrix2 = new OpenMapRealMatrix(2, 4);
                  OpenMapRealMatrix copy2 = new OpenMapRealMatrix(matrix2);
                  assertEquals(2, copy2.getRowDimension());
                  assertEquals(4, copy2.getColumnDimension());
              } catch (NumberIsTooLargeException e) {
                  fail("Should not throw exception for valid dimensions");
              }
          }

 @Test(expected = NumberIsTooLargeException.class)
          public void testConstructorWithLargeDimensions4() {
              // This test will catch the mutant because it uses different row/column dimensions
              // The mutant would use rowDimension for both calculations
              int largeDim = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
              int smallDim = 2;
              
              // Original code would throw when largeDim * smallDim >= MAX_VALUE
              // Mutant would throw when largeDim * largeDim >= MAX_VALUE (different condition)
              OpenMapRealMatrix matrix = new OpenMapRealMatrix(largeDim, smallDim);
              new OpenMapRealMatrix(matrix); // This should throw
          }

 @Test
         public void testConstructorThrowsWhenSizeEqualsMaxValue() {
             // Find dimensions that multiply to exactly Integer.MAX_VALUE
             // Using 1 and MAX_VALUE since they're factors
             int rows = 1;
             int columns = Integer.MAX_VALUE;
             
             thrown.expect(NumberIsTooLargeException.class);
             thrown.expectMessage(Long.toString(Integer.MAX_VALUE));
             
             // This should throw in original but pass in mutated version
             new OpenMapRealMatrix(rows, columns);
         }

 @Test
         public void testConstructorThrowsWhenSizeExceedsMaxValue1() {
             // Create case where size exceeds MAX_VALUE
             int rows = 2;
             int columns = Integer.MAX_VALUE / 2 + 1;
             
             thrown.expect(NumberIsTooLargeException.class);
             thrown.expectMessage(Long.toString((long)rows * columns));
             
             // Both original and mutated should throw here
             new OpenMapRealMatrix(rows, columns);
         }

 @Test
         public void testConstructorAcceptsValidSize() {
             // Test with size just below MAX_VALUE
             int rows = 1;
             int columns = Integer.MAX_VALUE - 1;
             
             // Should not throw in either version
             OpenMapRealMatrix matrix = new OpenMapRealMatrix(rows, columns);
             
             assertEquals(rows, matrix.getRowDimension());
             assertEquals(columns, matrix.getColumnDimension());
         }

 @Test
         public void testConstructorWithMaxValueDimensions() {
             // Test case where row * col = Integer.MAX_VALUE
             // This should throw exception in original code but pass in mutated code
             int n = (int) Math.sqrt(Integer.MAX_VALUE);
             thrown.expect(NumberIsTooLargeException.class);
             new OpenMapRealMatrix(n, n);
         }

 @Test
         public void testConstructorWithExceedingDimensions() {
             // Test case where row * col > Integer.MAX_VALUE
             // This should throw exception in both original and mutated code
             int n = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
             thrown.expect(NumberIsTooLargeException.class);
             new OpenMapRealMatrix(n, n);
         }

 @Test
         public void testConstructorWithValidDimensions() {
             // Test case where row * col < Integer.MAX_VALUE
             // This should pass in both original and mutated code
             new OpenMapRealMatrix(100, 100);
         }

 @Test
        public void testConstructorThrowsWhenSizeExceedsMaxValue2() {
            // This test will catch the mutant because it tests a case where
            // size > Integer.MAX_VALUE, which should throw but won't with the mutant
            
            // Calculate dimensions that will overflow Integer.MAX_VALUE
            // Using sqrt(MAX_VALUE)+1 to ensure product is > MAX_VALUE
            int dimension = (int)Math.sqrt(Integer.MAX_VALUE) + 2;
            
            thrown.expect(NumberIsTooLargeException.class);
            thrown.expectMessage("larger than");
            
            // This should throw in original code but won't with the mutant
            new OpenMapRealMatrix(dimension, dimension);
        }

 @Test
        public void testConstructorThrowsWhenSizeEqualsMaxValue1() {
            // This tests the boundary case that both original and mutant catch
            
            // Find factors of MAX_VALUE (approximate since MAX_VALUE is prime)
            // Using MAX_VALUE/2 and 2 to get close to the boundary
            int rows = Integer.MAX_VALUE / 2;
            int cols = 2;
            
            thrown.expect(NumberIsTooLargeException.class);
            thrown.expectMessage("larger than");
            
            // This should throw in both original and mutant
            new OpenMapRealMatrix(rows, cols);
        }

 @Test
        public void testConstructorAcceptsValidDimensions() {
            // Test normal case that should work in both original and mutant
            int validSize = (int)Math.sqrt(Integer.MAX_VALUE) - 1;
            new OpenMapRealMatrix(validSize, validSize);
            // No exception expected
        }

 @Test
        public void testConstructorWithDimensionsGreaterThanMaxValue() {
            // This test will catch the mutant because:
            // Original: 46341 * 46341 = 2147488281 > Integer.MAX_VALUE (2147483647) → throws exception
            // Mutant: same product != Integer.MAX_VALUE → doesn't throw exception
            
            thrown.expect(NumberIsTooLargeException.class);
            thrown.expectMessage("2147488281");
            
            // 46341 is chosen because 46340*46340=2147395600 < MAX_VALUE
            // 46341*46341=2147488281 > MAX_VALUE
            int largeDimension = 46341;
            new OpenMapRealMatrix(largeDimension, largeDimension);
        }

 @Test
        public void testConstructorWithDimensionsEqualToMaxValue() {
            // This is the boundary case that both original and mutant handle the same way
            thrown.expect(NumberIsTooLargeException.class);
            
            // We can't actually create dimensions that multiply to exactly MAX_VALUE
            // since MAX_VALUE is prime, so we'll test with 1 and MAX_VALUE
            new OpenMapRealMatrix(1, Integer.MAX_VALUE);
        }

 @Test
        public void testConstructorWithValidDimensions1() {
            // This should work in both original and mutant
            int validDimension = 46340; // 46340*46340 < MAX_VALUE
            OpenMapRealMatrix matrix = new OpenMapRealMatrix(validDimension, validDimension);
            assertEquals(validDimension, matrix.getRowDimension());
            assertEquals(validDimension, matrix.getColumnDimension());
        }

 @Test
       public void testConstructorSizeValidation() {
           // This test will catch the mutant by using dimensions where:
           // row * col >= MAX_VALUE (should throw)
           // but row + col < MAX_VALUE (mutant won't throw)
           
           int dimension = (int) Math.sqrt(Integer.MAX_VALUE); // ~46341
           // Make sure we're above the threshold
           if ((long)dimension * dimension < Integer.MAX_VALUE) {
               dimension++;
           }
           
           // Expect exception because total elements would exceed MAX_VALUE
           thrown.expect(NumberIsTooLargeException.class);
           thrown.expectMessage(Long.toString((long)dimension * dimension));
           
           // This should throw in original code but pass in mutant
           new OpenMapRealMatrix(dimension, dimension);
       }

 @Test
       public void testConstructorValidSize() {
           // Also test a valid case where both sum and product are small
           new OpenMapRealMatrix(100, 100); // Should work in both original and mutant
       }

 @Test
       public void testConstructorWithLargeDimensionsShouldThrowException() {
           // These dimensions are chosen because:
           // 46340 * 46340 = 2,147,395,600 which is > Integer.MAX_VALUE (2,147,483,647)
           // But 46340 + 46340 = 92,680 which is < Integer.MAX_VALUE
           int largeDim = 46340;
           
           thrown.expect(NumberIsTooLargeException.class);
           thrown.expectMessage("2,147,395,600");
           
           // This should throw in original code but pass in mutant
           new OpenMapRealMatrix(largeDim, largeDim);
       }

 @Test
       public void testConstructorWithValidDimensions2() {
           // Regular case that should work in both original and mutant
           OpenMapRealMatrix matrix = new OpenMapRealMatrix(100, 100);
           assertEquals(100, matrix.getRowDimension());
           assertEquals(100, matrix.getColumnDimension());
       }

 @Test
       public void testCopyConstructor() {
           // Test the copy constructor that was shown in the original code
           OpenMapRealMatrix original = new OpenMapRealMatrix(5, 5);
           original.setEntry(0, 0, 1.0);
           
           OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
           assertEquals(5, copy.getRowDimension());
           assertEquals(5, copy.getColumnDimension());
           assertEquals(1.0, copy.getEntry(0, 0), 0.0001);
       }

 @Test
      public void testConstructorThrowsWhenTotalElementsExceedsMaxValue() {
          // Choose dimensions where:
          // row + col < Integer.MAX_VALUE (won't trigger mutant)
          // row * col >= Integer.MAX_VALUE (should trigger original)
          int bigSize = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
          
          thrown.expect(NumberIsTooLargeException.class);
          thrown.expectMessage(String.valueOf((long)bigSize * bigSize));
          
          // This should throw in original but not in mutant
          new OpenMapRealMatrix(bigSize, bigSize);
      }

 @Test
      public void testConstructorDoesNotThrowWhenSumLargeButProductSmall() {
          // Choose dimensions where:
          // row + col is large (close to MAX_VALUE)
          // row * col is small (< MAX_VALUE)
          int halfMax = Integer.MAX_VALUE / 2;
          new OpenMapRealMatrix(halfMax, 1); // Should not throw in either case
      }

 @Test
      public void testConstructorThrowsWhenMatrixTooLarge() {
          // Create dimensions where:
          // rows * columns > Integer.MAX_VALUE (should throw)
          // but rows + columns <= Integer.MAX_VALUE (mutant would allow)
          int rows = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
          int columns = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
          
          // Verify that rows*columns would overflow
          assertTrue((long)rows * (long)columns > Integer.MAX_VALUE);
          // Verify that rows+columns wouldn't overflow
          assertTrue(rows + columns <= Integer.MAX_VALUE);
          
          thrown.expect(NumberIsTooLargeException.class);
          thrown.expectMessage("larger than");
          
          // This should throw in original code but would pass in mutant
          new OpenMapRealMatrix(rows, columns);
      }

 @Test
     public void testConstructorThrowsWhenSizeExactlyMaxValue() {
         // Find dimensions where rows * columns = Integer.MAX_VALUE
         // Using 1 and MAX_VALUE as simplest case
         int rows = 1;
         int columns = Integer.MAX_VALUE;
         
         // Set up exception expectation
         thrown.expect(NumberIsTooLargeException.class);
         thrown.expectMessage("1 * 2,147,483,647 >= 2,147,483,647");
         
         // This should throw in original but not in mutant
         new OpenMapRealMatrix(rows, columns);
     }

 @Test
     public void testConstructorDoesNotThrowWhenSizeBelowMaxValue() {
         // Test with size just below MAX_VALUE
         int rows = 1;
         int columns = Integer.MAX_VALUE - 1;
         
         // Should not throw in either original or mutant
         new OpenMapRealMatrix(rows, columns);
     }

 @Test
     public void testConstructorThrowsWhenSizeAboveMaxValue() {
         // Test with size just above MAX_VALUE
         int rows = 2;
         int columns = Integer.MAX_VALUE / 2 + 1;
         
         // Should throw in both original and mutant
         thrown.expect(NumberIsTooLargeException.class);
         new OpenMapRealMatrix(rows, columns);
     }

 @Test
     public void testConstructorWithMaxValueDimensions1() {
         // Calculate dimensions that multiply to exactly Integer.MAX_VALUE
         // Using 1 and Integer.MAX_VALUE since they are factors
         int rows = 1;
         int columns = Integer.MAX_VALUE;
         
         thrown.expect(NumberIsTooLargeException.class);
         thrown.expectMessage(Integer.MAX_VALUE + " <= " + Integer.MAX_VALUE);
         
         // This should throw in original code but not in mutated version
         new OpenMapRealMatrix(rows, columns);
     }

 @Test
     public void testConstructorWithJustAboveMaxValueDimensions() {
         // Calculate dimensions that multiply to just above Integer.MAX_VALUE
         // Using 2 and (Integer.MAX_VALUE/2 + 1) since their product is MAX_VALUE + 1
         int rows = 2;
         int columns = Integer.MAX_VALUE/2 + 1;
         
         thrown.expect(NumberIsTooLargeException.class);
         thrown.expectMessage((long)rows * columns + " > " + Integer.MAX_VALUE);
         
         // This should throw in both original and mutated versions
         new OpenMapRealMatrix(rows, columns);
     }

}
