package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import org.apache.commons.math.util.MathUtils;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
            public void testEquals_ReferenceEquality() {
                Complex c1 = new Complex(3.0, 4.0);
                assertTrue(c1.equals(c1));
            }

 @Test
            public void testEquals_NullComparison() {
                Complex c1 = new Complex(3.0, 4.0);
                assertFalse(c1.equals(null));
            }

 @Test
            public void testEquals_DifferentClass() {
                Complex c1 = new Complex(3.0, 4.0);
                Object obj = new Object();
                assertFalse(c1.equals(obj));
            }

 @Test
            public void testEquals_NaNComparison() {
                Complex nan1 = Complex.NaN;
                Complex nan2 = Complex.NaN;
                Complex regular = new Complex(1.0, 1.0);
                
                assertTrue(nan1.equals(nan2));
                assertFalse(nan1.equals(regular));
                assertFalse(regular.equals(nan1));
            }

 @Test
            public void testEquals_RegularNumbers() {
                Complex c1 = new Complex(3.0, 4.0);
                Complex c2 = new Complex(3.0, 4.0);
                Complex c3 = new Complex(3.1, 4.0);
                Complex c4 = new Complex(3.0, 4.1);
                
                assertTrue(c1.equals(c2));
                assertFalse(c1.equals(c3));
                assertFalse(c1.equals(c4));
            }

 @Test
            public void testEquals_Infinity() {
                Complex inf1 = Complex.INF;
                Complex inf2 = Complex.INF;
                Complex regular = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                
                assertTrue(inf1.equals(inf2));
                assertTrue(inf1.equals(regular));
                assertTrue(regular.equals(inf1));
            }

 @Test
            public void testEquals_SpecialConstants() {
                Complex zero1 = Complex.ZERO;
                Complex zero2 = new Complex(0.0, 0.0);
                Complex one1 = Complex.ONE;
                Complex one2 = new Complex(1.0, 0.0);
                Complex i1 = Complex.I;
                Complex i2 = new Complex(0.0, 1.0);
                
                assertTrue(zero1.equals(zero2));
                assertTrue(one1.equals(one2));
                assertTrue(i1.equals(i2));
                assertFalse(zero1.equals(one1));
                assertFalse(one1.equals(i1));
            }

 @Test
            public void testEquals_FloatingPointPrecision() {
                Complex c1 = new Complex(0.1 + 0.2, 0.3 + 0.4);
                Complex c2 = new Complex(0.3, 0.7);
                
                // This might fail due to floating point precision - depends on implementation
                // assertTrue(c1.equals(c2));
                // Better to test with exact values
                assertTrue(new Complex(0.3, 0.7).equals(new Complex(0.3, 0.7)));
            }

 @Test
        public void testEquals_SameObject_ShouldReturnTrue() {
            // Arrange
            Complex complex = new Complex(1.0, 2.0);
            
            // Act & Assert
            assertTrue("Comparing an object with itself should return true", 
                      complex.equals(complex));
        }

 @Test
       public void testEqualsWithSameReference() {
           // Create a complex number
           Complex complex = new Complex(1.0, 2.0);
           
           // Test that equals returns true when comparing with itself
           assertTrue("Equals should return true for same reference", complex.equals(complex));
           
           // Also test with one of the static constants
           assertTrue("Equals should return true for same reference", 
                     Complex.ONE.equals(Complex.ONE));
       }

 @Test
      public void testEqualsWithNaN() {
          // Create NaN complex numbers using the static field
          Complex nan1 = Complex.NaN;
          Complex nan2 = new Complex(Double.NaN, Double.NaN);
          Complex nonNan = new Complex(1.0, 1.0);
          
          // Two NaN values should be considered equal
          assertTrue("Two NaN complex numbers should be equal", nan1.equals(nan2));
          
          // NaN should not equal non-NaN
          assertFalse("NaN should not equal non-NaN complex", nan1.equals(nonNan));
          
          // Non-NaN should not equal NaN
          assertFalse("Non-NaN should not equal NaN complex", nonNan.equals(nan1));
          
          // Test normal complex number comparison
          Complex c1 = new Complex(2.0, 3.0);
          Complex c2 = new Complex(2.0, 3.0);
          Complex c3 = new Complex(2.0, 4.0);
          assertTrue("Equal complex numbers should return true", c1.equals(c2));
          assertFalse("Different complex numbers should return false", c1.equals(c3));
      }

 @Test
     public void testEqualsWithNaNComplexNumbers() {
         // Create two NaN Complex numbers
         Complex nan1 = Complex.NaN;
         Complex nan2 = new Complex(Double.NaN, Double.NaN);
         
         // Also create a non-NaN Complex for comparison
         Complex normal = new Complex(1.0, 1.0);
         
         // Two NaN Complex numbers should be considered equal
         assertTrue(nan1.equals(nan2));
         
         // NaN Complex should not equal normal Complex
         assertFalse(nan1.equals(normal));
         assertFalse(normal.equals(nan1));
         
         // NaN Complex should equal itself
         assertTrue(nan1.equals(nan1));
     }

}
