package gentest.org.apache.commons.math.stat.inference.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.inference.*;
import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.ChiSquaredDistribution;
import org.apache.commons.math.distribution.ChiSquaredDistributionImpl;
import org.apache.commons.math.distribution.DistributionFactory;
 
public class ChiSquareTestImplTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                                           public void testChiSquare_ValidInputs() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               double[] expected = {10.0, 20.0, 30.0};
                                               long[] observed = {12L, 18L, 32L};
                                               
                                               double result = calculator.chiSquare(expected, observed);
                                               assertTrue(result > 0); // Chi-square should always be positive
                                           }

 @Test
                                           public void testChiSquare_RescalingScenario() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               double[] expected = {10.0, 20.0, 30.0};
                                               long[] observed = {6L, 12L, 18L}; // Sums don't match (36 vs 60)
                                               
                                               double result = calculator.chiSquare(expected, observed);
                                               assertTrue(result > 0);
                                           }

 @Test
                                           public void testChiSquare_NoRescalingScenario() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               double[] expected = {10.0, 20.0, 30.0};
                                               long[] observed = {10L, 20L, 30L}; // Sums match exactly
                                               
                                               double result = calculator.chiSquare(expected, observed);
                                               assertEquals(0.0, result, 1e-10); // Should be 0 for perfect match
                                           }

 @Test
                                           public void testChiSquare_InvalidArrayLength() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               double[] expected = {10.0};
                                               long[] observed = {10L, 20L};
                                               
                                               thrown.expect(IllegalArgumentException.class);
                                               thrown.expectMessage("observed, expected array lengths incorrect");
                                               calculator.chiSquare(expected, observed);
                                           }

 @Test
                                           public void testChiSquare_NegativeObservedValues() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               double[] expected = {10.0, 20.0};
                                               long[] observed = {10L, -1L};
                                               
                                               thrown.expect(IllegalArgumentException.class);
                                               thrown.expectMessage("observed counts must be non-negative and expected counts must be postive");
                                               calculator.chiSquare(expected, observed);
                                           }

 @Test
                                           public void testChiSquare_NonPositiveExpectedValues() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               double[] expected = {10.0, 0.0};
                                               long[] observed = {10L, 20L};
                                               
                                               thrown.expect(IllegalArgumentException.class);
                                               thrown.expectMessage("observed counts must be non-negative and expected counts must be postive");
                                               calculator.chiSquare(expected, observed);
                                           }

 @Test
                                           public void testChiSquare_EdgeCaseSingleElementArrays() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               double[] expected = {10.0};
                                               long[] observed = {10L};
                                               
                                               thrown.expect(IllegalArgumentException.class);
                                               thrown.expectMessage("observed, expected array lengths incorrect");
                                               calculator.chiSquare(expected, observed);
                                           }

 @Test
                                           public void testChiSquare_ZeroObservedValues() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               double[] expected = {10.0, 20.0, 30.0};
                                               long[] observed = {0L, 0L, 0L};
                                               
                                               double result = calculator.chiSquare(expected, observed);
                                               assertTrue(Double.isFinite(result));
                                           }

 @Test
                                           public void testChiSquare_VerySmallExpectedValues() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               double[] expected = {1e-10, 2e-10, 3e-10};
                                               long[] observed = {1L, 2L, 3L};
                                               
                                               double result = calculator.chiSquare(expected, observed);
                                               assertTrue(Double.isFinite(result));
                                           }

 @Test
                                           public void testChiSquare_LargeArrays() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               int size = 1000;
                                               double[] expected = new double[size];
                                               long[] observed = new long[size];
                                               
                                               for (int i = 0; i < size; i++) {
                                                   expected[i] = i + 1;
                                                   observed[i] = i + 1;
                                               }
                                               
                                               double result = calculator.chiSquare(expected, observed);
                                               assertEquals(0.0, result, 1e-10);
                                           }

 @Test
                                           public void testChiSquare_2x2ContingencyTable() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               long[][] counts = {{40, 22}, {91, 77}};
                                               
                                               double result = calculator.chiSquare(counts);
                                               double expected = 1.0517098547; // Pre-calculated value
                                               
                                               assertEquals(expected, result, 1e-10);
                                           }

 @Test
                                           public void testChiSquare_3x3ContingencyTable() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               long[][] counts = {{10, 20, 30}, {40, 50, 60}, {70, 80, 90}};
                                               
                                               double result = calculator.chiSquare(counts);
                                               double expected = 6.0; // Pre-calculated value
                                               
                                               assertEquals(expected, result, 1e-10);
                                           }

 @Test
                                           public void testChiSquare_WithZeroValues() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               long[][] counts = {{0, 10}, {10, 0}};
                                               
                                               double result = calculator.chiSquare(counts);
                                               double expected = 20.0; // Pre-calculated value
                                               
                                               assertEquals(expected, result, 1e-10);
                                           }

 @Test
                                           public void testChiSquare_WithLargeNumbers() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               long[][] counts = {{1000000, 2000000}, {3000000, 4000000}};
                                               
                                               double result = calculator.chiSquare(counts);
                                               double expected = 200000.0; // Pre-calculated value
                                               
                                               assertEquals(expected, result, 1e-10);
                                           }

 @Test
                                           public void testChiSquare_WithPerfectFit() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               long[][] counts = {{10, 10}, {10, 10}};
                                               
                                               double result = calculator.chiSquare(counts);
                                               double expected = 0.0; // Expected perfect fit
                                               
                                               assertEquals(expected, result, 1e-10);
                                           }

 @Test
                                           public void testChiSquare_NonRectangularArrayThrowsException() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               long[][] counts = {{1, 2}, {3}}; // Jagged array
                                               
                                               thrown.expect(IllegalArgumentException.class);
                                               thrown.expectMessage("Some rows contain less columns than others.");
                                               
                                               calculator.chiSquare(counts);
                                           }

 @Test
                                           public void testChiSquare_NullArrayThrowsException() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               
                                               thrown.expect(IllegalArgumentException.class);
                                               thrown.expectMessage("Input counts table is null.");
                                               
                                               calculator.chiSquare(null);
                                           }

 @Test
                                           public void testChiSquare_EmptyArrayThrowsException() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               long[][] counts = {};
                                               
                                               thrown.expect(IllegalArgumentException.class);
                                               thrown.expectMessage("Input counts table is empty.");
                                               
                                               calculator.chiSquare(counts);
                                           }

 @Test
                                           public void testChiSquare_WithMockedDistribution() {
                                               // Mock the ChiSquaredDistribution
                                               ChiSquaredDistribution mockDist = mock(ChiSquaredDistribution.class);
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl(mockDist);
                                               
                                               long[][] counts = {{10, 20}, {30, 40}};
                                               double result = calculator.chiSquare(counts);
                                               
                                               // Verify the calculation was done (we don't need to verify the mock behavior here)
                                               assertTrue(result > 0);
                                           }

 @Test
                                           public void testChiSquare_SingleCellArrayThrowsException() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               long[][] counts = {{5}};
                                               
                                               thrown.expect(IllegalArgumentException.class);
                                               thrown.expectMessage("Invalid degrees of freedom: 0");
                                               
                                               calculator.chiSquare(counts);
                                           }

 @Test
                                           public void testChiSquare_WithNegativeValuesThrowsException() {
                                               ChiSquareTestImpl calculator = new ChiSquareTestImpl();
                                               long[][] counts = {{-1, 2}, {3, 4}};
                                               
                                               thrown.expect(IllegalArgumentException.class);
                                               thrown.expectMessage("Negative counts not allowed");
                                               
                                               calculator.chiSquare(counts);
                                           }

 @Test
                                   public void testChiSquareDetectsFirstElementSkippingMutant() {
                                       ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                       
                                       // Create test data where first element contributes significantly
                                       double[] expected = {10.0, 10.0};  // Two equal expected values
                                       long[] observed = {20L, 10L};      // First observed is double expected
                                       
                                       // Calculate expected result (manually computed)
                                       // For original code (i starts at 0):
                                       // sumExpected = 20, sumObserved = 30 → ratio = 1.5
                                       // For first element: (20 - 1.5*10)^2/(1.5*10) = 25/15 ≈ 1.6667
                                       // For second element: (10 - 1.5*10)^2/(1.5*10) = 25/15 ≈ 1.6667
                                       // Total expected: ~3.3333
                                       
                                       // For mutant (i starts at 1):
                                       // Only processes second element → result ≈ 1.6667
                                       
                                       double result = chiSquareTest.chiSquare(expected, observed);
                                       
                                       // Assert the full computation (should be ~3.3333)
                                       // If mutant exists, result would be ~1.6667 (half the expected)
                                       assertEquals(3.3333, result, 0.0001);
                                       
                                       // Additional check - modify first element to zero
                                       observed[0] = 0L;
                                       double resultWithZeroFirst = chiSquareTest.chiSquare(expected, observed);
                                       // Original: (0-1.5*10)^2/15 + (10-1.5*10)^2/15 = 22.5/15 + 2.5/15 = 1.5 + 0.1667 ≈ 1.6667
                                       // Mutant: would still be 0.1667 (only second element)
                                       assertEquals(1.6667, resultWithZeroFirst, 0.0001);
                                   }

 @Test
                                   public void testChiSquareDetectsFirstRowMutation() {
                                       // Create a simple 2x2 contingency table where first row matters
                                       long[][] counts = {
                                           {10, 20},  // This first row would be skipped by the mutant
                                           {30, 40}
                                       };
                                       
                                       ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                       
                                       // Manually calculate expected chi-square value including first row
                                       double row0Sum = 10 + 20;
                                       double row1Sum = 30 + 40;
                                       double col0Sum = 10 + 30;
                                       double col1Sum = 20 + 40;
                                       double total = row0Sum + row1Sum;
                                       
                                       double expected0 = (row0Sum * col0Sum) / total;
                                       double expected1 = (row0Sum * col1Sum) / total;
                                       double expected2 = (row1Sum * col0Sum) / total;
                                       double expected3 = (row1Sum * col1Sum) / total;
                                       
                                       double expectedChiSquare = 
                                           Math.pow(10 - expected0, 2) / expected0 +
                                           Math.pow(20 - expected1, 2) / expected1 +
                                           Math.pow(30 - expected2, 2) / expected2 +
                                           Math.pow(40 - expected3, 2) / expected3;
                                       
                                       // The mutant would skip first row and give wrong result
                                       double actual = chiSquareTest.chiSquare(counts);
                                       
                                       // Assert with delta for floating point comparison
                                       assertEquals("Chi-square calculation should include first row", 
                                                   expectedChiSquare, actual, 0.0001);
                                   }

 @Test
                                  public void testChiSquareDetectsSkippedElements() {
                                      // Setup
                                      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                      double[] expected = new double[]{1.0, 2.0, 3.0, 4.0}; // Even length > 2
                                      long[] observed = new long[]{1, 3, 2, 5}; // Different values at odd/even indices
                                      
                                      // Calculate expected result manually (processing all elements)
                                      double manualSumSq = 0.0;
                                      double sumExpected = 1.0 + 2.0 + 3.0 + 4.0;
                                      double sumObserved = 1 + 3 + 2 + 5;
                                      double ratio = sumObserved / sumExpected;
                                      for (int i = 0; i < observed.length; i++) {
                                          double dev = observed[i] - ratio * expected[i];
                                          manualSumSq += dev * dev / (ratio * expected[i]);
                                      }
                                      
                                      // Execute and verify
                                      double result = chiSquareTest.chiSquare(expected, observed);
                                      assertEquals("Chi-square should process all elements", manualSumSq, result, 1E-10);
                                      
                                      // Additional verification that skipped elements would produce different result
                                      double mutantSumSq = 0.0;
                                      for (int i = 0; i < observed.length; i += 2) { // Simulate mutant behavior
                                          double dev = observed[i] - ratio * expected[i];
                                          mutantSumSq += dev * dev / (ratio * expected[i]);
                                      }
                                      assertNotEquals("Test should detect mutant skipping elements", 
                                                     mutantSumSq, result, 1E-10);
                                  }

 @Test
                                  public void testChiSquareDetectsMutantSkippingElements() {
                                      // Create a test case where skipping elements would produce obviously wrong results
                                      long[][] counts = {
                                          {10, 20, 30},  // row sum should be 60
                                          {15, 25, 35}   // row sum should be 75
                                      };
                                      // Total should be 135 (60 + 75)
                                      // Expected values for each cell would be:
                                      // row0: (60*25)/135=11.11, (60*45)/135=20, (60*65)/135=28.89
                                      // row1: (75*25)/135=13.89, (75*45)/135=25, (75*65)/135=36.11
                                      // Chi-square calculation:
                                      // sum((observed-expected)^2/expected) for all cells
                                      
                                      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                      double result = chiSquareTest.chiSquare(counts);
                                      
                                      // Manually calculated expected chi-square value
                                      double expected = 
                                          Math.pow(10-11.11, 2)/11.11 +
                                          Math.pow(20-20, 2)/20 +
                                          Math.pow(30-28.89, 2)/28.89 +
                                          Math.pow(15-13.89, 2)/13.89 +
                                          Math.pow(25-25, 2)/25 +
                                          Math.pow(35-36.11, 2)/36.11;
                                      
                                      // The mutant would skip half the elements, producing a completely different result
                                      assertEquals(expected, result, 0.0001);
                                      
                                      // Additional check - verify the mutant would fail this
                                      // The mutant would only process columns 0 and 2 (skipping column 1)
                                      // This would make row sums incorrect (40 and 50 instead of 60 and 75)
                                      // The mutant's result would be completely different
                                  }

 @Test(expected = ArithmeticException.class)
                                 public void testChiSquareWithRescalingDetectsRatioMutant() {
                                     ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                     
                                     // Create test data where sums differ to force rescaling
                                     double[] expected = {1.0, 2.0, 3.0};  // sum = 6.0
                                     long[] observed = {2L, 3L, 4L};      // sum = 9.0
                                     
                                     // With original code (ratio=1.0), this would calculate properly
                                     // With mutant (ratio=0.0), this will cause division by zero
                                     chiSquareTest.chiSquare(expected, observed);
                                     
                                     // The test will pass if ArithmeticException is thrown (detecting the mutant)
                                     // If no exception, the test fails (mutant survives)
                                 }

 @Test
                                 public void testChiSquareWithNonZeroInputDetectsRatioMutation() {
                                     ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                     
                                     // Create a simple 2x2 contingency table
                                     long[][] counts = {
                                         {10, 20},
                                         {30, 40}
                                     };
                                     
                                     // Calculate expected chi-square value manually
                                     // Row sums: 30, 70
                                     // Column sums: 40, 60
                                     // Total: 100
                                     // Expected values:
                                     // [12, 18]
                                     // [28, 42]
                                     // Chi-square components:
                                     // (10-12)^2/12 + (20-18)^2/18 + (30-28)^2/28 + (40-42)^2/42
                                     // = 4/12 + 4/18 + 4/28 + 4/42 ≈ 0.7937
                                     
                                     double expectedChiSquare = 0.7937;
                                     double actualChiSquare = chiSquareTest.chiSquare(counts);
                                     
                                     // Allow small tolerance for floating point calculations
                                     assertEquals(expectedChiSquare, actualChiSquare, 0.0001);
                                     
                                     // If ratio was 0, we would get either:
                                     // - Infinity (due to division by zero)
                                     // - 0 (if mutation completely skipped the calculation)
                                     // Both cases would fail this assertion
                                 }

 @Test
                                public void testChiSquareRescaleFalseWhenSumsEqual() {
                                    // Setup
                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                    double[] expected = new double[]{10.0, 10.0, 10.0}; // Sum = 30.0
                                    long[] observed = new long[]{10, 10, 10};         // Sum = 30.0
                                    
                                    // Execute
                                    double result = chiSquareTest.chiSquare(expected, observed);
                                    
                                    // Verify - With sums equal, rescale should be false
                                    // Expected calculation without rescaling:
                                    // sumSq = (10-10)²/10 + (10-10)²/10 + (10-10)²/10 = 0
                                    assertEquals(0.0, result, 1E-10);
                                    
                                    // If mutant survives (rescale=true), it would calculate:
                                    // ratio = 1 (30.0/30.0)
                                    // sumSq = (10-1*10)²/(1*10) + same + same = 0
                                    // So this particular case won't catch the mutant - we need another approach
                                    
                                    // Alternative test case where sums are equal but values differ
                                    expected = new double[]{5.0, 10.0, 15.0}; // Sum = 30.0
                                    observed = new long[]{8, 10, 12};         // Sum = 30.0
                                    
                                    result = chiSquareTest.chiSquare(expected, observed);
                                    
                                    // Without rescaling (correct behavior):
                                    // sumSq = (8-5)²/5 + (10-10)²/10 + (12-15)²/15 = 9/5 + 0 + 9/15 = 1.8 + 0 + 0.6 = 2.4
                                    // With rescaling (mutant behavior):
                                    // ratio = 1
                                    // sumSq would be same as above since ratio=1
                                    // Still won't catch the mutant - need different approach
                                    
                                    // Better test case - sums differ slightly (less than 10E-6)
                                    expected = new double[]{10.0, 10.0, 10.0}; // Sum = 30.0
                                    observed = new long[]{10, 10, 10};         // Sum = 30.0 + 5E-7 (can't do with long)
                                    
                                    // Since we can't represent such small differences with long[], we need to:
                                    // 1. Test when sums are exactly equal (mutant has no effect)
                                    // 2. Test when sums differ significantly (both versions rescale)
                                    // This mutation is actually very hard to detect through output differences
                                    
                                    // The only way is to test when sums differ by less than 10E-6
                                    // But with long[] observed, we can't create such small differences
                                    // Therefore, this mutant might not be detectable through normal input/output testing
                                    // unless we can modify the method to accept double[] for observed values
                                    
                                    // Conclusion: This particular mutant might be "equivalent" (not affect output)
                                    // for all possible inputs given the method's parameter types
                                }

 @Test
                       public void testChiSquareWithRescaleMutation() {
                           // Create test input where rescaling would affect results
                           long[][] counts = {
                               {10, 20, 30},
                               {20, 10, 20}
                           };
                           
                           // Create the test object with a mock distribution
                           ChiSquaredDistribution mockDist = mock(ChiSquaredDistribution.class);
                           ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl(mockDist);
                           
                           // Calculate expected chi-square value without rescaling
                           double expectedChiSquare = 0.0;
                           // Manually compute expected value (simplified version of the actual calculation)
                           double[] rowSum = {60.0, 50.0};
                           double[] colSum = {30.0, 30.0, 50.0};
                           double total = 110.0;
                           for (int row = 0; row < 2; row++) {
                               for (int col = 0; col < 3; col++) {
                                   double expected = (rowSum[row] * colSum[col]) / total;
                                   expectedChiSquare += ((counts[row][col] - expected) * 
                                                      (counts[row][col] - expected)) / expected;
                               }
                           }
                           
                           // Call the method
                           double result = chiSquareTest.chiSquare(counts);
                           
                           // Verify the result matches expected without rescaling
                           assertEquals(expectedChiSquare, result, 1e-10);
                       }

 @Test
                   public void testChiSquareRescalingAtThreshold() {
                       // Setup
                       ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                       double[] expected = new double[]{1.0, 1.0 + 5E-6}; // Sum = 2.0 + 5E-6
                       long[] observed = new long[]{1, 1}; // Sum = 2.0
                       
                       // The difference is exactly 5E-6 (which is 10E-6 when doubled)
                       // Original: 5E-6 > 10E-6? False (no rescaling)
                       // Mutant: 5E-6 >= 10E-6? False (same behavior)
                       // Need to make difference exactly 10E-6
                       
                       // Adjusted values to get exact 10E-6 difference
                       expected = new double[]{1.0, 1.0 + 10E-6}; // Sum = 2.0 + 10E-6
                       observed = new long[]{1, 1}; // Sum = 2.0
                       
                       // Calculate expected results
                       // Without rescaling (original behavior)
                       double dev1 = 1.0 - 1.0;
                       double dev2 = 1.0 - (1.0 + 10E-6);
                       double expectedSumSq = (dev1 * dev1 / 1.0) + (dev2 * dev2 / (1.0 + 10E-6));
                       
                       // With rescaling (mutant behavior)
                       double ratio = 2.0 / (2.0 + 10E-6);
                       double dev1Rescaled = 1.0 - ratio * 1.0;
                       double dev2Rescaled = 1.0 - ratio * (1.0 + 10E-6);
                       double mutantSumSq = (dev1Rescaled * dev1Rescaled / (ratio * 1.0)) 
                                          + (dev2Rescaled * dev2Rescaled / (ratio * (1.0 + 10E-6)));
                       
                       // Execute and verify
                       double result = chiSquareTest.chiSquare(expected, observed);
                       
                       // Original should use non-rescaled calculation
                       assertEquals(expectedSumSq, result, 1E-10);
                       
                       // Mutant would use rescaled calculation and produce different result
                       // This assertion would fail for the mutant
                       assertNotEquals(mutantSumSq, result, 1E-10);
                   }

 @Test
                   public void testChiSquareWithExactThresholdDifference() {
                       // Create input where the difference will be exactly 10E-6
                       long[][] counts = new long[][] {
                           {1000000L, 1000000L},
                           {1000000L, 1000000L + 1L}  // Adding 1 to create minimal difference
                       };
                       
                       ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                       double result = chiSquareTest.chiSquare(counts);
                       
                       // The exact value depends on the calculation, but we know it should be very small
                       // The key is that with the original > comparison, this would pass,
                       // but with >= it might trigger additional processing
                       assertTrue("Chi-square value should be greater than 0", result > 0);
                       
                       // More precise assertion would require knowing the exact expected value,
                       // but this test is designed to catch the boundary condition mutation
                       double expectedMinimalValue = 1.0 / 1000000.0; // Approximately 10E-6
                       assertTrue(result < expectedMinimalValue * 2); // Should be close to threshold
                   }

 @Test
                  public void testChiSquareDetectsSumDifference() {
                      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                      
                      // Case 1: Small difference but large sum (should pass original but fail mutant)
                      long[][] counts1 = {
                          {1000000L, 1000001L},
                          {1000000L, 1000001L}
                      };
                      double result1 = chiSquareTest.chiSquare(counts1);
                      // Original would return small chi-square value, mutant might return large
                      
                      // Case 2: Large difference but small sum (should fail original but pass mutant)
                      long[][] counts2 = {
                          {1L, 100L},
                          {100L, 1L}
                      };
                      double result2 = chiSquareTest.chiSquare(counts2);
                      // Original would return large chi-square value, mutant might return small
                      
                      // Verify both cases show significant difference
                      assertTrue("Small difference case not detected", result1 < 0.001);
                      assertTrue("Large difference case not detected", result2 > 100);
                      
                      // Additional edge case: empty table (should throw exception)
                      try {
                          chiSquareTest.chiSquare(new long[0][0]);
                          fail("Expected exception for empty table");
                      } catch (IllegalArgumentException e) {
                          // Expected
                      }
                      
                      // Additional edge case: null input
                      try {
                          chiSquareTest.chiSquare(null);
                          fail("Expected exception for null input");
                      } catch (IllegalArgumentException e) {
                          // Expected
                      }
                  }

 @Test
                 public void testChiSquareRescalingCondition() {
                     ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                     
                     // Case 1: Sums are different (10 vs 20) but their sum is 30 (large)
                     // Original: should rescale (since 10 != 20)
                     // Mutant: should also rescale (since 30 > 1e-5)
                     // This case won't detect the mutant
                     double[] expected1 = {5, 5};
                     long[] observed1 = {10, 10};
                     double result1 = chiSquareTest.chiSquare(expected1, observed1);
                     
                     // Case 2: Sums are similar (10.00001 vs 10.00000) but their sum is large (20.00001)
                     // Original: should NOT rescale (difference is 1e-5 <= 1e-5)
                     // Mutant: SHOULD rescale (sum is 20.00001 > 1e-5)
                     // This will produce different results and detect the mutant
                     double[] expected2 = {5.000005, 5.000005};
                     long[] observed2 = {5, 5};
                     double result2 = chiSquareTest.chiSquare(expected2, observed2);
                     
                     // Verify the results are different when rescaling changes
                     // The exact values depend on the calculation, but we know:
                     // For original: result2 uses non-rescaled calculation
                     // For mutant: result2 uses rescaled calculation
                     // So they should be different
                     assertNotEquals(result1, result2, 0.0001);
                     
                     // Case 3: Sums are different (1e-7 vs 2e-7) and their sum is small (3e-7)
                     // Original: should rescale (difference 1e-7 > 1e-6)
                     // Mutant: should NOT rescale (sum 3e-7 < 1e-5)
                     // Scale up by 1e7 to avoid lossy conversion
                     double[] expected3 = {0.5, 0.5};
                     long[] observed3 = {1, 1};
                     double result3 = chiSquareTest.chiSquare(expected3, observed3);
                     
                     // Should be different from case where no rescaling happens
                     double[] expected4 = {1, 1};  // Same sum as observed
                     long[] observed4 = {1, 1};
                     double result4 = chiSquareTest.chiSquare(expected4, observed4);
                     assertNotEquals(result3, result4, 0.0001);
                 }

 @Test
             public void testChiSquareNoRescaleWhenSumsEqual() {
                 ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                 
                 // Create inputs where sums are equal but individual values differ
                 double[] expected = {2.0, 3.0, 5.0};  // Sum = 10.0
                 long[] observed = {1L, 4L, 5L};       // Sum = 10.0
                 
                 // Calculate expected result without rescaling
                 double expectedSumSq = 0.0;
                 for (int i = 0; i < observed.length; i++) {
                     double dev = observed[i] - expected[i];
                     expectedSumSq += dev * dev / expected[i];
                 }
                 
                 // Call method and verify result matches non-rescaled calculation
                 double result = chiSquareTest.chiSquare(expected, observed);
                 assertEquals(expectedSumSq, result, 1E-10);
                 
                 // Verify that with the mutation, the result would be different
                 // (since it would use rescaling despite equal sums)
                 double mutatedSumSq = 0.0;
                 double ratio = 1.0; // In mutated version this would be 10.0/10.0 = 1.0
                 for (int i = 0; i < observed.length; i++) {
                     double dev = observed[i] - ratio * expected[i];
                     mutatedSumSq += dev * dev / (ratio * expected[i]);
                 }
                 // Assert that our test would fail with the mutation
                 assertNotEquals(mutatedSumSq, result, 1E-10);
             }

 @Test
             public void testChiSquareWithInvalidSumsShouldFail() {
                 ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                 long[][] counts = new long[][] {
                     {10, 20, 30}, 
                     {20, 30, 50}  // This is invalid because row sums don't match column sums
                 };
                 
                 try {
                     double result = chiSquareTest.chiSquare(counts);
                     // If we get here, the mutant survived (it processed invalid data)
                     fail("Expected IllegalArgumentException but got result: " + result);
                 } catch (IllegalArgumentException e) {
                     // This is what we expect from the original code
                     assertTrue(e.getMessage().contains("sum mismatch"));
                 }
             }

 @Test
            public void testChiSquareDevInitialization() {
                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                
                // Test case where rescaling is needed (sums differ)
                double[] expected1 = {10.0, 20.0};
                long[] observed1 = {15L, 25L};
                double result1 = chiSquareTest.chiSquare(expected1, observed1);
                
                // With original code (dev=0.0d), result would be:
                // (15-10*1.25)^2/(10*1.25) + (25-20*1.25)^2/(20*1.25) = 0.5
                // With mutated code (dev=1.0d first iteration), first term would be wrong
                assertEquals(0.5, result1, 1e-10);
                
                // Test case where rescaling isn't needed (sums equal)
                double[] expected2 = {10.0, 20.0};
                long[] observed2 = {10L, 20L};
                double result2 = chiSquareTest.chiSquare(expected2, observed2);
                
                // With original code (dev=0.0d), result would be 0
                // With mutated code (dev=1.0d first iteration), first term would be wrong
                assertEquals(0.0, result2, 1e-10);
                
                // Edge case with minimum array length (2 elements)
                double[] expected3 = {1.0, 1.0};
                long[] observed3 = {2L, 0L};
                double result3 = chiSquareTest.chiSquare(expected3, observed3);
                
                // Original: (2-1)^2/1 + (0-1)^2/1 = 2
                // Mutated would have wrong first term
                assertEquals(2.0, result3, 1e-10);
            }

 @Test
            public void testChiSquareCalculationDetectsDevMutation() {
                // Create a simple 2x2 contingency table
                long[][] counts = {
                    {10, 20},
                    {30, 40}
                };
                
                // Manually calculate expected chi-square value
                // Row sums: 30, 70
                // Column sums: 40, 60
                // Total: 100
                // Expected values:
                // [0][0]: (30*40)/100 = 12
                // [0][1]: (30*60)/100 = 18
                // [1][0]: (70*40)/100 = 28
                // [1][1]: (70*60)/100 = 42
                // Chi-square components:
                // (10-12)²/12 = 0.333
                // (20-18)²/18 = 0.222
                // (30-28)²/28 = 0.143
                // (40-42)²/42 = 0.095
                // Sum: 0.333 + 0.222 + 0.143 + 0.095 = 0.793 (expected)
                
                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                double result = chiSquareTest.chiSquare(counts);
                
                // Verify result matches expected value with delta for floating point precision
                assertEquals(0.793, result, 0.001);
                
                // If the mutation adds 1.0 to the result, this assertion would fail
                // as the result would be ~1.793 instead of ~0.793
            }

 @Test
           public void testChiSquareDetectsFirstElementSkipMutant() {
               ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
               
               // Create test data where first element makes significant contribution
               double[] expected = {10.0, 20.0, 30.0};  // First element is 10
               long[] observed = {15L, 25L, 35L};       // First element has deviation of 5
               
               // Calculate expected chi-square value manually including first element
               double manualSumSq = Math.pow(15-10, 2)/10.0 + 
                                   Math.pow(25-20, 2)/20.0 + 
                                   Math.pow(35-30, 2)/30.0;
               
               // Call the method
               double result = chiSquareTest.chiSquare(expected, observed);
               
               // Assert the result matches manual calculation
               assertEquals(manualSumSq, result, 1e-10);
               
               // Additional check: verify the result is not what we'd get if first element was skipped
               double mutantSumSq = Math.pow(25-20, 2)/20.0 + Math.pow(35-30, 2)/30.0;
               assertNotEquals(mutantSumSq, result, 1e-10);
           }

 @Test
           public void testChiSquareDetectsFirstRowSkippingMutant() {
               ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
               
               // Create a 2x2 contingency table where first row has significant values
               long[][] counts = {
                   {10, 20},  // This row would be skipped by the mutant
                   {30, 40}
               };
               
               // Calculate expected chi-square value manually
               // Row sums: 30, 70
               // Column sums: 40, 60
               // Total: 100
               // Expected values:
               // (30*40)/100 = 12, (30*60)/100 = 18
               // (70*40)/100 = 28, (70*60)/100 = 42
               // Chi-square components:
               // (10-12)^2/12 + (20-18)^2/18 + (30-28)^2/28 + (40-42)^2/42
               // = 4/12 + 4/18 + 4/28 + 4/42 ≈ 0.7937
               
               double expectedChiSquare = 0.7937;
               double actualChiSquare = chiSquareTest.chiSquare(counts);
               
               // Use delta of 0.0001 for floating point comparison
               assertEquals("Chi-square value should include first row data", 
                           expectedChiSquare, actualChiSquare, 0.0001);
               
               // Additional assertion to specifically check if first row was processed
               // If first row was skipped, the result would be much larger
               assertTrue("Result suggests first row was skipped", 
                          actualChiSquare < 1.0);
           }

 @Test
          public void testChiSquareDetectsSkippedElementsMutant() {
              // Setup
              ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
              double[] expected = {1.0, 2.0, 3.0, 4.0, 5.0}; // odd length array
              long[] observed = {1L, 3L, 2L, 5L, 4L}; // values differ at each position
              
              // Expected calculation:
              // sumExpected = 1+2+3+4+5 = 15
              // sumObserved = 1+3+2+5+4 = 15 (no rescaling needed)
              // For each i:
              // (obs-exp)^2/exp = 
              // (1-1)^2/1=0, (3-2)^2/2=0.5, (2-3)^2/3=0.333, (5-4)^2/4=0.25, (4-5)^2/5=0.2
              // Total sumSq = 0 + 0.5 + 0.333 + 0.25 + 0.2 = 1.283 (approx)
              
              // Action
              double result = chiSquareTest.chiSquare(expected, observed);
              
              // Assertion
              // Original would give ~1.283, mutant would only sum i=0,2,4: 0 + 0.333 + 0.2 = 0.533
              assertEquals(1.283, result, 0.001); // Tight delta to catch the mutant
              
              // Additional check to ensure all elements were processed
              // If mutant skips elements, sumObserved would be different
              // But in this case sums are equal by coincidence, so we need the precise value check
          }

 @Test
          public void testChiSquareWithSmallContingencyTable() {
              // Setup
              ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
              long[][] counts = {
                  {10, 10},
                  {20, 20}
              };
              
              // Expected calculations:
              // Row sums: [20, 40]
              // Column sums: [30, 30]
              // Total: 60
              // Expected values:
              // [20*30/60=10, 20*30/60=10]
              // [40*30/60=20, 40*30/60=20]
              // Chi-square components:
              // (10-10)²/10 + (10-10)²/10 + (20-20)²/20 + (20-20)²/20 = 0
              
              // Test
              double result = chiSquareTest.chiSquare(counts);
              
              // Verify
              assertEquals(0.0, result, 0.0001);
              
              // This test catches the mutant because:
              // - Mutant would only process counts[0][0] and counts[1][0]
              // - Would get row sums [10, 20], column sums [30, 0], total 30
              // - Expected values would be wrong
              // - Final chi-square would not be 0
          }

 @Test
         public void testChiSquareNoRescalingNeeded() {
             // Setup
             ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
             double[] expected = {10.0, 10.0, 10.0};  // Sum = 30.0
             long[] observed = {10L, 10L, 10L};       // Sum = 30.0
             
             // Expected calculation without rescaling:
             // For each element: (observed - expected)^2 / expected
             // All terms will be (10-10)^2/10 = 0
             // So sumSq should be 0.0
             
             // Execute
             double result = chiSquareTest.chiSquare(expected, observed);
             
             // Verify
             assertEquals(0.0, result, 1e-10);
             
             // This test catches the mutant because:
             // Original code: won't rescale (sums equal) → correct calculation
             // Mutant code: will always rescale → would calculate ratio=1.0 but use wrong branch
             // Even though ratio=1.0, the mutant uses the rescaling branch which is incorrect
         }

 @Test
         public void testChiSquareSmallDifferenceNoRescaling() {
             // Setup
             ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
             double[] expected = {10.0, 10.0, 10.0};  // Sum = 30.0
             long[] observed = {10L, 10L, 11L};       // Sum = 31.0 (difference < 10E-6)
             
             // Expected calculation without rescaling:
             // Terms: (10-10)^2/10 = 0, (10-10)^2/10 = 0, (11-10)^2/10 = 0.1
             // So sumSq should be 0.1
             
             // Execute
             double result = chiSquareTest.chiSquare(expected, observed);
             
             // Verify
             assertEquals(0.1, result, 1e-10);
             
             // This test catches the mutant because:
             // Original code: won't rescale (difference < threshold) → correct calculation
             // Mutant code: will rescale → would calculate ratio=31/30 and use wrong formula
         }

 @Test
         public void testChiSquareWithRescaleMutation1() {
             // Create test instance
             ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
             
             // Create input data that would require rescaling
             // Using very large numbers that might cause overflow without rescaling
             long[][] counts = {
                 {10000000000L, 20000000000L},
                 {30000000000L, 40000000000L}
             };
             
             // Calculate expected value manually
             double total = 10000000000L + 20000000000L + 30000000000L + 40000000000L;
             double[] rowSum = {10000000000L + 20000000000L, 30000000000L + 40000000000L};
             double[] colSum = {10000000000L + 30000000000L, 20000000000L + 40000000000L};
             
             double expectedSumSq = 0.0;
             for (int row = 0; row < 2; row++) {
                 for (int col = 0; col < 2; col++) {
                     double expected = (rowSum[row] * colSum[col]) / total;
                     expectedSumSq += Math.pow(counts[row][col] - expected, 2) / expected;
                 }
             }
             
             // Call method and assert
             double result = chiSquareTest.chiSquare(counts);
             assertEquals(expectedSumSq, result, 1e-8);
             
             // Also test with very small numbers that might underflow without rescaling
             long[][] smallCounts = {
                 {1, 2},
                 {3, 4}
             };
             
             double smallTotal = 1 + 2 + 3 + 4;
             double[] smallRowSum = {1 + 2, 3 + 4};
             double[] smallColSum = {1 + 3, 2 + 4};
             
             double smallExpectedSumSq = 0.0;
             for (int row = 0; row < 2; row++) {
                 for (int col = 0; col < 2; col++) {
                     double expected = (smallRowSum[row] * smallColSum[col]) / smallTotal;
                     smallExpectedSumSq += Math.pow(smallCounts[row][col] - expected, 2) / expected;
                 }
             }
             
             double smallResult = chiSquareTest.chiSquare(smallCounts);
             assertEquals(smallExpectedSumSq, smallResult, 1e-8);
         }

 @Test
        public void testChiSquareRescaleAccumulation() {
            // Setup
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            double[] expected = {1.0, 2.0, 3.0};  // Sum = 6.0
            long[] observed = {2L, 3L, 4L};       // Sum = 9.0 (will trigger rescaling)
            
            // Calculate expected result manually
            double ratio = 9.0 / 6.0;  // sumObserved/sumExpected
            double term1 = Math.pow(2 - 1*ratio, 2) / (1*ratio);
            double term2 = Math.pow(3 - 2*ratio, 2) / (2*ratio);
            double term3 = Math.pow(4 - 3*ratio, 2) / (3*ratio);
            double expectedSumSq = term1 + term2 + term3;
            
            // Execute
            double result = chiSquareTest.chiSquare(expected, observed);
            
            // Verify
            assertEquals("Chi-square sum should accumulate all terms", 
                         expectedSumSq, result, 1E-10);
            
            // Additional verification that mutant would fail:
            // If mutant is present, result would equal only term3 (~0.148148)
            // instead of the full sum (~0.555555)
            assertTrue("Result should be greater than any single term",
                       result > term1 && result > term2 && result > term3);
        }

 @Test
        public void testChiSquareDetectsSumAccumulationMutant() {
            // Create a simple 2x2 contingency table where all cells contribute to sum
            long[][] counts = {
                {10, 20},
                {30, 40}
            };
            
            ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
            
            // Calculate expected result manually
            // Row sums: 30, 70
            // Col sums: 40, 60
            // Total: 100
            // Expected values:
            // [0][0]: 30*40/100 = 12
            // [0][1]: 30*60/100 = 18
            // [1][0]: 70*40/100 = 28
            // [1][1]: 70*60/100 = 42
            // Chi-square components:
            // (10-12)²/12 = 0.333
            // (20-18)²/18 = 0.222
            // (30-28)²/28 = 0.143
            // (40-42)²/42 = 0.095
            // Total expected sum: ~0.333 + 0.222 + 0.143 + 0.095 = ~0.793
            
            double result = chiSquareTest.chiSquare(counts);
            
            // The mutant would only keep the last term (0.095)
            // So we assert the sum is greater than any single term would be
            assertTrue(result > 0.5); // Should be ~0.793
            // More precise assertion with delta for floating point
            assertEquals(0.793, result, 0.001);
        }

 @Test
       public void testChiSquareWithoutRescalingToDetectSubtractionMutant() {
           // Setup - create arrays where sums are equal (no rescaling needed)
           double[] expected = new double[]{10.0, 20.0, 30.0, 40.0};
           long[] observed = new long[]{10, 20, 30, 40};
           
           // Create test instance
           ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
           
           // Calculate expected result manually
           // For each term: (observed-expected)²/expected
           // All terms should be 0 since observed == expected
           double expectedResult = 0.0;
           
           // Call method and get actual result
           double actualResult = chiSquareTest.chiSquare(expected, observed);
           
           // Assertions
           // The mutant would give -0.0 instead of 0.0
           assertEquals(expectedResult, actualResult, 1e-10);
           
           // Additional check that the result is non-negative
           // This would fail with the mutant since it subtracts terms
           assertTrue(actualResult >= 0.0);
       }

 @Test
       public void testChiSquarePositiveResult() {
           // Setup - simple 2x2 contingency table
           long[][] counts = {
               {10, 20},
               {30, 40}
           };
           
           // Expected value calculated manually:
           // Row sums: 30, 70
           // Col sums: 40, 60
           // Total: 100
           // Expected values:
           // [12, 18]
           // [28, 42]
           // Chi-square components:
           // (10-12)²/12 + (20-18)²/18 + (30-28)²/28 + (40-42)²/42
           // = 4/12 + 4/18 + 4/28 + 4/42 ≈ 0.7937
           
           ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
           double result = chiSquareTest.chiSquare(counts);
           
           // Verify result is positive and approximately correct
           assertTrue("Chi-square result should be positive", result > 0);
           assertEquals(0.7937, result, 0.0001);
           
           // Additional test with all equal values should give 0
           long[][] equalCounts = {
               {10, 10},
               {10, 10}
           };
           double zeroResult = chiSquareTest.chiSquare(equalCounts);
           assertEquals(0.0, zeroResult, 0.0001);
       }

 @Test
      public void testChiSquareWithoutRescalingDetectsDivisionMutant() {
          // Setup - create test instance
          ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
          
          // Test data where sumObserved == sumExpected (no rescaling)
          // and expected values are not 1 to make division vs multiplication difference significant
          double[] expected = new double[]{2.0, 0.5};  // sum = 2.5
          long[] observed = new long[]{3, 0};         // sum = 3 (but will adjust to match)
          
          // Adjust observed to make sums equal (no rescaling)
          observed[1] = (long)(2.5 - observed[0]);  // 3 + x = 2.5 => x = -0.5, but must be non-negative
          // Need to adjust to make sums equal while keeping observed non-negative
          expected = new double[]{1.5, 1.0};  // sum = 2.5
          observed = new long[]{2, 1};        // sum = 3 (still not matching)
          // Better approach: make sums equal from start
          expected = new double[]{2.0, 1.0};  // sum = 3.0
          observed = new long[]{2, 1};        // sum = 3.0
          
          // Calculate expected result manually
          // For first element: (2-2)²/2 = 0
          // For second element: (1-1)²/1 = 0
          // Original would return 0 + 0 = 0
          // Mutant would return (2-2)²*2 + (1-1)²*1 = 0*2 + 0*1 = 0 (same)
          // Need different values where division vs multiplication shows difference
          
          // Better test data:
          expected = new double[]{2.0, 1.0};  // sum = 3.0
          observed = new long[]{3, 0};        // sum = 3.0
          
          // Manual calculation:
          // Original: (3-2)²/2 + (0-1)²/1 = 1/2 + 1/1 = 1.5
          // Mutant: (3-2)²*2 + (0-1)²*1 = 1*2 + 1*1 = 3.0
          
          // Execute
          double result = chiSquareTest.chiSquare(expected, observed);
          
          // Verify - should be 1.5 (original), mutant would return 3.0
          assertEquals(1.5, result, 1e-10);
      }

 @Test
      public void testChiSquareDetectsDivisionToMultiplicationMutant() {
          // Create a simple 2x2 contingency table
          long[][] counts = {
              {10, 20},
              {30, 40}
          };
          
          // Expected chi-square value calculated manually using correct formula
          // Row sums: 30, 70
          // Column sums: 40, 60
          // Total: 100
          // Expected values:
          // [0][0]: (30*40)/100 = 12
          // [0][1]: (30*60)/100 = 18
          // [1][0]: (70*40)/100 = 28
          // [1][1]: (70*60)/100 = 42
          // Chi-square contributions:
          // [0][0]: (10-12)²/12 = 0.333
          // [0][1]: (20-18)²/18 = 0.222
          // [1][0]: (30-28)²/28 = 0.143
          // [1][1]: (40-42)²/42 = 0.095
          // Total: ~0.333 + 0.222 + 0.143 + 0.095 = 0.793
          
          // With mutant (multiplying by expected instead of dividing):
          // [0][0]: (10-12)²*12 = 48
          // [0][1]: (20-18)²*18 = 72
          // [1][0]: (30-28)²*28 = 112
          // [1][1]: (40-42)²*42 = 168
          // Total: 48 + 72 + 112 + 168 = 400
          
          ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
          double result = chiSquareTest.chiSquare(counts);
          
          // The correct result should be approximately 0.793
          // The mutant would give 400
          // We use a delta of 0.001 for floating point comparison
          assertEquals(0.793, result, 0.001);
          
          // Additionally, verify the result is not the mutant's output
          // The mutant's output would be much larger (400)
          assertTrue(result < 1.0);
      }

 @Test
     public void testChiSquareAccumulatesSumWhenNoRescaling() {
         // Setup
         ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
         double[] expected = new double[]{2.0, 3.0, 5.0}; // Sum = 10
         long[] observed = new long[]{2, 3, 5}; // Sum = 10 (no rescaling needed)
         
         // Calculate expected result manually
         // For first element: (2-2)²/2 = 0
         // Second element: (3-3)²/3 = 0
         // Third element: (5-5)²/5 = 0
         double expectedSumSq = 0.0;
         
         // Execute
         double result = chiSquareTest.chiSquare(expected, observed);
         
         // Verify
         assertEquals("Chi-square sum should accumulate all elements' contributions", 
                     expectedSumSq, result, 1E-10);
         
         // Now test with non-zero deviations
         observed = new long[]{3, 2, 6}; // Same sum but different distribution
         // First element: (3-2)²/2 = 0.5
         // Second element: (2-3)²/3 ≈ 0.333
         // Third element: (6-5)²/5 = 0.2
         expectedSumSq = 0.5 + (1.0/3.0) + 0.2;
         
         result = chiSquareTest.chiSquare(expected, observed);
         assertEquals("Chi-square sum should accumulate all elements' contributions", 
                     expectedSumSq, result, 1E-10);
     }

 @Test
     public void testChiSquareDetectsSumSqMutation() {
         // Create a 2x2 contingency table where multiple cells contribute to the sum
         long[][] counts = {
             {10, 20},
             {30, 40}
         };
         
         ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
         
         // Calculate expected result manually
         // Row sums: 30, 70
         // Column sums: 40, 60
         // Total: 100
         // Expected values:
         // Cell[0][0]: (30*40)/100 = 12
         // Cell[0][1]: (30*60)/100 = 18
         // Cell[1][0]: (70*40)/100 = 28
         // Cell[1][1]: (70*60)/100 = 42
         // Chi-square components:
         // (10-12)²/12 = 0.333...
         // (20-18)²/18 = 0.222...
         // (30-28)²/28 = 0.142...
         // (40-42)²/42 = 0.095...
         // Total sum should be ~0.333 + 0.222 + 0.142 + 0.095 = ~0.792
         
         double result = chiSquareTest.chiSquare(counts);
         
         // The mutated version would only return the last component (0.095)
         // So we assert the result is greater than any single component
         assertTrue(result > 0.3); // Should be ~0.792
         assertTrue(result > 0.2); // Either of these would catch the mutation
         assertEquals(0.792, result, 0.001); // Exact value with tolerance
     }

 @Test
    public void testChiSquareRescalingThreshold() {
        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
        
        // Create test data where difference is between 10E-6 and 10E-5
        double[] expected = {1.000005, 1.000005}; // sum = 2.00001
        long[] observed = {1L, 1L};                // sum = 2.0
        double difference = Math.abs(2.00001 - 2.0); // 0.00001
        
        // Verify difference is in target range
        assertTrue(difference > 10E-6);  // Original would rescale
        assertTrue(difference <= 10E-5); // Mutant wouldn't rescale
        
        // Calculate expected value with rescaling (original behavior)
        double ratio = 2.0 / 2.00001;
        double dev1 = (1.0 - ratio * 1.000005);
        double dev2 = (1.0 - ratio * 1.000005);
        double expectedSumSq = (dev1 * dev1 / (ratio * 1.000005)) + 
                              (dev2 * dev2 / (ratio * 1.000005));
        
        // Calculate actual value
        double actualSumSq = chiSquareTest.chiSquare(expected, observed);
        
        // Assert with tolerance to account for floating point precision
        assertEquals(expectedSumSq, actualSumSq, 10E-10);
        
        // The mutant would return a different value since it wouldn't rescale
        // This assertion will fail for the mutant but pass for original
    }

 @Test
    public void testChiSquareWithPrecisionDifference() {
        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
        
        // Create a contingency table where row/column sums will create
        // a small precision difference in calculations
        long[][] counts = {
            {1000000001L, 1000000000L},
            {1000000000L, 1000000001L}
        };
        
        // Calculate expected chi-square value
        double result = chiSquareTest.chiSquare(counts);
        
        // The key is that with these large numbers, floating point calculations
        // will have small precision differences that should be caught by 10E-6
        // but would be missed by 10E-5
        
        // Verify the result is within expected range
        // The exact value isn't as important as verifying the precision check works
        assertTrue(result > 0.0);
        assertTrue(result < 1.0);  // Should be very small for this symmetric case
        
        // The test will pass with original code but fail with mutant because:
        // - Original would catch the precision difference (10E-6)
        // - Mutant would miss it (10E-5 threshold too large)
    }

 @Test
   public void testChiSquareCapturesAllElements() {
       // Setup
       ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
       double[] expected = new double[]{1.0, 1.0};  // Minimum length of 2
       long[] observed = new long[]{2, 3};         // Last element differs
       
       // Action
       double result = chiSquareTest.chiSquare(expected, observed);
       
       // Verification
       // Calculate expected value manually including both elements
       double sumExpected = 1.0 + 1.0;
       double sumObserved = 2 + 3;
       double ratio = sumObserved / sumExpected;
       double dev1 = (2 - ratio * 1.0);
       double dev2 = (3 - ratio * 1.0);
       double expectedSumSq = (dev1 * dev1 / (ratio * 1.0)) + (dev2 * dev2 / (ratio * 1.0));
       
       assertEquals(expectedSumSq, result, 1e-10);
       
       // Additional test with more elements to be thorough
       double[] expected2 = new double[]{1.0, 1.0, 2.0};
       long[] observed2 = new long[]{1, 1, 5};  // Last element contributes significantly
       
       double result2 = chiSquareTest.chiSquare(expected2, observed2);
       
       // If mutant skips last element, result2 would be much smaller
       assertTrue(result2 > 1.0);  // Actual value should be around 2.25
   }

 @Test
   public void testChiSquareDetectsAllRows() {
       // Create a contingency table where last row has significant values
       long[][] counts = {
           {10, 20, 30},
           {15, 25, 35},
           {5, 10, 15}  // This row would be skipped by the mutant
       };
       
       ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
       
       // Calculate expected chi-square value manually
       // Row sums: 60, 75, 30
       // Col sums: 30, 55, 80
       // Total: 165
       // Expected values for last row cells: (30*30)/165≈5.45, (30*55)/165≈10, (30*80)/165≈14.55
       // Chi-square contributions from last row: 
       // ((5-5.45)^2)/5.45 + ((10-10)^2)/10 + ((15-14.55)^2)/14.55 ≈ 0.037 + 0 + 0.014 ≈ 0.051
       // Total chi-square should include this contribution
       
       double result = chiSquareTest.chiSquare(counts);
       
       // Verify result is greater than 0 (basic sanity check)
       assertTrue(result > 0);
       
       // Create same data without last row to simulate mutant behavior
       long[][] mutantCounts = {
           {10, 20, 30},
           {15, 25, 35}
       };
       double mutantResult = chiSquareTest.chiSquare(mutantCounts);
       
       // The real result should be different from mutant result
       assertNotEquals(mutantResult, result, 0.0001);
       
       // More precise check - last row contributes about 0.051 to chi-square
       assertTrue(result > mutantResult);
       assertEquals(result, mutantResult + 0.051, 0.01);
   }

 @Test
  public void testChiSquareShouldProcessAllElements() {
      // Setup
      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
      double[] expected = new double[]{10.0, 10.0, 10.0, 100.0}; // Last element is large
      long[] observed = new long[]{10, 10, 10, 50}; // Large deviation in last element
      
      // Expected value calculation (manually computed)
      // For first 3 elements: (10-10)²/10 = 0
      // For last element: (50-100)²/100 = 2500/100 = 25
      // Total expected chi-square: 0 + 0 + 0 + 25 = 25
      
      // Action
      double result = chiSquareTest.chiSquare(expected, observed);
      
      // Assertion
      assertEquals("Chi-square should include all elements in calculation", 
                  25.0, result, 1E-10);
      
      // Additional test with different array configuration
      double[] expected2 = new double[]{1.0, 1.0, 1.0, 1.0, 10.0};
      long[] observed2 = new long[]{1, 1, 1, 1, 20}; // Deviation only in last element
      // Expected: (20-10)²/10 = 100/10 = 10
      double result2 = chiSquareTest.chiSquare(expected2, observed2);
      assertEquals("Chi-square should properly process last element", 
                  10.0, result2, 1E-10);
  }

 @Test
  public void testChiSquareDetectsAllRows1() {
      // Setup
      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
      long[][] counts = new long[][] {
          {10, 20, 30},  // row 1
          {15, 25, 35},  // row 2
          {5, 10, 15}    // row 3 - this would be skipped by the mutant
      };
      
      // Calculate expected value manually
      // Row sums: 60, 75, 30
      // Col sums: 30, 55, 80
      // Total: 165
      // Expected values:
      // row1: (60*30)/165=10.909, (60*55)/165=20, (60*80)/165=29.091
      // row2: (75*30)/165=13.636, (75*55)/165=25, (75*80)/165=36.364
      // row3: (30*30)/165=5.4545, (30*55)/165=10, (30*80)/165=14.545
      // Chi-square contributions:
      // row1: (10-10.909)^2/10.909 + (20-20)^2/20 + (30-29.091)^2/29.091 ≈ 0.0756 + 0 + 0.0289 ≈ 0.1045
      // row2: (15-13.636)^2/13.636 + (25-25)^2/25 + (35-36.364)^2/36.364 ≈ 0.1364 + 0 + 0.0513 ≈ 0.1877
      // row3: (5-5.4545)^2/5.4545 + (10-10)^2/10 + (15-14.545)^2/14.545 ≈ 0.0379 + 0 + 0.0145 ≈ 0.0524
      // Total chi-square ≈ 0.1045 + 0.1877 + 0.0524 ≈ 0.3446
      
      // Action
      double result = chiSquareTest.chiSquare(counts);
      
      // Assertion
      assertEquals(0.3446, result, 0.0001);
      
      // This test will fail if the mutant skips the last row, as the result would be
      // approximately 0.2922 (missing the 0.0524 contribution from row 3)
  }

 @Test
 public void testChiSquareInvalidInputsThrowsCorrectException() {
     ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
     double[] expected = new double[] {1.0, -1.0}; // Contains negative value (invalid)
     long[] observed = new long[] {10L, 20L}; // Valid observed
     
     try {
         chiSquareTest.chiSquare(expected, observed);
         fail("Expected IllegalArgumentException");
     } catch (IllegalArgumentException e) {
         // Verify exact exception message to ensure it came from the correct validation check
         assertEquals("observed counts must be non-negative and expected counts must be postive", 
                      e.getMessage());
     }
     
     // Also test case where observed is negative
     expected = new double[] {1.0, 1.0}; // Valid expected
     observed = new long[] {10L, -20L}; // Contains negative observed
     
     try {
         chiSquareTest.chiSquare(expected, observed);
         fail("Expected IllegalArgumentException");
     } catch (IllegalArgumentException e) {
         assertEquals("observed counts must be non-negative and expected counts must be postive", 
                      e.getMessage());
     }
 }

 @Test
 public void testChiSquareWithInvalidInputs() {
     ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
     
     // Test case with negative observed values
     long[][] negativeObserved = {{1, -1}, {1, 1}};
     try {
         chiSquareTest.chiSquare(negativeObserved);
         fail("Expected IllegalArgumentException for negative observed values");
     } catch (IllegalArgumentException e) {
         // Expected behavior
     }
     
     // Test case with zero expected values
     long[][] zeroExpected = {{0, 0}, {0, 0}};
     try {
         chiSquareTest.chiSquare(zeroExpected);
         fail("Expected IllegalArgumentException for zero expected values");
     } catch (IllegalArgumentException e) {
         // Expected behavior
     }
     
     // Test case with valid inputs to ensure normal execution
     long[][] validInput = {{10, 10}, {10, 10}};
     double result = chiSquareTest.chiSquare(validInput);
     assertTrue("Result should be positive for valid input", result >= 0);
 }

}
