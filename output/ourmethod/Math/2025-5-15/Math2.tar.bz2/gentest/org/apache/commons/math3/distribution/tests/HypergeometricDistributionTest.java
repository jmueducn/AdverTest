package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
 
public class HypergeometricDistributionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                                    public void testGetNumericalMean_NormalCase() {
                                        HypergeometricDistribution dist = new HypergeometricDistribution(
                                            new Well19937c(), 100, 30, 10);
                                        double expected = 10 * (30 / 100.0);
                                        assertEquals(expected, dist.getNumericalMean(), 0.0001);
                                    }

 @Test
                                    public void testGetNumericalMean_AllSuccesses() {
                                        HypergeometricDistribution dist = new HypergeometricDistribution(
                                            new Well19937c(), 100, 100, 10);
                                        double expected = 10 * (100 / 100.0);
                                        assertEquals(expected, dist.getNumericalMean(), 0.0001);
                                    }

 @Test
                                    public void testGetNumericalMean_NoSuccesses() {
                                        HypergeometricDistribution dist = new HypergeometricDistribution(
                                            new Well19937c(), 100, 0, 10);
                                        double expected = 10 * (0 / 100.0);
                                        assertEquals(expected, dist.getNumericalMean(), 0.0001);
                                    }

 @Test
                                    public void testGetNumericalMean_FullSample() {
                                        HypergeometricDistribution dist = new HypergeometricDistribution(
                                            new Well19937c(), 100, 30, 100);
                                        double expected = 100 * (30 / 100.0);
                                        assertEquals(expected, dist.getNumericalMean(), 0.0001);
                                    }

 @Test
                                    public void testGetNumericalMean_SampleSizeOne() {
                                        HypergeometricDistribution dist = new HypergeometricDistribution(
                                            new Well19937c(), 100, 30, 1);
                                        double expected = 1 * (30 / 100.0);
                                        assertEquals(expected, dist.getNumericalMean(), 0.0001);
                                    }

 @Test
                                    public void testGetNumericalMean_PrecisionTest() {
                                        HypergeometricDistribution dist = new HypergeometricDistribution(
                                            new Well19937c(), 7, 3, 2);
                                        double expected = 2 * (3 / 7.0);
                                        assertEquals(expected, dist.getNumericalMean(), 0.0000000001);
                                    }

 @Test
                                    public void testGetNumericalMean_LargeNumbers() {
                                        HypergeometricDistribution dist = new HypergeometricDistribution(
                                            new Well19937c(), 1000000, 300000, 100000);
                                        double expected = 100000 * (300000 / 1000000.0);
                                        assertEquals(expected, dist.getNumericalMean(), 0.0001);
                                    }

 @Test
                                    public void testGetNumericalMean_InvalidPopulationSize() {
                                        thrown.expect(NotStrictlyPositiveException.class);
                                        new HypergeometricDistribution(new Well19937c(), 0, 30, 10);
                                    }

 @Test
                                    public void testGetNumericalMean_NegativeSuccesses() {
                                        thrown.expect(NotPositiveException.class);
                                        new HypergeometricDistribution(new Well19937c(), 100, -1, 10);
                                    }

 @Test
                                    public void testGetNumericalMean_NegativeSampleSize() {
                                        thrown.expect(NotPositiveException.class);
                                        new HypergeometricDistribution(new Well19937c(), 100, 30, -1);
                                    }

 @Test
                                    public void testGetNumericalMean_SuccessesExceedPopulation() {
                                        thrown.expect(NumberIsTooLargeException.class);
                                        new HypergeometricDistribution(new Well19937c(), 100, 101, 10);
                                    }

 @Test
                                    public void testGetNumericalMean_SampleExceedsPopulation() {
                                        thrown.expect(NumberIsTooLargeException.class);
                                        new HypergeometricDistribution(new Well19937c(), 100, 30, 101);
                                    }

 @Test
                                public void testInnerCumulativeProbabilityDetectsInitialProbabilityMutation() {
                                    // Create a mock object to control probability values
                                    HypergeometricDistribution distribution = mock(HypergeometricDistribution.class);
                                    
                                    // Setup test values
                                    int x0 = 5;
                                    int x1 = 5;  // Same as x0 to test no-iteration case
                                    int dx = 1;
                                    double expectedProbability = 0.3;
                                    
                                    // Stub the probability method to return our test value
                                    when(distribution.probability(x0)).thenReturn(expectedProbability);
                                    
                                    // Call the method (using reflection since it's private)
                                    try {
                                        java.lang.reflect.Method method = HypergeometricDistribution.class
                                            .getDeclaredMethod("innerCumulativeProbability", int.class, int.class, int.class);
                                        method.setAccessible(true);
                                        double result = (double) method.invoke(distribution, x0, x1, dx);
                                        
                                        // Verify the result matches expected probability
                                        assertEquals("Initial probability should be included in the sum", 
                                                    expectedProbability, result, 0.0001);
                                        
                                        // Verify probability(x0) was called exactly once
                                        verify(distribution, times(1)).probability(x0);
                                    } catch (Exception e) {
                                        fail("Exception occurred during test: " + e.getMessage());
                                    }
                                }

 @Test
                                public void testInnerCumulativeProbabilityWithSmallRange() {
                                    // Create a mock object to control probability values
                                    HypergeometricDistribution distribution = mock(HypergeometricDistribution.class);
                                    
                                    // Setup test values
                                    int x0 = 5;
                                    int x1 = 6;  // One step above x0
                                    int dx = 1;
                                    double prob1 = 0.3;
                                    double prob2 = 0.2;
                                    double expectedSum = prob1 + prob2;
                                    
                                    // Stub the probability method
                                    when(distribution.probability(x0)).thenReturn(prob1);
                                    when(distribution.probability(x1)).thenReturn(prob2);
                                    
                                    // Call the method (using reflection since it's private)
                                    try {
                                        java.lang.reflect.Method method = HypergeometricDistribution.class
                                            .getDeclaredMethod("innerCumulativeProbability", int.class, int.class, int.class);
                                        method.setAccessible(true);
                                        double result = (double) method.invoke(distribution, x0, x1, dx);
                                        
                                        // Verify the result matches expected sum
                                        assertEquals("Sum should include both probabilities", 
                                                    expectedSum, result, 0.0001);
                                        
                                        // Verify probability was called for both points
                                        verify(distribution, times(1)).probability(x0);
                                        verify(distribution, times(1)).probability(x1);
                                    } catch (Exception e) {
                                        fail("Exception occurred during test: " + e.getMessage());
                                    }
                                }

 @Test
                          public void testInnerCumulativeProbabilityDetectsMutant() throws Exception {
                              // Create test instance with arbitrary valid parameters
                              HypergeometricDistribution distribution = new HypergeometricDistribution(10, 5, 3);
                              
                              // Mock the probability method to return known values
                              HypergeometricDistribution spyDist = spy(distribution);
                              when(spyDist.probability(anyInt())).thenReturn(0.1);
                              
                              // Test parameters where x0 != x1 (should execute loop in original)
                              int x0 = 0;
                              int x1 = 2;
                              int dx = 1;
                              
                              // Use reflection to access the private method
                              Method method = HypergeometricDistribution.class.getDeclaredMethod(
                                  "innerCumulativeProbability", int.class, int.class, int.class);
                              method.setAccessible(true);
                              
                              // Call the method
                              double result = (double) method.invoke(spyDist, x0, x1, dx);
                              
                              // Verify behavior
                              // Original should return 0.3 (0.1 + 0.1 + 0.1)
                              // Mutant would return just 0.1 (only first probability)
                              assertEquals(0.3, result, 0.0001);
                              
                              // Verify probability was called multiple times (3 times: x0, x0+dx, x0+2dx)
                              verify(spyDist, times(3)).probability(anyInt());
                          }

 @Test
                     public void testInnerCumulativeProbabilityDetectsDirectionMutation() throws Exception {
                         // Create test hypergeometric distribution
                         HypergeometricDistribution dist = new HypergeometricDistribution(100, 50, 10);
                         
                         // Test parameters - x0 < x1 with positive dx
                         int x0 = 2;
                         int x1 = 5;
                         int dx = 1;
                         
                         // Calculate expected result manually
                         double expected = 0.0;
                         for (int x = x0; x <= x1; x += dx) {
                             expected += dist.probability(x);
                         }
                         
                         // Use reflection to access private method
                         Method innerCumulativeProbability = HypergeometricDistribution.class.getDeclaredMethod(
                             "innerCumulativeProbability", int.class, int.class, int.class);
                         innerCumulativeProbability.setAccessible(true);
                         double actual = (Double) innerCumulativeProbability.invoke(dist, x0, x1, dx);
                         
                         // Assert the result matches expected cumulative probability
                         assertEquals("Cumulative probability should sum from x0 to x1", 
                                    expected, actual, 1e-10);
                         
                         // Additional check to ensure we're testing the right direction
                         // Calculate what mutant would return (if it terminated)
                         double mutantExpected = 0.0;
                         for (int x = x0; x >= x1; x -= dx) {
                             mutantExpected += dist.probability(x);
                         }
                         // Ensure our actual result doesn't match the mutant's expected result
                         assertNotEquals("Result should not match mutant behavior", 
                                        mutantExpected, actual, 1e-10);
                     }

 @Test
                public void testInnerCumulativeProbabilityDetectsX0EqualsDxMutant() throws Exception {
                    // Create a test instance
                    HypergeometricDistribution dist = new HypergeometricDistribution(10, 5, 3);
                    
                    // Mock the probability method to return different values at different x
                    // This is important because if probability(x) returns same value always,
                    // the mutant might not be detected
                    HypergeometricDistribution spyDist = spy(dist);
                    when(spyDist.probability(1)).thenReturn(0.1);
                    when(spyDist.probability(2)).thenReturn(0.2);
                    when(spyDist.probability(3)).thenReturn(0.3);
                    
                    // Test parameters where x0 != x1 and dx != x1
                    int x0 = 1;
                    int x1 = 3;
                    int dx = 1;
                    
                    // Expected result: probability(1) + probability(2) + probability(3) = 0.1 + 0.2 + 0.3 = 0.6
                    double expected = 0.6;
                    
                    // Use reflection to access the private method
                    Method innerCumulativeProbabilityMethod = HypergeometricDistribution.class.getDeclaredMethod(
                        "innerCumulativeProbability", int.class, int.class, int.class);
                    innerCumulativeProbabilityMethod.setAccessible(true);
                    
                    // Actual result from the method
                    double actual = (double) innerCumulativeProbabilityMethod.invoke(spyDist, x0, x1, dx);
                    
                    // Assert the result matches expected
                    assertEquals(expected, actual, 0.0001);
                    
                    // Verify probability was called with the correct sequence of x values
                    verify(spyDist).probability(1);
                    verify(spyDist).probability(2);
                    verify(spyDist).probability(3);
                }

 @Test
            public void testInnerCumulativeProbabilityDetectsAccumulationMutant() {
                // Create a mock HypergeometricDistribution to control probability() behavior
                HypergeometricDistribution distribution = mock(HypergeometricDistribution.class);
                
                // Setup probability() to return known values in sequence
                when(distribution.probability(1)).thenReturn(0.1);
                when(distribution.probability(2)).thenReturn(0.2);
                when(distribution.probability(3)).thenReturn(0.3);
                
                try {
                    // Use reflection to access the private method
                    Method method = HypergeometricDistribution.class.getDeclaredMethod(
                        "innerCumulativeProbability", int.class, int.class, int.class);
                    method.setAccessible(true);
                    
                    // Test with range that requires multiple iterations (1 to 3 with step 1)
                    double result = (double) method.invoke(distribution, 1, 3, 1);
                    
                    // Verify the result is the SUM of probabilities (0.1 + 0.2 + 0.3 = 0.6)
                    // This will fail if mutant is present (would only return last probability 0.3)
                    assertEquals(0.6, result, 0.0001);
                    
                    // Verify probability() was called for each value in the range
                    verify(distribution).probability(1);
                    verify(distribution).probability(2);
                    verify(distribution).probability(3);
                } catch (Exception e) {
                    fail("Exception occurred during test: " + e.getMessage());
                }
            }

 @Test
          public void testInnerCumulativeProbabilityDetectsSubtractionMutant() {
              // Setup test data
              int x0 = 0;
              int x1 = 2;
              int dx = 1;
              
              // Create mock of HypergeometricDistribution
              HypergeometricDistribution distribution = mock(HypergeometricDistribution.class);
              
              // Stub probability() method to return known values
              when(distribution.probability(0)).thenReturn(0.1);
              when(distribution.probability(1)).thenReturn(0.2);
              when(distribution.probability(2)).thenReturn(0.3);
              
              try {
                  // Call the method (using reflection since it's private)
                  Method method = HypergeometricDistribution.class.getDeclaredMethod(
                      "innerCumulativeProbability", int.class, int.class, int.class);
                  method.setAccessible(true);
                  double result = (double) method.invoke(distribution, x0, x1, dx);
                  
                  // Verify the result is the sum of probabilities (0.1 + 0.2 + 0.3 = 0.6)
                  assertEquals(0.6, result, 0.0001);
                  
                  // Verify the probability method was called with expected values
                  verify(distribution).probability(0);
                  verify(distribution).probability(1);
                  verify(distribution).probability(2);
              } catch (NoSuchMethodException e) {
                  fail("Method innerCumulativeProbability not found");
              } catch (IllegalAccessException e) {
                  fail("Illegal access to innerCumulativeProbability method");
              } catch (InvocationTargetException e) {
                  fail("Exception thrown by innerCumulativeProbability method");
              }
          }

 @Test
     public void testInnerCumulativeProbability_DetectsReturnZeroMutant() throws Exception {
         // Setup
         HypergeometricDistribution distribution = new HypergeometricDistribution(10, 5, 3);
         
         // Mock probability() method to return known values
         HypergeometricDistribution spyDistribution = spy(distribution);
         when(spyDistribution.probability(anyInt())).thenReturn(0.1, 0.2, 0.3);
         
         // Test parameters - should produce non-zero result
         int x0 = 1;
         int x1 = 3;
         int dx = 1;
         
         // Expected: 0.1 (x0=1) + 0.2 (x0=2) + 0.3 (x0=3) = 0.6
         double expected = 0.6;
         
         // Use reflection to access private method
         Method method = HypergeometricDistribution.class.getDeclaredMethod(
             "innerCumulativeProbability", int.class, int.class, int.class);
         method.setAccessible(true);
         double actual = (double) method.invoke(spyDistribution, x0, x1, dx);
         
         // Assertions to catch the mutant
         assertNotEquals(0.0, actual, 0.0001); // This would fail if mutant is present
         assertEquals(expected, actual, 0.0001); // Verify correct calculation
         
         // Verify probability() was called 3 times (for x0=1,2,3)
         verify(spyDistribution, times(3)).probability(anyInt());
     }

 @Test
 public void testInnerCumulativeProbabilityDetectsMutant1() {
     // Setup values where sampleSize != numberOfSuccesses
     int populationSize = 1000;
     int numberOfSuccesses = 200;
     int sampleSize = 500;
     
     // Create test instance
     HypergeometricDistribution distribution = 
         new HypergeometricDistribution(populationSize, numberOfSuccesses, sampleSize);
     
     // Calculate expected value manually using correct formula
     double expected = sampleSize * (numberOfSuccesses / (double) populationSize);
     
     // The mutation would produce:
     double mutated = numberOfSuccesses * (sampleSize / (double) populationSize);
     
     // While mathematically equal, we test with exact floating point comparison
     // to detect any potential differences in calculation order
     double actual = distribution.probability(0); // probability() uses the same calculation
     
     // Assert exact equality to catch any floating point differences
     assertEquals("Test should detect multiplication order mutation", 
                 expected, actual, 0.0);
     
     // Additional test with different values to ensure robustness
     populationSize = Integer.MAX_VALUE;
     numberOfSuccesses = Integer.MAX_VALUE / 2;
     sampleSize = Integer.MAX_VALUE / 4;
     distribution = new HypergeometricDistribution(populationSize, numberOfSuccesses, sampleSize);
     
     expected = sampleSize * (numberOfSuccesses / (double) populationSize);
     actual = distribution.probability(0);
     assertEquals("Test should detect potential overflow differences",
                 expected, actual, 0.0);
 }

}
