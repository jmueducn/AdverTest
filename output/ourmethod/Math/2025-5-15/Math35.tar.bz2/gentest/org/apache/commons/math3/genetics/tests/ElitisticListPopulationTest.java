package gentest.org.apache.commons.math3.genetics.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.genetics.*;
import java.util.Collections;
import java.util.List;
import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
 
public class ElitisticListPopulationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                          public void testConstructor_NullChromosomesList() {
                                                              // Expect exception
                                                              thrown.expect(IllegalArgumentException.class);
                                                              thrown.expectMessage("list of chromosomes");
                                                      
                                                              // Test
                                                              new ElitisticListPopulation(null, 10, 0.1);
                                                          }

 @Test
                                                          public void testConstructor_EmptyChromosomesList() {
                                                              // Setup
                                                              List<Chromosome> chromosomes = new ArrayList<>();
                                                      
                                                              // Expect exception
                                                              thrown.expect(IllegalArgumentException.class);
                                                              thrown.expectMessage("list of chromosomes");
                                                      
                                                              // Test
                                                              new ElitisticListPopulation(chromosomes, 10, 0.1);
                                                          }

 @Test
                                                          public void testConstructor_ValidParameters() {
                                                              // Test with normal valid parameters
                                                              ElitisticListPopulation population = new ElitisticListPopulation(100, 0.2);
                                                              assertEquals(100, population.getPopulationLimit());
                                                              assertEquals(0.2, population.getElitismRate(), 0.0001);
                                                          }

 @Test
                                                          public void testConstructor_ZeroElitismRate() {
                                                              // Test with 0.0 elitism rate (valid boundary case)
                                                              ElitisticListPopulation population = new ElitisticListPopulation(50, 0.0);
                                                              assertEquals(0.0, population.getElitismRate(), 0.0001);
                                                          }

 @Test
                                                          public void testConstructor_MaxElitismRate() {
                                                              // Test with 1.0 elitism rate (valid boundary case)
                                                              ElitisticListPopulation population = new ElitisticListPopulation(50, 1.0);
                                                              assertEquals(1.0, population.getElitismRate(), 0.0001);
                                                          }

 @Test
                                                          public void testConstructor_ZeroPopulationLimit() {
                                                              // Test with zero population limit (edge case)
                                                              ElitisticListPopulation population = new ElitisticListPopulation(0, 0.5);
                                                              assertEquals(0, population.getPopulationLimit());
                                                              assertEquals(0.5, population.getElitismRate(), 0.0001);
                                                          }

 @Test
                                                  public void testConstructor_ElitismRateAboveOne() {
                                                      // Test with elitism rate > 1.0 (should throw exception)
                                                      try {
                                                          new ElitisticListPopulation(100, 1.1);
                                                          fail("Expected IllegalArgumentException for elitism rate > 1.0");
                                                      } catch (IllegalArgumentException e) {
                                                          // Expected exception
                                                      }
                                                  }

 @Test
                                              public void testConstructor_NegativeElitismRate() {
                                                  // Test with negative elitism rate (should throw exception)
                                                  org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                  exception.expect(IllegalArgumentException.class);
                                                  new ElitisticListPopulation(100, -0.1);
                                              }

 @Test
                                              public void testConstructor_NegativePopulationLimit() {
                                                  // Test with negative population limit (should throw exception from parent class)
                                                  ExpectedException exception = ExpectedException.none();
                                                  exception.expect(IllegalArgumentException.class);
                                                  new ElitisticListPopulation(-10, 0.5);
                                              }

 @Test
                                      public void testConstructor_NormalParameters() {
                                          // Setup
                                          org.apache.commons.math3.genetics.Chromosome chr1 = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                          org.apache.commons.math3.genetics.Chromosome chr2 = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                          java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = java.util.Arrays.asList(chr1, chr2);
                                          int populationLimit = 10;
                                          double elitismRate = 0.2;
                                          
                                          // Test
                                          org.apache.commons.math3.genetics.ElitisticListPopulation population = new org.apache.commons.math3.genetics.ElitisticListPopulation(
                                              chromosomes, populationLimit, elitismRate);
                                          
                                          // Verify
                                          assertEquals(2, population.getPopulationSize());
                                          assertEquals(10, population.getPopulationLimit());
                                          assertEquals(0.2, population.getElitismRate(), 0.0001);
                                      }

 @Test
          public void testConstructor_PopulationLimitEdgeCases() {
              // Setup
              org.apache.commons.math3.genetics.Chromosome chr1 = new org.apache.commons.math3.genetics.Chromosome() {
                  @Override
                  public double fitness() {
                      return 0;
                  }
              };
              org.apache.commons.math3.genetics.Chromosome chr2 = new org.apache.commons.math3.genetics.Chromosome() {
                  @Override
                  public double fitness() {
                      return 0;
                  }
              };
              java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
                  java.util.Arrays.asList(chr1, chr2);
              double elitismRate = 0.1;
              
              // Test minimum population limit (same as size)
              org.apache.commons.math3.genetics.ElitisticListPopulation pop1 = 
                  new org.apache.commons.math3.genetics.ElitisticListPopulation(
                      chromosomes, 2, elitismRate);
              assertEquals(2, pop1.getPopulationLimit());
              
              // Test larger population limit
              org.apache.commons.math3.genetics.ElitisticListPopulation pop2 = 
                  new org.apache.commons.math3.genetics.ElitisticListPopulation(
                      chromosomes, 100, elitismRate);
              assertEquals(100, pop2.getPopulationLimit());
          }

 @Test
      public void testConstructor_EdgeCaseElitismRates() {
          // Setup
          org.apache.commons.math3.genetics.Chromosome chr = new org.apache.commons.math3.genetics.Chromosome() {
              @Override
              public double fitness() {
                  return 0;
              }
          };
          java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
              java.util.Arrays.asList(chr);
          
          // Test 0.0 elitism rate
          org.apache.commons.math3.genetics.ElitisticListPopulation pop1 = 
              new org.apache.commons.math3.genetics.ElitisticListPopulation(
                  chromosomes, 1, 0.0);
          assertEquals(0.0, pop1.getElitismRate(), 0.0001);
          
          // Test 1.0 elitism rate
          org.apache.commons.math3.genetics.ElitisticListPopulation pop2 = 
              new org.apache.commons.math3.genetics.ElitisticListPopulation(
                  chromosomes, 1, 1.0);
          assertEquals(1.0, pop2.getElitismRate(), 0.0001);
      }

 @Test
      public void testConstructor_InvalidElitismRateNegative() {
          // Setup
          org.apache.commons.math3.genetics.Chromosome chr = new org.apache.commons.math3.genetics.Chromosome() {
              @Override
              public double fitness() {
                  return 0;
              }
          };
          java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
              new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
          chromosomes.add(chr);
          
          try {
              // Test
              new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomes, 1, -0.25);
              fail("Expected IllegalArgumentException");
          } catch (IllegalArgumentException e) {
              // Verify
              assertTrue(e.getMessage().contains("elitism rate (0.25)"));
          }
      }

 @Test
      public void testConstructor_InvalidElitismRateAboveOne() {
          // Setup
          org.apache.commons.math3.genetics.Chromosome chr = new org.apache.commons.math3.genetics.Chromosome() {
              @Override
              public double fitness() {
                  return 0;
              }
          };
          java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
              java.util.Arrays.asList(chr);
          
          // Test and verify exception
          try {
              new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomes, 1, 1.25);
              fail("Expected IllegalArgumentException");
          } catch (IllegalArgumentException e) {
              assertTrue(e.getMessage().contains("elitism rate (1.25)"));
          }
      }

 @Test
      public void testConstructor_PopulationLimitTooSmall() {
          // Setup
          org.apache.commons.math3.genetics.Chromosome chr1 = 
              new org.apache.commons.math3.genetics.Chromosome() {
                  @Override
                  public double fitness() {
                      return 0;
                  }
              };
          org.apache.commons.math3.genetics.Chromosome chr2 = 
              new org.apache.commons.math3.genetics.Chromosome() {
                  @Override
                  public double fitness() {
                      return 0;
                  }
              };
          java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
              java.util.Arrays.asList(chr1, chr2);
          
          try {
              // Test
              new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomes, 1, 0.1);
              org.junit.Assert.fail("Expected IllegalArgumentException");
          } catch (IllegalArgumentException e) {
              // Verify
              org.junit.Assert.assertTrue(e.getMessage().contains("population limit (1)"));
          }
      }

 @Test
     public void testConstructorSetsElitismRateCorrectly() {
         // Test normal case
         double testRate = 0.3;
         int limit = 100;
         ElitisticListPopulation population = new ElitisticListPopulation(limit, testRate);
         
         // Verify field is set correctly
         assertEquals(testRate, population.getElitismRate(), 0.0001);
         
         // Test boundary case - minimum valid rate
         testRate = 0.0;
         population = new ElitisticListPopulation(limit, testRate);
         assertEquals(testRate, population.getElitismRate(), 0.0001);
         
         // Test boundary case - maximum valid rate
         testRate = 1.0;
         population = new ElitisticListPopulation(limit, testRate);
         assertEquals(testRate, population.getElitismRate(), 0.0001);
     }

 @Test(expected = IllegalArgumentException.class)
     public void testConstructorWithNegativeElitismRate() {
         // Test invalid case - negative rate
         new ElitisticListPopulation(100, -0.1);
     }

 @Test(expected = IllegalArgumentException.class)
     public void testConstructorWithTooLargeElitismRate() {
         // Test invalid case - rate > 1.0
         new ElitisticListPopulation(100, 1.1);
     }

 @Test
     public void testConstructorEnsuresFinalParameterBehavior() {
         // Test that elitismRate parameter cannot be modified before being set
         double originalRate = 0.3;
         double attemptedModifiedRate = 0.5;
         
         // Create an anonymous subclass that tries to modify the parameter
         ElitisticListPopulation population = new ElitisticListPopulation(100, originalRate) {
             {
                 // This would only compile if parameter wasn't final (mutant case)
                 // In original code, this would cause compilation error
                 // elitismRate = attemptedModifiedRate; // Uncommenting would fail for original
             }
         };
         
         // Verify the field was set to original value, not modified one
         assertEquals(originalRate, population.getElitismRate(), 0.0001);
         
         // Additional test to ensure field setting works correctly
         population.setElitismRate(attemptedModifiedRate);
         assertEquals(attemptedModifiedRate, population.getElitismRate(), 0.0001);
     }

}
