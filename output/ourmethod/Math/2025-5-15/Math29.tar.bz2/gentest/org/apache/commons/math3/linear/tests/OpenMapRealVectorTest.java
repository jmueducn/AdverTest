package gentest.org.apache.commons.math3.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.linear.*;
import java.io.Serializable;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.OpenIntToDoubleHashMap;
import org.apache.commons.math3.util.OpenIntToDoubleHashMap.Iterator;
import org.apache.commons.math3.util.FastMath;
 
public class OpenMapRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                public void testEbeDivide_SameSizeVectors() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{4.0, 9.0, 16.0});
                    OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{2.0, 3.0, 4.0});
                    
                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                    
                    assertEquals(3, result.getDimension());
                    assertEquals(2.0, result.getEntry(0), 0.0001);
                    assertEquals(3.0, result.getEntry(1), 0.0001);
                    assertEquals(4.0, result.getEntry(2), 0.0001);
                }

    @Test
                public void testEbeDivide_WithZeroElements() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{0.0, 5.0, 0.0});
                    OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0, 0.0, 0.0});
                    
                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                    
                    assertEquals(3, result.getDimension());
                    assertEquals(0.0, result.getEntry(0), 0.0001);
                    assertTrue(Double.isNaN(result.getEntry(1))); // 5.0 / 0.0 = NaN
                    assertTrue(Double.isNaN(result.getEntry(2))); // 0.0 / 0.0 = NaN
                }

    @Test
                public void testEbeDivide_DifferentSizeVectorsThrowsException() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0});
                    OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                    
                    thrown.expect(IllegalArgumentException.class);
                    vector1.ebeDivide(vector2);
                }

    @Test
                public void testEbeDivide_WithRealVectorParameter() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{10.0, 20.0, 30.0});
                    RealVector mockVector = mock(RealVector.class);
                    when(mockVector.getDimension()).thenReturn(3);
                    when(mockVector.getEntry(0)).thenReturn(2.0);
                    when(mockVector.getEntry(1)).thenReturn(5.0);
                    when(mockVector.getEntry(2)).thenReturn(10.0);
                    
                    OpenMapRealVector result = vector1.ebeDivide(mockVector);
                    
                    assertEquals(3, result.getDimension());
                    assertEquals(5.0, result.getEntry(0), 0.0001);
                    assertEquals(4.0, result.getEntry(1), 0.0001);
                    assertEquals(3.0, result.getEntry(2), 0.0001);
                }

    @Test
                public void testEbeDivide_OriginalVectorNotModified() {
                    OpenMapRealVector original = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                    OpenMapRealVector divisor = new OpenMapRealVector(new double[]{1.0, 1.0, 1.0});
                    
                    OpenMapRealVector result = original.ebeDivide(divisor);
                    
                    // Verify original vector wasn't modified
                    assertEquals(1.0, original.getEntry(0), 0.0001);
                    assertEquals(2.0, original.getEntry(1), 0.0001);
                    assertEquals(3.0, original.getEntry(2), 0.0001);
                    
                    // Verify result is a new vector
                    assertNotSame(original, result);
                }

    @Test
                public void testEbeDivide_WithNegativeValues() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{-4.0, 9.0, -16.0});
                    OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{2.0, -3.0, -4.0});
                    
                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                    
                    assertEquals(3, result.getDimension());
                    assertEquals(-2.0, result.getEntry(0), 0.0001);
                    assertEquals(-3.0, result.getEntry(1), 0.0001);
                    assertEquals(4.0, result.getEntry(2), 0.0001);
                }

    @Test
                public void testEbeDivide_WithSparseVectors() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(5); // size 5, all zeros
                    vector1.setEntry(1, 10.0); // Only set one value
                    vector1.setEntry(3, 20.0);
                    
                    OpenMapRealVector vector2 = new OpenMapRealVector(5); // size 5, all zeros
                    vector2.setEntry(1, 2.0); // Only set one value
                    vector2.setEntry(3, 0.0); // Will cause division by zero
                    
                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                    
                    assertEquals(5, result.getDimension());
                    assertEquals(0.0, result.getEntry(0), 0.0001); // 0/0 = NaN but default value is 0
                    assertEquals(5.0, result.getEntry(1), 0.0001); // 10/2 = 5
                    assertEquals(0.0, result.getEntry(2), 0.0001); // 0/0 = NaN but default value is 0
                    assertTrue(Double.isNaN(result.getEntry(3))); // 20/0 = NaN
                    assertEquals(0.0, result.getEntry(4), 0.0001); // 0/0 = NaN but default value is 0
                }

    @Test
                public void testEbeMultiply_TypicalValues() {
                    // Setup
                    double[] data1 = {1.0, 2.0, 3.0};
                    double[] data2 = {4.0, 5.0, 6.0};
                    OpenMapRealVector v1 = new OpenMapRealVector(data1);
                    OpenMapRealVector v2 = new OpenMapRealVector(data2);
                    
                    // Execute
                    OpenMapRealVector result = v1.ebeMultiply(v2);
                    
                    // Verify
                    assertEquals(4.0, result.getEntry(0), 0.0001);
                    assertEquals(10.0, result.getEntry(1), 0.0001);
                    assertEquals(18.0, result.getEntry(2), 0.0001);
                }

    @Test
                public void testEbeMultiply_WithZeroValues() {
                    // Setup
                    double[] data1 = {1.0, 0.0, 3.0};
                    double[] data2 = {4.0, 5.0, 0.0};
                    OpenMapRealVector v1 = new OpenMapRealVector(data1);
                    OpenMapRealVector v2 = new OpenMapRealVector(data2);
                    
                    // Execute
                    OpenMapRealVector result = v1.ebeMultiply(v2);
                    
                    // Verify
                    assertEquals(4.0, result.getEntry(0), 0.0001);
                    assertEquals(0.0, result.getEntry(1), 0.0001);
                    assertEquals(0.0, result.getEntry(2), 0.0001);
                }

    @Test
                public void testEbeMultiply_WithNaNValues() {
                    // Setup
                    double[] data1 = {1.0, 0.0, 3.0};
                    double[] data2 = {4.0, Double.NaN, 6.0};
                    OpenMapRealVector v1 = new OpenMapRealVector(data1);
                    OpenMapRealVector v2 = new OpenMapRealVector(data2);
                    
                    // Execute
                    OpenMapRealVector result = v1.ebeMultiply(v2);
                    
                    // Verify
                    assertEquals(4.0, result.getEntry(0), 0.0001);
                    assertTrue(Double.isNaN(result.getEntry(1)));
                    assertEquals(18.0, result.getEntry(2), 0.0001);
                }

    @Test
                public void testEbeMultiply_WithInfinityValues() {
                    // Setup
                    double[] data1 = {1.0, 0.0, 3.0};
                    double[] data2 = {4.0, Double.POSITIVE_INFINITY, 6.0};
                    OpenMapRealVector v1 = new OpenMapRealVector(data1);
                    OpenMapRealVector v2 = new OpenMapRealVector(data2);
                    
                    // Execute
                    OpenMapRealVector result = v1.ebeMultiply(v2);
                    
                    // Verify
                    assertEquals(4.0, result.getEntry(0), 0.0001);
                    assertTrue(Double.isNaN(result.getEntry(1))); // 0 * Infinity = NaN
                    assertEquals(18.0, result.getEntry(2), 0.0001);
                }

    @Test
                public void testEbeMultiply_WithNegativeInfinity() {
                    // Setup
                    double[] data1 = {1.0, -2.0, 0.0};
                    double[] data2 = {4.0, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY};
                    OpenMapRealVector v1 = new OpenMapRealVector(data1);
                    OpenMapRealVector v2 = new OpenMapRealVector(data2);
                    
                    // Execute
                    OpenMapRealVector result = v1.ebeMultiply(v2);
                    
                    // Verify
                    assertEquals(4.0, result.getEntry(0), 0.0001);
                    assertEquals(Double.POSITIVE_INFINITY, result.getEntry(1), 0.0001);
                    assertTrue(Double.isNaN(result.getEntry(2))); // 0 * Infinity = NaN
                }

    @Test
                public void testEbeMultiply_DimensionMismatch() {
                    // Setup
                    double[] data1 = {1.0, 2.0, 3.0};
                    double[] data2 = {4.0, 5.0};
                    OpenMapRealVector v1 = new OpenMapRealVector(data1);
                    OpenMapRealVector v2 = new OpenMapRealVector(data2);
                    
                    // Expect exception
                    thrown.expect(IllegalArgumentException.class);
                    
                    // Execute
                    v1.ebeMultiply(v2);
                }

    @Test
                public void testEbeMultiply_WithSparseVectors() {
                    // Setup - create sparse vectors (most values are 0)
                    OpenMapRealVector v1 = new OpenMapRealVector(100);
                    OpenMapRealVector v2 = new OpenMapRealVector(100);
                    v1.setEntry(10, 2.5);
                    v1.setEntry(50, 3.0);
                    v2.setEntry(10, 4.0);
                    v2.setEntry(50, 0.0);
                    v2.setEntry(75, Double.NaN);
                    
                    // Execute
                    OpenMapRealVector result = v1.ebeMultiply(v2);
                    
                    // Verify
                    assertEquals(10.0, result.getEntry(10), 0.0001); // 2.5 * 4.0
                    assertEquals(0.0, result.getEntry(50), 0.0001);  // 3.0 * 0.0
                    assertTrue(Double.isNaN(result.getEntry(75)));   // 0.0 * NaN = NaN
                    assertEquals(0.0, result.getEntry(0), 0.0001);   // default value
                }

    @Test
                public void testEbeMultiply_WithRealVectorParameter() {
                    // Setup
                    double[] data1 = {1.0, 2.0, 3.0};
                    OpenMapRealVector v1 = new OpenMapRealVector(data1);
                    RealVector v2 = mock(RealVector.class);
                    when(v2.getDimension()).thenReturn(3);
                    when(v2.getEntry(0)).thenReturn(4.0);
                    when(v2.getEntry(1)).thenReturn(5.0);
                    when(v2.getEntry(2)).thenReturn(6.0);
                    
                    // Execute
                    OpenMapRealVector result = v1.ebeMultiply(v2);
                    
                    // Verify
                    assertEquals(4.0, result.getEntry(0), 0.0001);
                    assertEquals(10.0, result.getEntry(1), 0.0001);
                    assertEquals(18.0, result.getEntry(2), 0.0001);
                }

    @Test
            public void testEbeMultiply_ShouldNotProcessAllElementsWhenNoNaNOrInfinite() {
                // Create a test vector with normal values
                OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{4.0, 5.0, 6.0});
                
                // Mock the isNaN and isInfinite methods to return false
                OpenMapRealVector spyVector2 = spy(vector2);
                when(spyVector2.isNaN()).thenReturn(false);
                when(spyVector2.isInfinite()).thenReturn(false);
                
                // Perform the multiplication
                OpenMapRealVector result = vector1.ebeMultiply(spyVector2);
                
                // Verify the result is correct
                assertEquals(4.0, result.getEntry(0), 0.0001);
                assertEquals(10.0, result.getEntry(1), 0.0001);
                assertEquals(18.0, result.getEntry(2), 0.0001);
                
                // Verify isNaN and isInfinite were called (would fail if mutant is active)
                verify(spyVector2).isNaN();
                verify(spyVector2).isInfinite();
            }

    @Test
            public void testEbeMultiply_ShouldProcessAllElementsWhenNaNExists() {
                // Create a test vector with NaN value
                OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 0.0, 3.0});
                OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{4.0, Double.NaN, 6.0});
                
                // Mock the isNaN and isInfinite methods
                OpenMapRealVector spyVector2 = spy(vector2);
                when(spyVector2.isNaN()).thenReturn(true);
                when(spyVector2.isInfinite()).thenReturn(false);
                
                // Perform the multiplication
                OpenMapRealVector result = vector1.ebeMultiply(spyVector2);
                
                // Verify NaN was properly handled
                assertEquals(4.0, result.getEntry(0), 0.0001);
                assertTrue(Double.isNaN(result.getEntry(1)));
                assertEquals(18.0, result.getEntry(2), 0.0001);
            }

    @Test
            public void testEbeMultiply_ShouldProcessAllElementsWhenInfiniteExists() {
                // Create a test vector with Infinite value
                OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 0.0, 3.0});
                OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{4.0, Double.POSITIVE_INFINITY, 6.0});
                
                // Mock the isNaN and isInfinite methods
                OpenMapRealVector spyVector2 = spy(vector2);
                when(spyVector2.isNaN()).thenReturn(false);
                when(spyVector2.isInfinite()).thenReturn(true);
                
                // Perform the multiplication
                OpenMapRealVector result = vector1.ebeMultiply(spyVector2);
                
                // Verify Infinite was properly handled
                assertEquals(4.0, result.getEntry(0), 0.0001);
                assertEquals(Double.POSITIVE_INFINITY, result.getEntry(1), 0.0001);
                assertEquals(18.0, result.getEntry(2), 0.0001);
            }

    @Test
       public void testEbeMultiplyWithBothNaNAndInfiniteValues() {
           // Create a vector with 0, NaN, and Infinite values
           double[] values1 = {0.0, 1.0, 2.0};
           double[] values2 = {1.0, Double.NaN, Double.POSITIVE_INFINITY};
           
           OpenMapRealVector v1 = new OpenMapRealVector(values1);
           OpenMapRealVector v2 = new OpenMapRealVector(values2);
           
           // Perform multiplication
           OpenMapRealVector result = v1.ebeMultiply(v2);
           
           // Verify results
           assertEquals(0.0, result.getEntry(0), 0.0001);  // 0 * 1 = 0
           assertTrue(Double.isNaN(result.getEntry(1)));    // 1 * NaN = NaN
           assertEquals(Double.POSITIVE_INFINITY, result.getEntry(2), 0.0001); // 2 * ∞ = ∞
           
           // The key test - if mutant is present, the Infinite check would run after NaN check
           // but shouldn't affect the NaN result (though in reality it wouldn't)
           // This test ensures the NaN case is handled properly without Infinite interference
       }

    @Test
      public void testEbeMultiply_DetectsIteratorAdvanceMutation() {
          // Create a sparse vector with known non-zero entries
          OpenMapRealVector vector1 = new OpenMapRealVector(5); // dimension 5
          vector1.setEntry(0, 1.0); // non-zero at index 0
          vector1.setEntry(2, 2.0); // non-zero at index 2
          vector1.setEntry(4, 3.0); // non-zero at index 4
          
          // Create another vector to multiply with
          OpenMapRealVector vector2 = new OpenMapRealVector(5);
          vector2.setEntry(0, 4.0);
          vector2.setEntry(1, 5.0); // zero in vector1 but non-zero here
          vector2.setEntry(2, 6.0);
          vector2.setEntry(3, 7.0); // zero in vector1 but non-zero here
          vector2.setEntry(4, 8.0);
          
          // Perform multiplication
          OpenMapRealVector result = vector1.ebeMultiply(vector2);
          
          // Verify all expected multiplications occurred
          // The mutation would fail to multiply some entries
          assertEquals(4.0, result.getEntry(0), 0.0001);  // 1.0 * 4.0
          assertEquals(0.0, result.getEntry(1), 0.0001);  // 0.0 * 5.0 (should remain 0)
          assertEquals(12.0, result.getEntry(2), 0.0001); // 2.0 * 6.0
          assertEquals(0.0, result.getEntry(3), 0.0001);  // 0.0 * 7.0 (should remain 0)
          assertEquals(24.0, result.getEntry(4), 0.0001); // 3.0 * 8.0
          
          // Also test with a completely empty vector to ensure iterator handling
          OpenMapRealVector emptyVector = new OpenMapRealVector(3);
          OpenMapRealVector emptyResult = emptyVector.ebeMultiply(vector2);
          assertEquals(0.0, emptyResult.getEntry(0), 0.0001);
          assertEquals(0.0, emptyResult.getEntry(1), 0.0001);
          assertEquals(0.0, emptyResult.getEntry(2), 0.0001);
      }

    @Test
    public void testEbeMultiplyIteratorAdvancement() throws Exception {
        // Create a vector with exactly one non-zero entry
        OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{0, 1.5, 0});
        
        // Create another vector to multiply with
        OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{0, 2.0, 0});
        
        // Mock the iterator to verify advancement
        OpenIntToDoubleHashMap.Iterator mockIter = mock(OpenIntToDoubleHashMap.Iterator.class);
        when(mockIter.hasNext()).thenReturn(true, false); // Only one element
        
        // Create a mock map and set our mock iterator
        OpenIntToDoubleHashMap mockMap = mock(OpenIntToDoubleHashMap.class);
        when(mockMap.iterator()).thenReturn(mockIter);
        
        // Use reflection to set the private entries field
        Field entriesField = OpenMapRealVector.class.getDeclaredField("entries");
        entriesField.setAccessible(true);
        entriesField.set(vector1, mockMap);
        
        // Perform the operation
        OpenMapRealVector result = vector1.ebeMultiply(vector2);
        
        // Verify iterator advancement occurred exactly once
        verify(mockIter, times(1)).advance();
        
        // Also verify the result is correct
        assertEquals(0.0, result.getEntry(0), 0.0001);
        assertEquals(3.0, result.getEntry(1), 0.0001); // 1.5 * 2.0
        assertEquals(0.0, result.getEntry(2), 0.0001);
    }


}
