package gentest.org.apache.commons.math.special.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.special.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.util.ContinuedFraction;
 
public class GammaTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                             public void testLogGamma_NaNInput() {
                                                                                                 double result = Gamma.logGamma(Double.NaN);
                                                                                                 assertTrue(Double.isNaN(result));
                                                                                             }

 @Test
                                                                                             public void testLogGamma_ZeroInput() {
                                                                                                 double result = Gamma.logGamma(0.0);
                                                                                                 assertTrue(Double.isNaN(result));
                                                                                             }

 @Test
                                                                                             public void testLogGamma_NegativeInput() {
                                                                                                 double result = Gamma.logGamma(-5.0);
                                                                                                 assertTrue(Double.isNaN(result));
                                                                                             }

 @Test
                                                                                             public void testLogGamma_VerySmallPositiveValue() {
                                                                                                 double result = Gamma.logGamma(1e-10);
                                                                                                 // Testing behavior near zero (positive side)
                                                                                                 assertFalse(Double.isNaN(result));
                                                                                                 assertTrue(result > 0);
                                                                                             }

 @Test
                                                                                             public void testLogGamma_JustAboveZero() {
                                                                                                 double result = Gamma.logGamma(Double.MIN_VALUE);
                                                                                                 assertFalse(Double.isNaN(result));
                                                                                                 assertTrue(result > 0);
                                                                                             }

 @Test
                                                                                     public void testLogGamma_SmallPositiveValue() {
                                                                                         double result = Gamma.logGamma(0.1);
                                                                                         // Expected value calculated using reference implementation
                                                                                         double DELTA = 1e-15; // Define delta for floating-point comparison
                                                                                         assertEquals(2.252712651734205, result, DELTA);
                                                                                     }

 @Test
                                                                                     public void testLogGamma_One() {
                                                                                         final double DELTA = 1e-15;
                                                                                         double result = Gamma.logGamma(1.0);
                                                                                         // log(gamma(1)) = log(1) = 0
                                                                                         assertEquals(0.0, result, DELTA);
                                                                                     }

 @Test
                                                                                     public void testLogGamma_Half() {
                                                                                         final double DELTA = 1e-15;
                                                                                         double result = Gamma.logGamma(0.5);
                                                                                         // log(gamma(0.5)) = log(sqrt(pi)) ≈ 0.5723649429247001
                                                                                         assertEquals(0.5723649429247001, result, DELTA);
                                                                                     }

 @Test
                                                                                     public void testLogGamma_IntegerValue() {
                                                                                         final double DELTA = 1e-15;
                                                                                         double result = Gamma.logGamma(5.0);
                                                                                         // gamma(5) = 4! = 24, log(24) ≈ 3.1780538303479458
                                                                                         assertEquals(3.1780538303479458, result, DELTA);
                                                                                     }

 @Test
                                                                                     public void testLogGamma_LargeValue() {
                                                                                         final double DELTA = 1e-14;
                                                                                         double result = Gamma.logGamma(100.0);
                                                                                         // Expected value calculated using reference implementation
                                                                                         assertEquals(359.1342053695754, result, DELTA);
                                                                                     }

 @Test
                                     public void testRegularizedGammaP_TypicalValues() throws MathException {
                                         // Test with typical positive values
                                         assertEquals(0.632120558828558, Gamma.regularizedGammaP(1.0, 1.0), 1e-14);
                                         assertEquals(0.864664716763387, Gamma.regularizedGammaP(2.0, 2.0), 1e-14);
                                         assertEquals(0.950212931632136, Gamma.regularizedGammaP(3.0, 3.0), 1e-14);
                                     }

 @Test
                                     public void testRegularizedGammaP_EdgeCases() throws MathException {
                                         // Test with x = 0
                                         assertEquals(0.0, Gamma.regularizedGammaP(1.0, 0.0), 1e-14);
                                         assertEquals(0.0, Gamma.regularizedGammaP(2.0, 0.0), 1e-14);
                                         
                                         // Test with very small x
                                         assertEquals(9.999500016666262E-5, Gamma.regularizedGammaP(1.0, 0.0001), 1e-14);
                                         
                                         // Test with large x
                                         assertEquals(1.0, Gamma.regularizedGammaP(1.0, 100.0), 1e-14);
                                     }

 @Test
                                     public void testRegularizedGammaP_InvalidParameters() throws MathException {
                                         // Test with negative a
                                         thrown.expect(IllegalArgumentException.class);
                                         Gamma.regularizedGammaP(-1.0, 1.0);
                                         
                                         // Test with negative x
                                         thrown.expect(IllegalArgumentException.class);
                                         Gamma.regularizedGammaP(1.0, -1.0);
                                         
                                         // Test with both parameters negative
                                         thrown.expect(IllegalArgumentException.class);
                                         Gamma.regularizedGammaP(-1.0, -1.0);
                                     }

 @Test
                                     public void testRegularizedGammaP_SpecialCases() throws MathException {
                                         // Test with a = 1 (exponential distribution case)
                                         assertEquals(1 - Math.exp(-1), Gamma.regularizedGammaP(1.0, 1.0), 1e-14);
                                         
                                         // Test with a = 0.5 (relates to error function)
                                         assertEquals(0.842700792949715, Gamma.regularizedGammaP(0.5, 1.0), 1e-14);
                                         
                                         // Test with very small a
                                         assertEquals(1.0, Gamma.regularizedGammaP(1e-10, 1.0), 1e-6);
                                     }

 @Test
                                     public void testRegularizedGammaP_ConsistencyWithComplement() throws Exception {
                                         double a = 2.5;
                                         double x = 3.5;
                                         double p = Gamma.regularizedGammaP(a, x);
                                         double q = Gamma.regularizedGammaQ(a, x);
                                         assertEquals(1.0, p + q, 1e-14);
                                     }

 @Test(expected = MaxIterationsExceededException.class)
                                     public void testRegularizedGammaP_MaxIterationsExceeded() throws MathException {
                                         // Test case where max iterations are exceeded
                                         Gamma.regularizedGammaP(0.5, 100.0, 1e-20, 10); // Very tight epsilon with low max iterations
                                     }

 @Test
                                     public void testRegularizedGammaQ_TypicalValues() throws MathException {
                                         // Values where we know expected results
                                         assertEquals(1.0, Gamma.regularizedGammaQ(1.0, 0.0), 1e-10);
                                         assertEquals(Math.exp(-1), Gamma.regularizedGammaQ(1.0, 1.0), 1e-10);
                                         assertEquals(0.0, Gamma.regularizedGammaQ(1.0, Double.POSITIVE_INFINITY), 1e-10);
                                         
                                         // Test with a=2.0, x=1.0 (known value: 1 - (1 - e^-1 - e^-1) = e^-1*(1 + 1) = 2/e)
                                         assertEquals(2/Math.E, Gamma.regularizedGammaQ(2.0, 1.0), 1e-10);
                                     }

 @Test
                                     public void testRegularizedGammaQ_XZero() throws MathException {
                                         assertEquals(1.0, Gamma.regularizedGammaQ(0.5, 0.0), 1e-10);
                                         assertEquals(1.0, Gamma.regularizedGammaQ(1.0, 0.0), 1e-10);
                                         assertEquals(1.0, Gamma.regularizedGammaQ(2.0, 0.0), 1e-10);
                                     }

 @Test
                                     public void testRegularizedGammaQ_SmallA() throws MathException {
                                         assertEquals(1.0, Gamma.regularizedGammaQ(Double.MIN_VALUE, 0.0), 1e-10);
                                         assertEquals(0.0, Gamma.regularizedGammaQ(Double.MIN_VALUE, Double.MAX_VALUE), 1e-10);
                                     }

 @Test
                                     public void testRegularizedGammaQ_LargeX() throws org.apache.commons.math.MathException {
                                         assertEquals(0.0, Gamma.regularizedGammaQ(1.0, Double.MAX_VALUE), 1e-10);
                                         assertEquals(0.0, Gamma.regularizedGammaQ(10.0, Double.MAX_VALUE), 1e-10);
                                         assertEquals(0.0, Gamma.regularizedGammaQ(1.0, Double.POSITIVE_INFINITY), 1e-10);
                                     }

 @Test
                                     public void testRegularizedGammaQ_InvalidA() {
                                         try {
                                             Gamma.regularizedGammaQ(0.0, 1.0);
                                             fail("Expected IllegalArgumentException");
                                         } catch (IllegalArgumentException e) {
                                             // Expected
                                         } catch (MathException e) {
                                             fail("Unexpected MathException: " + e.getMessage());
                                         }
                                     }

 @Test
                                     public void testRegularizedGammaQ_InvalidX() {
                                         thrown.expect(IllegalArgumentException.class);
                                         try {
                                             Gamma.regularizedGammaQ(1.0, -1.0);
                                         } catch (MathException e) {
                                             fail("Unexpected MathException: " + e.getMessage());
                                         }
                                     }

 @Test
                                     public void testRegularizedGammaQ_RelationshipWithP() throws org.apache.commons.math.MathException {
                                         double a = 2.5;
                                         double x = 3.7;
                                         double p = Gamma.regularizedGammaP(a, x);
                                         double q = Gamma.regularizedGammaQ(a, x);
                                         assertEquals(1.0, p + q, 1e-10);
                                     }

 @Test
                                     public void testRegularizedGammaQ_Precision() throws org.apache.commons.math.MathException {
                                         // For a=1, Q(1,x) = e^-x, so we can verify precision
                                         double x = 10.0;
                                         double expected = Math.exp(-x);
                                         double actual = Gamma.regularizedGammaQ(1.0, x);
                                         assertEquals(expected, actual, 1e-10);
                                     }

 @Test
                                     public void testRegularizedGammaQ_NaNInputs() throws MathException {
                                         // Test NaN for a
                                         assertTrue(Double.isNaN(Gamma.regularizedGammaQ(Double.NaN, 1.0)));
                                         // Test NaN for x
                                         assertTrue(Double.isNaN(Gamma.regularizedGammaQ(1.0, Double.NaN)));
                                         // Test both NaN
                                         assertTrue(Double.isNaN(Gamma.regularizedGammaQ(Double.NaN, Double.NaN)));
                                     }

 @Test
                                     public void testRegularizedGammaQ_InvalidParameters() throws MathException {
                                         // Test a <= 0
                                         assertTrue(Double.isNaN(Gamma.regularizedGammaQ(0.0, 1.0)));
                                         assertTrue(Double.isNaN(Gamma.regularizedGammaQ(-1.0, 1.0)));
                                         // Test x < 0
                                         assertTrue(Double.isNaN(Gamma.regularizedGammaQ(1.0, -1.0)));
                                     }

 @Test
                                     public void testRegularizedGammaQ_WithEpsilonAndMaxIterations() throws org.apache.commons.math.MathException {
                                         // Test with custom epsilon and max iterations
                                         double customEpsilon = 1e-12;
                                         int maxIter = 10000;
                                         
                                         // Should be more precise with tighter epsilon
                                         assertEquals(0.36787944117, 
                                             Gamma.regularizedGammaQ(1.0, 1.0, customEpsilon, maxIter), 
                                             customEpsilon);
                                     }

 @Test
                                     public void testRegularizedGammaP_NaNInputs() throws MathException {
                                         // Test NaN inputs for a and x
                                         final double EPSILON = 1.0e-15;
                                         assertTrue(Double.isNaN(Gamma.regularizedGammaP(Double.NaN, 1.0, EPSILON, 1000)));
                                         assertTrue(Double.isNaN(Gamma.regularizedGammaP(1.0, Double.NaN, EPSILON, 1000)));
                                         assertTrue(Double.isNaN(Gamma.regularizedGammaP(Double.NaN, Double.NaN, EPSILON, 1000)));
                                     }

 @Test
                                     public void testRegularizedGammaP_InvalidParameters1() throws MathException {
                                         // Test invalid parameters (a <= 0 or x < 0)
                                         final double EPSILON = 1.0e-15;
                                         assertTrue(Double.isNaN(Gamma.regularizedGammaP(0.0, 1.0, EPSILON, 1000)));
                                         assertTrue(Double.isNaN(Gamma.regularizedGammaP(-1.0, 1.0, EPSILON, 1000)));
                                         assertTrue(Double.isNaN(Gamma.regularizedGammaP(1.0, -1.0, EPSILON, 1000)));
                                     }

 @Test
                                     public void testRegularizedGammaP_XZero() throws org.apache.commons.math.MathException {
                                         // Test x = 0.0 case
                                         final double EPSILON = 1e-15;
                                         assertEquals(0.0, org.apache.commons.math.special.Gamma.regularizedGammaP(1.0, 0.0, EPSILON, 1000), EPSILON);
                                         assertEquals(0.0, org.apache.commons.math.special.Gamma.regularizedGammaP(2.5, 0.0, EPSILON, 1000), EPSILON);
                                     }

 @Test
                                     public void testRegularizedGammaP_ConvergesToGammaQ() throws org.apache.commons.math.MathException {
                                         // Test case where a >= 1.0 and x > a (should use regularizedGammaQ)
                                         double a = 2.0;
                                         double x = 3.0;
                                         double EPSILON = 1.0e-15; // Define epsilon value
                                         double expected = 1.0 - Gamma.regularizedGammaQ(a, x, EPSILON, 1000);
                                         assertEquals(expected, Gamma.regularizedGammaP(a, x, EPSILON, 1000), EPSILON);
                                     }

 @Test
                                     public void testRegularizedGammaP_SeriesCalculation() throws MathException {
                                         // Define epsilon for comparison
                                         final double EPSILON = 1.0e-10;
                                         
                                         // Test series calculation for various valid inputs
                                         // Small values
                                         assertEquals(0.6321205588, Gamma.regularizedGammaP(1.0, 1.0, EPSILON, 1000), EPSILON);
                                         
                                         // Larger values
                                         assertEquals(0.9999999999, Gamma.regularizedGammaP(10.0, 30.0, EPSILON, 1000), EPSILON);
                                         
                                         // Fractional values
                                         assertEquals(0.6826894921, Gamma.regularizedGammaP(0.5, 0.5, EPSILON, 1000), EPSILON);
                                     }

 @Test
                                     public void testRegularizedGammaP_DefaultParameters() throws MathException {
                                         // Define test constants
                                         final double EPSILON = 1.0e-15;
                                         
                                         // Test the version with default epsilon and maxIterations
                                         double result1 = Gamma.regularizedGammaP(1.0, 1.0);
                                         double result2 = Gamma.regularizedGammaP(1.0, 1.0, EPSILON, 1000);
                                         assertEquals(result2, result1, EPSILON);
                                     }

 @Test
                                     public void testRegularizedGammaP_EdgeCases1() throws MathException {
                                         // Define epsilon locally for the test
                                         final double EPSILON = 1.0e-15;
                                         
                                         // Test various edge cases
                                         // When x is very small but not zero
                                         assertEquals(0.095162582, Gamma.regularizedGammaP(1.0, 0.1, EPSILON, 1000), EPSILON);
                                         
                                         // When a is very large
                                         assertEquals(1.0, Gamma.regularizedGammaP(1000.0, 1001.0, EPSILON, 1000), EPSILON);
                                         
                                         // When x is very large compared to a
                                         assertEquals(1.0, Gamma.regularizedGammaP(1.0, 100.0, EPSILON, 1000), EPSILON);
                                     }

 @Test
                                     public void testRegularizedGammaQ_XZero1() throws MathException {
                                         // When x = 0, result should be 1.0
                                         final double EPSILON = 1e-15;
                                         assertEquals(1.0, Gamma.regularizedGammaQ(1.0, 0.0), EPSILON);
                                         assertEquals(1.0, Gamma.regularizedGammaQ(2.5, 0.0), EPSILON);
                                     }

 @Test
                                     public void testRegularizedGammaQ_GeneralCase() throws MathException {
                                         // Define epsilon for double comparison
                                         final double EPSILON = 1e-12;
                                         
                                         // Test known values from mathematical tables
                                         // Q(1,1) = e^-1 ≈ 0.36787944117
                                         assertEquals(0.36787944117, Gamma.regularizedGammaQ(1.0, 1.0), EPSILON);
                                         
                                         // Q(2,1) = (1 + 1)*e^-1 ≈ 0.73575888234
                                         assertEquals(0.73575888234, Gamma.regularizedGammaQ(2.0, 1.0), EPSILON);
                                         
                                         // Q(0.5, 0.5) = erfc(sqrt(0.5)) ≈ 0.31731050786
                                         assertEquals(0.31731050786, Gamma.regularizedGammaQ(0.5, 0.5), EPSILON);
                                     }

 @Test
                                     public void testRegularizedGammaQ_ExtremeValues() throws MathException {
                                         // Define test constants
                                         final double EPSILON = 1e-15;
                                         
                                         // Test very large values
                                         assertEquals(0.0, Gamma.regularizedGammaQ(100.0, 200.0), EPSILON);
                                         
                                         // Test very small values
                                         assertEquals(1.0, Gamma.regularizedGammaQ(1e-10, 1e-20), EPSILON);
                                     }

 @Test
                                     public void testRegularizedGammaQ_ComplementProperty() throws org.apache.commons.math.MathException {
                                         // Verify that Q(a,x) = 1 - P(a,x)
                                         double a = 2.5;
                                         double x = 3.0;
                                         double epsilon = 1.0e-15; // Define epsilon for double comparison
                                         double p = Gamma.regularizedGammaP(a, x);
                                         double q = Gamma.regularizedGammaQ(a, x);
                                         assertEquals(1.0, p + q, epsilon);
                                     }

 @Test
                                     public void testRegularizedGammaQ_XLessThanA_Or_ALessThan() throws MathException {
                                         // Define epsilon for comparison
                                         final double EPSILON = 1e-15;
                                         
                                         // Case where x < a
                                         // regularizedGammaQ(a,x) = 1 - regularizedGammaP(a,x)
                                         // We expect this to follow the mathematical relationship
                                         double result1 = Gamma.regularizedGammaQ(1.5, 1.0);
                                         double expected1 = 1.0 - Gamma.regularizedGammaP(1.5, 1.0);
                                         assertEquals(expected1, result1, EPSILON);
                                         
                                         // Case where a < 1
                                         double result2 = Gamma.regularizedGammaQ(0.5, 1.0);
                                         double expected2 = 1.0 - Gamma.regularizedGammaP(0.5, 1.0);
                                         assertEquals(expected2, result2, EPSILON);
                                     }

}
