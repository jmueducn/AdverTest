package gentest.org.apache.commons.math.geometry.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.geometry.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathArithmeticException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class Vector3DTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                   public void testCrossProduct_StandardVectors() {
                                       // Test with standard basis vectors
                                       Vector3D i = Vector3D.PLUS_I;
                                       Vector3D j = Vector3D.PLUS_J;
                                       Vector3D k = Vector3D.PLUS_K;
                                       
                                       // i × j = k
                                       assertEquals(k, Vector3D.crossProduct(i, j));
                                       // j × k = i
                                       assertEquals(i, Vector3D.crossProduct(j, k));
                                       // k × i = j
                                       assertEquals(j, Vector3D.crossProduct(k, i));
                                       
                                       // Anti-commutative property
                                       assertEquals(Vector3D.crossProduct(i, j).negate(), Vector3D.crossProduct(j, i));
                                   }

 @Test
                                   public void testCrossProduct_OrthogonalVectors() {
                                       // Test with orthogonal vectors
                                       Vector3D v1 = new Vector3D(1, 2, 0);
                                       Vector3D v2 = new Vector3D(0, 0, 3);
                                       Vector3D expected = new Vector3D(6, -3, 0);
                                       
                                       assertEquals(expected, Vector3D.crossProduct(v1, v2));
                                   }

 @Test
                                   public void testCrossProduct_ParallelVectors() {
                                       // Parallel vectors should return zero vector
                                       Vector3D v1 = new Vector3D(1, 2, 3);
                                       Vector3D v2 = new Vector3D(2, 4, 6); // v2 = 2*v1
                                       
                                       assertEquals(Vector3D.ZERO, Vector3D.crossProduct(v1, v2));
                                   }

 @Test
                                   public void testCrossProduct_ZeroVectors() {
                                       // Test with zero vectors
                                       assertEquals(Vector3D.ZERO, Vector3D.crossProduct(Vector3D.ZERO, Vector3D.ZERO));
                                       
                                       Vector3D v = new Vector3D(1, 2, 3);
                                       assertEquals(Vector3D.ZERO, Vector3D.crossProduct(Vector3D.ZERO, v));
                                       assertEquals(Vector3D.ZERO, Vector3D.crossProduct(v, Vector3D.ZERO));
                                   }

 @Test
                                   public void testCrossProduct_VerySmallVectors() {
                                       // Test with vectors whose norms are very small
                                       Vector3D tiny1 = new Vector3D(1e-100, 2e-100, 3e-100);
                                       Vector3D tiny2 = new Vector3D(4e-100, 5e-100, 6e-100);
                                       
                                       // Should return zero vector because product of norms is below SAFE_MIN
                                       assertEquals(Vector3D.ZERO, Vector3D.crossProduct(tiny1, tiny2));
                                   }

 @Test
                                   public void testCrossProduct_DifferentMagnitudes() {
                                       // Test with vectors of very different magnitudes
                                       Vector3D small = new Vector3D(1e-50, 2e-50, 3e-50);
                                       Vector3D large = new Vector3D(1e50, 2e50, 3e50);
                                       
                                       // Should handle the scaling properly
                                       Vector3D result = Vector3D.crossProduct(small, large);
                                       assertNotEquals(Vector3D.ZERO, result);
                                       
                                       // Check that the result is orthogonal to both input vectors
                                       assertEquals(0.0, Vector3D.dotProduct(result, small), 1e-10);
                                       assertEquals(0.0, Vector3D.dotProduct(result, large), 1e-10);
                                   }

 @Test
                                   public void testCrossProduct_WithNaNComponents() {
                                       // Test with vectors containing NaN values
                                       Vector3D nanVector = new Vector3D(Double.NaN, 1, 1);
                                       Vector3D normalVector = new Vector3D(1, 2, 3);
                                       
                                       assertTrue(Vector3D.crossProduct(nanVector, normalVector).isNaN());
                                       assertTrue(Vector3D.crossProduct(normalVector, nanVector).isNaN());
                                   }

 @Test
                                   public void testCrossProduct_WithInfiniteComponents() {
                                       // Test with vectors containing infinite values
                                       Vector3D infVector = new Vector3D(Double.POSITIVE_INFINITY, 1, 1);
                                       Vector3D normalVector = new Vector3D(1, 2, 3);
                                       
                                       assertTrue(Vector3D.crossProduct(infVector, normalVector).isInfinite());
                                       assertTrue(Vector3D.crossProduct(normalVector, infVector).isInfinite());
                                   }

 @Test
                                   public void testCrossProduct_RandomVectors() {
                                       // Test with random vectors to verify orthogonality property
                                       Vector3D v1 = new Vector3D(1.23, 4.56, 7.89);
                                       Vector3D v2 = new Vector3D(9.87, 6.54, 3.21);
                                       
                                       Vector3D result = Vector3D.crossProduct(v1, v2);
                                       
                                       // The cross product should be orthogonal to both input vectors
                                       assertEquals(0.0, Vector3D.dotProduct(result, v1), 1e-10);
                                       assertEquals(0.0, Vector3D.dotProduct(result, v2), 1e-10);
                                       
                                       // Verify the magnitude property: |a × b| = |a||b|sinθ
                                       double angle = Vector3D.angle(v1, v2);
                                       double expectedMagnitude = v1.getNorm() * v2.getNorm() * FastMath.sin(angle);
                                       assertEquals(expectedMagnitude, result.getNorm(), 1e-10);
                                   }

 @Test
                           public void testCrossProduct_VeryLargeVectors() {
                               // Test with vectors whose norms are very large
                               Vector3D huge1 = new Vector3D(1e100, 2e100, 3e100);
                               Vector3D huge2 = new Vector3D(4e100, 5e100, 6e100);
                               
                               Vector3D expected = new Vector3D(
                                   huge1.getY() * huge2.getZ() - huge1.getZ() * huge2.getY(),
                                   huge1.getZ() * huge2.getX() - huge1.getX() * huge2.getZ(),
                                   huge1.getX() * huge2.getY() - huge1.getY() * huge2.getX()
                               );
                               
                               assertEquals(expected, Vector3D.crossProduct(huge1, huge2));
                           }

 @Test
                       public void testCrossProductDetectsMutantIgnoringYZComponents() {
                           // Create two vectors where y and z components contribute significantly to the dot product
                           Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
                           Vector3D v2 = new Vector3D(4.0, 5.0, 6.0);
                           
                           // Calculate expected cross product using correct implementation
                           // Expected cross product components:
                           // x = y1*z2 - z1*y2 = 2*6 - 3*5 = -3
                           // y = z1*x2 - x1*z2 = 3*4 - 1*6 = 6
                           // z = x1*y2 - y1*x2 = 1*5 - 2*4 = -3
                           Vector3D expected = new Vector3D(-3.0, 6.0, -3.0);
                           
                           // Calculate actual cross product
                           Vector3D actual = Vector3D.crossProduct(v1, v2);
                           
                           // Verify all components match
                           assertEquals(expected.getX(), actual.getX(), 1.0e-15);
                           assertEquals(expected.getY(), actual.getY(), 1.0e-15);
                           assertEquals(expected.getZ(), actual.getZ(), 1.0e-15);
                           
                           // The mutant would compute ratio = (1*4)/n2_scaled instead of (1*4 + 2*5 + 3*6)/n2_scaled
                           // leading to incorrect rho and thus incorrect cross product
                       }

 @Test
                 public void testCrossProductDetectsRhoMutation() {
                     // Create vectors where the dot product ratio isn't exactly representable in 8 bits
                     Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
                     Vector3D v2 = new Vector3D(1.0 / 3.0, 1.0 / 7.0, 1.0 / 11.0); // irrational ratios
                     
                     // Calculate expected result with original quantization using getters
                     double ratio = (v1.getX() * v2.getX() + v1.getY() * v2.getY() + v1.getZ() * v2.getZ()) / 
                                   (v2.getX() * v2.getX() + v2.getY() * v2.getY() + v2.getZ() * v2.getZ());
                     double quantizedRho = FastMath.rint(256 * ratio) / 256;
                     
                     // Calculate what the mutant would produce
                     double mutantRho = ratio;
                     
                     // The difference should be detectable in the final cross product
                     Vector3D originalResult = Vector3D.crossProduct(v1, v2);
                     
                     // Simulate mutant behavior by creating a version with the raw ratio
                     // This is equivalent to the crossProduct method but without the rho quantization
                     final double n1 = v1.getNormSq();
                     final double n2 = v2.getNormSq();
                     if ((n1 * n2) < MathUtils.SAFE_MIN) {
                         // Instead of returning, we'll compare with ZERO vector
                         Vector3D mutantResult = Vector3D.ZERO;
                         assertEquals("Results should be equal when product is below safe minimum", 
                                    originalResult, mutantResult);
                         return;
                     }
                     final int deltaExp = (FastMath.getExponent(n1) - FastMath.getExponent(n2)) / 4;
                     final double x1 = FastMath.scalb(v1.getX(), -deltaExp);
                     final double y1 = FastMath.scalb(v1.getY(), -deltaExp);
                     final double z1 = FastMath.scalb(v1.getZ(), -deltaExp);
                     final double x2 = FastMath.scalb(v2.getX(), deltaExp);
                     final double y2 = FastMath.scalb(v2.getY(), deltaExp);
                     final double z2 = FastMath.scalb(v2.getZ(), deltaExp);
                     
                     // Use unquantized ratio instead of rho
                     final double ratio2 = (x1 * x2 + y1 * y2 + z1 * z2) / FastMath.scalb(n2, 2 * deltaExp);
                     final double x3 = x1 - ratio2 * x2;
                     final double y3 = y1 - ratio2 * y2;
                     final double z3 = z1 - ratio2 * z2;
                     
                     Vector3D mutantResult = new Vector3D(y3 * z2 - z3 * y2, z3 * x2 - x3 * z2, x3 * y2 - y3 * x2);
                     
                     // The results should differ due to different preconditioning
                     assertNotEquals("Mutant should produce different result due to unquantized rho", 
                                    originalResult.getX(), mutantResult.getX(), 1e-15);
                     assertNotEquals("Mutant should produce different result due to unquantized rho",
                                    originalResult.getY(), mutantResult.getY(), 1e-15);
                     assertNotEquals("Mutant should produce different result due to unquantized rho",
                                    originalResult.getZ(), mutantResult.getZ(), 1e-15);
                 }

 @Test
             public void testCrossProductDetectsRhoPrecisionMutant() {
                 // Create vectors where the ratio calculation will be sensitive to precision
                 Vector3D v1 = new Vector3D(1.0001, 2.0001, 3.0001);
                 Vector3D v2 = new Vector3D(1.0002, 2.0002, 3.0002);
                 
                 // Calculate expected cross product with original precision (8 bits)
                 Vector3D expected = Vector3D.crossProduct(v1, v2);
                 
                 // Create a slightly different vector that would produce different results with 7-bit precision
                 Vector3D v1Modified = new Vector3D(1.00015, 2.00015, 3.00015);
                 Vector3D actual = Vector3D.crossProduct(v1Modified, v2);
                 
                 // The difference should be very small with original precision, but larger with mutant
                 double distance = Vector3D.distance(expected, actual);
                 
                 // With original 8-bit precision, distance should be very small (< 1e-10)
                 // With mutant 7-bit precision, distance would be larger (> 1e-8)
                 assertTrue("Cross product should be precise to 8 bits", distance < 1e-10);
                 
                 // Additional verification - check individual components
                 assertEquals(expected.getX(), actual.getX(), 1e-10);
                 assertEquals(expected.getY(), actual.getY(), 1e-10);
                 assertEquals(expected.getZ(), actual.getZ(), 1e-10);
             }

 @Test
                public void testCrossProductWithLargeExponentDifference() {
                    // Create two vectors with norms differing by 16 orders of magnitude
                    // This will make the deltaExp difference between original and mutant significant
                    Vector3D v1 = new Vector3D(1e8, 1e8, 1e8);  // norm ~ 1.73e8
                    Vector3D v2 = new Vector3D(1e-8, 1e-8, 1e-8); // norm ~ 1.73e-8
                    
                    // Calculate expected result with original scaling (/4)
                    // For original: deltaExp = (log2(1e8) - log2(1e-8)) / 4 = (26 - (-26))/4 = 13
                    // For mutant: deltaExp = (26 - (-26))/2 = 26
                    // The mutant's more aggressive scaling will lead to different results
                    
                    // Calculate what we expect from correct implementation
                    Vector3D expected = Vector3D.crossProduct(v1, v2);
                    
                    // With mutant, the more aggressive scaling would change the result
                    // We verify the result is numerically stable by checking it's not zero
                    // and has reasonable magnitude
                    assertNotEquals(Vector3D.ZERO, expected);
                    
                    // Check the components are what we expect (calculated manually or from reference)
                    // For these specific vectors, cross product should be (0, 0, 0) theoretically,
                    // but due to numerical operations, we might get very small values
                    // The key is that the mutant would produce different values
                    double tolerance = 1e-15;
                    assertEquals(0.0, expected.getX(), tolerance);
                    assertEquals(0.0, expected.getY(), tolerance);
                    assertEquals(0.0, expected.getZ(), tolerance);
                    
                    // Additionally, test with non-parallel vectors where cross product is significant
                    Vector3D v3 = new Vector3D(1e8, 0, 0);
                    Vector3D v4 = new Vector3D(0, 1e-8, 0);
                    Vector3D expected2 = Vector3D.crossProduct(v3, v4);
                    
                    // Should get (0, 0, 1) * (1e8 * 1e-8) = (0, 0, 1)
                    assertEquals(0.0, expected2.getX(), tolerance);
                    assertEquals(0.0, expected2.getY(), tolerance);
                    assertEquals(1.0, expected2.getZ(), tolerance);
                }

 @Test
           public void testCrossProductDetectsNormRatioMutation() {
               // Create two vectors with significantly different magnitudes
               Vector3D v1 = new Vector3D(1.0e10, 2.0e10, 3.0e10);  // Large vector
               Vector3D v2 = new Vector3D(4.0, 5.0, 6.0);           // Small vector
               
               // Calculate expected cross product using original formula
               double n1 = v1.getNormSq();
               double n2 = v2.getNormSq();
               int deltaExp = (FastMath.getExponent(n1) - FastMath.getExponent(n2)) / 4;
               
               // Original ratio calculation
               double x1 = FastMath.scalb(v1.getX(), -deltaExp);
               double y1 = FastMath.scalb(v1.getY(), -deltaExp);
               double z1 = FastMath.scalb(v1.getZ(), -deltaExp);
               double x2 = FastMath.scalb(v2.getX(), deltaExp);
               double y2 = FastMath.scalb(v2.getY(), deltaExp);
               double z2 = FastMath.scalb(v2.getZ(), deltaExp);
               
               double correctRatio = (x1 * x2 + y1 * y2 + z1 * z2) / FastMath.scalb(n2, 2 * deltaExp);
               double mutatedRatio = (x1 * x2 + y1 * y2 + z1 * z2) / FastMath.scalb(n1, 2 * deltaExp);
               
               // Verify the mutation would produce different ratio
               assertNotEquals("Ratio calculation should differ between original and mutated code", 
                              correctRatio, mutatedRatio, 1.0e-10);
               
               // Now test the actual cross product
               Vector3D result = Vector3D.crossProduct(v1, v2);
               
               // Calculate expected result manually
               double rho = FastMath.rint(256 * correctRatio) / 256;
               double x3 = x1 - rho * x2;
               double y3 = y1 - rho * y2;
               double z3 = z1 - rho * z2;
               Vector3D expected = new Vector3D(
                   y3 * z2 - z3 * y2,
                   z3 * x2 - x3 * z2,
                   x3 * y2 - y3 * x2
               );
               
               // Verify cross product matches expected
               assertEquals("X component incorrect", expected.getX(), result.getX(), 1.0e-10);
               assertEquals("Y component incorrect", expected.getY(), result.getY(), 1.0e-10);
               assertEquals("Z component incorrect", expected.getZ(), result.getZ(), 1.0e-10);
           }

 @Test
     public void testCrossProductDetectsRhoPrecisionMutation() {
         // First test case with original vectors
         Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
         Vector3D v2 = new Vector3D(1.0001, 2.0001, 3.0001);
         
         // Calculate expected cross product with original 8-bit precision
         double n1 = v1.getNormSq();
         double n2 = v2.getNormSq();
         int deltaExp = (FastMath.getExponent(n1) - FastMath.getExponent(n2)) / 4;
         double x1 = FastMath.scalb(v1.getX(), -deltaExp);
         double y1 = FastMath.scalb(v1.getY(), -deltaExp);
         double z1 = FastMath.scalb(v1.getZ(), -deltaExp);
         double x2 = FastMath.scalb(v2.getX(), deltaExp);
         double y2 = FastMath.scalb(v2.getY(), deltaExp);
         double z2 = FastMath.scalb(v2.getZ(), deltaExp);
         double ratio = (x1 * x2 + y1 * y2 + z1 * z2) / FastMath.scalb(n2, 2 * deltaExp);
         double rho8bit = FastMath.rint(256 * ratio) / 256;
         
         // Calculate what the result would be with mutated 9-bit precision
         double rho9bit = FastMath.rint(512 * ratio) / 512;
         
         // Only proceed if the precision difference actually matters
         if (rho8bit != rho9bit) {
             // Calculate expected results with both precision levels
             double x3_8bit = x1 - rho8bit * x2;
             double y3_8bit = y1 - rho8bit * y2;
             double z3_8bit = z1 - rho8bit * z2;
             Vector3D expected8bit = new Vector3D(
                 y3_8bit * z2 - z3_8bit * y2,
                 z3_8bit * x2 - x3_8bit * z2,
                 x3_8bit * y2 - y3_8bit * x2);
                 
             // Get actual result
             Vector3D actual = Vector3D.crossProduct(v1, v2);
             
             // Verify the actual result matches the 8-bit precision expectation
             assertEquals(expected8bit.getX(), actual.getX(), 1.0e-15);
             assertEquals(expected8bit.getY(), actual.getY(), 1.0e-15);
             assertEquals(expected8bit.getZ(), actual.getZ(), 1.0e-15);
             
             // Additional check that the 9-bit version would be different
             double x3_9bit = x1 - rho9bit * x2;
             double y3_9bit = y1 - rho9bit * y2;
             double z3_9bit = z1 - rho9bit * z2;
             Vector3D expected9bit = new Vector3D(
                 y3_9bit * z2 - z3_9bit * y2,
                 z3_9bit * x2 - x3_9bit * z2,
                 x3_9bit * y2 - y3_9bit * x2);
                 
             // This assertion will fail if the mutant is present
             assertNotEquals(expected9bit.getX(), actual.getX(), 1.0e-15);
         } else {
             // If the precision difference doesn't matter for these vectors,
             // try with different vectors that will show the difference
             Vector3D altV1 = new Vector3D(1.0, 1.0e-8, 1.0e-16);
             Vector3D altV2 = new Vector3D(1.0 + 1.0e-8, 1.0e-8 + 1.0e-16, 1.0e-16 + 1.0e-24);
             
             // Repeat the test logic with alternate vectors
             double altN1 = altV1.getNormSq();
             double altN2 = altV2.getNormSq();
             int altDeltaExp = (FastMath.getExponent(altN1) - FastMath.getExponent(altN2)) / 4;
             double altX1 = FastMath.scalb(altV1.getX(), -altDeltaExp);
             double altY1 = FastMath.scalb(altV1.getY(), -altDeltaExp);
             double altZ1 = FastMath.scalb(altV1.getZ(), -altDeltaExp);
             double altX2 = FastMath.scalb(altV2.getX(), altDeltaExp);
             double altY2 = FastMath.scalb(altV2.getY(), altDeltaExp);
             double altZ2 = FastMath.scalb(altV2.getZ(), altDeltaExp);
             double altRatio = (altX1 * altX2 + altY1 * altY2 + altZ1 * altZ2) / FastMath.scalb(altN2, 2 * altDeltaExp);
             double altRho8bit = FastMath.rint(256 * altRatio) / 256;
             double altRho9bit = FastMath.rint(512 * altRatio) / 512;
             
             // Calculate expected results with both precision levels
             double altX3_8bit = altX1 - altRho8bit * altX2;
             double altY3_8bit = altY1 - altRho8bit * altY2;
             double altZ3_8bit = altZ1 - altRho8bit * altZ2;
             Vector3D altExpected8bit = new Vector3D(
                 altY3_8bit * altZ2 - altZ3_8bit * altY2,
                 altZ3_8bit * altX2 - altX3_8bit * altZ2,
                 altX3_8bit * altY2 - altY3_8bit * altX2);
                 
             // Get actual result with alternate vectors
             Vector3D altActual = Vector3D.crossProduct(altV1, altV2);
             
             // Verify the actual result matches the 8-bit precision expectation
             assertEquals(altExpected8bit.getX(), altActual.getX(), 1.0e-15);
             assertEquals(altExpected8bit.getY(), altActual.getY(), 1.0e-15);
             assertEquals(altExpected8bit.getZ(), altActual.getZ(), 1.0e-15);
             
             // Additional check that the 9-bit version would be different
             double altX3_9bit = altX1 - altRho9bit * altX2;
             double altY3_9bit = altY1 - altRho9bit * altY2;
             double altZ3_9bit = altZ1 - altRho9bit * altZ2;
             Vector3D altExpected9bit = new Vector3D(
                 altY3_9bit * altZ2 - altZ3_9bit * altY2,
                 altZ3_9bit * altX2 - altX3_9bit * altZ2,
                 altX3_9bit * altY2 - altY3_9bit * altX2);
                 
             // This assertion will fail if the mutant is present
             assertNotEquals(altExpected9bit.getX(), altActual.getX(), 1.0e-15);
         }
     }

 @Test
 public void testCrossProductDetectsRhoDivisionMutant() {
     // Create two simple vectors where the ratio will be exactly 0.5
     Vector3D v1 = new Vector3D(1.0, 1.0, 1.0);
     Vector3D v2 = new Vector3D(1.0, 1.0, 0.0);
     
     // Calculate expected cross product manually
     // Original rho would be 0.5 (since ratio is 2/4 = 0.5)
     // x3 = 1 - 0.5*1 = 0.5
     // y3 = 1 - 0.5*1 = 0.5
     // z3 = 1 - 0.5*0 = 1.0
     // Cross product components:
     // y3*z2 - z3*y2 = 0.5*0 - 1.0*1 = -1.0
     // z3*x2 - x3*z2 = 1.0*1 - 0.5*0 = 1.0
     // x3*y2 - y3*x2 = 0.5*1 - 0.5*1 = 0.0
     Vector3D expected = new Vector3D(-1.0, 1.0, 0.0);
     
     // Mutant would use rho = 1.0 instead of 0.5
     // This would lead to different cross product components
     Vector3D actual = Vector3D.crossProduct(v1, v2);
     
     // Verify all components match expected values
     assertEquals(expected.getX(), actual.getX(), 1.0e-15);
     assertEquals(expected.getY(), actual.getY(), 1.0e-15);
     assertEquals(expected.getZ(), actual.getZ(), 1.0e-15);
 }

}
