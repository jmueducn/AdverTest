package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import org.apache.commons.math.MathRuntimeException;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                         public void testDistance_WithNaNValues() {
                                                                                                             double[] p1 = {1.0, Double.NaN};
                                                                                                             double[] p2 = {2.0, 3.0};
                                                                                                             assertTrue(Double.isNaN(MathUtils.distance(p1, p2)));
                                                                                                         }

 @Test
                                                                                                         public void testDistance_TypicalCases() {
                                                                                                             // Test with 2D points
                                                                                                             double[] point1 = {0.0, 0.0};
                                                                                                             double[] point2 = {3.0, 4.0};
                                                                                                             assertEquals(5.0, MathUtils.distance(point1, point2), 0.0001);
                                                                                                             
                                                                                                             // Test with 3D points
                                                                                                             double[] point3 = {1.0, 2.0, 3.0};
                                                                                                             double[] point4 = {4.0, 6.0, 8.0};
                                                                                                             assertEquals(Math.sqrt(50), MathUtils.distance(point3, point4), 0.0001);
                                                                                                             
                                                                                                             // Test with negative coordinates
                                                                                                             double[] point5 = {-1.0, -2.0};
                                                                                                             double[] point6 = {2.0, 2.0};
                                                                                                             assertEquals(5.0, MathUtils.distance(point5, point6), 0.0001);
                                                                                                         }

 @Test
                                                                                                         public void testDistance_EdgeCases() {
                                                                                                             // Test with identical points
                                                                                                             double[] point1 = {5.0, 5.0};
                                                                                                             double[] point2 = {5.0, 5.0};
                                                                                                             assertEquals(0.0, MathUtils.distance(point1, point2), 0.0001);
                                                                                                             
                                                                                                             // Test with very small differences
                                                                                                             double[] point3 = {1.0000001, 2.0000001};
                                                                                                             double[] point4 = {1.0000002, 2.0000002};
                                                                                                             assertEquals(Math.sqrt(2.0E-14), MathUtils.distance(point3, point4), 0.0001);
                                                                                                             
                                                                                                             // Test with large coordinates
                                                                                                             double[] point5 = {1.0E10, 2.0E10};
                                                                                                             double[] point6 = {2.0E10, 3.0E10};
                                                                                                             assertEquals(Math.sqrt(2.0E20), MathUtils.distance(point5, point6), 1.0E10);
                                                                                                         }

 @Test
                                                                                                         public void testDistance_WithNaNValues1() {
                                                                                                             double[] point1 = {1.0, Double.NaN};
                                                                                                             double[] point2 = {2.0, 3.0};
                                                                                                             assertTrue(Double.isNaN(MathUtils.distance(point1, point2)));
                                                                                                             
                                                                                                             double[] point3 = {1.0, 2.0};
                                                                                                             double[] point4 = {Double.NaN, 3.0};
                                                                                                             assertTrue(Double.isNaN(MathUtils.distance(point3, point4)));
                                                                                                         }

 @Test
                                                                                                         public void testDistance_WithInfiniteValues() {
                                                                                                             double[] point1 = {1.0, Double.POSITIVE_INFINITY};
                                                                                                             double[] point2 = {2.0, 3.0};
                                                                                                             assertEquals(Double.POSITIVE_INFINITY, MathUtils.distance(point1, point2), 0.0001);
                                                                                                             
                                                                                                             double[] point3 = {1.0, 2.0};
                                                                                                             double[] point4 = {Double.NEGATIVE_INFINITY, 3.0};
                                                                                                             assertEquals(Double.POSITIVE_INFINITY, MathUtils.distance(point3, point4), 0.0001);
                                                                                                         }

 @Test
                                                                                                         public void testDistance_HighDimensionalSpace() {
                                                                                                             // Test with 10-dimensional points
                                                                                                             double[] point1 = new double[10];
                                                                                                             double[] point2 = new double[10];
                                                                                                             for (int i = 0; i < 10; i++) {
                                                                                                                 point1[i] = i;
                                                                                                                 point2[i] = i + 1;
                                                                                                             }
                                                                                                             assertEquals(Math.sqrt(10), MathUtils.distance(point1, point2), 0.0001);
                                                                                                         }

 @Test
                                                                                                 public void testDistance_SamePoint() {
                                                                                                     double[] p1 = {1.0, 2.0, 3.0};
                                                                                                     double[] p2 = {1.0, 2.0, 3.0};
                                                                                                     final double DELTA = 0.0001;
                                                                                                     assertEquals(0.0, MathUtils.distance(p1, p2), DELTA);
                                                                                                 }

 @Test
                                                                                                 public void testDistance_OneDimensional() {
                                                                                                     double[] p1 = {5.0};
                                                                                                     double[] p2 = {2.0};
                                                                                                     final double DELTA = 1e-15;
                                                                                                     assertEquals(3.0, MathUtils.distance(p1, p2), DELTA);
                                                                                                 }

 @Test
                                                                                                 public void testDistance_TwoDimensional() {
                                                                                                     final double DELTA = 1e-15;
                                                                                                     double[] p1 = {0.0, 0.0};
                                                                                                     double[] p2 = {3.0, 4.0};
                                                                                                     assertEquals(5.0, MathUtils.distance(p1, p2), DELTA);
                                                                                                 }

 @Test
                                                                                                 public void testDistance_ThreeDimensional() {
                                                                                                     double[] p1 = {1.0, 2.0, 3.0};
                                                                                                     double[] p2 = {4.0, 5.0, 6.0};
                                                                                                     double expected = Math.sqrt(9 + 9 + 9); // sqrt(27)
                                                                                                     final double DELTA = 0.0001;
                                                                                                     assertEquals(expected, MathUtils.distance(p1, p2), DELTA);
                                                                                                 }

 @Test
                                                                                                 public void testDistance_NegativeCoordinates() {
                                                                                                     double[] p1 = {-1.0, -2.0};
                                                                                                     double[] p2 = {-4.0, -6.0};
                                                                                                     double expected = Math.sqrt(9 + 16); // sqrt(25)
                                                                                                     final double DELTA = 1e-15; // Define delta for double comparison
                                                                                                     assertEquals(5.0, MathUtils.distance(p1, p2), DELTA);
                                                                                                 }

 @Test
                                                                                                 public void testDistance_MixedSignCoordinates() {
                                                                                                     double[] p1 = {-1.0, 2.0};
                                                                                                     double[] p2 = {3.0, -4.0};
                                                                                                     double expected = Math.sqrt(16 + 36); // sqrt(52)
                                                                                                     assertEquals(expected, MathUtils.distance(p1, p2), 1e-10);
                                                                                                 }

 @Test
                                                                                                 public void testDistance_ZeroLengthArrays() {
                                                                                                     double[] p1 = {};
                                                                                                     double[] p2 = {};
                                                                                                     final double DELTA = 0.0001;
                                                                                                     assertEquals(0.0, MathUtils.distance(p1, p2), DELTA);
                                                                                                 }

 @Test
                                                                                                 public void testDistance_DifferentLengthArrays() {
                                                                                                     double[] p1 = {1.0, 2.0};
                                                                                                     double[] p2 = {1.0};
                                                                                                     
                                                                                                     try {
                                                                                                         MathUtils.distance(p1, p2);
                                                                                                         fail("Expected IllegalArgumentException");
                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                         assertEquals("Arrays must have the same length", e.getMessage());
                                                                                                     }
                                                                                                 }

 @Test
                                                                                                 public void testDistance_WithInfiniteValues1() {
                                                                                                     double[] p1 = {1.0, Double.POSITIVE_INFINITY};
                                                                                                     double[] p2 = {2.0, 3.0};
                                                                                                     final double DELTA = 0.0001;
                                                                                                     assertEquals(Double.POSITIVE_INFINITY, MathUtils.distance(p1, p2), DELTA);
                                                                                                 }

 @Test
                                                                                                 public void testDistance_VerySmallValues() {
                                                                                                     double[] p1 = {Double.MIN_VALUE, Double.MIN_VALUE};
                                                                                                     double[] p2 = {0.0, 0.0};
                                                                                                     double expected = Math.sqrt(2 * Double.MIN_VALUE * Double.MIN_VALUE);
                                                                                                     final double DELTA = 1e-15; // Adding delta definition
                                                                                                     assertEquals(expected, MathUtils.distance(p1, p2), DELTA);
                                                                                                 }

 @Test
                                                                                                 public void testDistance_VeryLargeValues() {
                                                                                                     final double DELTA = 1e-10; // Define delta for floating point comparison
                                                                                                     double[] p1 = {Double.MAX_VALUE / 2, 0.0}; // Using half of MAX_VALUE to avoid overflow
                                                                                                     double[] p2 = {0.0, Double.MAX_VALUE / 2};
                                                                                                     double expected = Math.sqrt(2 * (Double.MAX_VALUE / 2) * (Double.MAX_VALUE / 2));
                                                                                                     assertEquals(expected, MathUtils.distance(p1, p2), DELTA);
                                                                                                 }

 @Test(expected = IllegalArgumentException.class)
                                                                                                 public void testDistance_DifferentLengthArrays1() {
                                                                                                     double[] point1 = {1.0, 2.0};
                                                                                                     double[] point2 = {1.0, 2.0, 3.0};
                                                                                                     MathUtils.distance(point1, point2);
                                                                                                 }

 @Test
                                                                                                 public void testDistance_EmptyArrays() {
                                                                                                     org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                                                                                     exceptionRule.expect(IllegalArgumentException.class);
                                                                                                     exceptionRule.expectMessage("Arrays cannot be empty");
                                                                                                     
                                                                                                     double[] point1 = {};
                                                                                                     double[] point2 = {};
                                                                                                     MathUtils.distance(point1, point2);
                                                                                                 }

 @Test
                                                                                             public void testDistance_NullFirstArray() {
                                                                                                 double[] p2 = {1.0, 2.0};
                                                                                                 try {
                                                                                                     MathUtils.distance(null, p2);
                                                                                                     fail("Expected NullPointerException");
                                                                                                 } catch (NullPointerException e) {
                                                                                                     assertEquals("Point coordinates cannot be null", e.getMessage());
                                                                                                 }
                                                                                             }

 @Test
                                                             public void testDistanceWithZeroVectors() {
                                                                 double[] zeroVector = new double[]{0.0, 0.0};
                                                                 double actual = MathUtils.distance(zeroVector, zeroVector);
                                                                 assertEquals("Distance between identical points should be 0", 
                                                                             0.0, actual, 0.0);
                                                             }

 @Test
                                                             public void testDistanceWithSimpleVectors() {
                                                                 double[] p1 = new double[]{0.0};
                                                                 double[] p2 = new double[]{1.0};
                                                                 double actual = MathUtils.distance(p1, p2);
                                                                 assertEquals("Distance between [0] and [1] should be exactly 1", 
                                                                             1.0, actual, 0.0);
                                                             }

 @Test
                                                             public void testDistanceWithKnownResult() {
                                                                 double[] p1 = new double[]{3.0, 4.0};
                                                                 double[] p2 = new double[]{0.0, 0.0};
                                                                 double actual = MathUtils.distance(p1, p2);
                                                                 assertEquals("Distance between (3,4) and (0,0) should be exactly 5", 
                                                                             5.0, actual, 0.0);
                                                             }

 @Test
                                                             public void testDistanceWithZeroLengthVectors() {
                                                                 // Test with identical points (distance should be exactly 0)
                                                                 double[] p1 = {0.0, 0.0};
                                                                 double[] p2 = {0.0, 0.0};
                                                                 double result = MathUtils.distance(p1, p2);
                                                                 assertEquals(0.0, result, 0.0);  // Exact comparison for zero distance
                                                             }

 @Test
                                                             public void testDistanceWithSmallValues() {
                                                                 // Test with very small differences that would be affected by sum=1 mutation
                                                                 double[] p1 = {0.0, 0.0};
                                                                 double[] p2 = {0.001, 0.001};
                                                                 
                                                                 // Calculate expected value manually
                                                                 double expected = Math.sqrt(0.001*0.001 + 0.001*0.001);
                                                                 double result = MathUtils.distance(p1, p2);
                                                                 
                                                                 // Verify with high precision
                                                                 assertEquals(expected, result, 1e-15);
                                                             }

 @Test
                                                             public void testDistanceWithKnownValues() {
                                                                 // Test with simple integer coordinates where we know the exact distance
                                                                 double[] p1 = {0.0, 0.0};
                                                                 double[] p2 = {3.0, 4.0};
                                                                 
                                                                 // 3-4-5 triangle should give exactly 5.0 distance
                                                                 double result = MathUtils.distance(p1, p2);
                                                                 assertEquals(5.0, result, 0.0);
                                                             }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                        public void testDistanceArrayBounds() {
                                                            // Arrange
                                                            double[] point1 = {1.0, 2.0, 3.0};
                                                            double[] point2 = {4.0, 5.0, 6.0};
                                                            
                                                            // Act - this should throw ArrayIndexOutOfBoundsException for the mutated version
                                                            MathUtils.distance(point1, point2);
                                                            
                                                            // Assert - handled by the expected exception in the annotation
                                                            // For the original version, we should also verify the correct calculation
                                                            double expectedDistance = Math.sqrt((1.0-4.0)*(1.0-4.0) + 
                                                                                    (2.0-5.0)*(2.0-5.0) + 
                                                                                    (3.0-6.0)*(3.0-6.0));
                                                            assertEquals(expectedDistance, MathUtils.distance(point1, point2), 0.0001);
                                                        }

 @Test
                                                        public void testDistanceCorrectCalculation() {
                                                            // Arrange
                                                            double[] point1 = {1.0, 2.0, 3.0};
                                                            double[] point2 = {4.0, 5.0, 6.0};
                                                            
                                                            // Act & Assert
                                                            double expectedDistance = Math.sqrt((1.0-4.0)*(1.0-4.0) + 
                                                                                    (2.0-5.0)*(2.0-5.0) + 
                                                                                    (3.0-6.0)*(3.0-6.0));
                                                            assertEquals(expectedDistance, MathUtils.distance(point1, point2), 0.0001);
                                                        }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                        public void testDistanceArrayBounds1() {
                                                            // Arrange
                                                            double[] point1 = {1.0, 2.0};
                                                            double[] point2 = {3.0, 4.0};
                                                            
                                                            // Act - should throw for mutated version
                                                            MathUtils.distance(point1, point2);
                                                        }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                            public void testDistance_ArrayBounds() {
                                                                // Arrange
                                                                double[] p1 = {1.0, 2.0, 3.0};  // non-empty array
                                                                double[] p2 = {4.0, 5.0, 6.0};  // same length as p1
                                                                
                                                                // Act - this should throw ArrayIndexOutOfBoundsException for the mutant
                                                                // but pass normally for original code
                                                                MathUtils.distance(p1, p2);
                                                                
                                                                // If we get here, the original code passed (no exception)
                                                                // So we need to explicitly fail if no exception was thrown
                                                                // (though @Test(expected) handles this for us)
                                                            }

 @Test
                                                            public void testDistance_CorrectCalculation() {
                                                                // Arrange
                                                                double[] p1 = {0.0, 0.0};
                                                                double[] p2 = {3.0, 4.0};
                                                                double expected = 5.0; // sqrt(3² + 4²) = 5
                                                                
                                                                // Act
                                                                double result = MathUtils.distance(p1, p2);
                                                                
                                                                // Assert
                                                                assertEquals(expected, result, 0.0001);
                                                            }

 @Test
                                                           public void testDistance_ShouldIncludeFirstElement() {
                                                               // Arrange
                                                               double[] p1 = {1.0, 0.0, 0.0};  // First element is different
                                                               double[] p2 = {0.0, 0.0, 0.0};
                                                               
                                                               // Expected distance = sqrt((1-0)² + (0-0)² + (0-0)²) = 1.0
                                                               double expected = 1.0;
                                                               
                                                               // Act
                                                               double actual = MathUtils.distance(p1, p2);
                                                               
                                                               // Assert
                                                               assertEquals("Distance calculation should include first element", 
                                                                           expected, actual, 0.0001);
                                                               
                                                               // Additional test with single-element arrays
                                                               double[] single1 = {5.0};
                                                               double[] single2 = {3.0};
                                                               double expectedSingle = 2.0; // sqrt((5-3)²) = 2.0
                                                               assertEquals("Should work with single-element arrays",
                                                                           expectedSingle, 
                                                                           MathUtils.distance(single1, single2), 
                                                                           0.0001);
                                                           }

 @Test
                                                           public void testDistanceShouldIncludeFirstElement() {
                                                               // Test case where first elements differ significantly
                                                               double[] p1 = {10.0, 2.0, 3.0};  // First element is large
                                                               double[] p2 = {1.0, 2.0, 3.0};   // First element is small
                                                               
                                                               // Original should calculate sqrt((10-1)² + (2-2)² + (3-3)²) = sqrt(81) = 9.0
                                                               // Mutant would calculate sqrt((2-2)² + (3-3)²) = sqrt(0) = 0.0
                                                               double expected = 9.0;
                                                               double actual = MathUtils.distance(p1, p2);
                                                               
                                                               assertEquals("Distance calculation should include first element", 
                                                                           expected, actual, 0.0001);
                                                           }

 @Test
                                                           public void testDistanceWithSingleElementArrays() {
                                                               // Test case with single-element arrays
                                                               double[] p1 = {5.0};
                                                               double[] p2 = {2.0};
                                                               
                                                               // Original should calculate sqrt((5-2)²) = 3.0
                                                               // Mutant would skip the only element and calculate sqrt(0) = 0.0
                                                               double expected = 3.0;
                                                               double actual = MathUtils.distance(p1, p2);
                                                               
                                                               assertEquals("Distance calculation should work with single-element arrays",
                                                                           expected, actual, 0.0001);
                                                           }

 @Test
                                                           public void testDistanceWhereOnlyFirstElementsDiffer() {
                                                               // Test case where only first elements differ
                                                               double[] p1 = {4.0, 1.0, 1.0, 1.0};
                                                               double[] p2 = {1.0, 1.0, 1.0, 1.0};
                                                               
                                                               // Original should calculate sqrt((4-1)² + 0 + 0 + 0) = 3.0
                                                               // Mutant would calculate sqrt(0 + 0 + 0) = 0.0
                                                               double expected = 3.0;
                                                               double actual = MathUtils.distance(p1, p2);
                                                               
                                                               assertEquals("Distance should be non-zero when only first elements differ",
                                                                           expected, actual, 0.0001);
                                                           }

 @Test
                                                          public void testDistanceShouldCalculateEuclideanDistance() {
                                                              // Test case that will catch the p1[i] + p2[i] mutation
                                                              double[] point1 = {1.0, 2.0, 3.0};
                                                              double[] point2 = {4.0, 5.0, 6.0};
                                                              
                                                              // Manually calculate expected distance:
                                                              // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                                                              double expectedDistance = Math.sqrt(27.0);
                                                              
                                                              // If mutation exists (using p1[i] + p2[i]):
                                                              // sqrt((1+4)² + (2+5)² + (3+6)²) = sqrt(25 + 49 + 81) = sqrt(155) ≈ 12.4499
                                                              // This is significantly different from expected
                                                              
                                                              double actualDistance = MathUtils.distance(point1, point2);
                                                              
                                                              // Assert with delta for floating point precision
                                                              assertEquals("Distance calculation is incorrect", 
                                                                          expectedDistance, actualDistance, 1e-10);
                                                          }

 @Test
                                                          public void testDistanceWithZeroVectors1() {
                                                              // Test with zero vectors
                                                              double[] zeroVector = {0.0, 0.0, 0.0};
                                                              double[] point = {1.0, 2.0, 3.0};
                                                              
                                                              // Expected distance from zero vector
                                                              double expectedDistance = Math.sqrt(1.0 + 4.0 + 9.0); // sqrt(14)
                                                              
                                                              double actualDistance = MathUtils.distance(zeroVector, point);
                                                              
                                                              assertEquals(expectedDistance, actualDistance, 1e-10);
                                                          }

 @Test
                                                          public void testDistanceShouldCalculateEuclideanDistance1() {
                                                              // Test case that will catch the mutant
                                                              double[] p1 = {1.0, 2.0, 3.0};
                                                              double[] p2 = {4.0, 5.0, 6.0};
                                                              
                                                              // Calculate expected value manually
                                                              double expected = Math.sqrt(
                                                                  Math.pow(1.0 - 4.0, 2) + 
                                                                  Math.pow(2.0 - 5.0, 2) + 
                                                                  Math.pow(3.0 - 6.0, 2)
                                                              );
                                                              
                                                              // The mutant would calculate:
                                                              // Math.sqrt(Math.pow(1.0 + 4.0, 2) + Math.pow(2.0 + 5.0, 2) + Math.pow(3.0 + 6.0, 2))
                                                              // which is 13.076696... instead of 5.196152...
                                                              
                                                              double actual = MathUtils.distance(p1, p2);
                                                              
                                                              assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                                          }

 @Test
                                                          public void testDistanceWithNegativeNumbers() {
                                                              // Another test case with negative numbers
                                                              double[] p1 = {-1.0, -2.0};
                                                              double[] p2 = {1.0, 2.0};
                                                              
                                                              double expected = Math.sqrt(
                                                                  Math.pow(-1.0 - 1.0, 2) + 
                                                                  Math.pow(-2.0 - 2.0, 2)
                                                              );
                                                              
                                                              double actual = MathUtils.distance(p1, p2);
                                                              
                                                              assertEquals("Distance with negative numbers incorrect", expected, actual, 0.0001);
                                                          }

 @Test
                                                          public void testDistanceWithMixedSignNumbers() {
                                                              // Test case with mixed positive and negative numbers
                                                              double[] p1 = {-1.0, 2.0};
                                                              double[] p2 = {1.0, -2.0};
                                                              
                                                              double expected = Math.sqrt(
                                                                  Math.pow(-1.0 - 1.0, 2) + 
                                                                  Math.pow(2.0 - (-2.0), 2)
                                                              );
                                                              
                                                              double actual = MathUtils.distance(p1, p2);
                                                              
                                                              assertEquals("Distance with mixed signs incorrect", expected, actual, 0.0001);
                                                          }

 @Test
                                                     public void testDistanceWithOppositeVectors() {
                                                         // Additional test case where p1 = -p2
                                                         // This case wouldn't catch the mutation since p1[i] - p2[i] = p1[i] + p2[i] when p2 = -p1
                                                         double[] point1 = {1.0, -2.0, 3.0};
                                                         double[] point2 = {-1.0, 2.0, -3.0};
                                                         
                                                         // Both original and mutated would give same result here
                                                         double diff1 = 1.0 - (-1.0);
                                                         double diff2 = -2.0 - 2.0;
                                                         double diff3 = 3.0 - (-3.0);
                                                         double expectedDistance = Math.sqrt(diff1 * diff1 + diff2 * diff2 + diff3 * diff3);
                                                         
                                                         double actualDistance = MathUtils.distance(point1, point2);
                                                         
                                                         assertEquals(expectedDistance, actualDistance, 1e-10);
                                                     }

 @Test
                                                     public void testDistanceShouldDetectMutant() {
                                                         // Arrange - create asymmetric test data where p1[i] != p2[i]
                                                         double[] p1 = {3.0, 4.0, 5.0};
                                                         double[] p2 = {1.0, 2.0, 3.0};
                                                         
                                                         // Act - calculate distance
                                                         double result = MathUtils.distance(p1, p2);
                                                         
                                                         // Assert - verify correct calculation
                                                         // Expected calculation:
                                                         // sqrt((3-1)² + (4-2)² + (5-3)²) = sqrt(4 + 4 + 4) = sqrt(12) ≈ 3.4641
                                                         double expected = Math.sqrt(12.0);
                                                         assertEquals("Distance calculation is incorrect", expected, result, 0.0001);
                                                         
                                                         // Additional verification that the mutant would fail:
                                                         // If mutant is active, it would calculate:
                                                         // sqrt((1-3)² + (2-4)² + (3-5)²) = sqrt(4 + 4 + 4) = sqrt(12) ≈ 3.4641
                                                         // Wait - this shows the mutant would actually produce the same result!
                                                         // Need a different approach...
                                                         
                                                         // Better test: use arrays where order matters due to NaN/Infinity
                                                         double[] p3 = {Double.NaN, Double.POSITIVE_INFINITY};
                                                         double[] p4 = {1.0, 2.0};
                                                         double result2 = MathUtils.distance(p3, p4);
                                                         assertTrue("Should detect NaN in distance calculation", Double.isNaN(result2));
                                                     }

 @Test
                                                     public void testDistanceShouldCalculateCorrectEuclideanDistance() {
                                                         // Arrange
                                                         double[] p1 = {1.0, 2.0, 3.0};
                                                         double[] p2 = {4.0, 5.0, 6.0};
                                                         
                                                         // Expected calculation:
                                                         // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152422706632
                                                         
                                                         // Act
                                                         double result = MathUtils.distance(p1, p2);
                                                         
                                                         // Assert
                                                         assertEquals(5.196152422706632, result, 1e-10);
                                                         
                                                         // Additional verification with single dimension
                                                         double[] singleDim1 = {2.0};
                                                         double[] singleDim2 = {5.0};
                                                         double singleResult = MathUtils.distance(singleDim1, singleDim2);
                                                         assertEquals(3.0, singleResult, 1e-10);
                                                     }

 @Test
                                                 public void testDistanceShouldCalculateWithCorrectOperandOrder() {
                                                     // Arrange - using values where subtraction order matters for non-squared operations
                                                     double[] p1 = {Double.NaN, Double.POSITIVE_INFINITY};
                                                     double[] p2 = {1.0, Double.POSITIVE_INFINITY};
                                                     
                                                     // Act
                                                     double result = MathUtils.distance(p1, p2);
                                                     
                                                     // Assert - NaN should propagate through the calculation
                                                     assertTrue(Double.isNaN(result));
                                                 }

 @Test
                                                    public void testDistanceWithNonTrivialDifferences() {
                                                        // Test case with differences of 2 and 3
                                                        double[] p1 = {1.0, 2.0};
                                                        double[] p2 = {3.0, 5.0};  // Differences are 2 and 3
                                                        
                                                        // Expected calculation: sqrt(2² + 3²) = sqrt(4 + 9) = sqrt(13) ≈ 3.605551275463989
                                                        double expected = Math.sqrt(13);
                                                        double actual = MathUtils.distance(p1, p2);
                                                        
                                                        // Verify with delta for floating point precision
                                                        assertEquals("Distance calculation incorrect", expected, actual, 1e-10);
                                                        
                                                        // Another test case with single dimension
                                                        double[] p3 = {4.0};
                                                        double[] p4 = {6.0};  // Difference is 2
                                                        
                                                        // Expected: sqrt(2²) = 2.0
                                                        assertEquals(2.0, MathUtils.distance(p3, p4), 1e-10);
                                                    }

 @Test
                                                    public void testDistanceShouldCalculateEuclideanDistance2() {
                                                        // Test case with differences > 1 to expose the mutation
                                                        double[] p1 = {3.0, 4.0, 0.0};  // 3D point
                                                        double[] p2 = {0.0, 0.0, 0.0};  // Origin
                                                        
                                                        // Expected Euclidean distance: sqrt((3-0)² + (4-0)² + (0-0)²) = sqrt(9 + 16 + 0) = 5
                                                        double expected = 5.0;
                                                        double actual = MathUtils.distance(p1, p2);
                                                        
                                                        assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                                        
                                                        // Additional test case with negative differences
                                                        double[] p3 = {-1.0, -2.0};
                                                        double[] p4 = {2.0, 3.0};
                                                        
                                                        // Expected: sqrt((-1-2)² + (-2-3)²) = sqrt(9 + 25) = sqrt(34) ≈ 5.83095
                                                        expected = Math.sqrt(34);
                                                        actual = MathUtils.distance(p3, p4);
                                                        
                                                        assertEquals("Distance calculation with negative values is incorrect", 
                                                                    expected, actual, 0.0001);
                                                    }

 @Test
                                               public void testDistanceShouldCalculateCorrectEuclideanDistance1() {
                                                   // Arrange
                                                   double[] p1 = {1.0, 2.0, 3.0};
                                                   double[] p2 = {4.0, 5.0, 6.0};
                                                   
                                                   // Expected calculation:
                                                   // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                                                   // sqrt(27) ≈ 5.196152422706632
                                                   double expected = 5.196152422706632;
                                                   
                                                   // Act
                                                   double result = MathUtils.distance(p1, p2);
                                                   
                                                   // Assert
                                                   assertEquals("Distance calculation should match expected Euclidean distance", 
                                                               expected, result, 1e-10);
                                                   
                                                   // Additional assertion to ensure sum wasn't subtracted
                                                   // With the mutation, result would be NaN because of negative sum
                                                   assertFalse("Result should not be NaN (which would happen with negative sum)", 
                                                               Double.isNaN(result));
                                               }

 @Test
                                                   public void testDistanceShouldCalculateCorrectEuclideanDistance2() {
                                                       // Simple case that would fail with the mutant
                                                       double[] p1 = {1.0, 2.0};
                                                       double[] p2 = {4.0, 6.0};
                                                       
                                                       // Expected distance calculation:
                                                       // sqrt((1-4)^2 + (2-6)^2) = sqrt(9 + 16) = sqrt(25) = 5.0
                                                       double expected = 5.0;
                                                       double actual = MathUtils.distance(p1, p2);
                                                       
                                                       assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                                       
                                                       // Test with zeros to ensure basic addition works
                                                       double[] zeros1 = {0.0, 0.0};
                                                       double[] zeros2 = {0.0, 0.0};
                                                       assertEquals(0.0, MathUtils.distance(zeros1, zeros2), 0.0001);
                                                       
                                                       // Test with single dimension
                                                       double[] single1 = {5.0};
                                                       double[] single2 = {2.0};
                                                       assertEquals(3.0, MathUtils.distance(single1, single2), 0.0001);
                                                       
                                                       // Test with negative coordinates
                                                       double[] neg1 = {-1.0, -2.0};
                                                       double[] neg2 = {-4.0, -6.0};
                                                       assertEquals(5.0, MathUtils.distance(neg1, neg2), 0.0001);
                                                       
                                                       // Test with mixed positive/negative
                                                       double[] mixed1 = {-1.0, 2.0};
                                                       double[] mixed2 = {4.0, -6.0};
                                                       assertEquals(9.43398, MathUtils.distance(mixed1, mixed2), 0.0001);
                                                   }

 @Test
                                                  public void testDistanceShouldReturnSquareRootOfSumOfSquares() {
                                                      // Test case where sum of squares is 25 (5^2)
                                                      double[] p1 = {3, 4}; // 3^2 + 4^2 = 9 + 16 = 25
                                                      double[] p2 = {0, 0};
                                                      double expected = 5.0; // sqrt(25) = 5
                                                      double actual = MathUtils.distance(p1, p2);
                                                      assertEquals("Distance should be square root of sum of squares", expected, actual, 0.0001);
                                                      
                                                      // Test case where sum of squares is not a perfect square
                                                      double[] p3 = {1, 1}; // 1^2 + 1^2 = 1 + 1 = 2
                                                      double[] p4 = {0, 0};
                                                      expected = Math.sqrt(2); // approximately 1.4142
                                                      actual = MathUtils.distance(p3, p4);
                                                      assertEquals("Distance should be square root of sum of squares", expected, actual, 0.0001);
                                                      
                                                      // Test case with 3 dimensions
                                                      double[] p5 = {1, 2, 2}; // 1^2 + 2^2 + 2^2 = 1 + 4 + 4 = 9
                                                      double[] p6 = {0, 0, 0};
                                                      expected = 3.0; // sqrt(9) = 3
                                                      actual = MathUtils.distance(p5, p6);
                                                      assertEquals("Distance should be square root of sum of squares", expected, actual, 0.0001);
                                                  }

 @Test
                                                  public void testDistanceShouldReturnSquareRootOfSumOfSquares1() {
                                                      // Test case that will detect the sqrt vs sum mutant
                                                      double[] p1 = {3.0, 4.0};  // 3-4-5 triangle
                                                      double[] p2 = {0.0, 0.0};
                                                      
                                                      // Calculate expected value manually
                                                      double expectedSumOfSquares = (3.0*3.0) + (4.0*4.0); // 9 + 16 = 25
                                                      double expectedDistance = Math.sqrt(expectedSumOfSquares); // 5.0
                                                      
                                                      // Call the method
                                                      double actual = MathUtils.distance(p1, p2);
                                                      
                                                      // Verify the result is the square root (Euclidean distance)
                                                      // not just the sum of squares
                                                      assertEquals("Distance should be square root of sum of squares", 
                                                                  expectedDistance, actual, 0.0001);
                                                      
                                                      // Additional verification that it's not just returning the sum
                                                      assertNotEquals("Should not return just the sum of squares", 
                                                                     expectedSumOfSquares, actual, 0.0001);
                                                  }

 @Test
                                                  public void testDistanceWithAnotherKnownValue() {
                                                      // Another test case with different values
                                                      double[] p1 = {1.0, 1.0, 1.0, 1.0}; // 4 dimensions
                                                      double[] p2 = {0.0, 0.0, 0.0, 0.0};
                                                      
                                                      // Expected calculations
                                                      double expectedSumOfSquares = 4.0; // 1+1+1+1
                                                      double expectedDistance = 2.0; // sqrt(4)
                                                      
                                                      double actual = MathUtils.distance(p1, p2);
                                                      
                                                      assertEquals("Distance should be square root of sum of squares", 
                                                                  expectedDistance, actual, 0.0001);
                                                      assertNotEquals("Should not return just the sum of squares", 
                                                                     expectedSumOfSquares, actual, 0.0001);
                                                  }

 @Test
                                                 public void testDistanceExactCalculation() {
                                                     // Test with simple known values where distance is easy to calculate
                                                     double[] p1 = {0.0, 0.0};
                                                     double[] p2 = {3.0, 4.0}; // 3-4-5 triangle
                                                     
                                                     // Expected distance is exactly 5.0 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5
                                                     double expected = 5.0;
                                                     double actual = MathUtils.distance(p1, p2);
                                                     
                                                     // Use assertEquals with delta 0 to catch exact value differences
                                                     assertEquals("Distance calculation should be exact", expected, actual, 0.0);
                                                     
                                                     // Additional test case with zero distance
                                                     double[] p3 = {1.0, 2.0};
                                                     double[] p4 = {1.0, 2.0};
                                                     assertEquals("Zero distance case", 0.0, MathUtils.distance(p3, p4), 0.0);
                                                     
                                                     // Test case with one-dimensional points
                                                     double[] p5 = {2.0};
                                                     double[] p6 = {5.0};
                                                     assertEquals("One-dimensional distance", 3.0, MathUtils.distance(p5, p6), 0.0);
                                                 }

 @Test
                                                 public void testDistance() {
                                                     // Test with zero-length arrays (should return 0)
                                                     double[] empty1 = {};
                                                     double[] empty2 = {};
                                                     assertEquals(0.0, MathUtils.distance(empty1, empty2), 0.0);
                                                     
                                                     // Test with single-element arrays where distance is 0
                                                     double[] single1 = {5.0};
                                                     double[] single2 = {5.0};
                                                     assertEquals(0.0, MathUtils.distance(single1, single2), 0.0);
                                                     
                                                     // Test with single-element arrays where distance is known
                                                     double[] a = {0.0};
                                                     double[] b = {3.0};
                                                     assertEquals(3.0, MathUtils.distance(a, b), 0.0);
                                                     
                                                     // Test with multiple elements where distance is known
                                                     double[] p1 = {0.0, 0.0};
                                                     double[] p2 = {3.0, 4.0};
                                                     assertEquals(5.0, MathUtils.distance(p1, p2), 0.0);  // 3-4-5 triangle
                                                     
                                                     // Test with negative coordinates
                                                     double[] p3 = {1.0, 2.0, 3.0};
                                                     double[] p4 = {-1.0, -2.0, -3.0};
                                                     double expected = Math.sqrt(4 + 16 + 36); // sqrt(56)
                                                     assertEquals(expected, MathUtils.distance(p3, p4), 0.0);
                                                 }

 @Test
                                                public void testDistanceWithZeroLengthVectors1() {
                                                    // Test with zero vectors - should return exactly 0
                                                    double[] zeroVector = new double[]{0.0, 0.0, 0.0};
                                                    double result = MathUtils.distance(zeroVector, zeroVector);
                                                    
                                                    // The mutant would return sqrt(0.5) ≈ 0.7071 instead of 0
                                                    assertEquals("Distance between identical points should be 0", 
                                                                 0.0, result, 0.0000001);
                                                }

 @Test
                                                public void testDistanceWithVeryClosePoints() {
                                                    // Test with points very close to each other
                                                    double[] p1 = new double[]{1.0, 1.0, 1.0};
                                                    double[] p2 = new double[]{1.0000001, 1.0000001, 1.0000001};
                                                    
                                                    // Calculate expected value without the mutation
                                                    double expected = 0.0;
                                                    for (int i = 0; i < p1.length; i++) {
                                                        final double dp = p1[i] - p2[i];
                                                        expected += dp * dp;
                                                    }
                                                    expected = Math.sqrt(expected);
                                                    
                                                    double result = MathUtils.distance(p1, p2);
                                                    
                                                    // The mutant would add 0.5 to the sum before sqrt
                                                    assertEquals("Distance calculation is incorrect with small differences",
                                                                 expected, result, 0.0000001);
                                                }

 @Test
                                                public void testDistanceWithZeroLengthVectors2() {
                                                    // Test with zero-length vectors (should return 0)
                                                    double[] zeroVector = new double[0];
                                                    double result = MathUtils.distance(zeroVector, zeroVector);
                                                    assertEquals(0.0, result, 0.0);
                                                }

 @Test
                                                public void testDistanceWithIdenticalPoints() {
                                                    // Test with identical points (should return 0)
                                                    double[] point1 = {1.0, 2.0, 3.0};
                                                    double[] point2 = {1.0, 2.0, 3.0};
                                                    double result = MathUtils.distance(point1, point2);
                                                    assertEquals(0.0, result, 0.0);
                                                }

 @Test
                                                public void testDistanceWithVeryClosePoints1() {
                                                    // Test with very close points where the distance should be minimal
                                                    double[] point1 = {1.0, 1.0};
                                                    double[] point2 = {1.0000001, 1.0000001};
                                                    double expected = Math.sqrt(2 * Math.pow(0.0000001, 2));
                                                    double result = MathUtils.distance(point1, point2);
                                                    assertEquals(expected, result, 1e-10);
                                                }

 @Test
                                               public void testDistanceShouldProcessAllDimensions() {
                                                   // Create test points with 3 dimensions where the last dimension contributes significantly
                                                   double[] p1 = {1.0, 2.0, 3.0};
                                                   double[] p2 = {4.0, 5.0, 6.0};
                                                   
                                                   // Manually calculate expected distance (all dimensions included)
                                                   double expected = Math.sqrt(
                                                       (4.0-1.0)*(4.0-1.0) + 
                                                       (5.0-2.0)*(5.0-2.0) + 
                                                       (6.0-3.0)*(6.0-3.0)
                                                   );
                                                   
                                                   // Calculate using the method
                                                   double actual = MathUtils.distance(p1, p2);
                                                   
                                                   // Assert equality with delta for floating point precision
                                                   assertEquals("Distance calculation should include all dimensions", 
                                                              expected, actual, 0.0001);
                                                   
                                                   // Additional check: verify the last dimension was included by checking
                                                   // against a value that would be correct if last dimension was skipped
                                                   double wrongIfLastSkipped = Math.sqrt(
                                                       (4.0-1.0)*(4.0-1.0) + 
                                                       (5.0-2.0)*(5.0-2.0)
                                                   );
                                                   assertNotEquals("Distance should not match value with last dimension skipped",
                                                                 wrongIfLastSkipped, actual, 0.0001);
                                               }

 @Test
                                               public void testDistanceShouldProcessAllElements() {
                                                   // Test with 2-element arrays where distance comes from second element
                                                   double[] p1 = {0.0, 0.0};
                                                   double[] p2 = {0.0, 3.0};
                                                   
                                                   // Expected distance is 3.0 (from second element only)
                                                   double expected = 3.0;
                                                   double actual = MathUtils.distance(p1, p2);
                                                   
                                                   // This will fail for the mutant since it skips last element
                                                   assertEquals("Distance calculation should process all array elements", 
                                                               expected, actual, 0.0001);
                                                   
                                                   // Additional test with 3 elements to be thorough
                                                   double[] p3 = {0.0, 0.0, 0.0};
                                                   double[] p4 = {0.0, 0.0, 4.0};
                                                   assertEquals("Distance calculation should process all array elements", 
                                                               4.0, MathUtils.distance(p3, p4), 0.0001);
                                               }

 @Test
                                              public void testDistanceWithEmptyArrays() {
                                                  // Test with empty arrays - should return 0 distance
                                                  double[] empty1 = new double[0];
                                                  double[] empty2 = new double[0];
                                                  
                                                  // Original code would handle this fine (loop never executes)
                                                  // Mutated code (i != p1.length) would fail since i starts at 0 and p1.length is 0
                                                  double result = MathUtils.distance(empty1, empty2);
                                                  assertEquals(0.0, result, 0.0001);
                                              }

 @Test
                                              public void testDistanceWithSingleElementArrays1() {
                                                  // Normal case to ensure basic functionality still works
                                                  double[] p1 = {3.0};
                                                  double[] p2 = {7.0};
                                                  double expected = 4.0; // sqrt((3-7)^2) = 4
                                                  double result = MathUtils.distance(p1, p2);
                                                  assertEquals(expected, result, 0.0001);
                                              }

 @Test
                                              public void testDistanceWithMultipleElements() {
                                                  // More complex case
                                                  double[] p1 = {1.0, 2.0, 3.0};
                                                  double[] p2 = {4.0, 5.0, 6.0};
                                                  double expected = Math.sqrt(9 + 9 + 9); // sqrt(27)
                                                  double result = MathUtils.distance(p1, p2);
                                                  assertEquals(expected, result, 0.0001);
                                              }

 @Test
                                              public void testDistanceWithEmptyArrays1() {
                                                  // Setup
                                                  double[] empty1 = new double[0];
                                                  double[] empty2 = new double[0];
                                                  
                                                  // Expected behavior - should return 0.0 for zero-length arrays
                                                  double expected = 0.0;
                                                  
                                                  // Test
                                                  double actual = MathUtils.distance(empty1, empty2);
                                                  
                                                  // Verify
                                                  assertEquals("Distance between empty arrays should be 0.0", 
                                                              expected, actual, 0.0001);
                                              }

 @Test
                                              public void testDistanceWithNormalArrays() {
                                                  // Setup normal case to ensure basic functionality works
                                                  double[] p1 = {1.0, 2.0, 3.0};
                                                  double[] p2 = {4.0, 5.0, 6.0};
                                                  
                                                  // Expected distance: sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(27) ≈ 5.196152
                                                  double expected = 5.196152;
                                                  
                                                  // Test
                                                  double actual = MathUtils.distance(p1, p2);
                                                  
                                                  // Verify
                                                  assertEquals("Distance calculation incorrect", 
                                                              expected, actual, 0.0001);
                                              }

 @Test
                                             public void testDistanceShouldCalculateEuclideanDistance3() {
                                                 // Test case that will catch the p1[i] * p2[i] mutation
                                                 double[] p1 = {1.0, -2.0, 3.0};  // Includes negative value to catch multiplication vs subtraction
                                                 double[] p2 = {4.0, 5.0, 6.0};
                                                 
                                                 // Expected calculation:
                                                 // Original: sqrt((1-4)² + (-2-5)² + (3-6)²) = sqrt(9 + 49 + 9) = sqrt(67) ≈ 8.18535
                                                 // Mutated: sqrt((1*4)² + (-2*5)² + (3*6)²) = sqrt(16 + 100 + 324) = sqrt(440) ≈ 20.97617
                                                 double expected = 8.18535;
                                                 double actual = MathUtils.distance(p1, p2);
                                                 
                                                 // Using delta for floating point comparison
                                                 assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                                 
                                                 // Additional test case with zeros to ensure basic functionality
                                                 double[] zeros1 = {0.0, 0.0};
                                                 double[] zeros2 = {0.0, 0.0};
                                                 assertEquals(0.0, MathUtils.distance(zeros1, zeros2), 0.0);
                                                 
                                                 // Test case with single element arrays
                                                 double[] single1 = {5.0};
                                                 double[] single2 = {2.0};
                                                 assertEquals(3.0, MathUtils.distance(single1, single2), 0.0);
                                             }

 @Test
                                         public void testDistanceDetectsSubtractionMutation() {
                                             // Test case where subtraction and multiplication produce different results
                                             double[] p1 = {3.0, 4.0};  // Point (3,4)
                                             double[] p2 = {1.0, 2.0};  // Point (1,2)
                                             
                                             // Original correct calculation:
                                             // sqrt((3-1)² + (4-2)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.828
                                             // Mutated calculation:
                                             // sqrt((3*1) + (4*2)) = sqrt(3 + 8) = sqrt(11) ≈ 3.316
                                             
                                             double expected = Math.sqrt(8.0);  // Correct result
                                             double actual = MathUtils.distance(p1, p2);
                                             
                                             // Assert with delta for floating point precision
                                             assertEquals("Distance calculation should use subtraction, not multiplication", 
                                                         expected, actual, 0.0001);
                                             
                                             // Additional test case with negative numbers
                                             double[] p3 = {-1.0, -2.0};
                                             double[] p4 = {-3.0, -4.0};
                                             
                                             // Original: sqrt((-1 - -3)² + (-2 - -4)²) = sqrt(4 + 4) = sqrt(8)
                                             // Mutated: sqrt((-1 * -3) + (-2 * -4)) = sqrt(3 + 8) = sqrt(11)
                                             
                                             expected = Math.sqrt(8.0);
                                             actual = MathUtils.distance(p3, p4);
                                             assertEquals("Should handle negative coordinates correctly",
                                                         expected, actual, 0.0001);
                                             
                                             // Test with single dimension
                                             double[] p5 = {5.0};
                                             double[] p6 = {2.0};
                                             
                                             // Original: sqrt((5-2)²) = 3
                                             // Mutated: sqrt(5*2) = sqrt(10) ≈ 3.162
                                             
                                             assertEquals("Should work with single dimension arrays",
                                                         3.0, MathUtils.distance(p5, p6), 0.0001);
                                         }

 @Test
                                            public void testDistanceShouldCalculateEuclideanDistanceNotRatio() {
                                                // Test case that will fail with the mutated version
                                                double[] p1 = {3.0, 4.0};  // Point (3,4)
                                                double[] p2 = {1.0, 1.0};  // Point (1,1)
                                                
                                                // Original calculation: sqrt((3-1)² + (4-1)²) = sqrt(4 + 9) = sqrt(13) ≈ 3.6055
                                                double expectedDistance = Math.sqrt(13.0);
                                                
                                                // Mutated version would calculate: sqrt((3/1)² + (4/1)²) = sqrt(9 + 16) = 5.0
                                                // This is different from expectedDistance
                                                
                                                double actualDistance = MathUtils.distance(p1, p2);
                                                
                                                // Assert with delta for floating point precision
                                                assertEquals("Distance should be calculated using differences, not ratios", 
                                                            expectedDistance, actualDistance, 0.0001);
                                                
                                                // Additional test case with different values
                                                double[] p3 = {5.0, 12.0};
                                                double[] p4 = {2.0, 3.0};
                                                expectedDistance = Math.sqrt(9.0 + 81.0); // sqrt(90) ≈ 9.4868
                                                actualDistance = MathUtils.distance(p3, p4);
                                                assertEquals(expectedDistance, actualDistance, 0.0001);
                                                
                                                // Edge case: one coordinate is zero (would cause division to behave very differently)
                                                double[] p5 = {0.0, 1.0};
                                                double[] p6 = {1.0, 1.0};
                                                expectedDistance = 1.0; // sqrt(1 + 0)
                                                actualDistance = MathUtils.distance(p5, p6);
                                                assertEquals(expectedDistance, actualDistance, 0.0001);
                                            }

 @Test
                                            public void testDistanceShouldUseSubtractionNotDivision() {
                                                // Arrange
                                                double[] p1 = {3.0, 4.0};  // Simple coordinates
                                                double[] p2 = {1.0, 2.0};  // Different from p1
                                                
                                                // Expected calculation with subtraction:
                                                // dp1 = 3.0 - 1.0 = 2.0
                                                // dp2 = 4.0 - 2.0 = 2.0
                                                // sum = 2.0² + 2.0² = 4.0 + 4.0 = 8.0
                                                // expected = sqrt(8.0) ≈ 2.8284271247461903
                                                double expected = Math.sqrt(8.0);
                                                
                                                // If mutation exists (using division):
                                                // dp1 = 3.0 / 1.0 = 3.0
                                                // dp2 = 4.0 / 2.0 = 2.0
                                                // sum = 3.0² + 2.0² = 9.0 + 4.0 = 13.0
                                                // mutated = sqrt(13.0) ≈ 3.605551275463989
                                                double mutatedValue = Math.sqrt(13.0);
                                                
                                                // Act
                                                double actual = MathUtils.distance(p1, p2);
                                                
                                                // Assert
                                                assertEquals("Distance calculation should use subtraction, not division", 
                                                            expected, actual, 0.000001);
                                                
                                                // Additional assertion to explicitly show the difference
                                                assertNotEquals("Distance should not equal the mutated calculation", 
                                                               mutatedValue, actual, 0.000001);
                                            }

 @Test
                                           public void testDistanceDetectsCubeMutation() {
                                               // Test case with coordinate differences that will expose the mutation
                                               double[] p1 = {2.0, 3.0};  // First point
                                               double[] p2 = {1.0, 1.0};  // Second point
                                               
                                               // Manually calculate expected correct distance:
                                               // diff1 = 2.0 - 1.0 = 1.0
                                               // diff2 = 3.0 - 1.0 = 2.0
                                               // sum_of_squares = (1.0)^2 + (2.0)^2 = 1 + 4 = 5
                                               // expected_distance = sqrt(5) ≈ 2.2360679775
                                               
                                               // With mutation (sum += dp*dp*dp):
                                               // sum_of_cubes = (1.0)^3 + (2.0)^3 = 1 + 8 = 9
                                               // mutated_distance = sqrt(9) = 3.0
                                               
                                               double expected = Math.sqrt(5);  // Correct result
                                               double actual = MathUtils.distance(p1, p2);
                                               
                                               // Assert with delta for floating point precision
                                               assertEquals("Distance calculation should use squared differences", 
                                                           expected, actual, 0.0001);
                                               
                                               // Additional test case with negative differences
                                               double[] p3 = {-1.0, -2.0};
                                               double[] p4 = {0.0, 0.0};
                                               
                                               // Expected: sqrt((-1)^2 + (-2)^2) = sqrt(1 + 4) = sqrt(5)
                                               // Mutated: sqrt((-1)^3 + (-2)^3) = sqrt(-1 + -8) = sqrt(-9) = NaN
                                               double expected2 = Math.sqrt(5);
                                               double actual2 = MathUtils.distance(p3, p4);
                                               
                                               assertEquals("Should handle negative differences correctly",
                                                          expected2, actual2, 0.0001);
                                           }

 @Test
                                       public void testDistanceWithNonZeroNonOneDifferences() {
                                           // Setup test data where differences are neither 0 nor 1
                                           double[] p1 = {1.0, 2.0, 3.0};
                                           double[] p2 = {2.0, 4.0, 6.0}; // Differences will be 1, 2, 3
                                           
                                           // Calculate expected result manually
                                           // Original would calculate: (1² + 2² + 3²) = (1 + 4 + 9) = 14 → sqrt(14) ≈ 3.7416573867739413
                                           // Mutant would calculate: (1³ + 2³ + 3³) = (1 + 8 + 27) = 36 → sqrt(36) = 6.0
                                           
                                           double expected = Math.sqrt(1*1 + 2*2 + 3*3); // sqrt(14)
                                           double actual = MathUtils.distance(p1, p2);
                                           
                                           // Assert with delta for floating point precision
                                           assertEquals("Distance calculation should use squared differences", 
                                                       expected, actual, 1e-10);
                                           
                                           // Additional assertion to explicitly catch the mutant
                                           assertNotEquals("Mutant would return sqrt(36) = 6.0", 
                                                          6.0, actual, 1e-10);
                                       }

 @Test
                                          public void testDistanceWithMultipleDimensions() {
                                              // Test with 3D points where differences are different in each dimension
                                              double[] p1 = {1.0, 2.0, 3.0};
                                              double[] p2 = {4.0, 5.0, 6.0};
                                              
                                              // Calculate expected distance manually:
                                              // diff1 = 3.0 (4-1), diff2 = 3.0 (5-2), diff3 = 3.0 (6-3)
                                              // sum of squares = 9 + 9 + 9 = 27
                                              // sqrt(27) = 5.196152422706632
                                              double expected = 5.196152422706632;
                                              double actual = MathUtils.distance(p1, p2);
                                              
                                              assertEquals("Distance calculation incorrect for multi-dimensional points", 
                                                           expected, actual, 1e-10);
                                          }

 @Test
                                          public void testDistanceWithVaryingDifferences() {
                                              // Test with points where each dimension has different differences
                                              double[] p1 = {1.0, 5.0, 10.0};
                                              double[] p2 = {2.0, 3.0, 14.0};
                                              
                                              // Calculate expected distance manually:
                                              // diff1 = 1.0, diff2 = 2.0, diff3 = 4.0
                                              // sum of squares = 1 + 4 + 16 = 21
                                              // sqrt(21) = 4.58257569495584
                                              double expected = 4.58257569495584;
                                              double actual = MathUtils.distance(p1, p2);
                                              
                                              assertEquals("Distance calculation incorrect when dimensions have different differences",
                                                           expected, actual, 1e-10);
                                          }

 @Test
                                          public void testDistanceWithMultipleDimensions1() {
                                              // Test with 3-dimensional points
                                              double[] p1 = {1.0, 2.0, 3.0};
                                              double[] p2 = {4.0, 5.0, 6.0};
                                              
                                              // Calculate expected distance manually:
                                              // diff1 = 1-4 = -3 → squared = 9
                                              // diff2 = 2-5 = -3 → squared = 9
                                              // diff3 = 3-6 = -3 → squared = 9
                                              // sum = 9+9+9 = 27
                                              // sqrt(27) ≈ 5.196152422706632
                                              double expected = 5.196152422706632;
                                              double actual = MathUtils.distance(p1, p2);
                                              
                                              // Use delta for floating point comparison
                                              assertEquals("Distance calculation incorrect for multi-dimensional points", 
                                                          expected, actual, 1e-10);
                                              
                                              // Additional verification with different values
                                              double[] p3 = {0.0, 0.0, 0.0, 0.0}; // 4D origin
                                              double[] p4 = {1.0, 1.0, 1.0, 1.0}; // 4D point
                                              // Expected: sqrt(1+1+1+1) = 2.0
                                              assertEquals(2.0, MathUtils.distance(p3, p4), 1e-10);
                                          }

 @Test
                                         public void testDistanceDetectsSqrtToAbsMutant() {
                                             // Test case that will fail if sqrt is replaced with abs
                                             double[] p1 = {0.0, 0.0};
                                             double[] p2 = {3.0, 4.0};
                                             
                                             // Expected Euclidean distance: sqrt(3² + 4²) = 5
                                             double expected = 5.0;
                                             
                                             // If mutant is present (using abs instead of sqrt), 
                                             // result would be 3² + 4² = 25
                                             double actual = MathUtils.distance(p1, p2);
                                             
                                             // This assertion will fail if mutant is present
                                             assertEquals("Distance calculation should use square root", 
                                                         expected, actual, 0.0001);
                                             
                                             // Additional test case with different values
                                             double[] p3 = {1.0, 1.0};
                                             double[] p4 = {4.0, 5.0};
                                             expected = 5.0; // sqrt(3² + 4²)
                                             actual = MathUtils.distance(p3, p4);
                                             assertEquals("Distance calculation should use square root", 
                                                         expected, actual, 0.0001);
                                         }

 @Test
                                         public void testDistanceWithZeroDistance() {
                                             // This test case won't detect the mutant since sqrt(0) = abs(0)
                                             // But included for completeness
                                             double[] p1 = {2.5, 3.5};
                                             double[] p2 = {2.5, 3.5};
                                             double expected = 0.0;
                                             double actual = MathUtils.distance(p1, p2);
                                             assertEquals(expected, actual, 0.0001);
                                         }

 @Test
                                         public void testDistanceShouldReturnSquareRootOfSumNotAbsoluteValue() {
                                             // Test case that will fail if mutation (returning abs instead of sqrt) is present
                                             double[] p1 = {3.0, 4.0};  // 3² + 4² = 25
                                             double[] p2 = {0.0, 0.0};  // sqrt(25) = 5
                                             
                                             // Calculate expected values
                                             double sumOfSquares = 25.0;
                                             double expectedDistance = Math.sqrt(sumOfSquares);
                                             double mutatedDistance = Math.abs(sumOfSquares); // This is what mutant would return
                                             
                                             // Actual call
                                             double actualDistance = MathUtils.distance(p1, p2);
                                             
                                             // Verify it's the square root, not the absolute value
                                             assertEquals("Distance should be square root of sum of squares", 
                                                         expectedDistance, actualDistance, 0.0001);
                                             
                                             // Explicit check that it's not returning the absolute value
                                             assertNotEquals("Distance should not be equal to absolute value of sum", 
                                                            mutatedDistance, actualDistance, 0.0001);
                                         }

 @Test
                                         public void testDistanceWithNegativeCoordinates() {
                                             // Another test case with negative coordinates
                                             double[] p1 = {-1.0, -1.0};  // (-1)² + (-1)² = 2
                                             double[] p2 = {0.0, 0.0};    // sqrt(2) ≈ 1.4142
                                             
                                             double expected = Math.sqrt(2);
                                             double actual = MathUtils.distance(p1, p2);
                                             
                                             assertEquals(expected, actual, 0.0001);
                                             assertNotEquals(Math.abs(2.0), actual, 0.0001);
                                         }

 @Test
                                         public void testDistanceWithZeroDistance1() {
                                             // Edge case where distance should be zero
                                             double[] p1 = {5.0, 5.0};
                                             double[] p2 = {5.0, 5.0};  // 0 + 0 = 0
                                             
                                             // Both sqrt(0) and abs(0) are 0, so we need another test
                                             assertEquals(0.0, MathUtils.distance(p1, p2), 0.0001);
                                         }

 @Test
                                        public void testDistanceShouldReturnCorrectEuclideanDistance() {
                                            // Test case 1: Simple 1D case
                                            double[] p1 = {0.0};
                                            double[] p2 = {3.0};
                                            double expected = 3.0; // sqrt((3-0)^2) = 3
                                            double actual = MathUtils.distance(p1, p2);
                                            assertEquals("Distance between [0] and [3] should be 3", expected, actual, 0.0001);
                                            
                                            // Test case 2: 2D case with known distance
                                            double[] p3 = {0.0, 0.0};
                                            double[] p4 = {3.0, 4.0};
                                            expected = 5.0; // sqrt(3^2 + 4^2) = 5
                                            actual = MathUtils.distance(p3, p4);
                                            assertEquals("Distance between [0,0] and [3,4] should be 5", expected, actual, 0.0001);
                                            
                                            // Test case 3: 3D case
                                            double[] p5 = {1.0, 2.0, 3.0};
                                            double[] p6 = {4.0, 5.0, 6.0};
                                            expected = Math.sqrt(27); // sqrt((3^2)*3) = sqrt(27)
                                            actual = MathUtils.distance(p5, p6);
                                            assertEquals("Distance between [1,2,3] and [4,5,6] should be sqrt(27)", 
                                                        expected, actual, 0.0001);
                                            
                                            // Test case 4: Zero distance case
                                            double[] p7 = {1.5, 2.5, 3.5};
                                            double[] p8 = {1.5, 2.5, 3.5};
                                            expected = 0.0;
                                            actual = MathUtils.distance(p7, p8);
                                            assertEquals("Distance between identical points should be 0", 
                                                        expected, actual, 0.0001);
                                        }

 @Test
                                        public void testDistance1() {
                                            // Test case 1: Simple 1D case
                                            double[] p1 = {0.0};
                                            double[] p2 = {3.0};
                                            double expected = 3.0; // sqrt((3-0)^2) = 3
                                            double actual = MathUtils.distance(p1, p2);
                                            assertEquals("Distance calculation incorrect", expected, actual, 1e-10);
                                            
                                            // Test case 2: 2D case
                                            double[] p3 = {0.0, 0.0};
                                            double[] p4 = {3.0, 4.0};
                                            expected = 5.0; // sqrt(3^2 + 4^2) = 5
                                            actual = MathUtils.distance(p3, p4);
                                            assertEquals("Distance calculation incorrect", expected, actual, 1e-10);
                                            
                                            // Test case 3: Zero distance case
                                            double[] p5 = {1.5, 2.5, 3.5};
                                            double[] p6 = {1.5, 2.5, 3.5};
                                            expected = 0.0; // sqrt(0 + 0 + 0) = 0
                                            actual = MathUtils.distance(p5, p6);
                                            assertEquals("Distance should be zero for identical points", expected, actual, 1e-10);
                                        }

 @Test
                                       public void testDistanceWithZeroLengthVectors3() {
                                           // Test with identical points (should return 0)
                                           double[] p1 = {0.0, 0.0, 0.0};
                                           double[] p2 = {0.0, 0.0, 0.0};
                                           double expected = 0.0;
                                           double actual = MathUtils.distance(p1, p2);
                                           assertEquals("Distance between identical points should be 0", 
                                                        expected, actual, 0.0001);
                                       }

 @Test
                                       public void testDistanceWithNonZeroVectors() {
                                           // Test with different points to verify basic calculation
                                           double[] p1 = {1.0, 2.0, 3.0};
                                           double[] p2 = {4.0, 5.0, 6.0};
                                           // Expected distance = sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                                           double expected = Math.sqrt(27);
                                           double actual = MathUtils.distance(p1, p2);
                                           assertEquals("Distance calculation is incorrect",
                                                        expected, actual, 0.0001);
                                       }

 @Test
                                       public void testDistanceWithZeroLengthVectors4() {
                                           // Test with zero-length vectors (should return 0)
                                           double[] zeroVector = new double[0];
                                           double result = MathUtils.distance(zeroVector, zeroVector);
                                           assertEquals(0.0, result, 0.0001);
                                       }

 @Test
                                       public void testDistanceWithIdenticalVectors() {
                                           // Test with identical vectors (should return 0)
                                           double[] vector1 = {1.0, 2.0, 3.0};
                                           double[] vector2 = {1.0, 2.0, 3.0};
                                           double result = MathUtils.distance(vector1, vector2);
                                           assertEquals(0.0, result, 0.0001);
                                       }

 @Test
                                       public void testDistanceWithKnownDifference() {
                                           // Test with known difference (3-4-5 triangle)
                                           double[] vector1 = {0.0, 0.0, 0.0};
                                           double[] vector2 = {3.0, 4.0, 0.0};
                                           double result = MathUtils.distance(vector1, vector2);
                                           assertEquals(5.0, result, 0.0001); // sqrt(3² + 4²) = 5
                                       }

 @Test
                                       public void testDistanceWithSingleDimension() {
                                           // Test with single dimension difference
                                           double[] vector1 = {5.0};
                                           double[] vector2 = {2.0};
                                           double result = MathUtils.distance(vector1, vector2);
                                           assertEquals(3.0, result, 0.0001); // sqrt(3²) = 3
                                       }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                      public void testDistanceWithMutatedLoopCondition() {
                                          // Arrange
                                          double[] p1 = {1.0, 2.0, 3.0};  // 3-element array
                                          double[] p2 = {4.0, 5.0, 6.0};  // 3-element array
                                          
                                          // Act - this should throw ArrayIndexOutOfBoundsException with the mutated version
                                          MathUtils.distance(p1, p2);
                                          
                                          // Assert - handled by the expected exception in the @Test annotation
                                      }

 @Test
                                      public void testDistanceWithOriginalLoopCondition() {
                                          // Arrange
                                          double[] p1 = {1.0, 2.0, 3.0};  // 3-element array
                                          double[] p2 = {4.0, 5.0, 6.0};  // 3-element array
                                          double expected = Math.sqrt(9 + 9 + 9);  // sqrt(27)
                                          
                                          // Act
                                          double result = MathUtils.distance(p1, p2);
                                          
                                          // Assert
                                          assertEquals(expected, result, 0.0001);
                                      }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                      public void testDistanceWithDifferentLengthArrays() {
                                          // Arrange
                                          double[] p1 = {1.0};             // 1-element array
                                          double[] p2 = {4.0, 5.0, 6.0};   // 3-element array
                                          
                                          // Act - should throw with mutated version
                                          MathUtils.distance(p1, p2);
                                      }

 @Test
                                      public void testDistanceWithNonEmptyArrays() {
                                          // Arrange
                                          double[] p1 = {1.0, 2.0, 3.0};
                                          double[] p2 = {4.0, 5.0, 6.0};
                                          
                                          // Act & Assert
                                          try {
                                              double result = MathUtils.distance(p1, p2);
                                              // If we get here, the test passes (original behavior)
                                              double expected = Math.sqrt(9 + 9 + 9); // (4-1)² + (5-2)² + (6-3)²
                                              assertEquals(expected, result, 0.0001);
                                          } catch (ArrayIndexOutOfBoundsException e) {
                                              // If we get here, the mutant was detected
                                              fail("ArrayIndexOutOfBoundsException indicates the mutant was detected");
                                          }
                                      }

 @Test
                                     public void testDistanceShouldIncludeFirstElement1() {
                                         // Test case that will fail if first element is skipped
                                         double[] p1 = {3.0, 0.0, 0.0};  // First element contributes 9 to sum
                                         double[] p2 = {0.0, 0.0, 0.0};
                                         
                                         // Expected distance: sqrt((3-0)² + (0-0)² + (0-0)²) = sqrt(9) = 3.0
                                         double expected = 3.0;
                                         double actual = MathUtils.distance(p1, p2);
                                         
                                         assertEquals("Distance calculation should include first element", 
                                                     expected, actual, 0.0001);
                                     }

 @Test
                                     public void testDistanceWithSingleElementArray() {
                                         // Edge case: array with only one element
                                         double[] p1 = {5.0};
                                         double[] p2 = {2.0};
                                         
                                         // Expected distance: sqrt((5-2)²) = 3.0
                                         double expected = 3.0;
                                         double actual = MathUtils.distance(p1, p2);
                                         
                                         assertEquals("Distance calculation should work for single-element arrays",
                                                     expected, actual, 0.0001);
                                     }

 @Test
                                     public void testDistanceWithDifferentFirstElements() {
                                         // Case where first elements are different but others are same
                                         double[] p1 = {4.0, 1.0, 1.0};
                                         double[] p2 = {1.0, 1.0, 1.0};
                                         
                                         // Expected distance: sqrt((4-1)² + (1-1)² + (1-1)²) = sqrt(9) = 3.0
                                         double expected = 3.0;
                                         double actual = MathUtils.distance(p1, p2);
                                         
                                         assertEquals("Distance should be calculated correctly when first elements differ",
                                                     expected, actual, 0.0001);
                                     }

 @Test
                                     public void testDistanceShouldIncludeFirstElement2() {
                                         // Create test cases where first elements differ
                                         double[] p1 = {1.0, 0.0, 0.0};  // First element is 1.0
                                         double[] p2 = {0.0, 0.0, 0.0};   // First element is 0.0
                                         
                                         // Expected distance: sqrt((1-0)² + (0-0)² + (0-0)²) = 1.0
                                         double expected = 1.0;
                                         double actual = MathUtils.distance(p1, p2);
                                         
                                         // This will fail with the mutant since it skips first element
                                         // Mutant would calculate sqrt(0 + 0) = 0.0
                                         assertEquals("Distance calculation should include first element", 
                                                     expected, actual, 0.0001);
                                         
                                         // Additional test case with non-zero first elements
                                         double[] p3 = {2.5, 1.0, 3.0};
                                         double[] p4 = {1.5, 1.0, 3.0};
                                         expected = Math.sqrt(1.0); // sqrt((2.5-1.5)²) = 1.0
                                         actual = MathUtils.distance(p3, p4);
                                         assertEquals("Distance calculation should include first element", 
                                                     expected, actual, 0.0001);
                                     }

 @Test
                                    public void testDistanceShouldDetectSubtractionMutant() {
                                        // Test case that will fail with the mutated version
                                        double[] p1 = {1.0, 2.0, 3.0};
                                        double[] p2 = {4.0, 5.0, 6.0};
                                        
                                        // Expected distance calculation:
                                        // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                                        double expected = Math.sqrt(27);
                                        
                                        // Mutated version would calculate:
                                        // sqrt((1+4)² + (2+5)² + (3+6)²) = sqrt(25 + 49 + 81) = sqrt(155) ≈ 12.4499
                                        // This is significantly different from expected
                                        
                                        double actual = MathUtils.distance(p1, p2);
                                        
                                        // Using delta for floating point comparison
                                        assertEquals("Distance calculation is incorrect", expected, actual, 0.000001);
                                    }

 @Test
                                    public void testDistanceWithOppositeVectors1() {
                                        // Another test case where subtraction and addition differ greatly
                                        double[] p1 = {1.0, -1.0};
                                        double[] p2 = {-1.0, 1.0};
                                        
                                        // Expected: sqrt((1 - -1)² + (-1 - 1)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.828427
                                        double expected = Math.sqrt(8);
                                        
                                        // Mutated would calculate: sqrt((1 + -1)² + (-1 + 1)²) = sqrt(0 + 0) = 0
                                        // Completely wrong result
                                        
                                        double actual = MathUtils.distance(p1, p2);
                                        assertEquals("Distance with opposite vectors incorrect", expected, actual, 0.000001);
                                    }

 @Test
                                    public void testDistanceWithZeroVectors2() {
                                        // Test with zero vectors where mutation would still produce zero
                                        double[] p1 = {0.0, 0.0};
                                        double[] p2 = {0.0, 0.0};
                                        
                                        // Both original and mutated would return 0 here
                                        // This test ensures basic functionality works
                                        assertEquals(0.0, MathUtils.distance(p1, p2), 0.0);
                                    }

 @Test
                                    public void testDistanceShouldDetectSubtractionMutant1() {
                                        // Test case 1: Simple positive coordinates where addition and subtraction differ
                                        double[] p1 = {1.0, 2.0};
                                        double[] p2 = {3.0, 4.0};
                                        double expected = Math.sqrt((1.0-3.0)*(1.0-3.0) + (2.0-4.0)*(2.0-4.0));
                                        double actual = MathUtils.distance(p1, p2);
                                        assertEquals("Distance calculation incorrect", expected, actual, 0.0001);
                                        
                                        // Test case 2: Mixed positive and negative coordinates
                                        double[] p3 = {-1.0, 2.0};
                                        double[] p4 = {3.0, -4.0};
                                        expected = Math.sqrt((-1.0-3.0)*(-1.0-3.0) + (2.0-(-4.0))*(2.0-(-4.0)));
                                        actual = MathUtils.distance(p3, p4);
                                        assertEquals("Distance calculation with negative values incorrect", expected, actual, 0.0001);
                                        
                                        // Test case 3: Zero values
                                        double[] p5 = {0.0, 0.0};
                                        double[] p6 = {0.0, 0.0};
                                        expected = 0.0;
                                        actual = MathUtils.distance(p5, p6);
                                        assertEquals("Zero distance case incorrect", expected, actual, 0.0001);
                                        
                                        // Test case 4: Single dimension case
                                        double[] p7 = {5.0};
                                        double[] p8 = {2.0};
                                        expected = 3.0; // simple subtraction case
                                        actual = MathUtils.distance(p7, p8);
                                        assertEquals("Single dimension case incorrect", expected, actual, 0.0001);
                                    }

 @Test
                               public void testDistance_ShouldDetectSubtractionOrderMutant() {
                                   // Arrange
                                   double[] p1 = {1.5, 2.5, 3.5};
                                   double[] p2 = {4.5, 5.5, 6.5};
                                   
                                   // Expected calculation:
                                   // Original: sqrt((1.5-4.5)² + (2.5-5.5)² + (3.5-6.5)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152422706632
                                   // Mutant:   sqrt((4.5-1.5)² + (5.5-2.5)² + (6.5-3.5)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152422706632
                                   // While the final result is the same, we can verify the intermediate calculations
                                   
                                   // Act
                                   double result = MathUtils.distance(p1, p2);
                                   
                                   // Assert
                                   // Verify the exact expected result to ensure the computation path was correct
                                   assertEquals(5.196152422706632, result, 1e-10);
                                   
                                   // Additional test with asymmetric values to ensure the subtraction order matters
                                   double[] p3 = {1.1, 2.2};
                                   double[] p4 = {3.3, 4.4};
                                   double result2 = MathUtils.distance(p3, p4);
                                   assertEquals(Math.sqrt((1.1-3.3)*(1.1-3.3) + (2.2-4.4)*(2.2-4.4)), result2, 1e-10);
                                   
                                   // Edge case with very small differences
                                   double[] p5 = {Double.MIN_VALUE, Double.MAX_VALUE};
                                   double[] p6 = {Double.MIN_VALUE * 2, Double.MAX_VALUE / 2};
                                   double result3 = MathUtils.distance(p5, p6);
                                   assertEquals(Math.sqrt(Math.pow(Double.MIN_VALUE - Double.MIN_VALUE*2, 2) + 
                                                         Math.pow(Double.MAX_VALUE - Double.MAX_VALUE/2, 2)), 
                                               result3, 1e-10);
                               }

 @Test
                               public void testDistanceWithDifferentOrderShouldDetectMutant() {
                                   // Test with normal values where order matters for floating point precision
                                   double[] p1 = {1.0e300, 1.0};
                                   double[] p2 = {1.0, 1.0e300};
                                   
                                   // Original should be: sqrt((1.0e300-1.0)² + (1.0-1.0e300)²)
                                   // Mutated would be: sqrt((1.0-1.0e300)² + (1.0e300-1.0)²)
                                   // While mathematically equal, floating point arithmetic might differ
                                   double expected = Math.sqrt(Math.pow(1.0e300 - 1.0, 2) + Math.pow(1.0 - 1.0e300, 2));
                                   double actual = MathUtils.distance(p1, p2);
                                   
                                   // Test exact equality since we're testing the exact computation
                                   assertEquals("Distance calculation should be exact", expected, actual, 0.0);
                                   
                                   // Test with special values where order matters
                                   double[] p3 = {Double.NaN, 1.0};
                                   double[] p4 = {1.0, Double.NaN};
                                   double nanResult = MathUtils.distance(p3, p4);
                                   assertTrue("Should return NaN when any element is NaN", Double.isNaN(nanResult));
                                   
                                   // Test with very small differences
                                   double[] p5 = {Double.MIN_VALUE, 0.0};
                                   double[] p6 = {0.0, Double.MIN_VALUE};
                                   double smallDiff = MathUtils.distance(p5, p6);
                                   assertEquals("Should handle very small differences correctly", 
                                                Math.sqrt(2 * Math.pow(Double.MIN_VALUE, 2)), 
                                                smallDiff, 
                                                Double.MIN_VALUE);
                               }

 @Test
                                  public void testDistanceShouldCalculateEuclideanDistance4() {
                                      // Test case that will reveal the mutation
                                      double[] p1 = {1.0, 2.0, 3.0};  // Point 1
                                      double[] p2 = {4.0, 5.0, 6.0};  // Point 2
                                      
                                      // Calculate expected value manually
                                      // Differences: (4-1)=3, (5-2)=3, (6-3)=3
                                      // Squares: 3²=9, 3²=9, 3²=9
                                      // Sum: 9+9+9=27
                                      // Square root: √27 ≈ 5.196152422706632
                                      double expected = 5.196152422706632;
                                      
                                      // Calculate actual value
                                      double actual = MathUtils.distance(p1, p2);
                                      
                                      // Assert with delta for floating point precision
                                      assertEquals("Distance calculation incorrect - mutation not detected", 
                                                  expected, actual, 1e-10);
                                      
                                      // Additional assertion to verify it's not just summing differences
                                      // If it were summing differences (mutated version), result would be 3+3+3=9
                                      assertNotEquals("Mutation not detected - appears to be summing instead of squaring",
                                                      9.0, actual, 1e-10);
                                  }

 @Test
                                  public void testDistanceWithZeroDifference() {
                                      // Test case where mutation wouldn't affect result
                                      double[] p1 = {1.0, 2.0, 3.0};
                                      double[] p2 = {1.0, 2.0, 3.0};
                                      
                                      assertEquals(0.0, MathUtils.distance(p1, p2), 1e-10);
                                  }

 @Test
                                  public void testDistanceWithSingleDimension1() {
                                      // Simple one-dimensional case
                                      double[] p1 = {2.0};
                                      double[] p2 = {5.0};
                                      
                                      // Expected: √((5-2)²) = 3
                                      assertEquals(3.0, MathUtils.distance(p1, p2), 1e-10);
                                  }

 @Test
                                  public void testDistanceShouldCalculateEuclideanDistance5() {
                                      // Test case that will catch the mutant
                                      double[] p1 = {3.0, 4.0};  // Point (3,4)
                                      double[] p2 = {0.0, 0.0};  // Origin (0,0)
                                      
                                      // Original should calculate sqrt(3² + 4²) = 5
                                      // Mutant would calculate sqrt(3 + 4) = sqrt(7) ≈ 2.64575
                                      double expectedDistance = 5.0;
                                      double actualDistance = MathUtils.distance(p1, p2);
                                      
                                      assertEquals("Distance calculation is incorrect", 
                                                  expectedDistance, actualDistance, 0.0001);
                                      
                                      // Additional test case with different values
                                      double[] p3 = {1.0, 1.0, 1.0};  // 3D point
                                      double[] p4 = {0.0, 0.0, 0.0};  // Origin
                                      
                                      // Original: sqrt(1² + 1² + 1²) = sqrt(3) ≈ 1.73205
                                      // Mutant: sqrt(1 + 1 + 1) = sqrt(3) - same result by coincidence
                                      // So we need another test where squared sum ≠ direct sum
                                      double[] p5 = {2.0, 3.0};
                                      double[] p6 = {1.0, 1.0};
                                      
                                      // Original: sqrt((2-1)² + (3-1)²) = sqrt(1 + 4) = sqrt(5) ≈ 2.23607
                                      // Mutant: sqrt(1 + 2) = sqrt(3) ≈ 1.73205
                                      assertEquals("Distance calculation is incorrect",
                                                  Math.sqrt(5), MathUtils.distance(p5, p6), 0.0001);
                                  }

 @Test
                                 public void testDistanceShouldReturnPositiveValue() {
                                     // Test case with multiple dimensions
                                     double[] p1 = {1.0, 2.0, 3.0};
                                     double[] p2 = {4.0, 5.0, 6.0};
                                     
                                     double result = MathUtils.distance(p1, p2);
                                     
                                     // The result should be a valid positive number
                                     assertTrue("Distance should be positive", result >= 0);
                                     assertFalse("Distance should not be NaN", Double.isNaN(result));
                                     
                                     // Verify exact calculation for one test case
                                     double expected = Math.sqrt((1.0-4.0)*(1.0-4.0) + 
                                                                (2.0-5.0)*(2.0-5.0) + 
                                                                (3.0-6.0)*(3.0-6.0));
                                     assertEquals(expected, result, 0.0001);
                                 }

 @Test
                                 public void testDistanceWithSamePointsShouldReturnZero() {
                                     // Test case with identical points
                                     double[] p1 = {1.0, 2.0, 3.0};
                                     double[] p2 = {1.0, 2.0, 3.0};
                                     
                                     double result = MathUtils.distance(p1, p2);
                                     
                                     // Should be exactly 0 for identical points
                                     assertEquals(0.0, result, 0.0);
                                 }

 @Test
                                 public void testDistanceWithSingleDimension2() {
                                     // Test case with single dimension
                                     double[] p1 = {5.0};
                                     double[] p2 = {2.0};
                                     
                                     double result = MathUtils.distance(p1, p2);
                                     
                                     // Should be the absolute difference for 1D case
                                     assertEquals(3.0, result, 0.0001);
                                 }

 @Test
                                 public void testDistanceDetectsSumSubtractionMutant() {
                                     // Arrange
                                     double[] p1 = {1.0, 2.0, 3.0};
                                     double[] p2 = {4.0, 5.0, 6.0};
                                     
                                     // Expected calculation:
                                     // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                                     // sqrt(27) ≈ 5.196152422706632
                                     double expected = 5.196152422706632;
                                     
                                     // Act
                                     double actual = MathUtils.distance(p1, p2);
                                     
                                     // Assert
                                     // Check it's a valid positive number (would be NaN for mutant)
                                     assertFalse(Double.isNaN(actual));
                                     assertTrue(actual > 0);
                                     
                                     // Check exact calculation with delta for floating point precision
                                     assertEquals(expected, actual, 1e-10);
                                     
                                     // Additional check with different inputs
                                     double[] p3 = {0.0, 0.0};
                                     double[] p4 = {3.0, 4.0};
                                     assertEquals(5.0, MathUtils.distance(p3, p4), 1e-10);
                                 }

 @Test
                                public void testDistanceShouldReturnSquareRootOfSumOfSquares2() {
                                    // Test case that clearly shows the difference between sum and sqrt(sum)
                                    double[] p1 = {0.0, 0.0};
                                    double[] p2 = {3.0, 4.0};
                                    
                                    // Original should return 5.0 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5)
                                    // Mutant would return 25.0 (3² + 4² = 9+16 = 25)
                                    double expected = 5.0;
                                    double actual = MathUtils.distance(p1, p2);
                                    
                                    assertEquals("Distance should be the square root of sum of squares", 
                                                 expected, actual, 0.0001);
                                    
                                    // Additional test case with different values
                                    double[] p3 = {1.0, 1.0};
                                    double[] p4 = {4.0, 5.0};
                                    expected = 5.0; // sqrt((4-1)² + (5-1)²) = sqrt(9+16) = 5
                                    actual = MathUtils.distance(p3, p4);
                                    
                                    assertEquals("Distance should be the square root of sum of squares", 
                                                 expected, actual, 0.0001);
                                }

 @Test
                                public void testDistanceDetectsSqrtMutation() {
                                    // Test case where sum of squares is a perfect square
                                    double[] p1 = {0.0, 3.0};  // 0² + 3² = 9
                                    double[] p2 = {0.0, 0.0};
                                    double expected = 3.0;      // sqrt(9) = 3
                                    double actual = MathUtils.distance(p1, p2);
                                    assertEquals("Should return square root of sum of squares", expected, actual, 0.0001);
                                    
                                    // Test case where sum of squares is not a perfect square
                                    double[] p3 = {1.0, 1.0};  // 1² + 1² = 2
                                    double[] p4 = {0.0, 0.0};
                                    expected = Math.sqrt(2);    // ~1.4142
                                    actual = MathUtils.distance(p3, p4);
                                    assertEquals("Should return exact square root for non-perfect squares", 
                                                expected, actual, 0.0001);
                                    
                                    // Test case with identical points (distance should be 0)
                                    double[] p5 = {2.5, 3.7};
                                    double[] p6 = {2.5, 3.7};
                                    expected = 0.0;
                                    actual = MathUtils.distance(p5, p6);
                                    assertEquals("Identical points should have 0 distance", expected, actual, 0.0001);
                                }

 @Test
                               public void testDistanceExactValue() {
                                   // Test case with known exact distance
                                   double[] p1 = {0.0, 0.0};
                                   double[] p2 = {3.0, 4.0}; // 3-4-5 triangle
                                   
                                   // Expected distance is exactly 5.0 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5)
                                   double expected = 5.0;
                                   double actual = MathUtils.distance(p1, p2);
                                   
                                   // This will fail if the mutant is present (would get 6.0 instead of 5.0)
                                   assertEquals("Distance calculation incorrect", expected, actual, 0.000001);
                                   
                                   // Additional test case with zero distance
                                   double[] p3 = {1.5, 2.5};
                                   double expectedZero = 0.0;
                                   double actualZero = MathUtils.distance(p3, p3);
                                   
                                   // This will fail if the mutant is present (would get 1.0 instead of 0.0)
                                   assertEquals("Zero distance case incorrect", expectedZero, actualZero, 0.000001);
                               }

 @Test
                               public void testDistanceExactValue1() {
                                   // Simple case where distance can be calculated manually
                                   double[] p1 = {0.0, 0.0};
                                   double[] p2 = {3.0, 4.0};
                                   
                                   // Expected distance is 5.0 (3-4-5 triangle)
                                   double expected = 5.0;
                                   double actual = MathUtils.distance(p1, p2);
                                   
                                   // Use assertEquals with delta 0 to catch exact value differences
                                   assertEquals("Distance calculation should be exact", expected, actual, 0.0);
                                   
                                   // Additional simple case with zero distance
                                   double[] p3 = {1.5, 2.5};
                                   assertEquals("Zero distance case should work", 
                                               0.0, 
                                               MathUtils.distance(p3, p3), 
                                               0.0);
                               }

 @Test
                              public void testDistanceWithZeroVectors3() {
                                  // Test with identical points (distance should be exactly 0)
                                  double[] p1 = {0.0, 0.0, 0.0};
                                  double[] p2 = {0.0, 0.0, 0.0};
                                  
                                  double result = MathUtils.distance(p1, p2);
                                  assertEquals(0.0, result, 0.0);  // Using delta=0.0 to catch any difference
                                  
                                  // Test with very small differences
                                  double[] p3 = {0.0000001, 0.0000001};
                                  double[] p4 = {0.0, 0.0};
                                  double expected = Math.sqrt(2 * 0.0000001 * 0.0000001);
                                  double actual = MathUtils.distance(p3, p4);
                                  assertEquals(expected, actual, 1e-10);  // Very tight tolerance
                                  
                                  // Test with known values
                                  double[] p5 = {3.0, 4.0};
                                  double[] p6 = {0.0, 0.0};
                                  assertEquals(5.0, MathUtils.distance(p5, p6), 1e-10);
                              }

 @Test
                              public void testDistanceWithZeroLengthVectors5() {
                                  // Test with identical points (distance should be exactly 0)
                                  double[] p1 = {0.0, 0.0, 0.0};
                                  double[] p2 = {0.0, 0.0, 0.0};
                                  
                                  double result = MathUtils.distance(p1, p2);
                                  assertEquals("Distance between identical points should be 0", 0.0, result, 0.0);
                              }

 @Test
                              public void testDistanceWithSmallVectors() {
                                  // Test with very small distances where the 0.5 offset would be significant
                                  double[] p1 = {0.001, 0.001};
                                  double[] p2 = {0.0, 0.0};
                                  
                                  double expected = Math.sqrt(0.001*0.001 + 0.001*0.001);
                                  double result = MathUtils.distance(p1, p2);
                                  
                                  // The mutant would return Math.sqrt(expected*expected + 0.5)
                                  assertEquals("Distance calculation incorrect with small vectors", 
                                              expected, result, 1e-10);
                              }

 @Test
                              public void testDistanceWithKnownValues1() {
                                  // Test with known values where we can calculate exact expected result
                                  double[] p1 = {3.0, 4.0};
                                  double[] p2 = {0.0, 0.0};
                                  
                                  double expected = 5.0; // sqrt(3² + 4²) = 5
                                  double result = MathUtils.distance(p1, p2);
                                  
                                  // The mutant would return Math.sqrt(25 + 0.5) ≈ 5.0249
                                  assertEquals("Distance calculation incorrect with known values", 
                                              expected, result, 1e-10);
                              }

 @Test
                             public void testDistanceShouldProcessAllElements1() {
                                 // Test case with single element arrays
                                 double[] single1 = {5.0};
                                 double[] single2 = {2.0};
                                 double expectedSingle = 3.0; // sqrt((5-2)^2) = 3
                                 assertEquals(expectedSingle, MathUtils.distance(single1, single2), 0.0001);
                                 
                                 // Test case where last element makes the only difference
                                 double[] p1 = {0.0, 0.0, 0.0, 5.0};
                                 double[] p2 = {0.0, 0.0, 0.0, 2.0};
                                 double expected = 3.0; // sqrt(0+0+0+(5-2)^2) = 3
                                 assertEquals(expected, MathUtils.distance(p1, p2), 0.0001);
                                 
                                 // Test case with multiple elements where all contribute
                                 double[] multi1 = {1.0, 2.0, 3.0, 4.0};
                                 double[] multi2 = {0.0, 1.0, 2.0, 3.0};
                                 // sqrt((1-0)^2 + (2-1)^2 + (3-2)^2 + (4-3)^2) = sqrt(1+1+1+1) = 2
                                 double expectedMulti = 2.0;
                                 assertEquals(expectedMulti, MathUtils.distance(multi1, multi2), 0.0001);
                             }

 @Test
                         public void testDistanceShouldProcessAllDimensions1() {
                             // Test with 1D points - mutant might not be detected here
                             double[] p1_1d = {1.0};
                             double[] p2_1d = {2.0};
                             double expected1d = 1.0; // sqrt((1-2)^2) = 1
                             assertEquals(expected1d, MathUtils.distance(p1_1d, p2_1d), 0.0001);
                             
                             // Test with 2D points - this will detect the mutant
                             double[] p1_2d = {1.0, 2.0};
                             double[] p2_2d = {4.0, 6.0};
                             // Correct distance: sqrt((1-4)^2 + (2-6)^2) = sqrt(9 + 16) = 5
                             // Mutant would calculate: sqrt((1-4)^2) = 3 (ignores last dimension)
                             double expected2d = 5.0;
                             assertEquals(expected2d, MathUtils.distance(p1_2d, p2_2d), 0.0001);
                             
                             // Test with 3D points for additional verification
                             double[] p1_3d = {1.0, 2.0, 3.0};
                             double[] p2_3d = {4.0, 6.0, 8.0};
                             // Correct distance: sqrt((1-4)^2 + (2-6)^2 + (3-8)^2) = sqrt(9 + 16 + 25) = sqrt(50) ≈ 7.071
                             // Mutant would calculate: sqrt((1-4)^2 + (2-6)^2) = 5
                             double expected3d = 7.0710678118654755;
                             assertEquals(expected3d, MathUtils.distance(p1_3d, p2_3d), 0.0001);
                         }

 @Test
                            public void testDistanceWithEmptyArrays2() {
                                double[] empty1 = new double[0];
                                double[] empty2 = new double[0];
                                
                                // Original behavior: should return 0 for empty arrays
                                // Mutant behavior: will throw ArrayIndexOutOfBoundsException
                                double result = MathUtils.distance(empty1, empty2);
                                assertEquals(0.0, result, 0.0001);
                            }

 @Test
                            public void testDistanceWithNormalArrays1() {
                                double[] p1 = {1.0, 2.0, 3.0};
                                double[] p2 = {4.0, 5.0, 6.0};
                                
                                // Expected distance: sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(27) ≈ 5.196152
                                double expected = Math.sqrt(27);
                                double result = MathUtils.distance(p1, p2);
                                assertEquals(expected, result, 0.0001);
                            }

 @Test
                            public void testDistanceWithEmptyArrays3() {
                                double[] empty1 = new double[0];
                                double[] empty2 = new double[0];
                                
                                // Original should return 0 for empty arrays
                                double expected = 0.0;
                                double actual = MathUtils.distance(empty1, empty2);
                                
                                assertEquals("Distance between empty arrays should be 0", 
                                            expected, actual, 0.0001);
                            }

 @Test
                            public void testDistanceWithNormalArrays2() {
                                double[] p1 = {1.0, 2.0, 3.0};
                                double[] p2 = {4.0, 5.0, 6.0};
                                
                                // Expected distance = sqrt((1-4)^2 + (2-5)^2 + (3-6)^2) = sqrt(27) ≈ 5.196152
                                double expected = 5.196152;
                                double actual = MathUtils.distance(p1, p2);
                                
                                assertEquals("Distance calculation is incorrect",
                                            expected, actual, 0.0001);
                            }

 @Test
                           public void testDistanceDetectsSubtractionMutation1() {
                               // Test case where (a-b)² ≠ (a*b)²
                               double[] p1 = {2.0, 3.0};
                               double[] p2 = {1.0, 2.0};
                               
                               // Expected calculation:
                               // sqrt((2-1)² + (3-2)²) = sqrt(1 + 1) = sqrt(2) ≈ 1.4142
                               double expected = Math.sqrt(2);
                               
                               // Mutated calculation would be:
                               // sqrt((2*1)² + (3*2)²) = sqrt(4 + 36) = sqrt(40) ≈ 6.3246
                               // This is significantly different from expected
                               
                               double actual = MathUtils.distance(p1, p2);
                               
                               // Using delta of 0.0001 for floating point comparison
                               assertEquals("Distance calculation should use subtraction, not multiplication", 
                                          expected, actual, 0.0001);
                               
                               // Additional test case with negative numbers
                               double[] p3 = {-1.0, 0.0};
                               double[] p4 = {2.0, 3.0};
                               expected = Math.sqrt(9 + 9); // sqrt(18) ≈ 4.2426
                               actual = MathUtils.distance(p3, p4);
                               assertEquals("Should handle negative coordinates correctly",
                                          expected, actual, 0.0001);
                               
                               // Test with zero values
                               double[] p5 = {0.0, 0.0};
                               double[] p6 = {0.0, 0.0};
                               expected = 0.0;
                               actual = MathUtils.distance(p5, p6);
                               assertEquals("Distance between zero points should be zero",
                                          expected, actual, 0.0001);
                           }

 @Test
                           public void testDistanceShouldCalculateEuclideanDistanceNotMultiplication() {
                               // Arrange
                               double[] p1 = {1.0, 2.0};  // Simple test values where difference ≠ multiplication
                               double[] p2 = {3.0, 4.0};
                               
                               // Expected calculation:
                               // sqrt((1-3)² + (2-4)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.8284271247461903
                               double expectedDistance = Math.sqrt(8.0);
                               
                               // If mutation exists, it would calculate:
                               // sqrt((1*3)² + (2*4)²) = sqrt(9 + 16) = sqrt(25) = 5.0
                               
                               // Act
                               double actualDistance = MathUtils.distance(p1, p2);
                               
                               // Assert
                               assertEquals("Distance should be calculated using differences, not multiplications", 
                                           expectedDistance, actualDistance, 0.000001);
                           }

 @Test
                          public void testDistanceShouldDetectDivisionMutant() {
                              // Test case where subtraction and division produce different results
                              double[] p1 = {3.0, 4.0};  // Point (3,4)
                              double[] p2 = {1.0, 2.0};  // Point (1,2)
                              
                              // Expected Euclidean distance: sqrt((3-1)² + (4-2)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.828
                              double expectedDistance = Math.sqrt(8.0);
                              
                              // Mutated version would calculate: sqrt((3/1)² + (4/2)²) = sqrt(9 + 4) = sqrt(13) ≈ 3.606
                              // These are clearly different values
                              
                              double actualDistance = MathUtils.distance(p1, p2);
                              
                              // Assert with delta for floating point precision
                              assertEquals("Distance calculation should use subtraction, not division", 
                                          expectedDistance, actualDistance, 0.0001);
                          }

 @Test
                          public void testDistanceWithZeroValues() {
                              // Test case with zero values that would cause issues with division
                              double[] p1 = {0.0, 0.0};
                              double[] p2 = {1.0, 1.0};
                              
                              // Expected: sqrt((0-1)² + (0-1)²) = sqrt(1 + 1) = sqrt(2) ≈ 1.414
                              double expectedDistance = Math.sqrt(2.0);
                              
                              // Mutated version would calculate: sqrt((0/1)² + (0/1)²) = sqrt(0 + 0) = 0
                              // This would fail the test
                              
                              double actualDistance = MathUtils.distance(p1, p2);
                              
                              assertEquals("Distance with zero values should use subtraction", 
                                          expectedDistance, actualDistance, 0.0001);
                          }

 @Test
                          public void testDistanceWithNegativeValues() {
                              // Test case with negative values where subtraction and division behave differently
                              double[] p1 = {-3.0, -4.0};
                              double[] p2 = {-1.0, -2.0};
                              
                              // Expected: sqrt((-3 - -1)² + (-4 - -2)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.828
                              double expectedDistance = Math.sqrt(8.0);
                              
                              // Mutated version would calculate: sqrt((-3/-1)² + (-4/-2)²) = sqrt(9 + 4) = sqrt(13) ≈ 3.606
                              // Different from expected
                              
                              double actualDistance = MathUtils.distance(p1, p2);
                              
                              assertEquals("Distance with negative values should use subtraction", 
                                          expectedDistance, actualDistance, 0.0001);
                          }

 @Test
                          public void testDistanceDetectsSubtractionMutant() {
                              // Test case where subtraction and division would give different results
                              double[] p1 = {3.0, 4.0};  // Simple 3-4-5 triangle
                              double[] p2 = {0.0, 0.0};
                              
                              // Original would calculate: sqrt((3-0)² + (4-0)²) = 5
                              // Mutant would calculate: sqrt((3/0)² + (4/0)²) = Infinity (or would throw exception)
                              // But since we're testing the mutant that survived, let's use non-zero p2
                              
                              double[] p3 = {5.0, 5.0};
                              double[] p4 = {2.0, 1.0};
                              
                              // Original: sqrt((5-2)² + (5-1)²) = sqrt(9 + 16) = 5
                              // Mutant: sqrt((5/2)² + (5/1)²) = sqrt(6.25 + 25) ≈ 5.59
                              double expected = 5.0;
                              double result = MathUtils.distance(p3, p4);
                              
                              // Assert with delta to account for floating point precision
                              assertEquals("Distance calculation is incorrect", expected, result, 0.0001);
                              
                              // Additional test case where p2[i] is 1 (where subtraction and division might match)
                              double[] p5 = {4.0, 3.0};
                              double[] p6 = {1.0, 1.0};
                              
                              // Original: sqrt((4-1)² + (3-1)²) = sqrt(9 + 4) ≈ 3.60555
                              // Mutant: sqrt((4/1)² + (3/1)²) = sqrt(16 + 9) = 5
                              expected = 3.605551275463989;
                              result = MathUtils.distance(p5, p6);
                              assertEquals("Distance calculation should use subtraction not division", 
                                         expected, result, 0.0001);
                          }

 @Test
                         public void testDistanceWithNonZeroNonOneDifferences1() {
                             // Arrange
                             double[] p1 = {1.0, 2.0, 3.0};
                             double[] p2 = {2.0, 3.0, 5.0}; // Differences are 1.0, 1.0, 2.0
                             
                             // Calculate expected value manually:
                             // sqrt((1.0)^2 + (1.0)^2 + (2.0)^2) = sqrt(1 + 1 + 4) = sqrt(6) ≈ 2.44948974278
                             double expected = Math.sqrt(6.0);
                             
                             // Act
                             double actual = MathUtils.distance(p1, p2);
                             
                             // Assert
                             assertEquals("Distance calculation is incorrect", expected, actual, 1e-10);
                             
                             // For mutated version:
                             // sum would be (1.0)^3 + (1.0)^3 + (2.0)^3 = 1 + 1 + 8 = 10
                             // sqrt(10) ≈ 3.16227766017 which is different from expected
                             // So this test would fail for the mutant
                         }

 @Test
                         public void testDistanceWithNegativeDifferences() {
                             // Arrange
                             double[] p1 = {1.0, -2.0};
                             double[] p2 = {-1.0, 2.0}; // Differences are -2.0, 4.0
                             
                             // Expected: sqrt((-2)^2 + 4^2) = sqrt(4 + 16) = sqrt(20) ≈ 4.472135955
                             double expected = Math.sqrt(20.0);
                             
                             // Act
                             double actual = MathUtils.distance(p1, p2);
                             
                             // Assert
                             assertEquals("Distance calculation with negative values is incorrect", 
                                         expected, actual, 1e-10);
                             
                             // For mutated version:
                             // sum would be (-2)^3 + 4^3 = -8 + 64 = 56
                             // sqrt(56) ≈ 7.48331477355 which is different from expected
                         }

 @Test
                     public void testDistanceShouldDetectMutatedSumCalculation() {
                         // Test case with simple values that will show difference between squared and cubed sums
                         double[] p1 = {1.0, 2.0, 3.0};
                         double[] p2 = {0.0, 1.0, 2.0};
                         
                         // Calculate expected Euclidean distance manually
                         double expectedSum = 0;
                         for (int i = 0; i < p1.length; i++) {
                             final double dp = p1[i] - p2[i];
                             expectedSum += dp * dp; // Original correct calculation
                         }
                         double expectedDistance = Math.sqrt(expectedSum);
                         
                         // Call the method and get actual result
                         double actualDistance = MathUtils.distance(p1, p2);
                         
                         // Assert that actual matches expected
                         assertEquals("Distance calculation is incorrect due to mutated sum calculation", 
                                     expectedDistance, actualDistance, 0.0001);
                         
                         // Additional test case with negative values
                         double[] p3 = {-1.5, 0.5};
                         double[] p4 = {1.5, -0.5};
                         
                         expectedSum = 0;
                         for (int i = 0; i < p3.length; i++) {
                             final double dp = p3[i] - p4[i];
                             expectedSum += dp * dp;
                         }
                         expectedDistance = Math.sqrt(expectedSum);
                         
                         actualDistance = MathUtils.distance(p3, p4);
                         assertEquals("Distance calculation with negative values is incorrect", 
                                     expectedDistance, actualDistance, 0.0001);
                     }

 @Test
                        public void testDistanceWithMultipleDimensions2() {
                            // Test with 2D points where the mutation would be detectable
                            double[] p1 = {1.0, 2.0, 3.0};  // 3-dimensional point
                            double[] p2 = {4.0, 6.0, 8.0};  // 3-dimensional point
                            
                            // Calculate expected distance manually:
                            // sqrt((4-1)^2 + (6-2)^2 + (8-3)^2) = sqrt(9 + 16 + 25) = sqrt(50) ≈ 7.0710678118654755
                            double expected = Math.sqrt(9 + 16 + 25);
                            double actual = MathUtils.distance(p1, p2);
                            
                            assertEquals("Distance calculation should accumulate all squared differences", 
                                        expected, actual, 1e-10);
                            
                            // Additional test case with different values
                            double[] p3 = {0.0, 0.0, 0.0, 0.0};  // 4-dimensional
                            double[] p4 = {1.0, 1.0, 1.0, 1.0};  // 4-dimensional
                            expected = 2.0;  // sqrt(1+1+1+1) = 2
                            actual = MathUtils.distance(p3, p4);
                            assertEquals("Distance calculation should work for 4 dimensions", 
                                        expected, actual, 1e-10);
                        }

 @Test
                        public void testDistanceWithMultipleDimensions3() {
                            // Test with 3-dimensional points
                            double[] p1 = {1.0, 2.0, 3.0};
                            double[] p2 = {4.0, 5.0, 6.0};
                            
                            // Calculate expected distance manually:
                            // diff1 = 1-4 = -3 → squared = 9
                            // diff2 = 2-5 = -3 → squared = 9
                            // diff3 = 3-6 = -3 → squared = 9
                            // sum = 9+9+9 = 27
                            // sqrt(27) ≈ 5.196152422706632
                            double expected = 5.196152422706632;
                            double actual = MathUtils.distance(p1, p2);
                            
                            // Use delta for floating point comparison
                            assertEquals("Distance calculation incorrect for multi-dimensional points", 
                                        expected, actual, 1e-10);
                            
                            // Additional assertion to specifically catch the sum accumulation mutant
                            // The mutant would return sqrt(9) = 3.0 instead of sqrt(27)
                            assertNotEquals("Mutant detected: sum not being accumulated properly",
                                          3.0, actual, 1e-10);
                        }

 @Test
                        public void testDistanceWithTwoDimensions() {
                            // Another test case with 2 dimensions
                            double[] p1 = {0.0, 0.0};
                            double[] p2 = {3.0, 4.0};
                            
                            // Expected: sqrt(3² + 4²) = 5.0
                            double expected = 5.0;
                            double actual = MathUtils.distance(p1, p2);
                            
                            assertEquals("Distance calculation incorrect for 2D points",
                                        expected, actual, 1e-10);
                            
                            // The mutant would return sqrt(16) = 4.0
                            assertNotEquals("Mutant detected: sum not being accumulated properly",
                                          4.0, actual, 1e-10);
                        }

 @Test
                       public void testDistanceWithNonZeroInput() {
                           // Test with simple 2D points where distance is obvious
                           double[] p1 = {0.0, 0.0};
                           double[] p2 = {3.0, 4.0};
                           
                           // Expected Euclidean distance: sqrt(3² + 4²) = 5
                           double expected = 5.0;
                           double actual = MathUtils.distance(p1, p2);
                           
                           // This will fail if mutation (Math.abs instead of Math.sqrt) is present
                           assertEquals("Distance calculation incorrect", expected, actual, 0.0001);
                           
                           // Additional test with different values
                           double[] p3 = {1.0, 1.0};
                           double[] p4 = {4.0, 5.0};
                           double expected2 = 5.0; // sqrt(3² + 4²)
                           double actual2 = MathUtils.distance(p3, p4);
                           assertEquals("Distance calculation incorrect", expected2, actual2, 0.0001);
                       }

 @Test
                       public void testDistanceWithZeroInput() {
                           // Test with identical points
                           double[] p1 = {2.5, 3.7};
                           double[] p2 = {2.5, 3.7};
                           
                           // Expected distance should be 0
                           double expected = 0.0;
                           double actual = MathUtils.distance(p1, p2);
                           
                           // Both original and mutated version would return 0
                           assertEquals("Distance between identical points should be 0", 
                                       expected, actual, 0.0001);
                       }

 @Test
                       public void testDistanceDetectsSqrtToAbsMutant1() {
                           // Test case that will fail if sqrt is replaced with abs
                           double[] p1 = {0.0, 0.0};
                           double[] p2 = {3.0, 4.0};
                           
                           // Original should return 5.0 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5)
                           // Mutated version would return 25.0 (abs(9+16) = 25)
                           double expectedDistance = 5.0;
                           double actualDistance = MathUtils.distance(p1, p2);
                           
                           assertEquals("Distance calculation should use square root, not absolute value", 
                                       expectedDistance, actualDistance, 0.0001);
                           
                           // Additional test case with different values
                           double[] p3 = {1.0, 1.0};
                           double[] p4 = {4.0, 5.0};
                           
                           // sqrt((4-1)² + (5-1)²) = sqrt(9 + 16) = 5
                           // abs would give 25
                           assertEquals(5.0, MathUtils.distance(p3, p4), 0.0001);
                           
                           // Edge case with zero distance
                           double[] p5 = {2.5, 3.5};
                           double[] p6 = {2.5, 3.5};
                           assertEquals(0.0, MathUtils.distance(p5, p6), 0.0001);
                       }

 @Test
                      public void testDistance2() {
                          // Test case 1: Simple 1D case
                          double[] p1_1d = {3.0};
                          double[] p2_1d = {1.0};
                          double expected1 = 2.0; // sqrt((3-1)^2) = 2
                          assertEquals("1D distance calculation failed", 
                                      expected1, 
                                      MathUtils.distance(p1_1d, p2_1d), 
                                      1e-10);
                          
                          // Test case 2: 2D case with known result
                          double[] p1_2d = {0.0, 0.0};
                          double[] p2_2d = {3.0, 4.0};
                          double expected2 = 5.0; // sqrt(3^2 + 4^2) = 5
                          assertEquals("2D distance calculation failed", 
                                      expected2, 
                                      MathUtils.distance(p1_2d, p2_2d), 
                                      1e-10);
                          
                          // Test case 3: 3D case
                          double[] p1_3d = {1.0, 2.0, 3.0};
                          double[] p2_3d = {4.0, 5.0, 6.0};
                          double expected3 = Math.sqrt(27); // sqrt((3^2)*3) = sqrt(27)
                          assertEquals("3D distance calculation failed", 
                                      expected3, 
                                      MathUtils.distance(p1_3d, p2_3d), 
                                      1e-10);
                          
                          // Test case 4: Zero distance
                          double[] p1_zero = {5.0, 5.0, 5.0};
                          double[] p2_zero = {5.0, 5.0, 5.0};
                          double expected4 = 0.0;
                          assertEquals("Zero distance case failed", 
                                      expected4, 
                                      MathUtils.distance(p1_zero, p2_zero), 
                                      1e-10);
                      }

 @Test
                      public void testDistance3() {
                          // Test case 1: Simple 1D case
                          double[] p1 = {0.0};
                          double[] p2 = {3.0};
                          double expected = 3.0; // sqrt((3-0)^2) = 3
                          double actual = MathUtils.distance(p1, p2);
                          assertEquals("Distance calculation incorrect", expected, actual, 0.0001);
                          
                          // Test case 2: 2D case
                          double[] p3 = {0.0, 0.0};
                          double[] p4 = {3.0, 4.0};
                          expected = 5.0; // sqrt(3^2 + 4^2) = 5
                          actual = MathUtils.distance(p3, p4);
                          assertEquals("Distance calculation incorrect", expected, actual, 0.0001);
                          
                          // Test case 3: Zero distance case
                          double[] p5 = {1.5, 2.5};
                          double[] p6 = {1.5, 2.5};
                          expected = 0.0; // sqrt(0 + 0) = 0
                          actual = MathUtils.distance(p5, p6);
                          assertEquals("Distance calculation incorrect", expected, actual, 0.0001);
                      }

 @Test
                     public void testDistanceWithZeroVectors4() {
                         double[] zeroVector = new double[]{0.0, 0.0, 0.0};
                         double result = MathUtils.distance(zeroVector, zeroVector);
                         assertEquals(0.0, result, 0.0);  // Exact comparison for identical points
                     }

 @Test
                     public void testDistanceWithSimpleVectors1() {
                         double[] p1 = new double[]{1.0, 0.0};
                         double[] p2 = new double[]{0.0, 1.0};
                         double result = MathUtils.distance(p1, p2);
                         // Expected distance between (1,0) and (0,1) is √(1² + 1²) = √2
                         assertEquals(Math.sqrt(2), result, 0.0);  // Exact comparison
                     }

 @Test
                     public void testDistanceWithOneDimensionalVectors() {
                         double[] p1 = new double[]{3.0};
                         double[] p2 = new double[]{1.0};
                         double result = MathUtils.distance(p1, p2);
                         // Expected distance is √(2²) = 2.0
                         assertEquals(2.0, result, 0.0);  // Exact comparison
                     }

 @Test
                     public void testDistanceWithZeroLengthVectors6() {
                         // Test with identical points (distance should be 0)
                         double[] p1 = {0.0, 0.0, 0.0};
                         double[] p2 = {0.0, 0.0, 0.0};
                         double expected = 0.0;
                         double actual = MathUtils.distance(p1, p2);
                         assertEquals("Distance between identical points should be 0", expected, actual, 0.0001);
                     }

 @Test
                     public void testDistanceWithVeryClosePoints2() {
                         // Test with points that are very close (distance close to 0)
                         double[] p1 = {0.0, 0.0, 0.0};
                         double[] p2 = {0.001, 0.001, 0.001};
                         // Expected distance = sqrt(0.001² + 0.001² + 0.001²) = sqrt(0.000003) ≈ 0.00173205
                         double expected = 0.00173205;
                         double actual = MathUtils.distance(p1, p2);
                         assertEquals("Distance between very close points", expected, actual, 0.0001);
                         
                         // The mutant would return sqrt(1 + 0.000003) ≈ 1.0000015 which is significantly different
                     }

 @Test
                     public void testDistanceWithDifferentPoints() {
                         // Test with non-zero distance points
                         double[] p1 = {1.0, 2.0, 3.0};
                         double[] p2 = {4.0, 5.0, 6.0};
                         // Expected distance = sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                         double expected = 5.196152;
                         double actual = MathUtils.distance(p1, p2);
                         assertEquals("Distance between different points", expected, actual, 0.0001);
                         
                         // The mutant would return sqrt(1 + 27) ≈ 5.2915026 which is slightly different
                         // This shows why we need the zero-length test to catch the mutation
                     }

 @Test
                    public void testDistanceArrayBounds2() {
                        // Create test arrays with length 2
                        double[] p1 = {1.0, 2.0};
                        double[] p2 = {3.0, 4.0};
                        
                        // Calculate expected distance
                        double expected = Math.sqrt(Math.pow(1.0-3.0, 2) + Math.pow(2.0-4.0, 2));
                        
                        // Verify method works correctly with original code
                        double actual = MathUtils.distance(p1, p2);
                        assertEquals(expected, actual, 0.0001);
                        
                        // The mutated version would throw ArrayIndexOutOfBoundsException here
                        // because it would try to access p1[2] and p2[2] which don't exist
                    }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                    public void testDistanceArrayBoundsMutant() {
                        // This test will pass only with the mutated version
                        double[] p1 = {1.0};  // length 1
                        double[] p2 = {2.0};  // length 1
                        
                        // Mutated version will throw when i=1 (since length=1)
                        MathUtils.distance(p1, p2);
                        
                        // Original version would complete successfully
                        // So this test will fail with original code (as desired)
                    }

 @Test
                    public void testDistanceWithValidArrays() {
                        // Arrange
                        double[] p1 = {1.0, 2.0, 3.0};
                        double[] p2 = {4.0, 5.0, 6.0};
                        
                        // Act & Assert
                        // Original method should calculate distance correctly
                        double expectedDistance = Math.sqrt(
                            Math.pow(1.0-4.0, 2) + 
                            Math.pow(2.0-5.0, 2) + 
                            Math.pow(3.0-6.0, 2)
                        );
                        assertEquals(expectedDistance, MathUtils.distance(p1, p2), 0.0001);
                        
                        // Mutated version would throw ArrayIndexOutOfBoundsException
                        // This test will fail if the mutant is present
                    }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                    public void testDistanceWithMutatedLoopCondition1() {
                        // This test is designed to catch the mutant
                        // It will pass if the mutant is present (throws exception)
                        // and fail if the original code is present (no exception)
                        
                        // Arrange
                        double[] p1 = {1.0};  // Single element array
                        double[] p2 = {2.0};  // Single element array
                        
                        // Act - should throw for mutant when i=1 (array length=1)
                        MathUtils.distance(p1, p2);
                        
                        // If we reach here, the test fails (original code)
                        // The expected exception will only occur with the mutant
                    }

 @Test
                   public void testDistanceShouldIncludeFirstElement3() {
                       // Test with single-element arrays where the mutant would fail
                       double[] p1 = {3.0};  // Only element is at index 0
                       double[] p2 = {0.0};
                       
                       // Expected distance is sqrt((3-0)^2) = 3.0
                       double expected = 3.0;
                       double actual = MathUtils.distance(p1, p2);
                       
                       // This will fail with the mutant since it skips index 0
                       assertEquals("Distance calculation should include first element", 
                                   expected, actual, 0.0001);
                       
                       // Additional test with multiple elements where first element differs
                       double[] p3 = {1.0, 0.0, 0.0};
                       double[] p4 = {0.0, 0.0, 0.0};
                       
                       // Expected distance is sqrt((1-0)^2 + (0-0)^2 + (0-0)^2) = 1.0
                       double expected2 = 1.0;
                       double actual2 = MathUtils.distance(p3, p4);
                       
                       // This will also fail with the mutant since it skips index 0
                       assertEquals("Distance calculation should include first element in multi-element arrays",
                                   expected2, actual2, 0.0001);
                   }

 @Test
               public void testDistanceShouldIncludeFirstElement4() {
                   // Arrange
                   double[] p1 = {3.0, 4.0, 0.0};  // 3D point
                   double[] p2 = {0.0, 0.0, 0.0};  // Origin
                   
                   // Expected distance calculation:
                   // sqrt((3-0)² + (4-0)² + (0-0)²) = sqrt(9 + 16 + 0) = 5.0
                   double expectedDistance = 5.0;
                   
                   // Act
                   double actualDistance = MathUtils.distance(p1, p2);
                   
                   // Assert
                   assertEquals("Distance calculation should include first element", 
                               expectedDistance, actualDistance, 0.0001);
                   
                   // This test will fail with the mutant because:
                   // Mutant skips first element (3.0, 0.0)
                   // Mutant calculates sqrt((4-0)² + (0-0)²) = sqrt(16 + 0) = 4.0
                   // 4.0 != 5.0, so test would catch the mutant
               }

 @Test
                  public void testDistanceDetectsSubtractionMutation2() {
                      // Test case that will fail if subtraction is replaced with addition
                      double[] p1 = {1.0, 2.0, 3.0};
                      double[] p2 = {4.0, 5.0, 6.0};
                      
                      // Calculate expected value manually
                      double expected = Math.sqrt(
                          Math.pow(1.0 - 4.0, 2) + 
                          Math.pow(2.0 - 5.0, 2) + 
                          Math.pow(3.0 - 6.0, 2)
                      );
                      
                      // Calculate what the mutated version would produce
                      double mutated = Math.sqrt(
                          Math.pow(1.0 + 4.0, 2) + 
                          Math.pow(2.0 + 5.0, 2) + 
                          Math.pow(3.0 + 6.0, 2)
                      );
                      
                      // Verify the actual result matches expected and not the mutated version
                      double actual = MathUtils.distance(p1, p2);
                      assertEquals(expected, actual, 0.0001);
                      assertNotEquals(mutated, actual, 0.0001);
                      
                      // Additional test with negative numbers
                      double[] p3 = {-1.0, -2.0};
                      double[] p4 = {1.0, 2.0};
                      expected = Math.sqrt(Math.pow(-1.0 - 1.0, 2) + Math.pow(-2.0 - 2.0, 2));
                      mutated = Math.sqrt(Math.pow(-1.0 + 1.0, 2) + Math.pow(-2.0 + 2.0, 2));
                      
                      actual = MathUtils.distance(p3, p4);
                      assertEquals(expected, actual, 0.0001);
                      assertNotEquals(mutated, actual, 0.0001);
                  }

 @Test
                  public void testDistanceShouldCalculateCorrectEuclideanDistance3() {
                      // Test case that will expose the mutation
                      double[] point1 = {1.0, -2.0, 3.0};  // Contains positive and negative values
                      double[] point2 = {-1.0, 2.0, -3.0}; // Opposite signs to point1
                      
                      // Calculate expected value manually
                      double expectedSum = 0;
                      for (int i = 0; i < point1.length; i++) {
                          double dp = point1[i] - point2[i];
                          expectedSum += dp * dp;
                      }
                      double expected = Math.sqrt(expectedSum);
                      
                      // Calculate actual value
                      double actual = MathUtils.distance(point1, point2);
                      
                      // Assert with delta for floating point precision
                      assertEquals("Distance calculation is incorrect", expected, actual, 1e-10);
                      
                      // Additional test case with zeros
                      double[] zeroPoint1 = {0.0, 0.0};
                      double[] zeroPoint2 = {0.0, 0.0};
                      assertEquals(0.0, MathUtils.distance(zeroPoint1, zeroPoint2), 1e-10);
                      
                      // Test case with same values
                      double[] samePoint1 = {1.5, 2.5};
                      double[] samePoint2 = {1.5, 2.5};
                      assertEquals(0.0, MathUtils.distance(samePoint1, samePoint2), 1e-10);
                  }

 @Test
                 public void testDistanceWithDifferentPoints1() {
                     // Arrange
                     double[] p1 = {1.0, 2.0, 3.0};
                     double[] p2 = {4.0, 5.0, 6.0};
                     
                     // Act
                     double result = MathUtils.distance(p1, p2);
                     
                     // Assert - Calculate expected value manually with correct subtraction order
                     double expected = Math.sqrt(
                         Math.pow(1.0 - 4.0, 2) + 
                         Math.pow(2.0 - 5.0, 2) + 
                         Math.pow(3.0 - 6.0, 2)
                     );
                     
                     assertEquals("Distance calculation should use p1[i] - p2[i]", expected, result, 0.0001);
                 }

 @Test
                 public void testDistanceWithAsymmetricValues() {
                     // Arrange - Use values where subtraction order matters for intermediate steps
                     double[] p1 = {1.0e-300, 2.0e300};
                     double[] p2 = {2.0e-300, 1.0e300};
                     
                     // Act
                     double result = MathUtils.distance(p1, p2);
                     
                     // Assert - Calculate expected value manually
                     double expected = Math.sqrt(
                         Math.pow(1.0e-300 - 2.0e-300, 2) + 
                         Math.pow(2.0e300 - 1.0e300, 2)
                     );
                     
                     assertEquals("Distance should handle extreme values correctly", expected, result, 0.0001);
                 }

 @Test
                 public void testDistanceShouldCalculateCorrectEuclideanDistance4() {
                     // Test with values where floating-point subtraction order matters
                     double[] p1 = {1.1, 2.2, 3.3};
                     double[] p2 = {1.0, 2.0, 3.0};
                     
                     // Calculate expected value manually using correct subtraction order
                     double expected = 0.0;
                     double sum = 0.0;
                     for (int i = 0; i < p1.length; i++) {
                         final double dp = p1[i] - p2[i];  // Correct order
                         sum += dp * dp;
                     }
                     expected = Math.sqrt(sum);
                     
                     // Call the method and assert
                     double actual = MathUtils.distance(p1, p2);
                     assertEquals("Distance calculation should use p1[i]-p2[i] order", 
                                 expected, actual, 0.0001);
                     
                     // Additional test with different values
                     double[] p3 = {1.0000001, 2.0000001};
                     double[] p4 = {1.0, 2.0};
                     sum = 0.0;
                     for (int i = 0; i < p3.length; i++) {
                         final double dp = p3[i] - p4[i];  // Correct order
                         sum += dp * dp;
                     }
                     expected = Math.sqrt(sum);
                     actual = MathUtils.distance(p3, p4);
                     assertEquals("Distance calculation should be precise for small differences",
                                 expected, actual, 0.0000000001);
                 }

 @Test
                public void testDistanceShouldCalculateCorrectEuclideanDistance5() {
                    // Test case that will catch the mutant
                    double[] p1 = {1.0, 2.0, 3.0};
                    double[] p2 = {4.0, 5.0, 6.0};
                    
                    // Calculate expected value manually
                    // Original correct calculation: sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196
                    // Mutated incorrect calculation: sqrt((1-4) + (2-5) + (3-6)) = sqrt(-3 + -3 + -3) = sqrt(-9) → NaN or wrong
                    
                    double expected = Math.sqrt(27.0); // Correct expected value
                    double actual = MathUtils.distance(p1, p2);
                    
                    assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                }

 @Test
                public void testDistanceWithSingleDimension3() {
                    // Simple test case with one dimension
                    double[] p1 = {5.0};
                    double[] p2 = {2.0};
                    
                    // Expected: sqrt((5-2)²) = 3.0
                    // Mutated would give sqrt(3) ≈ 1.732 → wrong
                    
                    assertEquals(3.0, MathUtils.distance(p1, p2), 0.0001);
                }

 @Test
                public void testDistanceWithZeroDifference1() {
                    // Test case where points are identical
                    double[] p1 = {1.0, 2.0, 3.0};
                    double[] p2 = {1.0, 2.0, 3.0};
                    
                    // Both original and mutated would return 0 here, so this test alone wouldn't catch the mutant
                    // But it's good to have for completeness
                    assertEquals(0.0, MathUtils.distance(p1, p2), 0.0001);
                }

 @Test
                public void testDistanceWithNonZeroValues() {
                    // Test with simple values where squared sum != simple sum
                    double[] p1 = {1.0, 2.0, 3.0};
                    double[] p2 = {4.0, 5.0, 6.0};
                    
                    // Calculate expected value manually
                    // Original correct calculation:
                    // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                    // sqrt(27) ≈ 5.196152422706632
                    double expected = Math.sqrt(27);
                    
                    // Mutated incorrect calculation would be:
                    // (1-4) + (2-5) + (3-6) = -3 + -3 + -3 = -9
                    // sqrt(-9) would be NaN or throw exception
                    
                    double actual = MathUtils.distance(p1, p2);
                    
                    // Assert with delta for floating point precision
                    assertEquals(expected, actual, 1e-10);
                }

 @Test
                public void testDistanceWithZeroValues1() {
                    // Test with zero values where mutation would still produce same result
                    double[] p1 = {0.0, 0.0};
                    double[] p2 = {0.0, 0.0};
                    
                    // Both original and mutated would return 0
                    double expected = 0.0;
                    double actual = MathUtils.distance(p1, p2);
                    
                    assertEquals(expected, actual, 0.0);
                }

 @Test
                public void testDistanceWithSingleDimension4() {
                    // Test with single dimension where mutation would be most obvious
                    double[] p1 = {2.0};
                    double[] p2 = {5.0};
                    
                    // Original: sqrt((2-5)²) = 3
                    // Mutated: sqrt(2-5) = sqrt(-3) = NaN
                    double expected = 3.0;
                    double actual = MathUtils.distance(p1, p2);
                    
                    assertEquals(expected, actual, 0.0);
                }

 @Test
               public void testDistanceShouldCalculateCorrectEuclideanDistance6() {
                   // Test with simple 2D points where we can manually calculate distance
                   double[] p1 = {0.0, 0.0};
                   double[] p2 = {3.0, 4.0}; // 3-4-5 triangle
                   
                   // Expected distance is sqrt(3² + 4²) = 5
                   double expected = 5.0;
                   double actual = MathUtils.distance(p1, p2);
                   
                   // This will catch the mutant because:
                   // Original: sum = 9 + 16 = 25, sqrt(25) = 5
                   // Mutant: sum = -9 -16 = -25, sqrt(-25) = NaN
                   assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                   
                   // Additional test case with equal points
                   double[] p3 = {1.5, 2.5};
                   assertEquals("Distance between equal points should be 0", 
                               0.0, 
                               MathUtils.distance(p3, p3), 
                               0.0001);
                   
                   // Test case with 1D points
                   double[] p4 = {5.0};
                   double[] p5 = {8.0};
                   assertEquals("1D distance calculation is incorrect",
                               3.0,
                               MathUtils.distance(p4, p5),
                               0.0001);
               }

 @Test
               public void testDistanceShouldCalculateCorrectEuclideanDistance7() {
                   // Test with simple 2D points where distance is known
                   double[] p1 = {0.0, 0.0};
                   double[] p2 = {3.0, 4.0}; // 3-4-5 triangle
                   
                   // Expected distance is 5 (sqrt(3² + 4²) = sqrt(9 + 16) = sqrt(25) = 5)
                   double expected = 5.0;
                   double actual = MathUtils.distance(p1, p2);
                   
                   // Verify the result is a valid positive number
                   assertFalse(Double.isNaN(actual));
                   assertTrue(actual > 0);
                   
                   // Verify exact expected value with delta for floating point precision
                   assertEquals(expected, actual, 0.0001);
               }

 @Test
               public void testDistanceWithEqualPointsShouldReturnZero() {
                   // Test with identical points
                   double[] p1 = {1.0, 2.0, 3.0};
                   double[] p2 = {1.0, 2.0, 3.0};
                   
                   double expected = 0.0;
                   double actual = MathUtils.distance(p1, p2);
                   
                   assertEquals(expected, actual, 0.0);
               }

 @Test
               public void testDistanceWithNegativeCoordinates1() {
                   // Test with negative coordinates
                   double[] p1 = {-1.0, -2.0};
                   double[] p2 = {-4.0, -6.0};
                   
                   // Distance between (-1,-2) and (-4,-6) should be 5
                   // sqrt((-1 - -4)² + (-2 - -6)²) = sqrt(9 + 16) = 5
                   double expected = 5.0;
                   double actual = MathUtils.distance(p1, p2);
                   
                   assertEquals(expected, actual, 0.0001);
               }

 @Test
              public void testDistanceShouldReturnSquareRootOfSum() {
                  // Test case that will detect the sqrt vs sum mutant
                  double[] p1 = {3.0, 4.0};  // Point (3,4)
                  double[] p2 = {0.0, 0.0};  // Origin (0,0)
                  
                  // Calculate expected values
                  double sumOfSquares = (3.0*3.0) + (4.0*4.0);  // 9 + 16 = 25
                  double expectedDistance = Math.sqrt(sumOfSquares);  // 5.0
                  double mutatedOutput = sumOfSquares;  // What mutant would return (25.0)
                  
                  // Actual call
                  double actualDistance = MathUtils.distance(p1, p2);
                  
                  // Assertions
                  assertEquals("Distance should be square root of sum of squares", 
                              expectedDistance, actualDistance, 0.0001);
                  
                  // This assertion would fail for the mutant
                  assertNotEquals("Mutant would return sum instead of sqrt(sum)", 
                                 mutatedOutput, actualDistance, 0.0001);
              }

 @Test
              public void testDistanceWithSimpleValues() {
                  // Another simple test case to detect the mutant
                  double[] p1 = {1.0, 1.0};
                  double[] p2 = {0.0, 0.0};
                  
                  double expected = Math.sqrt(2.0);  // ~1.4142
                  double actual = MathUtils.distance(p1, p2);
                  
                  assertEquals(expected, actual, 0.0001);
                  assertNotEquals(2.0, actual, 0.0001);  // Would fail for mutant
              }

 @Test
          public void testDistanceShouldReturnSquareRootOfSum1() {
              // Test case where sum of squares is 25 (3² + 4²)
              // Expected distance should be 5 (√25)
              double[] p1 = {0, 0};
              double[] p2 = {3, 4};
              
              double expected = 5.0; // √(3² + 4²) = 5
              double actual = MathUtils.distance(p1, p2);
              
              // This will catch the mutant because:
              // Original: returns 5.0 (√25)
              // Mutant: returns 25.0 (just the sum)
              assertEquals("Distance should be square root of sum of squared differences", 
                          expected, actual, 0.0001);
              
              // Additional test case with different values
              p1 = new double[]{1, 2, 3};
              p2 = new double[]{4, 5, 6};
              expected = Math.sqrt(9 + 9 + 9); // √27 ≈ 5.196152
              actual = MathUtils.distance(p1, p2);
              assertEquals("Distance should be square root of sum of squared differences",
                          expected, actual, 0.0001);
          }

 @Test
             public void testDistanceShouldReturnExactValueWithoutOffset() {
                 // Test case 1: Zero distance (same points)
                 double[] p1 = {0.0, 0.0};
                 double[] p2 = {0.0, 0.0};
                 double result = MathUtils.distance(p1, p2);
                 assertEquals(0.0, result, 0.0);  // Exact comparison
                 
                 // Test case 2: Unit distance
                 double[] p3 = {0.0, 0.0};
                 double[] p4 = {1.0, 0.0};
                 double result2 = MathUtils.distance(p3, p4);
                 assertEquals(1.0, result2, 0.0);  // Exact comparison
                 
                 // Test case 3: Simple known distance
                 double[] p5 = {0.0, 0.0};
                 double[] p6 = {3.0, 4.0};
                 double result3 = MathUtils.distance(p5, p6);
                 assertEquals(5.0, result3, 0.0);  // Exact comparison (3-4-5 triangle)
             }

 @Test
         public void testDistanceShouldReturnCorrectEuclideanDistance1() {
             // Test case 1: Identical points should have distance 0
             double[] point1 = {0.0, 0.0};
             double[] point2 = {0.0, 0.0};
             assertEquals(0.0, MathUtils.distance(point1, point2), 0.0001);
             
             // Test case 2: Points with distance exactly 1
             double[] point3 = {0.0, 0.0};
             double[] point4 = {1.0, 0.0};
             assertEquals(1.0, MathUtils.distance(point3, point4), 0.0001);
             
             // Test case 3: Points with known distance (3-4-5 triangle)
             double[] point5 = {0.0, 0.0};
             double[] point6 = {3.0, 4.0};
             assertEquals(5.0, MathUtils.distance(point5, point6), 0.0001);
             
             // Test case 4: Higher dimension case
             double[] point7 = {1.0, 2.0, 3.0};
             double[] point8 = {4.0, 5.0, 6.0};
             double expected = Math.sqrt(9 + 9 + 9); // sqrt(27)
             assertEquals(expected, MathUtils.distance(point7, point8), 0.0001);
         }

 @Test
            public void testDistanceWithZeroLengthVectors7() {
                // Test with identical points (distance should be 0)
                double[] p1 = {0.0, 0.0, 0.0};
                double[] p2 = {0.0, 0.0, 0.0};
                double expected = 0.0;
                double actual = MathUtils.distance(p1, p2);
                assertEquals("Distance between identical points should be 0", expected, actual, 0.0001);
            }

 @Test
            public void testDistanceWithSmallVectors1() {
                // Test with small non-zero distance
                double[] p1 = {1.0, 1.0};
                double[] p2 = {0.0, 0.0};
                double expected = Math.sqrt(2); // √(1² + 1²) = √2 ≈ 1.4142
                double actual = MathUtils.distance(p1, p2);
                assertEquals("Distance calculation incorrect", expected, actual, 0.0001);
            }

 @Test
            public void testDistanceWithSingleDimension5() {
                // Test with single dimension where the effect would be most noticeable
                double[] p1 = {0.0};
                double[] p2 = {0.0};
                double expected = 0.0;
                double actual = MathUtils.distance(p1, p2);
                assertEquals("Distance between single-dimension identical points should be 0", 
                            expected, actual, 0.0001);
            }

 @Test
            public void testDistanceWithZeroLengthVectors8() {
                // Test with identical points (distance should be 0)
                double[] p1 = {0.0, 0.0, 0.0};
                double[] p2 = {0.0, 0.0, 0.0};
                
                double expected = 0.0;
                double actual = MathUtils.distance(p1, p2);
                
                // This will fail with the mutated version (returns sqrt(0.5))
                assertEquals("Distance between identical points should be 0", 
                            expected, actual, 0.000001);
            }

 @Test
            public void testDistanceWithUnitVectors() {
                // Test with points 1 unit apart in one dimension
                double[] p1 = {0.0, 0.0, 0.0};
                double[] p2 = {1.0, 0.0, 0.0};
                
                double expected = 1.0;
                double actual = MathUtils.distance(p1, p2);
                
                // This will fail with the mutated version (returns sqrt(1.5))
                assertEquals("Distance between unit vectors should be 1", 
                            expected, actual, 0.000001);
            }

 @Test
           public void testDistanceShouldProcessAllDimensions2() {
               // Create test points where the last dimension makes a significant difference
               double[] p1 = {1.0, 2.0, 3.0};  // 3D point
               double[] p2 = {4.0, 5.0, 6.0};  // 3D point
               
               // Calculate expected distance manually
               // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
               double expectedDistance = Math.sqrt(27.0);
               
               // Calculate with method
               double actualDistance = MathUtils.distance(p1, p2);
               
               // Verify all dimensions were processed
               assertEquals("Distance calculation should include all dimensions", 
                           expectedDistance, actualDistance, 1e-10);
               
               // Additional test with different values where last element is crucial
               double[] p3 = {0.0, 0.0, 0.0, 10.0};  // 4D point
               double[] p4 = {0.0, 0.0, 0.0, 0.0};   // 4D point
               
               // Expected: sqrt(0 + 0 + 0 + 100) = 10.0
               assertEquals("Should process last dimension when it's the only non-zero", 
                           10.0, MathUtils.distance(p3, p4), 1e-10);
           }

 @Test
       public void testDistanceShouldProcessAllElements2() {
           // Test case with single element arrays - mutant would skip processing entirely
           double[] single1 = {3.0};
           double[] single2 = {7.0};
           double expectedSingle = 4.0; // sqrt((3-7)^2) = 4
           assertEquals(expectedSingle, MathUtils.distance(single1, single2), 0.0001);
           
           // Test case with multiple elements where last element makes a difference
           double[] multi1 = {1.0, 2.0, 3.0, 4.0};
           double[] multi2 = {1.0, 2.0, 3.0, 8.0}; // Only last element differs
           double expectedMulti = 4.0; // sqrt(0+0+0+(4-8)^2) = 4
           assertEquals(expectedMulti, MathUtils.distance(multi1, multi2), 0.0001);
           
           // Test case where all elements are same except last one
           double[] sameExceptLast1 = {5.0, 5.0, 5.0, 5.0};
           double[] sameExceptLast2 = {5.0, 5.0, 5.0, 10.0};
           double expectedSameExceptLast = 5.0; // sqrt(0+0+0+(5-10)^2) = 5
           assertEquals(expectedSameExceptLast, MathUtils.distance(sameExceptLast1, sameExceptLast2), 0.0001);
           
           // Test case with 2 elements where both contribute
           double[] twoElements1 = {0.0, 3.0};
           double[] twoElements2 = {4.0, 0.0};
           double expectedTwoElements = 5.0; // sqrt((0-4)^2 + (3-0)^2) = 5 (3-4-5 triangle)
           assertEquals(expectedTwoElements, MathUtils.distance(twoElements1, twoElements2), 0.0001);
       }

 @Test
          public void testDistanceWithEmptyArrays4() {
              // Test with empty arrays
              double[] empty1 = new double[0];
              double[] empty2 = new double[0];
              
              // Original method should handle this fine (return 0)
              // Mutant will throw ArrayIndexOutOfBoundsException
              double result = MathUtils.distance(empty1, empty2);
              
              // Assert the expected result is 0 for zero-length arrays
              assertEquals(0.0, result, 0.0001);
          }

 @Test
          public void testDistanceWithNormalArrays3() {
              // Also include a normal case to ensure basic functionality works
              double[] p1 = {1.0, 2.0, 3.0};
              double[] p2 = {4.0, 5.0, 6.0};
              
              double expected = Math.sqrt(9 + 9 + 9); // sqrt(27)
              double result = MathUtils.distance(p1, p2);
              
              assertEquals(expected, result, 0.0001);
          }

 @Test
          public void testDistanceWithEmptyArrays5() {
              double[] empty1 = {};
              double[] empty2 = {};
              
              // Should return 0 for empty arrays and terminate properly
              double result = MathUtils.distance(empty1, empty2);
              assertEquals(0.0, result, 0.0001);
          }

 @Test
          public void testDistanceWithSingleElementArrays2() {
              double[] p1 = {3.0};
              double[] p2 = {7.0};
              
              // Should calculate sqrt((3-7)^2) = 4
              double result = MathUtils.distance(p1, p2);
              assertEquals(4.0, result, 0.0001);
          }

 @Test
          public void testDistanceWithLargeArrays() {
              // Create large arrays (size 10000)
              double[] p1 = new double[10000];
              double[] p2 = new double[10000];
              java.util.Arrays.fill(p1, 1.0);
              java.util.Arrays.fill(p2, 2.0);
              
              // Should calculate sqrt(10000 * (1-2)^2) = 100
              double result = MathUtils.distance(p1, p2);
              assertEquals(100.0, result, 0.0001);
          }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
          public void testDistanceWithDifferentLengthArrays1() {
              double[] p1 = {1.0, 2.0};
              double[] p2 = {1.0};  // Different length
              
              // Should throw ArrayIndexOutOfBoundsException
              MathUtils.distance(p1, p2);
          }

 @Test
     public void testDistanceShouldDetectMultiplicationMutant() {
         // Test case where (p1-p2)² is different from (p1*p2)²
         double[] p1 = {3.0, 4.0};  // Point (3,4)
         double[] p2 = {1.0, 2.0};  // Point (1,2)
         
         // Expected correct calculation:
         // sqrt((3-1)² + (4-2)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.8284
         double expectedDistance = Math.sqrt(8.0);
         
         // Mutated version would calculate:
         // sqrt((3*1)² + (4*2)²) = sqrt(9 + 64) = sqrt(73) ≈ 8.544
         // which is very different from expected
         
         double actualDistance = MathUtils.distance(p1, p2);
         
         // Assert with delta for floating point precision
         assertEquals(expectedDistance, actualDistance, 0.0001);
         
         // Additional test case with negative values to ensure robustness
         double[] p3 = {-1.0, 0.0};
         double[] p4 = {2.0, -3.0};
         expectedDistance = Math.sqrt(9.0 + 9.0); // sqrt(18) ≈ 4.2426
         actualDistance = MathUtils.distance(p3, p4);
         assertEquals(expectedDistance, actualDistance, 0.0001);
     }

 @Test
         public void testDistanceDetectsSubtractionMutant1() {
             // Test case that will fail with the multiplication mutant
             double[] p1 = {1.0, 2.0};  // Simple coordinates
             double[] p2 = {3.0, 4.0};  // Different coordinates
             
             // Calculate expected distance manually
             double expected = Math.sqrt(Math.pow(1.0-3.0, 2) + Math.pow(2.0-4.0, 2));
             
             // The mutant would calculate: Math.sqrt((1*3)^2 + (2*4)^2) = Math.sqrt(9 + 64) = √73 ≈ 8.544
             // While correct distance is √8 ≈ 2.828
             
             double actual = MathUtils.distance(p1, p2);
             
             // Assert with delta for floating point precision
             assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
             
             // Additional test with negative numbers
             double[] p3 = {-1.0, -2.0};
             double[] p4 = {1.0, 2.0};
             expected = Math.sqrt(Math.pow(-1.0-1.0, 2) + Math.pow(-2.0-2.0, 2));
             actual = MathUtils.distance(p3, p4);
             assertEquals("Distance with negative values incorrect", expected, actual, 0.0001);
             
             // Test with single dimension
             double[] p5 = {5.0};
             double[] p6 = {2.0};
             expected = Math.abs(5.0 - 2.0); // For 1D, distance is simple difference
             actual = MathUtils.distance(p5, p6);
             assertEquals("1D distance incorrect", expected, actual, 0.0001);
         }

 @Test
        public void testDistanceDetectsSubtractionMutation3() {
            // Test case that will clearly show difference between subtraction and division
            double[] p1 = {3.0, 4.0};  // Simple values where subtraction != division
            double[] p2 = {1.0, 2.0};  // Different from p1 and not 1
            
            // Expected calculation with subtraction:
            // sqrt((3-1)^2 + (4-2)^2) = sqrt(4 + 4) = sqrt(8) ≈ 2.828
            double expected = Math.sqrt(8.0);
            
            // What mutated version would calculate:
            // sqrt((3/1)^2 + (4/2)^2) = sqrt(9 + 4) = sqrt(13) ≈ 3.606
            // This is significantly different from expected
            
            double actual = MathUtils.distance(p1, p2);
            
            // Assert with delta for floating point precision
            assertEquals("Distance calculation should use subtraction, not division", 
                        expected, actual, 0.0001);
            
            // Additional test case with different values
            double[] p3 = {5.0, 10.0};
            double[] p4 = {2.0, 5.0};
            expected = Math.sqrt(9.0 + 25.0); // sqrt(34) ≈ 5.831
            actual = MathUtils.distance(p3, p4);
            assertEquals(expected, actual, 0.0001);
            
            // Edge case where p2 contains 1 (since x/1 = x)
            double[] p5 = {3.0, 4.0};
            double[] p6 = {1.0, 1.0};
            expected = Math.sqrt(4.0 + 9.0); // sqrt(13) ≈ 3.606
            actual = MathUtils.distance(p5, p6);
            assertEquals(expected, actual, 0.0001);
        }

 @Test
    public void testDistanceShouldCalculateUsingSubtractionNotDivision() {
        // Arrange
        double[] p1 = {4.0, 3.0};  // Simple coordinates
        double[] p2 = {1.0, 1.0};  // where subtraction ≠ division
        
        // Expected calculation:
        // sqrt((4-1)^2 + (3-1)^2) = sqrt(9 + 4) = sqrt(13) ≈ 3.605551275463989
        double expected = Math.sqrt(13.0);
        
        // Act
        double actual = MathUtils.distance(p1, p2);
        
        // Assert
        assertEquals("Distance should be calculated using subtraction of coordinates", 
                    expected, actual, 1e-10);
        
        // The mutant using division would calculate:
        // sqrt((4/1)^2 + (3/1)^2) = sqrt(16 + 9) = sqrt(25) = 5.0
        // which is different from our expected value
    }

 @Test
       public void testDistanceDetectsMutant() {
           // Test case with values > 1 where mutation would cause larger sum
           double[] p1 = {2.0, 3.0};
           double[] p2 = {1.0, 1.0};
           double expected = Math.sqrt((1.0*1.0) + (2.0*2.0)); // sqrt(1 + 4) = sqrt(5) ≈ 2.236
           double actual = MathUtils.distance(p1, p2);
           assertEquals("Distance calculation incorrect for values > 1", expected, actual, 0.0001);
   
           // Test case with values between 0 and 1 where mutation would cause smaller sum
           double[] p3 = {0.5, 0.3};
           double[] p4 = {0.1, 0.1};
           expected = Math.sqrt((0.4*0.4) + (0.2*0.2)); // sqrt(0.16 + 0.04) = sqrt(0.2) ≈ 0.4472
           actual = MathUtils.distance(p3, p4);
           assertEquals("Distance calculation incorrect for values between 0 and 1", expected, actual, 0.0001);
   
           // Test case with zero difference
           double[] p5 = {1.0, 2.0};
           double[] p6 = {1.0, 2.0};
           expected = 0.0;
           actual = MathUtils.distance(p5, p6);
           assertEquals("Distance should be zero for identical points", expected, actual, 0.0001);
       }

 @Test
       public void testDistanceWithKnownValues2() {
           // Test with simple known values where squared and cubed differ
           double[] p1 = {1.0, 2.0, 3.0};
           double[] p2 = {4.0, 5.0, 6.0};
           
           // Original calculation: sqrt((3^2 + 3^2 + 3^2)) = sqrt(27) ≈ 5.196152
           // Mutated calculation: sqrt((3^3 + 3^3 + 3^3)) = sqrt(81) = 9.0
           double expectedDistance = Math.sqrt(3 * 3 * 3); // 5.196152422706632
           double actualDistance = MathUtils.distance(p1, p2);
           
           // Use delta for floating point comparison
           assertEquals("Distance calculation should use squared differences", 
                      expectedDistance, actualDistance, 1e-10);
           
           // Another test case with different values
           double[] p3 = {0.0, 1.0};
           double[] p4 = {1.0, 0.0};
           
           // Original: sqrt((1^2 + 1^2)) = sqrt(2) ≈ 1.414213
           // Mutated: sqrt((1^3 + 1^3)) = sqrt(2) ≈ 1.414213 (same in this case)
           // So we need another case where squared and cubed differ
           double[] p5 = {2.0, 0.0};
           double[] p6 = {0.0, 0.0};
           
           // Original: sqrt(4) = 2.0
           // Mutated: sqrt(8) ≈ 2.828427
           assertEquals(2.0, MathUtils.distance(p5, p6), 1e-10);
       }

 @Test
      public void testDistanceWithMultipleDimensions4() {
          // Test with 3D points where all dimensions contribute to distance
          double[] p1 = {1.0, 2.0, 3.0};
          double[] p2 = {4.0, 5.0, 6.0};
          
          // Calculate expected distance manually:
          // sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
          double expected = Math.sqrt(27.0);
          double actual = MathUtils.distance(p1, p2);
          
          // Use delta for floating point comparison
          assertEquals("Distance should account for all dimensions", expected, actual, 1e-10);
          
          // Another test case with 2D points
          double[] p3 = {0.0, 0.0};
          double[] p4 = {3.0, 4.0};
          // sqrt(3^2 + 4^2) = 5.0
          assertEquals("Distance should be 5.0 for 3-4-5 triangle", 
                      5.0, MathUtils.distance(p3, p4), 1e-10);
      }

 @Test
      public void testDistanceWithMultipleDimensions5() {
          // Test with 3-dimensional points
          double[] p1 = {1.0, 2.0, 3.0};
          double[] p2 = {4.0, 5.0, 6.0};
          
          // Calculate expected distance manually:
          // sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
          double expected = Math.sqrt(27.0);
          double actual = MathUtils.distance(p1, p2);
          
          // Assert with delta for floating point precision
          assertEquals("Distance calculation should consider all dimensions", 
                      expected, actual, 1e-10);
          
          // Additional test with 2 dimensions to be thorough
          double[] p3 = {0.0, 0.0};
          double[] p4 = {3.0, 4.0};
          assertEquals("Distance should be 5 for 3-4-5 triangle", 
                      5.0, MathUtils.distance(p3, p4), 1e-10);
      }

 @Test
     public void testDistanceShouldReturnSquareRootOfSum2() {
         // Test case where sum of squared differences is 4 (sqrt(4)=2, abs(4)=4)
         double[] p1 = {0.0, 0.0};
         double[] p2 = {2.0, 0.0}; // distance = sqrt(2² + 0²) = 2
         
         double result = MathUtils.distance(p1, p2);
         
         // Verify the result is the square root (2) not the absolute value (4)
         assertEquals(2.0, result, 0.0001);
         
         // Additional test case where sum of squared differences is 0.25 (sqrt(0.25)=0.5, abs(0.25)=0.25)
         double[] p3 = {0.0, 0.0};
         double[] p4 = {0.5, 0.0}; // distance = sqrt(0.5² + 0²) = 0.5
         
         double result2 = MathUtils.distance(p3, p4);
         
         // Verify the result is the square root (0.5) not the absolute value (0.25)
         assertEquals(0.5, result2, 0.0001);
     }

 @Test
     public void testDistanceDetectsSqrtToAbsMutant2() {
         // Test case that will clearly show difference between sqrt and abs
         double[] p1 = {0.0, 0.0};
         double[] p2 = {3.0, 4.0};
         
         // Calculate expected value (Euclidean distance)
         double expected = 5.0; // sqrt(3² + 4²) = sqrt(9 + 16) = sqrt(25) = 5
         
         // Calculate what mutant would return
         double mutantValue = 25.0; // abs(9 + 16) = 25
         
         // Actual call
         double actual = MathUtils.distance(p1, p2);
         
         // Assertions
         assertEquals("Distance should be square root of sum of squares", 
                      expected, actual, 0.0001);
         
         // This assertion would fail for the mutant
         assertNotEquals("Test should detect sqrt->abs mutation", 
                        mutantValue, actual, 0.0001);
     }

 @Test
     public void testDistanceWithAnotherCaseToEnsureDetection() {
         // Another test case where sqrt and abs differ
         double[] p1 = {1.0, 2.0, 3.0};
         double[] p2 = {4.0, 5.0, 6.0};
         
         // Expected: sqrt((4-1)² + (5-2)² + (6-3)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196
         double expected = Math.sqrt(27);
         
         // Mutant would return: abs(9 + 9 + 9) = 27
         double mutantValue = 27.0;
         
         double actual = MathUtils.distance(p1, p2);
         
         assertEquals(expected, actual, 0.0001);
         assertNotEquals(mutantValue, actual, 0.0001);
     }

}
