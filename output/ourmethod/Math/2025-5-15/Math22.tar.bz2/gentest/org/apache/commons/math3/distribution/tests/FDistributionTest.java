package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.special.Beta;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
 
public class FDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                 public void testGetDenominatorDegreesOfFreedom_ValidValues() {
                                     // Test with typical positive values
                                     FDistribution dist1 = new FDistribution(5.0, 10.0);
                                     assertEquals(10.0, dist1.getDenominatorDegreesOfFreedom(), 0.0);
                                     
                                     // Test with fractional values
                                     FDistribution dist2 = new FDistribution(3.5, 7.25);
                                     assertEquals(7.25, dist2.getDenominatorDegreesOfFreedom(), 0.0);
                                     
                                     // Test with very large values
                                     FDistribution dist3 = new FDistribution(1.0, Double.MAX_VALUE);
                                     assertEquals(Double.MAX_VALUE, dist3.getDenominatorDegreesOfFreedom(), 0.0);
                                     
                                     // Test with values just above zero
                                     FDistribution dist4 = new FDistribution(1.0, Double.MIN_VALUE);
                                     assertEquals(Double.MIN_VALUE, dist4.getDenominatorDegreesOfFreedom(), 0.0);
                                 }

 @Test
                                 public void testGetDenominatorDegreesOfFreedom_ConstructorValidation() {
                                     // Verify constructor throws exception for zero denominator degrees
                                     thrown.expect(NotStrictlyPositiveException.class);
                                     thrown.expectMessage("degrees of freedom");
                                     new FDistribution(1.0, 0.0);
                                     
                                     // Verify constructor throws exception for negative denominator degrees
                                     thrown.expect(NotStrictlyPositiveException.class);
                                     thrown.expectMessage("degrees of freedom");
                                     new FDistribution(1.0, -1.0);
                                 }

 @Test
                                 public void testGetDenominatorDegreesOfFreedom_AfterConstruction() {
                                     // Test that the value remains constant after construction
                                     double denominatorDF = 15.0;
                                     FDistribution dist = new FDistribution(5.0, denominatorDF);
                                     
                                     // Multiple calls should return the same value
                                     assertEquals(denominatorDF, dist.getDenominatorDegreesOfFreedom(), 0.0);
                                     assertEquals(denominatorDF, dist.getDenominatorDegreesOfFreedom(), 0.0);
                                     assertEquals(denominatorDF, dist.getDenominatorDegreesOfFreedom(), 0.0);
                                 }

 @Test
                                 public void testGetDenominatorDegreesOfFreedom_WithDifferentConstructors() {
                                     // Test with different constructor variants
                                     double denominatorDF = 8.0;
                                     
                                     // Test with 2-arg constructor
                                     FDistribution dist1 = new FDistribution(3.0, denominatorDF);
                                     assertEquals(denominatorDF, dist1.getDenominatorDegreesOfFreedom(), 0.0);
                                     
                                     // Test with 3-arg constructor
                                     FDistribution dist2 = new FDistribution(3.0, denominatorDF, 1e-9);
                                     assertEquals(denominatorDF, dist2.getDenominatorDegreesOfFreedom(), 0.0);
                                     
                                     // Test with 4-arg constructor
                                     FDistribution dist3 = new FDistribution(new Well19937c(), 3.0, denominatorDF, 1e-9);
                                     assertEquals(denominatorDF, dist3.getDenominatorDegreesOfFreedom(), 0.0);
                                 }

 @Test
                                 public void testIsSupportLowerBoundInclusive() {
                                     // Test with different valid degrees of freedom combinations
                                     FDistribution dist1 = new FDistribution(1.0, 1.0);
                                     assertFalse(dist1.isSupportLowerBoundInclusive());
                                     
                                     FDistribution dist2 = new FDistribution(5.0, 10.0);
                                     assertFalse(dist2.isSupportLowerBoundInclusive());
                                     
                                     FDistribution dist3 = new FDistribution(100.0, 200.0);
                                     assertFalse(dist3.isSupportLowerBoundInclusive());
                                     
                                     FDistribution dist4 = new FDistribution(0.5, 0.5); // non-integer degrees of freedom
                                     assertFalse(dist4.isSupportLowerBoundInclusive());
                                     
                                     // Test with custom inverse cumulative accuracy
                                     FDistribution dist5 = new FDistribution(2.0, 3.0, 1e-12);
                                     assertFalse(dist5.isSupportLowerBoundInclusive());
                                 }

 @Test
                         public void testGetSolverAbsoluteAccuracy_DefaultConstructor() throws Exception {
                             // Test with default accuracy
                             FDistribution dist = new FDistribution(2.0, 5.0);
                             double defaultAccuracy = 1.0e-6; // Typical default value for solver accuracy
                             
                             // Use reflection to access protected method
                             Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                             method.setAccessible(true);
                             double actualAccuracy = (Double) method.invoke(dist);
                             
                             assertEquals(defaultAccuracy, actualAccuracy, 0.0);
                         }

 @Test
                         public void testGetSolverAbsoluteAccuracy_CustomAccuracy() throws Exception {
                             // Test with custom accuracy
                             double customAccuracy = 1e-15;
                             FDistribution dist = new FDistribution(3.0, 6.0, customAccuracy);
                             
                             // Use reflection to access protected method
                             Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                             method.setAccessible(true);
                             double actualAccuracy = (Double) method.invoke(dist);
                             
                             assertEquals(customAccuracy, actualAccuracy, 0.0);
                         }

 @Test
                         public void testGetSolverAbsoluteAccuracy_ZeroAccuracy() throws Exception {
                             // Test with zero accuracy (edge case)
                             FDistribution dist = new FDistribution(4.0, 7.0, 0.0);
                             
                             // Use reflection to access protected method
                             Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                             method.setAccessible(true);
                             double accuracy = (Double) method.invoke(dist);
                             
                             assertEquals(0.0, accuracy, 0.0);
                         }

 @Test
                         public void testGetSolverAbsoluteAccuracy_LargeAccuracy() throws Exception {
                             // Test with large accuracy value
                             double largeAccuracy = 1e5;
                             FDistribution dist = new FDistribution(1.5, 2.5, largeAccuracy);
                             
                             // Use reflection to access protected method
                             Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                             method.setAccessible(true);
                             double actualAccuracy = (Double) method.invoke(dist);
                             
                             assertEquals(largeAccuracy, actualAccuracy, 0.0);
                         }

 @Test
                         public void testGetSolverAbsoluteAccuracy_RandomGeneratorConstructor() throws Exception {
                             // Test with random generator constructor
                             double customAccuracy = 1e-10;
                             FDistribution dist = new FDistribution(new Well19937c(), 2.0, 3.0, customAccuracy);
                             
                             // Use reflection to access protected method
                             Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                             method.setAccessible(true);
                             double actualAccuracy = (Double) method.invoke(dist);
                             
                             assertEquals(customAccuracy, actualAccuracy, 0.0);
                         }

 @Test
                         public void testGetSolverAbsoluteAccuracy_AfterInvalidConstructionAttempt() throws Exception {
                             // Define test accuracy value
                             final double TEST_ACCURACY = 1.0e-12;
                             
                             // Verify accuracy is still set correctly even if construction fails
                             try {
                                 new FDistribution(-1.0, 2.0, TEST_ACCURACY);
                             } catch (NotStrictlyPositiveException e) {
                                 // Expected
                             }
                             
                             // Now create valid distribution
                             FDistribution dist = new FDistribution(2.0, 3.0, TEST_ACCURACY);
                             
                             // Use reflection to access protected method
                             Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                             method.setAccessible(true);
                             double accuracy = (Double) method.invoke(dist);
                             
                             assertEquals(TEST_ACCURACY, accuracy, 0.0);
                         }

 @Test
                         public void testGetSolverAbsoluteAccuracy_MultipleInstancesDifferentAccuracies() throws Exception {
                             // Test multiple instances with different accuracies
                             FDistribution dist1 = new FDistribution(2.0, 5.0, 1e-6);
                             FDistribution dist2 = new FDistribution(3.0, 6.0, 1e-9);
                             FDistribution dist3 = new FDistribution(4.0, 7.0, 1e-12);
                             
                             // Use reflection to access protected method
                             Method getSolverAccuracy = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                             getSolverAccuracy.setAccessible(true);
                             
                             assertEquals(1e-6, (Double)getSolverAccuracy.invoke(dist1), 0.0);
                             assertEquals(1e-9, (Double)getSolverAccuracy.invoke(dist2), 0.0);
                             assertEquals(1e-12, (Double)getSolverAccuracy.invoke(dist3), 0.0);
                         }

 @Test
                         public void testGetDenominatorDegreesOfFreedomReturnsExactValue() {
                             // Create test values - including a negative value to catch the abs mutant
                             double positiveValue = 5.0;
                             double negativeValue = -3.0;
                             
                             // Test with positive value
                             FDistribution distPositive = new FDistribution(1.0, positiveValue);
                             assertEquals("Should return exact positive value", 
                                         positiveValue, 
                                         distPositive.getDenominatorDegreesOfFreedom(), 
                                         0.0001);
                             
                             // Test with negative value - this will catch the mutant
                             // Note: While negative values are invalid for F-distribution parameters,
                             // the getter should still return the exact stored value
                             FDistribution distNegative = new FDistribution(1.0, negativeValue);
                             assertEquals("Should return exact negative value", 
                                         negativeValue, 
                                         distNegative.getDenominatorDegreesOfFreedom(), 
                                         0.0001);
                         }

 @Test
                        public void testGetDenominatorDegreesOfFreedom() {
                            // Test with typical positive value
                            double testValue1 = 5.0;
                            FDistribution dist1 = new FDistribution(2.0, testValue1);
                            assertEquals("Getter should return exact denominator degrees of freedom", 
                                        testValue1, 
                                        dist1.getDenominatorDegreesOfFreedom(), 
                                        0.0);
                            
                            // Test with different positive value
                            double testValue2 = 10.5;
                            FDistribution dist2 = new FDistribution(3.0, testValue2);
                            assertEquals("Getter should return exact denominator degrees of freedom", 
                                        testValue2, 
                                        dist2.getDenominatorDegreesOfFreedom(), 
                                        0.0);
                            
                            // Test with boundary value (just above 0)
                            double testValue3 = Double.MIN_VALUE;
                            FDistribution dist3 = new FDistribution(1.0, testValue3);
                            assertEquals("Getter should return exact denominator degrees of freedom for very small values", 
                                        testValue3, 
                                        dist3.getDenominatorDegreesOfFreedom(), 
                                        0.0);
                            
                            // Test with large value
                            double testValue4 = 1e6;
                            FDistribution dist4 = new FDistribution(1.0, testValue4);
                            assertEquals("Getter should return exact denominator degrees of freedom for large values", 
                                        testValue4, 
                                        dist4.getDenominatorDegreesOfFreedom(), 
                                        0.0);
                        }

 @Test
                       public void testGetDenominatorDegreesOfFreedomWhenZero() {
                           // Create FDistribution with denominatorDegreesOfFreedom = 0
                           // Note: The constructor throws exception for values <= 0, so we need to use reflection
                           // to set the field value directly for this test case
                           
                           try {
                               // Create instance with valid initial values
                               FDistribution dist = new FDistribution(1.0, 1.0);
                               
                               // Use reflection to set denominatorDegreesOfFreedom to 0
                               java.lang.reflect.Field field = FDistribution.class.getDeclaredField("denominatorDegreesOfFreedom");
                               field.setAccessible(true);
                               field.set(dist, 0.0);
                               
                               // Test the method
                               double result = dist.getDenominatorDegreesOfFreedom();
                               
                               // Assert that it returns 0 (original behavior)
                               assertEquals(0.0, result, 0.0001);
                           } catch (Exception e) {
                               fail("Exception occurred during test: " + e.getMessage());
                           }
                       }

 @Test
                      public void testGetDenominatorDegreesOfFreedomReturnsCorrectValue() {
                          // Arrange
                          double numeratorDf = 5.0;
                          double denominatorDf = 10.0;
                          FDistribution fDist = new FDistribution(numeratorDf, denominatorDf);
                          
                          // Act
                          double result = fDist.getDenominatorDegreesOfFreedom();
                          
                          // Assert
                          assertEquals("Denominator degrees of freedom should match constructor argument", 
                                      denominatorDf, result, 0.0001);
                          assertTrue("Denominator degrees of freedom should be positive", 
                                    result > 0);
                      }

 @Test
                     public void testGetDenominatorDegreesOfFreedomReturnsCorrectValue1() {
                         // Test with normal value
                         double testDenominator = 5.0;
                         FDistribution dist = new FDistribution(2.0, testDenominator);
                         assertEquals("Should return exact denominator degrees of freedom", 
                                      testDenominator, 
                                      dist.getDenominatorDegreesOfFreedom(), 
                                      0.0);
                         
                         // Test with very large value (but not MAX_VALUE)
                         double largeValue = 1.0e100;
                         FDistribution dist2 = new FDistribution(2.0, largeValue);
                         assertEquals("Should return exact denominator degrees of freedom even for large values",
                                      largeValue,
                                      dist2.getDenominatorDegreesOfFreedom(),
                                      0.0);
                         
                         // Test with very small value
                         double smallValue = Double.MIN_VALUE;
                         FDistribution dist3 = new FDistribution(2.0, smallValue);
                         assertEquals("Should return exact denominator degrees of freedom even for small values",
                                      smallValue,
                                      dist3.getDenominatorDegreesOfFreedom(),
                                      0.0);
                     }

 @Test
                     public void testGetDenominatorDegreesOfFreedomDoesNotReturnMaxValue() {
                         double testDenominator = 10.0;
                         FDistribution dist = new FDistribution(2.0, testDenominator);
                         assertNotEquals("Should not return Double.MAX_VALUE",
                                        Double.MAX_VALUE,
                                        dist.getDenominatorDegreesOfFreedom(),
                                        0.0);
                     }

 @Test
                    public void testGetDenominatorDegreesOfFreedomReturnsCorrectValue2() {
                        // Arrange
                        double expectedValue = 5.0;
                        FDistribution fDist = new FDistribution(2.0, expectedValue);
                        
                        // Act
                        double actualValue = fDist.getDenominatorDegreesOfFreedom();
                        
                        // Assert
                        assertEquals("Denominator degrees of freedom should match constructor value", 
                                    expectedValue, actualValue, 0.0001);
                    }

 @Test
                    public void testGetDenominatorDegreesOfFreedomWithLargeValue() {
                        // Arrange
                        double expectedValue = Double.MAX_VALUE;
                        FDistribution fDist = new FDistribution(1.0, expectedValue);
                        
                        // Act
                        double actualValue = fDist.getDenominatorDegreesOfFreedom();
                        
                        // Assert
                        assertEquals("Should handle maximum double value correctly",
                                    expectedValue, actualValue, 0.0);
                    }

 @Test
                    public void testGetDenominatorDegreesOfFreedomWithSmallValue() {
                        // Arrange
                        double expectedValue = Double.MIN_VALUE;
                        FDistribution fDist = new FDistribution(1.0, expectedValue);
                        
                        // Act
                        double actualValue = fDist.getDenominatorDegreesOfFreedom();
                        
                        // Assert
                        assertEquals("Should handle minimum double value correctly",
                                    expectedValue, actualValue, 0.0);
                    }

 @Test
                   public void testGetDenominatorDegreesOfFreedom1() {
                       // Test normal case
                       FDistribution dist1 = new FDistribution(5.0, 10.0);
                       assertEquals(10.0, dist1.getDenominatorDegreesOfFreedom(), 0.0001);
                       
                       // Test boundary case with very small value
                       FDistribution dist2 = new FDistribution(1.0, Double.MIN_VALUE);
                       assertEquals(Double.MIN_VALUE, dist2.getDenominatorDegreesOfFreedom(), 0.0);
                       
                       // Test case to catch the mutant - POSITIVE_INFINITY
                       FDistribution dist3 = new FDistribution(1.0, Double.POSITIVE_INFINITY);
                       assertEquals(Double.POSITIVE_INFINITY, dist3.getDenominatorDegreesOfFreedom(), 0.0);
                       
                       // Test large finite value
                       FDistribution dist4 = new FDistribution(1.0, Double.MAX_VALUE);
                       assertEquals(Double.MAX_VALUE, dist4.getDenominatorDegreesOfFreedom(), 0.0);
                   }

 @Test
                  public void testGetDenominatorDegreesOfFreedomReturnsCorrectValue3() {
                      // Arrange
                      double numeratorDof = 5.0;
                      double denominatorDof = 10.0;
                      FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
                      
                      // Act
                      double result = fDist.getDenominatorDegreesOfFreedom();
                      
                      // Assert
                      assertEquals("Denominator degrees of freedom should match constructor argument", 
                                   denominatorDof, result, 0.0001);
                      
                      // Additional assertion to specifically catch the negative infinity mutant
                      assertNotEquals("Denominator degrees of freedom should not be negative infinity",
                                     Double.NEGATIVE_INFINITY, result, 0.0);
                  }

 @Test
                  public void testGetDenominatorDegreesOfFreedomWithLargeValue1() {
                      // Arrange
                      double numeratorDof = 5.0;
                      double largeDenominatorDof = 1.0e300; // Very large but finite value
                      FDistribution fDist = new FDistribution(numeratorDof, largeDenominatorDof);
                      
                      // Act
                      double result = fDist.getDenominatorDegreesOfFreedom();
                      
                      // Assert
                      assertEquals("Should handle large denominator values correctly",
                                   largeDenominatorDof, result, 0.0001);
                      assertTrue("Result should be finite", Double.isFinite(result));
                  }

 @Test
                 public void testGetDenominatorDegreesOfFreedomReturnsActualValueNotMaxValue() {
                     // Test with normal value
                     double testDenominator = 5.0;
                     FDistribution dist = new FDistribution(2.0, testDenominator);
                     assertEquals("Getter should return actual denominator value", 
                                 testDenominator, 
                                 dist.getDenominatorDegreesOfFreedom(), 
                                 0.0001);
                     
                     // Test with very large value (but still less than Double.MAX_VALUE)
                     double largeDenominator = 1.0E100;
                     FDistribution distLarge = new FDistribution(2.0, largeDenominator);
                     assertEquals("Getter should return actual large denominator value",
                                 largeDenominator,
                                 distLarge.getDenominatorDegreesOfFreedom(),
                                 0.0001);
                     
                     // Test with smallest possible positive value
                     double smallDenominator = Double.MIN_VALUE;
                     FDistribution distSmall = new FDistribution(2.0, smallDenominator);
                     assertEquals("Getter should return actual small denominator value",
                                 smallDenominator,
                                 distSmall.getDenominatorDegreesOfFreedom(),
                                 0.0001);
                 }

 @Test
           public void testGetDenominatorDegreesOfFreedomPositiveValue() {
               double numeratorDof = 5.0;
               double denominatorDof = 10.0; // Our positive test value
               FDistribution fDistribution = new FDistribution(numeratorDof, denominatorDof);
               assertEquals("Should return exact positive value", 
                   denominatorDof, 
                   fDistribution.getDenominatorDegreesOfFreedom(), 
                   0.0001);
           }

 @Test
           public void testGetDenominatorDegreesOfFreedomNegativeValue() throws Exception {
               // Create FDistribution instance with valid initial values
               FDistribution fDistribution = new FDistribution(1.0, 1.0);
               
               // Define negative test value
               double negativeValue = -5.0;
               
               // Use reflection to set negative value to test the mutant
               Field field = FDistribution.class.getDeclaredField("denominatorDegreesOfFreedom");
               field.setAccessible(true);
               field.set(fDistribution, negativeValue);
               
               // Test would fail if mutant is present (would return 5.0 instead of -5.0)
               assertEquals("Should return exact negative value when field is set via reflection", 
                   negativeValue, 
                   fDistribution.getDenominatorDegreesOfFreedom(), 
                   0.0001);
           }

 @Test
           public void testGetDenominatorDegreesOfFreedom2() {
               // Test with typical value
               double testValue1 = 5.0;
               FDistribution dist1 = new FDistribution(2.0, testValue1);
               assertEquals("Should return exact denominator degrees of freedom", 
                           testValue1, 
                           dist1.getDenominatorDegreesOfFreedom(), 
                           0.0);
               
               // Test with different value
               double testValue2 = 10.5;
               FDistribution dist2 = new FDistribution(3.0, testValue2);
               assertEquals("Should return exact denominator degrees of freedom", 
                           testValue2, 
                           dist2.getDenominatorDegreesOfFreedom(), 
                           0.0);
               
               // Test with edge case (smallest valid value)
               double testValue3 = Double.MIN_VALUE;
               FDistribution dist3 = new FDistribution(1.0, testValue3);
               assertEquals("Should handle smallest possible positive value",
                           testValue3,
                           dist3.getDenominatorDegreesOfFreedom(),
                           0.0);
               
               // Test with large value
               double testValue4 = Double.MAX_VALUE;
               FDistribution dist4 = new FDistribution(1.0, testValue4);
               assertEquals("Should handle largest possible value",
                           testValue4,
                           dist4.getDenominatorDegreesOfFreedom(),
                           0.0);
           }

 @Test
          public void testGetDenominatorDegreesOfFreedomReturnsCorrectValue4() {
              // Test with normal positive value
              double expectedDof = 5.0;
              FDistribution dist = new FDistribution(3.0, expectedDof);
              double actualDof = dist.getDenominatorDegreesOfFreedom();
              assertEquals("Denominator degrees of freedom should match constructor value", 
                          expectedDof, actualDof, 0.0001);
              
              // Test with another positive value
              expectedDof = 10.5;
              dist = new FDistribution(2.0, expectedDof);
              actualDof = dist.getDenominatorDegreesOfFreedom();
              assertEquals("Denominator degrees of freedom should match constructor value", 
                          expectedDof, actualDof, 0.0001);
              
              // Test with large value (not infinity)
              expectedDof = Double.MAX_VALUE;
              dist = new FDistribution(1.0, expectedDof);
              actualDof = dist.getDenominatorDegreesOfFreedom();
              assertEquals("Denominator degrees of freedom should match constructor value even for large numbers", 
                          expectedDof, actualDof, 0.0001);
          }

 @Test
          public void testGetDenominatorDegreesOfFreedomNotNegativeInfinity() {
              double expectedDof = 7.0;
              FDistribution dist = new FDistribution(3.0, expectedDof);
              double actualDof = dist.getDenominatorDegreesOfFreedom();
              
              // Explicit check for negative infinity
              assertNotEquals("Denominator degrees of freedom should not be negative infinity", 
                             Double.NEGATIVE_INFINITY, actualDof, 0.0001);
              
              // Also check it's not positive infinity
              assertNotEquals("Denominator degrees of freedom should not be positive infinity", 
                             Double.POSITIVE_INFINITY, actualDof, 0.0001);
          }

 @Test
         public void testGetDenominatorDegreesOfFreedomReturnsCorrectValue5() {
             // Test with typical value
             double testDenominator = 5.0;
             FDistribution dist = new FDistribution(2.0, testDenominator);
             assertEquals("Getter should return exact denominator degrees of freedom", 
                         testDenominator, 
                         dist.getDenominatorDegreesOfFreedom(), 
                         0.0);
             
             // Test with large value (but not MAX_VALUE)
             double largeDenominator = 1e100;
             FDistribution distLarge = new FDistribution(2.0, largeDenominator);
             assertEquals("Getter should return exact denominator degrees of freedom even for large values",
                         largeDenominator,
                         distLarge.getDenominatorDegreesOfFreedom(),
                         0.0);
             
             // Test with small positive value
             double smallDenominator = Double.MIN_VALUE;
             FDistribution distSmall = new FDistribution(2.0, smallDenominator);
             assertEquals("Getter should return exact denominator degrees of freedom even for small values",
                         smallDenominator,
                         distSmall.getDenominatorDegreesOfFreedom(),
                         0.0);
         }

 @Test
        public void testGetDenominatorDegreesOfFreedomReturnsCorrectValue6() {
            // Arrange
            double numeratorDof = 5.0;
            double denominatorDof = 10.0;
            FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
            
            // Act
            double result = fDist.getDenominatorDegreesOfFreedom();
            
            // Assert
            assertEquals("Should return the exact denominator degrees of freedom", 
                        denominatorDof, result, 0.0001);
            assertFalse("Should not return NaN", Double.isNaN(result));
        }

 @Test
        public void testGetDenominatorDegreesOfFreedomWithDifferentValues() {
            // Arrange
            double numeratorDof = 3.0;
            double denominatorDof = 7.5;
            FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
            
            // Act
            double result = fDist.getDenominatorDegreesOfFreedom();
            
            // Assert
            assertEquals("Should return the exact denominator degrees of freedom", 
                        denominatorDof, result, 0.0001);
            assertFalse("Should not return NaN", Double.isNaN(result));
        }

 @Test
       public void testGetDenominatorDegreesOfFreedomReturnsCorrectValue7() {
           // Test with normal finite value
           double testDenominatorDF = 5.0;
           FDistribution dist = new FDistribution(2.0, testDenominatorDF);
           assertEquals("Denominator degrees of freedom should match constructor argument",
                        testDenominatorDF, dist.getDenominatorDegreesOfFreedom(), 0.0001);
           
           // Test with large finite value
           double largeValue = 1e300;
           FDistribution distLarge = new FDistribution(2.0, largeValue);
           assertEquals("Large denominator degrees of freedom should be preserved",
                        largeValue, distLarge.getDenominatorDegreesOfFreedom(), 0.0001);
           
           // Test with infinite value (edge case)
           FDistribution distInf = new FDistribution(2.0, Double.POSITIVE_INFINITY);
           assertEquals("Infinite denominator degrees of freedom should be preserved",
                        Double.POSITIVE_INFINITY, distInf.getDenominatorDegreesOfFreedom(), 0.0);
       }

 @Test
       public void testGetDenominatorDegreesOfFreedomNeverReturnsZero() {
           // Test with very small positive value
           double smallValue = Double.MIN_VALUE;
           FDistribution distSmall = new FDistribution(2.0, smallValue);
           assertNotEquals("Denominator degrees of freedom should never return 0",
                           0.0, distSmall.getDenominatorDegreesOfFreedom(), 0.0);
           
           // Test with normal value to ensure no regression
           FDistribution distNormal = new FDistribution(2.0, 10.0);
           assertNotEquals("Normal denominator degrees of freedom should not return 0",
                           0.0, distNormal.getDenominatorDegreesOfFreedom(), 0.0);
       }

 @Test
      public void testGetDenominatorDegreesOfFreedomReturnsCorrectValue8() {
          // Arrange
          double numeratorDof = 5.0;
          double denominatorDof = 10.0;
          FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
          
          // Act
          double result = fDist.getDenominatorDegreesOfFreedom();
          
          // Assert
          assertEquals("Denominator degrees of freedom should match constructor argument",
                       denominatorDof, result, 0.0001);
          assertFalse("Should not return negative infinity", 
                     Double.isInfinite(result) && result < 0);
      }

 @Test
     public void testGetDenominatorDegreesOfFreedom3() {
         // Test with normal finite value
         double finiteValue = 10.5;
         FDistribution distFinite = new FDistribution(5.0, finiteValue);
         assertEquals("Finite denominator degrees of freedom should be returned as-is",
                     finiteValue, distFinite.getDenominatorDegreesOfFreedom(), 0.0);
         
         // Test with infinity value
         FDistribution distInfinite = new FDistribution(5.0, Double.POSITIVE_INFINITY);
         assertEquals("Infinite denominator degrees of freedom should be returned as infinity",
                     Double.POSITIVE_INFINITY, distInfinite.getDenominatorDegreesOfFreedom(), 0.0);
     }

}
