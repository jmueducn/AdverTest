package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                        public void testAddValue_WithComparableObject_ShouldDelegate() {
                                                                                                                            // Setup
                                                                                                                            Frequency frequency = new Frequency();
                                                                                                                            Comparable<String> comparableString = "test";
                                                                                                                            
                                                                                                                            // This test verifies the method delegates to addValue(Comparable) when input is Comparable
                                                                                                                            // We can't easily verify the delegation, but we can check no exception is thrown
                                                                                                                            // and the value is added to the frequency table
                                                                                                                            frequency.addValue(comparableString);
                                                                                                                            
                                                                                                                            // Verify the value was added by checking count
                                                                                                                            assertEquals(1, frequency.getCount(comparableString));
                                                                                                                        }

    @Test
                                                                                                                        public void testAddValue_WithNonComparableObject_ShouldThrowException() {
                                                                                                                            // Setup
                                                                                                                            Frequency frequency = new Frequency();
                                                                                                                            Object nonComparable = new Object();
                                                                                                                            
                                                                                                                            // Expect exception
                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                            thrown.expectMessage("Object must implement Comparable");
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            frequency.addValue(nonComparable);
                                                                                                                        }

    @Test
                                                                                                                        public void testAddValue_WithNull_ShouldThrowException() {
                                                                                                                            // Setup
                                                                                                                            Frequency frequency = new Frequency();
                                                                                                                            
                                                                                                                            // Expect exception
                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                            thrown.expectMessage("Object must implement Comparable");
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            frequency.addValue(null);
                                                                                                                        }

    @Test
                                                                                                                        public void testAddValue_WithPrimitiveWrapper_ShouldDelegate() {
                                                                                                                            // Setup
                                                                                                                            Frequency frequency = new Frequency();
                                                                                                                            Integer integerValue = 42;
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            frequency.addValue(integerValue);
                                                                                                                            
                                                                                                                            // Verify
                                                                                                                            assertEquals(1, frequency.getCount(integerValue));
                                                                                                                        }

    @Test
                                                                                                                        public void testAddValue_WithComparatorConstructor_ShouldWorkWithComparable() {
                                                                                                                            // Setup
                                                                                                                            Comparator<String> reverseComparator = Comparator.reverseOrder();
                                                                                                                            Frequency frequency = new Frequency(reverseComparator);
                                                                                                                            Comparable<String> comparableString = "test";
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            frequency.addValue(comparableString);
                                                                                                                            
                                                                                                                            // Verify
                                                                                                                            assertEquals(1, frequency.getCount(comparableString));
                                                                                                                        }

    @Test
                                                                                                                        public void testAddValue_MixedTypesWithCustomComparator() {
                                                                                                                            // Test with custom comparator that can handle different types
                                                                                                                            Comparator<Object> comparator = (o1, o2) -> {
                                                                                                                                if (o1 instanceof Long && o2 instanceof Long) {
                                                                                                                                    return ((Long)o1).compareTo((Long)o2);
                                                                                                                                }
                                                                                                                                if (o1 instanceof String && o2 instanceof String) {
                                                                                                                                    return ((String)o1).compareTo((String)o2);
                                                                                                                                }
                                                                                                                                return 0;
                                                                                                                            };
                                                                                                                            
                                                                                                                            Frequency customFrequency = new Frequency(comparator);
                                                                                                                            
                                                                                                                            // These would normally throw ClassCastException without custom comparator
                                                                                                                            customFrequency.addValue(100L);
                                                                                                                            customFrequency.addValue("test");
                                                                                                                            
                                                                                                                            assertEquals(1L, customFrequency.getCount(100L));
                                                                                                                            assertEquals(1L, customFrequency.getCount("test"));
                                                                                                                        }

    @Test
                                                                                                                        public void testAddValue_WithCustomComparator() {
                                                                                                                            // Test with a custom comparator that treats all values as equal
                                                                                                                            Frequency customFrequency = new Frequency(new Comparator() {
                                                                                                                                @Override
                                                                                                                                public int compare(Object o1, Object o2) {
                                                                                                                                    return 0;
                                                                                                                                }
                                                                                                                            });
                                                                                                                            
                                                                                                                            customFrequency.addValue(1L);
                                                                                                                            customFrequency.addValue(2L);
                                                                                                                            customFrequency.addValue(3L);
                                                                                                                            
                                                                                                                            // All values should be counted as the same
                                                                                                                            assertEquals(3L, customFrequency.getCount(1L));
                                                                                                                            assertEquals(3L, customFrequency.getCount(2L));
                                                                                                                            assertEquals(3L, customFrequency.getCount(3L));
                                                                                                                            assertEquals(3L, customFrequency.getSumFreq());
                                                                                                                        }

    @Test
                                                                                                                        public void testAddValue_WithComparator() {
                                                                                                                            // Test with custom comparator (case insensitive string comparison)
                                                                                                                            Frequency caseInsensitiveFrequency = new Frequency(String.CASE_INSENSITIVE_ORDER);
                                                                                                                            caseInsensitiveFrequency.addValue("Test");
                                                                                                                            caseInsensitiveFrequency.addValue("test");
                                                                                                                            caseInsensitiveFrequency.addValue("TEST");
                                                                                                                            
                                                                                                                            assertEquals(3, caseInsensitiveFrequency.getCount("test"));
                                                                                                                            assertEquals(3, caseInsensitiveFrequency.getSumFreq());
                                                                                                                        }

    @Test
                                                                                                                        public void testAddValue_Long_WithCustomComparator() {
                                                                                                                            // Create a frequency with custom comparator (reverse order)
                                                                                                                            Comparator<Long> reverseComparator = Comparator.reverseOrder();
                                                                                                                            Frequency customFrequency = new Frequency(reverseComparator);
                                                                                                                            
                                                                                                                            // Add values
                                                                                                                            customFrequency.addValue(5L);
                                                                                                                            customFrequency.addValue(10L);
                                                                                                                            customFrequency.addValue(5L);
                                                                                                                            
                                                                                                                            // Verify counts
                                                                                                                            assertEquals(2, customFrequency.getCount(5L));
                                                                                                                            assertEquals(1, customFrequency.getCount(10L));
                                                                                                                            assertEquals(3, customFrequency.getSumFreq());
                                                                                                                        }

    @Test
                                                                                                                        public void testAddValue_Char_WithCustomComparator() {
                                                                                                                            // Test with custom comparator (case insensitive)
                                                                                                                            Frequency caseInsensitiveFrequency = new Frequency(String.CASE_INSENSITIVE_ORDER);
                                                                                                                            caseInsensitiveFrequency.addValue('A');
                                                                                                                            caseInsensitiveFrequency.addValue('a');
                                                                                                                            
                                                                                                                            assertEquals(2, caseInsensitiveFrequency.getCount('A'));
                                                                                                                            assertEquals(2, caseInsensitiveFrequency.getCount('a'));
                                                                                                                            assertEquals(2, caseInsensitiveFrequency.getSumFreq());
                                                                                                                        }

    @Test
                                                                                                                public void testAddValue_WithCustomComparable_ShouldDelegate() {
                                                                                                                    // Setup
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    
                                                                                                                    // Define a simple custom Comparable implementation
                                                                                                                    class CustomComparable implements Comparable<CustomComparable> {
                                                                                                                        private int value;
                                                                                                                        
                                                                                                                        public CustomComparable(int value) {
                                                                                                                            this.value = value;
                                                                                                                        }
                                                                                                                        
                                                                                                                        @Override
                                                                                                                        public int compareTo(CustomComparable o) {
                                                                                                                            return Integer.compare(this.value, o.value);
                                                                                                                        }
                                                                                                                    }
                                                                                                                    
                                                                                                                    Comparable<CustomComparable> customComparable = new CustomComparable(10);
                                                                                                                    
                                                                                                                    // Execute
                                                                                                                    frequency.addValue(customComparable);
                                                                                                                    
                                                                                                                    // Verify
                                                                                                                    assertEquals(1, frequency.getCount(customComparable));
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_Integer() {
                                                                                                                    // Initialize frequency object
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    
                                                                                                                    // Test basic Integer addition
                                                                                                                    frequency.addValue(5);
                                                                                                                    assertEquals(1L, frequency.getCount(5));
                                                                                                                    
                                                                                                                    // Test multiple additions
                                                                                                                    frequency.addValue(5);
                                                                                                                    assertEquals(2L, frequency.getCount(5));
                                                                                                                    
                                                                                                                    // Test different Integer
                                                                                                                    frequency.addValue(10);
                                                                                                                    assertEquals(1L, frequency.getCount(10));
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_Long() {
                                                                                                                    // Create new Frequency instance
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    
                                                                                                                    // Test basic Long addition
                                                                                                                    frequency.addValue(1000L);
                                                                                                                    assertEquals(1L, frequency.getCount(1000L));
                                                                                                                    
                                                                                                                    // Test multiple additions
                                                                                                                    frequency.addValue(1000L);
                                                                                                                    frequency.addValue(1000L);
                                                                                                                    assertEquals(3L, frequency.getCount(1000L));
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_String() {
                                                                                                                    // Create new Frequency object for testing
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    
                                                                                                                    // Test with String (Comparable)
                                                                                                                    frequency.addValue("test");
                                                                                                                    assertEquals(1L, frequency.getCount("test"));
                                                                                                                    
                                                                                                                    frequency.addValue("test");
                                                                                                                    assertEquals(2L, frequency.getCount("test"));
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_IntegerConversionToLong() {
                                                                                                                    // Create a new Frequency instance
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    
                                                                                                                    // Verify Integer is converted to Long in the map
                                                                                                                    frequency.addValue(Integer.valueOf(42));
                                                                                                                    assertEquals(1L, frequency.getCount(42L)); // Check with Long
                                                                                                                    assertEquals(1L, frequency.getCount(42));  // Check with Integer
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_EdgeCases() {
                                                                                                                    // Initialize frequency object
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    
                                                                                                                    // Test min/max values
                                                                                                                    frequency.addValue(Integer.MIN_VALUE);
                                                                                                                    frequency.addValue(Integer.MAX_VALUE);
                                                                                                                    frequency.addValue(Long.MIN_VALUE);
                                                                                                                    frequency.addValue(Long.MAX_VALUE);
                                                                                                                    
                                                                                                                    // Verify counts - note we need to use Long objects for comparison
                                                                                                                    assertEquals(1L, frequency.getCount((long)Integer.MIN_VALUE));
                                                                                                                    assertEquals(1L, frequency.getCount((long)Integer.MAX_VALUE));
                                                                                                                    assertEquals(1L, frequency.getCount(Long.MIN_VALUE));
                                                                                                                    assertEquals(1L, frequency.getCount(Long.MAX_VALUE));
                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                public void testAddValue_NonComparableThrowsException() {
                                                                                                                    // Test with non-comparable object
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    Object nonComparable = new Object();
                                                                                                                    
                                                                                                                    try {
                                                                                                                        frequency.addValue(nonComparable);
                                                                                                                        fail("Expected IllegalArgumentException");
                                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                                        assertEquals("Value not comparable to existing values.", e.getMessage());
                                                                                                                        throw e;
                                                                                                                    }
                                                                                                                }

    @Test(expected = NullPointerException.class)
                                                                                                                public void testAddValue_NullInput() {
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    frequency.addValue(null);
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_CharType() {
                                                                                                                    // Test char type which is autoboxed to Character
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    frequency.addValue('a');
                                                                                                                    assertEquals(1L, frequency.getCount('a'));
                                                                                                                    
                                                                                                                    frequency.addValue('a');
                                                                                                                    assertEquals(2L, frequency.getCount('a'));
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_SingleValue() {
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    frequency.addValue(5L);
                                                                                                                    assertEquals(1L, frequency.getCount(5L));
                                                                                                                    assertEquals(1L, frequency.getSumFreq());
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_MultipleDifferentValues() {
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    frequency.addValue(1L);
                                                                                                                    frequency.addValue(2L);
                                                                                                                    frequency.addValue(3L);
                                                                                                                    
                                                                                                                    assertEquals(1L, frequency.getCount(1L));
                                                                                                                    assertEquals(1L, frequency.getCount(2L));
                                                                                                                    assertEquals(1L, frequency.getCount(3L));
                                                                                                                    assertEquals(3L, frequency.getSumFreq());
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_MultipleSameValues() {
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    frequency.addValue(10L);
                                                                                                                    frequency.addValue(10L);
                                                                                                                    frequency.addValue(10L);
                                                                                                                    
                                                                                                                    assertEquals(3L, frequency.getCount(10L));
                                                                                                                    assertEquals(3L, frequency.getSumFreq());
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_EdgeCases1() {
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    frequency.addValue(Long.MIN_VALUE);
                                                                                                                    frequency.addValue(Long.MAX_VALUE);
                                                                                                                    
                                                                                                                    assertEquals(1L, frequency.getCount(Long.MIN_VALUE));
                                                                                                                    assertEquals(1L, frequency.getCount(Long.MAX_VALUE));
                                                                                                                    assertEquals(2L, frequency.getSumFreq());
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_ZeroValue() {
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    frequency.addValue(0L);
                                                                                                                    frequency.addValue(0L);
                                                                                                                    
                                                                                                                    assertEquals(2L, frequency.getCount(0L));
                                                                                                                    assertEquals(2L, frequency.getSumFreq());
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_NegativeValues() {
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    frequency.addValue(-5L);
                                                                                                                    frequency.addValue(-10L);
                                                                                                                    frequency.addValue(-5L);
                                                                                                                    
                                                                                                                    assertEquals(2L, frequency.getCount(-5L));
                                                                                                                    assertEquals(1L, frequency.getCount(-10L));
                                                                                                                    assertEquals(3L, frequency.getSumFreq());
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_Integer1() {
                                                                                                                    // Test typical Integer values
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    frequency.addValue(5);
                                                                                                                    frequency.addValue(10);
                                                                                                                    frequency.addValue(5); // duplicate
                                                                                                                    
                                                                                                                    assertEquals(2, frequency.getCount(5));
                                                                                                                    assertEquals(1, frequency.getCount(10));
                                                                                                                    assertEquals(3, frequency.getSumFreq());
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_Long1() {
                                                                                                                    // Test typical Long values
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    frequency.addValue(1000L);
                                                                                                                    frequency.addValue(2000L);
                                                                                                                    frequency.addValue(1000L); // duplicate
                                                                                                                    
                                                                                                                    assertEquals(2, frequency.getCount(1000L));
                                                                                                                    assertEquals(1, frequency.getCount(2000L));
                                                                                                                    assertEquals(3, frequency.getSumFreq());
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_Char() {
                                                                                                                    // Initialize frequency object
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    
                                                                                                                    // Test character values
                                                                                                                    frequency.addValue('a');
                                                                                                                    frequency.addValue('b');
                                                                                                                    frequency.addValue('a'); // duplicate
                                                                                                                    
                                                                                                                    assertEquals(2, frequency.getCount('a'));
                                                                                                                    assertEquals(1, frequency.getCount('b'));
                                                                                                                    assertEquals(3, frequency.getSumFreq());
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_Object() {
                                                                                                                    // Initialize Frequency object
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    
                                                                                                                    // Test with various object types
                                                                                                                    frequency.addValue("test");
                                                                                                                    frequency.addValue(Boolean.TRUE);
                                                                                                                    frequency.addValue("test"); // duplicate
                                                                                                                    
                                                                                                                    assertEquals(2, frequency.getCount("test"));
                                                                                                                    assertEquals(1, frequency.getCount(Boolean.TRUE));
                                                                                                                    assertEquals(3, frequency.getSumFreq());
                                                                                                                }

    @Test
                                                                                                                public void testAddValue_EdgeCases2() {
                                                                                                                    // Test edge cases
                                                                                                                    Frequency frequency = new Frequency();
                                                                                                                    frequency.addValue(0);
                                                                                                                    frequency.addValue(Integer.MAX_VALUE);
                                                                                                                    frequency.addValue(Integer.MIN_VALUE);
                                                                                                                    frequency.addValue(0); // duplicate
                                                                                                                    
                                                                                                                    assertEquals(2, frequency.getCount(0));
                                                                                                                    assertEquals(1, frequency.getCount(Integer.MAX_VALUE));
                                                                                                                    assertEquals(1, frequency.getCount(Integer.MIN_VALUE));
                                                                                                                    assertEquals(4, frequency.getSumFreq());
                                                                                                                }

    @Test
                                                                                                            public void testAddValue_Null() {
                                                                                                                org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                                                org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                                                                                
                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                thrown.expectMessage("Value cannot be null");
                                                                                                                frequency.addValue(null);
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_MixedTypes() {
                                                                                                                // Create new Frequency instance
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                
                                                                                                                // Test mixing different types
                                                                                                                frequency.addValue(1);
                                                                                                                frequency.addValue(1L);
                                                                                                                frequency.addValue('1');
                                                                                                                frequency.addValue("1");
                                                                                                                
                                                                                                                // Each should be treated as distinct
                                                                                                                assertEquals(1, frequency.getCount(1));
                                                                                                                assertEquals(1, frequency.getCount(1L));
                                                                                                                assertEquals(1, frequency.getCount('1'));
                                                                                                                assertEquals(1, frequency.getCount("1"));
                                                                                                                assertEquals(4, frequency.getSumFreq());
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_AfterClear() {
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                frequency.addValue(10);
                                                                                                                frequency.addValue(20);
                                                                                                                frequency.clear();
                                                                                                                
                                                                                                                // Add values after clear
                                                                                                                frequency.addValue(30);
                                                                                                                frequency.addValue(30);
                                                                                                                
                                                                                                                assertEquals(0, frequency.getCount(10));
                                                                                                                assertEquals(2, frequency.getCount(30));
                                                                                                                assertEquals(2, frequency.getSumFreq());
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_Long_AddsValueToFrequencyTable() {
                                                                                                                // Create frequency table for testing
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                
                                                                                                                // Test adding a single value
                                                                                                                frequency.addValue(5L);
                                                                                                                assertEquals(1, frequency.getCount(5L));
                                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                                                
                                                                                                                // Test adding the same value multiple times
                                                                                                                frequency.addValue(5L);
                                                                                                                frequency.addValue(5L);
                                                                                                                assertEquals(3, frequency.getCount(5L));
                                                                                                                assertEquals(3, frequency.getSumFreq());
                                                                                                                
                                                                                                                // Test adding different values
                                                                                                                frequency.addValue(10L);
                                                                                                                assertEquals(1, frequency.getCount(10L));
                                                                                                                assertEquals(4, frequency.getSumFreq());
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_Long_EdgeCases() {
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                
                                                                                                                // Test with zero
                                                                                                                frequency.addValue(0L);
                                                                                                                assertEquals(1, frequency.getCount(0L));
                                                                                                                
                                                                                                                // Test with Long.MAX_VALUE
                                                                                                                frequency.addValue(Long.MAX_VALUE);
                                                                                                                assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                                                                                                
                                                                                                                // Test with Long.MIN_VALUE
                                                                                                                frequency.addValue(Long.MIN_VALUE);
                                                                                                                assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                                                                                                
                                                                                                                assertEquals(3, frequency.getSumFreq());
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_Long_AfterClear() {
                                                                                                                // Create frequency object
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                
                                                                                                                // Add some values first
                                                                                                                frequency.addValue(1L);
                                                                                                                frequency.addValue(2L);
                                                                                                                assertEquals(2, frequency.getSumFreq());
                                                                                                                
                                                                                                                // Clear and verify
                                                                                                                frequency.clear();
                                                                                                                assertEquals(0, frequency.getSumFreq());
                                                                                                                
                                                                                                                // Add new values after clear
                                                                                                                frequency.addValue(3L);
                                                                                                                assertEquals(1, frequency.getCount(3L));
                                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_Long_VerifyTreeMapStructure() {
                                                                                                                // Create frequency instance
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                
                                                                                                                // Add values in random order
                                                                                                                frequency.addValue(5L);
                                                                                                                frequency.addValue(2L);
                                                                                                                frequency.addValue(8L);
                                                                                                                frequency.addValue(2L);
                                                                                                                
                                                                                                                // Verify counts and order (should be natural ordering)
                                                                                                                assertEquals(2, frequency.getCount(2L));
                                                                                                                assertEquals(1, frequency.getCount(5L));
                                                                                                                assertEquals(1, frequency.getCount(8L));
                                                                                                                assertEquals(4, frequency.getSumFreq());
                                                                                                                
                                                                                                                // Verify cumulative frequencies (natural ordering)
                                                                                                                assertEquals(2, frequency.getCumFreq(2L));
                                                                                                                assertEquals(3, frequency.getCumFreq(5L));
                                                                                                                assertEquals(4, frequency.getCumFreq(8L));
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_Char_AddSingleCharacter() {
                                                                                                                // Test adding a single character
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                frequency.addValue('a');
                                                                                                                assertEquals(1, frequency.getCount('a'));
                                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_Char_AddMultipleSameCharacters() {
                                                                                                                // Test adding the same character multiple times
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                frequency.addValue('b');
                                                                                                                frequency.addValue('b');
                                                                                                                frequency.addValue('b');
                                                                                                                
                                                                                                                assertEquals(3, frequency.getCount('b'));
                                                                                                                assertEquals(3, frequency.getSumFreq());
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_Char_AddDifferentCharacters() {
                                                                                                                // Initialize frequency object
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                
                                                                                                                // Test adding different characters
                                                                                                                frequency.addValue('c');
                                                                                                                frequency.addValue('d');
                                                                                                                frequency.addValue('e');
                                                                                                                
                                                                                                                assertEquals(1, frequency.getCount('c'));
                                                                                                                assertEquals(1, frequency.getCount('d'));
                                                                                                                assertEquals(1, frequency.getCount('e'));
                                                                                                                assertEquals(3, frequency.getSumFreq());
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_Char_AddSpecialCharacters() {
                                                                                                                // Test adding special characters
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                frequency.addValue('@');
                                                                                                                frequency.addValue(' ');
                                                                                                                frequency.addValue('\n');
                                                                                                                
                                                                                                                assertEquals(1, frequency.getCount('@'));
                                                                                                                assertEquals(1, frequency.getCount(' '));
                                                                                                                assertEquals(1, frequency.getCount('\n'));
                                                                                                                assertEquals(3, frequency.getSumFreq());
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_Char_AddUpperCaseAndLowerCase() {
                                                                                                                // Test case sensitivity
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                frequency.addValue('A');
                                                                                                                frequency.addValue('a');
                                                                                                                
                                                                                                                assertEquals(1, frequency.getCount('A'));
                                                                                                                assertEquals(1, frequency.getCount('a'));
                                                                                                                assertEquals(2, frequency.getSumFreq());
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_Char_AddDigitCharacters() {
                                                                                                                // Test adding digit characters
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                frequency.addValue('0');
                                                                                                                frequency.addValue('9');
                                                                                                                
                                                                                                                assertEquals(1, frequency.getCount('0'));
                                                                                                                assertEquals(1, frequency.getCount('9'));
                                                                                                                assertEquals(2, frequency.getSumFreq());
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_Char_AfterClear() {
                                                                                                                // Test adding after clear
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                frequency.addValue('x');
                                                                                                                frequency.clear();
                                                                                                                frequency.addValue('y');
                                                                                                                
                                                                                                                assertEquals(0, frequency.getCount('x'));
                                                                                                                assertEquals(1, frequency.getCount('y'));
                                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                                            }

    @Test
                                                                                                            public void testAddValue_Char_CheckToString() {
                                                                                                                // Test if toString reflects the added values
                                                                                                                Frequency frequency = new Frequency();
                                                                                                                frequency.addValue('z');
                                                                                                                frequency.addValue('z');
                                                                                                                frequency.addValue('w');
                                                                                                                
                                                                                                                String result = frequency.toString();
                                                                                                                assertTrue(result.contains("z"));
                                                                                                                assertTrue(result.contains("w"));
                                                                                                                assertTrue(result.contains("2")); // count for 'z'
                                                                                                                assertTrue(result.contains("1")); // count for 'w'
                                                                                                            }

    @Test
                                                                                                        public void testAddValue_AfterClear1() {
                                                                                                            org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                                                                            frequency.addValue(10);
                                                                                                            frequency.addValue(20);
                                                                                                            frequency.clear();
                                                                                                            
                                                                                                            // Add values after clear
                                                                                                            frequency.addValue(30);
                                                                                                            frequency.addValue(30);
                                                                                                            
                                                                                                            assertEquals(0, frequency.getCount(10));
                                                                                                            assertEquals(2, frequency.getCount(30));
                                                                                                            assertEquals(2, frequency.getSumFreq());
                                                                                                        }

    @Test
                                                                                                        public void testAddValueWithNullShouldThrowNullPointerException() {
                                                                                                            Frequency frequency = new Frequency();
                                                                                                            
                                                                                                            // Expect NullPointerException to be thrown
                                                                                                            thrown.expect(NullPointerException.class);
                                                                                                            
                                                                                                            // Call method with null input
                                                                                                            frequency.addValue((Object) null);
                                                                                                        }

    @Test(expected = NullPointerException.class)
                                                                                                        public void testAddValueWithNullShouldThrowException() {
                                                                                                            Frequency frequency = new Frequency();
                                                                                                            // This should throw NullPointerException in original code
                                                                                                            // but would pass silently in mutated code
                                                                                                            frequency.addValue((Object)null);
                                                                                                        }

    @Test
                                                                                                        public void testAddValueWithNonNullComparable() {
                                                                                                            Frequency frequency = new Frequency();
                                                                                                            Long testValue = 123L;
                                                                                                            
                                                                                                            // Add value and verify it was counted
                                                                                                            frequency.addValue(testValue);
                                                                                                            assertEquals(1L, frequency.getCount(testValue));
                                                                                                            
                                                                                                            // Add same value again and verify count increases
                                                                                                            frequency.addValue(testValue);
                                                                                                            assertEquals(2L, frequency.getCount(testValue));
                                                                                                        }

    @Test
                                                                                                        public void testAddValueWithNonComparable() {
                                                                                                            Frequency frequency = new Frequency();
                                                                                                            Object nonComparable = new Object();
                                                                                                            
                                                                                                            try {
                                                                                                                frequency.addValue(nonComparable);
                                                                                                                fail("Expected ClassCastException for non-comparable object");
                                                                                                            } catch (ClassCastException e) {
                                                                                                                // Expected behavior
                                                                                                            }
                                                                                                        }

    @Test(expected = NullPointerException.class)
                                                                                                        public void testAddValueWithNullShouldThrowException1() {
                                                                                                            // This test will pass with original code (expecting NPE)
                                                                                                            // and fail with mutant (which would handle null safely)
                                                                                                            Frequency frequency = new Frequency();
                                                                                                            frequency.addValue((Object)null);
                                                                                                        }

    @Test
                                                                                                        public void testAddValueWithNullShouldNotModifyFrequency() {
                                                                                                            // Additional test to verify behavior more thoroughly
                                                                                                            Frequency frequency = new Frequency();
                                                                                                            long initialCount = frequency.getCount(null);
                                                                                                            
                                                                                                            try {
                                                                                                                frequency.addValue((Object)null);
                                                                                                                // If we get here with mutant, verify count didn't change
                                                                                                                assertEquals(initialCount, frequency.getCount(null));
                                                                                                            } catch (NullPointerException e) {
                                                                                                                // Expected with original code
                                                                                                                assertTrue(true);
                                                                                                            }
                                                                                                        }

    @Test(expected = NullPointerException.class)
                                                                                                        public void testAddValueWithNullShouldThrowException2() {
                                                                                                            // This test will detect the mutant because:
                                                                                                            // Original code: throws NullPointerException when v is null (due to instanceof check)
                                                                                                            // Mutated code: would not throw exception (due to null check before instanceof)
                                                                                                            
                                                                                                            Frequency frequency = new Frequency();
                                                                                                            frequency.addValue((Object)null); // Explicit cast to Object to force the method we want to test
                                                                                                            
                                                                                                            // If we reach this point (no exception), the test fails and mutant is detected
                                                                                                            // The expected exception annotation will make the test pass only if NPE is thrown
                                                                                                        }

    @Test
                                                                                                        public void testAddValueWithNullCharacter() {
                                                                                                            // Setup
                                                                                                            Frequency frequency = new Frequency();
                                                                                                            
                                                                                                            // Test null value - should not throw exception in original, but mutant would handle it
                                                                                                            try {
                                                                                                                frequency.addValue((Character)null);
                                                                                                                // If we get here, the mutant survived (null check was added)
                                                                                                                fail("Expected NullPointerException but none was thrown");
                                                                                                            } catch (NullPointerException e) {
                                                                                                                // This is expected behavior for original code
                                                                                                                assertTrue(true);
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                        public void testAddValueWithValidCharacter() {
                                                                                                            // Setup
                                                                                                            Frequency frequency = new Frequency();
                                                                                                            Character testChar = 'A';
                                                                                                            
                                                                                                            // Test valid character
                                                                                                            frequency.addValue(testChar);
                                                                                                            
                                                                                                            // Verify the character was added to frequency table
                                                                                                            assertEquals(1L, frequency.getCount(testChar));
                                                                                                        }

    @Test
                                                                                                        public void testAddValueWithNonComparableObject() {
                                                                                                            // Setup
                                                                                                            Frequency frequency = new Frequency();
                                                                                                            Object nonComparable = new Object();
                                                                                                            
                                                                                                            // Test non-comparable object
                                                                                                            try {
                                                                                                                frequency.addValue(nonComparable);
                                                                                                                // Should either throw ClassCastException or be ignored
                                                                                                                // Depending on implementation details not shown
                                                                                                            } catch (ClassCastException e) {
                                                                                                                // This might be expected for some implementations
                                                                                                                assertTrue(true);
                                                                                                            }
                                                                                                        }

    @Test(expected = NullPointerException.class)
                                                                                                   public void testAddValueWithNullShouldThrowNPE() {
                                                                                                       // This test will pass with original code (throws NPE)
                                                                                                       // but fail with mutant (which would handle null differently)
                                                                                                       Frequency frequency = new Frequency();
                                                                                                       frequency.addValue(null);
                                                                                                   }

    @Test
                                                                                                   public void testAddValueWithNullShouldNotBeInFrequencyTable() {
                                                                                                       Frequency frequency = new Frequency();
                                                                                                       try {
                                                                                                           frequency.addValue(null);
                                                                                                           fail("Expected NullPointerException");
                                                                                                       } catch (NullPointerException e) {
                                                                                                           // Expected with original code
                                                                                                       } catch (IllegalArgumentException e) {
                                                                                                           // Might happen with mutant if it gets to the TreeMap check
                                                                                                           fail("Null value should not reach TreeMap comparison");
                                                                                                       }
                                                                                                       
                                                                                                       // Verify null wasn't added to frequency table
                                                                                                       assertEquals(0, frequency.getCount(null));
                                                                                                   }

    @Test
                                                                                                   public void testAddValueWithNullShouldNotModifyFrequencyTable() {
                                                                                                       // Additional test to verify state hasn't changed when null is passed
                                                                                                       Frequency frequency = new Frequency();
                                                                                                       
                                                                                                       // Get original table using reflection
                                                                                                       TreeMap<Comparable<?>, Long> originalTable;
                                                                                                       try {
                                                                                                           Field field = Frequency.class.getDeclaredField("freqTable");
                                                                                                           field.setAccessible(true);
                                                                                                           @SuppressWarnings("unchecked")
                                                                                                           TreeMap<Comparable<?>, Long> table = (TreeMap<Comparable<?>, Long>) field.get(frequency);
                                                                                                           originalTable = new TreeMap<>(table);
                                                                                                       } catch (Exception e) {
                                                                                                           fail("Failed to access freqTable via reflection: " + e.getMessage());
                                                                                                           return;
                                                                                                       }
                                                                                                       
                                                                                                       try {
                                                                                                           frequency.addValue((Object)null);
                                                                                                           fail("Expected NullPointerException");
                                                                                                       } catch (NullPointerException e) {
                                                                                                           // Expected behavior for original code
                                                                                                       }
                                                                                                       
                                                                                                       // Compare with current table using reflection
                                                                                                       try {
                                                                                                           Field field = Frequency.class.getDeclaredField("freqTable");
                                                                                                           field.setAccessible(true);
                                                                                                           @SuppressWarnings("unchecked")
                                                                                                           TreeMap<Comparable<?>, Long> currentTable = (TreeMap<Comparable<?>, Long>) field.get(frequency);
                                                                                                           assertEquals(originalTable, currentTable);
                                                                                                       } catch (Exception e) {
                                                                                                           fail("Failed to access freqTable via reflection: " + e.getMessage());
                                                                                                       }
                                                                                                   }

    @Test
                                                                                                   public void testAddValueWithComparableObject() {
                                                                                                       // Setup
                                                                                                       Frequency frequency = new Frequency();
                                                                                                       String comparableObject = "testString"; // String implements Comparable
                                                                                                       
                                                                                                       try {
                                                                                                           // Exercise
                                                                                                           frequency.addValue(comparableObject);
                                                                                                           
                                                                                                           // Verify - if we get here, the test passes (original behavior)
                                                                                                           // The mutated version would throw exception
                                                                                                       } catch (IllegalArgumentException e) {
                                                                                                           fail("Should not throw exception for Comparable objects");
                                                                                                       }
                                                                                                       
                                                                                                       // Additional verification that the value was actually added
                                                                                                       assertTrue(frequency.getCount(comparableObject) > 0);
                                                                                                   }

    @Test(expected = IllegalArgumentException.class)
                                                                                                   public void testAddValueWithNonComparableObject1() {
                                                                                                       // Setup
                                                                                                       Frequency frequency = new Frequency();
                                                                                                       Object nonComparableObject = new Object(); // Object doesn't implement Comparable
                                                                                                       
                                                                                                       // Exercise & Verify
                                                                                                       frequency.addValue(nonComparableObject);
                                                                                                   }

    @Test
                                                                                                   public void testAddValueWithNonComparableObject2() {
                                                                                                       // Create a non-comparable object
                                                                                                       Object nonComparable = new Object() {
                                                                                                           @Override
                                                                                                           public String toString() {
                                                                                                               return "NonComparableObject";
                                                                                                           }
                                                                                                       };
                                                                                                       
                                                                                                       Frequency frequency = new Frequency();
                                                                                                       
                                                                                                       // Expect IllegalArgumentException for original code
                                                                                                       thrown.expect(IllegalArgumentException.class);
                                                                                                       thrown.expectMessage("Value not comparable to existing values.");
                                                                                                       
                                                                                                       // This will throw ClassCastException in mutant version
                                                                                                       frequency.addValue(nonComparable);
                                                                                                   }

    @Test
                                                                                               public void testAddValueWithComparableShouldIncreaseCount() {
                                                                                                   // Setup
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   Long testValue = 123L; // Long implements Comparable
                                                                                                   
                                                                                                   // Action
                                                                                                   frequency.addValue(testValue);
                                                                                                   
                                                                                                   // Verification
                                                                                                   // Original: count should be 1 (value was added)
                                                                                                   // Mutant: count will be 0 (value wasn't added due to false condition)
                                                                                                   assertEquals("Count should increase when adding Comparable value", 
                                                                                                                1L, frequency.getCount(testValue));
                                                                                                   
                                                                                                   // Additional check for sum frequency
                                                                                                   assertEquals("Sum frequency should reflect added value", 
                                                                                                                1L, frequency.getSumFreq());
                                                                                               }

    @Test
                                                                                                   public void testAddValueWithComparableShouldAddToFrequencyTable() {
                                                                                                       // Setup
                                                                                                       Frequency frequency = new Frequency();
                                                                                                       Long testValue = 123L;
                                                                                                       
                                                                                                       // Verify initial state
                                                                                                       assertEquals(0, frequency.getCount(testValue));
                                                                                                       assertEquals(0, frequency.getSumFreq());
                                                                                                       
                                                                                                       // Action
                                                                                                       frequency.addValue(testValue);
                                                                                                       
                                                                                                       // Verification
                                                                                                       // These assertions will fail with the mutant since the value won't be added
                                                                                                       assertEquals(1, frequency.getCount(testValue));
                                                                                                       assertEquals(1, frequency.getSumFreq());
                                                                                                       
                                                                                                       // Add another to verify increment works
                                                                                                       frequency.addValue(testValue);
                                                                                                       assertEquals(2, frequency.getCount(testValue));
                                                                                                       assertEquals(2, frequency.getSumFreq());
                                                                                                   }

    @Test
                                                                                                   public void testAddValueLongShouldIncrementCount() {
                                                                                                       // Setup
                                                                                                       Frequency frequency = new Frequency();
                                                                                                       Long testValue = 123L;
                                                                                                       
                                                                                                       // Verify initial count is 0
                                                                                                       assertEquals(0, frequency.getCount(testValue));
                                                                                                       
                                                                                                       // Action - add the value
                                                                                                       frequency.addValue(testValue);
                                                                                                       
                                                                                                       // Verification - count should be 1 for original code, 0 for mutated code
                                                                                                       assertEquals("Count should increment when adding a Long value", 
                                                                                                                    1, frequency.getCount(testValue));
                                                                                                   }

    @Test
                                                                                                   public void testAddValueComparableShouldBeHandled() {
                                                                                                       // Setup
                                                                                                       Frequency frequency = new Frequency();
                                                                                                       Comparable<Long> testValue = 456L; // Long implements Comparable
                                                                                                       
                                                                                                       // Verify initial count is 0
                                                                                                       assertEquals(0, frequency.getCount(testValue));
                                                                                                       
                                                                                                       // Action - add the value
                                                                                                       frequency.addValue(testValue);
                                                                                                       
                                                                                                       // Verification - count should be 1 for original code, 0 for mutated code
                                                                                                       assertEquals("Count should increment when adding a Comparable value", 
                                                                                                                    1, frequency.getCount(testValue));
                                                                                                   }

    @Test
                                                                                               public void testAddValueCharacterShouldBeCountedWhenComparable() {
                                                                                                   // Setup
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   char testChar = 'a';
                                                                                                   
                                                                                                   // Action
                                                                                                   frequency.addValue(testChar);
                                                                                                   
                                                                                                   // Verification
                                                                                                   // Original code would count this (since Character is Comparable)
                                                                                                   // Mutant would skip counting (due to if(false))
                                                                                                   assertEquals("Character value should be counted", 1L, frequency.getCount(testChar));
                                                                                                   
                                                                                                   // Additional verification to ensure it's properly stored in the TreeMap
                                                                                                   assertEquals("Character value should be counted in frequency table", 
                                                                                                                1L, frequency.getCount(Character.valueOf(testChar)));
                                                                                               }

    @Test
                                                                                                  public void testAddValueWithProperComparableShouldNotThrow() {
                                                                                                      Frequency frequency = new Frequency();
                                                                                                      // This should work in both original and mutated code
                                                                                                      frequency.addValue(Integer.valueOf(5)); // Integer implements Comparable<Integer>
                                                                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                                                                  public void testAddValueWithRawComparable() {
                                                                                                      // Create a test object that implements raw Comparable but isn't properly typed
                                                                                                      class RawComparable implements Comparable {
                                                                                                          private final int value;
                                                                                                          
                                                                                                          public RawComparable(int value) {
                                                                                                              this.value = value;
                                                                                                          }
                                                                                                          
                                                                                                          @Override
                                                                                                          public int compareTo(Object o) {
                                                                                                              RawComparable other = (RawComparable) o; // This is unsafe but demonstrates the issue
                                                                                                              return Integer.compare(this.value, other.value);
                                                                                                          }
                                                                                                      }
                                                                                                      
                                                                                                      Frequency frequency = new Frequency();
                                                                                                      // This should throw IllegalArgumentException because it's not properly typed Comparable
                                                                                                      frequency.addValue(new RawComparable(1));
                                                                                                  }

    @Test
                                                                                                  public void testAddValueWithRawComparable1() {
                                                                                                      // Create a custom class that implements raw Comparable
                                                                                                      class RawComparable implements Comparable {
                                                                                                          private final int value;
                                                                                                          
                                                                                                          public RawComparable(int value) {
                                                                                                              this.value = value;
                                                                                                          }
                                                                                                          
                                                                                                          @Override
                                                                                                          public int compareTo(Object o) {
                                                                                                              RawComparable other = (RawComparable) o;
                                                                                                              return Integer.compare(this.value, other.value);
                                                                                                          }
                                                                                                      }
                                                                                                      
                                                                                                      Frequency frequency = new Frequency();
                                                                                                      RawComparable rawComp = new RawComparable(5);
                                                                                                      
                                                                                                      // This should work in both original and mutated versions
                                                                                                      frequency.addValue(rawComp);
                                                                                                      assertEquals(1, frequency.getCount(rawComp));
                                                                                                      
                                                                                                      // The key difference is that the original version would have type safety
                                                                                                      // while the mutated version would allow potentially unsafe comparisons
                                                                                                      // We can test this by adding another value and checking behavior
                                                                                                      
                                                                                                      // Create another raw comparable with different type (should be rejected in original)
                                                                                                      class OtherRawComparable implements Comparable {
                                                                                                          private final String value;
                                                                                                          
                                                                                                          public OtherRawComparable(String value) {
                                                                                                              this.value = value;
                                                                                                          }
                                                                                                          
                                                                                                          @Override
                                                                                                          public int compareTo(Object o) {
                                                                                                              OtherRawComparable other = (OtherRawComparable) o;
                                                                                                              return this.value.compareTo(other.value);
                                                                                                          }
                                                                                                      }
                                                                                                      
                                                                                                      OtherRawComparable otherRawComp = new OtherRawComparable("test");
                                                                                                      try {
                                                                                                          frequency.addValue(otherRawComp);
                                                                                                          // If we get here, the mutant survived (accepted raw comparable)
                                                                                                          // Now check if it causes problems in the frequency table
                                                                                                          frequency.getCount(otherRawComp);  // This might throw ClassCastException
                                                                                                          fail("Expected potential ClassCastException due to raw comparable mixing");
                                                                                                      } catch (ClassCastException e) {
                                                                                                          // This is expected in original version
                                                                                                          assertTrue(true);
                                                                                                      }
                                                                                                  }

    @Test
                                                                                                  public void testAddValueWithRawComparable2() {
                                                                                                      // Setup
                                                                                                      Frequency frequency = new Frequency();
                                                                                                      // Create a raw Comparable implementation
                                                                                                      Comparable rawComparable = new Comparable() {
                                                                                                          @Override
                                                                                                          public int compareTo(Object o) {
                                                                                                              return 0; // simple implementation
                                                                                                          }
                                                                                                      };
                                                                                                      
                                                                                                      // Execute
                                                                                                      frequency.addValue(rawComparable);
                                                                                                      
                                                                                                      // Verify
                                                                                                      // Both original and mutant should handle this case
                                                                                                      assertEquals(1L, frequency.getCount(rawComparable));
                                                                                                      assertEquals(1L, frequency.getSumFreq());
                                                                                                  }

    @Test
                                                                                                  public void testAddValueWithNonComparable1() {
                                                                                                      // Setup
                                                                                                      Frequency frequency = new Frequency();
                                                                                                      Object nonComparable = new Object();
                                                                                                      
                                                                                                      // Execute
                                                                                                      frequency.addValue(nonComparable);
                                                                                                      
                                                                                                      // Verify
                                                                                                      // The method should still add the object even if it's not Comparable
                                                                                                      assertEquals(1L, frequency.getCount(nonComparable));
                                                                                                      assertEquals(1L, frequency.getSumFreq());
                                                                                                  }

    @Test
                                                                                                  public void testAddValueWithParameterizedComparable() {
                                                                                                      // Create a custom Comparable class with specific type parameter
                                                                                                      class StringComparable implements Comparable<String> {
                                                                                                          private final String value;
                                                                                                          
                                                                                                          public StringComparable(String value) {
                                                                                                              this.value = value;
                                                                                                          }
                                                                                                          
                                                                                                          @Override
                                                                                                          public int compareTo(String other) {
                                                                                                              return value.compareTo(other);
                                                                                                          }
                                                                                                      }
                                                                                                      
                                                                                                      Frequency frequency = new Frequency();
                                                                                                      StringComparable comparable = new StringComparable("test");
                                                                                                      
                                                                                                      // This should be added to frequency table in original code
                                                                                                      // But might be rejected by mutant
                                                                                                      frequency.addValue(comparable);
                                                                                                      
                                                                                                      // Verify the value was added by checking count
                                                                                                      assertEquals(1L, frequency.getCount(comparable));
                                                                                                  }

    @Test
                                                                                                  public void testAddValueWithRawComparable3() {
                                                                                                      // Create a raw Comparable implementation
                                                                                                      class RawComparable implements Comparable {
                                                                                                          private final int value;
                                                                                                          
                                                                                                          public RawComparable(int value) {
                                                                                                              this.value = value;
                                                                                                          }
                                                                                                          
                                                                                                          @Override
                                                                                                          public int compareTo(Object other) {
                                                                                                              RawComparable that = (RawComparable) other;
                                                                                                              return Integer.compare(this.value, that.value);
                                                                                                          }
                                                                                                      }
                                                                                                      
                                                                                                      Frequency frequency = new Frequency();
                                                                                                      RawComparable rawComparable = new RawComparable(42);
                                                                                                      
                                                                                                      // Both original and mutant should handle this
                                                                                                      frequency.addValue(rawComparable);
                                                                                                      
                                                                                                      // Verify the value was added
                                                                                                      assertEquals(1L, frequency.getCount(rawComparable));
                                                                                                  }

    @Test
                                                                                                  public void testAddValueWithGenericComparable() {
                                                                                                      // Create a test object that implements Comparable<String>
                                                                                                      class TestComparable implements Comparable<String> {
                                                                                                          @Override
                                                                                                          public int compareTo(String o) {
                                                                                                              return 0;
                                                                                                          }
                                                                                                      }
                                                                                                      
                                                                                                      TestComparable testObj = new TestComparable();
                                                                                                      Frequency frequency = new Frequency();
                                                                                                      
                                                                                                      // Add the test object and verify it was counted
                                                                                                      frequency.addValue(testObj);
                                                                                                      long count = frequency.getCount(testObj);
                                                                                                      
                                                                                                      // If the mutant is present (using raw Comparable), this might fail
                                                                                                      assertEquals("Generic Comparable object should be counted", 1, count);
                                                                                                      
                                                                                                      // Add another test to verify the type safety aspect
                                                                                                      // This would fail if the mutant allowed raw types improperly
                                                                                                      frequency.addValue(Character.valueOf('a'));
                                                                                                      assertEquals("Character should be counted separately", 1, frequency.getCount(Character.valueOf('a')));
                                                                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                                                             public void testAddValueWithRawComparableShouldThrowException() {
                                                                                                 Frequency frequency = new Frequency();
                                                                                                 // Define a simple class that doesn't implement Comparable
                                                                                                 class NonComparable {}
                                                                                                 // This should throw IllegalArgumentException
                                                                                                 frequency.addValue(new NonComparable());
                                                                                             }

    @Test
                                                                                             public void testAddValueWithGenericComparable1() {
                                                                                                 // Setup
                                                                                                 Frequency frequency = new Frequency();
                                                                                                 
                                                                                                 // Define a simple Comparable implementation for testing
                                                                                                 class TestComparable implements Comparable<TestComparable> {
                                                                                                     private int value;
                                                                                                     
                                                                                                     public TestComparable(int value) {
                                                                                                         this.value = value;
                                                                                                     }
                                                                                                     
                                                                                                     @Override
                                                                                                     public int compareTo(TestComparable other) {
                                                                                                         return Integer.compare(this.value, other.value);
                                                                                                     }
                                                                                                     
                                                                                                     @Override
                                                                                                     public boolean equals(Object obj) {
                                                                                                         if (this == obj) return true;
                                                                                                         if (!(obj instanceof TestComparable)) return false;
                                                                                                         TestComparable other = (TestComparable) obj;
                                                                                                         return value == other.value;
                                                                                                     }
                                                                                                     
                                                                                                     @Override
                                                                                                     public int hashCode() {
                                                                                                         return Integer.hashCode(value);
                                                                                                     }
                                                                                                 }
                                                                                                 
                                                                                                 TestComparable testObj = new TestComparable(42);
                                                                                                 
                                                                                                 // Execute
                                                                                                 frequency.addValue(testObj);
                                                                                                 
                                                                                                 // Verify
                                                                                                 // The original code would handle this properly as a Comparable<?>
                                                                                                 // The mutant would also handle it but with raw type comparison
                                                                                                 // We need to verify the count was incremented
                                                                                                 assertEquals(1L, frequency.getCount(testObj));
                                                                                                 
                                                                                                 // Additional verification that the value was properly added
                                                                                                 assertEquals(1L, frequency.getSumFreq());
                                                                                             }

    @Test
                                                                                             public void testAddValueWithNonComparableObject3() {
                                                                                                 // Create a non-Comparable object
                                                                                                 class NonComparable {}
                                                                                                 Object nonComparable = new NonComparable();
                                                                                                 
                                                                                                 Frequency frequency = new Frequency();
                                                                                                 
                                                                                                 // Expect IllegalArgumentException to be thrown
                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                 thrown.expectMessage("Object must implement Comparable");
                                                                                                 
                                                                                                 // This should throw exception in original code, but would pass in mutated version
                                                                                                 frequency.addValue(nonComparable);
                                                                                                 
                                                                                                 // Additional verification that the object wasn't actually added
                                                                                                 assertEquals(0, frequency.getCount(nonComparable));
                                                                                             }

    @Test
                                                                                             public void testAddValueWithComparableObject1() {
                                                                                                 // Create a Comparable object (String implements Comparable)
                                                                                                 String comparable = "test";
                                                                                                 
                                                                                                 Frequency frequency = new Frequency();
                                                                                                 
                                                                                                 // This should work in both original and mutated versions
                                                                                                 frequency.addValue(comparable);
                                                                                                 
                                                                                                 // Verify the object was added
                                                                                                 assertEquals(1, frequency.getCount(comparable));
                                                                                             }

    @Test
                                                                                             public void testAddValueWithNonComparableObject4() {
                                                                                                 // Create a non-comparable object
                                                                                                 class NonComparable {}
                                                                                                 Object nonComparable = new NonComparable();
                                                                                                 
                                                                                                 Frequency frequency = new Frequency();
                                                                                                 
                                                                                                 // Expect IllegalArgumentException to be thrown
                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                 thrown.expectMessage("Value not comparable to existing values.");
                                                                                                 
                                                                                                 // This should call addValue((Comparable<?>) v) in original code
                                                                                                 // but calls addValue(v) in mutated code
                                                                                                 frequency.addValue(nonComparable);
                                                                                                 
                                                                                                 // If we reach here in mutated version, the test will fail
                                                                                                 // because TreeMap would throw ClassCastException instead
                                                                                             }

    @Test
                                                                                             public void testAddValueWithNonComparableObject5() {
                                                                                                 // Create a Frequency instance with natural ordering
                                                                                                 Frequency frequency = new Frequency();
                                                                                                 
                                                                                                 // Create a non-Comparable object
                                                                                                 Object nonComparable = new Object() {
                                                                                                     @Override
                                                                                                     public String toString() {
                                                                                                         return "NonComparableObject";
                                                                                                     }
                                                                                                 };
                                                                                                 
                                                                                                 try {
                                                                                                     // This should throw ClassCastException in the mutated version
                                                                                                     frequency.addValue(nonComparable);
                                                                                                     
                                                                                                     // If we get here, the mutation survived (no exception thrown)
                                                                                                     fail("Expected ClassCastException when adding non-Comparable object");
                                                                                                 } catch (ClassCastException e) {
                                                                                                     // This is expected behavior for the original code
                                                                                                     assertTrue("Expected ClassCastException", true);
                                                                                                 }
                                                                                             }

    @Test
                                                                                             public void testAddValueWithComparableObject2() {
                                                                                                 // Create a Frequency instance
                                                                                                 Frequency frequency = new Frequency();
                                                                                                 
                                                                                                 // Create a Comparable object (Long implements Comparable)
                                                                                                 Long comparableValue = 123L;
                                                                                                 
                                                                                                 try {
                                                                                                     // This should work in both original and mutated versions
                                                                                                     frequency.addValue(comparableValue);
                                                                                                     
                                                                                                     // Verify the value was added
                                                                                                     assertEquals(1, frequency.getCount(comparableValue));
                                                                                                 } catch (ClassCastException e) {
                                                                                                     fail("Should not throw ClassCastException for Comparable objects");
                                                                                                 }
                                                                                             }

    @Test
                                                                                             public void testAddValueWithNonComparableObject6() {
                                                                                                 // Create a custom non-Comparable object
                                                                                                 class NonComparable {
                                                                                                     final long value;
                                                                                                     NonComparable(long v) { value = v; }
                                                                                                     long longValue() { return value; }
                                                                                                 }
                                                                                                 
                                                                                                 Frequency frequency = new Frequency();
                                                                                                 NonComparable nonComparable = new NonComparable(5L);
                                                                                                 
                                                                                                 // This should work in original version due to Comparable cast,
                                                                                                 // but fail in mutant version when trying to add to TreeMap
                                                                                                 try {
                                                                                                     frequency.addValue(Long.valueOf(nonComparable.longValue()));
                                                                                                     // Verify the value was added
                                                                                                     assertEquals(1L, frequency.getCount(5L));
                                                                                                 } catch (ClassCastException e) {
                                                                                                     fail("Original version should handle this via Comparable cast");
                                                                                                 }
                                                                                                 
                                                                                                 // Additional test with regular Long to ensure normal functionality
                                                                                                 frequency.clear();
                                                                                                 frequency.addValue(Long.valueOf(10L));
                                                                                                 assertEquals(1L, frequency.getCount(10L));
                                                                                             }

    @Test
                                                                                        public void testAddValueWithNonComparableObject7() {
                                                                                            // Create a non-Comparable object
                                                                                            class NonComparable {
                                                                                                final int value;
                                                                                                
                                                                                                public NonComparable(int value) {
                                                                                                    this.value = value;
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                public boolean equals(Object o) {
                                                                                                    if (this == o) return true;
                                                                                                    if (o == null || getClass() != o.getClass()) return false;
                                                                                                    NonComparable that = (NonComparable) o;
                                                                                                    return value == that.value;
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                public int hashCode() {
                                                                                                    return java.util.Objects.hash(value);
                                                                                                }
                                                                                            }
                                                                                            
                                                                                            NonComparable nc = new NonComparable(42);
                                                                                            org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                                                            
                                                                                            // This will fail with ClassCastException in the mutated version 
                                                                                            // because TreeMap can't handle non-Comparable objects without explicit casting
                                                                                            frequency.addValue(nc);
                                                                                            
                                                                                            // Verify the value was added correctly
                                                                                            assertEquals(1, frequency.getCount(nc));
                                                                                        }

    @Test
                                                                                        public void testAddValueCharCallsComparableVersion() {
                                                                                            // Create frequency object
                                                                                            Frequency freq = new Frequency();
                                                                                            
                                                                                            // Add a character value
                                                                                            char testChar = 'a';
                                                                                            freq.addValue(testChar);
                                                                                            
                                                                                            // Verify the value was added by checking count
                                                                                            assertEquals(1L, freq.getCount(testChar));
                                                                                            
                                                                                            // Verify the value was stored as Comparable in the TreeMap
                                                                                            try {
                                                                                                Field field = Frequency.class.getDeclaredField("freqTable");
                                                                                                field.setAccessible(true);
                                                                                                @SuppressWarnings("unchecked")
                                                                                                TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) field.get(freq);
                                                                                                assertTrue(freqTable.containsKey(Character.valueOf(testChar)));
                                                                                            } catch (Exception e) {
                                                                                                fail("Reflection failed: " + e.getMessage());
                                                                                            }
                                                                                            
                                                                                            // Add another character to test comparison
                                                                                            freq.addValue('b');
                                                                                            assertEquals(1L, freq.getCount('b'));
                                                                                            
                                                                                            // Verify ordering is maintained (TreeMap uses Comparable)
                                                                                            Iterator<?> it = freq.valuesIterator();
                                                                                            assertEquals(Character.valueOf('a'), it.next());
                                                                                            assertEquals(Character.valueOf('b'), it.next());
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                    public void testAddValueWithNonComparableObjectShouldThrowException() {
                                                                                        // Setup
                                                                                        Frequency frequency = new Frequency();
                                                                                        Object nonComparable = new Object(); // Object doesn't implement Comparable
                                                                                        
                                                                                        try {
                                                                                            // Exercise
                                                                                            frequency.addValue(nonComparable);
                                                                                        } catch (IllegalArgumentException e) {
                                                                                            // Verify
                                                                                            assertEquals("Value not comparable to existing values.", e.getMessage());
                                                                                            assertTrue(frequency.getSumFreq() == 0); // No value should be added
                                                                                            throw e;
                                                                                        }
                                                                                        
                                                                                        fail("Expected IllegalArgumentException was not thrown");
                                                                                    }

    @Test
                                                                                    public void testAddValueWithComparableObjectShouldWork() {
                                                                                        // Setup
                                                                                        Frequency frequency = new Frequency();
                                                                                        String comparableValue = "test"; // String implements Comparable
                                                                                        
                                                                                        // Exercise
                                                                                        frequency.addValue(comparableValue);
                                                                                        
                                                                                        // Verify
                                                                                        assertEquals(1, frequency.getCount(comparableValue));
                                                                                        assertEquals(1, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValueWithIntegerShouldConvertToLong() {
                                                                                        // Setup
                                                                                        Frequency frequency = new Frequency();
                                                                                        Integer intValue = 5;
                                                                                        
                                                                                        // Exercise
                                                                                        frequency.addValue(intValue);
                                                                                        
                                                                                        // Verify
                                                                                        assertEquals(1, frequency.getCount(5L)); // Should be stored as Long
                                                                                        assertEquals(1, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                        public void testAddValueCharCallsCorrectOverload() {
                                                                                            // Create a spy to track method calls
                                                                                            Frequency frequency = spy(new Frequency());
                                                                                            
                                                                                            // Test with a sample char value
                                                                                            char testChar = 'a';
                                                                                            frequency.addValue(testChar);
                                                                                            
                                                                                            // Verify the correct overload was called with Character.valueOf(testChar)
                                                                                            verify(frequency).addValue(eq(Character.valueOf(testChar)));
                                                                                            
                                                                                            // Also verify the incorrect overload (raw Comparable) was NOT called
                                                                                            verify(frequency, never()).addValue(any(Comparable.class));
                                                                                        }

    @Test
                                                                                   public void testAddValueWithGenericComparable2() {
                                                                                       Frequency frequency = new Frequency();
                                                                                       
                                                                                       // Create a type-sensitive Comparable implementation
                                                                                       class GenericComparable<T> implements Comparable<T> {
                                                                                           private final T value;
                                                                                           
                                                                                           public GenericComparable(T value) {
                                                                                               this.value = value;
                                                                                           }
                                                                                           
                                                                                           @Override
                                                                                           public int compareTo(T other) {
                                                                                               // This implementation is type-sensitive
                                                                                               if (other instanceof GenericComparable) {
                                                                                                   @SuppressWarnings("unchecked")
                                                                                                   GenericComparable<T> otherComp = (GenericComparable<T>) other;
                                                                                                   return this.value.toString().compareTo(otherComp.value.toString());
                                                                                               }
                                                                                               throw new ClassCastException("Incompatible types");
                                                                                           }
                                                                                       }
                                                                                       
                                                                                       GenericComparable<String> stringComparable = new GenericComparable<>("test");
                                                                                       
                                                                                       // This should work with both original and mutated code
                                                                                       frequency.addValue(stringComparable);
                                                                                       
                                                                                       // Create a raw Comparable that would behave differently with the mutation
                                                                                       Comparable rawComparable = stringComparable;
                                                                                       
                                                                                       try {
                                                                                           // This test will pass with original code but might fail with mutated code
                                                                                           // if the type information is not properly preserved
                                                                                           frequency.addValue(rawComparable);
                                                                                           
                                                                                           // Verify the count was incremented (assuming getCount works)
                                                                                           assertEquals(2L, frequency.getCount(rawComparable));
                                                                                       } catch (ClassCastException e) {
                                                                                           // The mutated version might throw this if type info is lost
                                                                                           fail("Type information was not properly preserved during cast");
                                                                                       }
                                                                                   }

    @Test
                                                                                   public void testAddValueWithCustomComparator() {
                                                                                       // Create a custom comparator that relies on type information
                                                                                       @SuppressWarnings("unchecked")
                                                                                       Comparator<Comparable> comparator = (o1, o2) -> {
                                                                                           // This comparison depends on proper generic typing
                                                                                           if (o1.getClass().equals(o2.getClass())) {
                                                                                               return ((Comparable<Object>)o1).compareTo(o2);
                                                                                           }
                                                                                           return o1.getClass().getName().compareTo(o2.getClass().getName());
                                                                                       };
                                                                                   
                                                                                       // Create Frequency with our custom comparator
                                                                                       Frequency frequency = new Frequency(comparator);
                                                                                       
                                                                                       // Add values that would be affected by type comparison
                                                                                       Long longValue = 100L;
                                                                                       Integer intValue = 100;
                                                                                       
                                                                                       // Add values - the mutant would treat these as raw Comparables
                                                                                       frequency.addValue(longValue);
                                                                                       frequency.addValue(intValue);
                                                                                       
                                                                                       // Verify counts - with proper generic handling, these should be separate counts
                                                                                       assertEquals(1L, frequency.getCount(longValue));
                                                                                       assertEquals(1L, frequency.getCount(intValue));
                                                                                       
                                                                                       // The mutant would potentially combine these counts due to raw type comparison
                                                                                   }

    @Test
                                                                                   public void testAddValueWithDifferentComparableTypes() {
                                                                                       // Create a new Frequency instance
                                                                                       Frequency frequency = new Frequency();
                                                                                       
                                                                                       // Add different types of Comparable objects
                                                                                       // These should all be handled correctly in original code
                                                                                       frequency.addValue((Comparable<?>) "string");
                                                                                       frequency.addValue((Comparable<?>) Long.valueOf(123L));
                                                                                       frequency.addValue((Comparable<?>) new java.util.Date());
                                                                                       
                                                                                       // Verify all values were added without exceptions
                                                                                       // The mutant would fail when trying to compare these different types
                                                                                       assertEquals(1, frequency.getCount("string"));
                                                                                       assertEquals(1, frequency.getCount(Long.valueOf(123L)));
                                                                                       // For Date, we can just verify the sum frequency increased
                                                                                       assertEquals(3, frequency.getSumFreq());
                                                                                       
                                                                                       // Add more test cases with edge values
                                                                                       frequency.addValue((Comparable<?>) null);
                                                                                       assertEquals(4, frequency.getSumFreq());
                                                                                       
                                                                                       // Test with custom comparable objects
                                                                                       class CustomComparable implements Comparable<CustomComparable> {
                                                                                           public int compareTo(CustomComparable o) { return 0; }
                                                                                       }
                                                                                       CustomComparable custom = new CustomComparable();
                                                                                       frequency.addValue((Comparable<?>) custom);
                                                                                       assertEquals(5, frequency.getSumFreq());
                                                                                   }

    @Test
                                                                                   public void testAddValueWithLongMaintainsTypeSafety() {
                                                                                       // Setup
                                                                                       Frequency frequency = new Frequency();
                                                                                       Long testValue = 12345L;
                                                                                       
                                                                                       // Action
                                                                                       frequency.addValue(testValue);
                                                                                       
                                                                                       // Verification
                                                                                       try {
                                                                                           // Use reflection to access private freqTable field
                                                                                           Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                                                                           freqTableField.setAccessible(true);
                                                                                           @SuppressWarnings("unchecked")
                                                                                           TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                                                                                           
                                                                                           assertTrue("Frequency table should contain the test value", 
                                                                                                     freqTable.containsKey(testValue));
                                                                                           
                                                                                           // Verify the key in the table maintains proper generic type
                                                                                           for (Comparable<?> key : freqTable.keySet()) {
                                                                                               assertTrue("Key should be instance of Long", 
                                                                                                         key instanceof Long);
                                                                                               // This assertion would fail if the mutant is present because 
                                                                                               // the raw type Comparable would allow non-Long keys
                                                                                           }
                                                                                           
                                                                                           // Additional verification of type safety
                                                                                           try {
                                                                                               frequency.addValue("not a long"); // This should fail with ClassCastException
                                                                                               fail("Should have thrown ClassCastException for non-Long value");
                                                                                           } catch (ClassCastException e) {
                                                                                               // Expected behavior
                                                                                           }
                                                                                       } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                           fail("Failed to access freqTable field through reflection: " + e.getMessage());
                                                                                       }
                                                                                   }

    @Test
                                                                                   public void testAddValueWithComparableShouldAddToFrequencyTable1() {
                                                                                       // Setup
                                                                                       Frequency frequency = new Frequency();
                                                                                       String testValue = "testValue"; // String implements Comparable
                                                                                       
                                                                                       // Action
                                                                                       frequency.addValue(testValue);
                                                                                       
                                                                                       // Verification
                                                                                       assertEquals("Value should be added once", 1, frequency.getCount(testValue));
                                                                                   }

    @Test(expected = IllegalArgumentException.class)
                                                                                   public void testAddValueWithNonComparableShouldThrowException() {
                                                                                       // Setup
                                                                                       Frequency frequency = new Frequency();
                                                                                       Object nonComparable = new Object(); // Object doesn't implement Comparable
                                                                                       
                                                                                       // Action & Verification
                                                                                       frequency.addValue(nonComparable);
                                                                                   }

    @Test
                                                                                   public void testAddValueWithComparableShouldCallCorrectOverload() {
                                                                                       // Setup
                                                                                       Frequency frequency = new Frequency();
                                                                                       Integer testValue = 42; // Integer implements Comparable
                                                                                       
                                                                                       // Action
                                                                                       frequency.addValue(testValue);
                                                                                       
                                                                                       // Verification
                                                                                       // If mutant exists, this would either throw NPE or return 0 count
                                                                                       assertEquals("Value should be properly added via Comparable overload", 
                                                                                                   1, frequency.getCount(testValue));
                                                                                   }

    @Test
                                                                               public void testAddValueDetectsNullMutation() {
                                                                                   // Setup
                                                                                   Frequency frequency = new Frequency();
                                                                                   Integer testValue = 5;
                                                                                   long initialCount = frequency.getCount(testValue);
                                                                                   long initialSum = frequency.getSumFreq();
                                                                                   
                                                                                   // Action
                                                                                   frequency.addValue(testValue);
                                                                                   
                                                                                   // Verification
                                                                                   // Verify count increased by 1 for our test value
                                                                                   assertEquals("Count should increase by 1 after adding value", 
                                                                                                initialCount + 1, frequency.getCount(testValue));
                                                                                                
                                                                                   // Verify total sum increased by 1
                                                                                   assertEquals("Total frequency sum should increase by 1", 
                                                                                                initialSum + 1, frequency.getSumFreq());
                                                                                                
                                                                                   // Verify the value was actually added (not null)
                                                                                   assertTrue("Frequency table should contain the added value", 
                                                                                              frequency.getCount(testValue) > 0);
                                                                               }

    @Test
                                                                               public void testAddValueShouldNotPassNull() {
                                                                                   // Setup
                                                                                   Frequency frequency = new Frequency();
                                                                                   Long testValue = 42L;
                                                                                   
                                                                                   // Action
                                                                                   frequency.addValue(testValue);
                                                                                   
                                                                                   // Verification
                                                                                   // Original behavior: count for 42L should be 1
                                                                                   assertEquals(1L, frequency.getCount(testValue));
                                                                                   // Mutant behavior would increment null count instead
                                                                                   assertEquals(0L, frequency.getCount(null));
                                                                                   
                                                                                   // Additional verification that sum frequency increased
                                                                                   assertEquals(1L, frequency.getSumFreq());
                                                                               }

    @Test
                                                                               public void testAddValueCharDetectsNullMutant() {
                                                                                   // Setup
                                                                                   Frequency frequency = new Frequency();
                                                                                   char testChar = 'a';
                                                                                   
                                                                                   // Action
                                                                                   frequency.addValue(testChar);
                                                                                   
                                                                                   // Verification
                                                                                   // Original behavior should have count = 1 for the test character
                                                                                   // Mutant would have count = 0 since it adds null instead
                                                                                   assertEquals("Character count should be 1 after adding", 1, frequency.getCount(testChar));
                                                                                   
                                                                                   // Also verify the null wasn't actually added
                                                                                   assertEquals("Null count should remain 0", 0, frequency.getCount(null));
                                                                               }

    @Test
                                                                              public void testAddValueLongShouldNotPassNull() {
                                                                                  // Setup
                                                                                  Frequency frequency = new Frequency();
                                                                                  long testValue = 123L;
                                                                                  
                                                                                  // Get initial state
                                                                                  long initialCount = frequency.getCount(testValue);
                                                                                  long initialSum = frequency.getSumFreq();
                                                                                  
                                                                                  // Action
                                                                                  frequency.addValue(testValue);
                                                                                  
                                                                                  // Verification
                                                                                  // Verify count for the specific value increased
                                                                                  assertEquals("Count for value should increase by 1", 
                                                                                              initialCount + 1, 
                                                                                              frequency.getCount(testValue));
                                                                                              
                                                                                  // Verify total sum increased
                                                                                  assertEquals("Total frequency sum should increase by 1",
                                                                                              initialSum + 1,
                                                                                              frequency.getSumFreq());
                                                                                              
                                                                                  // Verify the value was actually added (not null)
                                                                                  assertTrue("Frequency should have count for test value",
                                                                                            frequency.getCount(testValue) > 0);
                                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                                          public void testAddValueWithNonComparableObjectShouldThrowException1() {
                                                                              // Setup
                                                                              Frequency frequency = new Frequency();
                                                                              Object nonComparable = new Object(); // Object is not Comparable
                                                                              
                                                                              // Exercise
                                                                              try {
                                                                                  frequency.addValue(nonComparable);
                                                                              } catch (IllegalArgumentException e) {
                                                                                  // Verify
                                                                                  assertEquals("Value not comparable to existing values.", e.getMessage());
                                                                                  assertEquals(0, frequency.getSumFreq()); // Verify table is empty through public method
                                                                                  throw e; // rethrow to satisfy @Test(expected)
                                                                              }
                                                                              
                                                                              // If we get here, the test failed
                                                                              fail("Expected IllegalArgumentException was not thrown");
                                                                          }

    @Test
                                                                      public void testAddValueWithComparableShouldAddToFrequencyTable2() {
                                                                          // Setup
                                                                          Frequency frequency = new Frequency();
                                                                          String comparableValue = "testValue"; // String implements Comparable
                                                                          
                                                                          // Exercise
                                                                          frequency.addValue(comparableValue);
                                                                          
                                                                          // Verify
                                                                          // If the method works correctly, count should be 1
                                                                          // If mutated (commented out), count would remain 0
                                                                          assertEquals("Comparable value should be added to frequency table", 
                                                                                       1, 
                                                                                       frequency.getCount(comparableValue));
                                                                      }

    @Test
                                                                      public void testAddValueWithNonComparableShouldThrowException1() {
                                                                          // Setup
                                                                          Frequency frequency = new Frequency();
                                                                          Object nonComparableValue = new Object(); // Object doesn't implement Comparable
                                                                          
                                                                          // Exercise & Verify
                                                                          try {
                                                                              frequency.addValue(nonComparableValue);
                                                                              fail("Expected IllegalArgumentException for non-Comparable object");
                                                                          } catch (IllegalArgumentException e) {
                                                                              assertEquals("Object must implement Comparable", e.getMessage());
                                                                          }
                                                                      }

    @Test
                                                                          public void testAddValueWithCustomComparator1() {
                                                                              // Create frequency with custom comparator
                                                                              Comparator<String> lengthComparator = Comparator.comparingInt(String::length);
                                                                              Frequency customFrequency = new Frequency(lengthComparator);
                                                                              
                                                                              // Add strings of different lengths
                                                                              customFrequency.addValue("short");
                                                                              customFrequency.addValue("longer");
                                                                              customFrequency.addValue("short"); // same length as first
                                                                              
                                                                              assertEquals(2, customFrequency.getCount("short"));
                                                                              assertEquals(1, customFrequency.getCount("longer"));
                                                                          }

    @Test
                                                                      public void testAddValueWithComparableShouldAddToFrequencyTable3() {
                                                                          // Setup
                                                                          Frequency frequency = new Frequency();
                                                                          String testValue = "testString"; // String implements Comparable
                                                                          
                                                                          // Exercise
                                                                          try {
                                                                              frequency.addValue(testValue);
                                                                              
                                                                              // Verify
                                                                              // Check that the value was added to the frequency table
                                                                              long count = frequency.getCount(testValue);
                                                                              assertEquals("Comparable value should be added to frequency table", 1L, count);
                                                                          } catch (ClassCastException e) {
                                                                              fail("Should not throw ClassCastException for Comparable values");
                                                                          }
                                                                      }

    @Test
                                                                      public void testAddValueWithNonNumericComparable() {
                                                                          // Setup
                                                                          Frequency frequency = new Frequency();
                                                                          
                                                                          // Create a custom Comparable object that isn't numeric
                                                                          Comparable<String> nonNumericComparable = new Comparable<String>() {
                                                                              @Override
                                                                              public int compareTo(String o) {
                                                                                  return 0;
                                                                              }
                                                                              
                                                                              @Override
                                                                              public String toString() {
                                                                                  return "testComparable";
                                                                              }
                                                                          };
                                                                          
                                                                          // Test the original behavior should count this object
                                                                          frequency.addValue(nonNumericComparable);
                                                                          
                                                                          // Verify the object was counted
                                                                          assertEquals(1L, frequency.getCount("testComparable"));
                                                                          
                                                                          // The mutant would skip counting this object, so this test would fail
                                                                          // if the mutation is present (count would remain 0)
                                                                      }

    @Test
                                                                          public void testAddValueWithComparable() {
                                                                              // Setup
                                                                              Frequency frequency = new Frequency();
                                                                              String comparableValue = "testValue"; // String implements Comparable
                                                                              
                                                                              // Action
                                                                              frequency.addValue(comparableValue);
                                                                              
                                                                              // Verification
                                                                              assertEquals("Count should be 1 for added comparable value", 
                                                                                           1L, frequency.getCount(comparableValue));
                                                                          }

    @Test
                                                                      public void testAddValueCharHandlesAsComparable() {
                                                                          // Setup
                                                                          Frequency frequency = new Frequency();
                                                                          char testChar = 'a';
                                                                          
                                                                          // Action - add the char value
                                                                          frequency.addValue(testChar);
                                                                          
                                                                          // Verification - check count using different comparison methods
                                                                          // This verifies the char was properly stored as a Comparable
                                                                          assertEquals(1L, frequency.getCount(testChar)); // primitive char
                                                                          assertEquals(1L, frequency.getCount(Character.valueOf(testChar))); // Character object
                                                                          assertEquals(1L, frequency.getCount((Comparable<?>) testChar)); // as Comparable
                                                                          
                                                                          // Additional verification - check with different case to ensure proper comparison
                                                                          char upperCaseChar = 'A';
                                                                          frequency.addValue(upperCaseChar);
                                                                          assertEquals(1L, frequency.getCount(upperCaseChar));
                                                                          assertNotEquals(frequency.getCount(testChar), frequency.getCount(upperCaseChar));
                                                                          
                                                                          // Verify the values are properly ordered in the TreeMap
                                                                          Iterator valuesIter = frequency.valuesIterator();
                                                                          Object first = valuesIter.next();
                                                                          Object second = valuesIter.next();
                                                                          assertTrue(((Comparable) first).compareTo(second) < 0);
                                                                      }

    @Test
                                                                     public void testAddValueWithComparableObject3() {
                                                                         // Create frequency instance
                                                                         Frequency frequency = new Frequency();
                                                                         
                                                                         // Create a custom Comparable object
                                                                         class TestComparable implements Comparable<TestComparable> {
                                                                             private final int value;
                                                                             
                                                                             public TestComparable(int value) {
                                                                                 this.value = value;
                                                                             }
                                                                             
                                                                             @Override
                                                                             public int compareTo(TestComparable other) {
                                                                                 return Integer.compare(this.value, other.value);
                                                                             }
                                                                             
                                                                             @Override
                                                                             public boolean equals(Object obj) {
                                                                                 if (this == obj) return true;
                                                                                 if (!(obj instanceof TestComparable)) return false;
                                                                                 return this.value == ((TestComparable)obj).value;
                                                                             }
                                                                             
                                                                             @Override
                                                                             public int hashCode() {
                                                                                 return value;
                                                                             }
                                                                         }
                                                                         
                                                                         TestComparable comparable1 = new TestComparable(1);
                                                                         TestComparable comparable2 = new TestComparable(1); // equal to comparable1
                                                                         
                                                                         // Add first comparable object
                                                                         frequency.addValue(comparable1);
                                                                         assertEquals(1, frequency.getCount(comparable1));
                                                                         
                                                                         // Add equal comparable object - should increment count
                                                                         frequency.addValue(comparable2);
                                                                         assertEquals(2, frequency.getCount(comparable1));
                                                                         
                                                                         // Test with different comparable
                                                                         TestComparable comparable3 = new TestComparable(2);
                                                                         frequency.addValue(comparable3);
                                                                         assertEquals(1, frequency.getCount(comparable3));
                                                                     }

    @Test(expected = IllegalArgumentException.class)
                                                                     public void testAddValueWithNonComparableObject8() {
                                                                         // Create a frequency instance
                                                                         Frequency frequency = new Frequency();
                                                                         
                                                                         // Create a non-comparable object
                                                                         class NonComparable {}
                                                                         
                                                                         // This should throw IllegalArgumentException
                                                                         frequency.addValue(new NonComparable());
                                                                     }

    @Test
                                                                     public void testAddValueWithInteger() {
                                                                         Frequency frequency = new Frequency();
                                                                         Integer intValue = 5;
                                                                         frequency.addValue(intValue);
                                                                         assertEquals(1, frequency.getCount(intValue));
                                                                         
                                                                         // Add same value again
                                                                         frequency.addValue(intValue);
                                                                         assertEquals(2, frequency.getCount(intValue));
                                                                         
                                                                         // Verify it was converted to Long
                                                                         assertEquals(2, frequency.getCount(5L));
                                                                     }

    @Test
                                                                     public void testAddValueWithComparableShouldNotThrowException() {
                                                                         // Setup
                                                                         Frequency frequency = new Frequency();
                                                                         Comparable<String> comparableObject = "testString"; // String implements Comparable
                                                                         
                                                                         try {
                                                                             // Test
                                                                             frequency.addValue(comparableObject);
                                                                             // If we get here, test passes (no exception thrown)
                                                                         } catch (IllegalArgumentException e) {
                                                                             fail("Should not throw exception for Comparable object");
                                                                         }
                                                                     }

    @Test(expected = IllegalArgumentException.class)
                                                                     public void testAddValueWithNonComparableShouldThrowException2() {
                                                                         // Setup
                                                                         Frequency frequency = new Frequency();
                                                                         Object nonComparableObject = new Object(); // Object doesn't implement Comparable
                                                                         
                                                                         // Test - should throw exception
                                                                         frequency.addValue(nonComparableObject);
                                                                     }

    @Test
                                                                 public void testAddValueDetectsMutatedElse() {
                                                                     // Setup
                                                                     Frequency frequency = new Frequency();
                                                                     Integer testValue = 5;
                                                                     
                                                                     // First addition - should create new entry with count=1
                                                                     frequency.addValue(testValue);
                                                                     
                                                                     // Second addition - should increment to count=2
                                                                     frequency.addValue(testValue);
                                                                     
                                                                     // Verify the count is exactly 2 (would be 3 if mutant survives)
                                                                     assertEquals("Frequency count should be 2 after adding same value twice", 
                                                                                  2L, frequency.getCount(testValue));
                                                                     
                                                                     // Additional test for new value to ensure basic functionality
                                                                     Integer newValue = 10;
                                                                     frequency.addValue(newValue);
                                                                     assertEquals("Frequency count should be 1 for new value",
                                                                                  1L, frequency.getCount(newValue));
                                                                 }

    @Test
                                                                     public void testAddValueLongDetectsMutant() {
                                                                         // Setup
                                                                         Frequency frequency = new Frequency();
                                                                         Long testValue = 12345L;
                                                                         
                                                                         // First addition - should add new entry with count 1
                                                                         frequency.addValue(testValue);
                                                                         assertEquals("First addition should have count 1", 1, frequency.getCount(testValue));
                                                                         
                                                                         // Second addition - should increment count to 2
                                                                         frequency.addValue(testValue);
                                                                         assertEquals("Second addition should have count 2", 2, frequency.getCount(testValue));
                                                                         
                                                                         // Test with different value to ensure separate counting
                                                                         Long anotherValue = 67890L;
                                                                         frequency.addValue(anotherValue);
                                                                         assertEquals("Different value should have count 1", 1, frequency.getCount(anotherValue));
                                                                         assertEquals("Original value should still have count 2", 2, frequency.getCount(testValue));
                                                                     }

    @Test
                                                                 public void testAddValueLongDetectsMutant1() {
                                                                     // Setup
                                                                     Frequency frequency = new Frequency();
                                                                     Long testValue = 12345L;
                                                                     
                                                                     // Test adding the same value multiple times
                                                                     frequency.addValue(testValue);
                                                                     frequency.addValue(testValue);
                                                                     
                                                                     // Verify count - should be 2
                                                                     assertEquals("Count should be 2 after adding same value twice", 
                                                                                  2L, frequency.getCount(testValue));
                                                                     
                                                                     // Test with different values
                                                                     Long anotherValue = 67890L;
                                                                     frequency.addValue(anotherValue);
                                                                     
                                                                     // Verify counts
                                                                     assertEquals("Original value count should remain 2", 
                                                                                  2L, frequency.getCount(testValue));
                                                                     assertEquals("New value count should be 1", 
                                                                                  1L, frequency.getCount(anotherValue));
                                                                     
                                                                     // Test with null value (edge case)
                                                                     try {
                                                                         frequency.addValue((Long)null);
                                                                         fail("Expected NullPointerException");
                                                                     } catch (NullPointerException e) {
                                                                         // Expected behavior
                                                                     }
                                                                     
                                                                     // Verify previous counts weren't affected by failed addition
                                                                     assertEquals("Original value count should remain 2 after null test", 
                                                                                  2L, frequency.getCount(testValue));
                                                                     assertEquals("Second value count should remain 1 after null test", 
                                                                                  1L, frequency.getCount(anotherValue));
                                                                 }

    @Test
                                                                 public void testAddValueLongDetectsMutant2() {
                                                                     Frequency frequency = new Frequency();
                                                                     Long testValue = 12345L;
                                                                     
                                                                     // First addition - should create new entry with count=1
                                                                     frequency.addValue(testValue);
                                                                     assertEquals(1L, frequency.getCount(testValue));
                                                                     
                                                                     // Second addition - should increment existing entry to count=2
                                                                     frequency.addValue(testValue);
                                                                     assertEquals(2L, frequency.getCount(testValue));
                                                                     
                                                                     // Third addition - should increment to count=3
                                                                     frequency.addValue(testValue);
                                                                     assertEquals(3L, frequency.getCount(testValue));
                                                                     
                                                                     // Verify with different value to ensure isolation
                                                                     Long anotherValue = 67890L;
                                                                     frequency.addValue(anotherValue);
                                                                     assertEquals(1L, frequency.getCount(anotherValue));
                                                                     assertEquals(3L, frequency.getCount(testValue));
                                                                 }

    @Test
                                                                 public void testAddValueCharDetectsMutant() {
                                                                     // Setup
                                                                     Frequency frequency = new Frequency();
                                                                     char testChar = 'a';
                                                                     
                                                                     // First addition - count should be 1
                                                                     frequency.addValue(testChar);
                                                                     assertEquals("Count after first addition should be 1", 
                                                                         1L, frequency.getCount(testChar));
                                                                     
                                                                     // Second addition - count should be 2
                                                                     // This will detect the mutant if the else was incorrectly removed
                                                                     frequency.addValue(testChar);
                                                                     assertEquals("Count after second addition should be 2", 
                                                                         2L, frequency.getCount(testChar));
                                                                     
                                                                     // Verify with a different character to ensure isolation
                                                                     char anotherChar = 'b';
                                                                     frequency.addValue(anotherChar);
                                                                     assertEquals("Count for different char should be 1", 
                                                                         1L, frequency.getCount(anotherChar));
                                                                     assertEquals("Count for original char should remain 2", 
                                                                         2L, frequency.getCount(testChar));
                                                                 }

    @Test
                                                               public void testAddValueObjectIsDeprecated() throws Exception {
                                                                   // Get the Method object for addValue(Object)
                                                                   Method method = org.apache.commons.math.stat.Frequency.class.getMethod("addValue", Object.class);
                                                                   
                                                                   // Check for Deprecated annotation
                                                                   java.lang.annotation.Annotation deprecatedAnnotation = method.getAnnotation(java.lang.Deprecated.class);
                                                                   
                                                                   // Assert that the annotation exists
                                                                   org.junit.Assert.assertNotNull("addValue(Object) method should be marked as @Deprecated", deprecatedAnnotation);
                                                               }

    @Test
                                                               public void testAddValueObjectMethodIsDeprecated() throws NoSuchMethodException {
                                                                   // Get the method using reflection
                                                                   Method method = Frequency.class.getMethod("addValue", Object.class);
                                                                   
                                                                   // Check if the method has Deprecated annotation
                                                                   Deprecated deprecatedAnnotation = method.getAnnotation(Deprecated.class);
                                                                   
                                                                   // Assert that the annotation exists
                                                                   assertNotNull("addValue(Object) method should be marked as @Deprecated", deprecatedAnnotation);
                                                               }

    @Test
                                                               public void testAddValueCharIsDeprecated() throws NoSuchMethodException {
                                                                   // Get the method using reflection
                                                                   Method method = Frequency.class.getMethod("addValue", char.class);
                                                                   
                                                                   // Check if the method has @Deprecated annotation
                                                                   boolean isDeprecated = method.isAnnotationPresent(Deprecated.class);
                                                                   
                                                                   // Assert that the method is deprecated
                                                                   assertTrue("addValue(char) method should be marked as @Deprecated", isDeprecated);
                                                               }

    @Test
                                                           public void testAddValueLongMethodIsDeprecated() throws Exception {
                                                               // Get the method we want to test
                                                               Method method = org.apache.commons.math.stat.Frequency.class.getMethod("addValue", Long.class);
                                                               
                                                               // Check if the method has @Deprecated annotation
                                                               java.lang.annotation.Annotation[] annotations = method.getAnnotations();
                                                               boolean isDeprecated = false;
                                                               
                                                               for (java.lang.annotation.Annotation annotation : annotations) {
                                                                   if (annotation instanceof java.lang.Deprecated) {
                                                                       isDeprecated = true;
                                                                       break;
                                                                   }
                                                               }
                                                               
                                                               // Assert that the method is deprecated
                                                               assertTrue("addValue(Long) method should be marked as @Deprecated", isDeprecated);
                                                           }

    @Test
                                                       public void testAddValueLongMethodIsDeprecated1() throws Exception {
                                                           try {
                                                               // Get the method we want to test - using primitive long type
                                                               Method method = org.apache.commons.math.stat.Frequency.class.getMethod("addValue", long.class);
                                                               
                                                               // Check if the method has the Deprecated annotation
                                                               Deprecated deprecatedAnnotation = method.getAnnotation(Deprecated.class);
                                                               
                                                               // Assert that the annotation exists
                                                               assertNotNull("addValue(long) method should be marked as @Deprecated", deprecatedAnnotation);
                                                           } catch (NoSuchMethodException e) {
                                                               fail("addValue(long) method not found");
                                                           }
                                                       }

    @Test
                                                       public void testAddValueLongIsDeprecated() throws Exception {
                                                           // Get the addValue method that takes a long parameter
                                                           Class<?> frequencyClass = Class.forName("org.apache.commons.math.stat.Frequency");
                                                           Method[] methods = frequencyClass.getDeclaredMethods();
                                                           Method addValueLongMethod = null;
                                                           
                                                           for (Method method : methods) {
                                                               if (method.getName().equals("addValue")) {
                                                                   Class<?>[] params = method.getParameterTypes();
                                                                   if (params.length == 1 && params[0] == Long.TYPE) {
                                                                       addValueLongMethod = method;
                                                                       break;
                                                                   }
                                                               }
                                                           }
                                                           
                                                           assertNotNull("addValue(long) method should exist", addValueLongMethod);
                                                           
                                                           // Check for Deprecated annotation
                                                           java.lang.annotation.Annotation[] annotations = addValueLongMethod.getAnnotations();
                                                           boolean isDeprecated = false;
                                                           
                                                           for (java.lang.annotation.Annotation annotation : annotations) {
                                                               if (annotation.annotationType() == java.lang.Deprecated.class) {
                                                                   isDeprecated = true;
                                                                   break;
                                                               }
                                                           }
                                                           
                                                           assertTrue("addValue(long) method should be marked as @Deprecated", isDeprecated);
                                                       }

    @Test
                                                       public void testAddValueObjectMethodSignature() throws NoSuchMethodException {
                                                           // Get the method using reflection
                                                           Method method = Frequency.class.getMethod("addValue", Object.class);
                                                           
                                                           // Verify the method is public
                                                           assertTrue(Modifier.isPublic(method.getModifiers()));
                                                           
                                                           // Verify the method declares throwing IllegalArgumentException
                                                           Class<?>[] exceptionTypes = method.getExceptionTypes();
                                                           boolean throwsIllegalArgumentException = false;
                                                           for (Class<?> exceptionType : exceptionTypes) {
                                                               if (exceptionType.equals(IllegalArgumentException.class)) {
                                                                   throwsIllegalArgumentException = true;
                                                                   break;
                                                               }
                                                           }
                                                           assertTrue("Method should declare throwing IllegalArgumentException", 
                                                                     throwsIllegalArgumentException);
                                                       }

    @Test
                                                       public void testAddValueObjectWithNonComparable() {
                                                           Frequency frequency = new Frequency();
                                                           Object nonComparable = new Object(); // Object doesn't implement Comparable
                                                           
                                                           try {
                                                               frequency.addValue(nonComparable);
                                                               fail("Expected IllegalArgumentException to be thrown");
                                                           } catch (IllegalArgumentException e) {
                                                               assertEquals("Object must implement Comparable", e.getMessage());
                                                           }
                                                       }

    @Test
                                                       public void testAddValueObjectWithComparable() {
                                                           Frequency frequency = new Frequency();
                                                           Comparable<String> comparable = "test"; // String implements Comparable
                                                           
                                                           try {
                                                               frequency.addValue(comparable);
                                                               // No exception expected
                                                           } catch (IllegalArgumentException e) {
                                                               fail("No exception should be thrown for Comparable objects");
                                                           }
                                                           
                                                           // Verify the value was added to the frequency table
                                                           assertEquals(1, frequency.getCount(comparable));
                                                       }

    @Test
                                                       public void testAddValueSignatureThrowsIllegalArgumentException() throws Exception {
                                                           // Get the method using reflection
                                                           Method method = Frequency.class.getMethod("addValue", Object.class);
                                                           
                                                           // Verify the method declares IllegalArgumentException
                                                           Class<?>[] exceptionTypes = method.getExceptionTypes();
                                                           boolean throwsIllegalArgumentException = false;
                                                           for (Class<?> exceptionType : exceptionTypes) {
                                                               if (exceptionType.equals(IllegalArgumentException.class)) {
                                                                   throwsIllegalArgumentException = true;
                                                                   break;
                                                               }
                                                           }
                                                           
                                                           assertTrue("Method should declare IllegalArgumentException", 
                                                                     throwsIllegalArgumentException);
                                                       }

    @Test(expected = IllegalArgumentException.class)
                                                       public void testAddValueWithNonComparableObject9() {
                                                           Frequency frequency = new Frequency();
                                                           // Create a non-comparable object
                                                           Object nonComparable = new Object();
                                                           frequency.addValue(nonComparable);
                                                       }

    @Test
                                                       public void testAddValueWithComparableObject4() {
                                                           Frequency frequency = new Frequency();
                                                           // Test with a comparable object (String)
                                                           frequency.addValue("test");
                                                           assertEquals(1, frequency.getCount("test"));
                                                       }

    @Test
                                                       public void testAddValueWithInteger1() {
                                                           Frequency frequency = new Frequency();
                                                           // Test with Integer which should be converted to Long
                                                           frequency.addValue(Integer.valueOf(5));
                                                           assertEquals(1, frequency.getCount(5L)); // Check count using Long
                                                       }

    @Test
                                                       public void testAddValueObjectThrowsIllegalArgumentException() {
                                                           // Test with null value which should throw IllegalArgumentException
                                                           Frequency frequency = new Frequency();
                                                           thrown.expect(IllegalArgumentException.class);
                                                           thrown.expectMessage("Value cannot be null");
                                                           frequency.addValue((Object) null);
                                                       }

    @Test
                                                       public void testAddValueObjectWithInvalidComparable() {
                                                           // Test with an object that's not properly comparable
                                                           // This might throw IllegalArgumentException when TreeMap tries to compare it
                                                           Frequency frequency = new Frequency();
                                                           Object invalidObj = new Object(); // Object doesn't implement Comparable
                                                           
                                                           thrown.expect(IllegalArgumentException.class);
                                                           frequency.addValue(invalidObj);
                                                       }

    @Test
                                                       public void testAddValueObjectWithValidValue() {
                                                           // Test with valid object to ensure normal operation still works
                                                           Frequency frequency = new Frequency();
                                                           String validValue = "test";
                                                           
                                                           // Should not throw any exception
                                                           frequency.addValue(validValue);
                                                           
                                                           // Verify the value was added
                                                           assertEquals(1L, frequency.getCount(validValue));
                                                       }

    @Test
                                                       public void testAddValueObjectWithInvalidInput() {
                                                           Frequency frequency = new Frequency();
                                                           
                                                           // Test with invalid non-numeric object
                                                           thrown.expect(IllegalArgumentException.class);
                                                           frequency.addValue(new Object()); // This should throw in mutated version
                                                           
                                                           // The original version would likely throw ClassCastException or similar,
                                                           // so this test would fail on original but pass on mutated version
                                                       }

    @Test
                                                       public void testAddValueObjectWithNullInput() {
                                                           Frequency frequency = new Frequency();
                                                           
                                                           // Test with null input
                                                           thrown.expect(IllegalArgumentException.class);
                                                           frequency.addValue(null); // Should throw in mutated version
                                                           
                                                           // Original might throw NullPointerException, so this detects the mutation
                                                       }

    @Test
                                                       public void testAddValueObjectWithValidInput() throws Exception {
                                                           Frequency frequency = new Frequency();
                                                           
                                                           // Test with valid numeric input (should work in both versions)
                                                           frequency.addValue(10L); // Long
                                                           frequency.addValue(10); // Integer
                                                           frequency.addValue("10"); // String that can be parsed to Long
                                                           
                                                           // Verify the values were added
                                                           assertEquals(1, frequency.getCount(10L));
                                                           assertEquals(1, frequency.getCount(10));
                                                           assertEquals(1, frequency.getCount("10"));
                                                       }

    @Test
                                                       public void testAddValueObjectShouldNotThrowExceptionForValidInput() {
                                                           Frequency frequency = new Frequency();
                                                           // Valid input - should not throw exception
                                                           frequency.addValue("test");
                                                           frequency.addValue(123);
                                                           frequency.addValue(new Object());
                                                       }

    @Test
                                                       public void testAddValueObjectShouldThrowIllegalArgumentExceptionForNullInput() {
                                                           Frequency frequency = new Frequency();
                                                           // Expect IllegalArgumentException for null input
                                                           thrown.expect(IllegalArgumentException.class);
                                                           thrown.expectMessage("Value cannot be null");
                                                           frequency.addValue(null);
                                                       }

    @Test
                                                       public void testAddValueObjectShouldThrowIllegalArgumentExceptionForInvalidInput() {
                                                           Frequency frequency = new Frequency();
                                                           // Expect IllegalArgumentException for some invalid input
                                                           // (assuming the mutated version throws for certain cases)
                                                           thrown.expect(IllegalArgumentException.class);
                                                           thrown.expectMessage("Invalid value");
                                                           frequency.addValue(new Object() {
                                                               @Override
                                                               public String toString() {
                                                                   throw new RuntimeException("Bad object");
                                                               }
                                                           });
                                                       }

    @Test
                                                       public void testAddValueObjectWithValidCharacter() {
                                                           Frequency frequency = new Frequency();
                                                           // Valid character object should not throw exception
                                                           frequency.addValue('a'); // This should work in both original and mutated version
                                                       }

    @Test
                                                       public void testAddValueObjectWithInvalidObject() {
                                                           Frequency frequency = new Frequency();
                                                           // Expect IllegalArgumentException for invalid object that can't be converted to Character
                                                           thrown.expect(IllegalArgumentException.class);
                                                           frequency.addValue(new Object()); // This should throw exception in mutated version
                                                       }

    @Test
                                                       public void testAddValueObjectWithNull() {
                                                           Frequency frequency = new Frequency();
                                                           // Null should also throw IllegalArgumentException in mutated version
                                                           thrown.expect(IllegalArgumentException.class);
                                                           frequency.addValue(null);
                                                       }

    @Test
                                                       public void testAddValueObjectWithNonCharacterString() {
                                                           Frequency frequency = new Frequency();
                                                           // String that can't be converted to single character
                                                           thrown.expect(IllegalArgumentException.class);
                                                           frequency.addValue("invalid string"); // String with length != 1
                                                       }

    @Test
                                                  public void testAddValueWithComparableShouldCallCorrectMethod() {
                                                      // Create a spy of Frequency to verify method calls
                                                      Frequency frequencySpy = spy(new Frequency());
                                                      
                                                      // Create a test Comparable object
                                                      Comparable<String> testComparable = "testValue";
                                                      
                                                      // Call the method
                                                      frequencySpy.addValue(testComparable);
                                                      
                                                      // Verify that addValue(Comparable) was called directly
                                                      // This would fail if the mutant is present (this.addValue)
                                                      verify(frequencySpy).addValue((Comparable<?>) testComparable);
                                                      
                                                      // Also verify the value was actually added to the frequency table
                                                      assertEquals(1, frequencySpy.getCount(testComparable));
                                                  }

    @Test
                                                  public void testAddValueWithNonComparableShouldThrowException3() {
                                                      Frequency frequency = new Frequency();
                                                      Object nonComparable = new Object();
                                                      
                                                      try {
                                                          frequency.addValue(nonComparable);
                                                          fail("Expected IllegalArgumentException");
                                                      } catch (IllegalArgumentException e) {
                                                          assertEquals("Object must implement Comparable", e.getMessage());
                                                      }
                                                  }

    @Test
                                                  public void testAddValueWithNullShouldThrowException3() {
                                                      Frequency frequency = new Frequency();
                                                      
                                                      try {
                                                          frequency.addValue(null);
                                                          fail("Expected IllegalArgumentException");
                                                      } catch (IllegalArgumentException e) {
                                                          assertEquals("Object must implement Comparable", e.getMessage());
                                                      }
                                                  }

    @Test
                                                      public void testAddValueCallsCorrectOverloadedMethod() {
                                                          // Create a spy to track method calls
                                                          Frequency frequency = spy(new Frequency());
                                                          
                                                          // Test with a Comparable value
                                                          Comparable<String> comparableValue = "test";
                                                          frequency.addValue(comparableValue);
                                                          
                                                          // Verify the call was routed to addValue(Comparable<?>)
                                                          // This will fail if the mutation changes the call behavior
                                                          verify(frequency).addValue((Comparable<?>) comparableValue);
                                                          
                                                          // Test with a non-Comparable value that needs conversion
                                                          Integer intValue = 5;
                                                          frequency.addValue(intValue);
                                                          
                                                          // The original should convert to Long and call addValue(Object)
                                                          // The mutant might incorrectly route to addValue(Comparable<?>)
                                                          verify(frequency).addValue(Long.valueOf(intValue.longValue()));
                                                      }

    @Test
                                                      public void testAddValueLongVsComparable() {
                                                          // Create a spy of Frequency to verify method calls
                                                          Frequency frequencySpy = spy(new Frequency());
                                                          
                                                          // Create test values
                                                          long longValue = 100L;
                                                          int intValue = 100;
                                                          char charValue = 'a';
                                                          
                                                          // Test with long value
                                                          frequencySpy.addValue(longValue);
                                                          // Verify the correct addValue method was called
                                                          verify(frequencySpy).addValue((long)longValue);
                                                          
                                                          // Test with int value
                                                          frequencySpy.addValue(intValue);
                                                          // Verify it calls addValue(long) after conversion, not addValue(Comparable)
                                                          verify(frequencySpy).addValue((long)intValue);
                                                          
                                                          // Test with char value
                                                          frequencySpy.addValue(charValue);
                                                          // Verify it calls addValue(long) after conversion, not addValue(Comparable)
                                                          verify(frequencySpy).addValue((long)charValue);
                                                          
                                                          // Additional verification that the values were actually added to freqTable
                                                          assertEquals(1, frequencySpy.getCount(longValue));
                                                          assertEquals(1, frequencySpy.getCount(intValue));
                                                          assertEquals(1, frequencySpy.getCount(charValue));
                                                      }

    @Test
                                                  public void testAddValueWithLongConversion() {
                                                      // Setup
                                                      Frequency frequency = new Frequency();
                                                      Long testValue = 12345L;
                                                      
                                                      // Create a spy to monitor method calls
                                                      Frequency spyFrequency = spy(frequency);
                                                      
                                                      // Action
                                                      spyFrequency.addValue(testValue);
                                                      
                                                      // Verification
                                                      // Verify the correct overloaded method was called
                                                      verify(spyFrequency).addValue((Comparable<?>) testValue);
                                                      
                                                      // Verify the value was actually added to freqTable
                                                      assertEquals(1L, spyFrequency.getCount(testValue));
                                                      
                                                      // Verify no other unexpected interactions occurred
                                                      verifyNoMoreInteractions(spyFrequency);
                                                  }

    @Test
                                                  public void testAddValueMutantDetection() {
                                                      // Create a spy of Frequency that will help us track method calls
                                                      Frequency frequency = new Frequency() {
                                                          @Override
                                                          public void addValue(Comparable<?> v) {
                                                              // Override to track calls to this specific method
                                                              super.addValue(v);
                                                          }
                                                      };
                                                      
                                                      // Create a second instance to test the mutation
                                                      Frequency frequencyWithMutation = new Frequency() {
                                                          @Override
                                                          public void addValue(Comparable<?> v) {
                                                              // This simulates the mutated version using 'this'
                                                              this.addValue(v);
                                                          }
                                                      };
                                                      
                                                      // Test original behavior
                                                      frequency.addValue(5L);  // Should call parent class implementation
                                                      assertEquals(1, frequency.getCount(5L));  // Verify value was added
                                                      
                                                      // Test mutated behavior - this would cause infinite recursion in the real mutation
                                                      try {
                                                          frequencyWithMutation.addValue(10L);
                                                          fail("Expected StackOverflowError due to infinite recursion");
                                                      } catch (StackOverflowError e) {
                                                          // Expected behavior for the mutated version
                                                      }
                                                      
                                                      // Additional test to verify normal behavior with different types
                                                      Frequency normalFrequency = new Frequency();
                                                      normalFrequency.addValue(5);
                                                      normalFrequency.addValue(10L);
                                                      normalFrequency.addValue('a');
                                                      
                                                      assertEquals(1, normalFrequency.getCount(5));
                                                      assertEquals(1, normalFrequency.getCount(10L));
                                                      assertEquals(1, normalFrequency.getCount('a'));
                                                  }

    @Test
                                                      public void testAddValueCharInheritanceBehavior() {
                                                          // Create a subclass that overrides behavior
                                                          class TestFrequency extends Frequency {
                                                              @Override
                                                              public void addValue(Comparable<?> v) {
                                                                  // Override to change behavior
                                                                  throw new RuntimeException("Mutant behavior detected");
                                                              }
                                                          }
                                                          
                                                          TestFrequency freq = new TestFrequency();
                                                          char testChar = 'a';
                                                          
                                                          try {
                                                              freq.addValue(testChar);
                                                              // If we get here, the original implementation was used (correct)
                                                              assertEquals(1L, freq.getCount(testChar));
                                                          } catch (RuntimeException e) {
                                                              fail("Mutant behavior detected - this.addValue(Comparable<?>) was called instead of addValue(Object)");
                                                          }
                                                      }

    @Test
                                                 public void testAddValueCharCallsCorrectMethod() {
                                                     // Create a subclass that tracks which addValue method is called
                                                     class TestFrequency extends Frequency {
                                                         boolean objectMethodCalled = false;
                                                         boolean comparableMethodCalled = false;
                                                         
                                                         @Override
                                                         public synchronized void addValue(Object v) {
                                                             objectMethodCalled = true;
                                                             super.addValue(v);
                                                         }
                                                         
                                                         @Override
                                                         public synchronized void addValue(Comparable<?> v) {
                                                             comparableMethodCalled = true;
                                                             super.addValue(v);
                                                         }
                                                     }
                                                     
                                                     TestFrequency freq = new TestFrequency();
                                                     char testChar = 'a';
                                                     
                                                     freq.addValue(testChar);
                                                     
                                                     // The original code should call addValue(Object) via Character.valueOf()
                                                     // The mutant using this.addValue would behave the same in this case,
                                                     // but we can verify the expected call path
                                                     assertTrue("Should call addValue(Object) method", 
                                                               freq.objectMethodCalled);
                                                     assertFalse("Should not call addValue(Comparable<?>) method", 
                                                                freq.comparableMethodCalled);
                                                     
                                                     // Verify the value was actually added
                                                     assertEquals(1L, freq.getCount(testChar));
                                                 }

    @Test
                                                 public void testAddValueWithNullInput() {
                                                     Frequency frequency = new Frequency();
                                                     
                                                     // Set expectation for original behavior (should not throw exception)
                                                     // But we expect the mutant to throw IllegalArgumentException
                                                     
                                                     thrown.expect(IllegalArgumentException.class);
                                                     thrown.expectMessage("Object must implement Comparable");
                                                     
                                                     // Call method with null input
                                                     frequency.addValue((Object)null);
                                                     
                                                     // If we reach here in original code, the test would fail for mutant
                                                     // If mutant exists, exception will be thrown as expected
                                                 }

    @Test(expected = NullPointerException.class)
                                                 public void testAddValueWithNullShouldThrowException4() {
                                                     // This test should pass with original code (throws NPE) 
                                                     // and fail with mutated code (handles null)
                                                     Frequency frequency = new Frequency();
                                                     frequency.addValue((Object)null);
                                                 }

    @Test
                                                 public void testAddValueWithNonNullComparable1() {
                                                     // Test normal behavior remains unchanged
                                                     Frequency frequency = new Frequency();
                                                     Long testValue = 123L;
                                                     
                                                     // Verify initial count is 0
                                                     assertEquals(0, frequency.getCount(testValue));
                                                     
                                                     // Add value and verify count increases
                                                     frequency.addValue(testValue);
                                                     assertEquals(1, frequency.getCount(testValue));
                                                     
                                                     // Add again and verify count increases
                                                     frequency.addValue(testValue);
                                                     assertEquals(2, frequency.getCount(testValue));
                                                 }

    @Test
                                                 public void testAddValueWithNonComparableObject10() {
                                                     // Test behavior with non-Comparable objects
                                                     Frequency frequency = new Frequency();
                                                     Object nonComparable = new Object();
                                                     
                                                     try {
                                                         frequency.addValue(nonComparable);
                                                         // Should throw ClassCastException when trying to add to TreeMap
                                                         fail("Expected ClassCastException");
                                                     } catch (ClassCastException e) {
                                                         // Expected behavior
                                                     }
                                                 }

    @Test
                                                 public void testAddValueWithNullInput1() {
                                                     // Setup
                                                     Frequency frequency = new Frequency();
                                                     
                                                     // Test null input - should either throw NPE (original) or handle it (mutant)
                                                     try {
                                                         frequency.addValue((Object)null);
                                                         // If we get here, the mutant survived (null check worked)
                                                         // Verify the null wasn't added to frequency table
                                                         assertEquals(0, frequency.getCount(null));
                                                     } catch (NullPointerException e) {
                                                         // Original behavior - test fails if exception is thrown
                                                         fail("NullPointerException was thrown - mutant not detected");
                                                     }
                                                 }

    @Test
                                                 public void testAddValueWithNonNullComparable2() {
                                                     // Setup
                                                     Frequency frequency = new Frequency();
                                                     Long testValue = 123L;
                                                     
                                                     // Test non-null Comparable input
                                                     frequency.addValue(testValue);
                                                     
                                                     // Verify the value was added correctly
                                                     assertEquals(1, frequency.getCount(testValue));
                                                 }

    @Test
                                                 public void testAddValueWithNonComparableObject11() {
                                                     // Setup
                                                     Frequency frequency = new Frequency();
                                                     Object nonComparable = new Object();
                                                     
                                                     // Test non-Comparable input
                                                     try {
                                                         frequency.addValue(nonComparable);
                                                         fail("Expected ClassCastException for non-Comparable input");
                                                     } catch (ClassCastException e) {
                                                         // Expected behavior
                                                     }
                                                 }

    @Test
                                                 public void testAddValueWithNull() {
                                                     // Setup
                                                     Frequency frequency = new Frequency();
                                                     
                                                     // Action - add null value
                                                     frequency.addValue((Object)null);
                                                     
                                                     // Verification
                                                     // Original code would either throw exception or add null to freqTable
                                                     // Mutant would skip adding null, so count should be 0
                                                     assertEquals(0, frequency.getCount(null));
                                                     
                                                     // Also verify sum frequency remains 0
                                                     assertEquals(0, frequency.getSumFreq());
                                                 }

    @Test
                                                 public void testAddValueWithNonNullComparable3() {
                                                     // Setup
                                                     Frequency frequency = new Frequency();
                                                     Long value = 123L;
                                                     
                                                     // Action - add non-null comparable
                                                     frequency.addValue(value);
                                                     
                                                     // Verification - should be added normally
                                                     assertEquals(1, frequency.getCount(value));
                                                     assertEquals(1, frequency.getSumFreq());
                                                 }

    @Test(expected = NullPointerException.class)
                                                 public void testAddValueWithNullShouldThrowException5() {
                                                     // This test will pass with original code (throws NPE) 
                                                     // and fail with mutated code (handles null)
                                                     Frequency frequency = new Frequency();
                                                     frequency.addValue((Object)null);
                                                 }

    @Test
                                                 public void testAddValueWithCharacterShouldAddToTable() {
                                                     Frequency frequency = new Frequency();
                                                     char testChar = 'a';
                                                     
                                                     // Verify initial count is 0
                                                     assertEquals(0, frequency.getCount(testChar));
                                                     
                                                     // Add the value
                                                     frequency.addValue(testChar);
                                                     
                                                     // Verify count increased to 1
                                                     assertEquals(1, frequency.getCount(testChar));
                                                 }

    @Test
                                                 public void testAddValueWithNonComparableShouldNotAdd() {
                                                     Frequency frequency = new Frequency();
                                                     Object nonComparable = new Object();
                                                     
                                                     // Verify initial count is 0
                                                     assertEquals(0, frequency.getCount(nonComparable));
                                                     
                                                     // Add the value - should not be added since it's not Comparable
                                                     frequency.addValue(nonComparable);
                                                     
                                                     // Verify count remains 0
                                                     assertEquals(0, frequency.getCount(nonComparable));
                                                 }

    @Test
                                            public void testAddValueWithNullShouldThrowIllegalArgumentException() {
                                                // The mutated version should throw IllegalArgumentException for null input
                                                // rather than NullPointerException
                                                Frequency frequency = new Frequency();  // Create local Frequency instance
                                                try {
                                                    frequency.addValue(null);
                                                    fail("Expected IllegalArgumentException for null input");
                                                } catch (IllegalArgumentException e) {
                                                    assertEquals("Value not comparable to existing values.", e.getMessage());
                                                    // Verify freqTable remains empty
                                                    assertTrue(frequency.getSumFreq() == 0);
                                                    throw e;
                                                }
                                            }

    @Test
                                            public void testAddValueWithNullShouldNotModifyFrequencyTable1() {
                                                // Setup - create frequency table and add some values first
                                                Frequency frequency = new Frequency();
                                                frequency.addValue(1);
                                                frequency.addValue(2L);
                                                
                                                long initialSum = frequency.getSumFreq();
                                                
                                                try {
                                                    frequency.addValue(null);
                                                    fail("Expected IllegalArgumentException");
                                                } catch (IllegalArgumentException e) {
                                                    // Verify table wasn't modified
                                                    assertEquals(initialSum, frequency.getSumFreq());
                                                    assertEquals(1L, frequency.getCount(1));
                                                    assertEquals(1L, frequency.getCount(2L));
                                                    assertNull(frequency.getCount(null));
                                                }
                                            }

    @Test
                                            public void testAddValueWithNonComparableObject12() {
                                                // Create a non-comparable object
                                                Object nonComparable = new Object() {
                                                    @Override
                                                    public String toString() {
                                                        return "NonComparableObject";
                                                    }
                                                };
                                                
                                                Frequency frequency = new Frequency();
                                                
                                                // Expect IllegalArgumentException for original code
                                                thrown.expect(IllegalArgumentException.class);
                                                thrown.expectMessage("Value not comparable to existing values.");
                                                
                                                // This would throw ClassCastException in mutated version
                                                frequency.addValue(nonComparable);
                                            }

    @Test
                                        public void testAddValueWithComparableShouldAddToFrequencyTable4() {
                                            // Setup
                                            Frequency frequency = new Frequency();
                                            Long testValue = 123L;
                                            
                                            // Action
                                            frequency.addValue(testValue);
                                            
                                            // Verification
                                            // Check if the value was actually added to the frequency table
                                            long count = frequency.getCount(testValue);
                                            assertEquals("Comparable value should be added to frequency table", 1L, count);
                                            
                                            // Additional check to ensure the freqTable is not empty
                                            assertTrue("Frequency table should not be empty after adding value", 
                                                       frequency.getSumFreq() > 0);
                                        }

    @Test
                                       public void testAddValueWithComparableShouldAddToTable() {
                                           // Arrange
                                           Frequency frequency = new Frequency();
                                           String comparableValue = "test"; // String implements Comparable
                                           
                                           // Act
                                           frequency.addValue(comparableValue);
                                           
                                           // Assert
                                           // Verify the value was added by checking count
                                           assertEquals(1L, frequency.getCount(comparableValue));
                                       }

    @Test(expected = IllegalArgumentException.class)
                                       public void testAddValueWithNonComparableShouldThrowException4() {
                                           // Arrange
                                           Frequency frequency = new Frequency();
                                           Object nonComparableValue = new Object(); // Object doesn't implement Comparable
                                           
                                           // Act & Assert
                                           frequency.addValue(nonComparableValue);
                                       }

    @Test
                                       public void testAddValueWithComparableShouldNotThrowException1() {
                                           // Arrange
                                           Frequency frequency = new Frequency();
                                           Integer comparableValue = 123; // Integer implements Comparable
                                           
                                           try {
                                               // Act
                                               frequency.addValue(comparableValue);
                                               // If we get here, the test passes (no exception thrown)
                                               assertTrue(true);
                                           } catch (IllegalArgumentException e) {
                                               // If exception is thrown, test fails
                                               fail("Should not throw exception for Comparable objects");
                                           }
                                       }

    @Test
                                       public void testAddValueWithNonComparableObject13() {
                                           // Create a non-Comparable object
                                           class NonComparable {}
                                           Object nonComparable = new NonComparable();
                                           
                                           // Create Frequency instance
                                           Frequency frequency = new Frequency();
                                           
                                           // Try to add the non-Comparable object
                                           try {
                                               frequency.addValue(nonComparable);
                                               
                                               // If we get here, the mutant survived (since original would throw ClassCastException)
                                               try {
                                                   // Use reflection to access private freqTable field
                                                   Field field = frequency.getClass().getDeclaredField("freqTable");
                                                   field.setAccessible(true);
                                                   @SuppressWarnings("unchecked")
                                                   TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) field.get(frequency);
                                                   
                                                   // Assert the table is empty (original behavior)
                                                   assertTrue("Non-Comparable object should not be added to freqTable", 
                                                             freqTable.isEmpty());
                                                   
                                               } catch (NoSuchFieldException | IllegalAccessException e) {
                                                   fail("Failed to access freqTable field: " + e);
                                               }
                                               
                                           } catch (ClassCastException e) {
                                               // This is expected behavior for original code
                                               // Mutant would not throw this exception
                                           } catch (Exception e) {
                                               fail("Unexpected exception: " + e);
                                           }
                                       }

    @Test
                                       public void testAddValueWithComparableShouldAddToFreqTable() throws Exception {
                                           // Setup
                                           Frequency frequency = new Frequency();
                                           Long testValue = 123L;
                                           
                                           // Action
                                           frequency.addValue(testValue);
                                           
                                           // Use reflection to access private freqTable field
                                           Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                           freqTableField.setAccessible(true);
                                           @SuppressWarnings("unchecked")
                                           TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                                           
                                           // Verification
                                           assertTrue("Frequency table should contain the added value", freqTable.containsKey(testValue));
                                           assertEquals("Count should be 1 for newly added value", 1, (long)freqTable.get(testValue));
                                       }

    @Test
                                       public void testAddValueWithNonComparableShouldNotAddToFreqTable() {
                                           // Setup
                                           Frequency frequency = new Frequency();
                                           Object nonComparable = new Object(); // Object doesn't implement Comparable
                                           
                                           // Action
                                           frequency.addValue(nonComparable);
                                           
                                           // Verification
                                           assertEquals("Frequency count should be 0 for non-Comparable value", 
                                                      0, frequency.getCount(nonComparable));
                                       }

    @Test
                                       public void testAddValueObject_shouldOnlyAddComparableObjects() throws Exception {
                                           // Setup
                                           Frequency frequency = new Frequency();
                                           Object comparableObj = "testString"; // String implements Comparable
                                           Object nonComparableObj = new Object(); // Object doesn't implement Comparable
                                           
                                           // Exercise
                                           frequency.addValue(comparableObj);
                                           frequency.addValue(nonComparableObj);
                                           
                                           // Use reflection to access private freqTable field
                                           Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                           freqTableField.setAccessible(true);
                                           @SuppressWarnings("unchecked")
                                           TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                                           
                                           // Verify
                                           // Check that comparable object was added (would fail with mutant)
                                           assertTrue("Comparable object should be in freqTable", 
                                               freqTable.containsKey(comparableObj));
                                               
                                           // Check that non-comparable object was not added
                                           assertFalse("Non-comparable object should not be in freqTable",
                                               freqTable.containsKey(nonComparableObj));
                                               
                                           // Additional check that exactly one entry exists (would fail with mutant)
                                           assertEquals("Should have exactly one entry", 1, freqTable.size());
                                       }

    @Test
                                       public void testAddValueWithProperComparableShouldWork() {
                                           Frequency frequency = new Frequency();
                                           Integer properComparable = 42; // Integer implements Comparable<Integer>
                                           
                                           // This should work in both original and mutated code
                                           frequency.addValue(properComparable);
                                           
                                           // Verify it was added by checking count
                                           assertEquals(1, frequency.getCount(42));
                                       }

    @Test(expected = IllegalArgumentException.class)
                                       public void testAddValueWithRawComparable4() {
                                           // Create a raw Comparable implementation
                                           class RawComparable implements Comparable {
                                               private final int value;
                                               
                                               public RawComparable(int value) {
                                                   this.value = value;
                                               }
                                               
                                               @Override
                                               public int compareTo(Object o) {
                                                   RawComparable other = (RawComparable) o;
                                                   return Integer.compare(this.value, other.value);
                                               }
                                           }
                                           
                                           Frequency frequency = new Frequency();
                                           // This should fail in original code (due to type safety check)
                                           // but pass in mutant code (only checking raw Comparable)
                                           frequency.addValue(new RawComparable(1));
                                           
                                           // If we reach here, the mutant survived (wrong behavior)
                                           fail("Mutant survived - raw Comparable was accepted");
                                       }

    @Test
                                       public void testAddValueWithGenericComparable3() {
                                           // Create a proper generic Comparable implementation
                                           class GenericComparable implements Comparable<GenericComparable> {
                                               private final int value;
                                               
                                               public GenericComparable(int value) {
                                                   this.value = value;
                                               }
                                               
                                               @Override
                                               public int compareTo(GenericComparable o) {
                                                   return Integer.compare(this.value, o.value);
                                               }
                                           }
                                           
                                           Frequency frequency = new Frequency();
                                           // This should work in both original and mutant code
                                           frequency.addValue(new GenericComparable(1));
                                           
                                           // Verify the value was added
                                           assertEquals(1L, frequency.getCount(new GenericComparable(1)));
                                       }

    @Test
                                   public void testAddValueWithRawComparableShouldNotBeAdded() {
                                       // Create a raw Comparable implementation
                                       Comparable rawComparable = new Comparable() {
                                           @Override
                                           public int compareTo(Object o) {
                                               return 0;
                                           }
                                       };
                                       
                                       Frequency frequency = new Frequency();
                                       
                                       // Try to add the raw comparable
                                       frequency.addValue(rawComparable);
                                       
                                       // Verify it wasn't added (original behavior)
                                       // The mutated version would add it to freqTable
                                       assertEquals(0, frequency.getCount(rawComparable));
                                       
                                       // Also verify sum frequency remains 0
                                       assertEquals(0, frequency.getSumFreq());
                                   }

    @Test
                                       public void testAddValueWithDifferentComparableTypes1() {
                                           Frequency frequency = new Frequency();
                                           
                                           // Test with raw Comparable implementation
                                           class RawComparable implements Comparable {
                                               @Override
                                               public int compareTo(Object o) {
                                                   return 0;
                                               }
                                           }
                                           RawComparable raw = new RawComparable();
                                           frequency.addValue(raw);
                                           assertEquals(1, frequency.getCount(raw));
                                           
                                           // Test with parameterized Comparable implementation
                                           class ParamComparable implements Comparable<String> {
                                               @Override
                                               public int compareTo(String o) {
                                                   return 0;
                                               }
                                           }
                                           ParamComparable param = new ParamComparable();
                                           frequency.addValue(param);
                                           assertEquals(1, frequency.getCount(param));
                                           
                                           // Test with non-Comparable object
                                           class NonComparable {}
                                           NonComparable nonComp = new NonComparable();
                                           try {
                                               frequency.addValue(nonComp);
                                               fail("Expected ClassCastException for non-Comparable object");
                                           } catch (ClassCastException e) {
                                               // Expected behavior
                                           }
                                           
                                           // Test with null (should throw NPE)
                                           try {
                                               frequency.addValue(null);
                                               fail("Expected NullPointerException");
                                           } catch (NullPointerException e) {
                                               // Expected behavior
                                           }
                                       }

    @Test
                                       public void testAddValueWithParameterizedComparable1() {
                                           // Create a custom Comparable implementation that would behave differently
                                           // between raw and parameterized type checks
                                           class TestComparable<T> implements Comparable<T> {
                                               @Override
                                               public int compareTo(T o) {
                                                   return 0;
                                               }
                                           }
                                           
                                           Frequency frequency = new Frequency();
                                           TestComparable<String> testObj = new TestComparable<>();
                                           
                                           // This should be added to the frequency table in both original and mutant,
                                           // but we're testing the type checking behavior
                                           frequency.addValue(testObj);
                                           
                                           // Verify the object was added by checking its count
                                           assertEquals(1L, frequency.getCount(testObj));
                                           
                                           // The key difference would be in how the type checking is done internally,
                                           // but since the method is void, we verify the side effect (addition to freqTable)
                                           // If the mutant fails to properly recognize the parameterized Comparable,
                                           // this test would fail as the object wouldn't be added
                                       }

    @Test
                                       public void testAddValueWithCharacter() {
                                           Frequency frequency = new Frequency();
                                           char testChar = 'a';
                                           
                                           // This tests the specific line mentioned in the original code
                                           frequency.addValue(testChar);
                                           
                                           // Verify the Character was added
                                           assertEquals(1L, frequency.getCount(testChar));
                                       }

    @Test
                                       public void testAddValueWithNonComparable2() {
                                           Frequency frequency = new Frequency();
                                           Object nonComparable = new Object();
                                           
                                           // This should still work (though might not be added to freqTable if it requires Comparable)
                                           frequency.addValue(nonComparable);
                                           
                                           // Verify behavior - depends on class implementation
                                           // If class only stores Comparables, count would be 0
                                           // If it stores all Objects, count would be 1
                                           // This part is unclear from given info, so we keep it basic
                                           assertTrue(frequency.getCount(nonComparable) >= 0);
                                       }

    @Test
                                  public void testAddValueWithRawComparableShouldThrowException1() {
                                      // Define a simple class that doesn't implement Comparable
                                      class NonComparable {}
                                      
                                      Frequency frequency = new Frequency();
                                      NonComparable nonComparable = new NonComparable();
                                      
                                      // Expect IllegalArgumentException for original code
                                      thrown.expect(IllegalArgumentException.class);
                                      thrown.expectMessage("Object must implement Comparable");
                                      
                                      frequency.addValue(nonComparable);
                                  }

    @Test
                                  public void testAddValueWithRawComparable5() {
                                      Frequency frequency = new Frequency();
                                      
                                      // Create a simple Comparable implementation
                                      class TestComparable implements Comparable<TestComparable> {
                                          private final int value;
                                          
                                          public TestComparable(int value) {
                                              this.value = value;
                                          }
                                          
                                          @Override
                                          public int compareTo(TestComparable o) {
                                              return Integer.compare(this.value, o.value);
                                          }
                                          
                                          @Override
                                          public boolean equals(Object obj) {
                                              if (this == obj) return true;
                                              if (!(obj instanceof TestComparable)) return false;
                                              TestComparable that = (TestComparable) obj;
                                              return value == that.value;
                                          }
                                          
                                          @Override
                                          public int hashCode() {
                                              return value;
                                          }
                                      }
                                      
                                      TestComparable comp1 = new TestComparable(42);
                                      
                                      // Add the comparable object
                                      frequency.addValue(comp1);
                                      
                                      // Verify it was added correctly by checking count
                                      assertEquals(1L, frequency.getCount(comp1));
                                      
                                      // Add another instance with same value
                                      TestComparable comp2 = new TestComparable(42);
                                      frequency.addValue(comp2);
                                      
                                      // Verify count increased
                                      assertEquals(2L, frequency.getCount(comp1));
                                  }

    @Test
                                  public void testAddValueWithNonComparableObject14() {
                                      Frequency frequency = new Frequency();
                                      Object nonComparable = new Object(); // Object doesn't implement Comparable
                                      
                                      thrown.expect(IllegalArgumentException.class);
                                      thrown.expectMessage("Object must implement Comparable");
                                      frequency.addValue(nonComparable);
                                  }

    @Test
                                  public void testAddValueWithComparableObject5() {
                                      Frequency frequency = new Frequency();
                                      Comparable<String> comparable = "test"; // String implements Comparable
                                      
                                      // This should pass without exception
                                      frequency.addValue(comparable);
                                      
                                      // Verify the value was added by checking count
                                      assertEquals(1, frequency.getCount(comparable));
                                  }

    @Test
                                  public void testAddValueWithIntegerObject() {
                                      Frequency frequency = new Frequency();
                                      Integer integerValue = 42; // Integer implements Comparable
                                      
                                      // This should pass without exception
                                      frequency.addValue(integerValue);
                                      
                                      // Verify the value was added by checking count
                                      assertEquals(1, frequency.getCount(integerValue));
                                  }

    @Test(expected = IllegalArgumentException.class)
                              public void testAddValueWithNonComparableObjectShouldThrowIllegalArgumentException() {
                                  // Create a non-comparable object
                                  class NonComparable {}
                                  Object nonComparable = new NonComparable();
                                  
                                  // Create frequency instance
                                  Frequency frequency = new Frequency();
                                  
                                  // This should throw IllegalArgumentException in original code,
                                  // but would throw ClassCastException in mutated code
                                  frequency.addValue(nonComparable);
                              }

    @Test
                              public void testAddValueWithNonComparableObject15() {
                                  // Setup
                                  Frequency frequency = new Frequency();
                                  Object nonComparableObject = new Object(); // Object doesn't implement Comparable
                                  
                                  try {
                                      // This should throw ClassCastException in the mutated version
                                      frequency.addValue(nonComparableObject);
                                      
                                      // If we get here, the original behavior is preserved (cast to Comparable)
                                      // Verify the value was added (original behavior)
                                      assertEquals(1, frequency.getCount(nonComparableObject));
                                  } catch (ClassCastException e) {
                                      // This indicates the mutant was caught - raw value was added without casting
                                      fail("Mutation detected: addValue should cast to Comparable but didn't");
                                  }
                              }

    @Test
                              public void testAddValueWithComparableObject6() {
                                  // Setup
                                  Frequency frequency = new Frequency();
                                  Long comparableValue = 123L; // Long implements Comparable
                                  
                                  // This should work in both original and mutated versions
                                  frequency.addValue(comparableValue);
                                  
                                  // Verify the value was added
                                  assertEquals(1, frequency.getCount(comparableValue));
                              }

    @Test(expected = ClassCastException.class)
                                  public void testAddValueWithNonComparableObject16() {
                                      // Create a non-Comparable object
                                      Object nonComparable = new Object();
                                      
                                      // Create frequency instance
                                      Frequency frequency = new Frequency();
                                      
                                      // This should throw ClassCastException in original version
                                      // but might fail differently in mutated version
                                      frequency.addValue(nonComparable);
                                  }

    @Test
                              public void testAddValueWithNonComparableObject17() {
                                  // Create a Frequency instance
                                  Frequency frequency = new Frequency();
                                  
                                  // Create a non-Comparable object
                                  Object nonComparable = new Object() {
                                      @Override
                                      public String toString() {
                                          return "NonComparableObject";
                                      }
                                  };
                                  
                                  try {
                                      // This should throw ClassCastException when the mutant is present
                                      // because TreeMap can't handle non-Comparable objects
                                      frequency.addValue(nonComparable);
                                      
                                      // If we get here, the test fails because the mutant survived
                                      // (it called addValue(Object) instead of addValue(Comparable))
                                      fail("Expected ClassCastException but none was thrown");
                                  } catch (ClassCastException e) {
                                      // This is expected behavior for the original code
                                      // because it tries to cast to Comparable first
                                      assertTrue(e.getMessage().contains("Comparable"));
                                  }
                              }

    @Test
                              public void testAddValueWithComparableObject7() {
                                  // Create a Frequency instance
                                  Frequency frequency = new Frequency();
                                  
                                  // Create a Comparable object
                                  String comparable = "TestString";
                                  
                                  try {
                                      // This should work fine in both original and mutated code
                                      frequency.addValue(comparable);
                                      
                                      // Verify the value was added correctly
                                      assertEquals(1L, frequency.getCount(comparable));
                                  } catch (ClassCastException e) {
                                      // This would indicate the test failed
                                      fail("Unexpected ClassCastException was thrown");
                                  }
                              }

    @Test
                                  public void testAddValueCharShouldStoreAsComparable() {
                                      // Create frequency object
                                      Frequency freq = new Frequency();
                                      
                                      // Add some char values
                                      freq.addValue('a');
                                      freq.addValue('b');
                                      freq.addValue('a'); // duplicate
                                      
                                      // Verify counts - this would work in both original and mutant
                                      assertEquals(2, freq.getCount('a'));
                                      assertEquals(1, freq.getCount('b'));
                                      
                                      // The key test - verify values are stored as Comparable in TreeMap
                                      // by checking the iteration order
                                      Iterator<?> it = freq.valuesIterator();
                                      Object first = it.next();
                                      Object second = it.next();
                                      
                                      // Verify the values are Character objects (auto-boxed via original method)
                                      assertTrue(first instanceof Character);
                                      assertTrue(second instanceof Character);
                                      
                                      // Verify proper ordering (would fail if stored as raw chars)
                                      assertTrue(((Comparable)first).compareTo(second) < 0);
                                      
                                      // Additional check that the values are stored as Comparable
                                      assertTrue(first instanceof Comparable);
                                      assertTrue(second instanceof Comparable);
                                  }

    @Test(expected = IllegalArgumentException.class)
                                 public void testAddValueWithNonComparable3() {
                                     Frequency frequency = new Frequency();
                                     Object nonComparable = new Object();
                                     frequency.addValue(nonComparable);
                                 }

    @Test
                             public void testAddValueWithDifferentComparableTypes2() {
                                 // Create a custom comparable class that implements raw Comparable
                                 class CustomComparable implements Comparable {
                                     private final int value;
                                     
                                     public CustomComparable(int value) {
                                         this.value = value;
                                     }
                                     
                                     @Override
                                     public int compareTo(Object o) {
                                         if (!(o instanceof CustomComparable)) {
                                             throw new ClassCastException();
                                         }
                                         return Integer.compare(value, ((CustomComparable) o).value);
                                     }
                                 }
                                 
                                 Frequency frequency = new Frequency();
                                 CustomComparable cc1 = new CustomComparable(1);
                                 CustomComparable cc2 = new CustomComparable(2);
                                 
                                 // Test that the original method handles different comparable types correctly
                                 frequency.addValue(cc1);
                                 frequency.addValue(cc2);
                                 
                                 // Verify counts are tracked correctly
                                 assertEquals(1L, frequency.getCount(cc1));
                                 assertEquals(1L, frequency.getCount(cc2));
                                 
                                 // Test with a different comparable type that would fail with raw Comparable
                                 try {
                                     frequency.addValue("string"); // String is Comparable<String>, not raw Comparable
                                     fail("Expected IllegalArgumentException");
                                 } catch (IllegalArgumentException e) {
                                     assertEquals("Value not comparable to existing values.", e.getMessage());
                                 }
                             }

    @Test
                             public void testAddValueWithDifferentComparableTypes3() {
                                 // Create a custom Comparable class that's not naturally comparable with Long
                                 class CustomComparable implements Comparable<CustomComparable> {
                                     private final int value;
                                     
                                     public CustomComparable(int value) {
                                         this.value = value;
                                     }
                                     
                                     @Override
                                     public int compareTo(CustomComparable o) {
                                         return Integer.compare(this.value, o.value);
                                     }
                                 }
                                 
                                 // Create a Frequency instance with a custom comparator that can handle both Long and CustomComparable
                                 Frequency freq = new Frequency(new Comparator<Comparable<?>>() {
                                     @Override
                                     public int compare(Comparable<?> o1, Comparable<?> o2) {
                                         // Handle case where both are Long
                                         if (o1 instanceof Long && o2 instanceof Long) {
                                             return ((Long) o1).compareTo((Long) o2);
                                         }
                                         // Handle case where both are CustomComparable
                                         if (o1 instanceof CustomComparable && o2 instanceof CustomComparable) {
                                             return ((CustomComparable) o1).compareTo((CustomComparable) o2);
                                         }
                                         // Handle mixed types by converting to string representation
                                         return o1.toString().compareTo(o2.toString());
                                     }
                                 });
                                 
                                 // Add values of different comparable types
                                 Long longValue = 10L;
                                 CustomComparable customValue = new CustomComparable(10);
                                 
                                 // Original code would handle this correctly, mutant would fail
                                 freq.addValue(longValue);
                                 freq.addValue(customValue);
                                 
                                 // Verify both values were added correctly
                                 assertEquals(1, freq.getCount(longValue));
                                 assertEquals(1, freq.getCount(customValue));
                             }

    @Test
                             public void testAddValueCharWithCustomComparator() {
                                 // Create a custom comparator that relies on proper typing
                                 Comparator<Character> comparator = (c1, c2) -> {
                                     // This will fail if the values aren't properly typed as Characters
                                     return Character.compare(Character.toUpperCase(c1), 
                                                            Character.toUpperCase(c2));
                                 };
                                 
                                 Frequency frequency = new Frequency(comparator);
                                 
                                 // Add some test values
                                 frequency.addValue('a');
                                 frequency.addValue('A');
                                 frequency.addValue('b');
                                 frequency.addValue('B');
                                 
                                 // Verify counts - should be case-insensitive
                                 assertEquals(2, frequency.getCount('a'));
                                 assertEquals(2, frequency.getCount('A'));
                                 assertEquals(2, frequency.getCount('b'));
                                 assertEquals(2, frequency.getCount('B'));
                                 
                                 // Verify the mutated version would fail these assertions
                                 // because the non-generic Comparable cast might not work properly with the comparator
                             }

    @Test
                            public void testAddValueWithRawComparable6() {
                                Frequency frequency = new Frequency();
                                // Using String as a standard Comparable implementation instead of RawComparable
                                String testValue = "test";
                                
                                // This should work with both original and mutant, but we want to test the casting behavior
                                frequency.addValue(testValue);
                                
                                // Verify the value was properly added by checking count
                                assertEquals(1L, frequency.getCount(testValue));
                                
                                // The key difference is in how the type system handles the cast:
                                // Original code (Comparable<?>) maintains better type safety
                                // Mutant (Comparable) uses raw type which could cause issues in some cases
                                // This test would pass with both, but we need to test the internal behavior
                                
                                // More thorough test would require checking the internal freqTable state
                                // Since freqTable is private, we can't directly access it, but we can:
                                // 1. Add multiple values and verify counts
                                // 2. Add different types of Comparable objects
                                frequency.addValue(testValue);
                                assertEquals(2L, frequency.getCount(testValue));
                                
                                // Test with standard Comparable objects
                                String stringValue = "string";
                                frequency.addValue(stringValue);
                                assertEquals(1L, frequency.getCount(stringValue));
                                
                                Integer intValue = 42;
                                frequency.addValue(intValue);
                                assertEquals(1L, frequency.getCount(intValue));
                            }

    @Test
                            public void testAddValueWithDifferentComparableTypes4() {
                                // Setup
                                Frequency frequency = new Frequency();
                                
                                // Test with different Comparable types
                                frequency.addValue(123L);  // Long
                                frequency.addValue("test"); // String
                                frequency.addValue(42);    // Integer
                                
                                // Verify counts for each type
                                assertEquals(1L, frequency.getCount(123L));
                                assertEquals(1L, frequency.getCount("test"));
                                assertEquals(1L, frequency.getCount(42));
                                
                                // Verify the internal TreeMap handles types correctly
                                try {
                                    Field field = Frequency.class.getDeclaredField("freqTable");
                                    field.setAccessible(true);
                                    @SuppressWarnings("unchecked")
                                    TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) field.get(frequency);
                                    
                                    // Check that all keys maintain their proper types
                                    assertTrue(freqTable.keySet().stream().anyMatch(k -> k instanceof Long));
                                    assertTrue(freqTable.keySet().stream().anyMatch(k -> k instanceof String));
                                    assertTrue(freqTable.keySet().stream().anyMatch(k -> k instanceof Integer));
                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                    fail("Failed to access freqTable field: " + e.getMessage());
                                }
                                
                                // This test will fail with the mutant because:
                                // 1. The raw type Comparable will cause type safety warnings
                                // 2. The behavior with mixed types might differ
                                // 3. The test explicitly checks for proper generic type handling
                            }

    @Test
                            public void testAddValueWithLongShouldStoreCorrectly() {
                                // Setup
                                Frequency frequency = new Frequency();
                                Long testValue = 12345L;
                                
                                // Action
                                frequency.addValue(testValue);
                                
                                // Verification
                                // Verify the value was stored with count 1
                                assertEquals(1L, frequency.getCount(testValue));
                                
                                try {
                                    // Use reflection to access private freqTable field
                                    Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                    freqTableField.setAccessible(true);
                                    @SuppressWarnings("unchecked")
                                    TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) 
                                        freqTableField.get(frequency);
                                        
                                    // Verify the value exists in the freqTable with correct type
                                    assertTrue(freqTable.containsKey(testValue));
                                    assertEquals(1L, (long)freqTable.get(testValue));
                                    
                                    // Verify type safety by checking the class of the key
                                    Comparable<?> key = freqTable.firstKey();
                                    assertTrue(key instanceof Long);
                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                    fail("Failed to access freqTable field: " + e.getMessage());
                                }
                            }

    @Test
                        public void testAddValueWithComparableShouldAddActualValueNotNull() {
                            // Setup
                            Frequency frequency = new Frequency();
                            String testValue = "testValue"; // String implements Comparable
                            
                            // Exercise
                            frequency.addValue(testValue);
                            
                            // Verify
                            // Original would have count 1 for testValue, mutant would have count 1 for null
                            assertEquals("Test value should have count 1", 1, frequency.getCount(testValue));
                            assertEquals("Null should have count 0", 0, frequency.getCount(null));
                            
                            // Additional verification that the value was actually added
                            assertTrue("Frequency table should contain the test value", 
                                       frequency.getCount(testValue) > 0);
                        }

    @Test
                        public void testAddValueComparableDelegation() {
                            // Setup
                            Frequency frequency = new Frequency();
                            Comparable<String> testValue = "testString"; // Any Comparable object
                            
                            // Exercise
                            frequency.addValue(testValue);
                            
                            // Verify
                            // Original would have added with count=1, mutant would pass null
                            assertEquals(1L, frequency.getCount(testValue));
                            
                            // Additional verification that null wasn't added
                            assertEquals(0L, frequency.getCount(null));
                        }

    @Test
                        public void testAddValueShouldNotPassNullWhenLongValueGiven() {
                            // Setup
                            Frequency frequency = new Frequency();
                            int testValue = 5;
                            
                            // Action
                            frequency.addValue(testValue); // This should call addValue(Long.valueOf(v))
                            
                            // Verification
                            // Original behavior would increment count to 1, mutant would pass null and keep count 0
                            assertEquals("Count should be 1 after adding value", 1L, frequency.getCount(testValue));
                            
                            // Also verify the value was actually added to the freqTable
                            assertTrue("Frequency table should contain the test value", 
                                       frequency.getCount(testValue) > 0);
                        }

    @Test
                        public void testAddValueCharDetectsNullMutant1() {
                            // Setup
                            Frequency frequency = new Frequency();
                            char testChar = 'a';
                            
                            // Action - add the character
                            frequency.addValue(testChar);
                            
                            // Verification
                            // Original should have count 1 for the character, mutant will have 0
                            assertEquals("Character count should be 1 after addition", 
                                         1, frequency.getCount(testChar));
                            
                            // Original should have count 0 for null, mutant might have 1
                            assertEquals("Null count should remain 0", 
                                         0, frequency.getCount(null));
                            
                            // Additional verification that the character was actually added
                            // and not replaced with null
                            assertTrue("Frequency table should contain the character",
                                       frequency.getCount(testChar) > 0);
                        }

    @Test
                       public void testAddValueShouldNotPassNull1() {
                           // Setup
                           Frequency frequency = new Frequency();
                           long testValue = 42L;
                           
                           // Action
                           frequency.addValue(testValue);
                           
                           // Verification
                           // Verify the value was actually added by checking its count
                           assertEquals(1L, frequency.getCount(testValue));
                           // Verify the table size increased by checking sum of frequencies
                           assertEquals(1L, frequency.getSumFreq());
                           // Verify the value exists by checking its count is positive
                           assertTrue(frequency.getCount(testValue) > 0);
                       }

    @Test
                       public void testAddValueLongShouldNotPassNull1() {
                           // Setup
                           Frequency frequency = new Frequency();
                           Long testValue = 123L;
                           
                           // Action
                           try {
                               frequency.addValue(testValue);
                               
                               // Verification
                               // Original behavior: count should be 1 for the added value
                               // Mutant behavior: count would be 0 since null was passed
                               assertEquals("Count should be 1 after adding value", 
                                            1L, frequency.getCount(testValue));
                               
                               // Original behavior: sum of frequencies should be 1
                               // Mutant behavior: sum would be 0 or throw exception
                               assertEquals("Total frequency count should be 1", 
                                            1L, frequency.getSumFreq());
                           } catch (NullPointerException e) {
                               // This would catch the mutant behavior where null is passed to TreeMap
                               fail("NullPointerException occurred, suggesting null was passed to freqTable");
                           }
                       }

    @Test
                   public void testAddValueWithComparableShouldIncreaseCount1() {
                       // Setup
                       Frequency frequency = new Frequency();
                       String testValue = "test"; // String implements Comparable
                       
                       // Get initial count (should be 0)
                       long initialCount = frequency.getCount(testValue);
                       
                       // Action
                       frequency.addValue(testValue);
                       
                       // Verification
                       long newCount = frequency.getCount(testValue);
                       assertEquals("Count should increase by 1 after adding value", 
                                    initialCount + 1, newCount);
                       
                       // This test will fail on the mutant because:
                       // - Original: count increases by 1 (passes test)
                       // - Mutant: count remains same (fails test)
                   }

    @Test
                   public void testAddValueWithComparableObjectShouldHandleSpecially() {
                       // Setup
                       Frequency frequency = new Frequency();
                       String comparableValue = "test"; // String implements Comparable
                       
                       // Action
                       frequency.addValue(comparableValue);
                       
                       // Verification
                       // If the mutation is present, it will treat the String as a regular Object
                       // The original code would have delegated to addValue(Comparable)
                       assertEquals(1L, frequency.getCount(comparableValue));
                       
                       // Add another to verify counting works
                       frequency.addValue(comparableValue);
                       assertEquals(2L, frequency.getCount(comparableValue));
                       
                       // Test with non-comparable object
                       Object nonComparable = new Object();
                       try {
                           frequency.addValue(nonComparable);
                           fail("Expected IllegalArgumentException for non-comparable object");
                       } catch (IllegalArgumentException e) {
                           assertEquals("Value not comparable to existing values.", e.getMessage());
                       }
                       
                       // Test with null (edge case)
                       try {
                           frequency.addValue(null);
                           fail("Expected NullPointerException or IllegalArgumentException");
                       } catch (NullPointerException | IllegalArgumentException e) {
                           // Expected - TreeMap doesn't allow null keys
                       }
                   }

    @Test
                   public void testAddValueShouldIncreaseCountWhenLongValueAdded() {
                       // Setup
                       Frequency frequency = new Frequency();
                       long testValue = 123L;
                       long initialCount = frequency.getCount(testValue);
                       
                       // Action
                       frequency.addValue(testValue);  // This calls the method with the mutation
                       
                       // Verification
                       long newCount = frequency.getCount(testValue);
                       assertEquals("Count should increase by 1 after adding value", 
                                   initialCount + 1, newCount);
                       
                       // Additional check for the specific value
                       assertEquals("Specific value count should be 1", 
                                   1, frequency.getCount(testValue));
                   }

    @Test
                   public void testAddValueWithNonNumericComparable1() {
                       // Setup
                       Frequency frequency = new Frequency();
                       String nonNumericComparable = "testString"; // String implements Comparable
                       
                       // Action
                       frequency.addValue(nonNumericComparable);
                       
                       // Verification
                       // Check that the value was added to the frequency table
                       assertEquals(1L, frequency.getCount(nonNumericComparable));
                       
                       // Additional check to ensure it's not treating it as a numeric value
                       assertEquals(0L, frequency.getCount(Long.valueOf(0))); // Shouldn't affect numeric counts
                   }

    @Test
                   public void testAddValueLongDetectsMutant3() {
                       // Setup
                       Frequency frequency = new Frequency();
                       long testValue = 12345L;
                       
                       // Get initial count (should be 0)
                       long initialCount = frequency.getCount(testValue);
                       
                       // Action - add the value
                       frequency.addValue(testValue);
                       
                       // Verification
                       long newCount = frequency.getCount(testValue);
                       
                       // Original behavior: count should increase by 1
                       // Mutated behavior: count remains same (method call is commented out)
                       assertEquals("Value count should increase by 1 after addition", 
                                    initialCount + 1, newCount);
                       
                       // Additional check to ensure the value was actually added
                       assertEquals("Total frequency sum should increase by 1", 
                                    1L, frequency.getSumFreq());
                   }

    @Test
                       public void testAddValueCharDetectsMutant1() {
                           // Create a new Frequency instance
                           Frequency frequency = new Frequency();
                           
                           // Add some character values
                           frequency.addValue('a');
                           frequency.addValue('b');
                           frequency.addValue('a'); // duplicate to test counting
                           
                           // Verify counts - this would fail if the mutation is present
                           assertEquals(2, frequency.getCount('a'));
                           assertEquals(1, frequency.getCount('b'));
                           
                           // Verify ordering in the TreeMap by checking iterator sequence
                           Iterator valuesIter = frequency.valuesIterator();
                           assertEquals('a', valuesIter.next());
                           assertEquals('a', valuesIter.next());
                           assertEquals('b', valuesIter.next());
                           
                           // Verify sum of frequencies
                           assertEquals(3L, frequency.getSumFreq());
                       }

    @Test
                      public void testAddValueWithComparableObject8() {
                          Frequency frequency = new Frequency();
                          // Test with a Comparable object (should not throw exception)
                          try {
                              frequency.addValue("test"); // String implements Comparable
                              // If we get here, test passes (original behavior)
                              assertTrue(true);
                          } catch (IllegalArgumentException e) {
                              // If we get here, mutant is detected
                              fail("Should not throw exception for Comparable object");
                          }
                      }

    @Test(expected = IllegalArgumentException.class)
                      public void testAddValueWithNonComparableObject18() {
                          Frequency frequency = new Frequency();
                          // Test with a non-Comparable object (should throw exception)
                          frequency.addValue(new ArrayList<>()); // ArrayList doesn't implement Comparable
                      }

    @Test
                      public void testAddValueExceptionMessage() {
                          Frequency frequency = new Frequency();
                          try {
                              frequency.addValue(new Object()); // Object doesn't implement Comparable
                              fail("Expected IllegalArgumentException");
                          } catch (IllegalArgumentException e) {
                              assertEquals("Object must implement Comparable", e.getMessage());
                          }
                      }

    @Test
                  public void testAddValueNewEntryDetectsMutant() {
                      // Setup
                      Frequency frequency = new Frequency();
                      Integer testValue = 5; // New value not in frequency table
                      
                      // Exercise
                      frequency.addValue(testValue);
                      
                      // Verify
                      // Original behavior: count should be 1 for new entry
                      // Mutant behavior: count would be 2 (1 gets overwritten with 1+1)
                      assertEquals("Count for new value should be 1", 1L, frequency.getCount(testValue));
                      
                      // Additional verification that subsequent adds work correctly
                      frequency.addValue(testValue);
                      assertEquals("Count should increment to 2", 2L, frequency.getCount(testValue));
                  }

    @Test
                      public void testAddValueLongDetectsMutant4() {
                          // Setup
                          Frequency frequency = new Frequency();
                          Long testValue = 12345L;
                          
                          // First addition - should create new entry with count 1
                          frequency.addValue(testValue);
                          assertEquals("First addition should have count 1", 1, frequency.getCount(testValue));
                          
                          // Second addition - should increment count to 2
                          frequency.addValue(testValue);
                          assertEquals("Second addition should have count 2", 2, frequency.getCount(testValue));
                          
                          // Test with different value
                          Long anotherValue = 67890L;
                          frequency.addValue(anotherValue);
                          assertEquals("Different value should have count 1", 1, frequency.getCount(anotherValue));
                          assertEquals("Original value should still have count 2", 2, frequency.getCount(testValue));
                          
                          // Test with null (though original method may not handle it)
                          try {
                              frequency.addValue((Long)null);
                              fail("Expected NullPointerException");
                          } catch (NullPointerException e) {
                              // Expected behavior
                          }
                      }

    @Test
                  public void testAddValueLongWithMutation() {
                      // Setup
                      Frequency frequency = new Frequency();
                      Long testValue = 100L;
                      
                      // First addition - should increment count to 1
                      frequency.addValue(testValue);
                      assertEquals(1L, frequency.getCount(testValue));
                      
                      // Second addition - should increment count to 2
                      // This would test if the mutated block (now always executing) affects the count
                      frequency.addValue(testValue);
                      assertEquals(2L, frequency.getCount(testValue));
                      
                      // Test with different value to ensure proper isolation
                      Long anotherValue = 200L;
                      frequency.addValue(anotherValue);
                      assertEquals(1L, frequency.getCount(anotherValue));
                      // Original value count should remain unchanged
                      assertEquals(2L, frequency.getCount(testValue));
                      
                      // Test sum frequency to ensure no double counting from mutated block
                      assertEquals(3L, frequency.getSumFreq());
                  }

    @Test
                  public void testAddValueLongDetectsMutant5() {
                      Frequency frequency = new Frequency();
                      Long testValue = 12345L;
                      
                      // First addition - should initialize count to 1
                      frequency.addValue(testValue);
                      assertEquals(1L, frequency.getCount(testValue));
                      
                      // Second addition - should increment count to 2
                      // This will fail with mutant since it might reinitialize instead of increment
                      frequency.addValue(testValue);
                      assertEquals(2L, frequency.getCount(testValue));
                      
                      // Third addition - should increment count to 3
                      frequency.addValue(testValue);
                      assertEquals(3L, frequency.getCount(testValue));
                      
                      // Verify with a different value to ensure isolation
                      Long anotherValue = 67890L;
                      frequency.addValue(anotherValue);
                      assertEquals(1L, frequency.getCount(anotherValue));
                  }

    @Test
                  public void testAddValueCharDetectsMutant2() {
                      // Setup
                      Frequency frequency = new Frequency();
                      char testChar = 'a';
                      
                      // Test adding a new character
                      frequency.addValue(testChar);
                      assertEquals(1L, frequency.getCount(testChar));
                      
                      // Test adding same character again - this should increment count to 2
                      // The mutant would fail here if it skips the else block logic
                      frequency.addValue(testChar);
                      assertEquals(2L, frequency.getCount(testChar));
                      
                      // Test with a different character to ensure separate counting
                      char anotherChar = 'b';
                      frequency.addValue(anotherChar);
                      assertEquals(1L, frequency.getCount(anotherChar));
                      assertEquals(2L, frequency.getCount(testChar)); // Original count should remain
                      
                      // Edge case: test with minimum char value
                      frequency.addValue(Character.MIN_VALUE);
                      assertEquals(1L, frequency.getCount(Character.MIN_VALUE));
                      
                      // Edge case: test with maximum char value
                      frequency.addValue(Character.MAX_VALUE);
                      assertEquals(1L, frequency.getCount(Character.MAX_VALUE));
                  }

    @Test
                 public void testAddValueWithComparable1() {
                     // Setup
                     Frequency frequency = new Frequency();
                     String comparableValue = "test"; // String implements Comparable
                     
                     // Test
                     frequency.addValue(comparableValue);
                     
                     // Verify
                     assertEquals(1L, frequency.getCount(comparableValue));
                     
                     // Add again to test increment
                     frequency.addValue(comparableValue);
                     assertEquals(2L, frequency.getCount(comparableValue));
                     
                     // Test with different comparable
                     String anotherValue = "another";
                     frequency.addValue(anotherValue);
                     assertEquals(1L, frequency.getCount(anotherValue));
                     assertEquals(2L, frequency.getCount(comparableValue)); // Ensure original count unchanged
                 }

    @Test(expected = IllegalArgumentException.class)
                 public void testAddValueWithNonComparable4() {
                     // Setup
                     Frequency frequency = new Frequency();
                     Object nonComparable = new Object(); // Object doesn't implement Comparable
                     
                     // Test - should throw
                     frequency.addValue(nonComparable);
                 }

    @Test
                 public void testAddValueWithInteger2() {
                     // Setup
                     Frequency frequency = new Frequency();
                     Integer intValue = 42;
                     
                     // Test
                     frequency.addValue(intValue);
                     
                     // Verify - should be stored as Long
                     assertEquals(1L, frequency.getCount(42L));
                     assertEquals(0L, frequency.getCount(42)); // Shouldn't find as Integer
                 }

    @Test
                 public void testAddValueMutantDetection1() {
                     // Create a subclass that overrides addValue(Comparable<?>)
                     class FrequencySubclass extends Frequency {
                         boolean overriddenMethodCalled = false;
                         
                         @Override
                         public void addValue(Comparable<?> v) {
                             overriddenMethodCalled = true;
                             super.addValue(v);
                         }
                     }
                     
                     FrequencySubclass freq = new FrequencySubclass();
                     Long testValue = 42L;
                     
                     // Test the original behavior (should call overridden method)
                     freq.addValue(testValue);
                     assertTrue("Overridden method should be called", freq.overriddenMethodCalled);
                     
                     // Reset flag
                     freq.overriddenMethodCalled = false;
                     
                     // Test with explicit this (mutated version)
                     try {
                         // This would be the mutated version: this.addValue((Comparable<?>) v)
                         // In normal case, it should behave same as above
                         // But if we force it to use 'this' explicitly, it might bypass polymorphism
                         Method method = Frequency.class.getDeclaredMethod("addValue", Object.class);
                         method.setAccessible(true);
                         method.invoke(freq, testValue);
                         
                         // Verify the overridden method was still called
                         assertTrue("Mutant should be detected - overridden method not called", 
                                  freq.overriddenMethodCalled);
                     } catch (Exception e) {
                         fail("Test failed due to reflection exception: " + e.getMessage());
                     }
                 }

    @Test
                 public void testAddValueMutantDetection2() {
                     // Create a spy subclass that tracks method calls
                     class TestFrequency extends Frequency {
                         boolean overriddenMethodCalled = false;
                         
                         @Override
                         public void addValue(Comparable<?> v) {
                             overriddenMethodCalled = true;
                             super.addValue(v);
                         }
                     }
                     
                     TestFrequency frequency = new TestFrequency();
                     long testValue = 123L;
                     
                     // Call the method that contains either the original or mutated code
                     frequency.addValue(testValue);
                     
                     // The mutant (using this.addValue) would call the overridden method
                     // The original (using addValue) would call the parent class method directly
                     assertFalse("Mutant should be detected - overridden method was called", 
                                frequency.overriddenMethodCalled);
                     
                     // Verify the value was actually added
                     assertEquals(1L, frequency.getCount(testValue));
                 }

    @Test
                     public void testAddValueCharCallsCorrectMethod1() {
                         // Create a spy to track method calls
                         Frequency frequency = spy(new Frequency());
                         
                         // Test with a sample character
                         char testChar = 'a';
                         frequency.addValue(testChar);
                         
                         // Verify the correct addValue method was called
                         // Original should call addValue(Object) with Character
                         // Mutant might call addValue(Comparable) directly
                         verify(frequency).addValue(Character.valueOf(testChar));
                     }

    @Test
                     public void testAddValueCharWithSubclass() {
                         // Create a subclass that might override behavior
                         class SubFrequency extends Frequency {
                             boolean objectMethodCalled = false;
                             boolean comparableMethodCalled = false;
                             
                             @Override
                             public void addValue(Object v) {
                                 objectMethodCalled = true;
                                 super.addValue(v);
                             }
                             
                             @Override
                             public void addValue(Comparable<?> v) {
                                 comparableMethodCalled = true;
                                 super.addValue(v);
                             }
                         }
                         
                         SubFrequency frequency = new SubFrequency();
                         char testChar = 'b';
                         frequency.addValue(testChar);
                         
                         // Original should call addValue(Object) via Character
                         assertTrue(frequency.objectMethodCalled);
                         assertFalse(frequency.comparableMethodCalled);
                     }

    @Test
                public void testAddValueLongCallsCorrectMethod() {
                    // Create a spy subclass to monitor method calls
                    Frequency frequency = spy(new Frequency());
                    
                    // Create a test value
                    long testValue = 123L;
                    
                    // Call the method
                    frequency.addValue(testValue);
                    
                    // Verify the correct method was called
                    verify(frequency).addValue((Comparable<?>) Long.valueOf(testValue));
                }

    @Test
    public void testAddValueObjectCallsOverriddenMethod() {
        // Create a final array to hold our verification flag
        final boolean[] overriddenMethodCalled = new boolean[1];
        
        // Create an anonymous subclass that overrides addValue(Comparable)
        Frequency frequency = new Frequency() {
            @Override
            public void addValue(Comparable<?> v) {
                overriddenMethodCalled[0] = true;
                super.addValue(v);
            }
        };
        
        // Test with a Comparable object
        Comparable<String> testValue = "test";
        frequency.addValue(testValue);
        
        // Verify the overridden method was called
        assertTrue("Overridden addValue(Comparable) should be called", 
            overriddenMethodCalled[0]);
    }


}
