package gentest.org.apache.commons.math.optimization.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.*;
import org.apache.commons.math.ConvergenceException;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
import org.apache.commons.math.random.RandomGenerator;
import org.apache.commons.math.util.LocalizedFormats;
 
public class MultiStartUnivariateRealOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                            public void testGetFunctionValue_WithNegativeValue() throws Exception {
                                                                                                                                // Setup
                                                                                                                                UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                                                                                                RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                                MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 1, mockGenerator);
                                                                                                                                
                                                                                                                                double[] testValues = {-3.14, 0.0, 1.0};
                                                                                                                                
                                                                                                                                // Use reflection to set private optimaValues field
                                                                                                                                Field optimaValuesField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optimaValues");
                                                                                                                                optimaValuesField.setAccessible(true);
                                                                                                                                optimaValuesField.set(optimizer, testValues);
                                                                                                                                
                                                                                                                                // Test and verify
                                                                                                                                assertEquals(-3.14, optimizer.getFunctionValue(), 0.0001);
                                                                                                                            }

    @Test
                                                                                                                            public void testGetFunctionValue_WithZeroValue() throws Exception {
                                                                                                                                // Setup
                                                                                                                                UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                                                                                                RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                                MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 1, mockGenerator);
                                                                                                                                
                                                                                                                                double[] testValues = {0.0, 1.0, 2.0};
                                                                                                                                
                                                                                                                                // Use reflection to set private optimaValues field
                                                                                                                                Field optimaValuesField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optimaValues");
                                                                                                                                optimaValuesField.setAccessible(true);
                                                                                                                                optimaValuesField.set(optimizer, testValues);
                                                                                                                                
                                                                                                                                // Test and verify
                                                                                                                                assertEquals(0.0, optimizer.getFunctionValue(), 0.0001);
                                                                                                                            }

    @Test
                                                                                                                            public void testGetResult_WithMultipleValues_ShouldReturnFirstValue() throws Exception {
                                                                                                                                // Arrange
                                                                                                                                double expected = 10.0;
                                                                                                                                UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                                                                                                RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                                MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 5, mockGenerator);
                                                                                                                                
                                                                                                                                // Use reflection to set private optima field
                                                                                                                                Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                                                                                                                                optimaField.setAccessible(true);
                                                                                                                                optimaField.set(optimizer, new double[]{expected, 20.0, 30.0});
                                                                                                                                
                                                                                                                                // Act
                                                                                                                                double result = optimizer.getResult();
                                                                                                                                
                                                                                                                                // Assert
                                                                                                                                assertEquals(expected, result, 0.0001);
                                                                                                                            }

    @Test
                                                                                                                            public void testGetResult_WithNegativeValue_ShouldReturnCorrectValue() throws Exception {
                                                                                                                                // Arrange
                                                                                                                                double expected = -15.75;
                                                                                                                                // Create mock dependencies
                                                                                                                                UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                                                                                                RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                                
                                                                                                                                // Create real optimizer instance
                                                                                                                                MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                                                                                    mockOptimizer, 
                                                                                                                                    1, 
                                                                                                                                    mockGenerator
                                                                                                                                );
                                                                                                                                
                                                                                                                                // Use reflection to set private optima field
                                                                                                                                Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                                                                                                                                optimaField.setAccessible(true);
                                                                                                                                optimaField.set(optimizer, new double[]{expected, 0.0});
                                                                                                                                
                                                                                                                                // Act
                                                                                                                                double result = optimizer.getResult();
                                                                                                                                
                                                                                                                                // Assert
                                                                                                                                assertEquals(expected, result, 0.0001);
                                                                                                                            }

    @Test
                                                                                                                            public void testGetResult_WithZeroValue_ShouldReturnCorrectValue() throws Exception {
                                                                                                                                // Arrange
                                                                                                                                double expected = 0.0;
                                                                                                                                UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                                                                                                RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                                MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 1, mockGenerator);
                                                                                                                                
                                                                                                                                // Use reflection to set private optima field
                                                                                                                                Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                                                                                                                                optimaField.setAccessible(true);
                                                                                                                                optimaField.set(optimizer, new double[]{expected, 1.0});
                                                                                                                                
                                                                                                                                // Act
                                                                                                                                double result = optimizer.getResult();
                                                                                                                                
                                                                                                                                // Assert
                                                                                                                                assertEquals(expected, result, 0.0001);
                                                                                                                            }

    @Test
                                                                                                                        public void testGetFunctionValue_WithValidOptimaValues() throws Exception {
                                                                                                                            // Setup
                                                                                                                            org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                                                                                                new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                                                                            org.apache.commons.math.random.JDKRandomGenerator generator = 
                                                                                                                                new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                                                            MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                                                                                underlyingOptimizer, 5, generator);
                                                                                                                            
                                                                                                                            double[] testValues = {1.23, 4.56, 7.89};
                                                                                                                            
                                                                                                                            // Use reflection to set private optimaValues field
                                                                                                                            Field optimaValuesField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optimaValues");
                                                                                                                            optimaValuesField.setAccessible(true);
                                                                                                                            optimaValuesField.set(optimizer, testValues);
                                                                                                                            
                                                                                                                            // Test and verify
                                                                                                                            assertEquals(1.23, optimizer.getFunctionValue(), 0.0001);
                                                                                                                        }

    @Test
                                                                                                                        public void testGetResult_WhenOptimaIsNull_ShouldThrowException() {
                                                                                                                            // Arrange
                                                                                                                            UnivariateRealOptimizer underlyingOptimizer = mock(UnivariateRealOptimizer.class);
                                                                                                                            RandomGenerator randomGenerator = mock(RandomGenerator.class);
                                                                                                                            MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                                                                                underlyingOptimizer, 10, randomGenerator);
                                                                                                                            
                                                                                                                            // Set optima to null using reflection
                                                                                                                            try {
                                                                                                                                Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                                                                                                                                optimaField.setAccessible(true);
                                                                                                                                optimaField.set(optimizer, null);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to set optima field to null via reflection");
                                                                                                                            }
                                                                                                                            
                                                                                                                            try {
                                                                                                                                // Act
                                                                                                                                optimizer.getResult();
                                                                                                                                fail("Expected IllegalStateException");
                                                                                                                            } catch (IllegalStateException e) {
                                                                                                                                // Assert
                                                                                                                                assertEquals("no results available", e.getMessage());
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                                                                        public void testGetResult_WhenOptimaIsEmpty_ShouldThrowException() {
                                                                                                                            // Arrange
                                                                                                                            org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                                                                                                new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                                                                            org.apache.commons.math.random.JDKRandomGenerator random = 
                                                                                                                                new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                                                            MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                                new MultiStartUnivariateRealOptimizer(underlyingOptimizer, 10, random);
                                                                                                                            
                                                                                                                            // Use reflection to set private optima field since it's not accessible directly
                                                                                                                            try {
                                                                                                                                Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                                                                                                                                optimaField.setAccessible(true);
                                                                                                                                optimaField.set(optimizer, new double[0]);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to set optima field via reflection");
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Set up exception expectation
                                                                                                                            ExpectedException exception = ExpectedException.none();
                                                                                                                            exception.expect(IllegalStateException.class);
                                                                                                                            exception.expectMessage("no results available");
                                                                                                                            
                                                                                                                            // Act
                                                                                                                            optimizer.getResult();
                                                                                                                        }

    @Test
                                                                                                                        public void testGetResult_WithSingleValue_ShouldReturnCorrectValue() throws Exception {
                                                                                                                            // Arrange
                                                                                                                            double expected = 42.5;
                                                                                                                            UnivariateRealOptimizer underlyingOptimizer = new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                                                                            RandomGenerator generator = new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                                                            MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(underlyingOptimizer, 1, generator);
                                                                                                                            
                                                                                                                            // Use reflection to set private optima field
                                                                                                                            Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                                                                                                                            optimaField.setAccessible(true);
                                                                                                                            optimaField.set(optimizer, new double[]{expected});
                                                                                                                            
                                                                                                                            // Act
                                                                                                                            double result = optimizer.getResult();
                                                                                                                            
                                                                                                                            // Assert
                                                                                                                            assertEquals(expected, result, 0.0001);
                                                                                                                        }

    @Test
                                                                                                                        public void testGetResult_WithMaxDoubleValue_ShouldReturnCorrectValue() throws Exception {
                                                                                                                            // Arrange
                                                                                                                            org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                                                                                                new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                                                                            org.apache.commons.math.random.JDKRandomGenerator generator = 
                                                                                                                                new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                                                            org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                                new org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer(
                                                                                                                                    underlyingOptimizer, 1, generator);
                                                                                                                            
                                                                                                                            double expected = Double.MAX_VALUE;
                                                                                                                            
                                                                                                                            // Use reflection to set private optima field
                                                                                                                            Field optimaField = org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                                                                                                                            optimaField.setAccessible(true);
                                                                                                                            optimaField.set(optimizer, new double[]{expected, Double.MIN_VALUE});
                                                                                                                            
                                                                                                                            // Act
                                                                                                                            double result = optimizer.getResult();
                                                                                                                            
                                                                                                                            // Assert
                                                                                                                            assertEquals(expected, result, 0.0001);
                                                                                                                        }

    @Test
                                                                                                                    public void testGetFunctionValue_WithSingleValueArray() throws Exception {
                                                                                                                        // Setup
                                                                                                                        org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                                                                                            new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                                                                        org.apache.commons.math.random.JDKRandomGenerator generator = 
                                                                                                                            new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                                                        org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                            new org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer(
                                                                                                                                underlyingOptimizer, 1, generator);
                                                                                                                        
                                                                                                                        double[] testValues = {9.99};
                                                                                                                        
                                                                                                                        // Use reflection to set private optima field
                                                                                                                        Field optimaField = org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer.class
                                                                                                                            .getDeclaredField("optima");
                                                                                                                        optimaField.setAccessible(true);
                                                                                                                        optimaField.set(optimizer, testValues);
                                                                                                                        
                                                                                                                        // Test and verify
                                                                                                                        assertEquals(9.99, optimizer.getFunctionValue(), 0.0001);
                                                                                                                    }

    @Test
                                                                                    public void testGetFunctionValue_WithEmptyArray() {
                                                                                        // Setup
                                                                                        org.apache.commons.math.analysis.UnivariateRealFunction dummyFunction = 
                                                                                            new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                                                public double value(double x) { return 0; }
                                                                                            };
                                                                                        org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                                                            new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                                        org.apache.commons.math.random.RandomGenerator generator = 
                                                                                            new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                        org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer optimizer = 
                                                                                            new org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer(
                                                                                                underlyingOptimizer, 10, generator);
                                                                                        
                                                                                        // Use reflection to set private optimaValues field since it's not accessible directly
                                                                                        try {
                                                                                            java.lang.reflect.Field optimaValuesField = optimizer.getClass()
                                                                                                .getDeclaredField("optimaValues");
                                                                                            optimaValuesField.setAccessible(true);
                                                                                            optimaValuesField.set(optimizer, new double[0]);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set optimaValues field via reflection");
                                                                                        }
                                                                                        
                                                                                        // Expect exception
                                                                                        org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                        thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                                                        
                                                                                        // Test
                                                                                        optimizer.getFunctionValue();
                                                                                    }

    @Test
                                                public void testGetFunctionValue_WithNullOptimaValues() throws Exception {
                                                    // Setup
                                                    org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                        new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                    org.apache.commons.math.random.JDKRandomGenerator generator = 
                                                        new org.apache.commons.math.random.JDKRandomGenerator();
                                            {
                                            {
                                                        }
                                            }
                                                    
                                                    // Use reflection to set private optimaValues field to null
                                                    
                                                    // Test and verify exception
                                                    try {
                                                        fail("Expected NullPointerException");
                                                    } catch (NullPointerException e) {
                                                        // Expected behavior
                                                    }
                                                }

    @Test
                                          public void testConstructorSetsOptimizerCorrectly() throws NoSuchFieldException, IllegalAccessException {
                                              // Create mock dependencies
                                              UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                              RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                              int starts = 5;
                                              
                                              // Create instance under test
                                              MultiStartUnivariateRealOptimizer optimizer = 
                                                  new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
                                              
                                              // Use reflection to access private optimizer field
                                              Field optimizerField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optimizer");
                                              optimizerField.setAccessible(true);
                                              UnivariateRealOptimizer actualOptimizer = (UnivariateRealOptimizer) optimizerField.get(optimizer);
                                              
                                              // Verify optimizer field was set to the provided mock, not to 'this'
                                              // This will catch the mutant that sets optimizer = this
                                              assertSame("Optimizer field should be set to provided optimizer instance",
                                                        mockOptimizer, 
                                                        actualOptimizer);
                                          }

    @Test
                                          public void testConstructorInitializesTotalIterationsToZero() {
                                              // Arrange
                                              UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                              RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                              int starts = 5;
                                              
                                              // Act
                                              MultiStartUnivariateRealOptimizer optimizer = 
                                                  new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
                                              
                                              // Assert
                                              assertEquals("totalIterations should be initialized to 0", 
                                                          0, optimizer.getIterationCount());
                                          }

    @Test
                                    public void testConstructorInitializesTotalIterationsToZero1() {
                                        // Arrange
                                        UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                        RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                        int starts = 5;
                                        
                                        // Act
                                        MultiStartUnivariateRealOptimizer optimizer = 
                                            new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
                                        
                                        // Assert
                                        assertEquals("totalIterations should be initialized to 0", 
                                                     0, optimizer.getIterationCount());
                                        
                                        // Additional sanity checks for other initialized values
                                        assertNull(optimizer.getOptima());
                                        assertEquals(Integer.MAX_VALUE, optimizer.getMaximalIterationCount());
                                        assertEquals(Integer.MAX_VALUE, optimizer.getMaxEvaluations());
                                    }

    @Test
                               public void testConstructorInitializesStartsCorrectly() throws Exception {
                                   // Prepare test data
                                   UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                   RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                   int testStarts = 5; // non-zero test value
                                   
                                   // Create instance
                                   MultiStartUnivariateRealOptimizer optimizer = 
                                       new MultiStartUnivariateRealOptimizer(mockOptimizer, testStarts, mockGenerator);
                                   
                                   // Use reflection to access private starts field
                                   Field startsField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("starts");
                                   startsField.setAccessible(true);
                                   int actualStarts = (int) startsField.get(optimizer);
                                   
                                   // Verify starts was initialized correctly
                                   assertEquals("Starts should be initialized with constructor parameter value", 
                                                testStarts, actualStarts);
                                   
                                   // Additional test with different value to ensure it's not hardcoded
                                   int anotherTestStarts = 10;
                                   MultiStartUnivariateRealOptimizer anotherOptimizer = 
                                       new MultiStartUnivariateRealOptimizer(mockOptimizer, anotherTestStarts, mockGenerator);
                                   int anotherActualStarts = (int) startsField.get(anotherOptimizer);
                                   assertEquals("Starts should be initialized with constructor parameter value", 
                                                anotherTestStarts, anotherActualStarts);
                               }

    @Test
                          public void testConstructorStartsInitialization() throws Exception {
                              // Prepare test data with different start values
                              int[] testStarts = {0, 1, 5, 100, Integer.MAX_VALUE - 1};
                              
                              // Mock dependencies
                              UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                              RandomGenerator mockGenerator = mock(RandomGenerator.class);
                              
                              for (int expectedStarts : testStarts) {
                                  // Create instance with test parameters
                                  MultiStartUnivariateRealOptimizer optimizer = 
                                      new MultiStartUnivariateRealOptimizer(mockOptimizer, expectedStarts, mockGenerator);
                                  
                                  // Use reflection to access private starts field
                                  Field startsField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("starts");
                                  startsField.setAccessible(true);
                                  int actualStarts = (int) startsField.get(optimizer);
                                  
                                  // Verify starts was set exactly as passed (not +1)
                                  assertEquals("Starts should be initialized exactly as passed to constructor",
                                              expectedStarts, 
                                              actualStarts);
                              }
                          }

    @Test
                          public void testConstructorSetsGeneratorField() {
                              // Setup
                              UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                              RandomGenerator mockGenerator = mock(RandomGenerator.class);
                              int starts = 5;
                              
                              // Exercise
                              MultiStartUnivariateRealOptimizer optimizer = 
                                  new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
                              
                              // Verify generator field was set properly
                              try {
                                  // Use reflection to access private field for verification
                                  java.lang.reflect.Field generatorField = 
                                      MultiStartUnivariateRealOptimizer.class.getDeclaredField("generator");
                                  generatorField.setAccessible(true);
                                  RandomGenerator actualGenerator = (RandomGenerator) generatorField.get(optimizer);
                                  
                                  // Assertions
                                  assertNotNull("Generator field should not be null", actualGenerator);
                                  assertSame("Generator field should be same as passed generator", 
                                            mockGenerator, actualGenerator);
                              } catch (Exception e) {
                                  fail("Failed to access generator field: " + e.getMessage());
                              }
                          }

    @Test
                         public void testConstructorSetsMaxIterationsToMaxValue() {
                             // Arrange
                             UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                             int starts = 5;
                             RandomGenerator mockGenerator = mock(RandomGenerator.class);
                             
                             // Act
                             MultiStartUnivariateRealOptimizer optimizer = 
                                 new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
                             
                             // Assert
                             assertEquals("Max iterations should be Integer.MAX_VALUE", 
                                        Integer.MAX_VALUE, optimizer.getMaximalIterationCount());
                         }

    @Test
                   public void testConstructorSetsMaxIterationCountToMaxValue() throws Exception {
                       // Arrange
                       UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                       RandomGenerator mockGenerator = mock(RandomGenerator.class);
                       int testStarts = 5;
                       
                       // Act
                       MultiStartUnivariateRealOptimizer optimizer = 
                           new MultiStartUnivariateRealOptimizer(mockOptimizer, testStarts, mockGenerator);
                       
                       // Assert
                       assertEquals("Max iterations should be set to Integer.MAX_VALUE", 
                                    Integer.MAX_VALUE, optimizer.getMaximalIterationCount());
                       
                       // Additional verification of other constructor-set values
                       assertEquals("Total iterations should be initialized to 0",
                                   0, optimizer.getIterationCount());
                       
                       // Verify starts using reflection
                       Field startsField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("starts");
                       startsField.setAccessible(true);
                       assertEquals("Starts should be set correctly",
                                    testStarts, startsField.get(optimizer));
                       
                       // Verify generator using reflection
                       Field generatorField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("generator");
                       generatorField.setAccessible(true);
                       assertSame("Generator should be set correctly",
                                  mockGenerator, generatorField.get(optimizer));
                       
                       // Verify optima is null
                       Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                       optimaField.setAccessible(true);
                       assertNull("Optima should be initialized to null",
                                  optimaField.get(optimizer));
                       
                       assertEquals("Max evaluations should be set to Integer.MAX_VALUE",
                                    Integer.MAX_VALUE, optimizer.getMaxEvaluations());
                   }

    @Test
              public void testConstructorSetsMaxEvaluationsCorrectly() {
                  // Arrange
                  UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                  RandomGenerator mockGenerator = mock(RandomGenerator.class);
                  int starts = 5;
                  
                  // Act - create the object under test
                  MultiStartUnivariateRealOptimizer optimizer = 
                      new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
                  
                  // Assert - verify maxEvaluations is set to Integer.MAX_VALUE
                  assertEquals("Max evaluations should be set to Integer.MAX_VALUE", 
                              Integer.MAX_VALUE, optimizer.getMaxEvaluations());
                  
                  // Additional verification that other important fields are set
                  assertEquals("Total iterations should be initialized to 0", 
                              0, optimizer.getIterationCount());
                  
                  // Use reflection to verify private starts field
                  try {
                      Field startsField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("starts");
                      startsField.setAccessible(true);
                      int actualStarts = (int) startsField.get(optimizer);
                      assertEquals("Starts should be set correctly", starts, actualStarts);
                  } catch (Exception e) {
                      fail("Failed to access private starts field: " + e.getMessage());
                  }
                  
                  assertNull("Optima should be initialized to null", 
                            optimizer.getOptima());
              }

    @Test
              public void testConstructorSetsMaxEvaluationsCorrectly1() {
                  // Arrange
                  UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                  RandomGenerator mockGenerator = mock(RandomGenerator.class);
                  int starts = 5;
                  
                  // Act
                  MultiStartUnivariateRealOptimizer optimizer = 
                      new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
                  
                  // Assert
                  assertEquals("Max evaluations should be Integer.MAX_VALUE", 
                               Integer.MAX_VALUE, 
                               optimizer.getMaxEvaluations());
              }

    @Test
         public void testConstructorInitializesTotalIterationsToZero2() {
             // Arrange
             UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
             int starts = 5;
             RandomGenerator mockGenerator = mock(RandomGenerator.class);
             
             // Act
             MultiStartUnivariateRealOptimizer optimizer = 
                 new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
             
             // Assert
             assertEquals("totalIterations should be initialized to 0", 
                         0, optimizer.getIterationCount());
         }

    @Test
            public void testConstructorStartsInitialization1() throws Exception {
                // Prepare test data
                UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                RandomGenerator mockGenerator = mock(RandomGenerator.class);
                int testStarts = 5;  // Test with a positive number
                
                // Create instance
                MultiStartUnivariateRealOptimizer optimizer = 
                    new MultiStartUnivariateRealOptimizer(mockOptimizer, testStarts, mockGenerator);
                
                // Use reflection to access private field since there's no getter
                java.lang.reflect.Field startsField = 
                    MultiStartUnivariateRealOptimizer.class.getDeclaredField("starts");
                startsField.setAccessible(true);
                int actualStarts = (int) startsField.get(optimizer);
                
                // Verify the starts value was set correctly
                assertEquals("Starts field should be initialized with exact input value", 
                            testStarts, actualStarts);
            }

    @Test
            public void testConstructorStartsInitializationWithZero() throws Exception {
                // Prepare test data
                UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                RandomGenerator mockGenerator = mock(RandomGenerator.class);
                int testStarts = 0;  // Test with zero
                
                // Create instance
                MultiStartUnivariateRealOptimizer optimizer = 
                    new MultiStartUnivariateRealOptimizer(mockOptimizer, testStarts, mockGenerator);
                
                // Use reflection to access private field
                java.lang.reflect.Field startsField = 
                    MultiStartUnivariateRealOptimizer.class.getDeclaredField("starts");
                startsField.setAccessible(true);
                int actualStarts = (int) startsField.get(optimizer);
                
                // Verify the starts value was set correctly
                assertEquals("Starts field should be initialized with exact input value (0)", 
                            testStarts, actualStarts);
            }

    @Test
            public void testConstructorStartsInitializationWithMaxValue() throws Exception {
                // Prepare test data
                UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                RandomGenerator mockGenerator = mock(RandomGenerator.class);
                int testStarts = Integer.MAX_VALUE;  // Test with max value
                
                // Create instance
                MultiStartUnivariateRealOptimizer optimizer = 
                    new MultiStartUnivariateRealOptimizer(mockOptimizer, testStarts, mockGenerator);
                
                // Use reflection to access private field
                java.lang.reflect.Field startsField = 
                    MultiStartUnivariateRealOptimizer.class.getDeclaredField("starts");
                startsField.setAccessible(true);
                int actualStarts = (int) startsField.get(optimizer);
                
                // Verify the starts value was set correctly
                assertEquals("Starts field should be initialized with exact input value (MAX_VALUE)", 
                            testStarts, actualStarts);
            }

    @Test
           public void testConstructorSetsMaxIterationsCorrectly() {
               // Arrange
               UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
               RandomGenerator mockGenerator = mock(RandomGenerator.class);
               int testStarts = 10;
               
               // Act
               MultiStartUnivariateRealOptimizer optimizer = 
                   new MultiStartUnivariateRealOptimizer(mockOptimizer, testStarts, mockGenerator);
               
               // Assert
               // Original behavior should have MAX_VALUE, mutated would have testStarts
               assertEquals("Max iterations should be Integer.MAX_VALUE", 
                           Integer.MAX_VALUE, 
                           optimizer.getMaximalIterationCount());
           }

    @Test
           public void testConstructorWithDifferentStartsValues() {
               // Arrange
               UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
               RandomGenerator mockGenerator = mock(RandomGenerator.class);
               int[] testStartsValues = {1, 100, Integer.MAX_VALUE - 1};
               
               for (int starts : testStartsValues) {
                   // Act
                   MultiStartUnivariateRealOptimizer optimizer = 
                       new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
                   
                   // Assert
                   assertEquals("Max iterations should be Integer.MAX_VALUE regardless of starts value",
                               Integer.MAX_VALUE,
                               optimizer.getMaximalIterationCount());
               }
           }

    @Test
          public void testConstructorSetsMaxEvaluationsToMaxValue() {
              // Arrange
              UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
              RandomGenerator mockGenerator = mock(RandomGenerator.class);
              int testStarts = 10; // arbitrary value that's not Integer.MAX_VALUE
              
              // Act
              MultiStartUnivariateRealOptimizer optimizer = 
                  new MultiStartUnivariateRealOptimizer(mockOptimizer, testStarts, mockGenerator);
              
              // Assert
              assertEquals("Max evaluations should be Integer.MAX_VALUE", 
                         Integer.MAX_VALUE, optimizer.getMaxEvaluations());
              
              // Additional test with different starts value
              int anotherStarts = 100;
              MultiStartUnivariateRealOptimizer optimizer2 = 
                  new MultiStartUnivariateRealOptimizer(mockOptimizer, anotherStarts, mockGenerator);
              assertEquals("Max evaluations should remain Integer.MAX_VALUE regardless of starts value",
                         Integer.MAX_VALUE, optimizer2.getMaxEvaluations());
          }

    @Test
    public void testConstructorInitializesTotalIterationsToZero3() {
        // Arrange
        UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
        RandomGenerator mockGenerator = mock(RandomGenerator.class);
        int starts = 5; // Any non-zero value to test
        
        // Act
        MultiStartUnivariateRealOptimizer optimizer = 
            new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
        
        // Assert
        assertEquals("totalIterations should be initialized to 0", 
                    0, optimizer.getIterationCount());
        
        // Check other initialized values through public methods
        assertEquals(Integer.MAX_VALUE, optimizer.getMaximalIterationCount());
        assertEquals(Integer.MAX_VALUE, optimizer.getMaxEvaluations());
        
        // For private fields, we can either:
        // 1. Remove the assertions if they're not critical
        // 2. Or use reflection (shown below)
        try {
            Field optimizerField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optimizer");
            optimizerField.setAccessible(true);
            assertSame(mockOptimizer, optimizerField.get(optimizer));
            
            Field startsField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("starts");
            startsField.setAccessible(true);
            assertEquals(starts, startsField.get(optimizer));
            
            Field generatorField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("generator");
            generatorField.setAccessible(true);
            assertSame(mockGenerator, generatorField.get(optimizer));
            
            Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
            optimaField.setAccessible(true);
            assertNull(optimaField.get(optimizer));
        } catch (Exception e) {
            fail("Reflection failed: " + e.getMessage());
        }
    }


}
