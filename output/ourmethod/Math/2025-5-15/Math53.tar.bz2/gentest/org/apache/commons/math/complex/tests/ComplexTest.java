package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

      @Test
                  public void testAdd_TypicalValues() {
                      Complex c1 = new Complex(3.0, 4.0);
                      Complex c2 = new Complex(1.0, 2.0);
                      Complex result = c1.add(c2);
                      
                      assertEquals(4.0, result.getReal(), 0.0001);
                      assertEquals(6.0, result.getImaginary(), 0.0001);
                      assertFalse(result.isNaN());
                  }

 @Test
                  public void testAdd_WithNegativeValues() {
                      Complex c1 = new Complex(-3.0, -4.0);
                      Complex c2 = new Complex(1.0, 2.0);
                      Complex result = c1.add(c2);
                      
                      assertEquals(-2.0, result.getReal(), 0.0001);
                      assertEquals(-2.0, result.getImaginary(), 0.0001);
                  }

 @Test
                  public void testAdd_WithZero() {
                      Complex c1 = new Complex(0.0, 0.0);
                      Complex c2 = new Complex(0.0, 0.0);
                      Complex result = c1.add(c2);
                      
                      assertEquals(0.0, result.getReal(), 0.0001);
                      assertEquals(0.0, result.getImaginary(), 0.0001);
                  }

 @Test
                  public void testAdd_FirstOperandNaN() {
                      Complex c1 = new Complex(Double.NaN, Double.NaN);
                      Complex c2 = new Complex(1.0, 2.0);
                      Complex result = c1.add(c2);
                      
                      assertTrue(result.isNaN());
                  }

 @Test
                  public void testAdd_SecondOperandNaN() {
                      Complex c1 = new Complex(1.0, 2.0);
                      Complex c2 = new Complex(Double.NaN, Double.NaN);
                      Complex result = c1.add(c2);
                      
                      assertTrue(result.isNaN());
                  }

 @Test
                  public void testAdd_BothOperandsNaN() {
                      Complex c1 = new Complex(Double.NaN, Double.NaN);
                      Complex c2 = new Complex(Double.NaN, Double.NaN);
                      Complex result = c1.add(c2);
                      
                      assertTrue(result.isNaN());
                  }

 @Test
                  public void testAdd_WithInfinity() {
                      Complex c1 = new Complex(Double.POSITIVE_INFINITY, 4.0);
                      Complex c2 = new Complex(1.0, 2.0);
                      Complex result = c1.add(c2);
                      
                      assertTrue(result.isInfinite());
                      assertEquals(Double.POSITIVE_INFINITY, result.getReal(), 0.0001);
                      assertEquals(6.0, result.getImaginary(), 0.0001);
                  }

 @Test
                  public void testAdd_NullArgument() {
                      Complex c1 = new Complex(1.0, 2.0);
                      
                      thrown.expect(NullPointerException.class);
                      thrown.expectMessage("Null argument");
                      
                      c1.add(null);
                  }

 @Test
                  public void testAdd_WithStaticConstants() {
                      Complex result1 = Complex.ONE.add(Complex.I);
                      assertEquals(1.0, result1.getReal(), 0.0001);
                      assertEquals(1.0, result1.getImaginary(), 0.0001);
              
                      Complex result2 = Complex.ZERO.add(Complex.ONE);
                      assertEquals(1.0, result2.getReal(), 0.0001);
                      assertEquals(0.0, result2.getImaginary(), 0.0001);
                  }

 @Test
                  public void testAdd_CommutativeProperty() {
                      Complex c1 = new Complex(3.0, 4.0);
                      Complex c2 = new Complex(1.0, 2.0);
                      
                      Complex result1 = c1.add(c2);
                      Complex result2 = c2.add(c1);
                      
                      assertEquals(result1.getReal(), result2.getReal(), 0.0001);
                      assertEquals(result1.getImaginary(), result2.getImaginary(), 0.0001);
                  }

 @Test
              public void testAddWithNullParameterShouldThrowException() {
                  // Setup
                  Complex complex = new Complex(1.0, 2.0);
                  
                  // Expect exception
                  thrown.expect(NullPointerException.class);
                  thrown.expectMessage("The complex number must not be null");
                  
                  // Test
                  complex.add(null);
              }

 @Test
             public void testAddWithNaNValues() {
                 // Case 1: Current complex is NaN, rhs is not NaN
                 Complex nanComplex = new Complex(Double.NaN, 1.0);
                 Complex normalComplex = new Complex(1.0, 1.0);
                 assertTrue("Should return NaN when current is NaN", 
                            nanComplex.add(normalComplex).isNaN());
                 
                 // Case 2: Current complex is not NaN, rhs is NaN
                 assertTrue("Should return NaN when rhs is NaN", 
                            normalComplex.add(nanComplex).isNaN());
                 
                 // Case 3: Both are NaN
                 assertTrue("Should return NaN when both are NaN", 
                            nanComplex.add(nanComplex).isNaN());
                 
                 // Case 4: Neither is NaN (should perform normal addition)
                 Complex c1 = new Complex(1.0, 2.0);
                 Complex c2 = new Complex(3.0, 4.0);
                 Complex result = c1.add(c2);
                 assertEquals("Real part should be added correctly", 4.0, result.getReal(), 0.0001);
                 assertEquals("Imaginary part should be added correctly", 6.0, result.getImaginary(), 0.0001);
             }

 @Test
            public void testAddWithNaN() {
                // Create a NaN complex number
                Complex nanComplex = new Complex(Double.NaN, 0.0);
                // Create a valid complex number
                Complex validComplex = new Complex(1.0, 2.0);
                
                // Test adding NaN with valid number (should return NaN)
                Complex result1 = validComplex.add(nanComplex);
                assertTrue("Adding with NaN should return NaN", result1.isNaN());
                
                // Test adding valid with NaN (should return NaN)
                Complex result2 = nanComplex.add(validComplex);
                assertTrue("Adding NaN with valid should return NaN", result2.isNaN());
                
                // Test adding two NaN numbers (should return NaN)
                Complex result3 = nanComplex.add(nanComplex);
                assertTrue("Adding two NaNs should return NaN", result3.isNaN());
            }

 @Test
            public void testAddWithValidNumbers() {
                // Create two valid complex numbers
                Complex c1 = new Complex(1.0, 2.0);
                Complex c2 = new Complex(3.0, 4.0);
                
                // Test normal addition
                Complex result = c1.add(c2);
                assertEquals("Real part should be 4.0", 4.0, result.getReal(), 0.0001);
                assertEquals("Imaginary part should be 6.0", 6.0, result.getImaginary(), 0.0001);
                assertFalse("Result should not be NaN", result.isNaN());
            }

 @Test
           public void testAdd_WhenRhsIsNaN_ShouldReturnNaN() {
               // Create a valid complex number
               Complex valid = new Complex(1.0, 2.0);
               
               // Create a NaN complex number by using Double.NaN
               Complex nanComplex = new Complex(Double.NaN, Double.NaN);
               
               // Test addition where current is valid but rhs is NaN
               // Original should return NaN, mutant will perform addition
               Complex result = valid.add(nanComplex);
               
               // Verify the result is NaN (using isNaN() method)
               assertTrue("Adding NaN complex number should return NaN", result.isNaN());
               
               // Also verify the opposite case (current is NaN, rhs is valid)
               result = nanComplex.add(valid);
               assertTrue("Adding to NaN complex number should return NaN", result.isNaN());
               
               // Verify normal addition works (both valid)
               Complex anotherValid = new Complex(3.0, 4.0);
               result = valid.add(anotherValid);
               assertEquals(4.0, result.getReal(), 0.0001);
               assertEquals(6.0, result.getImaginary(), 0.0001);
           }

 @Test
          public void testAdd_CurrentObjectIsNaN_ShouldReturnNaN() {
              // Create a NaN complex number (current object)
              Complex nanComplex = new Complex(Double.NaN, 1.0);
              // Create a normal complex number (parameter)
              Complex normalComplex = new Complex(2.0, 3.0);
              
              // The original method should return NaN when either operand is NaN
              Complex result = nanComplex.add(normalComplex);
              
              // Assert that the result is NaN
              assertTrue(result.isNaN());
              
              // Also test the reverse case (normal + NaN) for completeness
              Complex reverseResult = normalComplex.add(nanComplex);
              assertTrue(reverseResult.isNaN());
          }

 @Test
         public void testAddWithNullArgumentShouldThrowException() {
             // Setup
             Complex complex = new Complex(1.0, 2.0);
             
             // Expect exception
             thrown.expect(NullPointerException.class);
             thrown.expectMessage("The complex number must not be null");
             
             // Test
             complex.add(null);
         }

 @Test
        public void testAddWithFirstOperandNaN() {
            // Create first complex number that is NaN
            Complex c1 = new Complex(Double.NaN, 1.0);
            // Create second complex number that is valid
            Complex c2 = new Complex(2.0, 3.0);
            
            // Should return NaN when either operand is NaN (original behavior)
            // Mutated version would incorrectly perform addition
            assertEquals(Complex.NaN, c1.add(c2));
        }

 @Test
        public void testAddWithSecondOperandNaN() {
            // Create first complex number that is valid
            Complex c1 = new Complex(1.0, 2.0);
            // Create second complex number that is NaN
            Complex c2 = new Complex(Double.NaN, 3.0);
            
            // Should return NaN when either operand is NaN (original behavior)
            // Mutated version would incorrectly perform addition
            assertEquals(Complex.NaN, c1.add(c2));
        }

 @Test
        public void testAddWithBothOperandsNaN() {
            // Create both complex numbers as NaN
            Complex c1 = new Complex(Double.NaN, 1.0);
            Complex c2 = new Complex(2.0, Double.NaN);
            
            // Should return NaN when either operand is NaN (original behavior)
            // Mutated version would also return NaN in this case
            assertEquals(Complex.NaN, c1.add(c2));
        }

 @Test
        public void testAddWithValidOperands() {
            // Create both complex numbers as valid
            Complex c1 = new Complex(1.0, 2.0);
            Complex c2 = new Complex(3.0, 4.0);
            
            // Should perform normal addition
            Complex result = c1.add(c2);
            assertEquals(4.0, result.getReal(), 0.0001);
            assertEquals(6.0, result.getImaginary(), 0.0001);
        }

 @Test
       public void testAddWithNaNCurrent() {
           // Create a NaN complex number (using Double.NaN in constructor)
           Complex nanComplex = new Complex(Double.NaN, 0);
           Complex normalComplex = new Complex(1.0, 2.0);
           
           // Original should return NaN, mutant will return new Complex(Double.NaN + 1.0, 0 + 2.0)
           Complex result = nanComplex.add(normalComplex);
           
           // Verify the result is NaN (using isNaN() method)
           assertTrue("Adding NaN complex number should return NaN", result.isNaN());
       }

 @Test
       public void testAddWithNaNArgument() {
           Complex normalComplex = new Complex(1.0, 2.0);
           // Create a NaN complex number (using Double.NaN in constructor)
           Complex nanComplex = new Complex(Double.NaN, 0);
           
           // Original should return NaN, mutant will return new Complex(1.0 + Double.NaN, 2.0 + 0)
           Complex result = normalComplex.add(nanComplex);
           
           // Verify the result is NaN (using isNaN() method)
           assertTrue("Adding with NaN argument should return NaN", result.isNaN());
       }

 @Test
       public void testAddWithBothNaN() {
           // Create two NaN complex numbers
           Complex nanComplex1 = new Complex(Double.NaN, Double.NaN);
           Complex nanComplex2 = new Complex(Double.NaN, Double.NaN);
           
           // Original should return NaN, mutant will return new Complex(Double.NaN + Double.NaN, Double.NaN + Double.NaN)
           Complex result = nanComplex1.add(nanComplex2);
           
           // Verify the result is NaN (using isNaN() method)
           assertTrue("Adding two NaN complex numbers should return NaN", result.isNaN());
       }

 @Test
  public void testAdd_WhenRhsIsNaN_ShouldReturnNaN1() {
      // Create a non-NaN complex number
      Complex nonNaN = new Complex(1.0, 2.0);
      
      // Create a NaN complex number by using Double.NaN
      Complex nanComplex = new Complex(Double.NaN, Double.NaN);
      
      // Verify the add operation
      Complex result = nonNaN.add(nanComplex);
      
      // Original behavior: should return NaN when rhs is NaN
      // Mutated behavior: would return new Complex(1.0 + NaN, 2.0 + NaN) which is wrong
      assertTrue("Should return NaN when rhs is NaN", result.isNaN());
      
      // Additional verification that it's exactly the NaN constant
      assertSame("Should return the NaN constant", Complex.NaN, result);
  }

 @Test
     public void testAdd_CurrentObjectIsNaN_ShouldReturnNaN1() {
         // Create a NaN complex number (current object)
         Complex nanComplex = new Complex(Double.NaN, 0);
         
         // Create a valid complex number (parameter)
         Complex validComplex = new Complex(1.0, 2.0);
         
         // Perform addition
         Complex result = nanComplex.add(validComplex);
         
         // Original behavior: should return NaN when either operand is NaN
         // Mutated behavior: would perform the addition
         assertTrue("Adding NaN complex number should return NaN", 
                   result.isNaN());
     }

 @Test
     public void testAdd_ParameterIsNaN_ShouldReturnNaN() {
         // Create a valid complex number (current object)
         Complex validComplex = new Complex(1.0, 2.0);
         
         // Create a NaN complex number (parameter)
         Complex nanComplex = new Complex(Double.NaN, 0);
         
         // Perform addition
         Complex result = validComplex.add(nanComplex);
         
         // Both original and mutated behavior should return NaN
         assertTrue("Adding with NaN parameter should return NaN", 
                   result.isNaN());
     }

}
