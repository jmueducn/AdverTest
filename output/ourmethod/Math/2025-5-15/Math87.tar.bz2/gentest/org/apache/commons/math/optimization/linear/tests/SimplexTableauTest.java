package gentest.org.apache.commons.math.optimization.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.linear.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.math.linear.MatrixUtils;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.RealMatrixImpl;
import org.apache.commons.math.linear.RealVector;
import org.apache.commons.math.optimization.GoalType;
import org.apache.commons.math.optimization.RealPointValuePair;
import org.apache.commons.math.util.MathUtils;
 
public class SimplexTableauTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                              public void testGetBasicRow_SingleBasicRowFound() throws Exception {
                                                                                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                                                                                  LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                                                                                                                  Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                                                                                                  constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 1));
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Use reflection to create SimplexTableau instance
                                                                                                                                                                                                                                                                                  Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                                                                                  Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                                                                                      LinearObjectiveFunction.class, 
                                                                                                                                                                                                                                                                                      Collection.class, 
                                                                                                                                                                                                                                                                                      GoalType.class, 
                                                                                                                                                                                                                                                                                      boolean.class, 
                                                                                                                                                                                                                                                                                      double.class
                                                                                                                                                                                                                                                                                  );
                                                                                                                                                                                                                                                                                  constructor.setAccessible(true);
                                                                                                                                                                                                                                                                                  Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, 1.0e-6);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  int col = 3;
                                                                                                                                                                                                                                                                                  Method getHeightMethod = tableauClass.getDeclaredMethod("getHeight");
                                                                                                                                                                                                                                                                                  getHeightMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                  int height = (Integer) getHeightMethod.invoke(tableau);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  Method getNumObjectiveFunctionsMethod = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                                                                                                                                                                                                                                                                  getNumObjectiveFunctionsMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                  int numObjFunctions = (Integer) getNumObjectiveFunctionsMethod.invoke(tableau);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  int basicRow = 4;
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Set one row to 1.0 and others to 0.0 using reflection
                                                                                                                                                                                                                                                                                  Method setEntryMethod = tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                                                                                                                                  setEntryMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  for (int i = numObjFunctions; i < height; i++) {
                                                                                                                                                                                                                                                                                      if (i == basicRow) {
                                                                                                                                                                                                                                                                                          setEntryMethod.invoke(tableau, i, col, 1.0);
                                                                                                                                                                                                                                                                                      } else {
                                                                                                                                                                                                                                                                                          setEntryMethod.invoke(tableau, i, col, 0.0);
                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Test using reflection to access private method
                                                                                                                                                                                                                                                                                  Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                                                                                  getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                  Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                                                                                  assertEquals(Integer.valueOf(basicRow), result);
                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                              public void testGetBasicRow_WithEpsilonPrecision() throws Exception {
                                                                                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                                                                                  double EPSILON = 1.0e-6;
                                                                                                                                                                                                                                                                                  int col = 0;
                                                                                                                                                                                                                                                                                  int height = 3;
                                                                                                                                                                                                                                                                                  int numObjFunctions = 0;
                                                                                                                                                                                                                                                                                  int basicRow = 1;
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Create objects needed for SimplexTableau constructor
                                                                                                                                                                                                                                                                                  LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                                                                                                                  Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                                                                                                  constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 1));
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Create SimplexTableau instance using reflection
                                                                                                                                                                                                                                                                                  Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                                                                                  Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                                                                                      LinearObjectiveFunction.class, 
                                                                                                                                                                                                                                                                                      Collection.class, 
                                                                                                                                                                                                                                                                                      GoalType.class, 
                                                                                                                                                                                                                                                                                      boolean.class, 
                                                                                                                                                                                                                                                                                      double.class
                                                                                                                                                                                                                                                                                  );
                                                                                                                                                                                                                                                                                  constructor.setAccessible(true);
                                                                                                                                                                                                                                                                                  Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, EPSILON);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Use reflection to set up the tableau entries
                                                                                                                                                                                                                                                                                  Method setEntryMethod = tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                                                                                                                                  setEntryMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                  setEntryMethod.invoke(tableau, basicRow, col, 1.0 + EPSILON/2);
                                                                                                                                                                                                                                                                                  setEntryMethod.invoke(tableau, 2, col, EPSILON/2);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Use reflection to test the private method
                                                                                                                                                                                                                                                                                  Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                                                                                  getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                  Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                                                                                  assertEquals(Integer.valueOf(basicRow), result);
                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                              public void testGetBasicRow_EmptyTableau() throws Exception {
                                                                                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                                                                                  int col = 0;
                                                                                                                                                                                                                                                                                  double epsilon = 1e-6;
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Create a minimal tableau using reflection
                                                                                                                                                                                                                                                                                  LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0}, 0);
                                                                                                                                                                                                                                                                                  Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                                                                                                  GoalType goalType = GoalType.MAXIMIZE;
                                                                                                                                                                                                                                                                                  boolean restrictToNonNegative = true;
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Get SimplexTableau constructor via reflection
                                                                                                                                                                                                                                                                                  Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                                                                                  Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                                                                                      LinearObjectiveFunction.class, 
                                                                                                                                                                                                                                                                                      Collection.class, 
                                                                                                                                                                                                                                                                                      GoalType.class, 
                                                                                                                                                                                                                                                                                      boolean.class, 
                                                                                                                                                                                                                                                                                      double.class
                                                                                                                                                                                                                                                                                  );
                                                                                                                                                                                                                                                                                  constructor.setAccessible(true);
                                                                                                                                                                                                                                                                                  Object tableau = constructor.newInstance(f, constraints, goalType, restrictToNonNegative, epsilon);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Use reflection to access private method
                                                                                                                                                                                                                                                                                  Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                                                                                  getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Test
                                                                                                                                                                                                                                                                                  Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                                                                                  assertNull(result);
                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                          public void testGetBasicRow_NonZeroValueInOtherRow() throws Exception {
                                                                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                                                                              LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                                                                                                              Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                                                                                              constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 1));
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Use reflection to create SimplexTableau instance
                                                                                                                                                                                                                                                                              Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                                                                              Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                                                                                  LinearObjectiveFunction.class, 
                                                                                                                                                                                                                                                                                  Collection.class, 
                                                                                                                                                                                                                                                                                  GoalType.class, 
                                                                                                                                                                                                                                                                                  boolean.class, 
                                                                                                                                                                                                                                                                                  double.class
                                                                                                                                                                                                                                                                              );
                                                                                                                                                                                                                                                                              constructor.setAccessible(true);
                                                                                                                                                                                                                                                                              Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, 1.0e-6);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Use reflection to access private methods
                                                                                                                                                                                                                                                                              Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                                                                              getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Set up test data
                                                                                                                                                                                                                                                                              int col = 2;
                                                                                                                                                                                                                                                                              int basicRow = 2;
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Get the tableau data through reflection
                                                                                                                                                                                                                                                                              Field dataField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                                                                                                                              dataField.setAccessible(true);
                                                                                                                                                                                                                                                                              RealMatrix matrix = (RealMatrix) dataField.get(tableau);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Set one row to 1.0 and another to non-zero
                                                                                                                                                                                                                                                                              matrix.setEntry(basicRow, col, 1.0);
                                                                                                                                                                                                                                                                              matrix.setEntry(3, col, 0.5);  // Invalid non-zero
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Test
                                                                                                                                                                                                                                                                              Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Verify
                                                                                                                                                                                                                                                                              assertNull(result);
                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                          public void testGetBasicRow_WithNegativeEpsilonPrecision() {
                                                                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                                                                              final double EPSILON = 1.0e-6;
                                                                                                                                                                                                                                                                              LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0}, 0);
                                                                                                                                                                                                                                                                              Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                                                                                              GoalType goalType = GoalType.MAXIMIZE;
                                                                                                                                                                                                                                                                              boolean restrictToNonNegative = true;
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Create real SimplexTableau instance using reflection since constructor isn't public
                                                                                                                                                                                                                                                                              Object tableau = null;
                                                                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                                                                  Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                                                                                  Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                                                                                      LinearObjectiveFunction.class, 
                                                                                                                                                                                                                                                                                      Collection.class, 
                                                                                                                                                                                                                                                                                      GoalType.class, 
                                                                                                                                                                                                                                                                                      boolean.class, 
                                                                                                                                                                                                                                                                                      double.class);
                                                                                                                                                                                                                                                                                  constructor.setAccessible(true);
                                                                                                                                                                                                                                                                                  tableau = constructor.newInstance(f, constraints, goalType, restrictToNonNegative, EPSILON);
                                                                                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                                                                                  fail("Failed to create SimplexTableau instance: " + e.getMessage());
                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              int col = 0;
                                                                                                                                                                                                                                                                              int basicRow = 1;
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Use reflection to set entries since getEntry is protected
                                                                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                                                                  Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                                                                                  Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                                                                                                                                  tableauField.setAccessible(true);
                                                                                                                                                                                                                                                                                  RealMatrix matrix = (RealMatrix) tableauField.get(tableau);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Set one row to approximately 1.0 and others to approximately 0.0
                                                                                                                                                                                                                                                                                  matrix.setEntry(basicRow, col, 1.0 - EPSILON/2);
                                                                                                                                                                                                                                                                                  matrix.setEntry(2, col, -EPSILON/2);
                                                                                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                                                                                  fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Test
                                                                                                                                                                                                                                                                              Integer result = null;
                                                                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                                                                  Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                                                                                  Method getBasicRow = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                                                                                  getBasicRow.setAccessible(true);
                                                                                                                                                                                                                                                                                  result = (Integer) getBasicRow.invoke(tableau, col);
                                                                                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                                                                                  fail("Failed to invoke getBasicRow: " + e.getMessage());
                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Verify
                                                                                                                                                                                                                                                                              assertEquals(Integer.valueOf(basicRow), result);
                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                      public void testGetBasicRow_MultiplePotentialBasicRows() {
                                                                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                                                                          LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                                                                                                          Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                                                                                                                                                                                                                                                          constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 1));
                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                                                                              // Create SimplexTableau instance using reflection
                                                                                                                                                                                                                                                                              Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                                                                              Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                                                                                  LinearObjectiveFunction.class, 
                                                                                                                                                                                                                                                                                  Collection.class, 
                                                                                                                                                                                                                                                                                  GoalType.class, 
                                                                                                                                                                                                                                                                                  boolean.class, 
                                                                                                                                                                                                                                                                                  double.class
                                                                                                                                                                                                                                                                              );
                                                                                                                                                                                                                                                                              constructor.setAccessible(true);
                                                                                                                                                                                                                                                                              Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, 1e-6);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              int col = 1;
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Use reflection to access private methods/fields
                                                                                                                                                                                                                                                                              // Set entries to create multiple potential basic rows
                                                                                                                                                                                                                                                                              Method setEntryMethod = tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                                                                                                                              setEntryMethod.setAccessible(true);
                                                                                                                                                                                                                                                                              setEntryMethod.invoke(tableau, 2, col, 1.0);
                                                                                                                                                                                                                                                                              setEntryMethod.invoke(tableau, 3, col, 1.0);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Get the basic row
                                                                                                                                                                                                                                                                              Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                                                                              getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                                                                                              Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Verify
                                                                                                                                                                                                                                                                              assertNull(result);
                                                                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                                                                              fail("Failed to test getBasicRow due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                  public void testGetBasicRow_NoBasicRowFound() throws Exception {
                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                      org.apache.commons.math.optimization.linear.LinearObjectiveFunction f = 
                                                                                                                                                                                                                                                                          new org.apache.commons.math.optimization.linear.LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                                                                                                      java.util.Collection<org.apache.commons.math.optimization.linear.LinearConstraint> constraints = 
                                                                                                                                                                                                                                                                          new java.util.ArrayList<org.apache.commons.math.optimization.linear.LinearConstraint>();
                                                                                                                                                                                                                                                                      constraints.add(new org.apache.commons.math.optimization.linear.LinearConstraint(
                                                                                                                                                                                                                                                                          new double[]{1, 1}, org.apache.commons.math.optimization.linear.Relationship.LEQ, 1));
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Create SimplexTableau instance through reflection since constructor is not public
                                                                                                                                                                                                                                                                      Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                                                                      java.lang.reflect.Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                                                                          org.apache.commons.math.optimization.linear.LinearObjectiveFunction.class,
                                                                                                                                                                                                                                                                          java.util.Collection.class,
                                                                                                                                                                                                                                                                          org.apache.commons.math.optimization.GoalType.class,
                                                                                                                                                                                                                                                                          boolean.class,
                                                                                                                                                                                                                                                                          double.class);
                                                                                                                                                                                                                                                                      constructor.setAccessible(true);
                                                                                                                                                                                                                                                                      Object tableau = constructor.newInstance(
                                                                                                                                                                                                                                                                          f, 
                                                                                                                                                                                                                                                                          constraints, 
                                                                                                                                                                                                                                                                          org.apache.commons.math.optimization.GoalType.MAXIMIZE,
                                                                                                                                                                                                                                                                          true, 
                                                                                                                                                                                                                                                                          1e-6);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Use reflection to access private method
                                                                                                                                                                                                                                                                      java.lang.reflect.Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                                                                      getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Test column with all zeros (column 2 is after decision variables and slack variables)
                                                                                                                                                                                                                                                                      int col = 2;
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Test
                                                                                                                                                                                                                                                                      Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                      assertNull(result);
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                         public void testGetBasicRowDetectsMutant() throws Exception {
                                                                                                                                                                                                                                                             // Setup test data that will expose the mutant
                                                                                                                                                                                                                                                             int col = 2;
                                                                                                                                                                                                                                                             double epsilon = 0.0001;
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create a real SimplexTableau with minimal setup
                                                                                                                                                                                                                                                             LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0, 0, 0}, 0);
                                                                                                                                                                                                                                                             Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to create SimplexTableau instance
                                                                                                                                                                                                                                                             Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                                                             Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                                                                 LinearObjectiveFunction.class, 
                                                                                                                                                                                                                                                                 Collection.class, 
                                                                                                                                                                                                                                                                 GoalType.class, 
                                                                                                                                                                                                                                                                 boolean.class, 
                                                                                                                                                                                                                                                                 double.class
                                                                                                                                                                                                                                                             );
                                                                                                                                                                                                                                                             constructor.setAccessible(true);
                                                                                                                                                                                                                                                             Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, epsilon);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to access private fields needed for testing
                                                                                                                                                                                                                                                             Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                                                                                                             tableauField.setAccessible(true);
                                                                                                                                                                                                                                                             RealMatrixImpl matrix = new RealMatrixImpl(new double[][]{
                                                                                                                                                                                                                                                                 {1.0, 0.0, 1.0},  // row 0
                                                                                                                                                                                                                                                                 {0.0, 0.0, 0.0},  // row 1
                                                                                                                                                                                                                                                                 {0.0, 0.0, 1.0}    // row 2
                                                                                                                                                                                                                                                             });
                                                                                                                                                                                                                                                             tableauField.set(tableau, matrix);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             Field numObjectiveFunctionsField = tableauClass.getDeclaredField("numObjectiveFunctions");
                                                                                                                                                                                                                                                             numObjectiveFunctionsField.setAccessible(true);
                                                                                                                                                                                                                                                             numObjectiveFunctionsField.set(tableau, 0);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Test the method - should return first row (0) with 1.0 entry
                                                                                                                                                                                                                                                             Method getBasicRow = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                                                             getBasicRow.setAccessible(true);
                                                                                                                                                                                                                                                             Integer result = (Integer) getBasicRow.invoke(tableau, col);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify the correct behavior
                                                                                                                                                                                                                                                             assertEquals(Integer.valueOf(0), result);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // The mutant would return row 2 because:
                                                                                                                                                                                                                                                             // - First iteration: entry=1.0, row=null → sets row=0 (same as original)
                                                                                                                                                                                                                                                             // - Second iteration: entry=0.0 → skips (same as original)
                                                                                                                                                                                                                                                             // - Third iteration: 
                                                                                                                                                                                                                                                             //   - Original: entry=1.0 but row!=null → doesn't set row
                                                                                                                                                                                                                                                             //   - Mutant: entry=1.0 OR row==null → since row!=null, but entry=1.0 → sets row=2
                                                                                                                                                                                                                                                             // So if mutant exists, result would be 2 instead of 0
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                public void testGetBasicRowDetectsEpsilonMutation() throws Exception {
                                                                                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                                                                                    int col = 2;
                                                                                                                                                                                                                                                    double epsilon = 0.0001;
                                                                                                                                                                                                                                                    double valueJustOutsideOriginalEpsilon = 1.0 + 1.5 * epsilon;
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Create minimal real instance of SimplexTableau using reflection
                                                                                                                                                                                                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                                                                                    Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Get SimplexTableau constructor via reflection
                                                                                                                                                                                                                                                    Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                                                    Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                                                        LinearObjectiveFunction.class, 
                                                                                                                                                                                                                                                        Collection.class, 
                                                                                                                                                                                                                                                        GoalType.class, 
                                                                                                                                                                                                                                                        boolean.class, 
                                                                                                                                                                                                                                                        double.class
                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                                                                                                    Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, epsilon);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Use reflection to set internal state for testing
                                                                                                                                                                                                                                                    Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                                                                                                    tableauField.setAccessible(true);
                                                                                                                                                                                                                                                    RealMatrixImpl matrix = (RealMatrixImpl) tableauField.get(tableau);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Setup test matrix data (2 rows after objective functions)
                                                                                                                                                                                                                                                    matrix.setEntry(1, col, valueJustOutsideOriginalEpsilon);
                                                                                                                                                                                                                                                    matrix.setEntry(2, col, 0.0);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Call the private method using reflection
                                                                                                                                                                                                                                                    Method method = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                                                                                                    Integer result = (Integer) method.invoke(tableau, col);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Verify the mutation would be caught
                                                                                                                                                                                                                                                    assertNull("Should return null when value is outside original epsilon range", result);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                       public void testGetBasicRowReturnsCorrectRowIndex() {
                                                                                                                                                                                                                                           // Setup test data
                                                                                                                                                                                                                                           int testCol = 2;
                                                                                                                                                                                                                                           int expectedRow = 3; // The row where we'll place our 1.0
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                               // Create a real SimplexTableau instance with minimal setup using reflection
                                                                                                                                                                                                                                               LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                                                                               Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                                                               constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 1));
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Get SimplexTableau constructor via reflection
                                                                                                                                                                                                                                               Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                                               Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                                                   LinearObjectiveFunction.class, 
                                                                                                                                                                                                                                                   Collection.class, 
                                                                                                                                                                                                                                                   GoalType.class, 
                                                                                                                                                                                                                                                   boolean.class, 
                                                                                                                                                                                                                                                   double.class
                                                                                                                                                                                                                                               );
                                                                                                                                                                                                                                               constructor.setAccessible(true);
                                                                                                                                                                                                                                               Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, 1e-10);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Use reflection to access private tableau field
                                                                                                                                                                                                                                               Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                                                                                               tableauField.setAccessible(true);
                                                                                                                                                                                                                                               RealMatrixImpl matrix = (RealMatrixImpl) tableauField.get(tableau);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Get methods needed for setup
                                                                                                                                                                                                                                               Method getNumObjectiveFunctions = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                                                                                                                                                                                                                               getNumObjectiveFunctions.setAccessible(true);
                                                                                                                                                                                                                                               Method getHeight = tableauClass.getDeclaredMethod("getHeight");
                                                                                                                                                                                                                                               getHeight.setAccessible(true);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Set up test data in the matrix
                                                                                                                                                                                                                                               int numObjFunctions = (Integer) getNumObjectiveFunctions.invoke(tableau);
                                                                                                                                                                                                                                               int height = (Integer) getHeight.invoke(tableau);
                                                                                                                                                                                                                                               for (int i = numObjFunctions; i < height; i++) {
                                                                                                                                                                                                                                                   matrix.setEntry(i, testCol, 0.0);
                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                               matrix.setEntry(expectedRow, testCol, 1.0);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Use reflection to test the private method
                                                                                                                                                                                                                                               Method method = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                                                                                               Integer result = (Integer) method.invoke(tableau, testCol);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Verify the result is exactly the expected row (not +1)
                                                                                                                                                                                                                                               assertEquals("Should return exact row index where 1.0 was found", 
                                                                                                                                                                                                                                                          expectedRow, result.intValue());
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                                               fail("Exception during test setup or execution: " + e.getMessage());
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                              public void testGetBasicRow_DetectsNonZeroEntriesAfterOne() throws Exception {
                                                                                                                                                                                                                                  // Setup test data
                                                                                                                                                                                                                                  int col = 2;
                                                                                                                                                                                                                                  double epsilon = 0.000001;
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Create a real SimplexTableau with minimal parameters using reflection
                                                                                                                                                                                                                                  Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                                                                                                                                                                  Object f = linearObjectiveFunctionClass.getConstructor(double[].class, double.class)
                                                                                                                                                                                                                                          .newInstance(new double[]{0, 0}, 0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  List<LinearConstraint> constraints = java.util.Collections.emptyList();
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                                                                                                                                                                                  Object maximize = goalTypeClass.getField("MAXIMIZE").get(null);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                                  Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                                          linearObjectiveFunctionClass, 
                                                                                                                                                                                                                                          Collection.class, 
                                                                                                                                                                                                                                          goalTypeClass, 
                                                                                                                                                                                                                                          boolean.class, 
                                                                                                                                                                                                                                          double.class);
                                                                                                                                                                                                                                  constructor.setAccessible(true);
                                                                                                                                                                                                                                  Object tableau = constructor.newInstance(f, constraints, maximize, false, epsilon);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Use reflection to set private fields needed for testing
                                                                                                                                                                                                                                  Field numObjectiveFunctionsField = simplexTableauClass.getDeclaredField("numObjectiveFunctions");
                                                                                                                                                                                                                                  numObjectiveFunctionsField.setAccessible(true);
                                                                                                                                                                                                                                  numObjectiveFunctionsField.set(tableau, 0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field heightField = simplexTableauClass.getDeclaredField("height");
                                                                                                                                                                                                                                  heightField.setAccessible(true);
                                                                                                                                                                                                                                  heightField.set(tableau, 3);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Create a mock matrix to control getEntry behavior
                                                                                                                                                                                                                                  RealMatrix matrixMock = mock(RealMatrix.class);
                                                                                                                                                                                                                                  when(matrixMock.getEntry(0, col)).thenReturn(1.0);  // Valid basic row
                                                                                                                                                                                                                                  when(matrixMock.getEntry(1, col)).thenReturn(0.5);  // Invalid non-zero entry
                                                                                                                                                                                                                                  when(matrixMock.getEntry(2, col)).thenReturn(0.0);  // Valid zero entry
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                                                                                                                                                                                                                  tableauField.setAccessible(true);
                                                                                                                                                                                                                                  tableauField.set(tableau, matrixMock);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Test the method - should return null because of the 0.5 entry
                                                                                                                                                                                                                                  Method getBasicRow = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                                  getBasicRow.setAccessible(true);
                                                                                                                                                                                                                                  Integer result = (Integer) getBasicRow.invoke(tableau, col);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Verify the result
                                                                                                                                                                                                                                  assertNull("Should return null when non-zero entry exists after 1.0", result);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Verify interactions
                                                                                                                                                                                                                                  verify(matrixMock).getEntry(0, col);
                                                                                                                                                                                                                                  verify(matrixMock).getEntry(1, col);
                                                                                                                                                                                                                                  // Note: Should not reach getEntry(2,col) due to early return
                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                     public void testGetBasicRow_DetectsNonZeroNonOneEntries() throws Exception {
                                                                                                                                                                                                                         // Setup test data
                                                                                                                                                                                                                         int col = 2;
                                                                                                                                                                                                                         double epsilon = 0.000001;
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Create test objects using reflection
                                                                                                                                                                                                                         Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                                                                                                                                                         Object f = linearObjectiveFunctionClass.getConstructor(double[].class, double.class)
                                                                                                                                                                                                                                 .newInstance(new double[]{0, 0}, 0.0);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                                         Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                                                                                                                                                                         Object goalType = Enum.valueOf((Class<Enum>)goalTypeClass, "MAXIMIZE");
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Create SimplexTableau instance using reflection
                                                                                                                                                                                                                         Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                         Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                                 linearObjectiveFunctionClass, 
                                                                                                                                                                                                                                 Collection.class, 
                                                                                                                                                                                                                                 goalTypeClass, 
                                                                                                                                                                                                                                 boolean.class, 
                                                                                                                                                                                                                                 double.class);
                                                                                                                                                                                                                         constructor.setAccessible(true);
                                                                                                                                                                                                                         Object tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Use reflection to set up test conditions
                                                                                                                                                                                                                         Field heightField = tableauClass.getDeclaredField("height");
                                                                                                                                                                                                                         heightField.setAccessible(true);
                                                                                                                                                                                                                         heightField.set(tableau, 3);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                                                                         tableauField.setAccessible(true);
                                                                                                                                                                                                                         Class<?> realMatrixImplClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                                                                                                                                                                                                         Object matrix = realMatrixImplClass.getConstructor(double[][].class)
                                                                                                                                                                                                                                 .newInstance((Object)new double[3][3]);
                                                                                                                                                                                                                         Method setEntry = realMatrixImplClass.getMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                                                                         setEntry.invoke(matrix, 0, col, 1.0);  // Valid basic row
                                                                                                                                                                                                                         setEntry.invoke(matrix, 1, col, 0.5);  // Invalid value (neither 0 nor 1)
                                                                                                                                                                                                                         setEntry.invoke(matrix, 2, col, 0.0);  // Valid zero
                                                                                                                                                                                                                         tableauField.set(tableau, matrix);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Test the method - should return null because of the 0.5 value
                                                                                                                                                                                                                         Method getBasicRow = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                         getBasicRow.setAccessible(true);
                                                                                                                                                                                                                         Integer result = (Integer) getBasicRow.invoke(tableau, col);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Verify the result
                                                                                                                                                                                                                         assertNull("Method should return null when column contains a value that's neither 0 nor 1", result);
                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                            public void testGetBasicRow_DetectsNonZeroWithinDoubleEpsilon() throws Exception {
                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                int col = 0;
                                                                                                                                                                                                                double epsilon = 0.000001;
                                                                                                                                                                                                                double valueBetweenEpsilons = epsilon * 1.5; // Value between epsilon and 2*epsilon
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Create real SimplexTableau instance using reflection
                                                                                                                                                                                                                LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1.0}, 0.0);
                                                                                                                                                                                                                Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                                GoalType goalType = GoalType.MAXIMIZE;
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Get SimplexTableau constructor
                                                                                                                                                                                                                Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                                Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                                    LinearObjectiveFunction.class, 
                                                                                                                                                                                                                    Collection.class, 
                                                                                                                                                                                                                    GoalType.class, 
                                                                                                                                                                                                                    boolean.class, 
                                                                                                                                                                                                                    double.class
                                                                                                                                                                                                                );
                                                                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                                                                Object tableau = constructor.newInstance(f, constraints, goalType, true, epsilon);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Use reflection to set up test conditions
                                                                                                                                                                                                                Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                                                                tableauField.setAccessible(true);
                                                                                                                                                                                                                RealMatrixImpl matrix = (RealMatrixImpl) tableauField.get(tableau);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Set up test data in the matrix
                                                                                                                                                                                                                matrix.setEntry(0, col, 1.0); // First row has 1.0
                                                                                                                                                                                                                matrix.setEntry(1, col, valueBetweenEpsilons); // Second row has problematic value
                                                                                                                                                                                                                matrix.setEntry(2, col, 0.0); // Third row is zero
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Test the private method using reflection
                                                                                                                                                                                                                Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                                getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                                Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                assertNull("Should return null when a value between epsilon and 2*epsilon is found", result);
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                   public void testGetBasicRow_ShouldReturnNullWhenNonZeroNonOneEntryExists() throws Exception {
                                                                                                                                                                                                       // Setup test data
                                                                                                                                                                                                       int col = 2;
                                                                                                                                                                                                       double epsilon = 0.000001;
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Create real SimplexTableau instance using reflection
                                                                                                                                                                                                       LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                                       Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                                       constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 1));
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Get SimplexTableau constructor via reflection
                                                                                                                                                                                                       Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                       Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                                           LinearObjectiveFunction.class, 
                                                                                                                                                                                                           Collection.class, 
                                                                                                                                                                                                           GoalType.class, 
                                                                                                                                                                                                           boolean.class, 
                                                                                                                                                                                                           double.class
                                                                                                                                                                                                       );
                                                                                                                                                                                                       constructor.setAccessible(true);
                                                                                                                                                                                                       Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, epsilon);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Use reflection to access private fields/methods
                                                                                                                                                                                                       Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                                                       tableauField.setAccessible(true);
                                                                                                                                                                                                       RealMatrixImpl matrix = new RealMatrixImpl(new double[][]{
                                                                                                                                                                                                           {0, 0, 0},  // objective functions
                                                                                                                                                                                                           {0, 0, 0},  // row 0
                                                                                                                                                                                                           {0, 0, 1},  // row 1 (valid basic row)
                                                                                                                                                                                                           {0, 0, 0.5} // row 2 (invalid non-zero, non-one)
                                                                                                                                                                                                       });
                                                                                                                                                                                                       tableauField.set(tableau, matrix);
                                                                                                                                                                                                       
                                                                                                                                                                                                       Field heightField = tableauClass.getDeclaredField("height");
                                                                                                                                                                                                       heightField.setAccessible(true);
                                                                                                                                                                                                       heightField.set(tableau, 3);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Mock the necessary methods
                                                                                                                                                                                                       Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                       getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Call the method under test
                                                                                                                                                                                                       Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Verify the result - should be null due to invalid entry
                                                                                                                                                                                                       assertNull("Should return null when non-zero non-one entry exists", result);
                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                          public void testGetBasicRow_NonZeroNonOneEntry_ShouldReturnNull() {
                                                                                                                                                                                              // Setup test data
                                                                                                                                                                                              int col = 1;
                                                                                                                                                                                              double epsilon = 0.0001;
                                                                                                                                                                                              
                                                                                                                                                                                              try {
                                                                                                                                                                                                  // Create real SimplexTableau with minimal setup using reflection
                                                                                                                                                                                                  Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                                  Class<?> objectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                                                                                                                                  Class<?> constraintClass = Class.forName("org.apache.commons.math.optimization.linear.LinearConstraint");
                                                                                                                                                                                                  Class<?> relationshipClass = Class.forName("org.apache.commons.math.optimization.linear.Relationship");
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create objective function
                                                                                                                                                                                                  Object f = objectiveFunctionClass.getConstructor(double[].class, double.class)
                                                                                                                                                                                                          .newInstance(new double[]{0, 0}, 0.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create constraints
                                                                                                                                                                                                  Collection<Object> constraints = new ArrayList<>();
                                                                                                                                                                                                  Object eqConstraint = constraintClass.getConstructor(double[].class, relationshipClass, double.class)
                                                                                                                                                                                                          .newInstance(new double[]{1, 1}, Enum.valueOf((Class<Enum>)relationshipClass, "EQ"), 0.0);
                                                                                                                                                                                                  constraints.add(eqConstraint);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create tableau
                                                                                                                                                                                                  Object tableau = tableauClass.getConstructor(
                                                                                                                                                                                                          objectiveFunctionClass, 
                                                                                                                                                                                                          Collection.class, 
                                                                                                                                                                                                          Class.forName("org.apache.commons.math.optimization.linear.GoalType"), 
                                                                                                                                                                                                          boolean.class, 
                                                                                                                                                                                                          double.class)
                                                                                                                                                                                                          .newInstance(f, constraints, 
                                                                                                                                                                                                              Enum.valueOf((Class<Enum>)Class.forName("org.apache.commons.math.optimization.linear.GoalType"), "MAXIMIZE"), 
                                                                                                                                                                                                              false, 
                                                                                                                                                                                                              epsilon);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Use reflection to set entries
                                                                                                                                                                                                  Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                                                  tableauField.setAccessible(true);
                                                                                                                                                                                                  Object matrix = tableauField.get(tableau);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Class<?> matrixClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                                                                                                                                                                                  Method setEntry = matrixClass.getMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                                                  setEntry.invoke(matrix, 0, col, 0.5);  // Non-zero, non-one entry
                                                                                                                                                                                                  setEntry.invoke(matrix, 1, col, 0.0);
                                                                                                                                                                                                  setEntry.invoke(matrix, 2, col, 0.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Call the method under test
                                                                                                                                                                                                  Method getBasicRow = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                                  getBasicRow.setAccessible(true);
                                                                                                                                                                                                  Integer result = (Integer) getBasicRow.invoke(tableau, col);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify the result
                                                                                                                                                                                                  assertNull("Should return null when non-zero, non-one entry is found", result);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                                                                                              }
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                 public void testGetBasicRow_ShouldReturnFirstRowWithOne_WhenMultipleRowsExist() {
                                                                                                                                                                                     // Setup test data
                                                                                                                                                                                     int col = 2;
                                                                                                                                                                                     double epsilon = 0.000001;
                                                                                                                                                                                     
                                                                                                                                                                                     try {
                                                                                                                                                                                         // Create actual SimplexTableau with minimal required setup using reflection
                                                                                                                                                                                         Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                                                                                                                         Object f = linearObjectiveFunctionClass.getConstructor(double[].class, double.class)
                                                                                                                                                                                                 .newInstance(new double[]{0, 0}, 0);
                                                                                                                                                                                         
                                                                                                                                                                                         Collection<Object> constraints = new ArrayList<>();
                                                                                                                                                                                         Class<?> linearConstraintClass = Class.forName("org.apache.commons.math.optimization.linear.LinearConstraint");
                                                                                                                                                                                         Class<?> relationshipClass = Class.forName("org.apache.commons.math.optimization.linear.Relationship");
                                                                                                                                                                                         Object eqRelationship = Enum.valueOf((Class<Enum>) relationshipClass, "EQ");
                                                                                                                                                                                         Object constraint = linearConstraintClass.getConstructor(double[].class, relationshipClass, double.class)
                                                                                                                                                                                                 .newInstance(new double[]{1, 1}, eqRelationship, 0);
                                                                                                                                                                                         constraints.add(constraint);
                                                                                                                                                                                         
                                                                                                                                                                                         Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                                                                                                                                         Object minimizeGoal = Enum.valueOf((Class<Enum>) goalTypeClass, "MINIMIZE");
                                                                                                                                                                                         
                                                                                                                                                                                         Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                         Object tableau = simplexTableauClass.getConstructor(linearObjectiveFunctionClass, Collection.class, goalTypeClass, boolean.class, double.class)
                                                                                                                                                                                                 .newInstance(f, constraints, minimizeGoal, true, epsilon);
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to set up test data
                                                                                                                                                                                         // Set height to 3
                                                                                                                                                                                         Field heightField = simplexTableauClass.getDeclaredField("height");
                                                                                                                                                                                         heightField.setAccessible(true);
                                                                                                                                                                                         heightField.set(tableau, 3);
                                                                                                                                                                                         
                                                                                                                                                                                         // Set numObjectiveFunctions to 0
                                                                                                                                                                                         Field numObjField = simplexTableauClass.getDeclaredField("numObjectiveFunctions");
                                                                                                                                                                                         numObjField.setAccessible(true);
                                                                                                                                                                                         numObjField.set(tableau, 0);
                                                                                                                                                                                         
                                                                                                                                                                                         // Set up tableau entries
                                                                                                                                                                                         Field dataField = simplexTableauClass.getDeclaredField("tableau");
                                                                                                                                                                                         dataField.setAccessible(true);
                                                                                                                                                                                         Object matrix = dataField.get(tableau);
                                                                                                                                                                                         Class<?> realMatrixImplClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                                                                                                                                                                         Method setEntryMethod = realMatrixImplClass.getMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                                         setEntryMethod.invoke(matrix, 0, col, 0.0);
                                                                                                                                                                                         setEntryMethod.invoke(matrix, 1, col, 1.0);  // This should be the basic row
                                                                                                                                                                                         setEntryMethod.invoke(matrix, 2, col, 0.0);
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to test the private method
                                                                                                                                                                                         Method method = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                         method.setAccessible(true);
                                                                                                                                                                                         Integer result = (Integer) method.invoke(tableau, col);
                                                                                                                                                                                         
                                                                                                                                                                                         // Assert that the correct row (1) is returned
                                                                                                                                                                                         assertEquals(Integer.valueOf(1), result);
                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                         fail("Failed to setup or invoke getBasicRow method: " + e.getMessage());
                                                                                                                                                                                     }
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                        public void testGetBasicRow_DetectsNonZeroBeforeBasicRow() throws Exception {
                                                                                                                                                                            // Setup test data
                                                                                                                                                                            int col = 2;
                                                                                                                                                                            double epsilon = 0.0001;
                                                                                                                                                                            
                                                                                                                                                                            // Create minimal SimplexTableau instance
                                                                                                                                                                            LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0}, 0);
                                                                                                                                                                            Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                                                                                                                                                            GoalType goalType = GoalType.MAXIMIZE;
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to create SimplexTableau instance
                                                                                                                                                                            Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                            Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                LinearObjectiveFunction.class, 
                                                                                                                                                                                Collection.class, 
                                                                                                                                                                                GoalType.class, 
                                                                                                                                                                                boolean.class, 
                                                                                                                                                                                double.class
                                                                                                                                                                            );
                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                            Object tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set up test conditions
                                                                                                                                                                            Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                            tableauField.setAccessible(true);
                                                                                                                                                                            RealMatrixImpl matrix = new RealMatrixImpl(new double[3][3]);
                                                                                                                                                                            matrix.setEntry(0, col, 0.5);  // Non-zero value before any 1.0
                                                                                                                                                                            matrix.setEntry(1, col, 1.0);  // Would be basic row if not for the earlier non-zero
                                                                                                                                                                            matrix.setEntry(2, col, 0.0);
                                                                                                                                                                            tableauField.set(tableau, matrix);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to get the private method
                                                                                                                                                                            Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                            getBasicRowMethod.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            // Call the method - should return null because of non-zero at row 0
                                                                                                                                                                            Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                                                                                                                                            
                                                                                                                                                                            // Verify the result
                                                                                                                                                                            assertNull("Should return null when non-zero value appears before any basic row", result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                               public void testGetBasicRow_DetectMutant_OrInsteadOfAnd() throws Exception {
                                                                                                                                                                   // Setup test data that will expose the mutant
                                                                                                                                                                   int col = 2;
                                                                                                                                                                   double epsilon = 0.0001;
                                                                                                                                                                   
                                                                                                                                                                   // Create minimal required objects for SimplexTableau constructor
                                                                                                                                                                   LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0, 0, 0}, 0);
                                                                                                                                                                   Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                   GoalType goalType = GoalType.MAXIMIZE;
                                                                                                                                                                   
                                                                                                                                                                   // Use reflection to create SimplexTableau instance
                                                                                                                                                                   Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                   Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                       LinearObjectiveFunction.class, 
                                                                                                                                                                       Collection.class, 
                                                                                                                                                                       GoalType.class, 
                                                                                                                                                                       boolean.class, 
                                                                                                                                                                       double.class
                                                                                                                                                                   );
                                                                                                                                                                   constructor.setAccessible(true);
                                                                                                                                                                   Object tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
                                                                                                                                                                   
                                                                                                                                                                   // Use reflection to set up test data
                                                                                                                                                                   Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                   tableauField.setAccessible(true);
                                                                                                                                                                   Object matrix = tableauField.get(tableau);
                                                                                                                                                                   
                                                                                                                                                                   // Set up a 3x3 matrix with our test data
                                                                                                                                                                   double[][] data = new double[3][3];
                                                                                                                                                                   data[0][col] = 1.0;  // First row matches 1.0
                                                                                                                                                                   data[1][col] = 1.0;  // Second row also matches 1.0
                                                                                                                                                                   data[2][col] = 0.0;  // Third row is 0.0
                                                                                                                                                                   
                                                                                                                                                                   // Set the matrix data through reflection
                                                                                                                                                                   Class<?> matrixClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                                                                                                                                                   Field dataField = matrixClass.getDeclaredField("data");
                                                                                                                                                                   dataField.setAccessible(true);
                                                                                                                                                                   dataField.set(matrix, data);
                                                                                                                                                                   
                                                                                                                                                                   // Get the private getBasicRow method
                                                                                                                                                                   Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                   getBasicRowMethod.setAccessible(true);
                                                                                                                                                                   
                                                                                                                                                                   // Call the method - should return first row (0) in original code
                                                                                                                                                                   Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                                                                                                                                   
                                                                                                                                                                   // Verify the result
                                                                                                                                                                   assertEquals(Integer.valueOf(0), result);  // Original would return first match (0)
                                                                                                                                                                   // Mutant would return last match (1) because OR condition keeps setting row
                                                                                                                                                               }

    @Test
                                                                                                                                                      public void testGetBasicRowDetectsEpsilonMutation1() throws Exception {
                                                                                                                                                          // Setup test data
                                                                                                                                                          int col = 0;
                                                                                                                                                          double epsilon = 0.000001;
                                                                                                                                                          double valueJustAboveEpsilon = 1.0 + epsilon * 1.5; // Between epsilon and epsilon*2
                                                                                                                                                          
                                                                                                                                                          // Create real SimplexTableau instance with minimal parameters using reflection
                                                                                                                                                          LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0}, 0);
                                                                                                                                                          Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                          
                                                                                                                                                          // Get SimplexTableau class and constructor
                                                                                                                                                          Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                          Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                              LinearObjectiveFunction.class, 
                                                                                                                                                              Collection.class, 
                                                                                                                                                              GoalType.class, 
                                                                                                                                                              boolean.class, 
                                                                                                                                                              double.class
                                                                                                                                                          );
                                                                                                                                                          constructor.setAccessible(true);
                                                                                                                                                          Object tableau = constructor.newInstance(f, constraints, GoalType.MINIMIZE, false, epsilon);
                                                                                                                                                          
                                                                                                                                                          // Use reflection to set up the tableau
                                                                                                                                                          Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                          tableauField.setAccessible(true);
                                                                                                                                                          RealMatrixImpl matrix = new RealMatrixImpl(new double[][]{
                                                                                                                                                              {1.0, 0, 0},
                                                                                                                                                              {valueJustAboveEpsilon, 0, 0},
                                                                                                                                                              {0.0, 0, 0}
                                                                                                                                                          });
                                                                                                                                                          tableauField.set(tableau, matrix);
                                                                                                                                                          
                                                                                                                                                          // Mock only the methods we can't set through reflection
                                                                                                                                                          Object spyTableau = spy(tableau);
                                                                                                                                                          when(tableauClass.getMethod("getNumObjectiveFunctions").invoke(spyTableau)).thenReturn(0);
                                                                                                                                                          when(tableauClass.getMethod("getHeight").invoke(spyTableau)).thenReturn(3);
                                                                                                                                                          when(tableauClass.getMethod("getEpsilon").invoke(spyTableau)).thenReturn(epsilon);
                                                                                                                                                          
                                                                                                                                                          // Call the method - in original should return null, mutant would return 1
                                                                                                                                                          Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                          getBasicRowMethod.setAccessible(true);
                                                                                                                                                          Integer result = (Integer) getBasicRowMethod.invoke(spyTableau, col);
                                                                                                                                                          
                                                                                                                                                          // Assert the correct behavior
                                                                                                                                                          assertNull("Should return null when value is outside epsilon tolerance", result);
                                                                                                                                                          
                                                                                                                                                          // Verify interactions
                                                                                                                                                          verify(tableauClass.getMethod("getNumObjectiveFunctions").invoke(spyTableau), times(1));
                                                                                                                                                          verify(tableauClass.getMethod("getHeight").invoke(spyTableau), atLeastOnce());
                                                                                                                                                      }

    @Test
                                                                                                                                             public void testGetBasicRowDetectsRowAssignmentMutant() {
                                                                                                                                                 // Setup test data
                                                                                                                                                 final int col = 2;
                                                                                                                                                 final double epsilon = 0.000001;
                                                                                                                                                 
                                                                                                                                                 // Create test constraints and objective function
                                                                                                                                                 LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0, 0, 0}, 0);
                                                                                                                                                 Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                 constraints.add(new LinearConstraint(new double[]{1, 0, 0}, Relationship.EQ, 0));
                                                                                                                                                 constraints.add(new LinearConstraint(new double[]{0, 1, 0}, Relationship.EQ, 0));
                                                                                                                                                 constraints.add(new LinearConstraint(new double[]{0, 0, 1}, Relationship.EQ, 0));
                                                                                                                                                 
                                                                                                                                                 try {
                                                                                                                                                     // Use reflection to create SimplexTableau instance
                                                                                                                                                     Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                     Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                         LinearObjectiveFunction.class, 
                                                                                                                                                         Collection.class, 
                                                                                                                                                         GoalType.class, 
                                                                                                                                                         boolean.class, 
                                                                                                                                                         double.class
                                                                                                                                                     );
                                                                                                                                                     constructor.setAccessible(true);
                                                                                                                                                     Object tableau = constructor.newInstance(f, constraints, GoalType.MINIMIZE, false, epsilon);
                                                                                                                                                     
                                                                                                                                                     // Use reflection to call setEntry method
                                                                                                                                                     Method setEntryMethod = tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                     setEntryMethod.setAccessible(true);
                                                                                                                                                     setEntryMethod.invoke(tableau, 0, col, 0.0);
                                                                                                                                                     setEntryMethod.invoke(tableau, 1, col, 1.0);  // This should be the basic row
                                                                                                                                                     setEntryMethod.invoke(tableau, 2, col, 0.0);
                                                                                                                                                     
                                                                                                                                                     // Use reflection to test the private method
                                                                                                                                                     Method method = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                     method.setAccessible(true);
                                                                                                                                                     
                                                                                                                                                     // Call the method and verify the result
                                                                                                                                                     Integer result = (Integer) method.invoke(tableau, col);
                                                                                                                                                     
                                                                                                                                                     // The key assertion - should return exact row 1, not 2 (which would happen with row = i + 1 mutation)
                                                                                                                                                     assertEquals("Should return exact row index where 1.0 was found", 
                                                                                                                                                                 Integer.valueOf(1), result);
                                                                                                                                                     
                                                                                                                                                     // Additional verification that we didn't get null
                                                                                                                                                     assertNotNull("Should not return null when valid basic row exists", result);
                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                     fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                                 }
                                                                                                                                             }

    @Test
                                                                                                                                public void testGetBasicRow_DetectsNonZeroValuesNearEpsilon() throws Exception {
                                                                                                                                    // Setup test data
                                                                                                                                    double epsilon = 0.0001;
                                                                                                                                    int col = 0;
                                                                                                                                    
                                                                                                                                    // Create a real SimplexTableau instance using reflection
                                                                                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1.0}, 0.0);
                                                                                                                                    Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                    
                                                                                                                                    // Get SimplexTableau constructor via reflection
                                                                                                                                    Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                    Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                        LinearObjectiveFunction.class, 
                                                                                                                                        Collection.class, 
                                                                                                                                        GoalType.class, 
                                                                                                                                        boolean.class, 
                                                                                                                                        double.class
                                                                                                                                    );
                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                    Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, epsilon);
                                                                                                                                    
                                                                                                                                    // Use reflection to access private getBasicRow method
                                                                                                                                    Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                    getBasicRowMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Set up test data in the tableau
                                                                                                                                    Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                    tableauField.setAccessible(true);
                                                                                                                                    Object matrix = tableauField.get(tableau);
                                                                                                                                    
                                                                                                                                    // Get matrix class and methods via reflection
                                                                                                                                    Class<?> matrixClass = Class.forName("org.apache.commons.math.linear.Array2DRowRealMatrix");
                                                                                                                                    Method setEntryMethod = matrixClass.getMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                    
                                                                                                                                    // Set test values in the matrix
                                                                                                                                    setEntryMethod.invoke(matrix, 0, col, 1.0);  // Valid basic row
                                                                                                                                    setEntryMethod.invoke(matrix, 1, col, epsilon * 1.1);  // Value just above epsilon
                                                                                                                                    setEntryMethod.invoke(matrix, 2, col, 0.0);  // Actual zero
                                                                                                                                    
                                                                                                                                    // Test the method - should return null because of the near-zero value in row 1
                                                                                                                                    Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                                                                                                    
                                                                                                                                    // Verify the result
                                                                                                                                    assertNull("Method should return null when encountering value just above epsilon", result);
                                                                                                                                    
                                                                                                                                    // Verify another case with value just below 2*epsilon
                                                                                                                                    setEntryMethod.invoke(matrix, 1, col, epsilon * 1.9);  // Value just below 2*epsilon
                                                                                                                                    result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                                                                                                    assertNull("Method should return null when encountering value just below 2*epsilon", result);
                                                                                                                                }

    @Test
                                                                                                                       public void testGetBasicRow_ShouldReturnNullWhenNonZeroEntryFoundAfterBasicRow() {
                                                                                                                           // Setup test data
                                                                                                                           int col = 2;
                                                                                                                           double epsilon = 0.0001;
                                                                                                                           
                                                                                                                           try {
                                                                                                                               // Create minimal SimplexTableau instance using reflection
                                                                                                                               Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                               Class<?> objectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                                                               Class<?> constraintClass = Class.forName("org.apache.commons.math.optimization.linear.LinearConstraint");
                                                                                                                               Class<?> relationshipClass = Class.forName("org.apache.commons.math.optimization.linear.Relationship");
                                                                                                                               Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                                                                               
                                                                                                                               // Create objective function
                                                                                                                               Object f = objectiveFunctionClass.getConstructor(double[].class, double.class)
                                                                                                                                   .newInstance(new double[]{0, 0, 0}, 0.0);
                                                                                                                               
                                                                                                                               // Create constraints
                                                                                                                               Collection<Object> constraints = new ArrayList<>();
                                                                                                                               Object constraint = constraintClass.getConstructor(double[].class, relationshipClass, double.class)
                                                                                                                                   .newInstance(new double[]{1, 0, 0}, Enum.valueOf((Class<Enum>)relationshipClass, "EQ"), 0.0);
                                                                                                                               constraints.add(constraint);
                                                                                                                               
                                                                                                                               // Create tableau instance
                                                                                                                               Object tableau = tableauClass.getConstructor(
                                                                                                                                       objectiveFunctionClass, Collection.class, goalTypeClass, boolean.class, double.class)
                                                                                                                                   .newInstance(f, constraints, Enum.valueOf((Class<Enum>)goalTypeClass, "MAXIMIZE"), false, epsilon);
                                                                                                                               
                                                                                                                               // Use reflection to set private fields needed for the test
                                                                                                                               Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                               tableauField.setAccessible(true);
                                                                                                                               Class<?> realMatrixImplClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                                                                                                               Object matrix = realMatrixImplClass.getConstructor(double[][].class)
                                                                                                                                   .newInstance((Object) new double[][]{
                                                                                                                                       {0, 0, 1.0, 0},    // row 0 has 1.0 in col 2
                                                                                                                                       {0, 0, 0.0, 0},     // row 1 has 0.0 in col 2
                                                                                                                                       {0, 0, 0.5, 0}      // row 2 has 0.5 in col 2 (non-zero)
                                                                                                                                   });
                                                                                                                               tableauField.set(tableau, matrix);
                                                                                                                               
                                                                                                                               Field heightField = tableauClass.getDeclaredField("height");
                                                                                                                               heightField.setAccessible(true);
                                                                                                                               heightField.set(tableau, 3);
                                                                                                                               
                                                                                                                               // Call the method under test using reflection
                                                                                                                               Method getBasicRow = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                               getBasicRow.setAccessible(true);
                                                                                                                               Integer result = (Integer) getBasicRow.invoke(tableau, col);
                                                                                                                               
                                                                                                                               // Verify the result - should be null because of non-zero in third row
                                                                                                                               assertNull("Should return null when non-zero entry found after basic row", result);
                                                                                                                           } catch (Exception e) {
                                                                                                                               fail("Reflection failed: " + e.getMessage());
                                                                                                                           }
                                                                                                                       }

    @Test
                                                                                                              public void testGetBasicRow_DetectsNonZeroNonOneEntry_ShouldReturnNull() throws Exception {
                                                                                                                  // Setup test data
                                                                                                                  int col = 1;
                                                                                                                  int height = 3;
                                                                                                                  double epsilon = 0.0001;
                                                                                                                  
                                                                                                                  // Create real SimplexTableau instance with minimal setup using reflection
                                                                                                                  LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0, 0}, 0);
                                                                                                                  Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                  constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 1));
                                                                                                                  
                                                                                                                  // Get SimplexTableau constructor via reflection
                                                                                                                  Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                  Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                      LinearObjectiveFunction.class, 
                                                                                                                      Collection.class, 
                                                                                                                      GoalType.class, 
                                                                                                                      boolean.class, 
                                                                                                                      double.class
                                                                                                                  );
                                                                                                                  constructor.setAccessible(true);
                                                                                                                  Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, epsilon);
                                                                                                                  
                                                                                                                  // Use reflection to set up test data
                                                                                                                  Field heightField = tableauClass.getDeclaredField("height");
                                                                                                                  heightField.setAccessible(true);
                                                                                                                  heightField.set(tableau, height);
                                                                                                                  
                                                                                                                  Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                  tableauField.setAccessible(true);
                                                                                                                  Object matrix = tableauField.get(tableau);
                                                                                                                  
                                                                                                                  // Set entries in the matrix using reflection
                                                                                                                  Class<?> matrixClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                                                                                                  Method setEntryMethod = matrixClass.getMethod("setEntry", int.class, int.class, double.class);
                                                                                                                  setEntryMethod.invoke(matrix, 0, col, 0.5);  // Non-zero, non-one value
                                                                                                                  setEntryMethod.invoke(matrix, 1, col, 0.0);
                                                                                                                  setEntryMethod.invoke(matrix, 2, col, 0.0);
                                                                                                                  
                                                                                                                  // Call method using reflection since it's private
                                                                                                                  Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                  getBasicRowMethod.setAccessible(true);
                                                                                                                  Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                                                                                  
                                                                                                                  // Assertion
                                                                                                                  assertNull("Should return null when non-zero non-one entry found", result);
                                                                                                              }

    @Test
                                                                                                     public void testGetBasicRowDetectsMutant1() throws Exception {
                                                                                                         // Setup test data
                                                                                                         int col = 2;
                                                                                                         double epsilon = 0.0001;
                                                                                                         
                                                                                                         // Create a real SimplexTableau instance with minimal setup using reflection
                                                                                                         LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0, 0, 0}, 0);
                                                                                                         Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                         Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                         Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                             LinearObjectiveFunction.class, 
                                                                                                             Collection.class, 
                                                                                                             GoalType.class, 
                                                                                                             boolean.class, 
                                                                                                             double.class
                                                                                                         );
                                                                                                         constructor.setAccessible(true);
                                                                                                         Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, epsilon);
                                                                                                         
                                                                                                         // Use reflection to set required internal state
                                                                                                         Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                         tableauField.setAccessible(true);
                                                                                                         RealMatrixImpl matrix = new RealMatrixImpl(new double[][]{
                                                                                                             {1.0, 0.0, 1.0},
                                                                                                             {0.0, 0.0, 0.0},
                                                                                                             {1.0, 0.0, 1.0}
                                                                                                         });
                                                                                                         tableauField.set(tableau, matrix);
                                                                                                         
                                                                                                         // Test the method - should return first row (0) with 1.0
                                                                                                         Method getBasicRow = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                         getBasicRow.setAccessible(true);
                                                                                                         Integer result = (Integer) getBasicRow.invoke(tableau, col);
                                                                                                         
                                                                                                         // Verify the result catches the mutant
                                                                                                         // Original code would return 0 (first matching row)
                                                                                                         // Mutant would return null (since row == i can't be true when row is null)
                                                                                                         assertEquals("Should return first row with value 1.0", Integer.valueOf(0), result);
                                                                                                     }

    @Test
                                                                                            public void testGetBasicRow_DetectsNonZeroBeforeBasicRow1() throws Exception {
                                                                                                // Setup test data where:
                                                                                                // - First row has 0.5 in the column (should make method return null)
                                                                                                // - Second row has 1.0 in the column (would be basic row if first check passed)
                                                                                                int testCol = 2;
                                                                                                double epsilon = 0.000001;
                                                                                                
                                                                                                // Create a real SimplexTableau instance with minimal setup using reflection
                                                                                                Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                                Object f = linearObjectiveFunctionClass.getConstructor(double[].class, double.class)
                                                                                                        .newInstance(new double[]{1, 1}, 0.0);
                                                                                                
                                                                                                Collection<Object> constraints = new ArrayList<>();
                                                                                                Class<?> linearConstraintClass = Class.forName("org.apache.commons.math.optimization.linear.LinearConstraint");
                                                                                                Class<?> relationshipClass = Class.forName("org.apache.commons.math.optimization.linear.Relationship");
                                                                                                Object leq = Enum.valueOf((Class<Enum>) relationshipClass, "LEQ");
                                                                                                Object constraint = linearConstraintClass.getConstructor(double[].class, relationshipClass, double.class)
                                                                                                        .newInstance(new double[]{1, 1}, leq, 1.0);
                                                                                                constraints.add(constraint);
                                                                                                
                                                                                                Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                                                Object maximize = Enum.valueOf((Class<Enum>) goalTypeClass, "MAXIMIZE");
                                                                                                
                                                                                                Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                                                                        linearObjectiveFunctionClass, Collection.class, goalTypeClass, boolean.class, double.class);
                                                                                                constructor.setAccessible(true);
                                                                                                Object tableau = constructor.newInstance(f, constraints, maximize, false, epsilon);
                                                                                                
                                                                                                // Use reflection to access private method
                                                                                                Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                getBasicRowMethod.setAccessible(true);
                                                                                                
                                                                                                // Set up the tableau entries using reflection
                                                                                                Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                                                                                tableauField.setAccessible(true);
                                                                                                Object matrix = tableauField.get(tableau);
                                                                                                
                                                                                                // Set the test values in the matrix
                                                                                                Method setEntryMethod = matrix.getClass().getMethod("setEntry", int.class, int.class, double.class);
                                                                                                setEntryMethod.invoke(matrix, 0, testCol, 0.5);  // Non-zero before basic row
                                                                                                setEntryMethod.invoke(matrix, 1, testCol, 1.0);  // Would-be basic row
                                                                                                setEntryMethod.invoke(matrix, 2, testCol, 0.0);  // Zero
                                                                                                
                                                                                                // Call the method - should return null because of non-zero at row 0
                                                                                                Integer result = (Integer) getBasicRowMethod.invoke(tableau, testCol);
                                                                                                
                                                                                                // Verify the original behavior would return null
                                                                                                assertNull("Should return null when non-zero entry appears before basic row", result);
                                                                                            }

    @Test
                                                                               public void testGetBasicRow_ShouldReturnFirstValidRow_WhenMultipleValidRowsExist() throws Exception {
                                                                                   // Setup test data
                                                                                   int col = 2;
                                                                                   double epsilon = 0.0001;
                                                                                   
                                                                                   // Create test constraints and objective function
                                                                                   LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                   Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                   constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 1));
                                                                                   
                                                                                   // Get the SimplexTableau class
                                                                                   Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                   
                                                                                   // Create real SimplexTableau instance using reflection
                                                                                   Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                       LinearObjectiveFunction.class, 
                                                                                       Collection.class, 
                                                                                       GoalType.class, 
                                                                                       boolean.class, 
                                                                                       double.class
                                                                                   );
                                                                                   constructor.setAccessible(true);
                                                                                   Object tableau = constructor.newInstance(
                                                                                       f, 
                                                                                       constraints, 
                                                                                       GoalType.MAXIMIZE, 
                                                                                       true, 
                                                                                       epsilon
                                                                                   );
                                                                                   
                                                                                   // Spy on the real instance to mock specific methods
                                                                                   Object spyTableau = spy(tableau);
                                                                                   
                                                                                   // Mock behavior
                                                                                   when((Integer) tableauClass.getMethod("getNumObjectiveFunctions").invoke(spyTableau)).thenReturn(0);
                                                                                   when((Integer) tableauClass.getMethod("getHeight").invoke(spyTableau)).thenReturn(4);
                                                                                   when((Double) tableauClass.getMethod("getEntry", int.class, int.class).invoke(spyTableau, 0, col)).thenReturn(0.0);
                                                                                   when((Double) tableauClass.getMethod("getEntry", int.class, int.class).invoke(spyTableau, 1, col)).thenReturn(1.0);  // First valid row
                                                                                   when((Double) tableauClass.getMethod("getEntry", int.class, int.class).invoke(spyTableau, 2, col)).thenReturn(1.0);  // Second valid row (should be ignored)
                                                                                   when((Double) tableauClass.getMethod("getEntry", int.class, int.class).invoke(spyTableau, 3, col)).thenReturn(0.0);
                                                                                   
                                                                                   // Call the method
                                                                                   Method getBasicRow = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                   getBasicRow.setAccessible(true);
                                                                                   Integer result = (Integer) getBasicRow.invoke(spyTableau, col);
                                                                                   
                                                                                   // Verify - should return first valid row (1)
                                                                                   assertEquals(Integer.valueOf(1), result);
                                                                               }

    @Test
                                                                      public void testGetBasicRowDetectsEpsilonMutation2() throws Exception {
                                                                          // Setup test with known epsilon value
                                                                          double epsilon = 0.000001;
                                                                          
                                                                          // Use reflection to create SimplexTableau instance
                                                                          Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                          Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                              LinearObjectiveFunction.class,
                                                                              Collection.class,
                                                                              GoalType.class,
                                                                              boolean.class,
                                                                              double.class
                                                                          );
                                                                          constructor.setAccessible(true);
                                                                          
                                                                          // Create mock objects
                                                                          LinearObjectiveFunction mockFunction = mock(LinearObjectiveFunction.class);
                                                                          Collection<LinearConstraint> emptyConstraints = new ArrayList<LinearConstraint>();
                                                                          
                                                                          // Create tableau instance
                                                                          Object tableau = constructor.newInstance(
                                                                              mockFunction,
                                                                              emptyConstraints,
                                                                              GoalType.MAXIMIZE,
                                                                              false,
                                                                              epsilon
                                                                          );
                                                                          
                                                                          // Mock behavior
                                                                          when(tableau.getClass().getMethod("getNumObjectiveFunctions").invoke(tableau)).thenReturn(0);
                                                                          when(tableau.getClass().getMethod("getHeight").invoke(tableau)).thenReturn(3);
                                                                          
                                                                          // Test column index
                                                                          int testCol = 1;
                                                                          
                                                                          // Case 1: Value that's 1.0 within original epsilon but not epsilon*2
                                                                          double boundaryValue1 = 1.0 + epsilon * 0.9;
                                                                          when(tableau.getClass().getMethod("getEntry", int.class, int.class).invoke(tableau, 0, testCol)).thenReturn(boundaryValue1);
                                                                          when(tableau.getClass().getMethod("getEntry", int.class, int.class).invoke(tableau, 1, testCol)).thenReturn(0.0);
                                                                          when(tableau.getClass().getMethod("getEntry", int.class, int.class).invoke(tableau, 2, testCol)).thenReturn(0.0);
                                                                          
                                                                          // Original should find row 0, mutant should miss it
                                                                          assertEquals(Integer.valueOf(0), tableau.getClass().getMethod("getBasicRow", int.class).invoke(tableau, testCol));
                                                                          
                                                                          // Case 2: Value that's 1.0 within epsilon*2 but not original epsilon
                                                                          double boundaryValue2 = 1.0 + epsilon * 1.1;
                                                                          when(tableau.getClass().getMethod("getEntry", int.class, int.class).invoke(tableau, 0, testCol)).thenReturn(boundaryValue2);
                                                                          
                                                                          // Original should return null, mutant would return row 0
                                                                          assertNull(tableau.getClass().getMethod("getBasicRow", int.class).invoke(tableau, testCol));
                                                                          
                                                                          // Case 3: Value that's clearly not 1.0 (outside both tolerances)
                                                                          double invalidValue = 1.0 + epsilon * 3;
                                                                          when(tableau.getClass().getMethod("getEntry", int.class, int.class).invoke(tableau, 0, testCol)).thenReturn(invalidValue);
                                                                          assertNull(tableau.getClass().getMethod("getBasicRow", int.class).invoke(tableau, testCol));
                                                                          
                                                                          // Case 4: Value that's clearly 1.0 (within both tolerances)
                                                                          double validValue = 1.0 + epsilon * 0.1;
                                                                          when(tableau.getClass().getMethod("getEntry", int.class, int.class).invoke(tableau, 0, testCol)).thenReturn(validValue);
                                                                          assertEquals(Integer.valueOf(0), tableau.getClass().getMethod("getBasicRow", int.class).invoke(tableau, testCol));
                                                                      }

    @Test
                                                         public void testGetBasicRow_DetectsRowAssignmentMutant() {
                                                             // Setup test data
                                                             int col = 2;
                                                             int expectedRow = 3; // The row where we'll place our 1.0 entry
                                                             double epsilon = 0.000001;
                                                             
                                                             // Create a real SimplexTableau with minimal required setup
                                                             LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                             Collection<LinearConstraint> constraints = new ArrayList<>();
                                                             constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 1));
                                                             
                                                             // Create tableau instance using reflection
                                                             try {
                                                                 Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                 Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                     LinearObjectiveFunction.class, 
                                                                     Collection.class, 
                                                                     GoalType.class, 
                                                                     boolean.class, 
                                                                     double.class
                                                                 );
                                                                 constructor.setAccessible(true);
                                                                 Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, epsilon);
                                                                 
                                                                 // Use reflection to access private methods to set up test data
                                                                 // Set the height to 5
                                                                 Method setHeight = tableau.getClass().getDeclaredMethod("setHeight", int.class);
                                                                 setHeight.setAccessible(true);
                                                                 setHeight.invoke(tableau, 5);
                                                                 
                                                                 // Set the entry at expectedRow,col to 1.0
                                                                 Method setEntry = tableau.getClass().getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                 setEntry.setAccessible(true);
                                                                 setEntry.invoke(tableau, expectedRow, col, 1.0);
                                                                 
                                                                 // Set other entries in the column to 0.0
                                                                 for (int i = 1; i < 5; i++) {
                                                                     if (i != expectedRow) {
                                                                         setEntry.invoke(tableau, i, col, 0.0);
                                                                     }
                                                                 }
                                                                 
                                                                 // Call the method under test using reflection
                                                                 Method method = tableau.getClass().getDeclaredMethod("getBasicRow", int.class);
                                                                 method.setAccessible(true);
                                                                 Integer result = (Integer) method.invoke(tableau, col);
                                                                 
                                                                 // Verify the result is exactly our expected row, not row+1
                                                                 assertEquals("Should return exact row index where 1.0 was found", 
                                                                             expectedRow, result.intValue());
                                                             } catch (Exception e) {
                                                                 fail("Reflection failed: " + e.getMessage());
                                                             }
                                                         }

    @Test
                                                    public void testGetBasicRow_DetectsNonZeroValuesWithinDoubleEpsilon() throws Exception {
                                                        // Setup test data
                                                        int col = 1;
                                                        double epsilon = 0.000001;
                                                        double valueBetweenEpsilonAndDoubleEpsilon = epsilon * 1.5; // Value that should be detected as non-zero
                                                        
                                                        // Create a real SimplexTableau instance using reflection
                                                        Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                        Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                            LinearObjectiveFunction.class, 
                                                            Collection.class, 
                                                            GoalType.class, 
                                                            boolean.class, 
                                                            double.class
                                                        );
                                                        constructor.setAccessible(true);
                                                        
                                                        // Create dummy parameters for constructor
                                                        LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0}, 0);
                                                        Collection<LinearConstraint> constraints = new ArrayList<>();
                                                        GoalType goalType = GoalType.MAXIMIZE;
                                                        
                                                        // Create instance
                                                        Object tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
                                                        
                                                        // Set up test data using reflection
                                                        Method setEntryMethod = simplexTableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                        setEntryMethod.setAccessible(true);
                                                        setEntryMethod.invoke(tableau, 0, col, 0.0); // First row has zero
                                                        setEntryMethod.invoke(tableau, 1, col, valueBetweenEpsilonAndDoubleEpsilon); // Second row has problematic value
                                                        setEntryMethod.invoke(tableau, 2, col, 0.0); // Third row has zero
                                                        
                                                        // Set height to 3 using reflection
                                                        Field heightField = simplexTableauClass.getDeclaredField("height");
                                                        heightField.setAccessible(true);
                                                        heightField.set(tableau, 3);
                                                        
                                                        // Call the method using reflection
                                                        Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                        getBasicRowMethod.setAccessible(true);
                                                        Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                                        
                                                        // Verify the result
                                                        assertNull("Should return null when a value between epsilon and 2*epsilon is found", result);
                                                    }

    @Test
                                           public void testGetBasicRow_ShouldReturnNullWhenNonZeroEntryFoundAfterOne() throws Exception {
                                               // Setup test data
                                               int col = 2;
                                               int numObjectiveFunctions = 1;
                                               int height = 4;
                                               double epsilon = 0.000001;
                                               
                                               // Create test LinearObjectiveFunction (empty)
                                               LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0, 0, 0}, 0);
                                               
                                               // Create empty constraints
                                               Collection<LinearConstraint> constraints = new ArrayList<>();
                                               
                                               // Get SimplexTableau class and constructor using reflection
                                               Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                               Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                   LinearObjectiveFunction.class, 
                                                   Collection.class, 
                                                   GoalType.class, 
                                                   boolean.class, 
                                                   double.class
                                               );
                                               constructor.setAccessible(true);
                                               
                                               // Create real SimplexTableau instance
                                               Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, epsilon);
                                               
                                               // Use reflection to access private methods for testing
                                               Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                               getBasicRowMethod.setAccessible(true);
                                               
                                               // Set up test data in the tableau
                                               // First we need to get the tableau data using reflection
                                               Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                               tableauField.setAccessible(true);
                                               Object matrix = tableauField.get(tableau);
                                               
                                               // Get setEntry method from matrix class
                                               Method setEntryMethod = matrix.getClass().getMethod("setEntry", int.class, int.class, double.class);
                                               
                                               // Set entries in the matrix
                                               setEntryMethod.invoke(matrix, 1, col, 1.0);  // First row matches 1.0
                                               setEntryMethod.invoke(matrix, 2, col, 0.5);  // Second row has non-zero value
                                               setEntryMethod.invoke(matrix, 3, col, 0.0);  // Third row is zero
                                               
                                               // Call the method using reflection
                                               Integer result = (Integer) getBasicRowMethod.invoke(tableau, col);
                                               
                                               // Verify the result - should be null because of non-zero entry at row 2
                                               assertNull("Should return null when non-zero entry found after 1.0", result);
                                           }

    @Test
                              public void testGetBasicRow_DetectsNonZeroEntry() throws Exception {
                                  // Setup test data
                                  double[][] entries = {
                                      {0.0}, // row 0 (objective)
                                      {1.0}, // row 1
                                      {0.5}  // row 2
                                  };
                                  
                                  // Create mock objects needed for SimplexTableau constructor
                                  LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0}, 0);
                                  List<LinearConstraint> constraints = new ArrayList<>();
                                  GoalType goalType = GoalType.MAXIMIZE;
                                  double epsilon = 1e-10;
                                  
                                  // Get SimplexTableau class and constructor using reflection
                                  Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                  Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                      LinearObjectiveFunction.class, 
                                      Collection.class, 
                                      GoalType.class, 
                                      boolean.class, 
                                      double.class
                                  );
                                  constructor.setAccessible(true);
                                  
                                  // Create SimplexTableau instance
                                  Object tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
                                  
                                  // Use reflection to access private getBasicRow method
                                  Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                  getBasicRowMethod.setAccessible(true);
                                  
                                  // Use reflection to set the tableau data
                                  Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                  tableauField.setAccessible(true);
                                  RealMatrixImpl matrix = new RealMatrixImpl(entries);
                                  tableauField.set(tableau, matrix);
                                  
                                  // Call the method under test
                                  Integer result = (Integer) getBasicRowMethod.invoke(tableau, 0);
                                  
                                  // Verify the result
                                  assertNull("Should return null when non-zero entry found", result);
                              }

    @Test
                     public void testGetBasicRowDetectsMutant2() throws Exception {
                         // Setup test data
                         int col = 1;
                         double epsilon = 0.000001;
                         
                         // Create a real SimplexTableau with minimal setup using reflection
                         LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0, 0}, 0);
                         Collection<LinearConstraint> constraints = new ArrayList<>();
                         GoalType goalType = GoalType.MAXIMIZE;
                         
                         // Get SimplexTableau class and constructor using reflection
                         Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                         Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                             LinearObjectiveFunction.class, 
                             Collection.class, 
                             GoalType.class, 
                             boolean.class, 
                             double.class
                         );
                         constructor.setAccessible(true);
                         Object tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
                         
                         // Use reflection to access private fields needed for testing
                         Field heightField = simplexTableauClass.getDeclaredField("height");
                         heightField.setAccessible(true);
                         heightField.set(tableau, 3);
                         
                         Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                         tableauField.setAccessible(true);
                         RealMatrixImpl matrix = new RealMatrixImpl(new double[3][2]);
                         tableauField.set(tableau, matrix);
                         
                         // Set up test entries
                         matrix.setEntry(0, col, 0.0);
                         matrix.setEntry(1, col, 1.0);  // This should be detected as basic row
                         matrix.setEntry(2, col, 0.0);
                         
                         // Test the method - should return 1 for original, null for mutant
                         Method getBasicRow = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                         getBasicRow.setAccessible(true);
                         Integer result = (Integer) getBasicRow.invoke(tableau, col);
                         
                         // Assertions that will catch the mutant
                         assertNotNull("Should find basic row at index 1", result);
                         assertEquals(1, result.intValue());
                         
                         // Additional test case where multiple 1.0 entries exist
                         matrix.setEntry(2, col, 1.0);
                         result = (Integer) getBasicRow.invoke(tableau, col);
                         assertNotNull("Should find first basic row at index 1", result);
                         assertEquals(1, result.intValue());
                     }

    @Test
    public void testGetBasicRow_NonZeroBeforeOne_ShouldReturnNull() throws Exception {
        // Setup test data
        int col = 2;
        double epsilon = 0.000001;
        
        // Create real SimplexTableau instance with minimal parameters using reflection
        LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0}, 0);
        Collection<LinearConstraint> constraints = new ArrayList<>();
        GoalType goalType = GoalType.MAXIMIZE;
        
        // Get SimplexTableau constructor via reflection
        Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
        Constructor<?> constructor = tableauClass.getDeclaredConstructor(
            LinearObjectiveFunction.class, Collection.class, GoalType.class, boolean.class, double.class);
        constructor.setAccessible(true);
        Object tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
        
        // Use reflection to set private fields needed for test
        Field numObjectiveFunctionsField = tableauClass.getDeclaredField("numObjectiveFunctions");
        numObjectiveFunctionsField.setAccessible(true);
        numObjectiveFunctionsField.set(tableau, 0);
        
        Field heightField = tableauClass.getDeclaredField("height");
        heightField.setAccessible(true);
        heightField.set(tableau, 3);
        
        // Create a spy to control specific method behaviors
        Object spyTableau = spy(tableau);
        
        // Get Method objects for verification
        Method getEntryMethod = tableauClass.getDeclaredMethod("getEntry", int.class, int.class);
        
        // Configure spy behavior
        when(getEntryMethod.invoke(spyTableau, 0, col)).thenReturn(0.5);  // Non-zero before any 1.0
        when(getEntryMethod.invoke(spyTableau, 1, col)).thenReturn(1.0);  // Would be valid if we got here
        when(getEntryMethod.invoke(spyTableau, 2, col)).thenReturn(0.0);  // Zero
        
        // Call the method under test
        Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
        getBasicRowMethod.setAccessible(true);
        Integer result = (Integer) getBasicRowMethod.invoke(spyTableau, col);
        
        // Verify the result - should return null due to early non-zero
        assertNull("Should return null when non-zero entry appears before any 1.0 entry", result);
        
        // Verify interactions by checking that getEntry was called only once (for first row)
        verify(getEntryMethod, times(1)).invoke(spyTableau, 0, col);
        verify(getEntryMethod, never()).invoke(spyTableau, 1, col);
        verify(getEntryMethod, never()).invoke(spyTableau, 2, col);
    }


}
