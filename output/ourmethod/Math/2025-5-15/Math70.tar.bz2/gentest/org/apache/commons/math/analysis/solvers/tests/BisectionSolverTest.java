package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class BisectionSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                public void testSolve_FindsRootInSimpleCase() throws Exception {
                                    // Setup mock function: f(x) = x - 2 (root at x=2)
                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                    when(f.value(1.0)).thenReturn(-1.0);
                                    when(f.value(1.5)).thenReturn(-0.5);
                                    when(f.value(2.0)).thenReturn(0.0);
                                    when(f.value(3.0)).thenReturn(1.0);
                            
                                    BisectionSolver solver = new BisectionSolver(f);
                                    double result = solver.solve(1.0, 3.0);
                                    
                                    assertEquals(2.0, result, 1e-6);
                                }

    @Test
                                public void testSolve_FindsRootWhenRootIsMidpoint() throws Exception {
                                    // Setup mock function: f(x) = x - 1.5 (root at x=1.5)
                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                    when(f.value(1.0)).thenReturn(-0.5);
                                    when(f.value(1.5)).thenReturn(0.0);
                                    when(f.value(2.0)).thenReturn(0.5);
                            
                                    BisectionSolver solver = new BisectionSolver(f);
                                    double result = solver.solve(1.0, 2.0);
                                    
                                    assertEquals(1.5, result, 1e-6);
                                }

    @Test
                                public void testSolve_FindsRootAtIntervalBoundary() throws Exception {
                                    // Setup mock function: f(x) = x - 2 (root at x=2)
                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                    when(f.value(2.0)).thenReturn(0.0);
                                    when(f.value(3.0)).thenReturn(1.0);
                            
                                    BisectionSolver solver = new BisectionSolver(f);
                                    double result = solver.solve(2.0, 3.0);
                                    
                                    assertEquals(2.0, result, 1e-6);
                                }

    @Test
                                public void testSolve_ConvergesWithinSpecifiedAccuracy() throws Exception {
                                    // Setup mock function: f(x) = x - 1.41421356237 (root at sqrt(2))
                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                    when(f.value(anyDouble())).thenAnswer(invocation -> {
                                        double x = (Double)invocation.getArguments()[0];
                                        return x*x - 2.0;
                                    });
                            
                                    BisectionSolver solver = new BisectionSolver(f);
                                    solver.setAbsoluteAccuracy(1e-8);
                                    double result = solver.solve(1.0, 2.0);
                                    
                                    double expected = Math.sqrt(2.0);
                                    assertEquals(expected, result, 1e-8);
                                }

    @Test
                        public void testSolve_ThrowsWhenRootNotBracketed() throws Exception {
                            // Setup mock function where f(min) and f(max) have same sign
                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                            when(f.value(1.0)).thenReturn(1.0);
                            when(f.value(2.0)).thenReturn(2.0);
                            
                            try {
                                BisectionSolver solver = new BisectionSolver(f);
                                solver.solve(1.0, 2.0);
                                fail("Expected IllegalArgumentException");
                            } catch (IllegalArgumentException e) {
                                assertEquals("Function values at endpoints must have different signs", e.getMessage());
                            }
                        }

    @Test
                        public void testSolve_InvalidIntervalThrowsException() throws Exception {
                            org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                            when(f.value(2.0)).thenReturn(1.0);
                            when(f.value(1.0)).thenReturn(-1.0);
                            
                            exception.expect(IllegalArgumentException.class);
                            exception.expectMessage("Endpoints do not specify an interval");
                            
                            BisectionSolver solver = new BisectionSolver(f);
                            solver.solve(2.0, 1.0); // min > max
                        }

    @Test
                    public void testSolve_ThrowsWhenMaxIterationsExceeded() throws Exception {
                        // Setup mock function that converges slowly
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(anyDouble())).thenAnswer(invocation -> {
                            double x = (Double)invocation.getArguments()[0];
                            return x - 1.999999999; // Very close to root at 2.0 but not exact
                        });
                        
                        // Create solver with very small max iterations
                        BisectionSolver solver = new BisectionSolver(f);
                        solver.setMaximalIterationCount(5);
                        
                        try {
                            solver.solve(1.0, 3.0);
                            fail("Expected MaxIterationsExceededException");
                        } catch (MaxIterationsExceededException e) {
                            assertEquals("Maximal number of iterations (5) exceeded", e.getMessage());
                        }
                    }

    @Test
        public void testSolveWithFunctionAndRange() throws FunctionEvaluationException, MaxIterationsExceededException {
            // Setup mock function that crosses zero at x=2
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(1.0)).thenReturn(-1.0);
            when(f.value(2.0)).thenReturn(0.0);
            when(f.value(3.0)).thenReturn(1.0);
            
            BisectionSolver solver = new BisectionSolver(f);
            double result = solver.solve(1.0, 3.0);
            
            assertEquals(2.0, result, 1E-6);
        }

    @Test
        public void testSolveWithFunctionRangeAndInitial() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(0.0)).thenReturn(-2.0);
            when(f.value(1.0)).thenReturn(-1.0);
            when(f.value(2.0)).thenReturn(0.0);
            when(f.value(3.0)).thenReturn(1.0);
            
            BisectionSolver solver = new BisectionSolver(f);
            double result = solver.solve(0.0, 3.0, 1.5);
            
            assertEquals(2.0, result, 1E-6);
        }

    @Test
        public void testSolveWithRootAtEndpoint() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(0.0)).thenReturn(0.0);
            when(f.value(1.0)).thenReturn(1.0);
            
            BisectionSolver solver = new BisectionSolver(f);
            double result = solver.solve(0.0, 1.0);
            
            assertEquals(0.0, result, 1E-6);
        }

    @Test
        public void testSolveWithVerySmallRange() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(1.999999)).thenReturn(-0.000001);
            when(f.value(2.000001)).thenReturn(0.000001);
            
            BisectionSolver solver = new BisectionSolver(f);
            double result = solver.solve(1.999999, 2.000001);
            
            assertEquals(2.0, result, 1E-6);
        }

    @Test
        public void testSolveDoesNotHang() throws FunctionEvaluationException, MaxIterationsExceededException {
            // Test that the solver doesn't hang on valid input
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(0.0)).thenReturn(-1.0);
            when(f.value(1.0)).thenReturn(1.0);
            
            BisectionSolver solver = new BisectionSolver(f);
            double result = solver.solve(0.0, 1.0);
            
            assertTrue(result >= 0.0 && result <= 1.0);
        }

    @Test
        public void testSolve_WithFunctionAndRange_ConvergesToRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
            // Mock a function that crosses zero between 1 and 3 (root at 2)
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(1.0)).thenReturn(-1.0);
            when(f.value(2.0)).thenReturn(0.0);
            when(f.value(3.0)).thenReturn(1.0);
            
            BisectionSolver solver = new BisectionSolver(f);
            double result = solver.solve(1.0, 3.0);
            
            assertEquals(2.0, result, 1e-6);
        }

    @Test
        public void testSolve_WithInitialGuess_ConvergesToRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(0.0)).thenReturn(-1.0);
            when(f.value(1.0)).thenReturn(0.0);
            when(f.value(2.0)).thenReturn(1.0);
            
            BisectionSolver solver = new BisectionSolver(f);
            double result = solver.solve(0.0, 2.0, 1.0);
            
            assertEquals(1.0, result, 1e-6);
        }

    @Test
        public void testSolve_WithFunctionAndRangeAndInitial_ConvergesToRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(-2.0)).thenReturn(-2.0);
            when(f.value(0.0)).thenReturn(0.0);
            when(f.value(2.0)).thenReturn(2.0);
            
            BisectionSolver solver = new BisectionSolver();
            double result = solver.solve(f, -2.0, 2.0, 0.0);
            
            assertEquals(0.0, result, 1e-6);
        }

    @Test
        public void testSolve_WithFunctionAndRange_AtBoundaryCondition() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(0.0)).thenReturn(0.0); // root exactly at boundary
            when(f.value(1.0)).thenReturn(1.0);
            
            BisectionSolver solver = new BisectionSolver(f);
            double result = solver.solve(0.0, 1.0);
            
            assertEquals(0.0, result, 1e-6);
        }

    @Test
        public void testSolve_WithFunctionAndRange_ReverseOrder() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(1.0)).thenReturn(1.0);
            when(f.value(0.0)).thenReturn(-1.0);
            
            BisectionSolver solver = new BisectionSolver(f);
            double result = solver.solve(1.0, 0.0);
            
            assertEquals(0.5, result, 1e-6); // Should find root between 0 and 1
        }

    @Test
        public void testSolve_WithFunctionAndRange_PositiveCase() throws FunctionEvaluationException, MaxIterationsExceededException {
            // Mock a simple function that crosses zero between 1 and 3 (f(x) = x-2)
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            when(function.value(1.0)).thenReturn(-1.0);
            when(function.value(2.0)).thenReturn(0.0);
            when(function.value(3.0)).thenReturn(1.0);
            
            BisectionSolver solver = new BisectionSolver(function);
            double result = solver.solve(1.0, 3.0);
            
            assertEquals(2.0, result, 1E-6);
        }

    @Test
        public void testSolve_WithFunctionAndRange_NegativeCase() throws FunctionEvaluationException, MaxIterationsExceededException {
            // Mock a function that crosses zero between -3 and -1 (f(x) = x+2)
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            when(function.value(-3.0)).thenReturn(-1.0);
            when(function.value(-2.0)).thenReturn(0.0);
            when(function.value(-1.0)).thenReturn(1.0);
            
            BisectionSolver solver = new BisectionSolver(function);
            double result = solver.solve(-3.0, -1.0);
            
            assertEquals(-2.0, result, 1E-6);
        }

    @Test
        public void testSolve_WithRangeOnly_PositiveCase() throws FunctionEvaluationException, MaxIterationsExceededException {
            // Test with default function (needs to be set somehow, but since we don't have the full class,
            // we'll assume the class has a way to set the function)
            // This test might need adjustment based on actual implementation
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            when(function.value(1.0)).thenReturn(-1.0);
            when(function.value(2.0)).thenReturn(0.0);
            when(function.value(3.0)).thenReturn(1.0);
            
            BisectionSolver solver = new BisectionSolver(function);
            double result = solver.solve(1.0, 3.0);
            
            assertEquals(2.0, result, 1E-6);
        }

    @Test
        public void testSolve_WithFunctionAndRangeAndInitial_PositiveCase() throws FunctionEvaluationException, MaxIterationsExceededException {
            // Mock a simple function (f(x) = x-1.5)
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            when(function.value(1.0)).thenReturn(-0.5);
            when(function.value(1.5)).thenReturn(0.0);
            when(function.value(2.0)).thenReturn(0.5);
            
            BisectionSolver solver = new BisectionSolver(function);
            double result = solver.solve(1.0, 2.0, 1.5);
            
            assertEquals(1.5, result, 1E-6);
        }

    @Test
        public void testSolve_WithFunctionAndRange_EdgeCaseRootAtBoundary() throws FunctionEvaluationException, MaxIterationsExceededException {
            // Mock a function with root at the left boundary
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            when(function.value(0.0)).thenReturn(0.0);
            when(function.value(1.0)).thenReturn(1.0);
            
            BisectionSolver solver = new BisectionSolver(function);
            double result = solver.solve(0.0, 1.0);
            
            assertEquals(0.0, result, 1E-6);
        }

    @Test
        public void testSolve_WithFunctionAndRange_VerySmallRange() throws FunctionEvaluationException, MaxIterationsExceededException {
            // Mock a function with root in a very small range
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            when(function.value(1.999999)).thenReturn(-0.000001);
            when(function.value(2.000001)).thenReturn(0.000001);
            
            BisectionSolver solver = new BisectionSolver(function);
            double result = solver.solve(1.999999, 2.000001);
            
            assertEquals(2.0, result, 1E-6);
        }

    @Test
        public void testSolveWithNoRootInRange() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(1.0)).thenReturn(1.0);
            when(f.value(2.0)).thenReturn(2.0);
            when(f.value(3.0)).thenReturn(3.0);
            
            try {
                BisectionSolver solver = new BisectionSolver(f);
                solver.solve(1.0, 3.0);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                assertEquals("Function values at endpoints do not have different signs", e.getMessage());
            }
        }

    @Test
        public void testSolve_WithFunctionAndRange_NoRoot() throws FunctionEvaluationException {
            // Mock a function that doesn't cross zero (f(x) = x^2 + 1)
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            when(function.value(anyDouble())).thenReturn(1.0);
            
            BisectionSolver solver = new BisectionSolver();
            
            try {
                solver.solve(function, -1.0, 1.0);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                // Expected exception
            } catch (MaxIterationsExceededException e) {
                fail("Unexpected MaxIterationsExceededException");
            }
        }

    @Test
    public void testSolveWithRangeOnly() throws MaxIterationsExceededException, FunctionEvaluationException {
        // Test the version that takes only min/max (assuming it uses some default function)
        BisectionSolver solver = new BisectionSolver();
        // This test assumes the default function is x^2 - 4 (root at x=2)
        // Note: In real implementation, we'd need to know the actual default function
        double result = solver.solve(1.0, 3.0);
        
        // Verify result is within bounds and close to expected root (2.0)
        assertTrue(result >= 1.0 && result <= 3.0);
        assertEquals(2.0, result, solver.getAbsoluteAccuracy());
    }

    @Test
    public void testSolve_WithRangeOnly_UsesDefaultFunction() throws MaxIterationsExceededException, FunctionEvaluationException {
        // Test the no-arg constructor and solve with range only
        BisectionSolver solver = new BisectionSolver();
        
        // This will depend on the default function behavior
        // Assuming it's a simple identity function for testing
        double result = solver.solve(-1.0, 1.0);
        
        assertEquals(0.0, result, 1e-6);
    }

    @Test
    public void testSolveWithInvalidRange() throws MaxIterationsExceededException, FunctionEvaluationException {
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        when(f.value(anyDouble())).thenReturn(0.0); // Mock function to return a value without throwing exception
        ExpectedException exception = ExpectedException.none();
        
        exception.expect(IllegalArgumentException.class);
        exception.expectMessage("Endpoints do not specify an interval");
        
        BisectionSolver solver = new BisectionSolver(f);
        solver.solve(3.0, 1.0); // max < min
    }

    @Test
    public void testSolve_WithInvalidRange_ThrowsIllegalArgumentException() {
        // Setup
        UnivariateRealFunction f = new UnivariateRealFunction() {
            public double value(double x) {
                return 1.0; // Always return 1.0 to simulate no sign change
            }
        };
        
        BisectionSolver solver = new BisectionSolver();
        
        // Expected exception
        try {
            solver.solve(f, 1.0, 2.0);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertEquals("Function values at endpoints do not have different signs", e.getMessage());
        } catch (org.apache.commons.math.FunctionEvaluationException e) {
            // This shouldn't happen with our test case, but we need to catch it
            fail("Unexpected FunctionEvaluationException");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
            // This shouldn't happen with our test case, but we need to catch it
            fail("Unexpected MaxIterationsExceededException");
        }
    }

    @Test
    public void testSolve_WithInvalidRange() {
        org.apache.commons.math.analysis.UnivariateRealFunction f = new org.apache.commons.math.analysis.UnivariateRealFunction() {
            public double value(double x) {
                return x; // simple identity function for testing
            }
        };
        org.apache.commons.math.analysis.solvers.BisectionSolver solver = new org.apache.commons.math.analysis.solvers.BisectionSolver(f);
        
        try {
            solver.solve(3.0, 1.0);  // max < min
            fail("Expected IllegalArgumentException for invalid range");
        } catch (IllegalArgumentException e) {
            // Expected exception
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
            // Also possible exception that we need to catch
        } catch (org.apache.commons.math.FunctionEvaluationException e) {
            // Handle the checked exception
            fail("Unexpected FunctionEvaluationException");
        }
    }


}
