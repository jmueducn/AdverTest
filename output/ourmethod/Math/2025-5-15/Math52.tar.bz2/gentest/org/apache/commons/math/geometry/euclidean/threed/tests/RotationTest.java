package gentest.org.apache.commons.math.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.geometry.euclidean.threed.*;
import java.io.Serializable;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.FastMath;
 
public class RotationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                               public void testConstructor_ZeroVectorWithNormalization() {
                                                                                                   // Test with zero vector and normalization requested - should throw exception
                                                                                                   thrown.expect(ArithmeticException.class);
                                                                                                   thrown.expectMessage("zero norm");
                                                                                                   
                                                                                                   new Rotation(0.0, 0.0, 0.0, 0.0, true);
                                                                                               }

 @Test
                                                                                               public void testConstructor_XAxisRotation() {
                                                                                                   Vector3D xAxis = new Vector3D(1, 0, 0);
                                                                                                   double angle = Math.PI / 2; // 90 degrees
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(xAxis, angle);
                                                                                                   
                                                                                                   // Verify quaternion components
                                                                                                   double halfAngle = -0.5 * angle;
                                                                                                   double expectedQ0 = FastMath.cos(halfAngle);
                                                                                                   double expectedQ1 = FastMath.sin(halfAngle) * xAxis.getX() / xAxis.getNorm();
                                                                                                   double expectedQ2 = FastMath.sin(halfAngle) * xAxis.getY() / xAxis.getNorm();
                                                                                                   double expectedQ3 = FastMath.sin(halfAngle) * xAxis.getZ() / xAxis.getNorm();
                                                                                                   
                                                                                                   assertEquals(expectedQ0, rotation.getQ0(), 1e-15);
                                                                                                   assertEquals(expectedQ1, rotation.getQ1(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ2(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ3(), 1e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructor_YAxisRotation() {
                                                                                                   Vector3D yAxis = new Vector3D(0, 1, 0);
                                                                                                   double angle = Math.PI; // 180 degrees
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(yAxis, angle);
                                                                                                   
                                                                                                   double halfAngle = -0.5 * angle;
                                                                                                   double expectedQ0 = FastMath.cos(halfAngle);
                                                                                                   double expectedQ2 = FastMath.sin(halfAngle) * yAxis.getY() / yAxis.getNorm();
                                                                                                   
                                                                                                   assertEquals(expectedQ0, rotation.getQ0(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ1(), 1e-15);
                                                                                                   assertEquals(expectedQ2, rotation.getQ2(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ3(), 1e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructor_ZAxisRotation() {
                                                                                                   Vector3D zAxis = new Vector3D(0, 0, 1);
                                                                                                   double angle = Math.PI / 4; // 45 degrees
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(zAxis, angle);
                                                                                                   
                                                                                                   double halfAngle = -0.5 * angle;
                                                                                                   double expectedQ0 = FastMath.cos(halfAngle);
                                                                                                   double expectedQ3 = FastMath.sin(halfAngle) * zAxis.getZ() / zAxis.getNorm();
                                                                                                   
                                                                                                   assertEquals(expectedQ0, rotation.getQ0(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ1(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ2(), 1e-15);
                                                                                                   assertEquals(expectedQ3, rotation.getQ3(), 1e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructor_DiagonalAxisRotation() {
                                                                                                   Vector3D axis = new Vector3D(1, 1, 1);
                                                                                                   double angle = 2 * Math.PI / 3; // 120 degrees
                                                                                                   double norm = axis.getNorm();
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(axis, angle);
                                                                                                   
                                                                                                   double halfAngle = -0.5 * angle;
                                                                                                   double coeff = FastMath.sin(halfAngle) / norm;
                                                                                                   double expectedQ0 = FastMath.cos(halfAngle);
                                                                                                   double expectedQ1 = coeff * axis.getX();
                                                                                                   double expectedQ2 = coeff * axis.getY();
                                                                                                   double expectedQ3 = coeff * axis.getZ();
                                                                                                   
                                                                                                   assertEquals(expectedQ0, rotation.getQ0(), 1e-15);
                                                                                                   assertEquals(expectedQ1, rotation.getQ1(), 1e-15);
                                                                                                   assertEquals(expectedQ2, rotation.getQ2(), 1e-15);
                                                                                                   assertEquals(expectedQ3, rotation.getQ3(), 1e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructor_ZeroAngle() {
                                                                                                   Vector3D axis = new Vector3D(1, 0, 0);
                                                                                                   double angle = 0.0;
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(axis, angle);
                                                                                                   
                                                                                                   // For zero angle, should be identity rotation
                                                                                                   assertEquals(1.0, rotation.getQ0(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ1(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ2(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ3(), 1e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructor_FullRotation() {
                                                                                                   Vector3D axis = new Vector3D(0, 1, 0);
                                                                                                   double angle = 2 * Math.PI; // 360 degrees
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(axis, angle);
                                                                                                   
                                                                                                   // Full rotation should be equivalent to identity
                                                                                                   assertEquals(1.0, rotation.getQ0(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ1(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ2(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ3(), 1e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructor_NegativeAngle() {
                                                                                                   Vector3D axis = new Vector3D(0, 0, 1);
                                                                                                   double angle = -Math.PI / 2; // -90 degrees
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(axis, angle);
                                                                                                   
                                                                                                   double halfAngle = -0.5 * angle;
                                                                                                   double expectedQ0 = FastMath.cos(halfAngle);
                                                                                                   double expectedQ3 = FastMath.sin(halfAngle) * axis.getZ() / axis.getNorm();
                                                                                                   
                                                                                                   assertEquals(expectedQ0, rotation.getQ0(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ1(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ2(), 1e-15);
                                                                                                   assertEquals(expectedQ3, rotation.getQ3(), 1e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructor_NonNormalizedAxis() {
                                                                                                   Vector3D axis = new Vector3D(2, 0, 0); // Non-normalized x-axis
                                                                                                   double angle = Math.PI / 3; // 60 degrees
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(axis, angle);
                                                                                                   
                                                                                                   // Should work the same as normalized axis since we divide by norm
                                                                                                   Vector3D normalizedAxis = axis.normalize();
                                                                                                   Rotation expectedRotation = new Rotation(normalizedAxis, angle);
                                                                                                   
                                                                                                   assertEquals(expectedRotation.getQ0(), rotation.getQ0(), 1e-15);
                                                                                                   assertEquals(expectedRotation.getQ1(), rotation.getQ1(), 1e-15);
                                                                                                   assertEquals(expectedRotation.getQ2(), rotation.getQ2(), 1e-15);
                                                                                                   assertEquals(expectedRotation.getQ3(), rotation.getQ3(), 1e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructor_ValidVectors() {
                                                                                                   Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                   Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                   Vector3D v1 = new Vector3D(1, 0, 0);
                                                                                                   Vector3D v2 = new Vector3D(0, 1, 0);
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                   
                                                                                                   // Should be identity rotation since vectors are identical
                                                                                                   assertEquals(1.0, rotation.getQ0(), 1e-10);
                                                                                                   assertEquals(0.0, rotation.getQ1(), 1e-10);
                                                                                                   assertEquals(0.0, rotation.getQ2(), 1e-10);
                                                                                                   assertEquals(0.0, rotation.getQ3(), 1e-10);
                                                                                               }

 @Test
                                                                                               public void testConstructor_NonOrthogonalVectors() {
                                                                                                   Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                   Vector3D u2 = new Vector3D(1, 1, 0);
                                                                                                   Vector3D v1 = new Vector3D(1, 0, 0);
                                                                                                   Vector3D v2 = new Vector3D(0, 1, 0);
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                   
                                                                                                   // Verify we get a valid rotation (not identity)
                                                                                                   assertNotEquals(1.0, rotation.getQ0(), 1e-10);
                                                                                                   assertTrue(rotation.getQ1() != 0.0 || rotation.getQ2() != 0.0 || rotation.getQ3() != 0.0);
                                                                                               }

 @Test
                                                                                               public void testConstructor_NearlyAlignedVectors() {
                                                                                                   Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                   Vector3D u2 = new Vector3D(1, 0.0001, 0);
                                                                                                   Vector3D v1 = new Vector3D(1, 0, 0);
                                                                                                   Vector3D v2 = new Vector3D(0, 1, 0);
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                   
                                                                                                   // Should produce a very small rotation
                                                                                                   assertTrue(rotation.getQ0() > 0.9999); // cos(θ/2) close to 1
                                                                                                   assertTrue(Math.abs(rotation.getQ1()) < 0.0001);
                                                                                                   assertTrue(Math.abs(rotation.getQ2()) < 0.0001);
                                                                                                   assertTrue(Math.abs(rotation.getQ3()) < 0.0001);
                                                                                               }

 @Test
                                                                                               public void testConstructor_180DegreeRotation() {
                                                                                                   Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                   Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                   Vector3D v1 = new Vector3D(-1, 0, 0);
                                                                                                   Vector3D v2 = new Vector3D(0, -1, 0);
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                   
                                                                                                   // For 180 degree rotation, q0 should be 0
                                                                                                   assertEquals(0.0, rotation.getQ0(), 1e-10);
                                                                                                   // One of the vector components should be 1 (axis of rotation)
                                                                                                   assertTrue(Math.abs(rotation.getQ1()) == 1.0 || 
                                                                                                             Math.abs(rotation.getQ2()) == 1.0 || 
                                                                                                             Math.abs(rotation.getQ3()) == 1.0);
                                                                                               }

 @Test
                                                                                               public void testConstructor_ArbitraryRotation() {
                                                                                                   Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                   Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                   Vector3D v1 = new Vector3D(0, 1, 0);
                                                                                                   Vector3D v2 = new Vector3D(0, 0, 1);
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                   
                                                                                                   // Verify it's a valid rotation (quaternion norm = 1)
                                                                                                   double norm = rotation.getQ0() * rotation.getQ0() + 
                                                                                                                rotation.getQ1() * rotation.getQ1() + 
                                                                                                                rotation.getQ2() * rotation.getQ2() + 
                                                                                                                rotation.getQ3() * rotation.getQ3();
                                                                                                   assertEquals(1.0, norm, 1e-10);
                                                                                                   
                                                                                                   // Verify it actually performs the expected rotation
                                                                                                   Vector3D rotatedU1 = rotation.applyTo(u1);
                                                                                                   assertEquals(0.0, rotatedU1.distance(v1), 1e-10);
                                                                                               }

 @Test
                                                                                               public void testConstructor_ZeroNormVector() {
                                                                                                   Vector3D zeroVector = new Vector3D(0, 0, 0);
                                                                                                   Vector3D normalVector = new Vector3D(1, 0, 0);
                                                                                                   
                                                                                                   thrown.expect(MathRuntimeException.class);
                                                                                                   thrown.expectMessage(LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR.toString());
                                                                                                   
                                                                                                   new Rotation(zeroVector, normalVector);
                                                                                               }

 @Test
                                                                                               public void testConstructor_OppositeVectors() {
                                                                                                   Vector3D u = new Vector3D(1, 0, 0);
                                                                                                   Vector3D v = new Vector3D(-1, 0, 0);
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(u, v);
                                                                                                   
                                                                                                   // Verify q0 is 0 for PI rotation
                                                                                                   assertEquals(0.0, rotation.getQ0(), 1.0e-15);
                                                                                                   
                                                                                                   // Verify the rotation axis is orthogonal to u
                                                                                                   Vector3D axis = rotation.getAxis();
                                                                                                   assertEquals(0.0, u.dotProduct(axis), 1.0e-15);
                                                                                                   
                                                                                                   // Verify the angle is PI
                                                                                                   assertEquals(Math.PI, rotation.getAngle(), 1.0e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructor_IdenticalVectors() {
                                                                                                   Vector3D u = new Vector3D(1, 0, 0);
                                                                                                   Vector3D v = new Vector3D(1, 0, 0);
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(u, v);
                                                                                                   
                                                                                                   // Should be identity rotation
                                                                                                   assertEquals(1.0, rotation.getQ0(), 1.0e-15);
                                                                                                   assertEquals(0.0, rotation.getQ1(), 1.0e-15);
                                                                                                   assertEquals(0.0, rotation.getQ2(), 1.0e-15);
                                                                                                   assertEquals(0.0, rotation.getQ3(), 1.0e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructor_OrthogonalVectors() {
                                                                                                   Vector3D u = new Vector3D(1, 0, 0);
                                                                                                   Vector3D v = new Vector3D(0, 1, 0);
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(u, v);
                                                                                                   
                                                                                                   // Verify quaternion components
                                                                                                   assertEquals(Math.sqrt(0.5), rotation.getQ0(), 1.0e-15);
                                                                                                   assertEquals(0.0, rotation.getQ1(), 1.0e-15);
                                                                                                   assertEquals(0.0, rotation.getQ2(), 1.0e-15);
                                                                                                   assertEquals(Math.sqrt(0.5), rotation.getQ3(), 1.0e-15);
                                                                                                   
                                                                                                   // Verify angle is PI/2
                                                                                                   assertEquals(Math.PI/2, rotation.getAngle(), 1.0e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructor_GeneralCase() {
                                                                                                   Vector3D u = new Vector3D(1, 1, 0);
                                                                                                   Vector3D v = new Vector3D(0, 1, 1);
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(u, v);
                                                                                                   
                                                                                                   // Verify quaternion is normalized
                                                                                                   double norm = rotation.getQ0() * rotation.getQ0() + 
                                                                                                                rotation.getQ1() * rotation.getQ1() + 
                                                                                                                rotation.getQ2() * rotation.getQ2() + 
                                                                                                                rotation.getQ3() * rotation.getQ3();
                                                                                                   assertEquals(1.0, norm, 1.0e-15);
                                                                                                   
                                                                                                   // Verify the rotation actually transforms u to v
                                                                                                   Vector3D rotatedU = rotation.applyTo(u.normalize());
                                                                                                   Vector3D normalizedV = v.normalize();
                                                                                                   assertEquals(normalizedV.getX(), rotatedU.getX(), 1.0e-15);
                                                                                                   assertEquals(normalizedV.getY(), rotatedU.getY(), 1.0e-15);
                                                                                                   assertEquals(normalizedV.getZ(), rotatedU.getZ(), 1.0e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructor_NearlyOppositeVectors() {
                                                                                                   Vector3D u = new Vector3D(1, 0, 0);
                                                                                                   Vector3D v = new Vector3D(-1.0001, 0.0001, 0.0001);
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(u, v);
                                                                                                   
                                                                                                   // Should still create a valid rotation
                                                                                                   assertNotNull(rotation);
                                                                                                   
                                                                                                   // Verify quaternion is normalized
                                                                                                   double norm = rotation.getQ0() * rotation.getQ0() + 
                                                                                                                rotation.getQ1() * rotation.getQ1() + 
                                                                                                                rotation.getQ2() * rotation.getQ2() + 
                                                                                                                rotation.getQ3() * rotation.getQ3();
                                                                                                   assertEquals(1.0, norm, 1.0e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructorWithRotationOrder_ZeroAngles() {
                                                                                                   // Test with zero angles should result in identity rotation
                                                                                                   RotationOrder order = RotationOrder.XYZ;
                                                                                                   Rotation rotation = new Rotation(order, 0.0, 0.0, 0.0);
                                                                                                   
                                                                                                   assertEquals(1.0, rotation.getQ0(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ1(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ2(), 1e-15);
                                                                                                   assertEquals(0.0, rotation.getQ3(), 1e-15);
                                                                                               }

 @Test
                                                                                               public void testConstructorWithRotationOrder_NaNValues() {
                                                                                                   RotationOrder order = RotationOrder.XYZ;
                                                                                                   
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   new Rotation(order, Double.NaN, 0.1, 0.2);
                                                                                               }

 @Test
                                                                                               public void testConstructorWithRotationOrder_InfiniteValues() {
                                                                                                   RotationOrder order = RotationOrder.XYZ;
                                                                                                   
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   new Rotation(order, 0.1, Double.POSITIVE_INFINITY, 0.2);
                                                                                               }

 @Test
                                                                                               public void testConstructorWithRotationOrder_ConsistencyWithMatrix() {
                                                                                                   // Test that the rotation produces the same result when converted to matrix
                                                                                                   RotationOrder order = RotationOrder.XYZ;
                                                                                                   double alpha1 = 0.1;
                                                                                                   double alpha2 = 0.2;
                                                                                                   double alpha3 = 0.3;
                                                                                                   
                                                                                                   Rotation rotation = new Rotation(order, alpha1, alpha2, alpha3);
                                                                                                   double[][] matrix = rotation.getMatrix();
                                                                                                   
                                                                                                   // Create a vector and apply rotation directly and via matrix
                                                                                                   Vector3D vector = new Vector3D(1, 2, 3);
                                                                                                   Vector3D rotatedDirect = rotation.applyTo(vector);
                                                                                                   
                                                                                                   // Multiply vector by matrix
                                                                                                   double x = matrix[0][0] * vector.getX() + matrix[0][1] * vector.getY() + matrix[0][2] * vector.getZ();
                                                                                                   double y = matrix[1][0] * vector.getX() + matrix[1][1] * vector.getY() + matrix[1][2] * vector.getZ();
                                                                                                   double z = matrix[2][0] * vector.getX() + matrix[2][1] * vector.getY() + matrix[2][2] * vector.getZ();
                                                                                                   Vector3D rotatedViaMatrix = new Vector3D(x, y, z);
                                                                                                   
                                                                                                   assertEquals(0.0, rotatedDirect.distance(rotatedViaMatrix), 1e-10);
                                                                                               }

 @Test
                                                                                       public void testConstructor_NoNormalization() {
                                                                                           // Test with values that don't need normalization
                                                                                           double epsilon = 1.0e-12;
                                                                                           Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);
                                                                                           
                                                                                           assertEquals(1.0, rotation.getQ0(), epsilon);
                                                                                           assertEquals(0.0, rotation.getQ1(), epsilon);
                                                                                           assertEquals(0.0, rotation.getQ2(), epsilon);
                                                                                           assertEquals(0.0, rotation.getQ3(), epsilon);
                                                                                       }

 @Test
                                                                                       public void testConstructor_WithNormalization() {
                                                                                           // Define epsilon for double comparisons
                                                                                           final double EPSILON = 1.0e-15;
                                                                                           
                                                                                           // Test with values that need normalization
                                                                                           Rotation rotation = new Rotation(2.0, 0.0, 0.0, 0.0, true);
                                                                                           
                                                                                           // Expected normalized values
                                                                                           double expectedNorm = 1.0;
                                                                                           double actualNorm = Math.sqrt(
                                                                                               rotation.getQ0() * rotation.getQ0() +
                                                                                               rotation.getQ1() * rotation.getQ1() +
                                                                                               rotation.getQ2() * rotation.getQ2() +
                                                                                               rotation.getQ3() * rotation.getQ3()
                                                                                           );
                                                                                           
                                                                                           assertEquals(expectedNorm, actualNorm, EPSILON);
                                                                                           assertEquals(1.0, rotation.getQ0(), EPSILON);
                                                                                           assertEquals(0.0, rotation.getQ1(), EPSILON);
                                                                                           assertEquals(0.0, rotation.getQ2(), EPSILON);
                                                                                           assertEquals(0.0, rotation.getQ3(), EPSILON);
                                                                                       }

 @Test
                                                                                       public void testConstructor_WithNormalization_NonZeroComponents() {
                                                                                           // Test with all non-zero components that need normalization
                                                                                           Rotation rotation = new Rotation(1.0, 1.0, 1.0, 1.0, true);
                                                                                           
                                                                                           double expectedValue = 0.5; // 1.0 / sqrt(4)
                                                                                           final double EPSILON = 1.0e-12; // tolerance for double comparison
                                                                                           assertEquals(expectedValue, rotation.getQ0(), EPSILON);
                                                                                           assertEquals(expectedValue, rotation.getQ1(), EPSILON);
                                                                                           assertEquals(expectedValue, rotation.getQ2(), EPSILON);
                                                                                           assertEquals(expectedValue, rotation.getQ3(), EPSILON);
                                                                                       }

 @Test
                                                                                       public void testConstructor_ZeroVectorWithoutNormalization() {
                                                                                           // Define tolerance for double comparisons
                                                                                           final double EPSILON = 1.0e-12;
                                                                                           
                                                                                           // Test with zero vector but no normalization requested - should work
                                                                                           Rotation rotation = new Rotation(0.0, 0.0, 0.0, 0.0, false);
                                                                                           
                                                                                           assertEquals(0.0, rotation.getQ0(), EPSILON);
                                                                                           assertEquals(0.0, rotation.getQ1(), EPSILON);
                                                                                           assertEquals(0.0, rotation.getQ2(), EPSILON);
                                                                                           assertEquals(0.0, rotation.getQ3(), EPSILON);
                                                                                       }

 @Test
                                                                                       public void testConstructor_ExtremeValues() {
                                                                                           // Define epsilon for floating point comparison
                                                                                           final double EPSILON = 1.0e-15;
                                                                                           
                                                                                           // Test with very large values that need normalization
                                                                                           Rotation rotation = new Rotation(Double.MAX_VALUE, Double.MAX_VALUE, 
                                                                                                                          Double.MAX_VALUE, Double.MAX_VALUE, true);
                                                                                           
                                                                                           double expectedValue = 0.5; // All components should be equal after normalization
                                                                                           assertEquals(expectedValue, rotation.getQ0(), EPSILON);
                                                                                           assertEquals(expectedValue, rotation.getQ1(), EPSILON);
                                                                                           assertEquals(expectedValue, rotation.getQ2(), EPSILON);
                                                                                           assertEquals(expectedValue, rotation.getQ3(), EPSILON);
                                                                                       }

 @Test
                                                                                       public void testConstructor_AlreadyNormalized() {
                                                                                           // Test with already normalized quaternion
                                                                                           double q0 = Math.sqrt(0.5);
                                                                                           double q1 = Math.sqrt(0.3);
                                                                                           double q2 = Math.sqrt(0.1);
                                                                                           double q3 = Math.sqrt(0.1);
                                                                                           
                                                                                           // Define epsilon for floating point comparisons
                                                                                           final double EPSILON = 1.0e-12;
                                                                                           
                                                                                           Rotation rotation = new Rotation(q0, q1, q2, q3, true);
                                                                                           
                                                                                           // Values should remain unchanged (within floating point precision)
                                                                                           assertEquals(q0, rotation.getQ0(), EPSILON);
                                                                                           assertEquals(q1, rotation.getQ1(), EPSILON);
                                                                                           assertEquals(q2, rotation.getQ2(), EPSILON);
                                                                                           assertEquals(q3, rotation.getQ3(), EPSILON);
                                                                                       }

 @Test
                                                                                       public void testConstructor_NearZeroNorm() {
                                                                                           // Test with values very close to zero that need normalization
                                                                                           Rotation rotation = new Rotation(1e-20, 1e-20, 1e-20, 1e-20, true);
                                                                                           
                                                                                           double expectedValue = 0.5; // All components should be equal after normalization
                                                                                           double epsilon = 1.0e-15; // Small epsilon for double comparison
                                                                                           assertEquals(expectedValue, rotation.getQ0(), epsilon);
                                                                                           assertEquals(expectedValue, rotation.getQ1(), epsilon);
                                                                                           assertEquals(expectedValue, rotation.getQ2(), epsilon);
                                                                                           assertEquals(expectedValue, rotation.getQ3(), epsilon);
                                                                                       }

 @Test
                                                                                       public void testConstructor_ZeroNormAxis() {
                                                                                           org.apache.commons.math.geometry.euclidean.threed.Vector3D zeroVector = 
                                                                                               new org.apache.commons.math.geometry.euclidean.threed.Vector3D(0, 0, 0);
                                                                                           org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                           thrown.expect(org.apache.commons.math.exception.MathArithmeticException.class);
                                                                                           thrown.expectMessage("zero norm for rotation axis");
                                                                                           new org.apache.commons.math.geometry.euclidean.threed.Rotation(zeroVector, 1.0);
                                                                                       }

 @Test
                                                                                       public void testConstructor_ZeroVectorU() {
                                                                                           // Setup exception rule
                                                                                           org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                           
                                                                                           // Test vectors
                                                                                           Vector3D u1 = new Vector3D(0, 0, 0);
                                                                                           Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                           Vector3D v1 = new Vector3D(1, 0, 0);
                                                                                           Vector3D v2 = new Vector3D(0, 1, 0);
                                                                                           
                                                                                           // Expect exception
                                                                                           thrown.expect(org.apache.commons.math.exception.MathIllegalArgumentException.class);
                                                                                           thrown.expectMessage("zero norm for rotation defining vector");
                                                                                           
                                                                                           // Test
                                                                                           new Rotation(u1, u2, v1, v2);
                                                                                       }

 @Test
                                                                                       public void testConstructorWithRotationOrder_CompositionOrder() {
                                                                                           // Verify that rotations are applied in the correct order (right to left)
                                                                                           RotationOrder order = RotationOrder.XYZ;
                                                                                           double alpha1 = 0.1;  // x
                                                                                           double alpha2 = 0.2;  // y
                                                                                           double alpha3 = 0.3;  // z
                                                                                           
                                                                                           // Create individual rotations using axis-angle representation
                                                                                           Rotation r1 = new Rotation(Vector3D.PLUS_I, alpha1);
                                                                                           Rotation r2 = new Rotation(Vector3D.PLUS_J, alpha2);
                                                                                           Rotation r3 = new Rotation(Vector3D.PLUS_K, alpha3);
                                                                                           
                                                                                           // Manual composition (r1.applyTo(r2.applyTo(r3)))
                                                                                           Rotation manualComposition = r1.applyTo(r2.applyTo(r3));
                                                                                           
                                                                                           // Constructor composition
                                                                                           Rotation constructorComposition = new Rotation(order, alpha1, alpha2, alpha3);
                                                                                           
                                                                                           // Should be equal
                                                                                           assertEquals(0.0, Rotation.distance(manualComposition, constructorComposition), 1e-15);
                                                                                       }

 @Test
                                                                               public void testConstructor_ZeroVectorU1() {
                                                                                   try {
                                                                                       Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                       Vector3D u2 = new Vector3D(0, 0, 0);
                                                                                       Vector3D v1 = new Vector3D(1, 0, 0);
                                                                                       Vector3D v2 = new Vector3D(0, 1, 0);
                                                                                       
                                                                                       new Rotation(u1, u2, v1, v2);
                                                                                       fail("Expected MathIllegalArgumentException");
                                                                                   } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
                                                                                       assertEquals("zero norm for rotation defining vector", e.getMessage());
                                                                                   }
                                                                               }

 @Test
                                                   public void testConstructor_ZeroVectorV() {
                                                       Vector3D u1 = new Vector3D(1, 0, 0);
                                                       Vector3D u2 = new Vector3D(0, 1, 0);
                                                       Vector3D v1 = new Vector3D(0, 0, 0);
                                                       Vector3D v2 = new Vector3D(0, 1, 0);
                                                       
                                                       try {
                                                           new Rotation(u1, u2, v1, v2);
                                                           fail("Expected MathIllegalArgumentException");
                                                       } catch (IllegalArgumentException e) {
                                                           assertEquals("zero norm for rotation defining vector", e.getMessage());
                                                       }
                                                   }

 @Test
                                           public void testConstructor_ZeroVectorV1() {
                                               Vector3D u1 = new Vector3D(1, 0, 0);
                                               Vector3D u2 = new Vector3D(0, 1, 0);
                                               Vector3D v1 = new Vector3D(0, 0, 0);
                                               Vector3D v2 = new Vector3D(0, 1, 0);
                                               
                                               try {
                                                   new Rotation(u1, u2, v1, v2);
                                                   fail("Expected IllegalArgumentException");
                                               } catch (IllegalArgumentException e) {
                                                   assertEquals("zero norm for rotation defining vector", e.getMessage());
                                               }
                                           }

 @Test
                                       public void testConstructor_ValidRotationMatrix() {
                                           // Valid rotation matrix (identity matrix)
                                           double[][] matrix = {
                                               {1, 0, 0},
                                               {0, 1, 0},
                                               {0, 0, 1}
                                           };
                                           double threshold = 1e-10;
                                           
                                           try {
                                               Rotation rotation = new Rotation(matrix, threshold);
                                               
                                               assertEquals(1.0, rotation.getQ0(), threshold);
                                               assertEquals(0.0, rotation.getQ1(), threshold);
                                               assertEquals(0.0, rotation.getQ2(), threshold);
                                               assertEquals(0.0, rotation.getQ3(), threshold);
                                           } catch (NotARotationMatrixException e) {
                                               fail("Should not have thrown NotARotationMatrixException for valid rotation matrix");
                                           }
                                       }

 @Test
                                       public void testConstructor_MatrixWithNegativeDeterminant() throws NotARotationMatrixException {
                                           // Matrix with determinant -1 (invalid for rotation)
                                           double[][] matrix = {
                                               {1, 0, 0},
                                               {0, 1, 0},
                                               {0, 0, -1}
                                           };
                                           double threshold = 1e-10;
                                           
                                           thrown.expect(NotARotationMatrixException.class);
                                           thrown.expectMessage("negative determinant");
                                           new Rotation(matrix, threshold);
                                       }

 @Test
                                       public void testConstructor_CloseToRotationMatrix() throws NotARotationMatrixException {
                                           // Matrix that's close to a rotation matrix but needs orthogonalization
                                           double[][] matrix = {
                                               {1.0, 0.01, 0.01},
                                               {0.01, 1.0, 0.01},
                                               {0.01, 0.01, 1.0}
                                           };
                                           double threshold = 1e-5;
                                           
                                           Rotation rotation = new Rotation(matrix, threshold);
                                           
                                           // Verify the resulting quaternion represents a valid rotation
                                           double norm = Math.sqrt(
                                               rotation.getQ0() * rotation.getQ0() +
                                               rotation.getQ1() * rotation.getQ1() +
                                               rotation.getQ2() * rotation.getQ2() +
                                               rotation.getQ3() * rotation.getQ3()
                                           );
                                           assertEquals(1.0, norm, threshold);
                                       }

 @Test
                                       public void testConstructor_QuaternionCalculationPath() throws NotARotationMatrixException {
                                           // Matrix that will take the first calculation path (s > -0.19)
                                           double[][] matrix = {
                                               {0.8, -0.4, 0.4},
                                               {0.4, 0.8, -0.4},
                                               {-0.4, 0.4, 0.8}
                                           };
                                           double threshold = 1e-10;
                                           
                                           Rotation rotation = new Rotation(matrix, threshold);
                                           
                                           // Verify the quaternion components
                                           double norm = rotation.getQ0() * rotation.getQ0() +
                                                        rotation.getQ1() * rotation.getQ1() +
                                                        rotation.getQ2() * rotation.getQ2() +
                                                        rotation.getQ3() * rotation.getQ3();
                                           assertEquals(1.0, norm, threshold);
                                       }

 @Test
                                       public void testConstructor_QuaternionCalculationPath1() throws NotARotationMatrixException {
                                           // Matrix that will take the second calculation path (q1 path)
                                           double[][] matrix = {
                                               {0.5, 0.5, 0.5},
                                               {0.5, 0.5, -0.5},
                                               {-0.5, 0.5, 0.5}
                                           };
                                           double threshold = 1e-10;
                                           
                                           Rotation rotation = new Rotation(matrix, threshold);
                                           
                                           // Verify the quaternion components
                                           double norm = rotation.getQ0() * rotation.getQ0() +
                                                        rotation.getQ1() * rotation.getQ1() +
                                                        rotation.getQ2() * rotation.getQ2() +
                                                        rotation.getQ3() * rotation.getQ3();
                                           assertEquals(1.0, norm, threshold);
                                       }

 @Test
                                       public void testConstructor_QuaternionCalculationPath2() throws NotARotationMatrixException {
                                           // Matrix that will take the third calculation path (q2 path)
                                           double[][] matrix = {
                                               {0.5, -0.5, 0.5},
                                               {0.5, 0.5, 0.5},
                                               {-0.5, 0.5, 0.5}
                                           };
                                           double threshold = 1e-10;
                                           
                                           Rotation rotation = new Rotation(matrix, threshold);
                                           
                                           // Verify the quaternion components
                                           double norm = rotation.getQ0() * rotation.getQ0() +
                                                        rotation.getQ1() * rotation.getQ1() +
                                                        rotation.getQ2() * rotation.getQ2() +
                                                        rotation.getQ3() * rotation.getQ3();
                                           assertEquals(1.0, norm, threshold);
                                       }

 @Test
                                       public void testConstructor_QuaternionCalculationPath3() throws NotARotationMatrixException {
                                           // Matrix that will take the fourth calculation path (q3 path)
                                           double[][] matrix = {
                                               {0.5, 0.5, -0.5},
                                               {-0.5, 0.5, 0.5},
                                               {0.5, 0.5, 0.5}
                                           };
                                           double threshold = 1e-10;
                                           
                                           Rotation rotation = new Rotation(matrix, threshold);
                                           
                                           // Verify the quaternion components
                                           double norm = rotation.getQ0() * rotation.getQ0() +
                                                        rotation.getQ1() * rotation.getQ1() +
                                                        rotation.getQ2() * rotation.getQ2() +
                                                        rotation.getQ3() * rotation.getQ3();
                                           assertEquals(1.0, norm, threshold);
                                       }

 @Test
                                       public void testConstructor_ZeroThreshold() throws NotARotationMatrixException {
                                           // Test with zero threshold (should still work for valid rotation matrix)
                                           double[][] matrix = {
                                               {1, 0, 0},
                                               {0, 1, 0},
                                               {0, 0, 1}
                                           };
                                           double threshold = 0.0;
                                           
                                           Rotation rotation = new Rotation(matrix, threshold);
                                           
                                           assertEquals(1.0, rotation.getQ0(), 1e-15);
                                           assertEquals(0.0, rotation.getQ1(), 1e-15);
                                           assertEquals(0.0, rotation.getQ2(), 1e-15);
                                           assertEquals(0.0, rotation.getQ3(), 1e-15);
                                       }

 @Test
                                       public void testConstructor_JaggedArray() throws NotARotationMatrixException {
                                           // Jagged array (invalid dimensions)
                                           double[][] matrix = {
                                               {1, 0, 0},
                                               {0, 1},
                                               {0, 0, 1}
                                           };
                                           double threshold = 1e-10;
                                           
                                           thrown.expect(NotARotationMatrixException.class);
                                           thrown.expectMessage("a 3x3 matrix");
                                           new Rotation(matrix, threshold);
                                       }

 @Test
                                       public void testConstructorWithRotationOrder_XYZOrder() throws CardanEulerSingularityException {
                                           // Test with XYZ rotation order and typical angles
                                           RotationOrder order = RotationOrder.XYZ;
                                           double alpha1 = 0.1;  // x rotation
                                           double alpha2 = 0.2;  // y rotation
                                           double alpha3 = 0.3;  // z rotation
                                           
                                           Rotation rotation = new Rotation(order, alpha1, alpha2, alpha3);
                                           
                                           // Verify the composed rotation isn't identity
                                           assertNotEquals(1.0, rotation.getQ0(), 1e-15);
                                           
                                           // Verify the angles can be retrieved back (with some tolerance)
                                           double[] angles = rotation.getAngles(order);
                                           assertEquals(alpha1, angles[0], 1e-10);
                                           assertEquals(alpha2, angles[1], 1e-10);
                                           assertEquals(alpha3, angles[2], 1e-10);
                                       }

 @Test
                                       public void testConstructorWithRotationOrder_ZYXOrder() throws CardanEulerSingularityException {
                                           // Test with ZYX rotation order
                                           RotationOrder order = RotationOrder.ZYX;
                                           double alpha1 = 0.3;  // z rotation
                                           double alpha2 = 0.2;  // y rotation
                                           double alpha3 = 0.1;  // x rotation
                                           
                                           Rotation rotation = new Rotation(order, alpha1, alpha2, alpha3);
                                           
                                           // Verify the angles can be retrieved back
                                           double[] angles = rotation.getAngles(order);
                                           assertEquals(alpha1, angles[0], 1e-10);
                                           assertEquals(alpha2, angles[1], 1e-10);
                                           assertEquals(alpha3, angles[2], 1e-10);
                                       }

 @Test
                                       public void testConstructorWithRotationOrder_LargeAngles() throws CardanEulerSingularityException {
                                           // Test with angles larger than 2π
                                           RotationOrder order = RotationOrder.XYZ;
                                           double alpha1 = 2 * Math.PI + 0.1;
                                           double alpha2 = 4 * Math.PI + 0.2;
                                           double alpha3 = -2 * Math.PI + 0.3;
                                           
                                           Rotation rotation = new Rotation(order, alpha1, alpha2, alpha3);
                                           
                                           // The angles should be normalized when retrieved
                                           double[] angles = rotation.getAngles(order);
                                           assertEquals(0.1, angles[0], 1e-10);
                                           assertEquals(0.2, angles[1], 1e-10);
                                           assertEquals(0.3, angles[2], 1e-10);
                                       }

 @Test
                                       public void testConstructor_NullMatrix() {
                                           double threshold = 1e-10;
                                           
                                           thrown.expect(NullPointerException.class);
                                           try {
                                               new Rotation((double[][])null, threshold);
                                           } catch (NotARotationMatrixException e) {
                                               // Ignore this exception as we expect NullPointerException to be thrown first
                                           }
                                       }

 @Test
                                   public void testConstructor_NonSquareMatrix() throws NotARotationMatrixException {
                                       // 2x3 matrix (invalid dimensions)
                                       double[][] matrix = {
                                           {1, 0, 0},
                                           {0, 1, 0}
                                       };
                                       double threshold = 1e-10;
                                       
                                       // Set up expected exception
                                       ExpectedException thrown = ExpectedException.none();
                                       thrown.expect(NotARotationMatrixException.class);
                                       thrown.expectMessage("a 3x3 matrix");
                                       
                                       // Attempt to create rotation with non-square matrix
                                       new Rotation(matrix, threshold);
                                   }

 @Test
                                  public void testVectorRotationWithDifferentNorms() {
                                      // Create input vectors with different norms
                                      Vector3D u1 = new Vector3D(1, 0, 0);  // norm = 1
                                      Vector3D u2 = new Vector3D(0, 1, 0);  // norm = 1
                                      Vector3D v1 = new Vector3D(2, 2, 0);  // norm = sqrt(8)
                                      Vector3D v2 = new Vector3D(0, 3, 0);  // norm = 3
                                      
                                      // Create rotation
                                      Rotation rotation = new Rotation(u1, u2, v1, v2);
                                      
                                      // Apply rotation to u1
                                      Vector3D rotatedU1 = rotation.applyTo(u1);
                                      
                                      // Verify rotated u1 matches v1 in both direction and magnitude
                                      double tolerance = 1e-10;
                                      assertEquals("X component should match", v1.getX(), rotatedU1.getX(), tolerance);
                                      assertEquals("Y component should match", v1.getY(), rotatedU1.getY(), tolerance);
                                      assertEquals("Z component should match", v1.getZ(), rotatedU1.getZ(), tolerance);
                                      assertEquals("Norm should match", v1.getNorm(), rotatedU1.getNorm(), tolerance);
                                      
                                      // Also verify the rotation transforms u2 to v2 (secondary check)
                                      Vector3D rotatedU2 = rotation.applyTo(u2);
                                      assertEquals("X component should match", v2.getX(), rotatedU2.getX(), tolerance);
                                      assertEquals("Y component should match", v2.getY(), rotatedU2.getY(), tolerance);
                                      assertEquals("Z component should match", v2.getZ(), rotatedU2.getZ(), tolerance);
                                  }

 @Test
                              public void testRotationConstructorDetectsMutant() {
                                  // Create test vectors with different norms
                                  Vector3D u1 = new Vector3D(1, 0, 0);  // norm = 1
                                  Vector3D u2 = new Vector3D(0, 1, 0);  // norm = 1
                                  Vector3D v1 = new Vector3D(2, 0, 0);  // norm = 2
                                  Vector3D v2 = new Vector3D(0, 2, 0);  // norm = 2
                                  
                                  // Create rotation that should map u1->v1 and u2->v2
                                  Rotation rotation = new Rotation(u1, u2, v1, v2);
                                  
                                  // Verify the rotation properly transforms u1 to v1 (with correct scaling)
                                  Vector3D transformedU1 = rotation.applyTo(u1);
                                  double tolerance = 1e-10;
                                  assertEquals(v1.getX(), transformedU1.getX(), tolerance);
                                  assertEquals(v1.getY(), transformedU1.getY(), tolerance);
                                  assertEquals(v1.getZ(), transformedU1.getZ(), tolerance);
                                  
                                  // Verify the quaternion components (q0-q3) are calculated correctly
                                  // These values would be different if the mutant was present
                                  double expectedQ0 = 1.0;  // For identity rotation (since u and v are colinear)
                                  double expectedQ1 = 0.0;
                                  double expectedQ2 = 0.0;
                                  double expectedQ3 = 0.0;
                                  
                                  assertEquals(expectedQ0, rotation.getQ0(), tolerance);
                                  assertEquals(expectedQ1, rotation.getQ1(), tolerance);
                                  assertEquals(expectedQ2, rotation.getQ2(), tolerance);
                                  assertEquals(expectedQ3, rotation.getQ3(), tolerance);
                                  
                                  // Additional test with non-colinear vectors
                                  Vector3D u3 = new Vector3D(1, 1, 0);
                                  Vector3D u4 = new Vector3D(0, 1, 1);
                                  Vector3D v3 = new Vector3D(2, 2, 0);
                                  Vector3D v4 = new Vector3D(0, 2, 2);
                                  
                                  Rotation rotation2 = new Rotation(u3, u4, v3, v4);
                                  Vector3D transformedU3 = rotation2.applyTo(u3);
                                  
                                  assertEquals(v3.getX(), transformedU3.getX(), tolerance);
                                  assertEquals(v3.getY(), transformedU3.getY(), tolerance);
                                  assertEquals(v3.getZ(), transformedU3.getZ(), tolerance);
                              }

 @Test
                              public void testRotationConstructorDetectsMutantInV1Normalization() {
                                  // Create input vectors with different norms
                                  Vector3D u1 = new Vector3D(1, 0, 0);  // norm = 1
                                  Vector3D u2 = new Vector3D(0, 1, 0);  // norm = 1
                                  Vector3D v1 = new Vector3D(2, 0, 0);  // norm = 2
                                  Vector3D v2 = new Vector3D(0, 2, 0);  // norm = 2
                                  
                                  // Create rotation that should map u1 to v1 and u2 to v2
                                  Rotation rotation = new Rotation(u1, u2, v1, v2);
                                  
                                  // Apply the rotation to u1
                                  Vector3D rotatedU1 = rotation.applyTo(u1);
                                  
                                  // Verify the rotated u1 has same direction and norm as original v1
                                  // Check norm first (this would fail with the mutant)
                                  assertEquals(v1.getNorm(), rotatedU1.getNorm(), 1.0e-12);
                                  
                                  // Check direction (angle between vectors should be 0)
                                  double angle = Vector3D.angle(v1, rotatedU1);
                                  assertEquals(0.0, angle, 1.0e-12);
                                  
                                  // Also verify u2 transformation for completeness
                                  Vector3D rotatedU2 = rotation.applyTo(u2);
                                  assertEquals(v2.getNorm(), rotatedU2.getNorm(), 1.0e-12);
                                  angle = Vector3D.angle(v2, rotatedU2);
                                  assertEquals(0.0, angle, 1.0e-12);
                              }

 @Test
                              public void testRotationWithDifferentNormsDetectsMutant() {
                                  // Create input vectors with different norms
                                  Vector3D u1 = new Vector3D(1.0, 0.0, 0.0);  // Norm = 1.0
                                  Vector3D u2 = new Vector3D(0.0, 1.0, 0.0);  // Norm = 1.0
                                  Vector3D v1 = new Vector3D(2.0, 0.0, 0.0);  // Norm = 2.0
                                  Vector3D v2 = new Vector3D(0.0, 2.0, 0.0);  // Norm = 2.0
                                  
                                  // Create rotation that should map u1->v1 and u2->v2
                                  Rotation rotation = new Rotation(u1, u2, v1, v2);
                                  
                                  // Verify the rotation correctly transforms u1 to v1's direction
                                  Vector3D rotatedU1 = rotation.applyTo(u1);
                                  // Since v1 was supposed to be normalized to match u1's norm,
                                  // but was scaled incorrectly by mutant, this assertion would fail
                                  assertEquals(1.0, rotatedU1.getNorm(), 1.0e-15);
                                  assertEquals(v1.normalize().getX(), rotatedU1.getX(), 1.0e-15);
                                  assertEquals(v1.normalize().getY(), rotatedU1.getY(), 1.0e-15);
                                  assertEquals(v1.normalize().getZ(), rotatedU1.getZ(), 1.0e-15);
                                  
                                  // Verify quaternion components (would differ with mutant)
                                  // These values are based on expected behavior of original code
                                  assertEquals(1.0, rotation.getQ0(), 1.0e-15);
                                  assertEquals(0.0, rotation.getQ1(), 1.0e-15);
                                  assertEquals(0.0, rotation.getQ2(), 1.0e-15);
                                  assertEquals(0.0, rotation.getQ3(), 1.0e-15);
                                  
                                  // Verify rotation angle is 0 (since we're rotating identical directions)
                                  assertEquals(0.0, rotation.getAngle(), 1.0e-15);
                              }

 @Test
                              public void testRotationFromOrderAnglesDetectsVectorNormalizationMutant() {
                                  // Create vectors with different norms to expose the mutation
                                  Vector3D u1 = new Vector3D(2.0, 0.0, 0.0);  // norm = 2.0
                                  Vector3D u2 = new Vector3D(0.0, 1.0, 0.0);  // norm = 1.0
                                  Vector3D v1 = new Vector3D(3.0, 0.0, 0.0);  // norm = 3.0
                                  Vector3D v2 = new Vector3D(0.0, 1.0, 0.0);  // norm = 1.0
                                  
                                  // Create rotation that should map u1->v1 and u2->v2
                                  Rotation rotation = new Rotation(u1, u2, v1, v2);
                                  
                                  // Apply rotation to u1 and verify it matches v1's direction and has correct scaling
                                  Vector3D transformed = rotation.applyTo(u1);
                                  double expectedScale = v1.getNorm() / u1.getNorm(); // Should be 1.5 (3.0/2.0)
                                  assertEquals(expectedScale, transformed.getNorm() / u1.getNorm(), 1.0e-10);
                                  assertEquals(0.0, transformed.normalize().distance(v1.normalize()), 1.0e-10);
                                  
                                  // Verify some quaternion components (exact values depend on implementation)
                                  // These values would differ if the normalization was incorrect
                                  assertNotEquals(0.0, rotation.getQ0(), 1.0e-10);
                                  assertEquals(0.0, rotation.getQ1(), 1.0e-10); // Since rotation is around z-axis
                                  assertEquals(0.0, rotation.getQ2(), 1.0e-10); // Since rotation is around z-axis
                                  assertNotEquals(0.0, rotation.getQ3(), 1.0e-10);
                                  
                                  // Verify it correctly transforms u2 to v2
                                  Vector3D transformed2 = rotation.applyTo(u2);
                                  assertEquals(0.0, transformed2.distance(v2), 1.0e-10);
                              }

 @Test
                             public void testRotationConstructorDetectsMutantInV1Scaling() {
                                 // Create input vectors with different norms
                                 Vector3D u1 = new Vector3D(1, 0, 0);  // norm = 1
                                 Vector3D u2 = new Vector3D(0, 1, 0);  // norm = 1
                                 Vector3D v1 = new Vector3D(2, 0, 0);  // norm = 2
                                 Vector3D v2 = new Vector3D(0, 2, 0);  // norm = 2
                                 
                                 // Create rotation that should map u1->v1 and u2->v2
                                 Rotation rotation = new Rotation(u1, u2, v1, v2);
                                 
                                 // Verify the rotation transforms u1 to a vector with same direction as v1 but original u1's norm
                                 Vector3D transformedU1 = rotation.applyTo(u1);
                                 double transformedNorm = transformedU1.getNorm();
                                 
                                 // Original behavior: transformed u1 should have same direction as v1 but norm of original u1 (1)
                                 // Mutant behavior: would incorrectly scale and give wrong norm
                                 assertEquals(1.0, transformedNorm, 1.0e-12);
                                 // Check direction by verifying cross product is zero (parallel vectors)
                                 assertEquals(0.0, transformedU1.crossProduct(v1.normalize()).getNorm(), 1.0e-12);
                                 
                                 // Also verify it correctly transforms u1 to v1 (with proper scaling)
                                 Vector3D expectedV1 = new Vector3D(1, 0, 0); // v1 normalized to u1's norm
                                 assertEquals(0.0, transformedU1.distance(expectedV1), 1.0e-12);
                                 
                                 // Verify the rotation properties by checking another vector
                                 Vector3D testVector = new Vector3D(1, 1, 0);
                                 Vector3D rotatedTest = rotation.applyTo(testVector);
                                 // The x component should be scaled by 2 (v1's original scaling)
                                 // while y component should be scaled by 2 (v2's original scaling)
                                 assertEquals(2.0, rotatedTest.getX(), 1.0e-12);
                                 assertEquals(2.0, rotatedTest.getY(), 1.0e-12);
                             }

 @Test
                             public void testVectorConstructorDetectsAlphaCalculationMutant() {
                                 // Create two pairs of vectors that will show the difference between + and -
                                 Vector3D u1 = new Vector3D(1, 0, 0);
                                 Vector3D u2 = new Vector3D(0, 1, 0);
                                 Vector3D v1 = new Vector3D(0.8, 0.6, 0);
                                 Vector3D v2 = new Vector3D(-0.6, 0.8, 0);
                                 
                                 // Create rotation that would be affected by the mutation
                                 Rotation rotation = new Rotation(u1, u2, v1, v2);
                                 
                                 // Test vector to apply rotation to
                                 Vector3D testVector = new Vector3D(1, 1, 0);
                                 Vector3D rotated = rotation.applyTo(testVector);
                                 
                                 // With correct calculation, the rotated vector should be approximately (0.8-0.6, 0.6+0.8)
                                 // With mutated calculation, it would be significantly different
                                 assertEquals(0.2, rotated.getX(), 1e-10);
                                 assertEquals(1.4, rotated.getY(), 1e-10);
                                 assertEquals(0.0, rotated.getZ(), 1e-10);
                                 
                                 // Also verify the rotation preserves vector norms
                                 assertEquals(testVector.getNorm(), rotated.getNorm(), 1e-10);
                             }

 @Test
                             public void testRotationFromTwoPairsOfVectorsDetectsMutant() {
                                 // Create non-orthogonal input vectors
                                 Vector3D u1 = new Vector3D(1, 0, 0);
                                 Vector3D u2 = new Vector3D(1, 1, 0); // 45 degrees from u1
                                 Vector3D v1 = new Vector3D(0, 1, 0);
                                 Vector3D v2 = new Vector3D(-1, 1, 0); // 135 degrees from v1
                                 
                                 // Create rotation that should map u1->v1 and u2->v2
                                 Rotation rotation = new Rotation(u1, u2, v1, v2);
                                 
                                 // Apply rotation to u1 and u2
                                 Vector3D rotatedU1 = rotation.applyTo(u1);
                                 Vector3D rotatedU2 = rotation.applyTo(u2);
                                 
                                 // Verify the rotation worked correctly
                                 double tolerance = 1e-10;
                                 assertEquals(0.0, rotatedU1.distance(v1), tolerance);
                                 assertEquals(0.0, rotatedU2.distance(v2), tolerance);
                                 
                                 // Additional verification - check the angle between rotated vectors matches expected
                                 double originalAngle = Vector3D.angle(u1, u2);
                                 double rotatedAngle = Vector3D.angle(rotatedU1, rotatedU2);
                                 assertEquals(originalAngle, rotatedAngle, tolerance);
                             }

 @Test
                         public void testRotationWithNonOrthogonalVectorsDetectsAlphaMutation() {
                             // Create non-orthogonal input vectors
                             Vector3D u1 = new Vector3D(1, 0, 0);
                             Vector3D u2 = new Vector3D(1, 1, 0); // Not orthogonal to u1
                             Vector3D v1 = new Vector3D(0, 1, 0);
                             Vector3D v2 = new Vector3D(0, 1, 1); // Not orthogonal to v1
                             
                             // Create rotation that should map u1->v1 and u2->v2
                             Rotation rotation = new Rotation(u1, u2, v1, v2);
                             
                             // Apply rotation to input vectors
                             Vector3D rotatedU1 = rotation.applyTo(u1);
                             Vector3D rotatedU2 = rotation.applyTo(u2);
                             
                             // Verify rotation correctly transforms the vectors
                             double tolerance = 1e-10;
                             assertEquals(0.0, rotatedU1.distance(v1), tolerance);
                             assertEquals(0.0, rotatedU2.distance(v2), tolerance);
                             
                             // Additional verification - check the rotation properties
                             // The mutant would fail these assertions because the incorrect alpha
                             // would cause incorrect rotation calculations
                             double dotOriginal = u1.dotProduct(u2);
                             double dotRotated = rotatedU1.dotProduct(rotatedU2);
                             assertEquals(dotOriginal, dotRotated, tolerance);
                             
                             double normU1 = u1.getNorm();
                             double normRotatedU1 = rotatedU1.getNorm();
                             assertEquals(normU1, normRotatedU1, tolerance);
                             
                             double normU2 = u2.getNorm();
                             double normRotatedU2 = rotatedU2.getNorm();
                             assertEquals(normU2, normRotatedU2, tolerance);
                         }

 @Test
                         public void testRotationConstructorDetectsAlphaCalculationMutation() {
                             // Create input vectors where the mutation would produce different results
                             Vector3D u1 = new Vector3D(1, 0, 0);
                             Vector3D u2 = new Vector3D(0, 1, 0);
                             Vector3D v1 = new Vector3D(0, 0, 1);
                             Vector3D v2 = new Vector3D(1, 1, 0);
                             
                             // Create the rotation
                             Rotation rotation = new Rotation(u1, u2, v1, v2);
                             
                             // Get the resulting quaternion components
                             double q0 = rotation.getQ0();
                             double q1 = rotation.getQ1();
                             double q2 = rotation.getQ2();
                             double q3 = rotation.getQ3();
                             
                             // Verify the quaternion is normalized
                             double norm = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                             assertEquals(1.0, norm, 1.0e-12);
                             
                             // Create expected rotation by applying the rotation to input vectors
                             Vector3D rotatedU1 = rotation.applyTo(u1);
                             Vector3D rotatedU2 = rotation.applyTo(u2);
                             
                             // Verify the rotation transforms u1 to v1 and u2 to v2 (within tolerance)
                             double tolerance = 1.0e-10;
                             assertEquals(0.0, rotatedU1.subtract(v1).getNorm(), tolerance);
                             assertEquals(0.0, rotatedU2.subtract(v2).getNorm(), tolerance);
                             
                             // Additional verification - check specific quaternion components
                             // These values would be different if alpha was calculated with +
                             assertTrue(q0 != 0.0);  // Should not be identity rotation
                             assertTrue(Math.abs(q1) > 0.1 || Math.abs(q2) > 0.1 || Math.abs(q3) > 0.1);
                             
                             // Verify the rotation is invertible
                             Rotation inverse = rotation.revert();
                             Vector3D originalU1 = inverse.applyTo(v1);
                             assertEquals(0.0, originalU1.subtract(u1).getNorm(), tolerance);
                         }

 @Test
                         public void testRotationConstructorDetectsAlphaCalculationMutant() {
                             // Setup vectors where coeffV is significant
                             Vector3D u1 = new Vector3D(1, 0, 0);
                             Vector3D u2 = new Vector3D(0, 1, 0);
                             Vector3D v1 = new Vector3D(0, 0, 1);
                             Vector3D v2 = new Vector3D(1, 1, 0);
                             
                             // Calculate expected alpha value (coeffU - beta*coeffV)
                             double u1u1 = u1.getNormSq();
                             double u1u2 = u1.dotProduct(u2);
                             double v1v2 = v1.dotProduct(v2);
                             double coeffU = u1u2 / u1u1;
                             double coeffV = v1v2 / u1u1;
                             double beta = FastMath.sqrt((u2.getNormSq() - u1u2 * coeffU) / 
                                            (v2.getNormSq() - v1v2 * coeffV));
                             double expectedAlpha = coeffU - beta * coeffV;
                             
                             // Create rotation - if mutant exists, alpha will be coeffU + beta*coeffV
                             Rotation rotation = new Rotation(u1, u2, v1, v2);
                             
                             // Verify the rotation transforms u1 to v1
                             Vector3D rotatedU1 = rotation.applyTo(u1);
                             assertEquals(0.0, rotatedU1.distance(v1), 1.0e-15);
                             
                             // Verify the rotation transforms u2 to v2 (this would fail with mutant)
                             Vector3D rotatedU2 = rotation.applyTo(u2);
                             assertEquals(0.0, rotatedU2.distance(v2), 1.0e-15);
                             
                             // Additional verification by checking quaternion components
                             // The exact values would depend on the specific vectors used
                             assertFalse(Double.isNaN(rotation.getQ0()));
                             assertFalse(Double.isNaN(rotation.getQ1()));
                             assertFalse(Double.isNaN(rotation.getQ2()));
                             assertFalse(Double.isNaN(rotation.getQ3()));
                             
                             // Verify the rotation is normalized
                             double norm = FastMath.sqrt(rotation.getQ0() * rotation.getQ0() +
                                                        rotation.getQ1() * rotation.getQ1() +
                                                        rotation.getQ2() * rotation.getQ2() +
                                                        rotation.getQ3() * rotation.getQ3());
                             assertEquals(1.0, norm, 1.0e-15);
                         }

 @Test
                             public void testRotationFromVectorPairsDetectsAlphaMutation() {
                                 // Create input vectors where coeffV will be non-zero
                                 Vector3D u1 = new Vector3D(1, 0, 0);
                                 Vector3D u2 = new Vector3D(0, 1, 0);
                                 Vector3D v1 = new Vector3D(0, 0, 1);
                                 Vector3D v2 = new Vector3D(1, 1, 1);
                                 
                                 // Create rotation from vector pairs
                                 Rotation rotation = new Rotation(u1, u2, v1, v2);
                                 
                                 // Get the quaternion components
                                 double q0 = rotation.getQ0();
                                 double q1 = rotation.getQ1();
                                 double q2 = rotation.getQ2();
                                 double q3 = rotation.getQ3();
                                 
                                 // Verify the quaternion represents a valid rotation (norm = 1)
                                 double norm = q0*q0 + q1*q1 + q2*q2 + q3*q3;
                                 assertEquals(1.0, norm, 1.0e-12);
                                 
                                 // Verify specific quaternion components that would be affected by the mutation
                                 // These expected values are based on the original subtraction operation
                                 // The mutation would cause these to fail
                                 assertNotEquals(0.0, q0, 1.0e-12);
                                 assertNotEquals(0.0, q1, 1.0e-12);
                                 assertNotEquals(0.0, q2, 1.0e-12);
                                 assertNotEquals(0.0, q3, 1.0e-12);
                                 
                                 // More specific assertions based on expected rotation
                                 // For these vectors, we expect certain component relationships
                                 assertTrue(q0 > 0.5); // Scalar part should be significant
                                 assertEquals(q1, q2, 1.0e-12); // x and y components should be equal
                                 assertTrue(q3 < 0); // z component should be negative
                             }

 @Test
                        public void testRotationFromVectorsDetectsCrossProductMutant() {
                            // Create test vectors
                            Vector3D u1 = new Vector3D(1, 0, 0);
                            Vector3D u2 = new Vector3D(0, 1, 0);
                            Vector3D v1 = new Vector3D(0, 0, 1);
                            Vector3D v2 = new Vector3D(1, 1, 0);
                            
                            // Create rotation
                            Rotation rotation = new Rotation(u1, u2, v1, v2);
                            
                            // Verify the rotation components
                            // The exact expected values depend on the implementation details,
                            // but we know that reversing the cross product would change the signs
                            // of some quaternion components
                            double q0 = rotation.getQ0();
                            double q1 = rotation.getQ1();
                            double q2 = rotation.getQ2();
                            double q3 = rotation.getQ3();
                            
                            // Check that none of the components are zero (which might mask the mutation)
                            assertNotEquals(0.0, q0, 1e-10);
                            assertNotEquals(0.0, q1, 1e-10);
                            assertNotEquals(0.0, q2, 1e-10);
                            assertNotEquals(0.0, q3, 1e-10);
                            
                            // Verify the rotation actually transforms the vectors as expected
                            Vector3D rotatedU1 = rotation.applyTo(u1);
                            Vector3D rotatedU2 = rotation.applyTo(u2);
                            
                            assertEquals(0.0, rotatedU1.distance(v1), 1e-10);
                            assertEquals(0.0, rotatedU2.distance(v2), 1e-10);
                            
                            // Additional check: verify the rotation matrix is proper (orthogonal with det=1)
                            double[][] m = rotation.getMatrix();
                            // Check orthogonality
                            for (int i = 0; i < 3; i++) {
                                for (int j = 0; j < 3; j++) {
                                    double dot = 0;
                                    for (int k = 0; k < 3; k++) {
                                        dot += m[i][k] * m[j][k];
                                    }
                                    assertEquals(i == j ? 1.0 : 0.0, dot, 1e-10);
                                }
                            }
                            // Check determinant
                            double det = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) -
                                         m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
                                         m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
                            assertEquals(1.0, det, 1e-10);
                        }

 @Test
                            public void testRotationFromVectorsDetectsCrossProductMutant1() {
                                // Create non-orthogonal vectors where order of cross product matters
                                Vector3D u1 = new Vector3D(1, 0, 0);
                                Vector3D u2 = new Vector3D(1, 1, 0);
                                Vector3D v1 = new Vector3D(0, 1, 0);
                                Vector3D v2 = new Vector3D(0, 1, 1);
                                
                                // Create rotation that should map u1->v1 and u2->v2
                                Rotation rotation = new Rotation(u1, u2, v1, v2);
                                
                                // Verify the rotation actually transforms the vectors as expected
                                Vector3D rotatedU1 = rotation.applyTo(u1);
                                Vector3D rotatedU2 = rotation.applyTo(u2);
                                
                                // Check if rotation correctly transforms u1 to v1 (with some tolerance)
                                assertEquals(0.0, rotatedU1.distance(v1), 1.0e-12);
                                
                                // Check if rotation correctly transforms u2 to v2 (with some tolerance)
                                assertEquals(0.0, rotatedU2.distance(v2), 1.0e-12);
                                
                                // Additionally verify the quaternion components to catch the mutant
                                // The mutant would produce different quaternion components due to flipped cross product
                                Rotation expectedRotation = new Rotation(
                                    new Vector3D(0, 0, 1),  // axis
                                    Math.PI/2                // angle (90 degrees)
                                );
                                
                                assertEquals(expectedRotation.getQ0(), rotation.getQ0(), 1.0e-12);
                                assertEquals(expectedRotation.getQ1(), rotation.getQ1(), 1.0e-12);
                                assertEquals(expectedRotation.getQ2(), rotation.getQ2(), 1.0e-12);
                                assertEquals(expectedRotation.getQ3(), rotation.getQ3(), 1.0e-12);
                            }

 @Test
                        public void testRotationConstructorCrossProductOrder() {
                            // Create test vectors
                            Vector3D u1 = new Vector3D(1, 0, 0);
                            Vector3D u2 = new Vector3D(0, 1, 0);
                            Vector3D v1 = new Vector3D(0, 0, 1);
                            Vector3D v2 = new Vector3D(1, 0, 0);
                            
                            // Create rotation with original constructor
                            Rotation originalRotation = new Rotation(u1, u2, v1, v2);
                            
                            // Create a test vector to apply the rotation to
                            Vector3D testVector = new Vector3D(1, 1, 0);
                            Vector3D rotatedVector = originalRotation.applyTo(testVector);
                            
                            // Verify the rotation produces expected results
                            // Since u1×u2 = (0,0,1) and u2×u1 = (0,0,-1), the mutated version would produce
                            // a rotation with opposite sign in q1,q2,q3 components
                            // We can verify by checking the rotated vector's z-component
                            assertEquals(0.0, rotatedVector.getZ(), 1.0e-10);
                            
                            // Also verify the quaternion components
                            // The exact values depend on the implementation, but we know:
                            // - q0 should be positive (rotation angle < 180°)
                            // - At least one of q1,q2,q3 should be non-zero
                            assertTrue(originalRotation.getQ0() > 0);
                            assertTrue(Math.abs(originalRotation.getQ1()) > 1.0e-10 || 
                                      Math.abs(originalRotation.getQ2()) > 1.0e-10 ||
                                      Math.abs(originalRotation.getQ3()) > 1.0e-10);
                            
                            // Verify the rotation actually transforms u1 to v1 and u2 to v2
                            assertEquals(0.0, originalRotation.applyTo(u1).subtract(v1).getNorm(), 1.0e-10);
                            assertEquals(0.0, originalRotation.applyTo(u2).subtract(v2).getNorm(), 1.0e-10);
                        }

 @Test
                        public void testCrossProductOrderDetectsMutant() {
                            // Create non-parallel input vectors
                            Vector3D u1 = new Vector3D(1, 0, 0);
                            Vector3D u2 = new Vector3D(0, 1, 0);
                            Vector3D v1 = new Vector3D(0, 0, 1);
                            Vector3D v2 = new Vector3D(1, 1, 0);
                            
                            // Create rotation with original implementation
                            Rotation originalRotation = new Rotation(u1, u2, v1, v2);
                            
                            // Verify the quaternion components
                            // The exact expected values depend on the correct implementation,
                            // but we know q1 should be positive for these inputs with original cross product order
                            assertTrue("q1 should be positive with original cross product order", 
                                       originalRotation.getQ1() > 0);
                            
                            // For the mutated version (u2.crossProduct(u1)), q1 would be negative
                            // because the cross product direction is reversed
                            // This assertion would fail if the mutant is present
                            assertTrue("Test should fail if mutant is present (q1 would be negative)", 
                                       originalRotation.getQ1() > 0);
                            
                            // Additional verification of other quaternion components
                            assertEquals(originalRotation.getQ0(), FastMath.sqrt(0.5), 1e-10);
                            assertEquals(originalRotation.getQ2(), 0.0, 1e-10);
                            assertEquals(originalRotation.getQ3(), 0.0, 1e-10);
                        }

 @Test
                            public void testRotationOrderConstructorDetectsCrossProductMutant() {
                                // Setup - using non-trivial rotation angles where order matters
                                double alpha1 = Math.PI / 4;  // 45 degrees
                                double alpha2 = Math.PI / 3;  // 60 degrees
                                double alpha3 = Math.PI / 6;  // 30 degrees
                                
                                // Test with XYZ rotation order
                                RotationOrder order = RotationOrder.XYZ;
                                Rotation rotation = new Rotation(order, alpha1, alpha2, alpha3);
                                
                                // Calculate expected quaternion components manually
                                // These values are based on correct cross product order (u1×u2)
                                // The mutant would reverse the sign of q1,q2,q3 components
                                double expectedQ0 = 0.8001031451912651;
                                double expectedQ1 = 0.46193976625564337;
                                double expectedQ2 = 0.3314135740355916;
                                double expectedQ3 = 0.1913417161825449;
                                
                                // Assert all quaternion components
                                assertEquals("q0 component incorrect", expectedQ0, rotation.getQ0(), 1e-15);
                                assertEquals("q1 component incorrect", expectedQ1, rotation.getQ1(), 1e-15);
                                assertEquals("q2 component incorrect", expectedQ2, rotation.getQ2(), 1e-15);
                                assertEquals("q3 component incorrect", expectedQ3, rotation.getQ3(), 1e-15);
                                
                                // Additional test with ZYX order to ensure comprehensive coverage
                                order = RotationOrder.ZYX;
                                rotation = new Rotation(order, alpha3, alpha2, alpha1);
                                
                                expectedQ0 = 0.8001031451912651;
                                expectedQ1 = 0.1913417161825449;
                                expectedQ2 = 0.3314135740355916;
                                expectedQ3 = 0.46193976625564337;
                                
                                assertEquals("q0 component incorrect for ZYX order", expectedQ0, rotation.getQ0(), 1e-15);
                                assertEquals("q1 component incorrect for ZYX order", expectedQ1, rotation.getQ1(), 1e-15);
                                assertEquals("q2 component incorrect for ZYX order", expectedQ2, rotation.getQ2(), 1e-15);
                                assertEquals("q3 component incorrect for ZYX order", expectedQ3, rotation.getQ3(), 1e-15);
                            }

 @Test
                       public void testRotationFromVectorsDetectsCrossProductMutant2() {
                           // Create two non-parallel vectors
                           Vector3D u = new Vector3D(1, 0, 0);
                           Vector3D v = new Vector3D(0, 1, 0);
                           
                           // Create rotation that would align u with v
                           Rotation rotation = new Rotation(u, v);
                           
                           // Apply the rotation to u
                           Vector3D rotatedU = rotation.applyTo(u);
                           
                           // Verify the rotated u aligns with v (allowing for small numerical errors)
                           double angle = Vector3D.angle(rotatedU, v);
                           assertEquals(0.0, angle, 1.0e-15);
                           
                           // Now verify the rotation axis direction by checking quaternion components
                           // The cross product v × u should give (0,0,1) direction
                           // If mutated to u × v, it would give (0,0,-1)
                           // We can verify this through the q1,q2,q3 components which represent the axis
                           
                           // For v × u case (correct):
                           // Expected quaternion components for 90° rotation around z-axis:
                           // q0 = cos(45°) ≈ 0.7071
                           // q1,q2 = 0
                           // q3 = sin(45°) ≈ 0.7071 (positive because of correct cross product order)
                           
                           // For u × v case (mutated):
                           // q3 would be negative
                           
                           assertEquals(0.0, rotation.getQ1(), 1.0e-15);
                           assertEquals(0.0, rotation.getQ2(), 1.0e-15);
                           assertTrue("q3 should be positive for correct cross product order", 
                                     rotation.getQ3() > 0);
                           
                           // Verify the rotation angle is 90 degrees (π/2 radians)
                           assertEquals(Math.PI/2, rotation.getAngle(), 1.0e-15);
                       }

 @Test
                       public void testInPlaneThresholdMutation() {
                           // Create vectors that are slightly out-of-plane (angle ~0.01 radians)
                           // This is between the original threshold (0.001) and mutated threshold (0.1)
                           Vector3D u1 = new Vector3D(1, 0, 0);
                           Vector3D u2 = new Vector3D(0, 1, 0.01);  // slightly out of xy-plane
                           Vector3D v1 = new Vector3D(0, 1, 0);
                           Vector3D v2 = new Vector3D(-1, 0, 0.01); // slightly out of xy-plane
                           
                           // Create rotation with these vectors
                           Rotation rotation = new Rotation(u1, u2, v1, v2);
                           
                           // With original threshold (0.001), this should use the general case
                           // With mutated threshold (0.1), it would use the in-plane case
                           // Verify the rotation is not identity (which would happen if threshold was too large)
                           assertFalse("Rotation should not be identity for slightly out-of-plane vectors",
                                      rotation.getQ0() == 1.0 && 
                                      rotation.getQ1() == 0.0 && 
                                      rotation.getQ2() == 0.0 && 
                                      rotation.getQ3() == 0.0);
                           
                           // Verify the rotation actually transforms the vectors as expected
                           Vector3D u1Transformed = rotation.applyTo(u1);
                           assertTrue("u1 should be rotated to v1",
                                      Math.abs(u1Transformed.getX() - v1.getX()) < 1e-10 &&
                                      Math.abs(u1Transformed.getY() - v1.getY()) < 1e-10 &&
                                      Math.abs(u1Transformed.getZ() - v1.getZ()) < 1e-10);
                           
                           Vector3D u2Transformed = rotation.applyTo(u2);
                           assertTrue("u2 should be rotated to v2",
                                      Math.abs(u2Transformed.getX() - v2.getX()) < 1e-8 &&  // relaxed due to small z-component
                                      Math.abs(u2Transformed.getY() - v2.getY()) < 1e-8 &&
                                      Math.abs(u2Transformed.getZ() - v2.getZ()) < 1e-8);
                       }

 @Test
                   public void testRotationConstructorWithNearCoplanarVectors() {
                       // Create vectors that are slightly non-coplanar (angle ~0.05 radians)
                       Vector3D u1 = new Vector3D(1, 0, 0);
                       Vector3D u2 = new Vector3D(0, 1, 0);
                       Vector3D v1 = new Vector3D(1, 0.05, 0);  // slightly tilted in y-axis
                       Vector3D v2 = new Vector3D(0.05, 1, 0);  // slightly tilted in x-axis
                       
                       // Create rotation with these vectors
                       Rotation rotation = new Rotation(u1, u2, v1, v2);
                       
                       // With original threshold (0.001), this should be a real rotation
                       // With mutated threshold (0.1), this would be considered identity
                       
                       // Verify it's not identity rotation (q0=1, others=0)
                       assertNotEquals(1.0, rotation.getQ0(), 1e-10);
                       assertTrue(Math.abs(rotation.getQ1()) > 1e-10 || 
                                 Math.abs(rotation.getQ2()) > 1e-10 || 
                                 Math.abs(rotation.getQ3()) > 1e-10);
                       
                       // Verify the rotation actually transforms the vectors as expected
                       Vector3D rotatedU1 = rotation.applyTo(u1);
                       Vector3D rotatedU2 = rotation.applyTo(u2);
                       
                       assertEquals(0.0, rotatedU1.distance(v1), 1e-10);
                       assertEquals(0.0, rotatedU2.distance(v2), 1e-10);
                   }

 @Test
                   public void testRotationConstructorWithNearCoplanarVectors1() {
                       // Create input vectors that are slightly non-coplanar (angle ~0.01 radians)
                       Vector3D u1 = new Vector3D(1, 0, 0);
                       Vector3D u2 = new Vector3D(0, 1, 0.01);  // slight z-component makes them non-coplanar
                       Vector3D v1 = new Vector3D(0, 1, 0);
                       Vector3D v2 = new Vector3D(-1, 0, 0.01); // matching non-coplanarity
                       
                       // Create rotation with these vectors
                       Rotation rotation = new Rotation(u1, u2, v1, v2);
                       
                       // Verify the rotation transforms the vectors correctly
                       double epsilon = 1e-10;
                       
                       // Check u1 is rotated to v1
                       Vector3D rotatedU1 = rotation.applyTo(u1);
                       assertEquals(v1.getX(), rotatedU1.getX(), epsilon);
                       assertEquals(v1.getY(), rotatedU1.getY(), epsilon);
                       assertEquals(v1.getZ(), rotatedU1.getZ(), epsilon);
                       
                       // Check u2 is rotated to v2
                       Vector3D rotatedU2 = rotation.applyTo(u2);
                       assertEquals(v2.getX(), rotatedU2.getX(), epsilon);
                       assertEquals(v2.getY(), rotatedU2.getY(), epsilon);
                       assertEquals(v2.getZ(), rotatedU2.getZ(), epsilon);
                       
                       // With the mutated threshold (0.1), the method might incorrectly treat these as coplanar
                       // and produce a less accurate rotation. The original threshold (0.001) would handle
                       // this case properly, so the assertions would pass with original code but might fail
                       // with the mutated code.
                   }

 @Test
                   public void testRotationConstructorWithNearPlanarVectors() {
                       // Create vectors that are nearly but not quite in-plane with threshold 0.001
                       // but would be considered in-plane with threshold 0.1
                       Vector3D u1 = new Vector3D(1.0, 0.0, 0.0);
                       Vector3D u2 = new Vector3D(0.0, 1.0, 0.0);
                       
                       // v1 is same as u1
                       Vector3D v1 = new Vector3D(1.0, 0.0, 0.0);
                       // v2 is slightly out of plane (z-component of 0.01 is enough to be detected with 0.001 threshold)
                       Vector3D v2 = new Vector3D(0.0, 1.0, 0.01);
                   
                       // Create rotation with these vectors
                       Rotation rotation = new Rotation(u1, u2, v1, v2);
                       
                       // With original threshold (0.001), this should NOT be identity rotation
                       // With mutated threshold (0.1), this would be identity rotation
                       // So we verify it's not identity by checking q0 is not exactly 1.0
                       assertNotEquals(1.0, rotation.getQ0(), 0.0001);
                       
                       // Also verify other quaternion components are not exactly 0
                       assertNotEquals(0.0, rotation.getQ1(), 0.0001);
                       assertNotEquals(0.0, rotation.getQ2(), 0.0001);
                       assertNotEquals(0.0, rotation.getQ3(), 0.0001);
                       
                       // Additionally verify the rotation actually works by applying it to u1
                       Vector3D rotatedU1 = rotation.applyTo(u1);
                       assertEquals(v1.getX(), rotatedU1.getX(), 1.0e-10);
                       assertEquals(v1.getY(), rotatedU1.getY(), 1.0e-10);
                       assertEquals(v1.getZ(), rotatedU1.getZ(), 1.0e-10);
                   }

 @Test
                       public void testInPlaneThresholdMutation1() {
                           // Create vectors that are slightly non-coplanar (angle ~0.002 radians)
                           Vector3D u1 = new Vector3D(1, 0, 0);
                           Vector3D u2 = new Vector3D(0, 1, 0.002);
                           Vector3D v1 = new Vector3D(1, 0.001, 0);
                           Vector3D v2 = new Vector3D(0.001, 1, 0.002);
                           
                           // With original threshold (0.001), this should be considered non-coplanar
                           // With mutated threshold (0.1), this would be considered coplanar
                           Rotation rotation = new Rotation(u1, u2, v1, v2);
                           
                           // Verify the rotation is not identity (which it would be if considered coplanar)
                           assertNotEquals(1.0, rotation.getQ0(), 1e-10);
                           assertNotEquals(0.0, rotation.getQ1(), 1e-10);
                           assertNotEquals(0.0, rotation.getQ2(), 1e-10);
                           assertNotEquals(0.0, rotation.getQ3(), 1e-10);
                           
                           // Create more obviously non-coplanar vectors
                           Vector3D u3 = new Vector3D(1, 0, 0);
                           Vector3D u4 = new Vector3D(0, 1, 0.1);
                           Vector3D v3 = new Vector3D(1, 0.05, 0);
                           Vector3D v4 = new Vector3D(0.05, 1, 0.1);
                           
                           Rotation rotation2 = new Rotation(u3, u4, v3, v4);
                           
                           // Should still be non-identity rotation
                           assertNotEquals(1.0, rotation2.getQ0(), 1e-10);
                           assertNotEquals(0.0, rotation2.getQ1(), 1e-10);
                           assertNotEquals(0.0, rotation2.getQ2(), 1e-10);
                           assertNotEquals(0.0, rotation2.getQ3(), 1e-10);
                       }

 @Test
                  public void testNearlyCoplanarVectorsWithThreshold() {
                      // Create vectors that are nearly coplanar (angle between normal vectors is ~0.01 radians)
                      Vector3D u1 = new Vector3D(1, 0, 0);
                      Vector3D u2 = new Vector3D(0, 1, 0.01);  // slightly out of plane
                      Vector3D v1 = new Vector3D(1, 0, 0);
                      Vector3D v2 = new Vector3D(0, 1, 0.01);  // same slight deviation
                      
                      // Create rotation with original threshold (0.001)
                      Rotation originalRotation = new Rotation(u1, u2, v1, v2);
                      
                      // Create rotation with mutated threshold (0.1) - this would require mocking or reflection
                      // Since we can't directly modify the threshold, we'll test the behavior indirectly
                      // by verifying the rotation isn't identity when vectors are nearly coplanar
                      
                      // The test should verify that the rotation isn't identity (which would happen if threshold was too large)
                      assertFalse("Rotation should not be identity for nearly coplanar vectors", 
                          originalRotation.equals(Rotation.IDENTITY));
                      
                      // Verify specific quaternion components to ensure proper calculation
                      try {
                          double[] angles = originalRotation.getAngles(RotationOrder.XYZ);
                          assertTrue("X rotation angle should be significant", 
                              Math.abs(angles[0]) > 0.0001);
                          assertTrue("Y rotation angle should be significant", 
                              Math.abs(angles[1]) > 0.0001);
                          assertTrue("Z rotation angle should be significant", 
                              Math.abs(angles[2]) > 0.0001);
                      } catch (CardanEulerSingularityException e) {
                          fail("Unexpected CardanEulerSingularityException: " + e.getMessage());
                      }
                      
                      // Alternative test: create a case where vectors are 0.05 radians from coplanar
                      // This would be caught by original threshold but not by mutated one
                      Vector3D u3 = new Vector3D(1, 0, 0);
                      Vector3D u4 = new Vector3D(0, 1, 0.05);
                      Vector3D v3 = new Vector3D(1, 0, 0);
                      Vector3D v4 = new Vector3D(0, 1, 0.05);
                      
                      Rotation edgeCaseRotation = new Rotation(u3, u4, v3, v4);
                      assertFalse("Rotation should not be identity for vectors 0.05 radians from coplanar",
                          edgeCaseRotation.equals(Rotation.IDENTITY));
                  }

 @Test
              public void testRotationFromTwoVectorsDetectsCrossProductMutant() {
                  // Create input vectors
                  Vector3D u1 = new Vector3D(1, 0, 0);
                  Vector3D u2 = new Vector3D(0, 1, 0);
                  Vector3D v1 = new Vector3D(0, 0, 1);
                  Vector3D v2 = new Vector3D(1, 0, 0);
                  
                  // Create rotation
                  Rotation rotation = new Rotation(u1, u2, v1, v2);
                  
                  // Get the rotation axis
                  Vector3D axis = rotation.getAxis();
                  
                  // Verify the rotation transforms the vectors correctly
                  Vector3D rotatedU1 = rotation.applyTo(u1);
                  Vector3D rotatedU2 = rotation.applyTo(u2);
                  
                  // Assertions to catch the mutant
                  // The cross product direction affects the rotation axis direction
                  // so we check both the transformed vectors and quaternion components
                  assertEquals(0.0, rotatedU1.distance(v1), 1.0e-12);
                  assertEquals(0.0, rotatedU2.distance(v2), 1.0e-12);
                  
                  // Check quaternion components (the mutant would flip signs of q1,q2,q3)
                  // We know from the input vectors that q0 should be 0.5 and q3 should be 0.5
                  // (for a 90 degree rotation around (0,1,0) axis)
                  assertEquals(0.5, rotation.getQ0(), 1.0e-12);
                  assertEquals(0.0, rotation.getQ1(), 1.0e-12);
                  assertEquals(0.0, rotation.getQ2(), 1.0e-12);
                  assertEquals(0.5, rotation.getQ3(), 1.0e-12);
                  
                  // Additional check on the rotation angle (should be 90 degrees)
                  assertEquals(Math.PI/2, rotation.getAngle(), 1.0e-12);
              }

 @Test
              public void testRotationConstructorDetectsCrossProductMutant() {
                  // Create input vectors where the initial cross product approach will fail
                  // and the fallback path using v1×v2 will be taken
                  Vector3D u1 = new Vector3D(1, 0, 0);
                  Vector3D u2 = new Vector3D(0, 1, 0);
                  Vector3D v1 = new Vector3D(0, 1, 0);
                  Vector3D v2 = new Vector3D(-1, 0, 0);  // 90 degree rotation
                  
                  // Create the rotation
                  Rotation rotation = new Rotation(u1, u2, v1, v2);
                  
                  // Test the rotation by applying it to u1 and u2
                  Vector3D rotatedU1 = rotation.applyTo(u1);
                  Vector3D rotatedU2 = rotation.applyTo(u2);
                  
                  // Verify the rotated vectors match expected v1 and v2
                  double tolerance = 1e-10;
                  assertEquals(v1.getX(), rotatedU1.getX(), tolerance);
                  assertEquals(v1.getY(), rotatedU1.getY(), tolerance);
                  assertEquals(v1.getZ(), rotatedU1.getZ(), tolerance);
                  
                  assertEquals(v2.getX(), rotatedU2.getX(), tolerance);
                  assertEquals(v2.getY(), rotatedU2.getY(), tolerance);
                  assertEquals(v2.getZ(), rotatedU2.getZ(), tolerance);
                  
                  // Also verify the rotation angle is correct (should be 90 degrees)
                  assertEquals(Math.PI/2, rotation.getAngle(), tolerance);
                  
                  // Verify the axis is correct (should be Z axis)
                  Vector3D axis = rotation.getAxis();
                  assertEquals(0, axis.getX(), tolerance);
                  assertEquals(0, axis.getY(), tolerance);
                  assertEquals(1, axis.getZ(), tolerance);
              }

 @Test
              public void testRotationConstructorWithCrossProductMutation() {
                  // Create coplanar vectors to force the code path that uses v3
                  Vector3D u1 = new Vector3D(1, 0, 0);
                  Vector3D u2 = new Vector3D(0, 1, 0);
                  Vector3D v1 = new Vector3D(0, 1, 0);
                  Vector3D v2 = new Vector3D(-1, 0, 0);
                  
                  // Create the rotation
                  Rotation rotation = new Rotation(u1, u2, v1, v2);
                  
                  // Verify the rotation by applying it to test vectors
                  Vector3D testVector = new Vector3D(1, 1, 0);
                  Vector3D rotatedVector = rotation.applyTo(testVector);
                  
                  // Expected result should be (-1, 1, 0) for correct rotation
                  // The mutant would produce (1, -1, 0) due to reversed cross product
                  assertEquals(-1, rotatedVector.getX(), 1e-10);
                  assertEquals(1, rotatedVector.getY(), 1e-10);
                  assertEquals(0, rotatedVector.getZ(), 1e-10);
                  
                  // Also verify the quaternion components
                  // For this specific case, the correct rotation should have:
                  // q0 ≈ 0.7071 (cos(π/4))
                  // q3 ≈ 0.7071 (sin(π/4))
                  assertEquals(0.7071, rotation.getQ0(), 1e-4);
                  assertEquals(0.0, rotation.getQ1(), 1e-10);
                  assertEquals(0.0, rotation.getQ2(), 1e-10);
                  assertEquals(0.7071, rotation.getQ3(), 1e-4);
              }

 @Test
              public void testConstructorWithVectorsDetectsCrossProductMutant() {
                  // Create input vectors that will trigger the code path with the mutation
                  Vector3D u1 = new Vector3D(1, 0, 0);
                  Vector3D u2 = new Vector3D(0, 1, 0);
                  Vector3D v1 = new Vector3D(0, 0, 1);
                  Vector3D v2 = new Vector3D(1, 1, 0.001);  // Small z-component to make vectors not perfectly orthogonal
                  
                  // Create original rotation
                  Rotation originalRotation = new Rotation(u1, u2, v1, v2);
                  
                  // Create expected quaternion components by manually computing what they should be
                  // This is the key part that will differ with the mutant
                  Vector3D expectedV3 = Vector3D.crossProduct(v1, v2);
                  Vector3D expectedV3Su3 = expectedV3.subtract(u1.crossProduct(u2));
                  Vector3D expectedK = v1.subtract(u1).crossProduct(expectedV3Su3);
                  Vector3D expectedU2Prime = u1.crossProduct(u1.crossProduct(u2));
                  double expectedC = expectedK.dotProduct(expectedU2Prime);
                  expectedC = FastMath.sqrt(expectedC);
                  double inv = 1.0 / (expectedC + expectedC);
                  double expectedQ1 = inv * expectedK.getX();
                  double expectedQ2 = inv * expectedK.getY();
                  double expectedQ3 = inv * expectedK.getZ();
                  
                  // Verify the quaternion components match expected values
                  assertEquals(expectedQ1, originalRotation.getQ1(), 1.0e-15);
                  assertEquals(expectedQ2, originalRotation.getQ2(), 1.0e-15);
                  assertEquals(expectedQ3, originalRotation.getQ3(), 1.0e-15);
                  
                  // Also verify the rotation actually works by applying it to u1 and checking it becomes v1
                  Vector3D rotatedU1 = originalRotation.applyTo(u1);
                  assertEquals(0.0, rotatedU1.subtract(v1.normalize()).getNorm(), 1.0e-10);
              }

 @Test
                  public void testCrossProductOrderDetectsMutant1() {
                      // Create two non-parallel vectors where cross product order matters
                      Vector3D u = new Vector3D(1, 0, 0);
                      Vector3D v = new Vector3D(0, 1, 0);
                      
                      // Expected cross product v × u = (0, 0, -1)
                      // Mutated cross product u × v = (0, 0, 1)
                      
                      // Create rotation with original behavior
                      Rotation originalRotation = new Rotation(v, u);
                      
                      // In the mutated version, the cross product would be reversed
                      // So we expect q1,q2,q3 to be negated compared to original
                      // Let's create what the mutated version would produce
                      double dot = u.dotProduct(v);
                      double normProduct = u.getNorm() * v.getNorm();
                      double q0Expected = FastMath.sqrt(0.5 * (1.0 + dot / normProduct));
                      double coeff = 1.0 / (2.0 * q0Expected * normProduct);
                      Vector3D q = u.crossProduct(v); // This is the mutated version
                      double q1Expected = coeff * q.getX();
                      double q2Expected = coeff * q.getY();
                      double q3Expected = coeff * q.getZ();
                      
                      // Verify original rotation doesn't match the mutated version
                      assertNotEquals("q1 should differ between original and mutant", 
                                     q1Expected, originalRotation.getQ1(), 1e-10);
                      assertNotEquals("q2 should differ between original and mutant",
                                     q2Expected, originalRotation.getQ2(), 1e-10);
                      assertNotEquals("q3 should differ between original and mutant",
                                     q3Expected, originalRotation.getQ3(), 1e-10);
                      
                      // Additionally verify the signs are opposite
                      assertEquals("q1 should have opposite sign", 
                                  -q1Expected, originalRotation.getQ1(), 1e-10);
                      assertEquals("q2 should have opposite sign",
                                  -q2Expected, originalRotation.getQ2(), 1e-10);
                      assertEquals("q3 should have opposite sign",
                                  -q3Expected, originalRotation.getQ3(), 1e-10);
                  }

 @Test
              public void testRotationOrderConstructorDetectsCrossProductMutant1() {
                  // Create non-parallel vectors where cross product order matters
                  Vector3D v1 = new Vector3D(1, 0, 0);
                  Vector3D v2 = new Vector3D(0, 1, 0);
                  
                  // Create rotation order that will trigger cross product calculation
                  RotationOrder order = RotationOrder.XYZ;
                  double alpha1 = Math.PI/4;  // 45 degrees
                  double alpha2 = Math.PI/4;
                  double alpha3 = Math.PI/4;
                  
                  // Create rotation with the specified order and angles
                  Rotation rotation = new Rotation(order, alpha1, alpha2, alpha3);
                  
                  // Calculate expected quaternion components
                  // The correct cross product (v1 × v2) would produce (0,0,1)
                  // The mutated cross product (v2 × v1) would produce (0,0,-1)
                  // This affects the sign of q3 component in the quaternion
                  
                  // Expected values based on correct cross product order
                  double expectedQ0 = 0.9238795325112867;
                  double expectedQ1 = 0.22094238269055696;
                  double expectedQ2 = 0.22094238269055696;
                  double expectedQ3 = 0.22094238269055696;
                  
                  // Verify all quaternion components
                  assertEquals(expectedQ0, rotation.getQ0(), 1e-15);
                  assertEquals(expectedQ1, rotation.getQ1(), 1e-15);
                  assertEquals(expectedQ2, rotation.getQ2(), 1e-15);
                  assertEquals(expectedQ3, rotation.getQ3(), 1e-15);
                  
                  // The mutant would fail this test because q3 would be -0.22094238269055696
              }

 @Test
                 public void testVectorRotationCrossProductDirection() {
                     // Setup vectors where cross product direction matters
                     Vector3D u1 = new Vector3D(1, 0, 0);
                     Vector3D u2 = new Vector3D(0, 1, 0);
                     Vector3D v1 = new Vector3D(0, 0, 1);
                     Vector3D v2 = new Vector3D(1, 1, 0);
                     
                     // Create rotation - this will use the cross product internally
                     Rotation rotation = new Rotation(u1, u2, v1, v2);
                     
                     // Get the axis of rotation
                     Vector3D axis = rotation.getAxis();
                     
                     // Verify the rotation is not identity
                     assertNotEquals(0.0, rotation.getAngle(), 1e-10);
                     
                     // Verify the axis direction is correct (would be opposite if cross product was reversed)
                     // Expected axis should be roughly in the (1, -1, 1) direction
                     assertTrue(axis.getX() > 0);
                     assertTrue(axis.getY() < 0);
                     assertTrue(axis.getZ() > 0);
                     
                     // Verify specific quaternion components that would be affected by cross product reversal
                     assertTrue(rotation.getQ1() > 0); // Would be negative if cross product was reversed
                     assertTrue(rotation.getQ2() < 0); // Would be positive if cross product was reversed
                     assertTrue(rotation.getQ3() > 0); // Would be negative if cross product was reversed
                 }

 @Test
             public void testRotationFromVectorsDetectsCrossProductMutant3() {
                 // Create input vectors that will make the cross product direction significant
                 Vector3D u1 = new Vector3D(1, 0, 0);
                 Vector3D u2 = new Vector3D(0, 1, 0);
                 Vector3D v1 = new Vector3D(0, 0, 1);
                 Vector3D v2 = new Vector3D(1, 1, 0);
                 
                 // Create the rotation
                 Rotation rotation = new Rotation(u1, u2, v1, v2);
                 
                 // Get the resulting quaternion components
                 double q0 = rotation.getQ0();
                 double q1 = rotation.getQ1();
                 double q2 = rotation.getQ2();
                 double q3 = rotation.getQ3();
                 
                 // Verify the quaternion components (values based on expected behavior)
                 // The exact expected values would depend on the correct cross product direction
                 // We're mainly checking that the signs are correct
                 assertTrue("q0 should be positive", q0 > 0);
                 assertTrue("q1 should be positive", q1 > 0);
                 assertTrue("q2 should be positive", q2 > 0);
                 assertTrue("q3 should be negative", q3 < 0);
                 
                 // More precise assertions based on expected values
                 assertEquals(0.5, q0, 0.1);
                 assertEquals(0.5, q1, 0.1);
                 assertEquals(0.5, q2, 0.1);
                 assertEquals(-0.5, q3, 0.1);
                 
                 // Verify the rotation actually transforms u1 to v1 and u2 to v2
                 Vector3D rotatedU1 = rotation.applyTo(u1);
                 Vector3D rotatedU2 = rotation.applyTo(u2);
                 
                 assertEquals(0, rotatedU1.distance(v1), 1e-10);
                 assertEquals(0, rotatedU2.distance(v2), 1e-10);
             }

 @Test
             public void testRotationFromTwoVectorsWithCrossProductMutation() {
                 // Create input vectors where the cross product direction will affect the result
                 Vector3D u1 = new Vector3D(1, 0, 0);
                 Vector3D u2 = new Vector3D(0, 1, 0);
                 Vector3D v1 = new Vector3D(0, 0, 1);  // 90 degree rotation around (1,1,0)
                 Vector3D v2 = new Vector3D(0, 1, 0);  // u2 remains unchanged
                 
                 // Create the rotation
                 Rotation rotation = new Rotation(u1, u2, v1, v2);
                 
                 // Verify the rotation transforms u1 to v1
                 Vector3D rotatedU1 = rotation.applyTo(u1);
                 double distance = Vector3D.distance(v1, rotatedU1);
                 assertEquals(0.0, distance, 1.0e-12);
                 
                 // Verify the rotation transforms u2 to v2
                 Vector3D rotatedU2 = rotation.applyTo(u2);
                 distance = Vector3D.distance(v2, rotatedU2);
                 assertEquals(0.0, distance, 1.0e-12);
                 
                 // Verify specific quaternion components that would be affected by the cross product reversal
                 // The expected values come from mathematical calculation of the correct rotation
                 assertEquals(0.5, rotation.getQ0(), 1.0e-12);
                 assertEquals(0.5, rotation.getQ1(), 1.0e-12);
                 assertEquals(0.5, rotation.getQ2(), 1.0e-12);
                 assertEquals(-0.5, rotation.getQ3(), 1.0e-12);
                 
                 // Test with another vector to ensure full rotation correctness
                 Vector3D u3 = new Vector3D(0, 0, 1);
                 Vector3D expectedV3 = new Vector3D(-1, 0, 0);
                 Vector3D rotatedU3 = rotation.applyTo(u3);
                 distance = Vector3D.distance(expectedV3, rotatedU3);
                 assertEquals(0.0, distance, 1.0e-12);
             }

 @Test
             public void testRotationConstructorDetectsCrossProductMutant1() {
                 // Create input vectors that will trigger the mutated code path
                 // We need vectors where the initial rotation calculation is close to identity
                 Vector3D u1 = new Vector3D(1.0, 0.0, 0.0);
                 Vector3D u2 = new Vector3D(0.0, 1.0, 0.0);
                 Vector3D v1 = new Vector3D(1.0, 0.001, 0.0);  // slightly different from u1
                 Vector3D v2 = new Vector3D(0.001, 1.0, 0.0);  // slightly different from u2
                 
                 // Create the rotation
                 Rotation rotation = new Rotation(u1, u2, v1, v2);
                 
                 // Get the quaternion components
                 double q0 = rotation.getQ0();
                 double q1 = rotation.getQ1();
                 double q2 = rotation.getQ2();
                 double q3 = rotation.getQ3();
                 
                 // Verify the rotation is close to identity (as expected)
                 // The exact values will differ if the cross product order is reversed
                 assertEquals(1.0, q0, 0.01);  // scalar part should be close to 1
                 assertEquals(0.0, q1, 0.01);  // vector parts should be small
                 assertEquals(0.0, q2, 0.01);
                 assertEquals(0.0, q3, 0.01);
                 
                 // More precise check - the mutation would flip signs of some components
                 // The original code produces very small positive values for q1,q2,q3
                 // The mutated code would produce the same magnitude but opposite signs
                 assertTrue(q1 >= 0.0);
                 assertTrue(q2 >= 0.0);
                 assertTrue(q3 >= 0.0);
             }

 @Test
             public void testRotationFromNearlyCoplanarVectorsDetectsCrossProductMutant() {
                 // Create input vectors that will trigger the v3Su3 code path
                 Vector3D u1 = new Vector3D(1, 0, 0);
                 Vector3D u2 = new Vector3D(0, 1, 0);
                 
                 // v1 and v2 are nearly coplanar with u1 and u2
                 Vector3D v1 = new Vector3D(1, 0.001, 0);
                 Vector3D v2 = new Vector3D(0, 1, 0.001);
                 
                 // Create rotation
                 Rotation rotation = new Rotation(u1, u2, v1, v2);
                 
                 // Get the quaternion components
                 double q0 = rotation.getQ0();
                 double q1 = rotation.getQ1();
                 double q2 = rotation.getQ2();
                 double q3 = rotation.getQ3();
                 
                 // Verify the rotation is not identity
                 assertFalse(q0 == 1.0 && q1 == 0.0 && q2 == 0.0 && q3 == 0.0);
                 
                 // Create expected rotation by manually computing what it should be
                 Vector3D v1Su1 = v1.subtract(u1);
                 Vector3D v2Su2 = v2.subtract(u2);
                 Vector3D v3 = Vector3D.crossProduct(v1, v2);
                 Vector3D u3 = Vector3D.crossProduct(u1, u2);
                 Vector3D v3Su3 = v3.subtract(u3);
                 Vector3D expectedK = v1Su1.crossProduct(v3Su3);
                 Vector3D u2Prime = u1.crossProduct(u3);
                 double c = expectedK.dotProduct(u2Prime);
                 c = FastMath.sqrt(c);
                 double inv = 1.0 / (c + c);
                 double expectedQ1 = inv * expectedK.getX();
                 double expectedQ2 = inv * expectedK.getY();
                 double expectedQ3 = inv * expectedK.getZ();
                 
                 // Assert the quaternion components match expected values
                 // The mutant would produce -expectedQ1, -expectedQ2, -expectedQ3
                 assertEquals(expectedQ1, q1, 1.0e-10);
                 assertEquals(expectedQ2, q2, 1.0e-10);
                 assertEquals(expectedQ3, q3, 1.0e-10);
                 
                 // Also verify the rotation actually transforms u1 to v1 (within tolerance)
                 Vector3D rotatedU1 = rotation.applyTo(u1);
                 assertEquals(0.0, rotatedU1.subtract(v1).getNorm(), 1.0e-10);
             }

 @Test
             public void testRotationOrderConstructorDetectsCrossProductMutation() {
                 // Create vectors that will trigger the cross product path in the constructor
                 Vector3D u1 = new Vector3D(1, 0, 0);
                 Vector3D u2 = new Vector3D(0, 1, 0);
                 Vector3D v1 = new Vector3D(1, 0.001, 0);  // slightly different from u1
                 Vector3D v2 = new Vector3D(0, 1.001, 0);  // slightly different from u2
                 
                 // Create rotation using the vectors
                 Rotation rotation = new Rotation(u1, u2, v1, v2);
                 
                 // Get the quaternion components
                 double q0 = rotation.getQ0();
                 double q1 = rotation.getQ1();
                 double q2 = rotation.getQ2();
                 double q3 = rotation.getQ3();
                 
                 // Verify the quaternion components have expected values
                 // The exact expected values depend on the cross product direction
                 // The mutation would flip the signs of q1, q2, q3
                 assertTrue("q0 should be positive", q0 > 0);
                 
                 // Check that the vector part is non-zero (cross product was used)
                 double vectorNorm = q1*q1 + q2*q2 + q3*q3;
                 assertTrue("Vector part should be significant", vectorNorm > 0.0001);
                 
                 // Create another rotation with slightly different vectors to verify consistency
                 Vector3D v1b = new Vector3D(1, -0.001, 0);
                 Vector3D v2b = new Vector3D(0, 1.001, 0.001);
                 Rotation rotation2 = new Rotation(u1, u2, v1b, v2b);
                 
                 // Verify the two rotations are significantly different (not identity)
                 double distance = Rotation.distance(rotation, rotation2);
                 assertTrue("Rotations should be different", distance > 0.01);
                 
                 // Verify the rotation actually performs as expected by applying it to a vector
                 Vector3D testVector = new Vector3D(0, 0, 1);
                 Vector3D rotatedVector = rotation.applyTo(testVector);
                 double dotProduct = rotatedVector.dotProduct(testVector);
                 assertTrue("Rotation should change the vector", Math.abs(dotProduct) < 0.99);
             }

 @Test
                public void testRotationConstructorDetectsDotProductMutant() {
                    // Create input vectors where k and u2Prime are at 45 degrees
                    Vector3D u1 = new Vector3D(1, 0, 0);
                    Vector3D u2 = new Vector3D(0, 1, 0);
                    Vector3D v1 = new Vector3D(1, 1, 0).normalize();
                    Vector3D v2 = new Vector3D(-1, 1, 0).normalize();
                    
                    // Create rotation - this should use the dot product calculation
                    Rotation rotation = new Rotation(u1, u2, v1, v2);
                    
                    // Verify the rotation is not identity (would be if using mutated code)
                    assertFalse(rotation.getQ0() == 1.0 && 
                               rotation.getQ1() == 0.0 && 
                               rotation.getQ2() == 0.0 && 
                               rotation.getQ3() == 0.0);
                    
                    // Verify the rotation actually transforms u1 to v1 (approximately)
                    Vector3D rotatedU1 = rotation.applyTo(u1);
                    assertEquals(v1.getX(), rotatedU1.getX(), 1e-10);
                    assertEquals(v1.getY(), rotatedU1.getY(), 1e-10);
                    assertEquals(v1.getZ(), rotatedU1.getZ(), 1e-10);
                    
                    // Verify the rotation actually transforms u2 to v2 (approximately)
                    Vector3D rotatedU2 = rotation.applyTo(u2);
                    assertEquals(v2.getX(), rotatedU2.getX(), 1e-10);
                    assertEquals(v2.getY(), rotatedU2.getY(), 1e-10);
                    assertEquals(v2.getZ(), rotatedU2.getZ(), 1e-10);
                }

 @Test
                public void testRotationConstructorDetectsDotProductMutant1() {
                    // Create test vectors that are nearly coplanar but not exactly
                    Vector3D u1 = new Vector3D(1, 0, 0);
                    Vector3D u2 = new Vector3D(0, 1, 0.001);  // slight z-component
                    Vector3D v1 = new Vector3D(1, 0.001, 0);
                    Vector3D v2 = new Vector3D(0.001, 1, 0);
                    
                    // Create rotation - this should use the dot product calculation
                    Rotation rotation = new Rotation(u1, u2, v1, v2);
                    
                    // Verify the rotation is not identity (which it would be if the mutant was active)
                    assertFalse(rotation.getQ0() == 1.0 && 
                               rotation.getQ1() == 0.0 && 
                               rotation.getQ2() == 0.0 && 
                               rotation.getQ3() == 0.0);
                    
                    // More precise assertions on quaternion components
                    double norm = Math.sqrt(rotation.getQ0() * rotation.getQ0() + 
                                          rotation.getQ1() * rotation.getQ1() + 
                                          rotation.getQ2() * rotation.getQ2() + 
                                          rotation.getQ3() * rotation.getQ3());
                    assertEquals(1.0, norm, 1.0e-12);
                    
                    // The rotation should actually perform the required transformation
                    Vector3D v1Transformed = rotation.applyTo(u1);
                    assertEquals(0.0, v1.distance(v1Transformed), 1.0e-8);
                    
                    Vector3D v2Transformed = rotation.applyTo(u2);
                    assertEquals(0.0, v2.distance(v2Transformed), 1.0e-6);
                }

 @Test
                public void testRotationConstructorDetectsMutant1() {
                    // Create input vectors that are nearly but not exactly aligned
                    Vector3D u1 = new Vector3D(1, 0, 0);
                    Vector3D u2 = new Vector3D(0, 1, 0.001);  // slightly off from pure y-axis
                    Vector3D v1 = new Vector3D(1, 0, 0);
                    Vector3D v2 = new Vector3D(0, 1, 0.002);  // slightly more off than u2
                    
                    // Create rotation that should handle this near-alignment case
                    Rotation rotation = new Rotation(u1, u2, v1, v2);
                    
                    // Verify the rotation actually transforms the vectors as expected
                    Vector3D rotatedU1 = rotation.applyTo(u1);
                    Vector3D rotatedU2 = rotation.applyTo(u2);
                    
                    // Check if the rotation properly transformed u1 to v1 (should be exact)
                    assertEquals(0, rotatedU1.subtract(v1).getNorm(), 1e-15);
                    
                    // Check if the rotation properly transformed u2 to v2 (allowing small error)
                    assertEquals(0, rotatedU2.subtract(v2).getNorm(), 1e-10);
                    
                    // The key assertion - verify the quaternion components are reasonable
                    // The mutated version would produce incorrect quaternion values
                    assertTrue(Math.abs(rotation.getQ0()) > 0.99);  // Should be close to identity
                    assertTrue(Math.abs(rotation.getQ1()) < 0.01);
                    assertTrue(Math.abs(rotation.getQ2()) < 0.01);
                    assertTrue(Math.abs(rotation.getQ3()) < 0.01);
                }

 @Test
            public void testRotationConstructorDetectsDotProductMutant2() {
                // Create input vectors that will trigger the code path with the mutation
                // We need vectors where the dot product is significantly different from the product of norms
                Vector3D u1 = new Vector3D(1.0, 0.0, 0.0);
                Vector3D u2 = new Vector3D(0.0, 1.0, 0.0);
                
                // Create v1 and v2 that are slightly rotated versions of u1 and u2
                // The small rotation ensures we hit the threshold comparison code
                double smallAngle = 0.0005; // Just below the inPlaneThreshold
                Vector3D v1 = new Vector3D(FastMath.cos(smallAngle), FastMath.sin(smallAngle), 0.0);
                Vector3D v2 = new Vector3D(-FastMath.sin(smallAngle), FastMath.cos(smallAngle), 0.0);
                
                // Create the rotation
                Rotation rotation = new Rotation(u1, u2, v1, v2);
                
                // Verify the rotation properties
                // The key assertion is that the rotation actually rotates the vectors as expected
                Vector3D rotatedU1 = rotation.applyTo(u1);
                Vector3D rotatedU2 = rotation.applyTo(u2);
                
                // Check that the rotated vectors match the target vectors within tolerance
                double tolerance = 1.0e-10;
                assertEquals(v1.getX(), rotatedU1.getX(), tolerance);
                assertEquals(v1.getY(), rotatedU1.getY(), tolerance);
                assertEquals(v1.getZ(), rotatedU1.getZ(), tolerance);
                
                assertEquals(v2.getX(), rotatedU2.getX(), tolerance);
                assertEquals(v2.getY(), rotatedU2.getY(), tolerance);
                assertEquals(v2.getZ(), rotatedU2.getZ(), tolerance);
                
                // Additional check for quaternion normalization
                double norm = FastMath.sqrt(rotation.getQ0() * rotation.getQ0() +
                                          rotation.getQ1() * rotation.getQ1() +
                                          rotation.getQ2() * rotation.getQ2() +
                                          rotation.getQ3() * rotation.getQ3());
                assertEquals(1.0, norm, tolerance);
            }

 @Test
                public void testRotationConstructorDetectsDotProductMutation() {
                    // Create input vectors that are nearly coplanar but not perfectly aligned
                    Vector3D u1 = new Vector3D(1, 0, 0);
                    Vector3D u2 = new Vector3D(0, 1, 0.001);  // slightly out of plane
                    Vector3D v1 = new Vector3D(1, 0.001, 0);
                    Vector3D v2 = new Vector3D(0.001, 1, 0.001);
                    
                    // Create rotation - this will exercise the mutated code path
                    Rotation rotation = new Rotation(u1, u2, v1, v2);
                    
                    // Verify the rotation components
                    // The key assertion is that the rotation isn't identity (which it would be if c=0)
                    assertFalse("Rotation should not be identity", 
                               rotation.getQ0() == 1.0 && 
                               rotation.getQ1() == 0.0 && 
                               rotation.getQ2() == 0.0 && 
                               rotation.getQ3() == 0.0);
                    
                    // Additional assertions to verify the rotation is valid
                    assertEquals("Quaternion should be normalized", 
                                1.0, 
                                rotation.getQ0() * rotation.getQ0() + 
                                rotation.getQ1() * rotation.getQ1() + 
                                rotation.getQ2() * rotation.getQ2() + 
                                rotation.getQ3() * rotation.getQ3(), 
                                1.0e-15);
                    
                    // Verify the rotation actually transforms u1 to v1 (within tolerance)
                    Vector3D rotatedU1 = rotation.applyTo(u1);
                    assertEquals("Rotated u1 should match v1 x-component", 
                                v1.getX(), rotatedU1.getX(), 1.0e-10);
                    assertEquals("Rotated u1 should match v1 y-component", 
                                v1.getY(), rotatedU1.getY(), 1.0e-10);
                    assertEquals("Rotated u1 should match v1 z-component", 
                                v1.getZ(), rotatedU1.getZ(), 1.0e-10);
                }

 @Test
            public void testRotationCompositionWithNearlyAlignedVectors() {
                // Create vectors that are nearly but not perfectly aligned
                Vector3D u1 = new Vector3D(1.0, 0.0, 0.0);
                Vector3D u2 = new Vector3D(1.0, 0.001, 0.0);
                Vector3D v1 = new Vector3D(1.0, 0.0, 0.0);
                Vector3D v2 = new Vector3D(1.0, 0.001, 0.0);
                
                // Create rotation that should be very close to identity
                Rotation rotation = new Rotation(u1, u2, v1, v2);
                
                // In original code, quaternion components would be very small but non-zero
                // In mutated code, components would be larger due to incorrect angle calculation
                double tolerance = 1e-10;
                
                // Check that the rotation is close to identity but not exactly identity
                assertEquals(1.0, rotation.getQ0(), tolerance);
                assertTrue(Math.abs(rotation.getQ1()) < tolerance);
                assertTrue(Math.abs(rotation.getQ2()) < tolerance);
                assertTrue(Math.abs(rotation.getQ3()) < tolerance);
                
                // Verify that at least one component is non-zero (would fail with mutation)
                assertTrue(Math.abs(rotation.getQ1()) > 1e-15 || 
                           Math.abs(rotation.getQ2()) > 1e-15 || 
                           Math.abs(rotation.getQ3()) > 1e-15);
            }

 @Test
           public void testVectorRotationNearPlaneBoundary() {
               // Create vectors where c is small but k and u2Prime have large norms
               Vector3D u1 = new Vector3D(1, 0, 0);
               Vector3D u2 = new Vector3D(0, 1, 0);
               Vector3D v1 = new Vector3D(1, 0.001, 0);  // slightly rotated in x-y plane
               Vector3D v2 = new Vector3D(0, 1, 0.001);  // slightly rotated in y-z plane
               
               // These vectors will produce:
               // - A small c value (nearly coplanar)
               // - But large k and u2Prime norms
               
               // Create rotation - should use the main branch (not identity)
               Rotation rotation = new Rotation(u1, u2, v1, v2);
               
               // Verify we didn't get identity rotation (which would happen if mutant was triggered)
               assertFalse(rotation.getQ0() == 1.0 && rotation.getQ1() == 0.0 && 
                          rotation.getQ2() == 0.0 && rotation.getQ3() == 0.0);
               
               // Additional verification - check the rotation actually transforms the vectors
               Vector3D v1Rotated = rotation.applyTo(u1);
               Vector3D v2Rotated = rotation.applyTo(u2);
               
               // Check the rotation does what it's supposed to do (approximately)
               assertEquals(0.0, v1.distance(v1Rotated), 1.0e-10);
               assertEquals(0.0, v2.distance(v2Rotated), 1.0e-10);
           }

 @Test
               public void testInPlaneThresholdWithScaledVectors() {
                   // Create base vectors that are nearly but not exactly coplanar
                   Vector3D u1 = new Vector3D(1, 0, 0);
                   Vector3D u2 = new Vector3D(0, 1, 0.001);  // slightly out of plane
                   Vector3D v1 = new Vector3D(1, 0, 0);
                   Vector3D v2 = new Vector3D(0, 1, 0.001);  // same slight deviation
                   
                   // Create scaled versions (large magnitude)
                   double scale = 1000;
                   Vector3D scaledU1 = new Vector3D(scale, u1);
                   Vector3D scaledU2 = new Vector3D(scale, u2);
                   Vector3D scaledV1 = new Vector3D(scale, v1);
                   Vector3D scaledV2 = new Vector3D(scale, v2);
                   
                   // Create rotations - should behave the same since it's the same geometry
                   Rotation smallRotation = new Rotation(u1, u2, v1, v2);
                   Rotation largeRotation = new Rotation(scaledU1, scaledU2, scaledV1, scaledV2);
                   
                   // The mutant would treat these differently because it doesn't scale the threshold
                   // Check that the rotations are equivalent (within floating point tolerance)
                   assertEquals(smallRotation.getQ0(), largeRotation.getQ0(), 1e-10);
                   assertEquals(smallRotation.getQ1(), largeRotation.getQ1(), 1e-10);
                   assertEquals(smallRotation.getQ2(), largeRotation.getQ2(), 1e-10);
                   assertEquals(smallRotation.getQ3(), largeRotation.getQ3(), 1e-10);
               }

 @Test
           public void testRotationConstructorDetectsInPlaneCondition() {
               // Create vectors where the product of norms is large enough to make a difference
               Vector3D u1 = new Vector3D(1, 0, 0);
               Vector3D u2 = new Vector3D(0, 1, 0);
               Vector3D v1 = new Vector3D(1, 0.001, 0);  // slightly off from u1
               Vector3D v2 = new Vector3D(0.001, 1, 0.001);  // slightly off from u2
               
               // This should pass with original code but fail with mutated code
               // because c will be small but inPlaneThreshold*k.getNorm()*u2Prime.getNorm() will be larger
               try {
                   Rotation rotation = new Rotation(u1, u2, v1, v2);
                   // If we get here, the mutant wasn't caught - this is bad
                   fail("Expected the rotation to be detected as in-plane but it wasn't");
               } catch (Exception e) {
                   // This is expected for the original code
                   // The mutant would skip this exception
               }
               
               // More precise test with calculated values
               Vector3D v1Su1 = v1.subtract(u1);
               Vector3D v2Su2 = v2.subtract(u2);
               Vector3D k = v1Su1.crossProduct(v2Su2);
               Vector3D u3 = u1.crossProduct(u2);
               double c = k.dotProduct(u3);
               double threshold = 0.001;
               
               // Verify that the condition would be true with original code
               assertTrue(c <= threshold * k.getNorm() * u3.getNorm());
               
               // Verify that the condition would be false with mutated code
               assertFalse(c <= threshold);
           }

 @Test
           public void testRotationConstructorDetectsMutatedPlaneCondition() {
               // Create vectors where c is between inPlaneThreshold and inPlaneThreshold * norms product
               Vector3D u1 = new Vector3D(1, 0, 0);
               Vector3D u2 = new Vector3D(0, 1, 0);
               
               // v1 and v2 are slightly rotated versions that will produce a small but significant c value
               Vector3D v1 = new Vector3D(1, 0.001, 0);
               Vector3D v2 = new Vector3D(0.001, 1, 0.001);
               
               // Calculate expected values that would make the original condition false but mutated true
               Vector3D u3 = u1.crossProduct(u2);
               Vector3D v3 = Vector3D.crossProduct(v1, v2);
               Vector3D v3Su3 = v3.subtract(u3);
               Vector3D v1Su1 = v1.subtract(u1);
               Vector3D k = v1Su1.crossProduct(v3Su3);
               Vector3D u2Prime = u1.crossProduct(u3);
               double c = k.dotProduct(u2Prime);
               double threshold = 0.001; // inPlaneThreshold
               
               // Verify our test setup - c should be between threshold and threshold*norms
               assertTrue(c > threshold);
               assertTrue(c < threshold * k.getNorm() * u2Prime.getNorm());
               
               // Now test the actual constructor
               Rotation rotation = new Rotation(u1, u2, v1, v2);
               
               // Verify it's not identity rotation (which would happen if mutant was active)
               assertFalse(rotation.getQ0() == 1.0 && 
                          rotation.getQ1() == 0.0 && 
                          rotation.getQ2() == 0.0 && 
                          rotation.getQ3() == 0.0);
               
               // Additional verification that rotation was properly computed
               Vector3D rotatedU1 = rotation.applyTo(u1);
               assertTrue(rotatedU1.subtract(v1).getNorm() < 1.0e-10);
           }

 @Test
               public void testRotationConstructorDetectsCoplanarityCorrectly() {
                   // Create vectors where k.getNorm() * u2Prime.getNorm() is large
                   // so that inPlaneThreshold * k.getNorm() * u2Prime.getNorm() >> inPlaneThreshold
                   
                   // First pair of vectors (u1, v1)
                   Vector3D u1 = new Vector3D(1, 0, 0);
                   Vector3D v1 = new Vector3D(1, 0.0005, 0); // slightly different from u1
                   
                   // Second pair of vectors (u2, v2)
                   Vector3D u2 = new Vector3D(0, 1, 0);
                   Vector3D v2 = new Vector3D(0, 1, 0.0005); // slightly different from u2
                   
                   // Third vector (u3) - will be used in the second check
                   Vector3D u3 = new Vector3D(0, 0, 1);
                   
                   // Create rotation - this will trigger the path with the mutated condition
                   Rotation rotation = new Rotation(u1, u2, v1, v2);
                   
                   // The key assertion is that we get past the coplanarity check
                   // In the original code, with large k.getNorm() * u2Prime.getNorm(),
                   // c would be greater than inPlaneThreshold but less than inPlaneThreshold * k.getNorm() * u2Prime.getNorm()
                   // So the original would proceed to the second check, while the mutant would treat it as coplanar
                   
                   // Verify the rotation isn't identity (which would happen if mutant treated it as coplanar)
                   assertFalse(rotation.getQ0() == 1.0 && 
                              rotation.getQ1() == 0.0 && 
                              rotation.getQ2() == 0.0 && 
                              rotation.getQ3() == 0.0);
                   
                   // Additional verification that we got a valid rotation
                   assertEquals(1.0, 
                               rotation.getQ0() * rotation.getQ0() + 
                               rotation.getQ1() * rotation.getQ1() + 
                               rotation.getQ2() * rotation.getQ2() + 
                               rotation.getQ3() * rotation.getQ3(),
                               1.0e-15);
               }

 @Test
          public void testRotationConstructorDetectsMutant2() {
              // Create vectors where k.getNorm() * u2Prime.getNorm() is large
              // to amplify the difference between original and mutant
              Vector3D u1 = new Vector3D(1.0, 0.0, 0.0);
              Vector3D u2 = new Vector3D(0.0, 1.0, 0.0);
              Vector3D u3 = new Vector3D(0.0, 0.0, 1.0);
              
              // Create v vectors that are slightly different from u vectors
              // to trigger the in-plane check but not be exactly equal
              Vector3D v1 = new Vector3D(1.001, 0.001, 0.001);
              Vector3D v2 = new Vector3D(0.001, 1.001, 0.001);
              Vector3D v3 = new Vector3D(0.001, 0.001, 1.001);
              
              // Create rotation with large norms to make the product significant
              Rotation r1 = new Rotation(u1, 0.1);
              Rotation r2 = new Rotation(u2, 0.1);
              Rotation r3 = new Rotation(u3, 0.1);
              
              // The mutant will use a much smaller threshold (0.001) compared to original
              // which uses 0.001 * k.getNorm() * u2Prime.getNorm() (likely >> 0.001)
              // So we choose a c value between these two thresholds
              
              // Create a rotation that would pass the original check but fail the mutant
              try {
                  Rotation rotation = new Rotation(u1, u2, v1, v2);
                  
                  // Instead of comparing with mutant rotation, compare with expected values
                  // These values should be pre-calculated based on known correct behavior
                  double expectedQ0 = 0.9999995;  // Example expected value
                  double expectedQ1 = 0.0005;     // Example expected value
                  double expectedQ2 = 0.0005;     // Example expected value
                  double expectedQ3 = 0.0005;     // Example expected value
                  
                  // Assert that the actual rotation matches expected values
                  assertEquals(expectedQ0, rotation.getQ0(), 1e-6);
                  assertEquals(expectedQ1, rotation.getQ1(), 1e-6);
                  assertEquals(expectedQ2, rotation.getQ2(), 1e-6);
                  assertEquals(expectedQ3, rotation.getQ3(), 1e-6);
              } catch (Exception e) {
                  fail("Should not throw exception for these inputs");
              }
          }

 @Test
      public void testRotationConstructorDetectsDotProductMutant3() {
          // Create input vectors where k and u3 are not parallel
          Vector3D u1 = new Vector3D(1, 0, 0);
          Vector3D u2 = new Vector3D(0, 1, 0);
          Vector3D v1 = new Vector3D(0, 0, 1);
          Vector3D v2 = new Vector3D(0, 1, 0);
          
          // Create rotation - this will use the mutated code if not caught
          Rotation rotation = new Rotation(u1, u2, v1, v2);
          
          // Verify the rotation actually transforms u1 to v1
          Vector3D rotatedU1 = rotation.applyTo(u1);
          double distance = Vector3D.distance(v1, rotatedU1);
          assertTrue("Rotation should transform u1 to v1", distance < 1.0e-10);
          
          // Verify the rotation actually transforms u2 to v2
          Vector3D rotatedU2 = rotation.applyTo(u2);
          distance = Vector3D.distance(v2, rotatedU2);
          assertTrue("Rotation should transform u2 to v2", distance < 1.0e-10);
          
          // Additional verification - check quaternion norm is 1
          double norm = FastMath.sqrt(rotation.getQ0() * rotation.getQ0() +
                                    rotation.getQ1() * rotation.getQ1() +
                                    rotation.getQ2() * rotation.getQ2() +
                                    rotation.getQ3() * rotation.getQ3());
          assertEquals("Quaternion should be normalized", 1.0, norm, 1.0e-10);
      }

 @Test
      public void testRotationConstructorDetectsMutant3() {
          // Create test vectors where k and u3 are not parallel
          Vector3D u1 = new Vector3D(1, 0, 0);
          Vector3D u2 = new Vector3D(0, 1, 0);
          Vector3D v1 = new Vector3D(0, 0, 1);
          Vector3D v2 = new Vector3D(1, 1, 0);
          
          // Calculate expected values
          Vector3D v1Su1 = v1.subtract(u1);
          Vector3D v2Su2 = v2.subtract(u2);
          Vector3D k = v1Su1.crossProduct(v2Su2);
          Vector3D u3 = u1.crossProduct(u2);
          
          // Original would use dot product, mutant uses product of norms
          double originalC = k.dotProduct(u3);
          double mutantC = k.getNorm() * u3.getNorm();
          
          // These should be different for non-parallel vectors
          assertNotEquals(originalC, mutantC, 1e-10);
          
          // Create rotation - this should use original dot product calculation
          Rotation rotation = new Rotation(u1, u2, v1, v2);
          
          // Verify the rotation actually transforms the vectors as expected
          Vector3D rotatedU1 = rotation.applyTo(u1);
          Vector3D rotatedU2 = rotation.applyTo(u2);
          
          // Check if rotation correctly transforms u1 to v1 and u2 to v2
          assertEquals(0.0, rotatedU1.distance(v1), 1e-10);
          assertEquals(0.0, rotatedU2.distance(v2), 1e-10);
          
          // Also verify quaternion components are valid (unit norm)
          double norm = FastMath.sqrt(rotation.getQ0() * rotation.getQ0() +
                                    rotation.getQ1() * rotation.getQ1() +
                                    rotation.getQ2() * rotation.getQ2() +
                                    rotation.getQ3() * rotation.getQ3());
          assertEquals(1.0, norm, 1e-10);
      }

 @Test
      public void testRotationConstructorWithAntiParallelVectors() {
          // Create input vectors where k and u3 are anti-parallel
          Vector3D u1 = new Vector3D(1, 0, 0);
          Vector3D u2 = new Vector3D(0, 1, 0);
          
          // v1 and v2 are constructed such that v1Su1 and v2Su2 will create
          // a k vector anti-parallel to u3
          Vector3D v1 = new Vector3D(1, 0.1, 0);
          Vector3D v2 = new Vector3D(0.1, -1, 0);
          
          // This should create a valid rotation
          Rotation rotation = new Rotation(u1, u2, v1, v2);
          
          // Verify the rotation actually transforms u1 to v1 (normalized)
          Vector3D transformedU1 = rotation.applyTo(u1);
          Vector3D expectedV1 = v1.normalize();
          assertEquals(expectedV1.getX(), transformedU1.getX(), 1.0e-10);
          assertEquals(expectedV1.getY(), transformedU1.getY(), 1.0e-10);
          assertEquals(expectedV1.getZ(), transformedU1.getZ(), 1.0e-10);
          
          // Verify the rotation actually transforms u2 to v2 (normalized)
          Vector3D transformedU2 = rotation.applyTo(u2);
          Vector3D expectedV2 = v2.normalize();
          assertEquals(expectedV2.getX(), transformedU2.getX(), 1.0e-10);
          assertEquals(expectedV2.getY(), transformedU2.getY(), 1.0e-10);
          assertEquals(expectedV2.getZ(), transformedU2.getZ(), 1.0e-10);
          
          // Verify it's a valid rotation (determinant should be 1)
          double[][] m = rotation.getMatrix();
          double det = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) -
                       m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
                       m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
          assertEquals(1.0, det, 1.0e-10);
      }

 @Test
      public void testRotationConstructorDetectsNegativeDotProduct() {
          // Create input vectors that will trigger the mutated code path
          // and produce a negative dot product but positive norms product
          Vector3D u1 = new Vector3D(1, 0, 0);
          Vector3D u2 = new Vector3D(0, 1, 0);
          
          // v1 is same as u1 (identity rotation component)
          Vector3D v1 = new Vector3D(1, 0, 0);
          // v2 is opposite of u2 to create negative dot product
          Vector3D v2 = new Vector3D(0, -1, 0);
          
          // This should create a rotation where:
          // - The code reaches the mutated section
          // - k.dotProduct(u2.crossProduct(u3)) would be negative
          // - But k.getNorm() * u2.crossProduct(u3).getNorm() would be positive
          Rotation rotation = new Rotation(u1, u2, v1, v2);
          
          // Verify we don't get identity rotation (which would happen if mutant is present)
          // Since we created vectors that should produce a 180 degree rotation around x-axis
          assertNotEquals(1.0, rotation.getQ0(), 1e-10);
          assertEquals(1.0, rotation.getQ1(), 1e-10); // Should have x-component for 180° rotation
          assertEquals(0.0, rotation.getQ2(), 1e-10);
          assertEquals(0.0, rotation.getQ3(), 1e-10);
          
          // Additional verification by applying the rotation to u2 should give v2
          Vector3D rotatedU2 = rotation.applyTo(u2);
          assertEquals(0.0, rotatedU2.distance(v2), 1e-10);
      }

 @Test
      public void testRotationFromVectorsDetectsDotProductMutant() {
          // Create input vectors that will produce non-parallel k and u3 vectors
          Vector3D u1 = new Vector3D(1, 0, 0);
          Vector3D u2 = new Vector3D(0, 1, 0);
          Vector3D v1 = new Vector3D(0.5, 0.5, Math.sqrt(2)/2);
          Vector3D v2 = new Vector3D(-0.5, 0.5, Math.sqrt(2)/2);
          
          // Create rotation - this should use the correct dot product calculation
          Rotation rotation = new Rotation(u1, u2, v1, v2);
          
          // Calculate what the mutant would produce
          Vector3D v1Su1 = v1.subtract(u1);
          Vector3D v2Su2 = v2.subtract(u2);
          Vector3D k = v1Su1.crossProduct(v2Su2);
          Vector3D u3 = u1.crossProduct(u2);
          double mutantC = k.getNorm() * u3.getNorm();
          
          // Calculate what the original would produce
          double originalC = k.dotProduct(u3);
          
          // Verify the rotation didn't use the mutant calculation
          // If it did, the quaternion components would be wrong
          // We can check that the rotation actually rotates the vectors as expected
          Vector3D rotatedU1 = rotation.applyTo(u1);
          double angle = FastMath.acos(rotatedU1.dotProduct(v1) / (rotatedU1.getNorm() * v1.getNorm()));
          
          // The angle should be small (vectors should be nearly aligned after rotation)
          assertTrue("Rotation should properly align vectors", angle < 0.01);
          
          // Additionally verify the quaternion components are reasonable
          assertNotEquals("q0 should not be zero", 0.0, rotation.getQ0(), 1e-10);
          assertTrue("Quaternion should be normalized", 
              Math.abs(rotation.getQ0()*rotation.getQ0() + 
                       rotation.getQ1()*rotation.getQ1() + 
                       rotation.getQ2()*rotation.getQ2() + 
                       rotation.getQ3()*rotation.getQ3() - 1.0) < 1e-10);
          
          // Verify the mutant calculation would give different results
          assertNotEquals("Mutant calculation differs from original", mutantC, originalC, 1e-10);
      }

 @Test
     public void testRotationCompositionDetectsMutant() {
         // Create non-orthogonal rotation axes to expose the mutation
         Vector3D axis1 = new Vector3D(1, 0, 0);
         Vector3D axis2 = new Vector3D(1, 1, 0); // Not orthogonal to axis1
         Vector3D axis3 = new Vector3D(0, 1, 1); // Not orthogonal to others
         
         // Angles that will produce noticeable differences
         double angle1 = Math.PI/4;
         double angle2 = Math.PI/3;
         double angle3 = Math.PI/6;
         
         // Create individual rotations with non-orthogonal axes
         Rotation r1 = new Rotation(axis1, angle1);
         Rotation r2 = new Rotation(axis2, angle2);
         Rotation r3 = new Rotation(axis3, angle3);
         
         // Compose the rotations manually
         Rotation originalRotation = r1.applyTo(r2.applyTo(r3));
         
         // Expected values based on dot product behavior
         double expectedQ0 = originalRotation.getQ0();
         double expectedQ1 = originalRotation.getQ1();
         double expectedQ2 = originalRotation.getQ2();
         double expectedQ3 = originalRotation.getQ3();
         
         // With the mutated version (norm multiplication instead of dot product),
         // the quaternion components would be different
         // We assert that the actual values match the expected dot-product-based calculation
         assertEquals("q0 component should match expected value", expectedQ0, originalRotation.getQ0(), 1e-15);
         assertEquals("q1 component should match expected value", expectedQ1, originalRotation.getQ1(), 1e-15);
         assertEquals("q2 component should match expected value", expectedQ2, originalRotation.getQ2(), 1e-15);
         assertEquals("q3 component should match expected value", expectedQ3, originalRotation.getQ3(), 1e-15);
         
         // Additional test with different angles to ensure robustness
         angle1 = Math.PI/2;
         angle2 = Math.PI/4;
         angle3 = Math.PI/8;
         r1 = new Rotation(axis1, angle1);
         r2 = new Rotation(axis2, angle2);
         r3 = new Rotation(axis3, angle3);
         Rotation rotation2 = r1.applyTo(r2.applyTo(r3));
         
         // Verify the rotation actually changes with different angles
         assertNotEquals("Different angles should produce different q0", expectedQ0, rotation2.getQ0(), 1e-15);
         assertNotEquals("Different angles should produce different q1", expectedQ1, rotation2.getQ1(), 1e-15);
         assertNotEquals("Different angles should produce different q2", expectedQ2, rotation2.getQ2(), 1e-15);
         assertNotEquals("Different angles should produce different q3", expectedQ3, rotation2.getQ3(), 1e-15);
     }

 @Test
     public void testRotationFromTwoVectorPairsDetectsQ1Mutation() {
         // Create input vectors where k.getX() != k.getY()
         Vector3D u1 = new Vector3D(1, 0, 0);
         Vector3D u2 = new Vector3D(0, 1, 0);
         Vector3D v1 = new Vector3D(0, 1, 0);
         Vector3D v2 = new Vector3D(0, 0, 1);
         
         // This will create a k vector where x and y components are different
         Rotation rotation = new Rotation(u1, u2, v1, v2);
         
         // Get the actual k vector that would be used in the calculation
         Vector3D v1Su1 = v1.subtract(u1);
         Vector3D v2Su2 = v2.subtract(u2);
         Vector3D k = v1Su1.crossProduct(v2Su2);
         
         // Calculate what q1 should be (using k.getX())
         double c = k.dotProduct(u1.crossProduct(u2));
         c = FastMath.sqrt(c);
         double inv = 1.0 / (c + c);
         double expectedQ1 = inv * k.getX();
         
         // Verify the actual q1 matches what we expect
         assertEquals("q1 should be calculated using k.getX()", 
                     expectedQ1, rotation.getQ1(), 1e-15);
         
         // Additional check to ensure this would fail with the mutant
         double mutantQ1 = inv * k.getY();
         assertNotEquals("Test should fail if mutant is present", 
                        mutantQ1, rotation.getQ1(), 1e-15);
     }

 @Test
     public void testAxisAngleConstructor_q1Calculation() {
         // Create a test axis where x ≠ y to detect the mutant
         Vector3D axis = new Vector3D(2.0, 3.0, 4.0); // x=2, y=3
         double angle = Math.PI / 4; // 45 degrees
         
         // Create rotation
         Rotation rotation = new Rotation(axis, angle);
         
         // Calculate expected values
         double norm = axis.getNorm();
         double halfAngle = -0.5 * angle;
         double coeff = Math.sin(halfAngle) / norm;
         
         // Verify q1 is calculated using x-component (not y-component)
         double expectedQ1 = coeff * axis.getX();
         assertEquals("q1 should be calculated using x-component of axis", 
                     expectedQ1, rotation.getQ1(), 1e-15);
         
         // Also verify other components for completeness
         assertEquals(Math.cos(halfAngle), rotation.getQ0(), 1e-15);
         assertEquals(coeff * axis.getY(), rotation.getQ2(), 1e-15);
         assertEquals(coeff * axis.getZ(), rotation.getQ3(), 1e-15);
     }

 @Test
 public void testRotationFromTwoPairsOfVectorsDetectsQ1Mutant() {
     // Create input vectors that will generate a known k vector with distinct x and y components
     Vector3D u1 = new Vector3D(1, 0, 0);
     Vector3D u2 = new Vector3D(0, 1, 0);
     Vector3D v1 = new Vector3D(0, 1, 0);
     Vector3D v2 = new Vector3D(-1, 0, 0);
     
     // This should produce a 90-degree rotation around z-axis
     Rotation rotation = new Rotation(u1, u2, v1, v2);
     
     // Verify all quaternion components
     // For 90-degree z-rotation, expected quaternion is:
     // q0 = cos(45°) ≈ 0.7071
     // q1 = 0
     // q2 = 0
     // q3 = sin(45°) ≈ 0.7071
     double sqrt2 = FastMath.sqrt(2);
     double expectedQ0 = 1.0/sqrt2;
     double expectedQ1 = 0.0;
     double expectedQ2 = 0.0;
     double expectedQ3 = 1.0/sqrt2;
     
     // The mutation would make q1 = k.getY() instead of k.getX()
     // In this case, k.getX() would be 0 and k.getY() would be 0,
     // but we need a case where they're different to detect the mutant
     // Let's modify the test case to ensure k has different x and y
     
     // Alternative test case where k has distinct x and y components
     u1 = new Vector3D(1, 0, 0);
     u2 = new Vector3D(0, 1, 0);
     v1 = new Vector3D(0, 1, 1);  // changed z component
     v2 = new Vector3D(-1, 0, 1); // changed z component
     
     rotation = new Rotation(u1, u2, v1, v2);
     
     // Calculate expected values
     Vector3D v1Su1 = v1.subtract(u1);
     Vector3D v2Su2 = v2.subtract(u2);
     Vector3D k = v1Su1.crossProduct(v2Su2);
     double c = FastMath.sqrt(k.dotProduct(u1.crossProduct(u2)));
     double inv = 1.0 / (c + c);
     
     // These are the expected values from original code
     double correctQ1 = inv * k.getX();
     double correctQ2 = inv * k.getY();
     
     // Verify q1 and q2 are calculated correctly
     // The mutation would make q1 equal to q2 when x and y are different
     assertNotEquals("q1 should not equal q2 when k has different x and y components", 
                    rotation.getQ1(), rotation.getQ2(), 1e-10);
     assertEquals("q1 should be inv * k.getX()", correctQ1, rotation.getQ1(), 1e-10);
     assertEquals("q2 should be inv * k.getY()", correctQ2, rotation.getQ2(), 1e-10);
 }

 @Test
 public void testRotationConstructorDetectsQ1Mutation() {
     // Create input vectors where u1 and v1 are not parallel
     // and u2/v2 are not parallel to u1/v1 to ensure non-identity rotation
     Vector3D u1 = new Vector3D(1, 0, 0);
     Vector3D u2 = new Vector3D(0, 1, 0);
     Vector3D v1 = new Vector3D(0, 0, 1);
     Vector3D v2 = new Vector3D(1, 1, 0);
     
     // Create rotation - this will compute k vector with different x and y components
     Rotation rotation = new Rotation(u1, u2, v1, v2);
     
     // Get the quaternion components
     double q1 = rotation.getQ1();
     double q2 = rotation.getQ2();
     
     // Verify q1 is calculated from k's x-component (original behavior)
     // The mutation would make q1 equal to q2 since both would use k.getY()
     assertNotEquals("q1 and q2 should not be equal for this input", q1, q2, 1e-10);
     
     // Additional verification - compute expected q1 based on k vector calculation
     // This is the full verification that would catch the mutation
     Vector3D v1Normalized = new Vector3D(1.0, v1); // since u1 has norm 1
     Vector3D v2Adjusted = new Vector3D(0, v1Normalized, 1, v2); // simplified adjustment
     
     Vector3D v1Su1 = v1Normalized.subtract(u1);
     Vector3D v2Su2 = v2Adjusted.subtract(u2);
     Vector3D k = v1Su1.crossProduct(v2Su2);
     Vector3D u3 = u1.crossProduct(u2);
     double c = k.dotProduct(u3);
     c = FastMath.sqrt(c);
     double inv = 1.0 / (c + c);
     double expectedQ1 = inv * k.getX();
     
     assertEquals("q1 should be calculated from k's x-component", 
                 expectedQ1, q1, 1e-10);
 }

 @Test
 public void testRotationFromVectorsDetectsQ1Mutation() {
     // Create two non-parallel vectors to trigger general case
     Vector3D u = new Vector3D(1, 0, 0);
     Vector3D v = new Vector3D(0, 1, 0);
     
     // Calculate expected values
     double normProduct = u.getNorm() * v.getNorm();
     double dot = u.dotProduct(v);
     double expectedQ0 = FastMath.sqrt(0.5 * (1.0 + dot / normProduct));
     double coeff = 1.0 / (2.0 * expectedQ0 * normProduct);
     Vector3D q = v.crossProduct(u);
     
     // Create rotation
     Rotation rotation = new Rotation(u, v);
     
     // Verify all quaternion components
     assertEquals(expectedQ0, rotation.getQ0(), 1.0e-15);
     // This assertion will fail if mutation is present (using getY() instead of getX())
     assertEquals(coeff * q.getX(), rotation.getQ1(), 1.0e-15);
     assertEquals(coeff * q.getY(), rotation.getQ2(), 1.0e-15);
     assertEquals(coeff * q.getZ(), rotation.getQ3(), 1.0e-15);
     
     // Additional verification - the quaternion should be normalized
     double norm = FastMath.sqrt(rotation.getQ0() * rotation.getQ0() +
                               rotation.getQ1() * rotation.getQ1() +
                               rotation.getQ2() * rotation.getQ2() +
                               rotation.getQ3() * rotation.getQ3());
     assertEquals(1.0, norm, 1.0e-15);
 }

 @Test
     public void testQuaternionComponentsFromVectors() {
         // Create two vectors where their cross product has different x and y components
         Vector3D u = new Vector3D(1, 0, 0);
         Vector3D v = new Vector3D(0, 1, 0);
         
         // The cross product u × v should be (0, 0, 1)
         // In the original code, q1 should be based on the x-component (0)
         // The mutant would use the y-component (0 in this case - not good for detection)
         
         // Let's try different vectors where x and y components differ
         u = new Vector3D(1, 2, 3);
         v = new Vector3D(4, 5, 6);
         // Cross product is (-3, 6, -3) - x and y components are different
         
         Rotation rotation = new Rotation(u, v);
         
         // Calculate expected q1 value (should use x-component of cross product)
         Vector3D cross = u.crossProduct(v);
         double normProduct = u.getNorm() * v.getNorm();
         double dot = u.dotProduct(v);
         double q0Expected = FastMath.sqrt(0.5 * (1.0 + dot / normProduct));
         double coeff = 1.0 / (2.0 * q0Expected * normProduct);
         double q1Expected = coeff * cross.getX();
         
         // Verify q1 is calculated correctly (would fail with mutant)
         assertEquals("q1 should be calculated using x-component of cross product", 
                    q1Expected, rotation.getQ1(), 1e-10);
         
         // Additional verification that other components are correct
         assertEquals(coeff * cross.getY(), rotation.getQ2(), 1e-10);
         assertEquals(coeff * cross.getZ(), rotation.getQ3(), 1e-10);
     }

}
