package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
 
public class ContinuedFractionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                public void testEvaluate_WithNaNInput() {
                                                                    ContinuedFraction cf = new ContinuedFraction() {
                                                                        @Override
                                                                        protected double getA(int n, double x) {
                                                                            return 1.0;
                                                                        }
                                                                        
                                                                        @Override
                                                                        protected double getB(int n, double x) {
                                                                            return 1.0;
                                                                        }
                                                                    };
                                                                    double x = Double.NaN;
                                                                    
                                                                    double result = cf.evaluate(x);
                                                                    assertTrue(Double.isNaN(result));
                                                                }

 @Test
                                                                public void testEvaluate_WithInfiniteInput() {
                                                                    ContinuedFraction cf = new ContinuedFraction() {
                                                                        @Override
                                                                        protected double getA(int n, double x) {
                                                                            return 1.0;
                                                                        }
                                                                        
                                                                        @Override
                                                                        protected double getB(int n, double x) {
                                                                            return 1.0;
                                                                        }
                                                                    };
                                                                    double x = Double.POSITIVE_INFINITY;
                                                                    
                                                                    double result = cf.evaluate(x);
                                                                    assertTrue(Double.isNaN(result) || Double.isInfinite(result));
                                                                }

 @Test(expected = IllegalArgumentException.class)
                                                                public void testEvaluate_WithNaNInput1() {
                                                                    ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                                        @Override
                                                                        protected double getA(int n, double x) {
                                                                            return 1.0;
                                                                        }
                                                                        
                                                                        @Override
                                                                        protected double getB(int n, double x) {
                                                                            return 1.0;
                                                                        }
                                                                    };
                                                                    double x = Double.NaN;
                                                                    continuedFraction.evaluate(x);
                                                                }

 @Test
                                                                public void testEvaluate_WithNegativeEpsilon() {
                                                                    double x = 1.0;
                                                                    double negativeEpsilon = -1e-10;
                                                                    ExpectedException thrown = ExpectedException.none();
                                                                    thrown.expect(IllegalArgumentException.class);
                                                                    
                                                                    ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                                        @Override
                                                                        protected double getA(int n, double x) {
                                                                            return 1.0;
                                                                        }
                                                                        
                                                                        @Override
                                                                        protected double getB(int n, double x) {
                                                                            return 1.0;
                                                                        }
                                                                    };
                                                                    
                                                                    continuedFraction.evaluate(x, negativeEpsilon);
                                                                }

 @Test
                                                            public void testEvaluate_WithZeroMaxIterations() {
                                                                ContinuedFraction cf = new ContinuedFraction() {
                                                                    @Override
                                                                    protected double getA(int n, double x) {
                                                                        return 1.0;
                                                                    }
                                                                    
                                                                    @Override
                                                                    protected double getB(int n, double x) {
                                                                        return 1.0;
                                                                    }
                                                                };
                                                                double x = 2.0;
                                                                double epsilon = 0.0001;
                                                                cf.evaluate(x, epsilon, 0);
                                                            }

 @Test
                                                        public void testEvaluateWithSmallValuesDetectsEpsilonMutation() {
                                                            // Create a concrete subclass of ContinuedFraction for testing
                                                            ContinuedFraction fraction = new ContinuedFraction() {
                                                                @Override
                                                                protected double getA(int n, double x) {
                                                                    // Return a value between 1e-30 and 1e-50 for n=0
                                                                    return (n == 0) ? 5e-40 : 1.0;
                                                                }
                                                        
                                                                @Override
                                                                protected double getB(int n, double x) {
                                                                    return 1.0;
                                                                }
                                                            };
                                                        
                                                            // With original small=1e-50, 5e-40 should NOT be considered equal to 0
                                                            // With mutated small=1e-30, 5e-40 WOULD be considered equal to 0
                                                            // This should lead to different hN values
                                                            
                                                            double originalResult = fraction.evaluate(1.0, 1e-10, 100);
                                                            
                                                            // The exact expected value depends on the algorithm's behavior,
                                                            // but we know it should be different from the small value (1e-50 or 1e-30)
                                                            assertNotEquals(1e-50, originalResult, 1e-60);
                                                            assertTrue(originalResult > 1e-50);
                                                            
                                                            // If the mutation were present (small=1e-30), the result would be different
                                                            // because 5e-40 would be treated as 0 (replaced with small=1e-30)
                                                            // So we verify our test is sensitive to the small value
                                                        }

 @Test
                                                   public void testEvaluate_SingleParameter_WithMockBehavior() {
                                                       // Create a spy of ContinuedFraction with mocked behavior
                                                       ContinuedFraction fraction = spy(new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 0;
                                                           }
                                                       
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 0;
                                                           }
                                                       
                                                           @Override
                                                           public double evaluate(double x, double epsilon, int maxIterations) {
                                                               if (x == Double.POSITIVE_INFINITY) {
                                                                   return Double.POSITIVE_INFINITY;
                                                               }
                                                               if (x == Double.NEGATIVE_INFINITY) {
                                                                   return Double.NEGATIVE_INFINITY;
                                                               }
                                                               if (Double.isNaN(x)) {
                                                                   return Double.NaN;
                                                               }
                                                               return x;
                                                           }
                                                       });
                                                   
                                                       // Mock the single-parameter evaluate to call our three-parameter version
                                                       when(fraction.evaluate(anyDouble())).thenAnswer(invocation -> {
                                                           double x = invocation.getArgument(0);
                                                           return fraction.evaluate(x, 1e-15, Integer.MAX_VALUE);
                                                       });
                                                   
                                                       // Test infinity cases
                                                       assertEquals(Double.POSITIVE_INFINITY, fraction.evaluate(Double.POSITIVE_INFINITY), 0.0);
                                                       assertEquals(Double.NEGATIVE_INFINITY, fraction.evaluate(Double.NEGATIVE_INFINITY), 0.0);
                                                   
                                                       // Test NaN
                                                       assertTrue(Double.isNaN(fraction.evaluate(Double.NaN)));
                                                   }

 @Test
                                                   public void testEvaluate_SingleParameter_EdgeCases() {
                                                       ContinuedFraction fraction = spy(new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 0;
                                                           }
                                                       
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 0;
                                                           }
                                                       
                                                           @Override
                                                           public double evaluate(double x) {
                                                               return x;
                                                           }
                                                           
                                                           @Override
                                                           public double evaluate(double x, double epsilon, int maxIterations) {
                                                               return x;
                                                           }
                                                       });
                                                       
                                                       // Test very large values
                                                       assertEquals(Double.MAX_VALUE, fraction.evaluate(Double.MAX_VALUE), 0.0);
                                                       assertEquals(-Double.MAX_VALUE, fraction.evaluate(-Double.MAX_VALUE), 0.0);
                                                       
                                                       // Test very small values
                                                       assertEquals(Double.MIN_VALUE, fraction.evaluate(Double.MIN_VALUE), 0.0);
                                                       assertEquals(-Double.MIN_VALUE, fraction.evaluate(-Double.MIN_VALUE), 0.0);
                                                   }

 @Test
                                                   public void testEvaluate_WithCustomEpsilon() {
                                                       // Create an anonymous implementation of ContinuedFraction for testing
                                                       ContinuedFraction cf = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       
                                                       double x = 2.0;
                                                       double epsilon = 0.0001;
                                                       
                                                       ContinuedFraction spyCf = spy(cf);
                                                       spyCf.evaluate(x, epsilon);
                                                       
                                                       verify(spyCf).evaluate(x, epsilon, Integer.MAX_VALUE);
                                                   }

 @Test
                                                   public void testEvaluate_WithAllParameters() {
                                                       // Define a concrete implementation of ContinuedFraction for testing
                                                       ContinuedFraction cf = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return n * x;
                                                           }
                                                       };
                                                       
                                                       double x = 2.0;
                                                       double epsilon = 0.0001;
                                                       int maxIterations = 100;
                                                       
                                                       // Test the actual computation
                                                       double result = cf.evaluate(x, epsilon, maxIterations);
                                                       assertFalse(Double.isNaN(result));
                                                       assertFalse(Double.isInfinite(result));
                                                   }

 @Test
                                                   public void testEvaluate_WithNegativeMaxIterations() {
                                                       ContinuedFraction cf = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       double x = 2.0;
                                                       double epsilon = 0.0001;
                                                       
                                                       try {
                                                           cf.evaluate(x, epsilon, -1);
                                                           fail("Expected IllegalArgumentException");
                                                       } catch (IllegalArgumentException e) {
                                                           // Expected exception
                                                       }
                                                   }

 @Test
                                                   public void testEvaluate_WithDefaultParameters() {
                                                       // Create a test implementation of ContinuedFraction
                                                       ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return x;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       
                                                       double x = 2.0;
                                                       double result = continuedFraction.evaluate(x);
                                                       
                                                       // Since we're using the test implementation, we can calculate expected value
                                                       // For our simple test implementation, the continued fraction would be:
                                                       // x / (1 + x / (1 + x / (1 + ... )))
                                                       // For x=2, this converges to √3 - 1 ≈ 0.7320508075688772
                                                       double expected = Math.sqrt(3) - 1;
                                                       double testEpsilon = 1.0e-15; // Define our own epsilon for testing
                                                       assertEquals(expected, result, testEpsilon);
                                                   }

 @Test
                                                   public void testEvaluate_WithCustomEpsilon1() {
                                                       // Create a concrete implementation for testing
                                                       ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       
                                                       double x = 1.0;
                                                       double customEpsilon = 1e-15;
                                                       double result = continuedFraction.evaluate(x, customEpsilon);
                                                       
                                                       // For x=1, our test implementation converges to (√5 - 1)/2 ≈ 0.6180339887498949
                                                       double expected = (Math.sqrt(5) - 1)/2;
                                                       assertEquals(expected, result, customEpsilon);
                                                   }

 @Test
                                                   public void testEvaluate_WithMaxIterations() {
                                                       ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0; // Simple implementation for testing
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0; // Simple implementation for testing
                                                           }
                                                       };
                                                       
                                                       double x = 0.5;
                                                       int smallMaxIterations = 5;
                                                       double result = continuedFraction.evaluate(x, smallMaxIterations);
                                                       
                                                       // With only 5 iterations, the result should be less precise
                                                       // We'll just verify it's in a reasonable range
                                                       assertTrue(result > 0.3 && result < 0.4);
                                                   }

 @Test
                                                   public void testEvaluate_WithAllParameters1() {
                                                       ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return x;
                                                           }
                                                       };
                                                       
                                                       double x = 1.5;
                                                       double customEpsilon = 1e-12;
                                                       int maxIterations = 500;
                                                       double result = continuedFraction.evaluate(x, customEpsilon, maxIterations);
                                                       
                                                       // For x=1.5, our test implementation converges to (√13 - 3)/2 ≈ 0.3027756377319946
                                                       double expected = (Math.sqrt(13) - 3)/2;
                                                       assertEquals(expected, result, customEpsilon);
                                                   }

 @Test
                                                   public void testEvaluate_WithZeroX() {
                                                       // Create an anonymous implementation of ContinuedFraction for testing
                                                       ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0; // Sample a_n value
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return x; // b_n terms will be 0 when x=0
                                                           }
                                                       };
                                                       
                                                       double x = 0.0;
                                                       double result = continuedFraction.evaluate(x);
                                                       
                                                       // Use our own epsilon value since DEFAULT_EPSILON is private
                                                       double epsilon = 1.0e-15;
                                                       // For x=0, all b terms are 0, so the fraction should evaluate to 0
                                                       assertEquals(0.0, result, epsilon);
                                                   }

 @Test
                                                   public void testEvaluate_WithNegativeX() {
                                                       // Create a concrete implementation of ContinuedFraction for testing
                                                       ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       
                                                       double x = -1.0;
                                                       double result = continuedFraction.evaluate(x);
                                                       
                                                       // For x=-1, our test implementation converges to (√5 - 1)/2 ≈ 0.6180339887498949
                                                       // (same as x=1 because of x^2 in the terms)
                                                       double expected = (Math.sqrt(5) - 1)/2;
                                                       double epsilon = 1.0e-15; // Define our own epsilon for testing
                                                       assertEquals(expected, result, epsilon);
                                                   }

 @Test
                                                   public void testEvaluate_WithVerySmallEpsilon() {
                                                       // Create an anonymous implementation of ContinuedFraction for testing
                                                       ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       
                                                       double x = 1.0;
                                                       double verySmallEpsilon = 1e-20;
                                                       double result = continuedFraction.evaluate(x, verySmallEpsilon);
                                                       
                                                       double expected = (java.lang.Math.sqrt(5) - 1)/2;
                                                       assertEquals(expected, result, verySmallEpsilon);
                                                   }

 @Test
                                                   public void testEvaluate_WithInfiniteInput1() {
                                                       // Create a concrete instance of ContinuedFraction for testing
                                                       ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       
                                                       // Set up expected exception
                                                       org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                       thrown.expect(IllegalArgumentException.class);
                                                       
                                                       double x = Double.POSITIVE_INFINITY;
                                                       continuedFraction.evaluate(x);
                                                   }

 @Test
                                                   public void testEvaluate_WithZeroEpsilon() {
                                                       // Create a test implementation of the abstract ContinuedFraction class
                                                       ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       
                                                       // Setup expected exception
                                                       org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                       thrown.expect(IllegalArgumentException.class);
                                                       
                                                       double x = 1.0;
                                                       double zeroEpsilon = 0.0;
                                                       continuedFraction.evaluate(x, zeroEpsilon);
                                                   }

 @Test
                                                   public void testEvaluate_ConvergesWithinMaxIterations() {
                                                       // Create a test subclass that exposes the protected methods
                                                       class TestContinuedFraction extends ContinuedFraction {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return (n == 0) ? 1.0 : 1.0 / n;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       }
                                                       
                                                       // Use the test subclass instead of mocking
                                                       ContinuedFraction fraction = new TestContinuedFraction();
                                                       
                                                       double result = fraction.evaluate(2.0, 1e-10, 100);
                                                       
                                                       // Verify convergence happened before max iterations
                                                       assertTrue(result != 0.0);
                                                       assertFalse(Double.isNaN(result));
                                                       assertFalse(Double.isInfinite(result));
                                                   }

 @Test
                                                   public void testEvaluate_WithDefaultEpsilon() throws Exception {
                                                       // Create test subclass to expose protected methods
                                                       class TestContinuedFraction extends ContinuedFraction {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 0.5;
                                                           }
                                                       }
                                                       
                                                       // Get DEFAULT_EPSILON via reflection
                                                       Field field = ContinuedFraction.class.getDeclaredField("DEFAULT_EPSILON");
                                                       field.setAccessible(true);
                                                       double defaultEpsilon = field.getDouble(null);
                                                       
                                                       ContinuedFraction fraction = new TestContinuedFraction();
                                                       
                                                       double result = fraction.evaluate(1.0);
                                                       
                                                       // Verify it used the default epsilon
                                                       assertTrue(Precision.equals(result, 1.0 / (1.0 - 0.5), defaultEpsilon));
                                                   }

 @Test
                                                   public void testEvaluate_WithDefaultMaxIterations() {
                                                       // Create a test subclass that exposes the protected methods
                                                       class TestContinuedFraction extends ContinuedFraction {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 0.5;
                                                           }
                                                       }
                                                       
                                                       ContinuedFraction fraction = new TestContinuedFraction();
                                                       
                                                       double result = fraction.evaluate(1.0, 1e-10);
                                                       
                                                       // Should converge without hitting max iterations
                                                       assertTrue(result > 0);
                                                   }

 @Test
                                                   public void testEvaluate_WithDefaultEpsilon1() throws Exception {
                                                       // Create a simple implementation for testing
                                                       ContinuedFraction cf = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       
                                                       double x = 2.0;
                                                       
                                                       // Get the private DEFAULT_EPSILON value using reflection
                                                       Field field = ContinuedFraction.class.getDeclaredField("DEFAULT_EPSILON");
                                                       field.setAccessible(true);
                                                       double defaultEpsilon = field.getDouble(null);
                                                       
                                                       // Create spy and verify delegation
                                                       ContinuedFraction spyCf = spy(cf);
                                                       spyCf.evaluate(x);
                                                       
                                                       verify(spyCf).evaluate(x, defaultEpsilon, Integer.MAX_VALUE);
                                                   }

 @Test
                                                   public void testEvaluate_WithZeroEpsilon1() {
                                                       org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                       ContinuedFraction cf = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       double x = 2.0;
                                                       double epsilon = 0.0;
                                                       int maxIterations = 100;
                                                       
                                                       thrown.expect(IllegalArgumentException.class);
                                                       cf.evaluate(x, epsilon, maxIterations);
                                                   }

 @Test
                                                   public void testEvaluate_WithNegativeEpsilon1() {
                                                       ContinuedFraction cf = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       double x = 2.0;
                                                       double epsilon = -0.1;
                                                       
                                                       try {
                                                           cf.evaluate(x, epsilon, 100);
                                                           fail("Expected IllegalArgumentException for negative epsilon");
                                                       } catch (IllegalArgumentException e) {
                                                           // Expected exception
                                                       }
                                                   }

 @Test
                                                   public void testEvaluate_WithVeryLargeX() {
                                                       ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return x;
                                                           }
                                                       };
                                                       
                                                       double x = 1e6;
                                                       double result = continuedFraction.evaluate(x);
                                                       
                                                       // For very large x, the fraction should approach 1
                                                       // Using a reasonable epsilon value for comparison
                                                       double epsilon = 1e-15;
                                                       assertEquals(1.0, result, epsilon);
                                                   }

 @Test
                                                   public void testEvaluate_WithMaxIterationsTooSmall() {
                                                       ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return x;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       
                                                       double x = 1.0;
                                                       int verySmallMaxIterations = 1;
                                                       double result = continuedFraction.evaluate(x, verySmallMaxIterations);
                                                       
                                                       // With only 1 iteration, the result should be x/1 = x
                                                       // Using a small epsilon value for testing
                                                       double testEpsilon = 1e-15;
                                                       org.junit.Assert.assertEquals(x, result, testEpsilon);
                                                   }

 @Test
                                                   public void testEvaluate_WithNegativeMaxIterations1() {
                                                       // Create an anonymous implementation of ContinuedFraction
                                                       ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       
                                                       double x = 1.0;
                                                       int negativeMaxIterations = -1;
                                                       try {
                                                           continuedFraction.evaluate(x, negativeMaxIterations);
                                                           fail("Expected IllegalArgumentException");
                                                       } catch (IllegalArgumentException e) {
                                                           // Expected exception
                                                       }
                                                   }

 @Test
                                                   public void testEvaluate_WithZeroMaxIterations1() {
                                                       ContinuedFraction continuedFraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1.0;
                                                           }
                                                       };
                                                       
                                                       double x = 1.0;
                                                       int zeroMaxIterations = 0;
                                                       
                                                       org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                       thrown.expect(IllegalArgumentException.class);
                                                       continuedFraction.evaluate(x, zeroMaxIterations);
                                                   }

 @Test
                                                   public void testEvaluate_ReachesEpsilonQuickly() {
                                                       // Create a subclass that implements the protected methods
                                                       ContinuedFraction fraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 0.5;
                                                           }
                                                       };
                                                       
                                                       double epsilon = 1e-6;
                                                       double result = fraction.evaluate(1.0, epsilon, 1000);
                                                       
                                                       // Should converge in just a few iterations
                                                       double expected = 1.0 / (1.0 - 0.5);
                                                       assertEquals(expected, result, epsilon);
                                                   }

 @Test
                                                   public void testEvaluate_ThrowsNanDivergence() {
                                                       // Create a concrete subclass to expose protected methods
                                                       class TestContinuedFraction extends ContinuedFraction {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 0.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 0.0;
                                                           }
                                                       }
                                                       
                                                       // Setup expected exception
                                                       ExpectedException thrown = ExpectedException.none();
                                                       thrown.expect(ConvergenceException.class);
                                                       thrown.expectMessage("CONTINUED_FRACTION_NAN_DIVERGENCE");
                                                       
                                                       // Use the concrete subclass directly
                                                       ContinuedFraction fraction = new TestContinuedFraction();
                                                       fraction.evaluate(1.0, 1e-10, 100);
                                                   }

 @Test
                                                   public void testEvaluate_HandlesSmallValues() {
                                                       // Create a concrete subclass with our test values instead of mocking
                                                       ContinuedFraction fraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               return 1e-100; // very small value for testing
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               return 1e-100; // very small value for testing
                                                           }
                                                       };
                                                       
                                                       double result = fraction.evaluate(1.0, 1e-10, 100);
                                                       
                                                       assertFalse(Double.isNaN(result));
                                                       assertFalse(Double.isInfinite(result));
                                                   }

 @Test
                                                   public void testEvaluateWithPreciseCalculation() {
                                                       // Create a concrete subclass of ContinuedFraction for testing
                                                       ContinuedFraction fraction = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               // Simple pattern for testing precision
                                                               return 1.0;
                                                           }
                                                           
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               // Simple pattern for testing precision
                                                               return 1.0;
                                                           }
                                                       };
                                                       
                                                       // Test with a value that would show precision differences
                                                       double x = 0.000001;
                                                       
                                                       // The original implementation with small=1e-50 would be more precise
                                                       // The mutant with small=1e-30 would be less precise
                                                       // We expect at least 10 decimal places of precision with original
                                                       double result = fraction.evaluate(x);
                                                       
                                                       // Calculate expected value (approximation of this continued fraction)
                                                       // For this simple pattern, the continued fraction converges to (sqrt(5)-1)/2
                                                       double expected = (Math.sqrt(5) - 1) / 2;
                                                       
                                                       // Assert with delta that would catch the mutant (1e-40 is between 1e-30 and 1e-50)
                                                       assertEquals(expected, result, 1e-40);
                                                       
                                                       // Additional assertion to verify we're getting meaningful precision
                                                       assertNotEquals(expected, result, 1e-60);
                                                   }

 @Test
                                                   public void testEvaluateWithPrecisionSensitiveInput() {
                                                       // Create a concrete subclass of ContinuedFraction for testing
                                                       ContinuedFraction cf = new ContinuedFraction() {
                                                           @Override
                                                           protected double getA(int n, double x) {
                                                               // Simple pattern where a_n = 1 for all n
                                                               return 1.0;
                                                           }
                                                       
                                                           @Override
                                                           protected double getB(int n, double x) {
                                                               // Simple pattern where b_n = 1 for all n
                                                               return 1.0;
                                                           }
                                                       };
                                                   
                                                       // For this simple continued fraction [1;1,1,1,...], the exact value is (1+√5)/2 ≈ 1.618033988749895
                                                       double expected = (1 + Math.sqrt(5)) / 2;
                                                       
                                                       // With the original small=1e-50, the result should be very close to exact value
                                                       // With the mutant small=1e-30, the result might be less precise
                                                       double result = cf.evaluate(1.0); // x value doesn't matter for this simple fraction
                                                       
                                                       // Check that the result is very close to expected value
                                                       // The delta here is much larger than 1e-30 but smaller than 1e-15
                                                       // to detect if the mutant made the result significantly less precise
                                                       assertEquals(expected, result, 1e-15);
                                                       
                                                       // Also verify that the result is not exactly equal (since it's an infinite fraction)
                                                       // This ensures we're actually testing the precision
                                                       assertNotEquals(expected, result);
                                                   }

 @Test
                                               public void testEvaluate_SingleParameter() {
                                                   // Define DEFAULT_EPSILON if not available from class
                                                   final double DEFAULT_EPSILON = 1.0e-5;
                                                   
                                                   // Create a mock implementation of ContinuedFraction since it's abstract
                                                   ContinuedFraction fraction = spy(new ContinuedFraction() {
                                                       @Override
                                                       protected double getA(int n, double x) {
                                                           return 1.0;
                                                       }
                                                   
                                                       @Override
                                                       protected double getB(int n, double x) {
                                                           return 1.0;
                                                       }
                                                   
                                                       @Override
                                                       public double evaluate(double x, double epsilon, int maxIterations) {
                                                           // Mock the behavior of the actual implementation
                                                           return x * 2; // Simple test behavior
                                                       }
                                                   });
                                                
                                                   // Test typical value
                                                   double result = fraction.evaluate(5.0);
                                                   assertEquals(10.0, result, 0.0001);
                                                   
                                                   // Test zero
                                                   result = fraction.evaluate(0.0);
                                                   assertEquals(0.0, result, 0.0001);
                                                   
                                                   // Test negative value
                                                   result = fraction.evaluate(-3.5);
                                                   assertEquals(-7.0, result, 0.0001);
                                                   
                                                   // Verify the method delegates to the 3-parameter version with correct defaults
                                                   verify(fraction, times(3)).evaluate(anyDouble(), 
                                                       eq(DEFAULT_EPSILON), 
                                                       eq(Integer.MAX_VALUE));
                                               }

 @Test
                                           public void testEvaluate_ThrowsMaxCountExceeded() throws Exception {
                                               ContinuedFraction fraction = spy(ContinuedFraction.class);
                                               
                                               // Use reflection to access protected methods
                                               Method getAMethod = ContinuedFraction.class.getDeclaredMethod("getA", int.class, double.class);
                                               getAMethod.setAccessible(true);
                                               Method getBMethod = ContinuedFraction.class.getDeclaredMethod("getB", int.class, double.class);
                                               getBMethod.setAccessible(true);
                                               
                                               // Setup values that will never converge
                                               when(getAMethod.invoke(fraction, anyInt(), anyDouble())).thenReturn(1.0);
                                               when(getBMethod.invoke(fraction, anyInt(), anyDouble())).thenReturn(1.0);
                                               
                                               int maxIterations = 10;
                                               try {
                                                   fraction.evaluate(0.5, 1e-10, maxIterations);
                                                   fail("Expected MaxCountExceededException");
                                               } catch (MaxCountExceededException e) {
                                                   assertEquals("NON_CONVERGENT_CONTINUED_FRACTION", e.getMessage());
                                               }
                                           }

 @Test
                                           public void testEvaluate_ThrowsInfinityDivergence() {
                                               // Create test subclass to expose protected methods
                                               class TestContinuedFraction extends ContinuedFraction {
                                                   @Override
                                                   protected double getA(int n, double x) {
                                                       return 1.0;
                                                   }
                                                   
                                                   @Override
                                                   protected double getB(int n, double x) {
                                                       return 1.0;
                                                   }
                                               }
                                               
                                               ContinuedFraction fraction = new TestContinuedFraction();
                                               
                                               try {
                                                   fraction.evaluate(1.0, 1e-10, 100);
                                                   fail("Expected ConvergenceException");
                                               } catch (ConvergenceException e) {
                                                   assertEquals("Continued fraction diverged to infinity.", e.getMessage());
                                               }
                                           }

 @Test
                                       public void testEvaluate_WithMaxIterations1() {
                                           // Define a simple test implementation of ContinuedFraction
                                           class TestContinuedFraction extends ContinuedFraction {
                                               @Override
                                               protected double getA(int n, double x) {
                                                   return 1.0;
                                               }
                                               
                                               @Override
                                               protected double getB(int n, double x) {
                                                   return 1.0;
                                               }
                                           }
                                           
                                           ContinuedFraction cf = new TestContinuedFraction();
                                           double x = 2.0;
                                           int maxIterations = 100;
                                           
                                           // Create spy using Mockito
                                           ContinuedFraction spyCf = spy(cf);
                                           
                                           // Get default epsilon through reflection since it's private
                                           double defaultEpsilon = 0.0;
                                           try {
                                               java.lang.reflect.Field field = ContinuedFraction.class.getDeclaredField("DEFAULT_EPSILON");
                                               field.setAccessible(true);
                                               defaultEpsilon = field.getDouble(null);
                                           } catch (Exception e) {
                                               fail("Failed to access DEFAULT_EPSILON via reflection");
                                           }
                                           
                                           // Call the method
                                           spyCf.evaluate(x, maxIterations);
                                           
                                           // Verify the internal call
                                           verify(spyCf).evaluate(x, defaultEpsilon, maxIterations);
                                       }

 @Test
                                   public void testEvaluateDetectsFirstTermMutation() {
                                       // Create an anonymous subclass of ContinuedFraction where we control getA behavior
                                       ContinuedFraction fraction = new ContinuedFraction() {
                                           @Override
                                           protected double getA(int n, double x) {
                                               // Return distinct values for n=0 and n=1 to detect which one is used
                                               return n == 0 ? 1.0 : 2.0;
                                           }
                                           
                                           @Override
                                           protected double getB(int n, double x) {
                                               // Keep B simple for this test
                                               return 1.0;
                                           }
                                       };
                                       
                                       // The original implementation should use getA(0,x) which returns 1.0
                                       // The mutant uses getA(1,x) which returns 2.0
                                       // Since continued fractions are sensitive to initial terms, this should produce different results
                                       double result = fraction.evaluate(1.0);
                                       
                                       // If the mutant is present, result would be calculated with 2.0 instead of 1.0 as first term
                                       // We know with first term=1.0 and others=1.0, the continued fraction converges to ~1.618 (golden ratio)
                                       // With first term=2.0, it would converge to a different value
                                       assertEquals(1.618, result, 0.01); // Allowing some tolerance for convergence
                                   }

 @Test
                                   public void testEvaluateInitialValueDifference() throws Exception {
                                       // Create a mock ContinuedFraction where getA returns different values for n=0 and n=1
                                       ContinuedFraction cf = new ContinuedFraction() {
                                           @Override
                                           protected double getA(int n, double x) {
                                               return n == 0 ? 1.0 : 2.0; // Different values for n=0 and n=1
                                           }
                                           
                                           @Override
                                           protected double getB(int n, double x) {
                                               return 1.0; // Simple value for testing
                                           }
                                       };
                                       
                                       double x = 1.0;
                                       double epsilon = 1e-10;
                                       int maxIterations = 100;
                                       
                                       // Get the original result
                                       double originalResult = cf.evaluate(x, epsilon, maxIterations);
                                       
                                       // Now test with the mutated version (getA(1,x) instead of getA(0,x))
                                       ContinuedFraction mutatedCf = new ContinuedFraction() {
                                           @Override
                                           protected double getA(int n, double x) {
                                               return n == 0 ? 1.0 : 2.0;
                                           }
                                           
                                           @Override
                                           protected double getB(int n, double x) {
                                               return 1.0;
                                           }
                                           
                                           @Override
                                           public double evaluate(double x, double epsilon, int maxIterations) {
                                               // This is the mutated version
                                               final double small = 1e-50;
                                               double hPrev = getA(1, x); // Mutated line
                                               
                                               if (Precision.equals(hPrev, 0.0, small)) {
                                                   hPrev = small;
                                               }
                                               
                                               // Rest of the original implementation...
                                               int n = 1;
                                               double dPrev = 0.0;
                                               double cPrev = hPrev;
                                               double hN = hPrev;
                                   
                                               while (n < maxIterations) {
                                                   final double a = getA(n, x);
                                                   final double b = getB(n, x);
                                   
                                                   double dN = a + b * dPrev;
                                                   if (Precision.equals(dN, 0.0, small)) {
                                                       dN = small;
                                                   }
                                                   double cN = a + b / cPrev;
                                                   if (Precision.equals(cN, 0.0, small)) {
                                                       cN = small;
                                                   }
                                   
                                                   dN = 1 / dN;
                                                   final double deltaN = cN * dN;
                                                   hN = hPrev * deltaN;
                                   
                                                   if (Double.isInfinite(hN)) {
                                                       throw new ConvergenceException(LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE,
                                                                                  x);
                                                   }
                                                   if (Double.isNaN(hN)) {
                                                       throw new ConvergenceException(LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE,
                                                                                  x);
                                                   }
                                   
                                                   if (FastMath.abs(deltaN - 1.0) < epsilon) {
                                                       break;
                                                   }
                                   
                                                   dPrev = dN;
                                                   cPrev = cN;
                                                   hPrev = hN;
                                                   n++;
                                               }
                                   
                                               if (n >= maxIterations) {
                                                   throw new MaxCountExceededException(LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION,
                                                                                   maxIterations, x);
                                               }
                                   
                                               return hN;
                                           }
                                       };
                                       
                                       double mutatedResult = mutatedCf.evaluate(x, epsilon, maxIterations);
                                       
                                       // The results should be different because the initial value changed
                                       assertNotEquals("Results should differ when initial getA call changes from n=0 to n=1", 
                                                      originalResult, mutatedResult, 1e-10);
                                   }

 @Test
                                  public void testEvaluateInitialTerm() {
                                      // Create a test subclass to expose protected methods
                                      class TestContinuedFraction extends ContinuedFraction {
                                          @Override
                                          protected double getA(int n, double x) {
                                              return 0; // Will be mocked anyway
                                          }
                                          
                                          @Override
                                          protected double getB(int n, double x) {
                                              return 0; // Will be mocked anyway
                                          }
                                      }
                                      
                                      // Create a mock of our test subclass
                                      TestContinuedFraction cf = mock(TestContinuedFraction.class);
                                      
                                      // Define our own epsilon since DEFAULT_EPSILON is private
                                      final double epsilon = 1e-8;
                                      
                                      // Setup mock behavior
                                      when(cf.getA(0, 1.0)).thenReturn(2.0);  // First term
                                      when(cf.getA(1, 1.0)).thenReturn(3.0);  // Second term
                                      when(cf.getB(anyInt(), eq(1.0))).thenReturn(1.0);  // All b terms are 1
                                      
                                      // Setup the evaluate method to call our implementation
                                      when(cf.evaluate(1.0, epsilon, Integer.MAX_VALUE))
                                          .thenCallRealMethod();
                                      
                                      // Call the method
                                      double result = cf.evaluate(1.0);
                                      
                                      // Verify the first term was called with n=0 (would fail for mutant)
                                      verify(cf).getA(0, 1.0);
                                      
                                      // Also verify the result is correct (optional, but good practice)
                                      assertNotEquals(0.0, result, 0.0001);
                                  }

 @Test
                                  public void testEvaluateDetectsInitialCoefficientMutation() {
                                      // Create a test subclass that exposes protected methods
                                      class TestContinuedFraction extends ContinuedFraction {
                                          @Override
                                          public double getA(int n, double x) {
                                              return 0; // Will be mocked anyway
                                          }
                                          
                                          @Override
                                          public double getB(int n, double x) {
                                              return 0; // Will be mocked anyway
                                          }
                                          
                                          @Override
                                          public double evaluate(double x, int maxIterations) {
                                              return super.evaluate(x, maxIterations);
                                          }
                                      }
                                      
                                      // Create a mock of our test subclass
                                      TestContinuedFraction cf = mock(TestContinuedFraction.class);
                                      
                                      // Setup different values for getA(0,x) and getA(1,x)
                                      when(cf.getA(0, anyDouble())).thenReturn(1.0);
                                      when(cf.getA(1, anyDouble())).thenReturn(2.0);
                                      
                                      // Setup other coefficients to be the same so the difference comes only from initial coefficient
                                      when(cf.getA(anyInt(), anyDouble())).thenReturn(1.0);
                                      when(cf.getB(anyInt(), anyDouble())).thenReturn(1.0);
                                      
                                      // Setup the evaluate method to call the real logic (simplified for test)
                                      when(cf.evaluate(anyDouble(), anyInt())).thenCallRealMethod();
                                      
                                      try {
                                          // Call the method
                                          double result = cf.evaluate(1.0, 100);
                                          
                                          // The mutant would produce a different result because it starts with getA(1,x) = 2.0
                                          // instead of getA(0,x) = 1.0
                                          // We expect the original to produce a different value than the mutant
                                          // Since we can't know the exact expected value (as it's a mock),
                                          // we'll verify the getA calls
                                          verify(cf).getA(0, 1.0); // This verifies original behavior
                                          verify(cf, never()).getA(1, 1.0); // This would fail for the mutant
                                          
                                      } catch (Exception e) {
                                          fail("Exception should not be thrown");
                                      }
                                  }

 @Test
                              public void testEvaluateDetectsGetBMutation() {
                                  // Create a test implementation of ContinuedFraction
                                  ContinuedFraction fraction = new ContinuedFraction() {
                                      @Override
                                      protected double getA(int n, double x) {
                                          // Simple implementation where A is always 1
                                          return 1.0;
                                      }
                              
                                      @Override
                                      protected double getB(int n, double x) {
                                          // Make B values different for n and n+1 to detect the mutation
                                          return n == 1 ? 2.0 : 3.0; // B(1,x) = 2.0, B(2,x) = 3.0 etc.
                                      }
                                  };
                              
                                  // Calculate expected value manually based on the correct implementation
                                  // For a simple continued fraction with these coefficients:
                                  // b0 + a1/(b1 + a2/(b2 + ...))
                                  // With our implementation, first few terms would be:
                                  // 2.0 + 1.0/(3.0 + 1.0/(3.0 + ...))
                                  // For max iterations = 1: 2.0
                                  // For max iterations = 2: 2.0 + 1.0/3.0 ≈ 2.333...
                                  double expected = 2.0 + (1.0 / 3.0); // Result after 2 iterations
                                  
                                  // The mutant would use getB(n+1,x) which would give:
                                  // First term: getB(0+1,x) = 2.0 (correct)
                                  // Second term: getB(1+1,x) = 3.0 (should be getB(1,x) = 2.0)
                                  // So mutant would calculate: 3.0 + 1.0/(3.0 + ...) for second term
                                  // Which would give wrong result
                                  
                                  // Test with small max iterations to make the difference obvious
                                  double actual = fraction.evaluate(0.0, 1e-10, 2);
                                  
                                  // Assert the correct value
                                  assertEquals(expected, actual, 1e-10);
                                  
                                  // Note: This test will fail if the mutant is present because:
                                  // Original: uses getB(1,x) = 2.0 for second term
                                  // Mutant: uses getB(2,x) = 3.0 for second term
                                  // So the assertion will catch the difference
                              }

 @Test
                         public void testEvaluateGetBCallSequence() {
                             // Track the n values used in getB() calls
                             final List<Integer> bCallValues = new ArrayList<Integer>();
                             
                             // Create a test implementation of ContinuedFraction
                             ContinuedFraction fraction = new ContinuedFraction() {
                                 @Override
                                 protected double getA(int n, double x) {
                                     return 1.0; // Simple constant for testing
                                 }
                                 
                                 @Override
                                 protected double getB(int n, double x) {
                                     bCallValues.add(n); // Track the n values used
                                     return 1.0; // Simple constant for testing
                                 }
                             };
                             
                             // Call the evaluate method with test parameters
                             double x = 1.0;
                             double epsilon = 1e-6;
                             int maxIterations = 10;
                             fraction.evaluate(x, epsilon, maxIterations);
                             
                             // Verify the sequence of n values passed to getB()
                             List<Integer> expectedSequence = new ArrayList<Integer>();
                             expectedSequence.add(1);
                             expectedSequence.add(2);
                             expectedSequence.add(3);
                             expectedSequence.add(4);
                             expectedSequence.add(5);
                             
                             int compareLength = Math.min(5, bCallValues.size());
                             List<Integer> actualSequence = bCallValues.subList(0, compareLength);
                             
                             // The mutant would produce sequence starting with 2 instead of 1
                             assertEquals("getB() should be called with sequential n values starting from 1", 
                                          expectedSequence, 
                                          actualSequence);
                         }

 @Test
         public void testEvaluateDetectsGetBMutation1() {
             // Create a final array to track the lastBIndex
             final int[] lastBIndex = {-1};
             
             // Create a concrete subclass of ContinuedFraction for testing
             org.apache.commons.math3.util.ContinuedFraction fraction = new org.apache.commons.math3.util.ContinuedFraction() {
                 @Override
                 protected double getA(int n, double x) {
                     return 1.0; // Simple constant for testing
                 }
                 
                 @Override
                 protected double getB(int n, double x) {
                     // Record the n value used
                     lastBIndex[0] = n;
                     return n; // Return n as the value to make the effect noticeable
                 }
             };
             
             double x = 1.0;
             double epsilon = 1e-6;
             
             // First call should use n=1 (first term)
             fraction.evaluate(x, epsilon);
             org.junit.Assert.assertEquals("First term should use n=1", 1, lastBIndex[0]);
             
             // Reset for next test
             lastBIndex[0] = -1;
             
             // Verify that subsequent calls maintain correct behavior
             fraction.evaluate(x, epsilon);
             org.junit.Assert.assertEquals("Subsequent calls should still use n=1", 1, lastBIndex[0]);
         }

 @Test
     public void testEvaluateDetectsGetBMutation2() {
         // Create a concrete subclass of ContinuedFraction for testing
         org.apache.commons.math3.util.ContinuedFraction fraction = new org.apache.commons.math3.util.ContinuedFraction() {
             private int lastBIndex = -1;
             
             @Override
             protected double getA(int n, double x) {
                 return 1.0; // Simple constant for testing
             }
             
             @Override
             protected double getB(int n, double x) {
                 // Record the n value used
                 lastBIndex = n;
                 return n; // Return n as the value to make the effect noticeable
             }
             
             public int getLastBIndex() {
                 return lastBIndex;
             }
         };
         
         double x = 1.0;
         double epsilon = 1e-6;
         
         // First call should use n=1 (first term)
         fraction.evaluate(x, epsilon);
         try {
             java.lang.reflect.Method getLastBIndex = fraction.getClass().getMethod("getLastBIndex");
             int lastIndex = (Integer)getLastBIndex.invoke(fraction);
             org.junit.Assert.assertEquals("First term should use n=1", 1, lastIndex);
             
             // Verify that subsequent calls maintain correct behavior
             fraction.evaluate(x, epsilon);
             lastIndex = (Integer)getLastBIndex.invoke(fraction);
             org.junit.Assert.assertEquals("Subsequent calls should still use n=1", 1, lastIndex);
         } catch (Exception e) {
             org.junit.Assert.fail("Reflection failed: " + e.getMessage());
         }
     }

 @Test
 public void testEvaluate_DetectsInfiniteValue() {
     // Create a mock ContinuedFraction that will produce infinite hN
     ContinuedFraction cf = new ContinuedFraction() {
         private int callCount = 0;
         
         @Override
         protected double getA(int n, double x) {
             // Return values that will make hN infinite
             return callCount++ == 0 ? 1.0 : Double.MAX_VALUE;
         }
         
         @Override
         protected double getB(int n, double x) {
             // Return values that will make hN infinite
             return callCount == 1 ? 1.0 : 1.0;
         }
     };
     
     // The original implementation should detect the infinite value and handle it
     // The mutant would continue processing with the infinite value
     double result = cf.evaluate(1.0);
     
     // Verify the result is finite (original behavior)
     // The mutant would likely return infinity or incorrect value
     assertFalse("Result should be finite", Double.isInfinite(result));
     assertFalse("Result should not be NaN", Double.isNaN(result));
     
     // Additional check that the value is reasonable
     assertTrue("Result should be within expected range", 
                Math.abs(result) < Double.MAX_VALUE);
 }

 @Test
 public void testEvaluateWithInfinitePartialResult() {
     // Create a mock ContinuedFraction that will return values leading to infinite hN
     ContinuedFraction cf = new ContinuedFraction() {
         private int callCount = 0;
         
         @Override
         protected double getA(int n, double x) {
             return 1.0;
         }
         
         @Override
         protected double getB(int n, double x) {
             callCount++;
             // Return values that will make hN infinite on second iteration
             if (callCount == 1) return 1.0;
             if (callCount == 2) return Double.MAX_VALUE;
             return 1.0;
         }
     };
     
     double x = 1.0;
     double epsilon = 1e-6;
     int maxIterations = 100;
     
     // The original implementation should handle the infinite case gracefully
     // The mutant will continue computation despite the infinite value
     double result = cf.evaluate(x, epsilon, maxIterations);
     
     // Verify the result is either finite (original handles infinite case) 
     // or NaN/Infinity (but properly handled)
     assertFalse("Result should be finite when infinite partial result is detected",
                Double.isInfinite(result));
     assertFalse("Result should not be NaN when infinite partial result is detected",
                Double.isNaN(result));
     
     // Alternatively, if the original implementation throws an exception for infinite case:
     // (uncomment if that's the expected behavior)
     // try {
     //     cf.evaluate(x, epsilon, maxIterations);
     //     fail("Expected exception for infinite partial result");
     // } catch (ArithmeticException e) {
     //     // Expected behavior
     // }
 }

 @Test
 public void testEvaluate_DetectsInfiniteIntermediateValue() {
     // Create a test instance of ContinuedFraction (anonymous class for testing)
     ContinuedFraction fraction = new ContinuedFraction() {
         private int callCount = 0;
         
         @Override
         protected double getA(int n, double x) {
             // Return values that will eventually make hN infinite
             return 1.0;
         }
         
         @Override
         protected double getB(int n, double x) {
             // First call returns normal value, subsequent calls return very large values
             // to force hN to become infinite
             if (callCount++ < 1) {
                 return 1.0;
             } else {
                 return Double.MAX_VALUE;
             }
         }
     };
     
     // Test with input that should trigger infinite hN
     double result = fraction.evaluate(1.0);
     
     // Verify the result is finite (original would handle the infinity case)
     // The exact expected value depends on implementation, but key point is it shouldn't be infinite
     assertFalse("Result should be finite", Double.isInfinite(result));
     
     // Alternative check: could also verify the result equals some expected handling of infinity case
     // This depends on how the original implementation handles infinite hN
 }

 @Test(expected = ConvergenceException.class)
 public void testEvaluate_ShouldThrowConvergenceException_WhenResultBecomesInfinite() {
     // Setup test data that will cause infinite value
     ContinuedFraction fraction = new ContinuedFraction() {
         @Override
         protected double getA(int n, double x) {
             // Return values that will lead to infinite hN
             return (n == 0) ? 1.0 : Double.MAX_VALUE;
         }
         
         @Override
         protected double getB(int n, double x) {
             // Return values that will lead to infinite hN
             return (n == 0) ? 0.0 : Double.MAX_VALUE;
         }
     };
     
     // Call evaluate with parameters that will trigger the infinite case
     // Using small epsilon and sufficient maxIterations to ensure we reach the infinite case
     fraction.evaluate(1.0, 1e-10, 100);
     
     // If we get here, the test fails because no exception was thrown
     // The expected exception annotation will verify the correct exception is thrown
 }

}
