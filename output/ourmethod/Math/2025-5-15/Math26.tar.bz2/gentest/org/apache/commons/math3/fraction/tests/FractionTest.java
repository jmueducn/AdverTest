package gentest.org.apache.commons.math3.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.fraction.*;
import java.io.Serializable;
import java.math.BigInteger;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
 
public class FractionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                             public void testConstructor_ZeroValue() {
                                                 Fraction fraction = new Fraction(0.0);
                                                 assertEquals(0, fraction.getNumerator());
                                                 assertEquals(1, fraction.getDenominator());
                                                 assertEquals(Fraction.ZERO, fraction);
                                             }

    @Test
                                             public void testConstructor_IntegerValue() {
                                                 Fraction fraction = new Fraction(5.0);
                                                 assertEquals(5, fraction.getNumerator());
                                                 assertEquals(1, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructor_SimpleFraction() {
                                                 Fraction fraction = new Fraction(0.5);
                                                 assertEquals(1, fraction.getNumerator());
                                                 assertEquals(2, fraction.getDenominator());
                                                 assertEquals(Fraction.ONE_HALF, fraction);
                                             }

    @Test
                                             public void testConstructor_RecurringDecimal() {
                                                 Fraction fraction = new Fraction(0.3333333333);
                                                 assertEquals(1, fraction.getNumerator());
                                                 assertEquals(3, fraction.getDenominator());
                                                 assertEquals(Fraction.ONE_THIRD, fraction);
                                             }

    @Test
                                             public void testConstructor_NegativeValue() {
                                                 Fraction fraction = new Fraction(-0.75);
                                                 assertEquals(-3, fraction.getNumerator());
                                                 assertEquals(4, fraction.getDenominator());
                                                 assertEquals(Fraction.THREE_QUARTERS.negate(), fraction);
                                             }

    @Test
                                             public void testConstructor_CommonFractions() {
                                                 Fraction oneThird = new Fraction(1.0/3.0);
                                                 assertEquals(Fraction.ONE_THIRD, oneThird);
                                                 
                                                 Fraction twoThirds = new Fraction(2.0/3.0);
                                                 assertEquals(Fraction.TWO_THIRDS, twoThirds);
                                                 
                                                 Fraction threeQuarters = new Fraction(3.0/4.0);
                                                 assertEquals(Fraction.THREE_QUARTERS, threeQuarters);
                                             }

    @Test
                                             public void testConstructor_PrecisionHandling() {
                                                 // Test with value very close to 0.2 (1/5)
                                                 Fraction fraction = new Fraction(0.2000000001);
                                                 assertEquals(1, fraction.getNumerator());
                                                 assertEquals(5, fraction.getDenominator());
                                                 assertEquals(Fraction.ONE_FIFTH, fraction);
                                             }

    @Test
                                             public void testConstructor_EdgeCaseVerySmallValue() {
                                                 Fraction fraction = new Fraction(1.0e-6);
                                                 // Should be 1/1000000 or similar very small fraction
                                                 assertTrue(Math.abs(fraction.doubleValue() - 1.0e-6) < 1.0e-8);
                                             }

    @Test
                                             public void testConstructor_EdgeCaseVeryLargeValue() {
                                                 Fraction fraction = new Fraction(1.0e6);
                                                 assertEquals(1000000, fraction.getNumerator());
                                                 assertEquals(1, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructor_NaNValue() {
                                                 thrown.expect(IllegalArgumentException.class);
                                                 new Fraction(Double.NaN);
                                             }

    @Test
                                             public void testConstructor_PositiveInfinity() {
                                                 thrown.expect(IllegalArgumentException.class);
                                                 new Fraction(Double.POSITIVE_INFINITY);
                                             }

    @Test
                                             public void testConstructor_NegativeInfinity() {
                                                 thrown.expect(IllegalArgumentException.class);
                                                 new Fraction(Double.NEGATIVE_INFINITY);
                                             }

    @Test
                                             public void testConstructor_VerifyReducedForm() {
                                                 // 0.6 should be reduced to 3/5, not 6/10
                                                 Fraction fraction = new Fraction(0.6);
                                                 assertEquals(3, fraction.getNumerator());
                                                 assertEquals(5, fraction.getDenominator());
                                                 assertEquals(Fraction.THREE_FIFTHS, fraction);
                                             }

    @Test
                                             public void testConstructor_VerifyDoubleValueAccuracy() {
                                                 double testValue = 0.123456789;
                                                 Fraction fraction = new Fraction(testValue);
                                                 assertTrue(Math.abs(fraction.doubleValue() - testValue) < 1.0e-5);
                                             }

    @Test
                                             public void testConstructor_ExactValues() {
                                                 // Test exact fractions that can be represented precisely
                                                 Fraction half = new Fraction(0.5, 0.000001, 100);
                                                 assertEquals(1, half.getNumerator());
                                                 assertEquals(2, half.getDenominator());
                                         
                                                 Fraction third = new Fraction(1.0/3.0, 0.000001, 100);
                                                 assertEquals(1, third.getNumerator());
                                                 assertEquals(3, third.getDenominator());
                                         
                                                 Fraction quarter = new Fraction(0.25, 0.000001, 100);
                                                 assertEquals(1, quarter.getNumerator());
                                                 assertEquals(4, quarter.getDenominator());
                                             }

    @Test
                                             public void testConstructor_ApproximateValues() {
                                                 // Test values that need approximation
                                                 Fraction piApprox = new Fraction(3.1415926535, 0.0001, 1000);
                                                 assertEquals(355, piApprox.getNumerator());
                                                 assertEquals(113, piApprox.getDenominator());
                                         
                                                 Fraction eApprox = new Fraction(2.718281828, 0.0001, 1000);
                                                 assertEquals(193, eApprox.getNumerator());
                                                 assertEquals(71, eApprox.getDenominator());
                                             }

    @Test
                                             public void testConstructor_EdgeCases() {
                                                 // Test zero
                                                 Fraction zero = new Fraction(0.0, 0.000001, 100);
                                                 assertEquals(0, zero.getNumerator());
                                                 assertEquals(1, zero.getDenominator());
                                         
                                                 // Test one
                                                 Fraction one = new Fraction(1.0, 0.000001, 100);
                                                 assertEquals(1, one.getNumerator());
                                                 assertEquals(1, one.getDenominator());
                                         
                                                 // Test negative value
                                                 Fraction negative = new Fraction(-0.5, 0.000001, 100);
                                                 assertEquals(-1, negative.getNumerator());
                                                 assertEquals(2, negative.getDenominator());
                                             }

    @Test
                                             public void testConstructor_WithDifferentEpsilon() {
                                                 // Test with different epsilon values
                                                 Fraction tightEpsilon = new Fraction(0.333333, 0.000001, 100);
                                                 assertEquals(1, tightEpsilon.getNumerator());
                                                 assertEquals(3, tightEpsilon.getDenominator());
                                         
                                                 Fraction looseEpsilon = new Fraction(0.333333, 0.1, 100);
                                                 // With loose epsilon, we might get a different approximation
                                                 assertEquals(1, looseEpsilon.getNumerator());
                                                 assertEquals(3, looseEpsilon.getDenominator());
                                             }

    @Test
                                             public void testConstructor_WithMaxIterations() {
                                                 // Test that maxIterations limits the approximation attempts
                                                 // This might throw an exception if maxIterations is too small
                                                 try {
                                                     new Fraction(Math.PI, 0.0000000001, 5);
                                                 } catch (Exception e) {
                                                     assertTrue(e instanceof ArithmeticException);
                                                 }
                                             }

    @Test
                                             public void testConstructor_InvalidMaxIterations() {
                                                 thrown.expect(IllegalArgumentException.class);
                                                 new Fraction(0.5, 0.000001, 0); // maxIterations must be >= 1
                                             }

    @Test
                                             public void testConstructor_InvalidEpsilon() {
                                                 thrown.expect(IllegalArgumentException.class);
                                                 new Fraction(0.5, -0.000001, 100); // epsilon must be positive
                                             }

    @Test
                                             public void testConstructor_Infinity() {
                                                 thrown.expect(IllegalArgumentException.class);
                                                 new Fraction(Double.POSITIVE_INFINITY, 0.000001, 100);
                                             }

    @Test
                                             public void testConstructor_NaN() {
                                                 thrown.expect(IllegalArgumentException.class);
                                                 new Fraction(Double.NaN, 0.000001, 100);
                                             }

    @Test
                                             public void testConstructor_CompareWithStaticConstants() {
                                                 // Test that constructor produces same results as static constants
                                                 Fraction half = new Fraction(0.5, 0.000001, 100);
                                                 assertEquals(Fraction.ONE_HALF.getNumerator(), half.getNumerator());
                                                 assertEquals(Fraction.ONE_HALF.getDenominator(), half.getDenominator());
                                         
                                                 Fraction third = new Fraction(1.0/3.0, 0.000001, 100);
                                                 assertEquals(Fraction.ONE_THIRD.getNumerator(), third.getNumerator());
                                                 assertEquals(Fraction.ONE_THIRD.getDenominator(), third.getDenominator());
                                             }

    @Test
                                             public void testConstructor_SimpleFractions() {
                                                 // Test simple fractions that can be exactly represented
                                                 Fraction half = new Fraction(0.5, 100);
                                                 assertEquals(1, half.getNumerator());
                                                 assertEquals(2, half.getDenominator());
                                         
                                                 Fraction third = new Fraction(1.0/3, 100);
                                                 assertEquals(1, third.getNumerator());
                                                 assertEquals(3, third.getDenominator());
                                         
                                                 Fraction twoThirds = new Fraction(2.0/3, 100);
                                                 assertEquals(2, twoThirds.getNumerator());
                                                 assertEquals(3, twoThirds.getDenominator());
                                             }

    @Test
                                             public void testConstructor_WholeNumbers() {
                                                 // Test whole numbers
                                                 Fraction five = new Fraction(5.0, 100);
                                                 assertEquals(5, five.getNumerator());
                                                 assertEquals(1, five.getDenominator());
                                         
                                                 Fraction zero = new Fraction(0.0, 100);
                                                 assertEquals(0, zero.getNumerator());
                                                 assertEquals(1, zero.getDenominator());
                                         
                                                 Fraction negativeTwo = new Fraction(-2.0, 100);
                                                 assertEquals(-2, negativeTwo.getNumerator());
                                                 assertEquals(1, negativeTwo.getDenominator());
                                             }

    @Test
                                             public void testConstructor_MaxDenominatorLimitation() {
                                                 // Test that max denominator is respected
                                                 Fraction piApprox = new Fraction(Math.PI, 7);
                                                 assertEquals(22, piApprox.getNumerator());
                                                 assertEquals(7, piApprox.getDenominator());
                                         
                                                 // With smaller max denominator
                                                 Fraction piApproxSmaller = new Fraction(Math.PI, 5);
                                                 assertEquals(16, piApproxSmaller.getNumerator());
                                                 assertEquals(5, piApproxSmaller.getDenominator());
                                             }

    @Test
                                             public void testConstructor_NegativeValues() {
                                                 // Test negative values
                                                 Fraction negativeHalf = new Fraction(-0.5, 100);
                                                 assertEquals(-1, negativeHalf.getNumerator());
                                                 assertEquals(2, negativeHalf.getDenominator());
                                         
                                                 Fraction negativePi = new Fraction(-Math.PI, 7);
                                                 assertEquals(-22, negativePi.getNumerator());
                                                 assertEquals(7, negativePi.getDenominator());
                                             }

    @Test
                                             public void testConstructor_EdgeCases1() {
                                                 // Test very small values
                                                 Fraction smallValue = new Fraction(0.0001, 10000);
                                                 assertEquals(1, smallValue.getNumerator());
                                                 assertEquals(10000, smallValue.getDenominator());
                                         
                                                 // Test values very close to 1
                                                 Fraction almostOne = new Fraction(0.9999, 100);
                                                 assertEquals(100, almostOne.getNumerator());
                                                 assertEquals(100, almostOne.getDenominator());
                                             }

    @Test
                                             public void testConstructor_InvalidMaxDenominator() {
                                                 thrown.expect(IllegalArgumentException.class);
                                                 new Fraction(0.5, 0);  // maxDenominator must be positive
                                             }

    @Test
                                             public void testConstructor_ExtremeValues() {
                                                 // Test very large values
                                                 Fraction largeValue = new Fraction(1.0E6, 100);
                                                 assertEquals(1000000, largeValue.getNumerator());
                                                 assertEquals(1, largeValue.getDenominator());
                                         
                                                 // Test very small max denominator
                                                 Fraction constrained = new Fraction(0.333, 2);
                                                 assertEquals(1, constrained.getNumerator());
                                                 assertEquals(3, constrained.getDenominator());
                                             }

    @Test
                                             public void testConstructor_CompareWithStaticConstants1() {
                                                 // Test that constructor matches static constants
                                                 Fraction half = new Fraction(0.5, 100);
                                                 assertEquals(Fraction.ONE_HALF.getNumerator(), half.getNumerator());
                                                 assertEquals(Fraction.ONE_HALF.getDenominator(), half.getDenominator());
                                         
                                                 Fraction third = new Fraction(1.0/3, 100);
                                                 assertEquals(Fraction.ONE_THIRD.getNumerator(), third.getNumerator());
                                                 assertEquals(Fraction.ONE_THIRD.getDenominator(), third.getDenominator());
                                             }

    @Test
                                             public void testConstructor_ApproximationAccuracy() {
                                                 // Test approximation accuracy
                                                 double value = 0.123456789;
                                                 Fraction approx = new Fraction(value, 10000);
                                                 double error = Math.abs(value - approx.doubleValue());
                                                 assertTrue(error < 0.0001);  // Should be reasonably accurate
                                             }

    @Test
                                             public void testConstructorWithInt_PositiveNumber() {
                                                 Fraction fraction = new Fraction(3);
                                                 assertEquals(3, fraction.getNumerator());
                                                 assertEquals(1, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructorWithInt_NegativeNumber() {
                                                 Fraction fraction = new Fraction(-5);
                                                 assertEquals(-5, fraction.getNumerator());
                                                 assertEquals(1, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructorWithInt_Zero() {
                                                 Fraction fraction = new Fraction(0);
                                                 assertEquals(0, fraction.getNumerator());
                                                 assertEquals(1, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructorWithInt_MaxValue() {
                                                 Fraction fraction = new Fraction(Integer.MAX_VALUE);
                                                 assertEquals(Integer.MAX_VALUE, fraction.getNumerator());
                                                 assertEquals(1, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructorWithInt_MinValue() {
                                                 Fraction fraction = new Fraction(Integer.MIN_VALUE);
                                                 assertEquals(Integer.MIN_VALUE, fraction.getNumerator());
                                                 assertEquals(1, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructorWithInt_EqualsMethod() {
                                                 Fraction fraction1 = new Fraction(7);
                                                 Fraction fraction2 = new Fraction(7);
                                                 assertTrue(fraction1.equals(fraction2));
                                             }

    @Test
                                             public void testConstructorWithInt_NotEqualsMethod() {
                                                 Fraction fraction1 = new Fraction(7);
                                                 Fraction fraction2 = new Fraction(8);
                                                 assertFalse(fraction1.equals(fraction2));
                                             }

    @Test
                                             public void testConstructorWithInt_ToString() {
                                                 Fraction fraction = new Fraction(4);
                                                 assertEquals("4 / 1", fraction.toString());
                                             }

    @Test
                                             public void testConstructorWithInt_DoubleValue() {
                                                 Fraction fraction = new Fraction(3);
                                                 assertEquals(3.0, fraction.doubleValue(), 0.0001);
                                             }

    @Test
                                             public void testConstructorWithInt_FloatValue() {
                                                 Fraction fraction = new Fraction(3);
                                                 assertEquals(3.0f, fraction.floatValue(), 0.0001);
                                             }

    @Test
                                             public void testConstructorWithInt_IntValue() {
                                                 Fraction fraction = new Fraction(3);
                                                 assertEquals(3, fraction.intValue());
                                             }

    @Test
                                             public void testConstructorWithInt_LongValue() {
                                                 Fraction fraction = new Fraction(3);
                                                 assertEquals(3L, fraction.longValue());
                                             }

    @Test
                                             public void testConstructorWithInt_CompareTo() {
                                                 Fraction fraction1 = new Fraction(3);
                                                 Fraction fraction2 = new Fraction(4);
                                                 assertTrue(fraction1.compareTo(fraction2) < 0);
                                                 assertTrue(fraction2.compareTo(fraction1) > 0);
                                                 assertEquals(0, fraction1.compareTo(new Fraction(3)));
                                             }

    @Test
                                             public void testConstructor_NormalFraction() {
                                                 Fraction fraction = new Fraction(3, 4);
                                                 assertEquals(3, fraction.getNumerator());
                                                 assertEquals(4, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructor_ReducesFraction() {
                                                 Fraction fraction = new Fraction(6, 8);
                                                 assertEquals(3, fraction.getNumerator());
                                                 assertEquals(4, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructor_NegativeDenominator() {
                                                 Fraction fraction = new Fraction(3, -4);
                                                 assertEquals(-3, fraction.getNumerator());
                                                 assertEquals(4, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructor_NegativeNumeratorAndDenominator() {
                                                 Fraction fraction = new Fraction(-3, -4);
                                                 assertEquals(3, fraction.getNumerator());
                                                 assertEquals(4, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructor_ZeroNumerator() {
                                                 Fraction fraction = new Fraction(0, 1);
                                                 assertEquals(0, fraction.getNumerator());
                                                 assertEquals(1, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructor_ZeroDenominatorThrowsException() {
                                                 thrown.expect(MathArithmeticException.class);
                                                 thrown.expectMessage(LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION.getSourceString());
                                                 new Fraction(1, 0);
                                             }

    @Test
                                             public void testConstructor_MinValueNumeratorAndNegativeDenominator() {
                                                 thrown.expect(MathArithmeticException.class);
                                                 thrown.expectMessage(LocalizedFormats.OVERFLOW_IN_FRACTION.getSourceString());
                                                 new Fraction(Integer.MIN_VALUE, -1);
                                             }

    @Test
                                             public void testConstructor_MinValueDenominatorAndNegativeNumerator() {
                                                 thrown.expect(MathArithmeticException.class);
                                                 thrown.expectMessage(LocalizedFormats.OVERFLOW_IN_FRACTION.getSourceString());
                                                 new Fraction(1, Integer.MIN_VALUE);
                                             }

    @Test
                                             public void testConstructor_ReductionWithMinValue() {
                                                 // This should work because we divide by GCD first
                                                 Fraction fraction = new Fraction(Integer.MIN_VALUE/2, Integer.MIN_VALUE);
                                                 assertEquals(1, fraction.getNumerator());
                                                 assertEquals(2, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructor_LargeValues() {
                                                 Fraction fraction = new Fraction(Integer.MAX_VALUE, Integer.MAX_VALUE);
                                                 assertEquals(1, fraction.getNumerator());
                                                 assertEquals(1, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructor_LargeValuesNegativeDenominator() {
                                                 Fraction fraction = new Fraction(Integer.MAX_VALUE, -Integer.MAX_VALUE);
                                                 assertEquals(-1, fraction.getNumerator());
                                                 assertEquals(1, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructor_OneAsDenominator() {
                                                 Fraction fraction = new Fraction(5, 1);
                                                 assertEquals(5, fraction.getNumerator());
                                                 assertEquals(1, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructor_AlreadyReducedFraction() {
                                                 Fraction fraction = new Fraction(7, 11);
                                                 assertEquals(7, fraction.getNumerator());
                                                 assertEquals(11, fraction.getDenominator());
                                             }

    @Test
                                             public void testConstructor_ReductionWithGCDGreaterThanOne() {
                                                 Fraction fraction = new Fraction(15, 25);
                                                 assertEquals(3, fraction.getNumerator());
                                                 assertEquals(5, fraction.getDenominator());
                                             }

    @Test
                                     public void testIntegerValue() throws Exception {
                                         // Get the private constructor
                                         Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                                             double.class, double.class, int.class, int.class);
                                         constructor.setAccessible(true);
                                         
                                         // Create fraction using the private constructor
                                         Fraction f = constructor.newInstance(5.0, 0.00001, 100, 100);
                                         
                                         assertEquals(5, f.getNumerator());
                                         assertEquals(1, f.getDenominator());
                                     }

    @Test
                                     public void testSimpleFraction() {
                                         Fraction f = new Fraction(0.5, 0.00001, 100);
                                         assertEquals(1, f.getNumerator());
                                         assertEquals(2, f.getDenominator());
                                     }

    @Test
                                     public void testNegativeValue() throws Exception {
                                         // Get the private constructor via reflection
                                         Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                                             double.class, double.class, int.class, int.class);
                                         constructor.setAccessible(true);
                                         
                                         // Create the fraction using the private constructor
                                         Fraction f = constructor.newInstance(-0.75, 0.00001, 100, 100);
                                         
                                         assertEquals(-3, f.getNumerator());
                                         assertEquals(4, f.getDenominator());
                                     }

    @Test
                                     public void testZeroValue() throws Exception {
                                         // Get the private constructor
                                         Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                                             double.class, double.class, int.class, int.class);
                                         constructor.setAccessible(true);
                                         
                                         // Create fraction with zero value
                                         Fraction f = constructor.newInstance(0.0, 0.00001, 100, 100);
                                         
                                         assertEquals(0, f.getNumerator());
                                         assertEquals(1, f.getDenominator());
                                     }

    @Test
                                     public void testPrecisionWithinEpsilon() throws Exception {
                                         // Value is very close to 1/3
                                         Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                                             double.class, double.class, int.class, int.class);
                                         constructor.setAccessible(true);
                                         Fraction f = constructor.newInstance(0.333333333, 0.0001, 100, 100);
                                         
                                         assertEquals(1, f.getNumerator());
                                         assertEquals(3, f.getDenominator());
                                     }

    @Test
                                     public void testMaxDenominatorConstraint() {
                                         // PI approximation with max denominator 7 should give 22/7
                                         Fraction f = new Fraction(Math.PI, 7);
                                         assertEquals(22, f.getNumerator());
                                         assertEquals(7, f.getDenominator());
                                     }

    @Test
                                     public void testMaxIterationsExceeded() throws Exception {
                                         ExpectedException exception = ExpectedException.none();
                                         exception.expect(FractionConversionException.class);
                                         
                                         // Get the private constructor
                                         Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                                             double.class, double.class, int.class, int.class);
                                         constructor.setAccessible(true);
                                         
                                         // Call the private constructor with parameters that will exceed max iterations
                                         constructor.newInstance(Math.PI, 0.0000001, 1000000, 5);
                                     }

    @Test(expected = FractionConversionException.class)
                                     public void testNumeratorOverflow() {
                                         new Fraction(Double.MAX_VALUE, 0.0001, Integer.MAX_VALUE);
                                     }

    @Test
                                     public void testGoldenRatioApproximation() throws Exception {
                                         // Golden ratio (1 + sqrt(5))/2
                                         double phi = (1 + Math.sqrt(5)) / 2;
                                         // Use reflection to access private constructor
                                         Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                                             double.class, double.class, int.class, int.class);
                                         constructor.setAccessible(true);
                                         Fraction f = constructor.newInstance(phi, 0.0001, 1000, 100);
                                         // Should approximate to 89/55
                                         assertEquals(89, f.getNumerator());
                                         assertEquals(55, f.getDenominator());
                                     }

    @Test
                                     public void testVerySmallEpsilon() throws Exception {
                                         // Tests behavior with very tight precision constraint
                                         // Use reflection to access private constructor
                                         Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                                             double.class, double.class, int.class, int.class);
                                         constructor.setAccessible(true);
                                         Fraction f = constructor.newInstance(0.123456789, 0.000000001, 100000, 100);
                                         
                                         // Verify the fraction is precise enough
                                         double error = Math.abs(f.doubleValue() - 0.123456789);
                                         assertTrue(error < 0.000000001);
                                     }

    @Test
                                     public void testValueVeryCloseToInteger() throws Exception {
                                         // Value is 3.0000001 which should be treated as 3 due to epsilon
                                         Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                                             double.class, double.class, int.class, int.class);
                                         constructor.setAccessible(true);
                                         Fraction f = constructor.newInstance(3.0000001, 0.000001, 100, 100);
                                         assertEquals(3, f.getNumerator());
                                         assertEquals(1, f.getDenominator());
                                     }

    @Test
                                     public void testValueJustAboveEpsilonThreshold() {
                                         // Value is 0.3334 with epsilon 0.0001 - should not return 1/3
                                         Fraction f = new Fraction(0.3334, 0.0001, 100);
                                         assertNotEquals(1, f.getNumerator());
                                         assertNotEquals(3, f.getDenominator());
                                     }

    @Test
                                 public void testDenominatorOverflow() throws Exception {
                                     try {
                                         // Get the private constructor
                                         Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                                             double.class, double.class, int.class, int.class);
                                         constructor.setAccessible(true);
                                         
                                         // Call the constructor with values that would cause denominator overflow
                                         constructor.newInstance(1.0 / Integer.MAX_VALUE, 0.0001, Integer.MAX_VALUE, 100);
                                         fail("Expected FractionConversionException");
                                     } catch (InvocationTargetException e) {
                                         // Check if the cause is FractionConversionException
                                         assertTrue(e.getCause() instanceof FractionConversionException);
                                     }
                                 }

    @Test
                            public void testConstructorWithMaxIntegerValue() {
                                // This test is designed to catch the mutant where the overflow check
                                // was changed from > to >=. The original code should handle Integer.MAX_VALUE
                                // without throwing an exception.
                                
                                // Create a fraction with value exactly equal to Integer.MAX_VALUE
                                double maxIntValue = Integer.MAX_VALUE;
                                
                                // This should not throw an exception in the original code
                                Fraction fraction = new Fraction(maxIntValue);
                                
                                // Verify the fraction was created correctly
                                assertEquals(Integer.MAX_VALUE, fraction.getNumerator());
                                assertEquals(1, fraction.getDenominator());
                                assertEquals(maxIntValue, fraction.doubleValue(), 0.0);
                                
                                // Also test negative Integer.MAX_VALUE to cover both cases
                                Fraction negativeFraction = new Fraction(-maxIntValue);
                                assertEquals(-Integer.MAX_VALUE, negativeFraction.getNumerator());
                                assertEquals(1, negativeFraction.getDenominator());
                                assertEquals(-maxIntValue, negativeFraction.doubleValue(), 0.0);
                            }

    @Test(expected = FractionConversionException.class)
                                public void testConstructorWithMaxIntValue() {
                                    // This test should pass only with the mutated version (>=)
                                    // and fail with original version (>)
                                    double maxIntAsDouble = Integer.MAX_VALUE;
                                    new Fraction(maxIntAsDouble, 100);
                                }

    @Test
                                public void testConstructorWithJustBelowMaxIntValue() {
                                    // Should pass in both versions
                                    double justBelowMaxInt = Integer.MAX_VALUE - 0.5;
                                    Fraction f = new Fraction(justBelowMaxInt, 100);
                                    assertNotNull(f);
                                }

    @Test(expected = FractionConversionException.class)
                                public void testConstructorWithAboveMaxIntValue() {
                                    // Should pass in both versions
                                    double aboveMaxInt = Integer.MAX_VALUE + 1.0;
                                    new Fraction(aboveMaxInt, 100);
                                }

    @Test
                                public void testConstructorWithMaxIntegerValue1() {
                                    // Create a value where floor(value) equals Integer.MAX_VALUE
                                    double value = Integer.MAX_VALUE;
                                    
                                    // The original code should handle this without exception
                                    // The mutated code (>=) would throw FractionConversionException
                                    new Fraction(value);
                                    
                                    // If we want to explicitly test the boundary case with epsilon and max iterations:
                                    double epsilon = 1.0e-5;
                                    int maxIterations = 100;
                                    new Fraction(value, epsilon, maxIterations);
                                    
                                    // For even more precise testing, we can use a value just below MAX_VALUE
                                    // to ensure it's handled correctly
                                    double valueJustBelow = Integer.MAX_VALUE - 0.5;
                                    new Fraction(valueJustBelow);
                                }

    @Test
                                public void testConstructorWithNegativeMaxIntegerValue() {
                                    // Test negative boundary case
                                    double value = -Integer.MAX_VALUE;
                                    new Fraction(value);
                                    
                                    // Value just above negative MAX_VALUE
                                    double valueJustAbove = -Integer.MAX_VALUE + 0.5;
                                    new Fraction(valueJustAbove);
                                }

    @Test
                                public void testConstructorWithValueJustBelowMaxInteger() {
                                    // Test value that's just below Integer.MAX_VALUE
                                    double value = Integer.MAX_VALUE - 0.999999;
                                    
                                    // Original code should accept this
                                    Fraction fraction = new Fraction(value, 1.0e-5, 100);
                                    
                                    // Verify the fraction was created
                                    assertEquals(Integer.MAX_VALUE - 1, fraction.getNumerator());
                                    assertTrue(fraction.getDenominator() > 0);
                                }

    @Test
                           public void testConstructorWithMaxIntegerValue2() {
                               // Create a double value that when floored equals Integer.MAX_VALUE
                               double value = Integer.MAX_VALUE;
                               
                               try {
                                   // Get the private constructor using reflection
                                   Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                                       double.class, double.class, int.class, int.class);
                                   constructor.setAccessible(true);
                                   
                                   // Create the fraction using the private constructor
                                   Fraction fraction = constructor.newInstance(value, 1.0e-5, Integer.MAX_VALUE, 100);
                                   
                                   // Verify the fraction was created correctly
                                   assertEquals(Integer.MAX_VALUE, fraction.getNumerator());
                                   assertEquals(1, fraction.getDenominator());
                               } catch (Exception e) {
                                   if (e instanceof FractionConversionException) {
                                       // If we get here, the mutant was detected (>= condition triggered)
                                       fail("Mutant detected - exception thrown when a0 equals MAX_VALUE");
                                   } else {
                                       // Other reflection-related exceptions
                                       fail("Unexpected exception: " + e.getMessage());
                                   }
                               }
                           }

    @Test
                           public void testConstructorWithMaxIntValue1() {
                               // This test checks the boundary case where input equals Integer.MAX_VALUE
                               // Original code should handle this fine (since not strictly greater than max)
                               // Mutated code would throw exception (since condition becomes >=)
                               
                               double maxIntAsDouble = Integer.MAX_VALUE;
                               Fraction fraction = new Fraction(maxIntAsDouble, 1.0e-5, 100);
                               
                               // Verify the fraction was created correctly
                               assertEquals(Integer.MAX_VALUE, fraction.getNumerator());
                               assertEquals(1, fraction.getDenominator());
                               
                               // Verify the double value matches the input
                               assertEquals(maxIntAsDouble, fraction.doubleValue(), 1.0e-10);
                           }

    @Test(expected = ArithmeticException.class)
                           public void testConstructorWithValueGreaterThanMaxInt() {
                               // This is just a sanity check to verify overflow detection works
                               double tooLarge = Integer.MAX_VALUE + 1.0;
                               new Fraction(tooLarge, 1.0e-5, 100);
                           }

    @Test
                           public void testConstructorWithMaxIntegerValue3() {
                               // This test will detect the mutant by checking behavior at boundary condition
                               double value = Integer.MAX_VALUE;
                               
                               // Original code should accept this value without exception
                               Fraction fraction = new Fraction(value);
                               
                               // Verify the fraction was created correctly
                               assertEquals(Integer.MAX_VALUE, fraction.getNumerator());
                               assertEquals(1, fraction.getDenominator());
                               
                               // Now test the edge case that would fail with the mutant
                               // Create a value where floor(value) equals Integer.MAX_VALUE
                               value = Integer.MAX_VALUE - 0.1; // This will floor to Integer.MAX_VALUE
                               
                               // Set up expectation for mutant detection
                               thrown.expect(FractionConversionException.class);
                               
                               // Use an available public constructor that can trigger the same behavior
                               // The values are chosen to force the conversion to fail when value is close to MAX_VALUE
                               new Fraction(value, 0.1, 100);
                           }

    @Test
                           public void testConstructorWithMaxIntegerEdgeCase() throws Exception {
                               // This is the critical test that would detect the mutant
                               double value = Integer.MAX_VALUE - 0.000001;
                               
                               // Get the private constructor via reflection
                               Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                                   double.class, double.class, int.class, int.class);
                               constructor.setAccessible(true);
                               
                               // Original code should handle this fine
                               Fraction fraction = constructor.newInstance(value, 1.0e-5, Integer.MAX_VALUE, 100);
                               
                               // Verify fraction creation
                               assertNotNull(fraction);
                               
                               // Now test with value that would floor to exactly Integer.MAX_VALUE
                               thrown.expect(FractionConversionException.class);
                               constructor.newInstance((double)Integer.MAX_VALUE, 1.0e-5, Integer.MAX_VALUE, 100);
                           }

    @Test
                      public void testConstructorOverflowConditionOrVsAnd() throws Exception {
                          // This value will cause p2 to overflow while q2 stays within bounds
                          // Original code (OR condition) should throw, mutant (AND condition) won't throw
                          double value = 1.0e300; // Extremely large value that will cause overflow
                          double epsilon = 1.0e-5;
                          int maxDenominator = Integer.MAX_VALUE;
                          int maxIterations = 100;
                          
                          // Get the private constructor
                          Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                              double.class, double.class, int.class, int.class);
                          constructor.setAccessible(true);
                          
                          // This should throw in original code because p2 will overflow
                          // Mutant version won't throw because q2 won't overflow
                          try {
                              constructor.newInstance(value, epsilon, maxDenominator, maxIterations);
                              fail("Expected ArithmeticException due to overflow");
                          } catch (InvocationTargetException e) {
                              assertTrue(e.getCause() instanceof ArithmeticException);
                          }
                      }

    @Test(expected = ArithmeticException.class)
                      public void testConstructorOverflowConditionOrVsAnd1() throws Exception {
                          // This value will cause q2 to overflow while p2 stays within bounds
                          // Original code (OR condition) should throw, mutant (AND condition) won't throw
                          double value = 1.0e-300; // Extremely small value that will cause overflow in denominator
                          double epsilon = 1.0e-5;
                          int maxDenominator = Integer.MAX_VALUE;
                          int maxIterations = 100;
                          
                          // Get the private constructor
                          Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                              double.class, double.class, int.class, int.class);
                          constructor.setAccessible(true);
                          
                          // This should throw in original code because q2 will overflow
                          // Mutant version won't throw because p2 won't overflow
                          constructor.newInstance(value, epsilon, maxDenominator, maxIterations);
                      }

    @Test(expected = ArithmeticException.class)
                      public void testConstructorOverflowConditionBoth() throws Exception {
                          // This case tests when both overflow (both versions should throw)
                          double value = Double.MAX_VALUE;
                          double epsilon = 1.0e-5;
                          int maxDenominator = Integer.MAX_VALUE;
                          int maxIterations = 100;
                          
                          // Get the private constructor
                          Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                              double.class, double.class, int.class, int.class);
                          constructor.setAccessible(true);
                          
                          // Both original and mutant should throw
                          constructor.newInstance(value, epsilon, maxDenominator, maxIterations);
                      }

    @Test(expected = FractionConversionException.class)
                      public void testOverflowConditionWithLargeValue() {
                          // This value is chosen to cause p2 to overflow while q2 remains within bounds
                          // during the continued fraction calculation
                          double value = 1.0e20;
                          
                          // Create fraction with parameters that will lead to overflow in p2 but not q2
                          // Using small epsilon and max iterations to ensure we hit the overflow condition
                          new Fraction(value, 1.0e-10, 100);
                          
                          // The original code should throw FractionConversionException because p2 overflows
                          // The mutant would not throw because it requires both p2 AND q2 to overflow
                      }

    @Test(expected = FractionConversionException.class)
                      public void testOverflowConditionWithSmallValue() throws Exception {
                          // This value is chosen to cause q2 to overflow while p2 remains within bounds
                          double value = 1.0e-20;
                          double epsilon = 1.0e-10;
                          int maxDenominator = Integer.MAX_VALUE;
                          int maxIterations = 100;
                          
                          // Get the private constructor
                          Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                              double.class, double.class, int.class, int.class);
                          constructor.setAccessible(true);
                          
                          // Create fraction with parameters that will lead to overflow in q2 but not p2
                          constructor.newInstance(value, epsilon, maxDenominator, maxIterations);
                      }

    @Test
                      public void testFractionConversionOverflowCondition() throws Exception {
                          // This test will pass with original code but fail with mutant
                          // because mutant requires BOTH p2 and q2 to overflow
                          
                          // Choose a value that will cause p2 to overflow but not q2
                          // during the continued fraction computation
                          // Using a very large value that will generate large numerators
                          
                          // Get the private constructor
                          Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                              double.class, double.class, int.class, int.class);
                          constructor.setAccessible(true);
                          
                          // Create instance using the private constructor
                          constructor.newInstance(Double.MAX_VALUE, 0.0, Integer.MAX_VALUE, 100);
                      }

    @Test
                      public void testFractionConversionOverflowCondition1() throws Exception {
                          // Test case where both p2 and q2 overflow
                          // Using a value that causes both numerator and denominator to grow
                          Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                              double.class, double.class, int.class, int.class);
                          constructor.setAccessible(true);
                          constructor.newInstance(Math.PI, 0.0, Integer.MAX_VALUE, 100000);
                      }

    @Test
                      public void testOverflowCheckWithOnlyNumeratorOverflow() {
                          // This value will cause p2 to overflow while q2 remains normal
                          // Choose a value that will make the continued fraction algorithm
                          // produce a numerator that overflows while denominator doesn't
                          double value = 1.0e16; // Large value likely to cause numerator overflow
                          double epsilon = 1.0e-5;
                          int maxIterations = 100;
                          
                          thrown.expect(FractionConversionException.class);
                          // This should pass with original code (OR condition) but fail with mutant (AND condition)
                          // Using public constructor that takes (double, double, int)
                          new Fraction(value, epsilon, maxIterations);
                      }

    @Test
                      public void testOverflowCheckWithOnlyDenominatorOverflow() throws Exception {
                          // This value will cause q2 to overflow while p2 remains normal
                          // Choose a value that will make the continued fraction algorithm
                          // produce a denominator that overflows while numerator doesn't
                          double value = 1.0 / 1.0e16; // Very small value likely to cause denominator overflow
                          
                          thrown.expect(FractionConversionException.class);
                          
                          // Get the private constructor
                          Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                              double.class, double.class, int.class, int.class);
                          constructor.setAccessible(true);
                          
                          // Call the private constructor
                          constructor.newInstance(value, 1.0e-5, Integer.MAX_VALUE, 100);
                      }

    @Test
                      public void testOverflowCheckWithBothOverflow() throws Exception {
                          // This case should work in both original and mutant, but we include it for completeness
                          double value = Double.MAX_VALUE;
                          
                          thrown.expect(FractionConversionException.class);
                          
                          // Get the private constructor using reflection
                          Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                              double.class, double.class, int.class, int.class);
                          constructor.setAccessible(true);
                          
                          // Invoke the constructor with test parameters
                          constructor.newInstance(value, 1.0e-5, Integer.MAX_VALUE, 100);
                      }

    @Test
                      public void testOverflowConditionWithOnlyNumeratorOverflow() throws Exception {
                          // This value will cause p2 to overflow while q2 remains normal
                          // Original code should throw, mutant may not
                          Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                              double.class, double.class, int.class, int.class);
                          constructor.setAccessible(true);
                          constructor.newInstance(Double.MAX_VALUE, 1.0e-5, Integer.MAX_VALUE, 100);
                      }

    @Test
                      public void testOverflowConditionWithOnlyDenominatorOverflow() throws Exception {
                          // This value will cause q2 to overflow while p2 remains normal
                          // Original code should throw, mutant may not
                          Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                              double.class, double.class, int.class, int.class);
                          constructor.setAccessible(true);
                          constructor.newInstance(1.0/Double.MAX_VALUE, 1.0e-5, Integer.MAX_VALUE, 100);
                      }

    @Test(expected = ArithmeticException.class)
                      public void testOverflowConditionWithBothOverflow() throws Exception {
                          // This value will cause both p2 and q2 to overflow
                          // Both original and mutant should throw
                          Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                              double.class, double.class, int.class, int.class);
                          constructor.setAccessible(true);
                          constructor.newInstance(Double.MAX_VALUE, 1.0e-5, Integer.MAX_VALUE, 100);
                      }

    @Test(expected = MathArithmeticException.class)
                      public void testOverflowDetectionWhenEitherNumeratorOrDenominatorOverflows() throws Exception {
                          // Use reflection to access private constructor
                          Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                              double.class, double.class, int.class, int.class);
                          constructor.setAccessible(true);
                          
                          // This value will cause overflow in numerator but not denominator
                          constructor.newInstance(1.0e20, 0, 100000, 100);
                          
                          // The test expects MathArithmeticException to be thrown
                      }

    @Test
                      public void testOverflowDetectionWhenDenominatorOverflows() throws Exception {
                          // Get the private constructor
                          Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                              double.class, double.class, int.class, int.class);
                          constructor.setAccessible(true);
                          
                          // This value will cause q2 to overflow but p2 won't
                          constructor.newInstance(1.0e-20, 0, Integer.MAX_VALUE, 100);
                          
                          // The mutant would pass this test because it requires both to overflow
                          // Original code would throw exception since q2 overflows
                      }

    @Test(expected = MathArithmeticException.class)
                      public void testOverflowDetectionWhenBothOverflow() {
                          // This will cause overflow when trying to handle negative denominator
                          new Fraction(Integer.MIN_VALUE, Integer.MIN_VALUE);
                      }

    @Test
                  public void testFractionConversionOverflowCondition2() {
                      // Another test case where q2 overflows but p2 doesn't
                      // This is harder to trigger directly, but we can use a value
                      // that causes the denominator to grow very large
                      new Fraction(1.0e-300, Integer.MAX_VALUE);
                  }

    @Test
             public void testFractionConversionAtMaxIterations() {
                 // This test should detect the mutant by using maxIterations boundary
                 double value = 0.3333333333; // 1/3 approximation
                 double epsilon = 1.0e-5;
                 int maxIterations = 5; // Small number to easily reach max iterations
                 
                 // Create fraction that will hit maxIterations exactly
                 // Using public constructor that takes value, epsilon and maxIterations
                 Fraction fraction = new Fraction(value, epsilon, maxIterations);
                 
                 // In original code, iterations stop at n=5 (n < 5 is false)
                 // Mutated code would do one more iteration (n <= 5 when n=5)
                 // Verify the result matches expected behavior
                 
                 // Expected result when stopping at n=5
                 int expectedNumerator = 1;
                 int expectedDenominator = 3;
                 
                 assertEquals(expectedNumerator, fraction.getNumerator());
                 assertEquals(expectedDenominator, fraction.getDenominator());
                 
                 // Also test with maxIterations=1 to verify boundary case
                 maxIterations = 1;
                 fraction = new Fraction(value, epsilon, maxIterations);
                 
                 // Original would do 1 iteration (n=0, n=1)
                 // Mutated would allow n=1 iteration (n <=1 when n=1)
                 // Should be same in this case
                 expectedNumerator = 1;
                 expectedDenominator = 1; // First convergent is 1/1
                 
                 assertEquals(expectedNumerator, fraction.getNumerator());
                 assertEquals(expectedDenominator, fraction.getDenominator());
             }

    @Test
             public void testFractionConversionAtMaxIterationsBoundary() {
                 // This test is designed to catch the mutant where n <= maxIterations
                 // instead of n < maxIterations
                 
                 // We'll use a value that requires exactly maxIterations to converge
                 // With maxIterations=3, the original would stop after 2 iterations
                 // The mutant would allow a 3rd iteration
                 
                 // Setup - choose values that will hit maxIterations exactly
                 double value = 0.3333333333; // 1/3 approximation
                 double epsilon = 0.0001;
                 int maxIterations = 3;
                 
                 // Expected behavior - should throw FractionConversionException
                 // because with original n < maxIterations, it would stop at n=2
                 // but with mutant n <= maxIterations, it would do one more iteration
                 
                 try {
                     // This should throw an exception with original code
                     // but might not with the mutant
                     Fraction fraction = new Fraction(value, epsilon, maxIterations);
                     
                     // If we get here with original code, test fails
                     // With mutant, we might get here with different fraction
                     Fraction expected = new Fraction(1, 3); // expected best approximation
                     
                     // Verify the fraction is correct
                     assertEquals(expected.getNumerator(), fraction.getNumerator());
                     assertEquals(expected.getDenominator(), fraction.getDenominator());
                     
                     // If we reach here, the mutant survived (bad)
                     fail("Expected FractionConversionException but none was thrown");
                 } catch (FractionConversionException e) {
                     // This is expected for original code
                     // Verify the exception message contains maxIterations
                     assertTrue(e.getMessage().contains(String.valueOf(maxIterations)));
                 }
             }

    @Test
             public void testFractionConversionAtMaxIterationsBoundary1() throws Exception {
                 // This test is designed to catch the mutant where n < maxIterations was changed to n <= maxIterations
                 // We use a value that will require exactly 5 iterations to converge with given parameters
                 // and check that the constructor respects the maxIterations boundary
                 
                 // Parameters chosen so that convergence happens exactly at maxIterations
                 double value = 0.123456789; // A value that won't converge quickly
                 double epsilon = 0;
                 int maxIterations = 5;
                 int maxDenominator = Integer.MAX_VALUE;
                 
                 // Use reflection to access private constructor
                 Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                     double.class, double.class, int.class, int.class);
                 constructor.setAccessible(true);
                 
                 // Create fraction with original code (should stop at exactly 5 iterations)
                 Fraction originalFraction = constructor.newInstance(value, epsilon, maxDenominator, maxIterations);
                 
                 // The mutation would cause one extra iteration to occur, potentially:
                 // 1. Throwing FractionConversionException if q2 overflows in extra iteration
                 // 2. Producing a different fraction if extra iteration finds a better approximation
                 
                 // Verify the fraction was created successfully (mutant might throw exception)
                 assertNotNull(originalFraction);
                 
                 // For this specific case, we know with maxIterations=5, the denominator should be 81
                 // (This is based on the continued fraction expansion of 0.123456789)
                 // The mutant might produce a different denominator if it does an extra iteration
                 assertEquals(81, originalFraction.getDenominator());
                 
                 // Also verify numerator is correct (10/81 ≈ 0.123456790)
                 assertEquals(10, originalFraction.getNumerator());
                 
                 // Verify the approximation is within reasonable bounds
                 double error = Math.abs(originalFraction.doubleValue() - value);
                 assertTrue(error < 1.0e-5);
             }

    @Test
             public void testFractionConversionAtMaxIterationsBoundary2() {
                 // This value is chosen to require exactly maxIterations steps to converge
                 double value = 0.6180339887498949; // golden ratio conjugate
                 double epsilon = 1.0e-5;
                 int maxDenominator = Integer.MAX_VALUE;
                 int maxIterations = 10; // Set a low iteration limit to hit boundary
                 
                 // Use public constructor that's available
                 Fraction originalFraction = new Fraction(value, epsilon, maxIterations);
                 
                 // Now test with maxIterations-1 to see if behavior changes at boundary
                 int boundaryIterations = maxIterations - 1;
                 Fraction boundaryFraction = new Fraction(value, epsilon, boundaryIterations);
                 
                 // The mutant would behave differently when n equals maxIterations
                 // So we need to verify the behavior at the boundary
                 assertNotEquals("Fractions should differ at iteration boundary", 
                                originalFraction, boundaryFraction);
                 
                 // Also verify the exact boundary case
                 try {
                     // This should throw FractionConversionException with original code
                     // But might succeed with mutant
                     new Fraction(value, epsilon, boundaryIterations);
                     fail("Expected FractionConversionException");
                 } catch (FractionConversionException e) {
                     // Expected with original code
                     assertNotNull(e);
                 }
             }

    @Test
             public void testFractionConversionAtMaxIterationsBoundary3() throws Exception {
                 // This value is chosen because it requires exactly 5 iterations to converge
                 // with default epsilon (1.0e-5)
                 double value = 0.123456789;
                 int maxIterations = 4; // Should stop at 4 (original) vs 5 (mutant)
                 
                 // Get the private constructor
                 Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                     double.class, double.class, int.class, int.class);
                 constructor.setAccessible(true);
                 
                 // With original condition (n < maxIterations), it should throw exception
                 // because it can't converge in 4 iterations
                 try {
                     constructor.newInstance(value, 1.0e-5, Integer.MAX_VALUE, maxIterations);
                     fail("Expected FractionConversionException");
                 } catch (InvocationTargetException e) {
                     if (!(e.getCause() instanceof FractionConversionException)) {
                         fail("Expected FractionConversionException");
                     }
                     // Expected behavior for original code
                 }
                 
                 // With mutant condition (n <= maxIterations), it would do one more iteration
                 // and might produce a result (if it converges in 5 iterations)
                 // So this test would fail if the mutant is present
                 
                 // Additional test with maxIterations+1 to verify it converges
                 Fraction f = constructor.newInstance(value, 1.0e-5, Integer.MAX_VALUE, maxIterations+1);
                 assertNotNull(f);
                 assertEquals(10, f.getNumerator());
                 assertEquals(81, f.getDenominator());
             }

    @Test
         public void testFractionConversionAtMaxIterationsBoundary4() throws Exception {
             // Setup
             double value = 0.123456789; // A value that will require exact max iterations
             double epsilon = 1.0e-5;
             int maxDenominator = Integer.MAX_VALUE;
             int maxIterations = 10; // Set a small, exact number of iterations
             
             // Get the private constructor via reflection
             Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                 double.class, double.class, int.class, int.class);
             constructor.setAccessible(true);
             
             // Test - should throw when reaching maxIterations
             try {
                 Fraction fraction = constructor.newInstance(value, epsilon, maxDenominator, maxIterations);
                 fail("Expected FractionConversionException");
             } catch (InvocationTargetException e) {
                 // Verify the exception type
                 assertTrue(e.getCause() instanceof FractionConversionException);
             }
             
             // Now test with one less iteration to ensure it works when under limit
             Fraction validFraction = constructor.newInstance(value, epsilon, maxDenominator, maxIterations - 1);
             assertNotNull(validFraction);
         }

    @Test
     public void testFractionConversionAtOverflowBoundary() {
         // This test checks the boundary condition where p2 is exactly at overflow limit
         // Original code would accept Integer.MAX_VALUE as p2
         // Mutated code would reject it (>= instead of >)
         
         // Create a value that will result in p2 being exactly Integer.MAX_VALUE
         // We need to find a double value whose continued fraction expansion hits MAX_VALUE
         // This is tricky, but we can use the constructor with maxDenominator to force it
         
         try {
             // This value is carefully chosen to produce p2 = Integer.MAX_VALUE
             // in the continued fraction expansion
             double value = Integer.MAX_VALUE - 0.5;
             Fraction fraction = new Fraction(value, Integer.MAX_VALUE);
             
             // If we get here, the original code accepted the value
             // The mutant would have thrown an exception
             // So we need to verify the fraction is correct
             assertEquals(Integer.MAX_VALUE - 1, fraction.getNumerator());
             assertEquals(1, fraction.getDenominator());
         } catch (FractionConversionException e) {
             // If we get here, the mutant was detected
             fail("Mutant detected: Exception thrown for p2 at overflow boundary");
         }
         
         // Additional test case where p2 is just above overflow
         try {
             double value = Integer.MAX_VALUE + 1.0;
             new Fraction(value, Integer.MAX_VALUE);
             fail("Expected FractionConversionException for p2 > overflow");
         } catch (FractionConversionException e) {
             // Expected behavior for both original and mutant
         }
     }

    @Test
    public void testConstructorWithExactOverflowValue() throws Exception {
        // This test is designed to catch the mutant where >= is used instead of >
        // We need a value that will make p2 equal to Integer.MAX_VALUE exactly
        
        // The exact value that triggers this is tricky to calculate, but we know:
        // - The algorithm uses continued fractions
        // - We need p2 to reach exactly Integer.MAX_VALUE
        // - For the original code, this should NOT throw exception
        // - For the mutant, this WILL throw exception
        
        // Using a value that would make p2 = Integer.MAX_VALUE in one of the iterations
        // This is a carefully crafted value that would hit the boundary condition
        double boundaryValue = Integer.MAX_VALUE / (1.0 - 1.0/(Integer.MAX_VALUE + 1.0));
        
        // Get the private constructor using reflection
        Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
            double.class, double.class, int.class, int.class);
        constructor.setAccessible(true);
        
        try {
            // For the original code, this should create a fraction without exception
            // For the mutant, this should throw FractionConversionException
            constructor.newInstance(boundaryValue, 1.0e-10, Integer.MAX_VALUE, 100);
            
            // If we reach here, the test fails (no exception thrown)
            // Which means the mutant wasn't caught
            fail("Expected FractionConversionException for exact overflow boundary");
        } catch (InvocationTargetException e) {
            // Check if the cause is FractionConversionException
            if (!(e.getCause() instanceof FractionConversionException)) {
                fail("Expected FractionConversionException but got " + e.getCause().getClass());
            }
            // Test passes if we get FractionConversionException
        }
    }

    @Test
    public void testOverflowBoundaryCondition() throws Exception {
        // This test is designed to catch the mutant where the overflow check 
        // was changed from > to >= for p2
        
        // We need to find a value that will cause p2 to be exactly Integer.MAX_VALUE
        // during the continued fraction calculation
        
        // Using a value that will generate Integer.MAX_VALUE as a numerator
        // in one of the intermediate steps
        double value = 1.0 + 1.0/Integer.MAX_VALUE;
        
        try {
            // Get the private constructor using reflection
            Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                double.class, double.class, int.class, int.class);
            constructor.setAccessible(true);
            
            // Create fraction with max denominator set to Integer.MAX_VALUE
            // and small epsilon to force continued fraction calculation
            Fraction fraction = constructor.newInstance(
                value, 1.0e-10, Integer.MAX_VALUE, 100);
            
            // If we get here, the original code passed the overflow check
            // (which is correct since p2 equals but doesn't exceed MAX_VALUE)
            // Verify the fraction is created successfully
            assertNotNull(fraction);
        } catch (FractionConversionException e) {
            // If we get here, the mutant was caught because it threw an exception
            // when p2 was exactly MAX_VALUE
            fail("Original code should not throw exception when p2 equals Integer.MAX_VALUE exactly");
        }
    }

    @Test
    public void testFractionConversionWithMaxIntValue() {
        // This test is designed to catch the mutant where overflow check uses >= instead of >
        // We need a value that will produce p2 = Integer.MAX_VALUE exactly
        
        // The exact value that would produce p2 = Integer.MAX_VALUE is hard to compute directly,
        // but we can use a value very close to Integer.MAX_VALUE/1
        double value = Integer.MAX_VALUE;
        
        try {
            // Create fraction with maxDenominator large enough to allow exact representation
            Fraction fraction = new Fraction(value, Integer.MAX_VALUE);
            
            // Verify the fraction was created successfully (original behavior)
            assertEquals(Integer.MAX_VALUE, fraction.getNumerator());
            assertEquals(1, fraction.getDenominator());
        } catch (FractionConversionException e) {
            // If we get here, the mutant was detected (>= condition triggered)
            fail("Mutant detected: Exception thrown when p2 equals exactly Integer.MAX_VALUE");
        }
        
        // Also test with a value that would produce p2 = Integer.MAX_VALUE - 1
        // This should pass in both original and mutated versions
        value = Integer.MAX_VALUE - 1;
        Fraction fraction = new Fraction(value, Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE - 1, fraction.getNumerator());
        assertEquals(1, fraction.getDenominator());
    }

    @Test
    public void testOverflowBoundaryCondition1() {
        // This value is carefully chosen to make p2 reach exactly Integer.MAX_VALUE
        // during the continued fraction calculation
        double boundaryValue = 1.0 / (1.0 - 1.0 / Integer.MAX_VALUE);
        
        try {
            // Get the private constructor using reflection
            Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                double.class, double.class, int.class, int.class);
            constructor.setAccessible(true);
            
            // Original should accept this value since p2 equals but doesn't exceed MAX_VALUE
            Fraction fraction = constructor.newInstance(boundaryValue, 1.0e-5, Integer.MAX_VALUE, 100);
            
            // Verify the fraction was created successfully
            assertNotNull(fraction);
            assertEquals(Integer.MAX_VALUE, fraction.getNumerator());
            assertEquals(1, fraction.getDenominator());
        } catch (Exception e) {
            if (e instanceof FractionConversionException) {
                // If we get here, the test has detected the mutant
                fail("Original implementation should accept boundary value, but threw exception: " + e.getMessage());
            } else {
                // Other reflection-related exceptions
                fail("Unexpected exception: " + e.getMessage());
            }
        }
    }

    @Test
    public void testFractionConversionWithExactMaxValueNumerator() {
        // This value is carefully chosen to produce a numerator of exactly Integer.MAX_VALUE
        // during the continued fraction approximation process
        double value = 2147483647.0 / 1.0;
        
        // We use very small epsilon to force the algorithm to try to get as close as possible
        double epsilon = 1.0e-15;
        
        // Large max iterations to allow the exact representation
        int maxIterations = 100;
        
        // This should throw in the mutant but not in the original
        new Fraction(value, epsilon, maxIterations);
        
        // If we get here, the test fails (mutant survived)
        // The expected exception will be thrown by the mutant but not the original
    }


}
