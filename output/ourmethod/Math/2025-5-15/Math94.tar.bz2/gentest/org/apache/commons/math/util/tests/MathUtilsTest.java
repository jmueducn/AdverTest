package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                             public void testGcd_ZeroCases() {
                                 // When one or both numbers are zero
                                 assertEquals(5, MathUtils.gcd(0, 5));
                                 assertEquals(5, MathUtils.gcd(5, 0));
                                 assertEquals(0, MathUtils.gcd(0, 0));
                                 assertEquals(7, MathUtils.gcd(-7, 0));
                                 assertEquals(7, MathUtils.gcd(0, -7));
                             }

 @Test
                             public void testGcd_PositiveNumbers() {
                                 // Positive numbers
                                 assertEquals(1, MathUtils.gcd(1, 1));
                                 assertEquals(2, MathUtils.gcd(2, 4));
                                 assertEquals(6, MathUtils.gcd(12, 18));
                                 assertEquals(14, MathUtils.gcd(42, 56));
                                 assertEquals(1, MathUtils.gcd(13, 17)); // Co-prime numbers
                             }

 @Test
                             public void testGcd_NegativeNumbers() {
                                 // Negative numbers
                                 assertEquals(3, MathUtils.gcd(-3, -9));
                                 assertEquals(5, MathUtils.gcd(-10, 15));
                                 assertEquals(7, MathUtils.gcd(21, -28));
                                 assertEquals(1, MathUtils.gcd(-13, -17));
                             }

 @Test
                             public void testGcd_EqualNumbers() {
                                 // Equal numbers
                                 assertEquals(5, MathUtils.gcd(5, 5));
                                 assertEquals(10, MathUtils.gcd(-10, -10));
                             }

 @Test
                             public void testGcd_OneIsMultipleOfOther() {
                                 // One number is multiple of the other
                                 assertEquals(3, MathUtils.gcd(3, 9));
                                 assertEquals(4, MathUtils.gcd(16, 4));
                                 assertEquals(5, MathUtils.gcd(25, 5));
                             }

 @Test
                             public void testGcd_LargeNumbers() {
                                 // Large numbers
                                 assertEquals(1000, MathUtils.gcd(1000, 1000));
                                 assertEquals(1, MathUtils.gcd(Integer.MAX_VALUE, Integer.MAX_VALUE - 1));
                                 assertEquals(2, MathUtils.gcd(Integer.MIN_VALUE + 2, Integer.MIN_VALUE));
                             }

 @Test
                             public void testGcd_EdgeCases() {
                                 // Edge cases with MIN_VALUE
                                 assertEquals(1, MathUtils.gcd(Integer.MIN_VALUE, Integer.MAX_VALUE));
                                 assertEquals(1 << 30, MathUtils.gcd(Integer.MIN_VALUE, 1 << 30));
                             }

 @Test
                             public void testGcd_RandomCases() {
                                 // Random test cases
                                 assertEquals(6, MathUtils.gcd(54, 24));
                                 assertEquals(12, MathUtils.gcd(48, 180));
                                 assertEquals(1, MathUtils.gcd(35, 64));
                                 assertEquals(7, MathUtils.gcd(49, 21));
                                 assertEquals(14, MathUtils.gcd(42, 56));
                             }

 @Test
                             public void testGcd_EvenAndOddNumbers() {
                                 // Combinations of even and odd numbers
                                 assertEquals(1, MathUtils.gcd(9, 16)); // Both odd and even
                                 assertEquals(2, MathUtils.gcd(10, 6)); // Both even
                                 assertEquals(1, MathUtils.gcd(15, 8)); // Odd and even
                             }

 @Test
                     public void testGcd_OverflowCase() {
                         // Test overflow case (gcd is 2^31)
                         org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                         exceptionRule.expect(ArithmeticException.class);
                         exceptionRule.expectMessage("overflow: gcd is 2^31");
                         MathUtils.gcd(Integer.MIN_VALUE, 0);
                     }

 @Test
                     public void testFactorialLogWithZero() {
                         // Test n = 0 case which should return 0 (log of 0! is 0)
                         // This will catch the mutant that throws exception for n <= 0
                         double result = MathUtils.factorialLog(0);
                         assertEquals(0.0, result, 0.0001);
                     }

 @Test(expected = IllegalArgumentException.class)
                     public void testFactorialLogWithNegative() {
                         // Test negative input which should throw exception
                         MathUtils.factorialLog(-1);
                     }

 @Test
                     public void testFactorialLogWithPositive() {
                         // Test positive input for normal behavior
                         double result = MathUtils.factorialLog(5);
                         double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
                         assertEquals(expected, result, 0.0001);
                     }

 @Test
               public void testFactorialLogNegativeInputExceptionMessage() {
                   // Set up the expected exception
                   ExpectedException exceptionRule = ExpectedException.none();
                   exceptionRule.expect(IllegalArgumentException.class);
                   exceptionRule.expectMessage("must have n > 0 for n!");
                   
                   // Call the method with negative input to trigger the exception
                   MathUtils.factorialLog(-1);
               }

 @Test
               public void testFactorialLog() {
                   // Test n=0 (0! = 1, log(1) = 0)
                   assertEquals(0.0, MathUtils.factorialLog(0), 0.0001);
                   
                   // Test n=1 (1! = 1, log(1) = 0)
                   assertEquals(0.0, MathUtils.factorialLog(1), 0.0001);
                   
                   // Test n=2 (2! = 2, log(2) ≈ 0.6931)
                   assertEquals(Math.log(2), MathUtils.factorialLog(2), 0.0001);
                   
                   // Test n=5 (5! = 120, log(120) ≈ sum of logs from 2 to 5)
                   double expected = 0.0;
                   for (int i = 2; i <= 5; i++) {
                       expected += Math.log(i);
                   }
                   assertEquals(expected, MathUtils.factorialLog(5), 0.0001);
               }

 @Test(expected = IllegalArgumentException.class)
               public void testFactorialLogNegativeInput() {
                   MathUtils.factorialLog(-1);
               }

 @Test
          public void testFactorialLogEdgeCase() {
              // For n=1, original returns 0 (no iterations)
              // Mutant would return log(1) = 0 (same value but different path)
              // We can't directly detect this, but we can test with n=0
              
              assertEquals(0.0, MathUtils.factorialLog(0), 0.0);
              assertEquals(0.0, MathUtils.factorialLog(1), 0.0);
              
              // The real test is with n=2 where both return same value but different computation
              // Since we can't observe the computation, we need to accept this is a weak mutation
              // that doesn't affect the output
              
              // This mutation is actually equivalent and can't be killed by output observation
              // A better test would require instrumentation to count loop iterations
          }

 @Test
         public void testFactorialLogShouldStartFrom() {
             // Test with n=2 - both original and mutant return same value,
             // but we can verify the computation path by checking the number of log operations
             
             // Create a spy of MathUtils
             MathUtils mathUtils = spy(MathUtils.class);
             
             // Counter for log calls
             final int[] callCount = {0};
             
             // Mock Math.log to count calls
             doAnswer(invocation -> {
                 callCount[0]++;
                 return Math.log((double)invocation.getArguments()[0]);
             }).when(mathUtils).factorialLog(anyInt());
             
             // For n=2, original should call log once (for 2), mutant twice (for 1 and 2)
             double result = mathUtils.factorialLog(2);
             assertEquals(0.693147, result, 1e-6);
             
             // Verify only one log call was made (original behavior)
             // This would fail with the mutant which makes two calls
             assertEquals(1, callCount[0]);
         }

 @Test
         public void testFactorialLogDetectsMultiplicationMutant() {
             // Test n=0 (should return 0)
             assertEquals(0.0, MathUtils.factorialLog(0), 0.0001);
             
             // Test n=1 (should return 0)
             assertEquals(0.0, MathUtils.factorialLog(1), 0.0001);
             
             // Test n=2 
             // Original: log(2) ≈ 0.6931
             // Mutant: log(2) ≈ 0.6931 (same for n=2)
             // Need higher n to detect
             
             // Test n=3 - this will detect the mutant
             // Original: log(2) + log(3) ≈ 0.6931 + 1.0986 ≈ 1.7917
             // Mutant: log(2) * log(3) ≈ 0.6931 * 1.0986 ≈ 0.7615
             double expected = Math.log(2) + Math.log(3);
             assertEquals(expected, MathUtils.factorialLog(3), 0.0001);
             
             // Test n=4 for additional verification
             // Original: log(2)+log(3)+log(4) ≈ 0.6931+1.0986+1.3863 ≈ 3.1780
             // Mutant: log(2)*log(3)*log(4) ≈ 0.6931*1.0986*1.3863 ≈ 1.0556
             expected += Math.log(4);
             assertEquals(expected, MathUtils.factorialLog(4), 0.0001);
         }

 @Test(expected = IllegalArgumentException.class)
         public void testFactorialLogNegativeInput1() {
             MathUtils.factorialLog(-1);
         }

 @Test
        public void testFactorialLogWithZero1() {
            // This test will catch the mutant by verifying n=0 returns 0
            // Mutated version would throw exception instead
            double result = MathUtils.factorialLog(0);
            assertEquals(0.0, result, 0.000001);
        }

 @Test(expected = IllegalArgumentException.class)
        public void testFactorialLogWithNegative1() {
            // Verify exception is thrown for negative input
            MathUtils.factorialLog(-1);
        }

 @Test
        public void testFactorialLogWithOne() {
            // Additional test case for n=1 which should also return 0
            double result = MathUtils.factorialLog(1);
            assertEquals(0.0, result, 0.000001);
        }

 @Test
        public void testFactorialLogWithPositive1() {
            // Test normal case to ensure basic functionality works
            double result = MathUtils.factorialLog(5);
            double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
            assertEquals(expected, result, 0.000001);
        }

 @Test
       public void testFactorialLogNegativeInputExceptionMessage1() {
           // Set up the expected exception with the exact message
           thrown.expect(IllegalArgumentException.class);
           thrown.expectMessage("must have n > 0 for n!");
           
           // Call the method with a negative input to trigger the exception
           MathUtils.factorialLog(-1);
       }

 @Test
       public void testFactorialLogZeroInput() {
           // 0! is 1, and ln(1) is 0
           double result = MathUtils.factorialLog(0);
           assertEquals(0.0, result, 0.0001);
       }

 @Test
       public void testFactorialLogPositiveInput() {
           // Test with n=5: ln(2) + ln(3) + ln(4) + ln(5)
           double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
           double result = MathUtils.factorialLog(5);
           assertEquals(expected, result, 0.0001);
       }

 @Test
       public void testFactorialLogOneInput() {
           // 1! is 1, and ln(1) is 0, and the loop doesn't execute (i starts at 2)
           double result = MathUtils.factorialLog(1);
           assertEquals(0.0, result, 0.0001);
       }

 @Test
      public void testFactorialLogForN() {
          // Test with n=2 where the mutant behavior differs
          double expected = Math.log(2); // Correct: only log(2)
          double actual = MathUtils.factorialLog(2);
          
          // The mutant would return log(1) + log(2) = 0 + log(2) = log(2)
          // Wait - this shows the mutant isn't caught for n=2!
          // We need a case where n >=3 to see the difference
          
          // Let's modify to test n=3 instead
          expected = Math.log(2) + Math.log(3); // Correct sum
          actual = MathUtils.factorialLog(3);
          assertEquals("Sum of logs from 2 to 3", expected, actual, 1e-10);
          
          // The mutant would return log(1)+log(2)+log(3) which equals log(2)+log(3)
          // Still same result! This shows the mutant isn't detectable for any n
          
          // Wait - this suggests the mutant is actually equivalent!
          // Since log(1) = 0, adding it makes no difference
          
          // Therefore, this mutant is actually an equivalent mutant and cannot be killed
          // by any test case because the behavior is identical
          
          // However, if we want to enforce the exact implementation (starting from 2),
          // we could test the internal behavior through side effects or logging,
          // but that would be testing implementation rather than behavior
          
          // Conclusion: This is an equivalent mutant that cannot be killed by
          // behavioral tests since log(1) = 0 doesn't affect the result
      }

 @Test
     public void testFactorialLogWithZero2() {
         // Test that factorialLog(0) returns 0 and doesn't throw exception
         double result = MathUtils.factorialLog(0);
         assertEquals(0.0, result, 0.000001);
     }

 @Test(expected = IllegalArgumentException.class)
     public void testFactorialLogWithNegative2() {
         // Test that negative input throws exception
         MathUtils.factorialLog(-1);
     }

 @Test
     public void testFactorialLogWithOne1() {
         // Test that factorialLog(1) returns 0
         double result = MathUtils.factorialLog(1);
         assertEquals(0.0, result, 0.000001);
     }

 @Test
     public void testFactorialLogWithPositive2() {
         // Test normal case
         double result = MathUtils.factorialLog(5);
         double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
         assertEquals(expected, result, 0.000001);
     }

}
