package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.ConvergenceException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class UnivariateRealSolverUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                     public void testBracket_ValidRootFound() throws Exception {
                                                                                                                         // Mock a function that crosses zero between 1 and 2
                                                                                                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                         when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                         when(function.value(2.0)).thenReturn(1.0);
                                                                                                                         
                                                                                                                         double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 0.0, 3.0);
                                                                                                                         
                                                                                                                         assertNotNull(result);
                                                                                                                         assertEquals(2, result.length);
                                                                                                                         assertTrue(result[0] < result[1]);
                                                                                                                         assertTrue(function.value(result[0]) * function.value(result[1]) <= 0);
                                                                                                                     }

    @Test
                                                                                                                     public void testBracket_InitialPointIsRoot() throws Exception {
                                                                                                                         // Mock a function where initial point is already a root
                                                                                                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                         when(function.value(1.5)).thenReturn(0.0);
                                                                                                                         
                                                                                                                         double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 0.0, 3.0);
                                                                                                                         
                                                                                                                         assertNotNull(result);
                                                                                                                         assertEquals(2, result.length);
                                                                                                                         assertEquals(0.0, function.value(result[0]), 0.0001);
                                                                                                                     }

    @Test
                                                                                                                     public void testBracket_EdgeCaseBounds() throws Exception {
                                                                                                                         // Test when initial is exactly at lower or upper bound
                                                                                                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                         when(function.value(0.0)).thenReturn(-1.0);
                                                                                                                         when(function.value(1.0)).thenReturn(1.0);
                                                                                                                         
                                                                                                                         double[] result1 = UnivariateRealSolverUtils.bracket(function, 0.0, 0.0, 1.0);
                                                                                                                         assertNotNull(result1);
                                                                                                                         
                                                                                                                         double[] result2 = UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 1.0);
                                                                                                                         assertNotNull(result2);
                                                                                                                     }

    @Test
                                                                                                                     public void testBracket_ConvergesQuickly() throws Exception {
                                                                                                                         // Mock a function that will bracket quickly
                                                                                                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                         when(function.value(1.0)).thenReturn(-0.5);
                                                                                                                         when(function.value(1.5)).thenReturn(0.5);
                                                                                                                         
                                                                                                                         double[] result = UnivariateRealSolverUtils.bracket(function, 1.25, 1.0, 2.0);
                                                                                                                         
                                                                                                                         assertNotNull(result);
                                                                                                                         assertEquals(1.0, result[0], 0.0001);
                                                                                                                         assertEquals(1.5, result[1], 0.0001);
                                                                                                                     }

    @Test
                                                                                                             public void testBracket_InitialOutsideBounds() throws Exception {
                                                                                                                 UnivariateRealFunction function = new UnivariateRealFunction() {
                                                                                                                     public double value(double x) {
                                                                                                                         return 0;
                                                                                                                     }
                                                                                                                 };
                                                                                                                 
                                                                                                                 try {
                                                                                                                     UnivariateRealSolverUtils.bracket(function, -1.0, 0.0, 3.0);
                                                                                                                     fail("Expected IllegalArgumentException");
                                                                                                                 } catch (IllegalArgumentException e) {
                                                                                                                     // expected
                                                                                                                 }
                                                                                                             }

    @Test
                                                                                                             public void testBracket_NullFunction() throws Exception {
                                                                                                                 org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                 exception.expect(NullPointerException.class);
                                                                                                                 UnivariateRealSolverUtils.bracket(null, 1.5, 0.0, 3.0);
                                                                                                             }

    @Test
                                                                                                     public void testBracket_NoRootInBounds() throws Exception {
                                                                                                         // Mock a function that doesn't cross zero in bounds
                                                                                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                         when(function.value(anyDouble())).thenReturn(1.0);
                                                                                                         
                                                                                                         try {
                                                                                                             UnivariateRealSolverUtils.bracket(function, 1.5, 0.0, 3.0);
                                                                                                             fail("Expected IllegalArgumentException");
                                                                                                         } catch (IllegalArgumentException e) {
                                                                                                             // Expected exception
                                                                                                         }
                                                                                                     }

    @Test
                                                                     public void testBracket_InvalidBounds() throws Exception {
                                                                         // Setup
                                                                         org.apache.commons.math.analysis.UnivariateRealFunction function = new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                             public double value(double x) {
                                                                                 return x; // Simple linear function for testing
                                                                             }
                                                                         };
                                                                         
                                                                         try {
                                                                             // Test
                                                                             org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(
                                                                                 function, 1.5, 3.0, 0.0);
                                                                             fail("Expected IllegalArgumentException");
                                                                         } catch (IllegalArgumentException e) {
                                                                             // Verify
                                                                             assertEquals("invalid bracketing parameters", e.getMessage());
                                                                         }
                                                                     }

    @Test
                                                                 public void testBracket_InitialEqualsLowerBound() throws FunctionEvaluationException, ConvergenceException {
                                                                     UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                     when(function.value(0.0)).thenReturn(-1.0);
                                                                     when(function.value(1.0)).thenReturn(1.0);
                                                                     
                                                                     double[] result = UnivariateRealSolverUtils.bracket(function, 0.0, 0.0, 2.0, 100);
                                                                     assertArrayEquals(new double[]{0.0, 1.0}, result, 0.0001);
                                                                 }

    @Test
                                                                 public void testBracket_InitialEqualsUpperBound() throws FunctionEvaluationException, ConvergenceException {
                                                                     UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                     when(function.value(2.0)).thenReturn(1.0);
                                                                     when(function.value(1.0)).thenReturn(-1.0);
                                                                     
                                                                     double[] result = UnivariateRealSolverUtils.bracket(function, 2.0, 0.0, 2.0, 100);
                                                                     assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
                                                                 }

    @Test
                                                                 public void testBracket_SuccessfulBracketing() throws FunctionEvaluationException, ConvergenceException {
                                                                     UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                     // Setup function values to change sign between 1.0 and 2.0
                                                                     when(function.value(1.0)).thenReturn(-0.5);
                                                                     when(function.value(1.5)).thenReturn(-0.2);
                                                                     when(function.value(2.0)).thenReturn(0.5);
                                                                     
                                                                     double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 0.0, 3.0, 100);
                                                                     assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
                                                                 }

    @Test
                                                                 public void testBracket_ImmediateBracketing() throws FunctionEvaluationException, ConvergenceException {
                                                                     UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                     // Initial points already bracket the root
                                                                     when(function.value(1.0)).thenReturn(-1.0);
                                                                     when(function.value(1.5)).thenReturn(0.0);
                                                                     when(function.value(2.0)).thenReturn(1.0);
                                                                     
                                                                     double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 1.0, 2.0, 100);
                                                                     assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
                                                                 }

    @Test
                                                                 public void testBracket_MinimalIterationsNeeded() throws FunctionEvaluationException, ConvergenceException {
                                                                     UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                     // Will bracket after first expansion
                                                                     when(function.value(1.0)).thenReturn(1.0);
                                                                     when(function.value(1.5)).thenReturn(1.0);
                                                                     when(function.value(2.0)).thenReturn(-1.0);
                                                                     
                                                                     double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 1.0, 3.0, 100);
                                                                     assertArrayEquals(new double[]{1.5, 2.0}, result, 0.0001);
                                                                 }

    @Test
                                                                 public void testBracket_ReachesBoundsWithoutBracketing() throws FunctionEvaluationException, ConvergenceException {
                                                                     // Setup expected exception
                                                                     ExpectedException exception = ExpectedException.none();
                                                                     exception.expect(org.apache.commons.math.ConvergenceException.class);
                                                                     
                                                                     // Create mock using Mockito
                                                                     UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                     
                                                                     // Function values remain positive but approach zero
                                                                     when(function.value(0.0)).thenReturn(0.1);
                                                                     when(function.value(1.0)).thenReturn(0.05);
                                                                     when(function.value(2.0)).thenReturn(0.01);
                                                                     
                                                                     // Test the bracket method
                                                                     UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 100);
                                                                 }

    @Test
                                                             public void testBracket_NullFunction1() {
                                                                 try {
                                                                     UnivariateRealSolverUtils.bracket(null, 1.0, 0.0, 2.0, 100);
                                                                     fail("Expected IllegalArgumentException");
                                                                 } catch (IllegalArgumentException e) {
                                                                     assertEquals("function is null", e.getMessage());
                                                                 } catch (org.apache.commons.math.FunctionEvaluationException e) {
                                                                     // This shouldn't happen in this test case
                                                                     fail("Unexpected FunctionEvaluationException: " + e.getMessage());
                                                                 } catch (org.apache.commons.math.ConvergenceException e) {
                                                                     // This shouldn't happen in this test case
                                                                     fail("Unexpected ConvergenceException: " + e.getMessage());
                                                                 }
                                                             }

    @Test
                                                             public void testBracket_InvalidBracketingParameters() {
                                                                 UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                 try {
                                                                     UnivariateRealSolverUtils.bracket(function, -1.0, 0.0, 2.0, 100);
                                                                     fail("Expected IllegalArgumentException");
                                                                 } catch (FunctionEvaluationException e) {
                                                                     fail("Unexpected FunctionEvaluationException");
                                                                 } catch (ConvergenceException e) {
                                                                     // This is acceptable as it might happen before parameter validation
                                                                 } catch (IllegalArgumentException e) {
                                                                     assertTrue(e.getMessage().contains("invalid bracketing parameters"));
                                                                 }
                                                             }

    @Test
                                                             public void testBracket_ConvergenceFailure() throws org.apache.commons.math.ConvergenceException, org.apache.commons.math.FunctionEvaluationException {
                                                                 org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                 exception.expect(org.apache.commons.math.ConvergenceException.class);
                                                                 
                                                                 org.apache.commons.math.analysis.UnivariateRealFunction function = 
                                                                     new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                         @Override
                                                                         public double value(double x) {
                                                                             return 1.0;  // Always return positive value
                                                                         }
                                                                     };
                                                                 
                                                                 org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(
                                                                     function, 1.5, 0.0, 3.0, 10);
                                                             }

    @Test
                                                         public void testBracket_InvalidMaxIterations() throws ConvergenceException, FunctionEvaluationException {
                                                             ExpectedException exception = ExpectedException.none();
                                                             exception.expect(IllegalArgumentException.class);
                                                             exception.expectMessage("bad value for maximum iterations number: 0");
                                                             
                                                             UnivariateRealFunction function = new UnivariateRealFunction() {
                                                                 public double value(double x) {
                                                                     return x; // Simple linear function that won't cause convergence issues
                                                                 }
                                                             };
                                                             UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 0);
                                                         }

    @Test
                                                     public void testBracketIterationCount() throws Exception {
                                                         // Create a function that requires multiple iterations to bracket
                                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                         when(function.value(anyDouble())).thenAnswer(invocation -> {
                                                             double x = invocation.getArgument(0);
                                                             return x * x - 2;  // Root at sqrt(2) ~ 1.414
                                                         });
                                                     
                                                         double initial = 1.0;
                                                         double lowerBound = 0.0;
                                                         double upperBound = 2.0;
                                                     
                                                         // Call the method
                                                         double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound);
                                                     
                                                         // Verify the result is valid (brackets the root)
                                                         assertTrue(result[0] < Math.sqrt(2));
                                                         assertTrue(result[1] > Math.sqrt(2));
                                                         
                                                         // Verify the number of iterations by checking the range size
                                                         // The original would do more iterations (smaller steps) while mutant would do fewer
                                                         double rangeSize = result[1] - result[0];
                                                         // Expect relatively small range from proper iteration
                                                         assertTrue(rangeSize < 0.5);  // This would fail with mutant as it would do fewer iterations
                                                     }

    @Test
                                                         public void testBracketIterationCountDetectsMutant() throws Exception {
                                                             // Setup a function that will require exactly 4 iterations to bracket
                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                             when(function.value(anyDouble())).thenAnswer(invocation -> {
                                                                 double x = invocation.getArgument(0);
                                                                 // Function crosses zero at x = 2.0
                                                                 return x - 2.0;
                                                             });
                                                     
                                                             double initial = 1.0;
                                                             double lowerBound = 0.0;
                                                             double upperBound = 5.0;
                                                             int maximumIterations = 5; // Just above what we need
                                                     
                                                             try {
                                                                 double[] result = UnivariateRealSolverUtils.bracket(
                                                                     function, initial, lowerBound, upperBound, maximumIterations);
                                                                 
                                                                 // Verify the iteration count by checking the bracket size
                                                                 // Original: 4 iterations (a=0.0, b=3.0)
                                                                 // Mutant: 2 iterations (a=0.0, b=3.0) but reports 4
                                                                 double a = result[0];
                                                                 double b = result[1];
                                                                 
                                                                 // Original would have a=0.0, b=3.0 after 4 iterations
                                                                 // Mutant would reach same values but report 4 iterations after only 2 actual loops
                                                                 // So we verify the bracket is tight enough to confirm proper iteration count
                                                                 assertTrue(b - a <= 3.0); // Original would be exactly 3.0
                                                             } catch (ConvergenceException e) {
                                                                 // Check the iteration count in the exception message
                                                                 String msg = e.getMessage();
                                                                 assertTrue(msg.contains("number of iterations=4"));
                                                             }
                                                         }

    @Test(expected = ConvergenceException.class)
                                                         public void testBracketFailsWithOddIterationCount() throws Exception {
                                                             // This test will make the mutant fail where original would pass
                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                             when(function.value(anyDouble())).thenReturn(1.0); // Never crosses zero
                                                     
                                                             double initial = 1.0;
                                                             double lowerBound = 0.0;
                                                             double upperBound = 5.0;
                                                             int maximumIterations = 3; // Odd number
                                                     
                                                             // Original: 3 iterations then throw
                                                             // Mutant: 2 actual iterations (reports 4) but hits bounds first
                                                             UnivariateRealSolverUtils.bracket(
                                                                 function, initial, lowerBound, upperBound, maximumIterations);
                                                         }

    @Test
                                                        public void testBracketWithZeroFunctionValue() throws Exception {
                                                            // Setup mock function that returns zero at x=2.0 and non-zero elsewhere
                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                            when(function.value(1.0)).thenReturn(1.0);  // f(1) = 1
                                                            when(function.value(2.0)).thenReturn(0.0);  // f(2) = 0 (critical point)
                                                            when(function.value(3.0)).thenReturn(-1.0); // f(3) = -1
                                                            
                                                            // Test parameters
                                                            double initial = 2.0;
                                                            double lowerBound = 1.0;
                                                            double upperBound = 3.0;
                                                            int maxIterations = 10;
                                                            
                                                            // Call the method - should return [1,3] since f(1)*f(3) = -1 < 0
                                                            double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
                                                            
                                                            // Verify the result contains proper bracketing interval
                                                            assertEquals(1.0, result[0], 0.0001);
                                                            assertEquals(3.0, result[1], 0.0001);
                                                            
                                                            // Verify the function was called properly
                                                            verify(function).value(1.0);
                                                            verify(function).value(2.0);
                                                            verify(function).value(3.0);
                                                        }

    @Test
                                                   public void testBracketDetectsZeroFunctionValue() {
                                                       // Create a function that equals zero at x=2.0
                                                       UnivariateRealFunction function = new UnivariateRealFunction() {
                                                           public double value(double x) throws FunctionEvaluationException {
                                                               return x - 2.0;  // zero at x=2.0
                                                           }
                                                       };
                                                       
                                                       double initial = 1.0;
                                                       double lowerBound = 0.0;
                                                       double upperBound = 3.0;
                                                       int maxIterations = 100;
                                                       
                                                       // Call the bracket method
                                                       double[] result;
                                                       try {
                                                           result = UnivariateRealSolverUtils.bracket(
                                                               function, initial, lowerBound, upperBound, maxIterations);
                                                       } catch (ConvergenceException e) {
                                                           fail("ConvergenceException thrown: " + e.getMessage());
                                                           return;
                                                       } catch (FunctionEvaluationException e) {
                                                           fail("FunctionEvaluationException thrown: " + e.getMessage());
                                                           return;
                                                       }
                                                       
                                                       // Verify the result contains the zero point
                                                       double a = result[0];
                                                       double b = result[1];
                                                       double fa, fb;
                                                       try {
                                                           fa = function.value(a);
                                                           fb = function.value(b);
                                                       } catch (FunctionEvaluationException e) {
                                                           fail("FunctionEvaluationException thrown: " + e.getMessage());
                                                           return;
                                                       }
                                                       
                                                       // Original behavior would ensure fa*fb <= 0
                                                       // Mutated version might miss this if fa or fb is exactly zero
                                                       assertTrue("Should bracket the zero point", fa * fb <= 0);
                                                       
                                                       // Additional check to ensure we found the exact zero point
                                                       // Either a or b should be exactly 2.0 (or very close)
                                                       try {
                                                           assertTrue("Should find exact zero point", 
                                                               Math.abs(function.value(a)) < 1e-10 || 
                                                               Math.abs(function.value(b)) < 1e-10);
                                                       } catch (FunctionEvaluationException e) {
                                                           fail("FunctionEvaluationException thrown: " + e.getMessage());
                                                       }
                                                   }

    @Test
                                                   public void testBracketIterationCountDetectsMutation() throws Exception {
                                                       // Setup mock function that changes sign after 3 expansions
                                                       UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                       when(function.value(anyDouble())).thenAnswer(invocation -> {
                                                           double x = invocation.getArgument(0);
                                                           // f(x) = x - 2.5 (changes sign at x=2.5)
                                                           return x - 2.5;
                                                       });
                                               
                                                       // Test parameters that will require multiple iterations
                                                       double initial = 0.0;
                                                       double lowerBound = -10.0;
                                                       double upperBound = 10.0;
                                                       int maximumIterations = 100;
                                               
                                                       try {
                                                           double[] result = UnivariateRealSolverUtils.bracket(
                                                               function, initial, lowerBound, upperBound, maximumIterations);
                                                           
                                                           // Verify iteration count by checking the bracket size
                                                           // Original would take about 3 iterations to bracket 2.5 from 0.0
                                                           double bracketSize = result[1] - result[0];
                                                           assertTrue("Bracket should be reasonably small", bracketSize < 4.0);
                                                           
                                                       } catch (ConvergenceException e) {
                                                           // For the mutant case, check if exception contains wrong iteration count
                                                           String msg = e.getMessage();
                                                           assertFalse("Mutation detected - iteration count going down", 
                                                                      msg.contains("number of iterations=1"));
                                                       }
                                                   }

    @Test
                          public void testBracketWithIterationCount() {
                              // Mock a function that requires multiple iterations to bracket
                              UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                              try {
                                  when(function.value(anyDouble())).thenAnswer(invocation -> {
                                      try {
                                          double x = invocation.getArgument(0);
                                          return x * x - 2; // Root at sqrt(2) ~ 1.414
                                      } catch (Exception e) {
                                          throw new RuntimeException(e);
                                      }
                                  });
                              } catch (FunctionEvaluationException e) {
                                  fail("Mock setup failed: " + e.getMessage());
                              }
                              
                              double initial = 1.0;
                              double lowerBound = 0.0;
                              double upperBound = 2.0;
                              
                              // Call the method through reflection since it's private
                              try {
                                  Method bracketMethod = UnivariateRealSolverUtils.class.getDeclaredMethod(
                                      "bracket", 
                                      UnivariateRealFunction.class, 
                                      double.class, 
                                      double.class, 
                                      double.class
                                  );
                                  bracketMethod.setAccessible(true);
                                  
                                  double[] result = (double[]) bracketMethod.invoke(
                                      null, 
                                      function, 
                                      initial, 
                                      lowerBound, 
                                      upperBound
                                  );
                              
                                  // Verify the bracket contains the root
                                  double root = Math.sqrt(2);
                                  assertTrue("Bracket should contain root", 
                                      result[0] <= root && root <= result[1]);
                                  
                                  // Verify the bracket is reasonable (not too wide)
                                  assertTrue("Bracket width should be reasonable", 
                                      result[1] - result[0] < 1.0);
                                      
                              } catch (Exception e) {
                                  fail("Reflection failed: " + e.getMessage());
                              }
                          }

    @Test
             public void testBracketWithIterationLimit() throws FunctionEvaluationException {
                 // Mock the function that will force multiple iterations
                 UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                 when(function.value(anyDouble())).thenReturn(-1.0, -1.0, -1.0, 1.0); // First 3 calls return -1, then 1
                 
                 double initial = 0.0;
                 double lowerBound = -10.0;
                 double upperBound = 10.0;
                 int maxIterations = 3; // Small number to test iteration counting
                 
                 try {
                     // This should throw an exception when max iterations is reached
                     UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
                     fail("Expected MaxIterationsExceededException");
                 } catch (org.apache.commons.math.MaxIterationsExceededException e) {
                     // Verify the exception message contains the correct iteration count
                     assertTrue(e.getMessage().contains(String.valueOf(maxIterations)));
                 } catch (ConvergenceException e) {
                     fail("Unexpected ConvergenceException");
                 }
                 
                 // Verify the function was called the expected number of times
                 verify(function, times(maxIterations * 2)).value(anyDouble());
             }

    @Test
         public void testBracketIterationCountWhenMaxIterationsReached() throws FunctionEvaluationException {
             // Setup
             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
             when(function.value(anyDouble())).thenReturn(1.0); // Always positive, will never bracket
             
             double initial = 5.0;
             double lowerBound = 0.0;
             double upperBound = 10.0;
             int maximumIterations = 3; // Small number to quickly reach max iterations
             
             try {
                 // Exercise
                 UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maximumIterations);
             } catch (ConvergenceException e) {
                 // Verify
                 String message = e.getMessage();
                 assertTrue("Exception message should contain iteration count", 
                           message.contains("number of iterations=3"));
             }
         }

    @Test
    public void testBracketLoopTermination() {
        // Mock a function that initially doesn't bracket a root
        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
        try {
            when(function.value(anyDouble())).thenReturn(1.0); // Always positive
        } catch (FunctionEvaluationException e) {
            fail("Mock setup should not throw exception");
        }
        
        // Set bounds and a small max iterations to test termination
        double initial = 0.0;
        double lowerBound = -10.0;
        double upperBound = 10.0;
        int maxIterations = 5;
        
        try {
            // This should throw an exception when it can't bracket the root
            UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
            fail("Expected exception not thrown");
        } catch (Exception e) {
            // Verify it's the expected exception type
            assertTrue(e instanceof ConvergenceException);
            
            // The key assertion - if we get here with this exception,
            // it means the loop terminated properly (original behavior)
            // The mutant would either:
            // - Not enter the loop at all (no exception)
            // - Enter infinite loop (test would timeout)
        }
    }

    @Test
    public void testBracketLoopTerminationWithMaxIterations() throws FunctionEvaluationException {
        // Create a mock function that always returns positive values
        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
        when(function.value(anyDouble())).thenReturn(1.0);
        
        double initial = 5.0;
        double lowerBound = 0.0;
        double upperBound = 10.0;
        int maximumIterations = 3;  // Set a small number of iterations
        
        try {
            double[] result = UnivariateRealSolverUtils.bracket(
                function, initial, lowerBound, upperBound, maximumIterations);
            
            // The test should reach here only with original code
            // Verify the loop exited due to max iterations being reached
            // by checking the iteration count through the bounds expansion
            // Since we mock all function values as positive, the only way to exit
            // is by reaching max iterations (original) or bounds being exhausted (mutant)
            double a = result[0];
            double b = result[1];
            
            // In original code after 3 iterations:
            // a should be max(5-3, 0) = 2.0
            // b should be min(5+3, 10) = 8.0
            assertEquals(2.0, a, 0.0001);
            assertEquals(8.0, b, 0.0001);
            
        } catch (ConvergenceException e) {
            // This is expected for original code since fa*fb > 0
            // Verify the exception contains the correct iteration count
            assertTrue(e.getMessage().contains("number of iterations=3"));
        }
    }


}
