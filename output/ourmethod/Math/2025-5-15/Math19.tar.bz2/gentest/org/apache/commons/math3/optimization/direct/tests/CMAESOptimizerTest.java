package gentest.org.apache.commons.math3.optimization.direct.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.direct.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathUnsupportedOperationException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.GoalType;
import org.apache.commons.math3.optimization.MultivariateOptimizer;
import org.apache.commons.math3.optimization.PointValuePair;
import org.apache.commons.math3.optimization.SimpleValueChecker;
import org.apache.commons.math3.random.MersenneTwister;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.util.MathArrays;
 
public class CMAESOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                    public void testCheckParameters_AllInfiniteBounds() throws Exception {
                                                                                                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(10);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to mock methods
                                                                                                                                                                                                                                                                                        Method getLowerBound = CMAESOptimizer.class.getDeclaredMethod("getLowerBound");
                                                                                                                                                                                                                                                                                        Method getUpperBound = CMAESOptimizer.class.getDeclaredMethod("getUpperBound");
                                                                                                                                                                                                                                                                                        Method getStartPoint = CMAESOptimizer.class.getDeclaredMethod("getStartPoint");
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        getLowerBound.setAccessible(true);
                                                                                                                                                                                                                                                                                        getUpperBound.setAccessible(true);
                                                                                                                                                                                                                                                                                        getStartPoint.setAccessible(true);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Mock methods to return infinite bounds
                                                                                                                                                                                                                                                                                        when(getLowerBound.invoke(optimizer)).thenReturn(new double[]{Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY});
                                                                                                                                                                                                                                                                                        when(getUpperBound.invoke(optimizer)).thenReturn(new double[]{Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY});
                                                                                                                                                                                                                                                                                        when(getStartPoint.invoke(optimizer)).thenReturn(new double[]{0, 0});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to call private checkParameters method
                                                                                                                                                                                                                                                                                        Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                                        checkParameters.setAccessible(true);
                                                                                                                                                                                                                                                                                        checkParameters.invoke(optimizer);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to access private boundaries field
                                                                                                                                                                                                                                                                                        Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                                        boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                                                        double[][] boundaries = (double[][]) boundariesField.get(optimizer);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        assertNull(boundaries);
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                    public void testCheckParameters_MixedFiniteAndInfiniteBounds_ThrowsException() throws Exception {
                                                                                                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(10);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to access private methods
                                                                                                                                                                                                                                                                                        Method getLowerBound = CMAESOptimizer.class.getDeclaredMethod("getLowerBound");
                                                                                                                                                                                                                                                                                        getLowerBound.setAccessible(true);
                                                                                                                                                                                                                                                                                        Method getUpperBound = CMAESOptimizer.class.getDeclaredMethod("getUpperBound");
                                                                                                                                                                                                                                                                                        getUpperBound.setAccessible(true);
                                                                                                                                                                                                                                                                                        Method getStartPoint = CMAESOptimizer.class.getDeclaredMethod("getStartPoint");
                                                                                                                                                                                                                                                                                        getStartPoint.setAccessible(true);
                                                                                                                                                                                                                                                                                        Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                                        checkParameters.setAccessible(true);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Mock methods to return mixed bounds
                                                                                                                                                                                                                                                                                        when(getLowerBound.invoke(optimizer)).thenReturn(new double[]{-10, Double.NEGATIVE_INFINITY});
                                                                                                                                                                                                                                                                                        when(getUpperBound.invoke(optimizer)).thenReturn(new double[]{10, Double.POSITIVE_INFINITY});
                                                                                                                                                                                                                                                                                        when(getStartPoint.invoke(optimizer)).thenReturn(new double[]{0, 0});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        thrown.expect(MathUnsupportedOperationException.class);
                                                                                                                                                                                                                                                                                        checkParameters.invoke(optimizer);
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                    public void testCheckParameters_AllFiniteBounds() throws Exception {
                                                                                                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(10);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Mock methods to return finite bounds using reflection
                                                                                                                                                                                                                                                                                        Method setLowerBound = CMAESOptimizer.class.getDeclaredMethod("setLowerBound", double[].class);
                                                                                                                                                                                                                                                                                        setLowerBound.setAccessible(true);
                                                                                                                                                                                                                                                                                        setLowerBound.invoke(optimizer, new Object[]{new double[]{-10, -20}});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        Method setUpperBound = CMAESOptimizer.class.getDeclaredMethod("setUpperBound", double[].class);
                                                                                                                                                                                                                                                                                        setUpperBound.setAccessible(true);
                                                                                                                                                                                                                                                                                        setUpperBound.invoke(optimizer, new Object[]{new double[]{10, 20}});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        Method setStartPoint = CMAESOptimizer.class.getDeclaredMethod("setStartPoint", double[].class);
                                                                                                                                                                                                                                                                                        setStartPoint.setAccessible(true);
                                                                                                                                                                                                                                                                                        setStartPoint.invoke(optimizer, new Object[]{new double[]{0, 0}});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Call private checkParameters method using reflection
                                                                                                                                                                                                                                                                                        Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                                        checkParameters.setAccessible(true);
                                                                                                                                                                                                                                                                                        checkParameters.invoke(optimizer);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Access private boundaries field using reflection
                                                                                                                                                                                                                                                                                        Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                                        boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                                                        double[][] boundaries = (double[][]) boundariesField.get(optimizer);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        assertNotNull(boundaries);
                                                                                                                                                                                                                                                                                        assertArrayEquals(new double[]{-10, -20}, boundaries[0], 0.0);
                                                                                                                                                                                                                                                                                        assertArrayEquals(new double[]{10, 20}, boundaries[1], 0.0);
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                    public void testCheckParameters_BoundDifferenceOverflow_ThrowsException() throws Exception {
                                                                                                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(10);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to mock private fields since we can't mock methods directly
                                                                                                                                                                                                                                                                                        Field lowerBoundField = CMAESOptimizer.class.getDeclaredField("lowerBound");
                                                                                                                                                                                                                                                                                        lowerBoundField.setAccessible(true);
                                                                                                                                                                                                                                                                                        lowerBoundField.set(optimizer, new double[]{-Double.MAX_VALUE});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        Field upperBoundField = CMAESOptimizer.class.getDeclaredField("upperBound");
                                                                                                                                                                                                                                                                                        upperBoundField.setAccessible(true);
                                                                                                                                                                                                                                                                                        upperBoundField.set(optimizer, new double[]{Double.MAX_VALUE});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        Field startPointField = CMAESOptimizer.class.getDeclaredField("startPoint");
                                                                                                                                                                                                                                                                                        startPointField.setAccessible(true);
                                                                                                                                                                                                                                                                                        startPointField.set(optimizer, new double[]{0});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        thrown.expect(NumberIsTooLargeException.class);
                                                                                                                                                                                                                                                                                        thrown.expectMessage(LocalizedFormats.OVERFLOW.getSourceString());
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to call private method
                                                                                                                                                                                                                                                                                        Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                                        checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                        checkParametersMethod.invoke(optimizer);
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                    public void testCheckParameters_InputSigmaDimensionMismatch_ThrowsException() throws Exception {
                                                                                                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(10, new double[]{1.0});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Mock methods to return different dimension start point
                                                                                                                                                                                                                                                                                        CMAESOptimizer optimizerSpy = spy(optimizer);
                                                                                                                                                                                                                                                                                        when(optimizerSpy.getLowerBound()).thenReturn(new double[]{-10, -20});
                                                                                                                                                                                                                                                                                        when(optimizerSpy.getUpperBound()).thenReturn(new double[]{10, 20});
                                                                                                                                                                                                                                                                                        when(optimizerSpy.getStartPoint()).thenReturn(new double[]{0, 0});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        thrown.expect(DimensionMismatchException.class);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to access private checkParameters method
                                                                                                                                                                                                                                                                                        Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                                        checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                        checkParametersMethod.invoke(optimizerSpy);
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                    public void testCheckParameters_NegativeInputSigma_ThrowsException() throws Exception {
                                                                                                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(10, new double[]{-1.0});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Mock methods to return matching dimensions
                                                                                                                                                                                                                                                                                        when(optimizer.getLowerBound()).thenReturn(new double[]{-10});
                                                                                                                                                                                                                                                                                        when(optimizer.getUpperBound()).thenReturn(new double[]{10});
                                                                                                                                                                                                                                                                                        when(optimizer.getStartPoint()).thenReturn(new double[]{0});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        thrown.expect(NotPositiveException.class);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                                                                                                                                                        Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                                        checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                        checkParametersMethod.invoke(optimizer);
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                    public void testCheckParameters_InputSigmaExceedsBoundRange_ThrowsException() throws Exception {
                                                                                                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(10, new double[]{25.0});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Mock methods to return finite bounds
                                                                                                                                                                                                                                                                                        when(optimizer.getLowerBound()).thenReturn(new double[]{-10});
                                                                                                                                                                                                                                                                                        when(optimizer.getUpperBound()).thenReturn(new double[]{10});
                                                                                                                                                                                                                                                                                        when(optimizer.getStartPoint()).thenReturn(new double[]{0});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        thrown.expect(OutOfRangeException.class);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to access private checkParameters method
                                                                                                                                                                                                                                                                                        Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                                        checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                        checkParametersMethod.invoke(optimizer);
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                    public void testCheckParameters_ValidInputSigmaWithinBounds() throws Exception {
                                                                                                                                                                                                                                                                                        double[] inputSigma = {5.0};
                                                                                                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(10, inputSigma);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Mock methods to return finite bounds
                                                                                                                                                                                                                                                                                        CMAESOptimizer optimizerSpy = spy(optimizer);
                                                                                                                                                                                                                                                                                        when(optimizerSpy.getLowerBound()).thenReturn(new double[]{-10});
                                                                                                                                                                                                                                                                                        when(optimizerSpy.getUpperBound()).thenReturn(new double[]{10});
                                                                                                                                                                                                                                                                                        when(optimizerSpy.getStartPoint()).thenReturn(new double[]{0});
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to call private checkParameters method
                                                                                                                                                                                                                                                                                        Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                                        checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                        checkParametersMethod.invoke(optimizerSpy);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to access private boundaries field
                                                                                                                                                                                                                                                                                        Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                                        boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                                                        double[][] boundaries = (double[][]) boundariesField.get(optimizerSpy);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        assertNotNull(boundaries);
                                                                                                                                                                                                                                                                                        assertArrayEquals(new double[]{-10}, boundaries[0], 0.0);
                                                                                                                                                                                                                                                                                        assertArrayEquals(new double[]{10}, boundaries[1], 0.0);
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                               public void testCheckParametersWithNullInitDetectsMutant() throws Exception {
                                                                                                                                                                                                                                                                                   // Setup test data
                                                                                                                                                                                                                                                                                   double[] inputSigma = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Create partial mock of CMAESOptimizer
                                                                                                                                                                                                                                                                                   CMAESOptimizer optimizer = new CMAESOptimizer(10, inputSigma);
                                                                                                                                                                                                                                                                                   CMAESOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Mock getStartPoint() to return null (simulating the mutant)
                                                                                                                                                                                                                                                                                   when(spyOptimizer.getStartPoint()).thenReturn(null);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Mock other required methods to avoid NPEs from other parts
                                                                                                                                                                                                                                                                                   when(spyOptimizer.getLowerBound()).thenReturn(new double[]{0.0, 0.0, 0.0});
                                                                                                                                                                                                                                                                                   when(spyOptimizer.getUpperBound()).thenReturn(new double[]{10.0, 10.0, 10.0});
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Use reflection to access private checkParameters method
                                                                                                                                                                                                                                                                                   Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                                   checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // This should throw NullPointerException when checking inputSigma.length vs init.length
                                                                                                                                                                                                                                                                                   // The original code would pass this test (no exception), but the mutant fails
                                                                                                                                                                                                                                                                                   checkParametersMethod.invoke(spyOptimizer);
                                                                                                                                                                                                                                                                               }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                                                                                                                                                                                                                                          public void testCheckParametersDetectsEmptyLowerBounds() throws Exception {
                                                                                                                                                                                                                                                                              // Setup test data
                                                                                                                                                                                                                                                                              double[] init = {1.0, 2.0, 3.0}; // Non-empty start point
                                                                                                                                                                                                                                                                              double[] uB = {10.0, 20.0, 30.0}; // Non-empty upper bounds
                                                                                                                                                                                                                                                                              double[] inputSigma = {0.1, 0.1, 0.1}; // Valid sigma values
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Create partial mock of CMAESOptimizer
                                                                                                                                                                                                                                                                              CMAESOptimizer optimizer = new CMAESOptimizer(0, inputSigma);
                                                                                                                                                                                                                                                                              optimizer = spy(optimizer);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Mock methods to return test data
                                                                                                                                                                                                                                                                              when(optimizer.getStartPoint()).thenReturn(init);
                                                                                                                                                                                                                                                                              when(optimizer.getUpperBound()).thenReturn(uB);
                                                                                                                                                                                                                                                                              // Don't mock getLowerBound() - let it use the mutated version
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Use reflection to invoke private checkParameters method
                                                                                                                                                                                                                                                                              Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                              checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                                                                              checkParametersMethod.invoke(optimizer);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Verify the mutation was detected by the exception
                                                                                                                                                                                                                                                                              // (ExpectedException annotation handles this)
                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                      public void testCheckParametersDetectsDifferentBounds() {
                                                                                                                                                                                                                                                                          // Setup test with different lower and upper bounds
                                                                                                                                                                                                                                                                          CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                          // Mock getLowerBound() and getUpperBound() to return different values
                                                                                                                                                                                                                                                                          double[] lowerBounds = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                                                                                                                          double[] upperBounds = new double[]{4.0, 5.0, 6.0};
                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                          // Use reflection to inject mock bounds since they're private methods
                                                                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                                                                              Method getLowerBound = CMAESOptimizer.class.getDeclaredMethod("getLowerBound");
                                                                                                                                                                                                                                                                              getLowerBound.setAccessible(true);
                                                                                                                                                                                                                                                                              when(getLowerBound.invoke(optimizer)).thenReturn(lowerBounds);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              Method getUpperBound = CMAESOptimizer.class.getDeclaredMethod("getUpperBound");
                                                                                                                                                                                                                                                                              getUpperBound.setAccessible(true);
                                                                                                                                                                                                                                                                              when(getUpperBound.invoke(optimizer)).thenReturn(upperBounds);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Also mock getStartPoint() since it's called first
                                                                                                                                                                                                                                                                              Method getStartPoint = CMAESOptimizer.class.getDeclaredMethod("getStartPoint");
                                                                                                                                                                                                                                                                              getStartPoint.setAccessible(true);
                                                                                                                                                                                                                                                                              when(getStartPoint.invoke(optimizer)).thenReturn(new double[]{2.0, 3.0, 4.0});
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Call the method under test
                                                                                                                                                                                                                                                                              Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                              checkParameters.setAccessible(true);
                                                                                                                                                                                                                                                                              checkParameters.invoke(optimizer);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Verify boundaries were set correctly (would fail with mutation)
                                                                                                                                                                                                                                                                              Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                              boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                                              double[][] boundaries = (double[][]) boundariesField.get(optimizer);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              assertNotNull(boundaries);
                                                                                                                                                                                                                                                                              assertEquals(lowerBounds, boundaries[0]);
                                                                                                                                                                                                                                                                              assertEquals(upperBounds, boundaries[1]);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                                                                              fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                    public void testCheckParametersWithAllInfiniteBounds() throws Exception {
                                                                                                                                                                                                                                                                        // Create test subclass that properly extends CMAESOptimizer
                                                                                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(10) {
                                                                                                                                                                                                                                                                            @Override
                                                                                                                                                                                                                                                                            public double[] getLowerBound() {
                                                                                                                                                                                                                                                                                return new double[]{Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY};
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            @Override
                                                                                                                                                                                                                                                                            public double[] getUpperBound() {
                                                                                                                                                                                                                                                                                return new double[]{Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY};
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            @Override
                                                                                                                                                                                                                                                                            public double[] getStartPoint() {
                                                                                                                                                                                                                                                                                return new double[]{0, 0};
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                        };
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Use reflection to set private inputSigma field
                                                                                                                                                                                                                                                                        Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                                                                                                                        inputSigmaField.setAccessible(true);
                                                                                                                                                                                                                                                                        inputSigmaField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Use reflection to access private checkParameters method
                                                                                                                                                                                                                                                                        Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                        checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                                                                        checkParametersMethod.invoke(optimizer);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Use reflection to verify private boundaries field
                                                                                                                                                                                                                                                                        Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                        boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                                        assertNull(boundariesField.get(optimizer));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                public void testCheckParametersArrayBounds() {
                                                                                                                                                                                                                                                                    // Setup test data with finite bounds
                                                                                                                                                                                                                                                                    double[] init = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                                                                                                                    double[] lB = new double[]{0.0, 1.0, 2.0}; // finite lower bounds
                                                                                                                                                                                                                                                                    double[] uB = new double[]{2.0, 3.0, 4.0}; // finite upper bounds
                                                                                                                                                                                                                                                                    double[] inputSigma = new double[]{0.1, 0.1, 0.1}; // valid sigma
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Mock the CMAESOptimizer and setup test scenario
                                                                                                                                                                                                                                                                    CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                                                                                                                                                                    when(optimizer.getStartPoint()).thenReturn(init);
                                                                                                                                                                                                                                                                    when(optimizer.getLowerBound()).thenReturn(lB);
                                                                                                                                                                                                                                                                    when(optimizer.getUpperBound()).thenReturn(uB);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Use reflection to test the private method
                                                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                                                        Method method = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // This should not throw ArrayIndexOutOfBoundsException with original code
                                                                                                                                                                                                                                                                        method.invoke(optimizer);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // If we get here, test passes (original behavior)
                                                                                                                                                                                                                                                                    } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                                        // Check if the cause is ArrayIndexOutOfBoundsException
                                                                                                                                                                                                                                                                        if (e.getCause() instanceof ArrayIndexOutOfBoundsException) {
                                                                                                                                                                                                                                                                            fail("Mutant detected: ArrayIndexOutOfBoundsException was thrown indicating loop bound error");
                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                        // Re-throw other exceptions
                                                                                                                                                                                                                                                                        throw new RuntimeException(e);
                                                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                                                        throw new RuntimeException(e);
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                              public void testCheckParametersDetectsFiniteBoundsWithMixedInfiniteBounds() {
                                                                                                                                                                                                                                                                  // Setup test with mock bounds where:
                                                                                                                                                                                                                                                                  // - First dimension has finite lower bound but infinite upper bound
                                                                                                                                                                                                                                                                  // - Second dimension has infinite lower bound but finite upper bound
                                                                                                                                                                                                                                                                  // This should be detected as having finite bounds in original code
                                                                                                                                                                                                                                                                  // but mutant would miss it since it requires both bounds to be finite
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  CMAESOptimizer optimizer = new CMAESOptimizer(10);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Mock getLowerBound and getUpperBound to return test values
                                                                                                                                                                                                                                                                  double[] lowerBounds = new double[]{1.0, Double.NEGATIVE_INFINITY};
                                                                                                                                                                                                                                                                  double[] upperBounds = new double[]{Double.POSITIVE_INFINITY, 2.0};
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Use reflection to inject mock bounds since they're private
                                                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                                                      Field lowerBoundField = CMAESOptimizer.class.getDeclaredField("lowerBound");
                                                                                                                                                                                                                                                                      lowerBoundField.setAccessible(true);
                                                                                                                                                                                                                                                                      lowerBoundField.set(optimizer, lowerBounds);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field upperBoundField = CMAESOptimizer.class.getDeclaredField("upperBound");
                                                                                                                                                                                                                                                                      upperBoundField.setAccessible(true);
                                                                                                                                                                                                                                                                      upperBoundField.set(optimizer, upperBounds);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Also need to mock getStartPoint() to return array of correct length
                                                                                                                                                                                                                                                                      Field startPointField = CMAESOptimizer.class.getDeclaredField("startPoint");
                                                                                                                                                                                                                                                                      startPointField.setAccessible(true);
                                                                                                                                                                                                                                                                      startPointField.set(optimizer, new double[]{0.5, 0.5});
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Get and invoke private checkParameters method
                                                                                                                                                                                                                                                                      Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                      checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                                                                      checkParametersMethod.invoke(optimizer);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Verify boundaries were set (proves hasFiniteBounds was true)
                                                                                                                                                                                                                                                                      Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                      boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                                      double[][] boundaries = (double[][]) boundariesField.get(optimizer);
                                                                                                                                                                                                                                                                      assertNotNull(boundaries);
                                                                                                                                                                                                                                                                      assertEquals(lowerBounds, boundaries[0]);
                                                                                                                                                                                                                                                                      assertEquals(upperBounds, boundaries[1]);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                                                      fail("Unexpected exception: " + e.getMessage());
                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                         public void testCheckParametersDetectsFiniteUpperBoundWithInfiniteLowerBound() {
                                                                                                                                                                                                                                                             // Setup test case where upper bound is finite but lower bound is infinite
                                                                                                                                                                                                                                                             // This should be detected as finite bounds case in original code
                                                                                                                                                                                                                                                             // But mutant would miss it
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create optimizer instance
                                                                                                                                                                                                                                                             CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Mock getStartPoint, getLowerBound, getUpperBound
                                                                                                                                                                                                                                                             double[] init = new double[]{1.0};
                                                                                                                                                                                                                                                             double[] lB = new double[]{Double.NEGATIVE_INFINITY}; // infinite lower bound
                                                                                                                                                                                                                                                             double[] uB = new double[]{10.0}; // finite upper bound
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to set private fields for testing
                                                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                                                 java.lang.reflect.Field initField = CMAESOptimizer.class.getDeclaredField("init");
                                                                                                                                                                                                                                                                 initField.setAccessible(true);
                                                                                                                                                                                                                                                                 initField.set(optimizer, init);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 java.lang.reflect.Field lBField = CMAESOptimizer.class.getDeclaredField("lB");
                                                                                                                                                                                                                                                                 lBField.setAccessible(true);
                                                                                                                                                                                                                                                                 lBField.set(optimizer, lB);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 java.lang.reflect.Field uBField = CMAESOptimizer.class.getDeclaredField("uB");
                                                                                                                                                                                                                                                                 uBField.setAccessible(true);
                                                                                                                                                                                                                                                                 uBField.set(optimizer, uB);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Also set inputSigma to avoid NPE
                                                                                                                                                                                                                                                                 java.lang.reflect.Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                                                                                                                 inputSigmaField.setAccessible(true);
                                                                                                                                                                                                                                                                 inputSigmaField.set(optimizer, new double[]{1.0});
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                                                 fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // The original code should proceed with boundary checks
                                                                                                                                                                                                                                                             // The mutant would treat this as no finite bounds case
                                                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                                                 // Use reflection to call private method
                                                                                                                                                                                                                                                                 java.lang.reflect.Method method = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                                 method.setAccessible(true);
                                                                                                                                                                                                                                                                 method.invoke(optimizer);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Verify boundaries were set (original behavior)
                                                                                                                                                                                                                                                                 java.lang.reflect.Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                 boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                                 double[][] boundaries = (double[][]) boundariesField.get(optimizer);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 assertNotNull("Boundaries should be set when finite bounds exist", boundaries);
                                                                                                                                                                                                                                                                 assertEquals("Lower bound should match", lB, boundaries[0]);
                                                                                                                                                                                                                                                                 assertEquals("Upper bound should match", uB, boundaries[1]);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                                                 fail("Exception should not be thrown for valid finite bounds: " + e.getMessage());
                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                     public void testCheckParametersDetectsFiniteBounds() {
                                                                                                                                                                                                                                                         // Setup test with one finite bound
                                                                                                                                                                                                                                                         CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Mock getLowerBound() and getUpperBound() to return bounds where one value is finite
                                                                                                                                                                                                                                                         double[] lowerBounds = new double[]{Double.NEGATIVE_INFINITY, 0.0}; // One finite bound
                                                                                                                                                                                                                                                         double[] upperBounds = new double[]{Double.POSITIVE_INFINITY, 1.0}; // One finite bound
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Use reflection to inject test bounds since original methods are private
                                                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                                                             Field lowerBoundField = CMAESOptimizer.class.getDeclaredField("lB");
                                                                                                                                                                                                                                                             lowerBoundField.setAccessible(true);
                                                                                                                                                                                                                                                             lowerBoundField.set(optimizer, lowerBounds);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             Field upperBoundField = CMAESOptimizer.class.getDeclaredField("uB");
                                                                                                                                                                                                                                                             upperBoundField.setAccessible(true);
                                                                                                                                                                                                                                                             upperBoundField.set(optimizer, upperBounds);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Also set inputSigma to avoid NPE
                                                                                                                                                                                                                                                             Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                                                                                                             inputSigmaField.setAccessible(true);
                                                                                                                                                                                                                                                             inputSigmaField.set(optimizer, new double[]{0.1, 0.1});
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Call the method - should process finite bounds
                                                                                                                                                                                                                                                             Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                             checkParameters.setAccessible(true);
                                                                                                                                                                                                                                                             checkParameters.invoke(optimizer);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify boundaries were set (would be null if mutant skipped processing)
                                                                                                                                                                                                                                                             Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                             boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                             double[][] boundaries = (double[][]) boundariesField.get(optimizer);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             assertNotNull("Boundaries should be set when finite bounds exist", boundaries);
                                                                                                                                                                                                                                                             assertEquals("Lower bounds should match", lowerBounds, boundaries[0]);
                                                                                                                                                                                                                                                             assertEquals("Upper bounds should match", upperBounds, boundaries[1]);
                                                                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                                                                             fail("Test setup failed: " + e.getMessage());
                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                   public void testCheckParametersDetectsFiniteBoundsEarly() {
                                                                                                                                                                                                                                                       // Setup test with mixed bounds where finite bound appears first
                                                                                                                                                                                                                                                       CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock getStartPoint, getLowerBound and getUpperBound
                                                                                                                                                                                                                                                       // We'll use reflection to set these since they're private
                                                                                                                                                                                                                                                       try {
                                                                                                                                                                                                                                                           Field lowerBoundField = CMAESOptimizer.class.getDeclaredField("lB");
                                                                                                                                                                                                                                                           lowerBoundField.setAccessible(true);
                                                                                                                                                                                                                                                           Field upperBoundField = CMAESOptimizer.class.getDeclaredField("uB");
                                                                                                                                                                                                                                                           upperBoundField.setAccessible(true);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Create bounds where first element is finite, others are infinite
                                                                                                                                                                                                                                                           double[] lB = new double[]{1.0, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY};
                                                                                                                                                                                                                                                           double[] uB = new double[]{2.0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY};
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           lowerBoundField.set(optimizer, lB);
                                                                                                                                                                                                                                                           upperBoundField.set(optimizer, uB);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Also need to mock getStartPoint()
                                                                                                                                                                                                                                                           Method getStartPoint = CMAESOptimizer.class.getDeclaredMethod("getStartPoint");
                                                                                                                                                                                                                                                           getStartPoint.setAccessible(true);
                                                                                                                                                                                                                                                           when(getStartPoint.invoke(optimizer)).thenReturn(new double[]{1.5, 0.0, 0.0});
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Get the private checkParameters method using reflection
                                                                                                                                                                                                                                                           Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                           checkParameters.setAccessible(true);
                                                                                                                                                                                                                                                           checkParameters.invoke(optimizer);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Verify boundaries were set (original would do this after first element)
                                                                                                                                                                                                                                                           Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                           boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                           double[][] boundaries = (double[][]) boundariesField.get(optimizer);
                                                                                                                                                                                                                                                           assertNotNull(boundaries);
                                                                                                                                                                                                                                                           assertEquals(lB, boundaries[0]);
                                                                                                                                                                                                                                                           assertEquals(uB, boundaries[1]);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                                                                                                                           fail("Test setup failed: " + e.getMessage());
                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                          public void testCheckParametersWithAllFiniteBoundsShouldNotThrowException() throws Exception {
                                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                                              CMAESOptimizer optimizer = new CMAESOptimizer(0, new double[]{0.1, 0.1, 0.1});
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Mock finite bounds (no infinite values)
                                                                                                                                                                                                                                              double[] finiteBounds = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                                                                                              CMAESOptimizer optimizerSpy = spy(optimizer);
                                                                                                                                                                                                                                              when(optimizerSpy.getLowerBound()).thenReturn(finiteBounds);
                                                                                                                                                                                                                                              when(optimizerSpy.getUpperBound()).thenReturn(finiteBounds);
                                                                                                                                                                                                                                              when(optimizerSpy.getStartPoint()).thenReturn(new double[]{1.5, 2.5, 3.5});
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                                  // Use reflection to call private checkParameters method
                                                                                                                                                                                                                                                  Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                                  checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                                                  checkParametersMethod.invoke(optimizerSpy);
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Verify - no exception should be thrown
                                                                                                                                                                                                                                                  // Use reflection to verify boundaries were set correctly
                                                                                                                                                                                                                                                  Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                  boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                  double[][] boundaries = (double[][]) boundariesField.get(optimizerSpy);
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  assertNotNull(boundaries);
                                                                                                                                                                                                                                                  assertArrayEquals(finiteBounds, boundaries[0], 0.0);
                                                                                                                                                                                                                                                  assertArrayEquals(finiteBounds, boundaries[1], 0.0);
                                                                                                                                                                                                                                              } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                  if (e.getCause() instanceof MathUnsupportedOperationException) {
                                                                                                                                                                                                                                                      fail("Should not throw MathUnsupportedOperationException for all finite bounds");
                                                                                                                                                                                                                                                  } else {
                                                                                                                                                                                                                                                      throw e;
                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                      public void testCheckParametersWithMixedFiniteInfiniteBounds() {
                                                                                                                                                                                                                                          // Setup test with mixed finite/infinite bounds
                                                                                                                                                                                                                                          CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Mock getLowerBound() and getUpperBound() to return mixed bounds
                                                                                                                                                                                                                                          // One finite bound, one infinite bound
                                                                                                                                                                                                                                          double[] lowerBounds = new double[]{0.0, Double.NEGATIVE_INFINITY};
                                                                                                                                                                                                                                          double[] upperBounds = new double[]{1.0, Double.POSITIVE_INFINITY};
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Use reflection to inject mock bounds since they're private
                                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                                              Field lowerBoundField = CMAESOptimizer.class.getDeclaredField("lB");
                                                                                                                                                                                                                                              lowerBoundField.setAccessible(true);
                                                                                                                                                                                                                                              lowerBoundField.set(optimizer, lowerBounds);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              Field upperBoundField = CMAESOptimizer.class.getDeclaredField("uB");
                                                                                                                                                                                                                                              upperBoundField.setAccessible(true);
                                                                                                                                                                                                                                              upperBoundField.set(optimizer, upperBounds);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Also need to mock getStartPoint() to return array of correct length
                                                                                                                                                                                                                                              double[] startPoint = new double[]{0.5, 0.0};
                                                                                                                                                                                                                                              Field initField = CMAESOptimizer.class.getDeclaredField("init");
                                                                                                                                                                                                                                              initField.setAccessible(true);
                                                                                                                                                                                                                                              initField.set(optimizer, startPoint);
                                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                                              fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Test should throw MathUnsupportedOperationException for mixed bounds
                                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                                              Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                              checkParameters.setAccessible(true);
                                                                                                                                                                                                                                              checkParameters.invoke(optimizer);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // If we get here, the mutant survived (it skipped the check)
                                                                                                                                                                                                                                              fail("Expected MathUnsupportedOperationException for mixed finite/infinite bounds");
                                                                                                                                                                                                                                          } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                              // Original should throw MathUnsupportedOperationException
                                                                                                                                                                                                                                              assertTrue(e.getCause() instanceof MathUnsupportedOperationException);
                                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                                              fail("Unexpected exception: " + e.getMessage());
                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                      }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                                                                                                                                                                                                    public void testCheckParametersLoopBoundary() throws Exception {
                                                                                                                                                                                                                                        // Setup test data with bounds arrays of length 1
                                                                                                                                                                                                                                        double[] lowerBounds = new double[]{0.0};
                                                                                                                                                                                                                                        double[] upperBounds = new double[]{1.0};
                                                                                                                                                                                                                                        double[] startPoint = new double[]{0.5};
                                                                                                                                                                                                                                        double[] inputSigma = new double[]{0.1};
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Create partial mock of CMAESOptimizer
                                                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(0, inputSigma);
                                                                                                                                                                                                                                        CMAESOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Mock the getter methods to return our test data
                                                                                                                                                                                                                                        doReturn(startPoint).when(spyOptimizer).getStartPoint();
                                                                                                                                                                                                                                        doReturn(lowerBounds).when(spyOptimizer).getLowerBound();
                                                                                                                                                                                                                                        doReturn(upperBounds).when(spyOptimizer).getUpperBound();
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Use reflection to call private checkParameters method
                                                                                                                                                                                                                                        Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                        checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                                        checkParametersMethod.invoke(spyOptimizer);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // If we get here, the test fails (mutant not caught)
                                                                                                                                                                                                                                        // The expected exception annotation will verify the mutant is caught
                                                                                                                                                                                                                                    }

    @Test(expected = MathUnsupportedOperationException.class)
                                                                                                                                                                                                                               public void testCheckParametersDetectsMixedFiniteInfiniteBounds() throws Exception {
                                                                                                                                                                                                                                   // Setup test with mixed finite/infinite bounds
                                                                                                                                                                                                                                   double[] init = new double[]{1.0, 2.0}; // arbitrary start point
                                                                                                                                                                                                                                   double[] lB = new double[]{Double.NEGATIVE_INFINITY, 0.0}; // first lower bound is infinite
                                                                                                                                                                                                                                   double[] uB = new double[]{1.0, Double.POSITIVE_INFINITY}; // second upper bound is infinite
                                                                                                                                                                                                                                   double[] inputSigma = new double[]{0.5, 0.5}; // valid sigma values
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Create partial mock of CMAESOptimizer
                                                                                                                                                                                                                                   CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                                                   optimizer = spy(optimizer);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Mock the methods called by checkParameters
                                                                                                                                                                                                                                   when(optimizer.getStartPoint()).thenReturn(init);
                                                                                                                                                                                                                                   when(optimizer.getLowerBound()).thenReturn(lB);
                                                                                                                                                                                                                                   when(optimizer.getUpperBound()).thenReturn(uB);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Set inputSigma through reflection since it's private
                                                                                                                                                                                                                                   Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                                                                                   inputSigmaField.setAccessible(true);
                                                                                                                                                                                                                                   inputSigmaField.set(optimizer, inputSigma);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Get the private checkParameters method
                                                                                                                                                                                                                                   Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                   checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Invoke the method which should throw MathUnsupportedOperationException
                                                                                                                                                                                                                                   checkParametersMethod.invoke(optimizer);
                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                          public void testCheckParametersDetectsFiniteLowerBoundWithInfiniteUpperBound() throws Exception {
                                                                                                                                                                                                                              // Setup test with:
                                                                                                                                                                                                                              // - finite lower bound
                                                                                                                                                                                                                              // - infinite upper bound
                                                                                                                                                                                                                              // This should trigger hasFiniteBounds=true in original code
                                                                                                                                                                                                                              // but would fail with the mutant
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Create test instance
                                                                                                                                                                                                                              CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Mock getStartPoint, getLowerBound, getUpperBound
                                                                                                                                                                                                                              optimizer = spy(optimizer);
                                                                                                                                                                                                                              when(optimizer.getStartPoint()).thenReturn(new double[]{1.0});
                                                                                                                                                                                                                              when(optimizer.getLowerBound()).thenReturn(new double[]{0.0}); // finite
                                                                                                                                                                                                                              when(optimizer.getUpperBound()).thenReturn(new double[]{Double.POSITIVE_INFINITY}); // infinite
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Use reflection to set inputSigma
                                                                                                                                                                                                                              Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                                                                              inputSigmaField.setAccessible(true);
                                                                                                                                                                                                                              inputSigmaField.set(optimizer, new double[]{0.1});
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                  // Use reflection to call private checkParameters method
                                                                                                                                                                                                                                  Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                                  checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                                  checkParametersMethod.invoke(optimizer);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Use reflection to verify boundaries were set
                                                                                                                                                                                                                                  Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                  boundariesField.setAccessible(true);
                                                                                                                                                                                                                                  double[][] boundaries = (double[][]) boundariesField.get(optimizer);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  assertNotNull(boundaries);
                                                                                                                                                                                                                                  assertEquals(0.0, boundaries[0][0], 0.0);
                                                                                                                                                                                                                                  assertEquals(Double.POSITIVE_INFINITY, boundaries[1][0], 0.0);
                                                                                                                                                                                                                              } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                  if (e.getCause() instanceof MathUnsupportedOperationException) {
                                                                                                                                                                                                                                      // This exception would indicate the mutant was present
                                                                                                                                                                                                                                      fail("Mutant detected - method incorrectly threw MathUnsupportedOperationException");
                                                                                                                                                                                                                                  } else {
                                                                                                                                                                                                                                      throw e;
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                          }

    @Test(expected = MathUnsupportedOperationException.class)
                                                                                                                                                                                                                     public void testCheckParametersWithMixedBoundsThrowsException() throws Exception {
                                                                                                                                                                                                                         // Setup test with mixed finite and infinite bounds
                                                                                                                                                                                                                         CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Mock getLowerBound() and getUpperBound() to return test values
                                                                                                                                                                                                                         // One finite bound and one infinite bound to trigger the condition
                                                                                                                                                                                                                         when(optimizer.getLowerBound()).thenReturn(new double[]{1.0, Double.NEGATIVE_INFINITY});
                                                                                                                                                                                                                         when(optimizer.getUpperBound()).thenReturn(new double[]{2.0, Double.POSITIVE_INFINITY});
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Mock getStartPoint() to return any value since it's not relevant for this test
                                                                                                                                                                                                                         when(optimizer.getStartPoint()).thenReturn(new double[]{1.5, 0.0});
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Set inputSigma to null using reflection since it's private
                                                                                                                                                                                                                         Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                                                                         inputSigmaField.setAccessible(true);
                                                                                                                                                                                                                         inputSigmaField.set(optimizer, null);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Invoke checkParameters() using reflection since it's private
                                                                                                                                                                                                                         Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                         checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                         checkParametersMethod.invoke(optimizer);
                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                public void testCheckParametersDetectsFiniteBoundsEarly1() {
                                                                                                                                                                                                                    // Setup test data with finite bound at first position
                                                                                                                                                                                                                    double[] init = new double[]{1.0, 1.0, 1.0};
                                                                                                                                                                                                                    double[] lB = new double[]{0.0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY};
                                                                                                                                                                                                                    double[] uB = new double[]{2.0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY};
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Mock the required methods
                                                                                                                                                                                                                    CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                                                                                                                    when(optimizer.getStartPoint()).thenReturn(init);
                                                                                                                                                                                                                    when(optimizer.getLowerBound()).thenReturn(lB);
                                                                                                                                                                                                                    when(optimizer.getUpperBound()).thenReturn(uB);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Use reflection to test private method
                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                        Method method = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // This should execute quickly with original code (due to break)
                                                                                                                                                                                                                        // Will timeout with mutated code (due to // break)
                                                                                                                                                                                                                        method.invoke(optimizer);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Verify boundaries were set by checking the private field
                                                                                                                                                                                                                        Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                        boundariesField.setAccessible(true);
                                                                                                                                                                                                                        double[][] boundaries = (double[][]) boundariesField.get(optimizer);
                                                                                                                                                                                                                        assertNotNull(boundaries);
                                                                                                                                                                                                                        assertEquals(lB, boundaries[0]);
                                                                                                                                                                                                                        assertEquals(uB, boundaries[1]);
                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                        fail("Exception during test: " + e.getMessage());
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                           public void testCheckParametersWithMixedBoundsThrowsException1() {
                                                                                                                                                                                                               // Setup test with mixed finite and infinite bounds
                                                                                                                                                                                                               CMAESOptimizer optimizer = new CMAESOptimizer(10);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Mock the bounds to return mixed finite/infinite values
                                                                                                                                                                                                               // First dimension: finite lower, infinite upper
                                                                                                                                                                                                               // Second dimension: infinite lower, finite upper
                                                                                                                                                                                                               double[] mockLowerBounds = new double[]{1.0, Double.NEGATIVE_INFINITY};
                                                                                                                                                                                                               double[] mockUpperBounds = new double[]{Double.POSITIVE_INFINITY, 2.0};
                                                                                                                                                                                                               double[] mockStartPoint = new double[]{1.5, 0.0};
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Use reflection to inject mock bounds since they're private
                                                                                                                                                                                                               try {
                                                                                                                                                                                                                   Field lowerBoundField = CMAESOptimizer.class.getDeclaredField("lB");
                                                                                                                                                                                                                   lowerBoundField.setAccessible(true);
                                                                                                                                                                                                                   lowerBoundField.set(optimizer, mockLowerBounds);
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   Field upperBoundField = CMAESOptimizer.class.getDeclaredField("uB");
                                                                                                                                                                                                                   upperBoundField.setAccessible(true);
                                                                                                                                                                                                                   upperBoundField.set(optimizer, mockUpperBounds);
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   Field startPointField = CMAESOptimizer.class.getDeclaredField("init");
                                                                                                                                                                                                                   startPointField.setAccessible(true);
                                                                                                                                                                                                                   startPointField.set(optimizer, mockStartPoint);
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   // Get the private checkParameters method via reflection
                                                                                                                                                                                                                   Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                                   checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   // This should throw MathUnsupportedOperationException
                                                                                                                                                                                                                   checkParametersMethod.invoke(optimizer);
                                                                                                                                                                                                                   fail("Expected MathUnsupportedOperationException");
                                                                                                                                                                                                               } catch (InvocationTargetException e) {
                                                                                                                                                                                                                   // Check if the cause is the expected exception
                                                                                                                                                                                                                   if (!(e.getCause() instanceof MathUnsupportedOperationException)) {
                                                                                                                                                                                                                       fail("Expected MathUnsupportedOperationException but got " + e.getCause().getClass().getName());
                                                                                                                                                                                                                   }
                                                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                                                   fail("Failed to set up or execute test via reflection: " + e.getMessage());
                                                                                                                                                                                                               }
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                      public void testCheckParametersBoundariesArraySize() {
                                                                                                                                                                                                          // Setup test data with finite bounds
                                                                                                                                                                                                          double[] lowerBounds = {1.0, 2.0, 3.0};
                                                                                                                                                                                                          double[] upperBounds = {4.0, 5.0, 6.0};
                                                                                                                                                                                                          double[] initPoint = {1.5, 2.5, 3.5};
                                                                                                                                                                                                          double[] inputSigma = {0.1, 0.1, 0.1};
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Create mock optimizer
                                                                                                                                                                                                          CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Stub methods called by checkParameters
                                                                                                                                                                                                          when(optimizer.getStartPoint()).thenReturn(initPoint);
                                                                                                                                                                                                          when(optimizer.getLowerBound()).thenReturn(lowerBounds);
                                                                                                                                                                                                          when(optimizer.getUpperBound()).thenReturn(upperBounds);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use spy to test actual implementation
                                                                                                                                                                                                          CMAESOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Set inputSigma through reflection since it's private
                                                                                                                                                                                                          try {
                                                                                                                                                                                                              Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                                                              inputSigmaField.setAccessible(true);
                                                                                                                                                                                                              inputSigmaField.set(spyOptimizer, inputSigma);
                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                              fail("Failed to set inputSigma field");
                                                                                                                                                                                                          }
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute the method through reflection
                                                                                                                                                                                                          try {
                                                                                                                                                                                                              Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                              checkParameters.setAccessible(true);
                                                                                                                                                                                                              checkParameters.invoke(spyOptimizer);
                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                              fail("Failed to invoke checkParameters method");
                                                                                                                                                                                                          }
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify boundaries array was created with correct size
                                                                                                                                                                                                          try {
                                                                                                                                                                                                              Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                              boundariesField.setAccessible(true);
                                                                                                                                                                                                              double[][] boundaries = (double[][]) boundariesField.get(spyOptimizer);
                                                                                                                                                                                                              
                                                                                                                                                                                                              assertEquals(2, boundaries.length);
                                                                                                                                                                                                              assertNotNull(boundaries[0]);
                                                                                                                                                                                                              assertNotNull(boundaries[1]);
                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                              fail("Failed to verify boundaries array");
                                                                                                                                                                                                          }
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                 public void testCheckParametersBoundaryAssignment() throws Exception {
                                                                                                                                                                                                     // Setup test data with distinct lower and upper bounds
                                                                                                                                                                                                     final double[] testLowerBounds = {1.0, 2.0, 3.0};
                                                                                                                                                                                                     final double[] testUpperBounds = {4.0, 5.0, 6.0};
                                                                                                                                                                                                     final double[] testInitPoint = {1.5, 2.5, 3.5};
                                                                                                                                                                                                     final double[] testInputSigma = {0.1, 0.1, 0.1};
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Create partial mock of CMAESOptimizer using constructor that accepts inputSigma
                                                                                                                                                                                                     CMAESOptimizer optimizer = new CMAESOptimizer(0, testInputSigma);
                                                                                                                                                                                                     optimizer = spy(optimizer);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Mock methods called by checkParameters()
                                                                                                                                                                                                     doReturn(testInitPoint).when(optimizer).getStartPoint();
                                                                                                                                                                                                     doReturn(testLowerBounds).when(optimizer).getLowerBound();
                                                                                                                                                                                                     doReturn(testUpperBounds).when(optimizer).getUpperBound();
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Use reflection to call private checkParameters method
                                                                                                                                                                                                     Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                     checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                     checkParametersMethod.invoke(optimizer);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Use reflection to access boundaries field
                                                                                                                                                                                                     Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                     boundariesField.setAccessible(true);
                                                                                                                                                                                                     double[][] boundaries = (double[][]) boundariesField.get(optimizer);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Verify boundary assignment
                                                                                                                                                                                                     assertNotNull(boundaries);
                                                                                                                                                                                                     assertSame(testLowerBounds, boundaries[0]); // This will fail if mutant survives
                                                                                                                                                                                                     assertSame(testUpperBounds, boundaries[1]);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Verify boundary-dependent operations
                                                                                                                                                                                                     for (int i = 0; i < testLowerBounds.length; i++) {
                                                                                                                                                                                                         // Check boundary difference calculation
                                                                                                                                                                                                         double expectedDiff = testUpperBounds[i] - testLowerBounds[i];
                                                                                                                                                                                                         double actualDiff = boundaries[1][i] - boundaries[0][i];
                                                                                                                                                                                                         assertEquals(expectedDiff, actualDiff, 0.0);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Check input sigma validation
                                                                                                                                                                                                         assertTrue(testInputSigma[i] < actualDiff);
                                                                                                                                                                                                     }
                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                            public void testCheckParametersBoundariesAssignment() throws Exception {
                                                                                                                                                                                                // Setup test data with different lower and upper bounds
                                                                                                                                                                                                double[] lowerBounds = {1.0, 2.0, 3.0};
                                                                                                                                                                                                double[] upperBounds = {4.0, 5.0, 6.0};
                                                                                                                                                                                                double[] startPoint = {2.0, 3.0, 4.0};
                                                                                                                                                                                                double[] inputSigma = {0.1, 0.1, 0.1};
                                                                                                                                                                                                
                                                                                                                                                                                                // Create partial mock of CMAESOptimizer
                                                                                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                CMAESOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                                                                
                                                                                                                                                                                                // Mock the methods called by checkParameters
                                                                                                                                                                                                when(spyOptimizer.getStartPoint()).thenReturn(startPoint);
                                                                                                                                                                                                when(spyOptimizer.getLowerBound()).thenReturn(lowerBounds);
                                                                                                                                                                                                when(spyOptimizer.getUpperBound()).thenReturn(upperBounds);
                                                                                                                                                                                                
                                                                                                                                                                                                // Set inputSigma using reflection
                                                                                                                                                                                                Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                                                inputSigmaField.setAccessible(true);
                                                                                                                                                                                                inputSigmaField.set(spyOptimizer, inputSigma);
                                                                                                                                                                                                
                                                                                                                                                                                                // Call the private checkParameters method using reflection
                                                                                                                                                                                                Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                checkParametersMethod.setAccessible(true);
                                                                                                                                                                                                checkParametersMethod.invoke(spyOptimizer);
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify boundaries assignment using reflection
                                                                                                                                                                                                Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                boundariesField.setAccessible(true);
                                                                                                                                                                                                double[][] boundaries = (double[][]) boundariesField.get(spyOptimizer);
                                                                                                                                                                                                
                                                                                                                                                                                                assertNotNull(boundaries);
                                                                                                                                                                                                assertEquals(2, boundaries.length);
                                                                                                                                                                                                
                                                                                                                                                                                                // This is the critical assertion that will catch the mutant
                                                                                                                                                                                                // Verify boundaries[1] contains upper bounds, not lower bounds
                                                                                                                                                                                                assertArrayEquals(upperBounds, boundaries[1], 0.0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Additional verification that boundaries[0] contains lower bounds
                                                                                                                                                                                                assertArrayEquals(lowerBounds, boundaries[0], 0.0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify the difference between bounds is correct
                                                                                                                                                                                                for (int i = 0; i < lowerBounds.length; i++) {
                                                                                                                                                                                                    assertEquals(upperBounds[i] - lowerBounds[i], boundaries[1][i] - boundaries[0][i], 0.0);
                                                                                                                                                                                                }
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                        public void testCheckParametersDetectsFiniteBoundsInLastElement() {
                                                                                                                                                                                            // Setup test data where only last element has finite bounds
                                                                                                                                                                                            double[] init = new double[]{0.0, 0.0, 0.0};
                                                                                                                                                                                            double[] lB = new double[]{Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, -1.0};
                                                                                                                                                                                            double[] uB = new double[]{Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 1.0};
                                                                                                                                                                                            double[] inputSigma = new double[]{0.1, 0.1, 0.1};
                                                                                                                                                                                            
                                                                                                                                                                                            // Mock the CMAESOptimizer class and setup test scenario
                                                                                                                                                                                            CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                                                                                            when(optimizer.getStartPoint()).thenReturn(init);
                                                                                                                                                                                            when(optimizer.getLowerBound()).thenReturn(lB);
                                                                                                                                                                                            when(optimizer.getUpperBound()).thenReturn(uB);
                                                                                                                                                                                            
                                                                                                                                                                                            // Set private fields using reflection
                                                                                                                                                                                            try {
                                                                                                                                                                                                Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                boundariesField.setAccessible(true);
                                                                                                                                                                                                boundariesField.set(optimizer, null);
                                                                                                                                                                                                
                                                                                                                                                                                                Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                                                inputSigmaField.setAccessible(true);
                                                                                                                                                                                                inputSigmaField.set(optimizer, inputSigma);
                                                                                                                                                                                                
                                                                                                                                                                                                // Call the private method using reflection
                                                                                                                                                                                                Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                                checkParameters.setAccessible(true);
                                                                                                                                                                                                
                                                                                                                                                                                                // This should not throw exception in original code
                                                                                                                                                                                                checkParameters.invoke(optimizer);
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify boundaries were set (proves last element was checked)
                                                                                                                                                                                                assertNotNull(boundariesField.get(optimizer));
                                                                                                                                                                                                
                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                                                                            }
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                      public void testCheckParametersWithOverflowBoundaries() {
                                                                                                                                                                                          // Setup test with boundaries that would cause overflow
                                                                                                                                                                                          double[] lowerBounds = new double[]{Double.MIN_VALUE};
                                                                                                                                                                                          double[] upperBounds = new double[]{Double.MAX_VALUE};
                                                                                                                                                                                          double[] startPoint = new double[]{0.0};
                                                                                                                                                                                          
                                                                                                                                                                                          // Create mock CMAESOptimizer
                                                                                                                                                                                          CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                                                                                          
                                                                                                                                                                                          // Mock the getter methods to return our test boundaries
                                                                                                                                                                                          when(optimizer.getLowerBound()).thenReturn(lowerBounds);
                                                                                                                                                                                          when(optimizer.getUpperBound()).thenReturn(upperBounds);
                                                                                                                                                                                          when(optimizer.getStartPoint()).thenReturn(startPoint);
                                                                                                                                                                                          
                                                                                                                                                                                          // Set inputSigma to a valid value using reflection
                                                                                                                                                                                          double[] inputSigma = new double[]{1.0};
                                                                                                                                                                                          try {
                                                                                                                                                                                              Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                                              inputSigmaField.setAccessible(true);
                                                                                                                                                                                              inputSigmaField.set(optimizer, inputSigma);
                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                              fail("Failed to set inputSigma field: " + e);
                                                                                                                                                                                          }
                                                                                                                                                                                          
                                                                                                                                                                                          // Call the real checkParameters method (not the mock)
                                                                                                                                                                                          // This requires using reflection since the method is private
                                                                                                                                                                                          try {
                                                                                                                                                                                              Method method = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                              method.setAccessible(true);
                                                                                                                                                                                              method.invoke(optimizer);
                                                                                                                                                                                          } catch (InvocationTargetException e) {
                                                                                                                                                                                              // We expect this to throw NumberIsTooLargeException
                                                                                                                                                                                              throw (RuntimeException) e.getCause();
                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                              fail("Unexpected exception: " + e);
                                                                                                                                                                                          }
                                                                                                                                                                                      }

    @Test(expected = NumberIsTooLargeException.class)
                                                                                                                                                                                  public void testCheckParametersDetectsBoundaryOverflowWithLargeLowerBound() {
                                                                                                                                                                                      // Setup test data
                                                                                                                                                                                      double[] lowerBounds = new double[]{Double.MAX_VALUE / 2};
                                                                                                                                                                                      double[] upperBounds = new double[]{Double.MAX_VALUE};
                                                                                                                                                                                      double[] startPoint = new double[]{Double.MAX_VALUE / 2};
                                                                                                                                                                                      double[] inputSigma = new double[]{1.0}; // Valid sigma
                                                                                                                                                                                      
                                                                                                                                                                                      // Create partial mock of CMAESOptimizer
                                                                                                                                                                                      CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                                                                                      
                                                                                                                                                                                      // Mock the methods called by checkParameters
                                                                                                                                                                                      when(optimizer.getLowerBound()).thenReturn(lowerBounds);
                                                                                                                                                                                      when(optimizer.getUpperBound()).thenReturn(upperBounds);
                                                                                                                                                                                      when(optimizer.getStartPoint()).thenReturn(startPoint);
                                                                                                                                                                                      
                                                                                                                                                                                      // Set inputSigma through reflection since it's private
                                                                                                                                                                                      try {
                                                                                                                                                                                          Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                                          inputSigmaField.setAccessible(true);
                                                                                                                                                                                          inputSigmaField.set(optimizer, inputSigma);
                                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                                          fail("Failed to set inputSigma through reflection");
                                                                                                                                                                                      }
                                                                                                                                                                                      
                                                                                                                                                                                      // Call the real checkParameters method
                                                                                                                                                                                      try {
                                                                                                                                                                                          Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                          checkParameters.setAccessible(true);
                                                                                                                                                                                          checkParameters.invoke(optimizer);
                                                                                                                                                                                      } catch (InvocationTargetException e) {
                                                                                                                                                                                          // We expect this to throw NumberIsTooLargeException
                                                                                                                                                                                          throw (RuntimeException) e.getCause();
                                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                                          fail("Failed to invoke checkParameters method");
                                                                                                                                                                                      }
                                                                                                                                                                                      
                                                                                                                                                                                      // If we get here, the test failed (no exception thrown)
                                                                                                                                                                                      fail("Expected NumberIsTooLargeException for boundary overflow");
                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                public void testCheckParametersBoundaryOverflow() throws Exception {
                                                                                                                                                                                    // Setup test data with boundaries that will cause overflow
                                                                                                                                                                                    double[] lowerBounds = new double[]{0.0};
                                                                                                                                                                                    double[] upperBounds = new double[]{Double.MAX_VALUE};
                                                                                                                                                                                    double[] initPoint = new double[]{0.0};
                                                                                                                                                                                    
                                                                                                                                                                                    // Create mock CMAESOptimizer instance
                                                                                                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock the getter methods to return our test data
                                                                                                                                                                                    CMAESOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                                                    when(spyOptimizer.getLowerBound()).thenReturn(lowerBounds);
                                                                                                                                                                                    when(spyOptimizer.getUpperBound()).thenReturn(upperBounds);
                                                                                                                                                                                    when(spyOptimizer.getStartPoint()).thenReturn(initPoint);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to set the private inputSigma field to null
                                                                                                                                                                                    Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                                    inputSigmaField.setAccessible(true);
                                                                                                                                                                                    inputSigmaField.set(spyOptimizer, null);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to get the private checkParameters method
                                                                                                                                                                                    Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                    checkParametersMethod.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // This should throw NumberIsTooLargeException due to boundary overflow
                                                                                                                                                                                    // If the mutant is present, this won't throw the exception
                                                                                                                                                                                    try {
                                                                                                                                                                                        checkParametersMethod.invoke(spyOptimizer);
                                                                                                                                                                                        fail("Expected NumberIsTooLargeException");
                                                                                                                                                                                    } catch (InvocationTargetException e) {
                                                                                                                                                                                        assertTrue(e.getCause() instanceof NumberIsTooLargeException);
                                                                                                                                                                                    }
                                                                                                                                                                                }

    @Test
                                                                                                                                                                           public void testCheckParametersOverflowMessage() {
                                                                                                                                                                               // Setup test data that will cause boundary overflow
                                                                                                                                                                               double[] lowerBounds = {Double.MIN_VALUE, Double.MIN_VALUE};
                                                                                                                                                                               double[] upperBounds = {Double.MAX_VALUE, Double.MAX_VALUE};
                                                                                                                                                                               double[] startPoint = {0.0, 0.0};
                                                                                                                                                                               double[] inputSigma = null; // Not relevant for this test
                                                                                                                                                                               
                                                                                                                                                                               // Mock the CMAESOptimizer and setup test scenario
                                                                                                                                                                               CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                                                                               when(optimizer.getLowerBound()).thenReturn(lowerBounds);
                                                                                                                                                                               when(optimizer.getUpperBound()).thenReturn(upperBounds);
                                                                                                                                                                               when(optimizer.getStartPoint()).thenReturn(startPoint);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to test private method
                                                                                                                                                                               try {
                                                                                                                                                                                   Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                                   checkParameters.setAccessible(true);
                                                                                                                                                                                   
                                                                                                                                                                                   // This should throw NumberIsTooLargeException due to boundary overflow
                                                                                                                                                                                   checkParameters.invoke(optimizer);
                                                                                                                                                                                   fail("Expected NumberIsTooLargeException");
                                                                                                                                                                               } catch (InvocationTargetException e) {
                                                                                                                                                                                   // Verify the exception contains the OVERFLOW message in its context
                                                                                                                                                                                   Throwable cause = e.getCause();
                                                                                                                                                                                   assertTrue(cause instanceof NumberIsTooLargeException);
                                                                                                                                                                                   NumberIsTooLargeException exception = (NumberIsTooLargeException) cause;
                                                                                                                                                                                   
                                                                                                                                                                                   // This assertion will fail if the mutant is present (commented line)
                                                                                                                                                                                   assertTrue(exception.getContext().getMessage().contains(LocalizedFormats.OVERFLOW.toString()));
                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                   fail("Unexpected exception: " + e.getClass().getSimpleName());
                                                                                                                                                                               }
                                                                                                                                                                           }

    @Test
                                                                                                                                                              public void testCheckParametersOverflowAtNonZeroIndex() {
                                                                                                                                                                  // Setup test with boundaries that will cause overflow at index 1
                                                                                                                                                                  double[] lowerBounds = {Double.MIN_VALUE, Double.MIN_VALUE};
                                                                                                                                                                  double[] upperBounds = {Double.MAX_VALUE, Double.MAX_VALUE + 1}; // Will overflow at index 1
                                                                                                                                                                  double[] startPoint = {0, 0};
                                                                                                                                                                  double[] inputSigma = null;
                                                                                                                                                                  
                                                                                                                                                                  // Mock the required methods
                                                                                                                                                                  CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                                                                  when(optimizer.getLowerBound()).thenReturn(lowerBounds);
                                                                                                                                                                  when(optimizer.getUpperBound()).thenReturn(upperBounds);
                                                                                                                                                                  when(optimizer.getStartPoint()).thenReturn(startPoint);
                                                                                                                                                                  
                                                                                                                                                                  // Use reflection to set private fields needed for the test
                                                                                                                                                                  try {
                                                                                                                                                                      Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                      boundariesField.setAccessible(true);
                                                                                                                                                                      Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                      inputSigmaField.setAccessible(true);
                                                                                                                                                                      inputSigmaField.set(optimizer, inputSigma);
                                                                                                                                                                      
                                                                                                                                                                      // Call the private method using reflection
                                                                                                                                                                      Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                      checkParameters.setAccessible(true);
                                                                                                                                                                      
                                                                                                                                                                      try {
                                                                                                                                                                          checkParameters.invoke(optimizer);
                                                                                                                                                                          fail("Expected NumberIsTooLargeException");
                                                                                                                                                                      } catch (InvocationTargetException e) {
                                                                                                                                                                          // Verify the correct exception was thrown
                                                                                                                                                                          assertTrue(e.getCause() instanceof NumberIsTooLargeException);
                                                                                                                                                                          NumberIsTooLargeException exception = (NumberIsTooLargeException) e.getCause();
                                                                                                                                                                          
                                                                                                                                                                          // Verify the context contains information about the overflow
                                                                                                                                                                          // The exception should contain the value that caused overflow (Double.MAX_VALUE + 1)
                                                                                                                                                                          // and the maximum allowed value (Double.MAX_VALUE)
                                                                                                                                                                          assertEquals(Double.MAX_VALUE + 1, exception.getArgument().doubleValue(), 0.0);
                                                                                                                                                                          assertEquals(Double.MAX_VALUE, exception.getMax().doubleValue(), 0.0);
                                                                                                                                                                      }
                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                      fail("Test setup failed: " + e.getMessage());
                                                                                                                                                                  }
                                                                                                                                                              }

    @Test
                                                                                                                                                         public void testCheckParametersDetectsBoundaryOverflow() {
                                                                                                                                                             // Setup test data that will cause boundary subtraction overflow
                                                                                                                                                             double[] init = new double[]{0.0};
                                                                                                                                                             double[] lB = new double[]{Double.MAX_VALUE};
                                                                                                                                                             double[] uB = new double[]{-Double.MAX_VALUE};
                                                                                                                                                             
                                                                                                                                                             // Create partial mock of CMAESOptimizer
                                                                                                                                                             CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                                                             
                                                                                                                                                             // Mock the boundary methods to return our test data
                                                                                                                                                             when(optimizer.getStartPoint()).thenReturn(init);
                                                                                                                                                             when(optimizer.getLowerBound()).thenReturn(lB);
                                                                                                                                                             when(optimizer.getUpperBound()).thenReturn(uB);
                                                                                                                                                             
                                                                                                                                                             // Set inputSigma to valid value to avoid other exceptions using reflection
                                                                                                                                                             try {
                                                                                                                                                                 Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                                 inputSigmaField.setAccessible(true);
                                                                                                                                                                 inputSigmaField.set(optimizer, new double[]{1.0});
                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                 fail("Failed to set inputSigma field: " + e);
                                                                                                                                                             }
                                                                                                                                                             
                                                                                                                                                             // Call the real checkParameters method
                                                                                                                                                             try {
                                                                                                                                                                 Method method = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                                 method.setAccessible(true);
                                                                                                                                                                 method.invoke(optimizer);
                                                                                                                                                             } catch (InvocationTargetException e) {
                                                                                                                                                                 // Unwrap the exception to verify it's the expected one
                                                                                                                                                                 throw (RuntimeException) e.getCause();
                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                 fail("Unexpected exception: " + e);
                                                                                                                                                             }
                                                                                                                                                             
                                                                                                                                                             // If we get here, the test fails (exception wasn't thrown)
                                                                                                                                                             fail("Expected NumberIsTooLargeException for boundary overflow");
                                                                                                                                                         }

    @Test
                                                                                                                                                    public void testCheckParametersWithAllInfiniteBounds1() throws Exception {
                                                                                                                                                        // Setup - create optimizer with all infinite bounds
                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                        
                                                                                                                                                        // Mock getLowerBound() and getUpperBound() to return arrays of infinite values
                                                                                                                                                        double[] infiniteBounds = new double[]{Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY};
                                                                                                                                                        
                                                                                                                                                        // Use reflection to mock the methods since they're not public in the actual class
                                                                                                                                                        Method getLowerBound = CMAESOptimizer.class.getDeclaredMethod("getLowerBound");
                                                                                                                                                        getLowerBound.setAccessible(true);
                                                                                                                                                        when(getLowerBound.invoke(optimizer)).thenReturn(infiniteBounds);
                                                                                                                                                        
                                                                                                                                                        Method getUpperBound = CMAESOptimizer.class.getDeclaredMethod("getUpperBound");
                                                                                                                                                        getUpperBound.setAccessible(true);
                                                                                                                                                        when(getUpperBound.invoke(optimizer)).thenReturn(infiniteBounds);
                                                                                                                                                        
                                                                                                                                                        // Mock getStartPoint() to return any finite array
                                                                                                                                                        double[] startPoint = new double[]{1.0, 2.0};
                                                                                                                                                        Method getStartPoint = CMAESOptimizer.class.getDeclaredMethod("getStartPoint");
                                                                                                                                                        getStartPoint.setAccessible(true);
                                                                                                                                                        when(getStartPoint.invoke(optimizer)).thenReturn(startPoint);
                                                                                                                                                        
                                                                                                                                                        // Set inputSigma to null using reflection
                                                                                                                                                        Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                                        inputSigmaField.setAccessible(true);
                                                                                                                                                        inputSigmaField.set(optimizer, null);
                                                                                                                                                        
                                                                                                                                                        // Execute checkParameters using reflection
                                                                                                                                                        Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                        checkParameters.setAccessible(true);
                                                                                                                                                        checkParameters.invoke(optimizer);
                                                                                                                                                        
                                                                                                                                                        // Verify - the key assertion to catch the mutant
                                                                                                                                                        Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                        boundariesField.setAccessible(true);
                                                                                                                                                        assertNull("Boundaries should be null when all bounds are infinite", boundariesField.get(optimizer));
                                                                                                                                                        
                                                                                                                                                        // Additional verification that no exceptions were thrown
                                                                                                                                                        // (since we're testing the no-finite-bounds case)
                                                                                                                                                    }

    @Test
                                                                                                                                               public void testCheckParametersDetectsInputSigmaNotNullMutation() throws Exception {
                                                                                                                                                   // Setup test data
                                                                                                                                                   double[] init = new double[]{1.0, 2.0};
                                                                                                                                                   double[] lB = new double[]{-10.0, -10.0};
                                                                                                                                                   double[] uB = new double[]{10.0, 10.0};
                                                                                                                                                   double[] inputSigma = new double[]{1.0}; // Wrong dimension - should trigger exception
                                                                                                                                                   
                                                                                                                                                   // Create partial mock of CMAESOptimizer
                                                                                                                                                   CMAESOptimizer optimizer = new CMAESOptimizer(10, inputSigma);
                                                                                                                                                   
                                                                                                                                                   // Mock the getter methods
                                                                                                                                                   CMAESOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                   when(spyOptimizer.getStartPoint()).thenReturn(init);
                                                                                                                                                   when(spyOptimizer.getLowerBound()).thenReturn(lB);
                                                                                                                                                   when(spyOptimizer.getUpperBound()).thenReturn(uB);
                                                                                                                                                   
                                                                                                                                                   // Get the private checkParameters method via reflection
                                                                                                                                                   Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                                   checkParametersMethod.setAccessible(true);
                                                                                                                                                   
                                                                                                                                                   try {
                                                                                                                                                       // Invoke the private method
                                                                                                                                                       checkParametersMethod.invoke(spyOptimizer);
                                                                                                                                                       // If we reach here, the mutant survived (no exception thrown)
                                                                                                                                                       fail("Mutant detected - inputSigma validation was skipped");
                                                                                                                                                   } catch (InvocationTargetException e) {
                                                                                                                                                       // Verify the correct exception was thrown
                                                                                                                                                       assertTrue(e.getCause() instanceof DimensionMismatchException);
                                                                                                                                                   }
                                                                                                                                               }

    @Test
                                                                                                                                          public void testCheckParametersWithMismatchedSigmaLength() throws Exception {
                                                                                                                                              // Setup test data with mismatched lengths
                                                                                                                                              double[] init = new double[]{1.0, 2.0, 3.0}; // length 3
                                                                                                                                              double[] inputSigma = new double[]{0.1, 0.2}; // length 2 (mismatch)
                                                                                                                                              
                                                                                                                                              // Mock the CMAESOptimizer and its methods
                                                                                                                                              CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                                              
                                                                                                                                              // Stub getStartPoint to return our test init array
                                                                                                                                              when(optimizer.getStartPoint()).thenReturn(init);
                                                                                                                                              
                                                                                                                                              // Stub getLowerBound/getUpperBound to return some bounds
                                                                                                                                              when(optimizer.getLowerBound()).thenReturn(new double[]{-10, -10, -10});
                                                                                                                                              when(optimizer.getUpperBound()).thenReturn(new double[]{10, 10, 10});
                                                                                                                                              
                                                                                                                                              // Use reflection to set the private inputSigma field
                                                                                                                                              Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                              inputSigmaField.setAccessible(true);
                                                                                                                                              inputSigmaField.set(optimizer, inputSigma);
                                                                                                                                              
                                                                                                                                              // Use reflection to call the private method
                                                                                                                                              Method method = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                              method.setAccessible(true);
                                                                                                                                              
                                                                                                                                              // The test expects DimensionMismatchException to be thrown
                                                                                                                                              try {
                                                                                                                                                  method.invoke(optimizer);
                                                                                                                                                  fail("Expected DimensionMismatchException");
                                                                                                                                              } catch (InvocationTargetException e) {
                                                                                                                                                  assertTrue(e.getCause() instanceof DimensionMismatchException);
                                                                                                                                              }
                                                                                                                                          }

    @Test(expected = DimensionMismatchException.class)
                                                                                                                                     public void testCheckParametersThrowsDimensionMismatchWhenInputSigmaLengthMismatch() throws Exception {
                                                                                                                                         // Setup
                                                                                                                                         CMAESOptimizer optimizer = new CMAESOptimizer(10);
                                                                                                                                         
                                                                                                                                         // Mock getStartPoint to return array of length 3
                                                                                                                                         optimizer = spy(optimizer);
                                                                                                                                         when(optimizer.getStartPoint()).thenReturn(new double[]{1.0, 2.0, 3.0});
                                                                                                                                         
                                                                                                                                         // Use reflection to set private inputSigma field
                                                                                                                                         Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                         inputSigmaField.setAccessible(true);
                                                                                                                                         inputSigmaField.set(optimizer, new double[]{0.1, 0.2});
                                                                                                                                         
                                                                                                                                         // Use reflection to call private checkParameters method
                                                                                                                                         Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                         checkParametersMethod.setAccessible(true);
                                                                                                                                         checkParametersMethod.invoke(optimizer);
                                                                                                                                     }

    @Test
                                                                                                                                public void testCheckParametersWithBoundariesAndInputSigma() throws Exception {
                                                                                                                                    // Setup test data
                                                                                                                                    double[] init = new double[]{1.0, 2.0, 3.0}; // length = 3
                                                                                                                                    double[] lB = new double[]{0.0, 1.0, 2.0};  // length = 3
                                                                                                                                    double[] uB = new double[]{2.0, 3.0, 4.0};  // length = 3
                                                                                                                                    double[] inputSigma = new double[]{0.5, 0.5, 0.5}; // length = 3
                                                                                                                                    
                                                                                                                                    // Create partial mock of CMAESOptimizer
                                                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer(10, inputSigma);
                                                                                                                                    optimizer = spy(optimizer);
                                                                                                                                    
                                                                                                                                    // Mock methods called by checkParameters()
                                                                                                                                    doReturn(init).when(optimizer).getStartPoint();
                                                                                                                                    doReturn(lB).when(optimizer).getLowerBound();
                                                                                                                                    doReturn(uB).when(optimizer).getUpperBound();
                                                                                                                                    
                                                                                                                                    // Use reflection to set boundaries
                                                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                    boundariesField.setAccessible(true);
                                                                                                                                    double[][] boundaries = new double[2][];
                                                                                                                                    boundaries[0] = lB;
                                                                                                                                    boundaries[1] = uB;
                                                                                                                                    boundariesField.set(optimizer, boundaries);
                                                                                                                                    
                                                                                                                                    // Use reflection to invoke checkParameters()
                                                                                                                                    Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                    checkParametersMethod.setAccessible(true);
                                                                                                                                    checkParametersMethod.invoke(optimizer);
                                                                                                                                }

    @Test
                                                                                                                           public void testCheckParametersWithZeroSigmaShouldNotThrowException() {
                                                                                                                               // Setup test data
                                                                                                                               double[] initPoint = new double[]{1.0, 2.0};
                                                                                                                               double[] lowerBounds = new double[]{Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY};
                                                                                                                               double[] upperBounds = new double[]{Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY};
                                                                                                                               double[] inputSigma = new double[]{0.0, 1.0}; // Contains zero value
                                                                                                                               
                                                                                                                               // Create partial mock of CMAESOptimizer
                                                                                                                               CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                               
                                                                                                                               // Mock the necessary methods
                                                                                                                               when(optimizer.getStartPoint()).thenReturn(initPoint);
                                                                                                                               when(optimizer.getLowerBound()).thenReturn(lowerBounds);
                                                                                                                               when(optimizer.getUpperBound()).thenReturn(upperBounds);
                                                                                                                               
                                                                                                                               // Set the private inputSigma field using reflection
                                                                                                                               try {
                                                                                                                                   Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                   inputSigmaField.setAccessible(true);
                                                                                                                                   inputSigmaField.set(optimizer, inputSigma);
                                                                                                                               } catch (Exception e) {
                                                                                                                                   fail("Failed to set inputSigma field via reflection");
                                                                                                                               }
                                                                                                                               
                                                                                                                               // Call the real method on the partial mock
                                                                                                                               try {
                                                                                                                                   Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                                   checkParameters.setAccessible(true);
                                                                                                                                   checkParameters.invoke(optimizer);
                                                                                                                                   
                                                                                                                                   // If we get here, the test passes (no exception thrown for zero value)
                                                                                                                               } catch (Exception e) {
                                                                                                                                   // If any exception is thrown, fail the test
                                                                                                                                   fail("Should not throw exception for zero inputSigma value");
                                                                                                                               }
                                                                                                                           }

    @Test(expected = NotPositiveException.class)
                                                                                                                      public void testCheckParametersThrowsNotPositiveExceptionForNegativeSigma() throws Exception {
                                                                                                                          // Setup test data with negative sigma value
                                                                                                                          double[] initPoint = new double[]{1.0, 2.0};
                                                                                                                          double[] lowerBound = new double[]{0.0, 0.0};
                                                                                                                          double[] upperBound = new double[]{10.0, 10.0};
                                                                                                                          double[] inputSigma = new double[]{1.0, -0.5}; // Negative value here
                                                                                                                          
                                                                                                                          // Create partial mock of CMAESOptimizer
                                                                                                                          CMAESOptimizer optimizer = new CMAESOptimizer(10, inputSigma);
                                                                                                                          
                                                                                                                          // Mock the getStartPoint, getLowerBound, and getUpperBound methods
                                                                                                                          CMAESOptimizer spyOptimizer = spy(optimizer);
                                                                                                                          when(spyOptimizer.getStartPoint()).thenReturn(initPoint);
                                                                                                                          when(spyOptimizer.getLowerBound()).thenReturn(lowerBound);
                                                                                                                          when(spyOptimizer.getUpperBound()).thenReturn(upperBound);
                                                                                                                          
                                                                                                                          // Use reflection to access private checkParameters method
                                                                                                                          Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                          checkParametersMethod.setAccessible(true);
                                                                                                                          
                                                                                                                          // This should throw NotPositiveException due to negative sigma
                                                                                                                          checkParametersMethod.invoke(spyOptimizer);
                                                                                                                      }

    @Test
                                                                                                                  public void testCheckParametersWithBoundariesAndSigma() {
                                                                                                                      // Setup test data - boundaries exist and inputSigma is provided
                                                                                                                      double[] lowerBounds = {0.0, 0.0};
                                                                                                                      double[] upperBounds = {1.0, 1.0};
                                                                                                                      double[] startPoint = {0.5, 0.5};
                                                                                                                      double[] inputSigma = {0.1, 0.1};
                                                                                                                      
                                                                                                                      // Create partial mock of CMAESOptimizer
                                                                                                                      CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                      
                                                                                                                      // Mock the getter methods to return our test data
                                                                                                                      when(optimizer.getLowerBound()).thenReturn(lowerBounds);
                                                                                                                      when(optimizer.getUpperBound()).thenReturn(upperBounds);
                                                                                                                      when(optimizer.getStartPoint()).thenReturn(startPoint);
                                                                                                                      
                                                                                                                      // Set the inputSigma field through reflection since it's private
                                                                                                                      try {
                                                                                                                          Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                          inputSigmaField.setAccessible(true);
                                                                                                                          inputSigmaField.set(optimizer, inputSigma);
                                                                                                                      } catch (Exception e) {
                                                                                                                          fail("Failed to set inputSigma field through reflection");
                                                                                                                      }
                                                                                                                      
                                                                                                                      // Call the real checkParameters method
                                                                                                                      try {
                                                                                                                          Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                          checkParameters.setAccessible(true);
                                                                                                                          checkParameters.invoke(optimizer);
                                                                                                                          
                                                                                                                          // Test passes - the validation was performed (original behavior)
                                                                                                                          // For mutant, this would throw OutOfRangeException incorrectly
                                                                                                                          
                                                                                                                          // Verify boundaries were set
                                                                                                                          Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                          boundariesField.setAccessible(true);
                                                                                                                          double[][] boundaries = (double[][]) boundariesField.get(optimizer);
                                                                                                                          assertNotNull(boundaries);
                                                                                                                          assertEquals(lowerBounds, boundaries[0]);
                                                                                                                          assertEquals(upperBounds, boundaries[1]);
                                                                                                                          
                                                                                                                      } catch (Exception e) {
                                                                                                                          fail("Unexpected exception: " + e.getMessage());
                                                                                                                      }
                                                                                                                      
                                                                                                                      // Now test with invalid sigma that should be caught by boundary check
                                                                                                                      double[] invalidSigma = {1.1, 1.1}; // Exceeds boundary range
                                                                                                                      try {
                                                                                                                          Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                          inputSigmaField.setAccessible(true);
                                                                                                                          inputSigmaField.set(optimizer, invalidSigma);
                                                                                                                          
                                                                                                                          Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                          checkParameters.setAccessible(true);
                                                                                                                          checkParameters.invoke(optimizer);
                                                                                                                          
                                                                                                                          fail("Expected OutOfRangeException not thrown");
                                                                                                                      } catch (InvocationTargetException e) {
                                                                                                                          // Original code should throw OutOfRangeException
                                                                                                                          assertTrue(e.getCause() instanceof OutOfRangeException);
                                                                                                                      } catch (Exception e) {
                                                                                                                          fail("Unexpected exception: " + e.getMessage());
                                                                                                                      }
                                                                                                                  }

    @Test
                                                                                                                public void testCheckParametersWithSigmaEqualToBoundRange() throws Exception {
                                                                                                                    // Setup test data
                                                                                                                    double[] lowerBounds = {0.0, 0.0};
                                                                                                                    double[] upperBounds = {1.0, 2.0};
                                                                                                                    double[] startPoint = {0.5, 1.0};
                                                                                                                    double[] inputSigma = {1.0, 2.0}; // Exactly equals upper-lower for each dimension
                                                                                                                    
                                                                                                                    // Create partial mock of CMAESOptimizer
                                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer(0, inputSigma);
                                                                                                                    
                                                                                                                    // Mock the boundary and start point methods
                                                                                                                    CMAESOptimizer spyOptimizer = spy(optimizer);
                                                                                                                    when(spyOptimizer.getLowerBound()).thenReturn(lowerBounds);
                                                                                                                    when(spyOptimizer.getUpperBound()).thenReturn(upperBounds);
                                                                                                                    when(spyOptimizer.getStartPoint()).thenReturn(startPoint);
                                                                                                                    
                                                                                                                    // Use reflection to access private checkParameters method
                                                                                                                    Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                                    checkParametersMethod.setAccessible(true);
                                                                                                                    
                                                                                                                    // Test - should not throw exception with original code
                                                                                                                    try {
                                                                                                                        checkParametersMethod.invoke(spyOptimizer);
                                                                                                                    } catch (InvocationTargetException e) {
                                                                                                                        if (e.getTargetException() instanceof OutOfRangeException) {
                                                                                                                            fail("Should accept inputSigma equal to boundary range");
                                                                                                                        }
                                                                                                                        throw e;
                                                                                                                    }
                                                                                                                    
                                                                                                                    // Additional verification - use reflection to access private boundaries field
                                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                    boundariesField.setAccessible(true);
                                                                                                                    double[][] boundaries = (double[][]) boundariesField.get(spyOptimizer);
                                                                                                                    assertNotNull(boundaries); // Verify boundaries were set
                                                                                                                }

    @Test(expected = OutOfRangeException.class)
                                                                                                           public void testCheckParametersDetectsSigmaExceedingBoundaries() throws Exception {
                                                                                                               // Setup test data
                                                                                                               double[] initPoint = new double[]{0.0, 0.0};
                                                                                                               double[] lowerBounds = new double[]{-1.0, -1.0};
                                                                                                               double[] upperBounds = new double[]{1.0, 1.0};
                                                                                                               double[] inputSigma = new double[]{0.5, 2.5}; // 2.5 exceeds boundary range of 2.0 (1.0 - (-1.0))
                                                                                                               
                                                                                                               // Create partial mock of CMAESOptimizer
                                                                                                               CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                               optimizer = spy(optimizer);
                                                                                                               
                                                                                                               // Mock methods called by checkParameters
                                                                                                               when(optimizer.getStartPoint()).thenReturn(initPoint);
                                                                                                               when(optimizer.getLowerBound()).thenReturn(lowerBounds);
                                                                                                               when(optimizer.getUpperBound()).thenReturn(upperBounds);
                                                                                                               
                                                                                                               // Set input sigma through reflection since it's private
                                                                                                               Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                               inputSigmaField.setAccessible(true);
                                                                                                               inputSigmaField.set(optimizer, inputSigma);
                                                                                                               
                                                                                                               // Get the private checkParameters method through reflection
                                                                                                               Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                               checkParametersMethod.setAccessible(true);
                                                                                                               
                                                                                                               // Invoke the private method which should throw OutOfRangeException
                                                                                                               checkParametersMethod.invoke(optimizer);
                                                                                                           }

    @Test
                                                                                                      public void testCheckParametersDetectsFiniteBoundsWithInfiniteUpperBound() throws Exception {
                                                                                                          // Setup test with:
                                                                                                          // - finite lower bound
                                                                                                          // - infinite upper bound
                                                                                                          // This should be detected as having finite bounds
                                                                                                          
                                                                                                          // Create test instance
                                                                                                          CMAESOptimizer optimizer = new CMAESOptimizer(10);
                                                                                                          
                                                                                                          // Mock getLowerBound() to return finite values
                                                                                                          CMAESOptimizer optimizerSpy = spy(optimizer);
                                                                                                          when(optimizerSpy.getLowerBound()).thenReturn(new double[]{1.0, 2.0});
                                                                                                          
                                                                                                          // Mock getUpperBound() to return one infinite value
                                                                                                          when(optimizerSpy.getUpperBound()).thenReturn(new double[]{Double.POSITIVE_INFINITY, 3.0});
                                                                                                          
                                                                                                          // Mock getStartPoint() - not relevant for this test
                                                                                                          when(optimizerSpy.getStartPoint()).thenReturn(new double[]{1.5, 2.5});
                                                                                                          
                                                                                                          // Use reflection to set inputSigma to null
                                                                                                          Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                          inputSigmaField.setAccessible(true);
                                                                                                          inputSigmaField.set(optimizerSpy, null);
                                                                                                          
                                                                                                          try {
                                                                                                              // Use reflection to call the private checkParameters method
                                                                                                              Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                              checkParametersMethod.setAccessible(true);
                                                                                                              checkParametersMethod.invoke(optimizerSpy);
                                                                                                              
                                                                                                              // Use reflection to verify boundaries were set
                                                                                                              Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                              boundariesField.setAccessible(true);
                                                                                                              double[][] boundaries = (double[][]) boundariesField.get(optimizerSpy);
                                                                                                              
                                                                                                              assertNotNull(boundaries);
                                                                                                              assertEquals(2, boundaries.length);
                                                                                                              assertEquals(1.0, boundaries[0][0], 0.0);
                                                                                                              assertEquals(2.0, boundaries[0][1], 0.0);
                                                                                                              assertTrue(Double.isInfinite(boundaries[1][0]));
                                                                                                              assertEquals(3.0, boundaries[1][1], 0.0);
                                                                                                          } catch (Exception e) {
                                                                                                              fail("Should not throw exception for this case");
                                                                                                          }
                                                                                                      }

    @Test
                                                                                                 public void testCheckParametersDetectsFiniteBoundsWhenOnlyOneBoundIsFinite() {
                                                                                                     // Setup test with mixed bounds - one finite, one infinite per dimension
                                                                                                     double[] init = new double[]{1.0, 2.0};
                                                                                                     double[] lB = new double[]{0.0, Double.NEGATIVE_INFINITY}; // First dimension has finite lower bound
                                                                                                     double[] uB = new double[]{Double.POSITIVE_INFINITY, 3.0}; // Second dimension has finite upper bound
                                                                                                     
                                                                                                     // Mock the CMAESOptimizer class to return our test bounds
                                                                                                     CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                     when(optimizer.getStartPoint()).thenReturn(init);
                                                                                                     when(optimizer.getLowerBound()).thenReturn(lB);
                                                                                                     when(optimizer.getUpperBound()).thenReturn(uB);
                                                                                                     
                                                                                                     // Set up input sigma (valid values)
                                                                                                     double[] inputSigma = new double[]{0.5, 0.5};
                                                                                                     
                                                                                                     // Use reflection to set private inputSigma field
                                                                                                     try {
                                                                                                         Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                         inputSigmaField.setAccessible(true);
                                                                                                         inputSigmaField.set(optimizer, inputSigma);
                                                                                                     } catch (Exception e) {
                                                                                                         fail("Failed to set inputSigma field: " + e.getMessage());
                                                                                                     }
                                                                                                     
                                                                                                     // Use reflection to call private method
                                                                                                     try {
                                                                                                         Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                         checkParameters.setAccessible(true);
                                                                                                         checkParameters.invoke(optimizer);
                                                                                                         
                                                                                                         // Verify boundaries were set (original behavior)
                                                                                                         Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                         boundariesField.setAccessible(true);
                                                                                                         double[][] boundaries = (double[][]) boundariesField.get(optimizer);
                                                                                                         
                                                                                                         assertNotNull("Boundaries should be set when either bound is finite", boundaries);
                                                                                                         assertEquals("Lower bounds should match", lB, boundaries[0]);
                                                                                                         assertEquals("Upper bounds should match", uB, boundaries[1]);
                                                                                                     } catch (Exception e) {
                                                                                                         fail("Exception during test: " + e.getMessage());
                                                                                                     }
                                                                                                 }

    @Test
                                                                                            public void testCheckParametersWithEarlyFiniteBound() throws Exception {
                                                                                                // Setup mock objects
                                                                                                CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                
                                                                                                // Mock methods called by checkParameters
                                                                                                when(optimizer.getStartPoint()).thenReturn(new double[]{0.0});
                                                                                                when(optimizer.getLowerBound()).thenReturn(new double[]{Double.NEGATIVE_INFINITY});
                                                                                                when(optimizer.getUpperBound()).thenReturn(new double[]{Double.POSITIVE_INFINITY});
                                                                                                
                                                                                                // Create large bounds array with finite value early
                                                                                                double[] largeLB = new double[10000];
                                                                                                double[] largeUB = new double[10000];
                                                                                                Arrays.fill(largeLB, Double.NEGATIVE_INFINITY);
                                                                                                Arrays.fill(largeUB, Double.POSITIVE_INFINITY);
                                                                                                // Set finite bound at position 10
                                                                                                largeLB[10] = -1.0;
                                                                                                
                                                                                                // Create real optimizer instance
                                                                                                CMAESOptimizer optimizerInstance = new CMAESOptimizer();
                                                                                                
                                                                                                // Use reflection to set private fields for testing
                                                                                                Field startPointField = CMAESOptimizer.class.getDeclaredField("startPoint");
                                                                                                startPointField.setAccessible(true);
                                                                                                startPointField.set(optimizerInstance, new double[1]);
                                                                                                
                                                                                                Field lowerBoundField = CMAESOptimizer.class.getDeclaredField("lowerBound");
                                                                                                lowerBoundField.setAccessible(true);
                                                                                                lowerBoundField.set(optimizerInstance, largeLB);
                                                                                                
                                                                                                Field upperBoundField = CMAESOptimizer.class.getDeclaredField("upperBound");
                                                                                                upperBoundField.setAccessible(true);
                                                                                                upperBoundField.set(optimizerInstance, largeUB);
                                                                                                
                                                                                                // Get private checkParameters method
                                                                                                Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                checkParametersMethod.setAccessible(true);
                                                                                                
                                                                                                // This should execute quickly if break works, timeout will catch mutant
                                                                                                checkParametersMethod.invoke(optimizerInstance);
                                                                                                
                                                                                                // Verify behavior is still correct
                                                                                                Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                boundariesField.setAccessible(true);
                                                                                                assertNull(boundariesField.get(optimizerInstance)); // Should be null when no finite bounds
                                                                                            }

    @Test
                                                                                            public void testCheckParametersWithMixedBounds() throws Exception {
                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                
                                                                                                // Mock methods to return mixed bounds
                                                                                                CMAESOptimizer spy = spy(optimizer);
                                                                                                doReturn(new double[]{0.0}).when(spy).getStartPoint();
                                                                                                doReturn(new double[]{-1.0, Double.NEGATIVE_INFINITY}).when(spy).getLowerBound();
                                                                                                doReturn(new double[]{1.0, Double.POSITIVE_INFINITY}).when(spy).getUpperBound();
                                                                                                
                                                                                                // Set inputSigma to null using reflection
                                                                                                Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                inputSigmaField.setAccessible(true);
                                                                                                inputSigmaField.set(spy, null);
                                                                                                
                                                                                                try {
                                                                                                    // Access private checkParameters method using reflection
                                                                                                    Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                                    checkParametersMethod.setAccessible(true);
                                                                                                    checkParametersMethod.invoke(spy);
                                                                                                    fail("Expected MathUnsupportedOperationException");
                                                                                                } catch (InvocationTargetException e) {
                                                                                                    if (e.getCause() instanceof MathUnsupportedOperationException) {
                                                                                                        // Expected exception for mixed bounds
                                                                                                    } else {
                                                                                                        throw e;
                                                                                                    }
                                                                                                }
                                                                                            }

    @Test
                                                                                       public void testCheckParametersWithMixedInfiniteBounds() throws Exception {
                                                                                           // Setup test with mixed bounds (one infinite, one finite)
                                                                                           double[] init = new double[]{1.0};
                                                                                           double[] lB = new double[]{Double.NEGATIVE_INFINITY}; // infinite lower bound
                                                                                           double[] uB = new double[]{1.0}; // finite upper bound
                                                                                           
                                                                                           // Create partial mock of CMAESOptimizer
                                                                                           CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                           optimizer = spy(optimizer);
                                                                                           
                                                                                           // Mock the getter methods to return our test bounds
                                                                                           doReturn(init).when(optimizer).getStartPoint();
                                                                                           doReturn(lB).when(optimizer).getLowerBound();
                                                                                           doReturn(uB).when(optimizer).getUpperBound();
                                                                                           
                                                                                           // Set inputSigma using reflection to avoid direct access to private field
                                                                                           Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                           inputSigmaField.setAccessible(true);
                                                                                           inputSigmaField.set(optimizer, new double[]{0.1});
                                                                                           
                                                                                           // Access checkParameters method via reflection
                                                                                           Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                           checkParametersMethod.setAccessible(true);
                                                                                           
                                                                                           // This should throw MathUnsupportedOperationException for mixed bounds
                                                                                           try {
                                                                                               checkParametersMethod.invoke(optimizer);
                                                                                               fail("Expected MathUnsupportedOperationException");
                                                                                           } catch (InvocationTargetException e) {
                                                                                               assertEquals(MathUnsupportedOperationException.class, e.getCause().getClass());
                                                                                           }
                                                                                       }

    @Test
                                                                              public void testCheckParametersDetectsEarlyExitForFiniteBounds() throws Exception {
                                                                                  // Setup test with multiple finite bounds
                                                                                  CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                  
                                                                                  // Mock getLowerBound() and getUpperBound() to return arrays with finite values
                                                                                  // First element is finite, others are infinite
                                                                                  double[] lowerBounds = new double[]{1.0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY};
                                                                                  double[] upperBounds = new double[]{2.0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY};
                                                                                  
                                                                                  // Mock the methods to return our test bounds
                                                                                  CMAESOptimizer spyOptimizer = spy(optimizer);
                                                                                  when(spyOptimizer.getLowerBound()).thenReturn(lowerBounds);
                                                                                  when(spyOptimizer.getUpperBound()).thenReturn(upperBounds);
                                                                                  when(spyOptimizer.getStartPoint()).thenReturn(new double[]{1.5, 0, 0});
                                                                                  
                                                                                  // Use reflection to access private checkParameters method
                                                                                  Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                                  checkParametersMethod.setAccessible(true);
                                                                                  
                                                                                  // Execute the test
                                                                                  checkParametersMethod.invoke(spyOptimizer);
                                                                                  
                                                                                  // Use reflection to access private boundaries field
                                                                                  Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                  boundariesField.setAccessible(true);
                                                                                  double[][] boundaries = (double[][]) boundariesField.get(spyOptimizer);
                                                                                  
                                                                                  // Verify boundaries were set
                                                                                  assertNotNull(boundaries);
                                                                                  
                                                                                  // Verify the correct bounds were stored
                                                                                  assertArrayEquals(lowerBounds, boundaries[0], 0.0);
                                                                                  assertArrayEquals(upperBounds, boundaries[1], 0.0);
                                                                              }

    @Test(expected = MathUnsupportedOperationException.class)
                                                                         public void testCheckParametersThrowsExceptionForMixedBounds() throws Exception {
                                                                             // Setup test data - mixed bounds (some finite, some infinite)
                                                                             double[] lowerBounds = new double[]{1.0, Double.NEGATIVE_INFINITY};
                                                                             double[] upperBounds = new double[]{2.0, Double.POSITIVE_INFINITY};
                                                                             double[] startPoint = new double[]{1.5, 0.0};
                                                                             
                                                                             // Create real instance of CMAESOptimizer
                                                                             CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                             
                                                                             // Use reflection to set private fields
                                                                             Field lowerBoundField = CMAESOptimizer.class.getDeclaredField("lowerBound");
                                                                             lowerBoundField.setAccessible(true);
                                                                             lowerBoundField.set(optimizer, lowerBounds);
                                                                             
                                                                             Field upperBoundField = CMAESOptimizer.class.getDeclaredField("upperBound");
                                                                             upperBoundField.setAccessible(true);
                                                                             upperBoundField.set(optimizer, upperBounds);
                                                                             
                                                                             Field startPointField = CMAESOptimizer.class.getDeclaredField("startPoint");
                                                                             startPointField.setAccessible(true);
                                                                             startPointField.set(optimizer, startPoint);
                                                                             
                                                                             // Use reflection to invoke private checkParameters method
                                                                             Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                             checkParametersMethod.setAccessible(true);
                                                                             checkParametersMethod.invoke(optimizer);
                                                                             
                                                                             // If we get here, the test fails (exception wasn't thrown)
                                                                             fail("Expected MathUnsupportedOperationException for mixed bounds");
                                                                         }

    @Test
                                                                    public void testCheckParametersDetectsFiniteBoundsInLastElement1() {
                                                                        // Setup test data where only the last element has finite bounds
                                                                        double[] init = new double[]{0.0, 0.0, 0.0};
                                                                        double[] lB = new double[]{Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, -1.0};
                                                                        double[] uB = new double[]{Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 1.0};
                                                                        
                                                                        // Mock the CMAESOptimizer class to return our test data
                                                                        CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                        when(optimizer.getStartPoint()).thenReturn(init);
                                                                        when(optimizer.getLowerBound()).thenReturn(lB);
                                                                        when(optimizer.getUpperBound()).thenReturn(uB);
                                                                        
                                                                        // Set up reflection to test private method and check boundaries field
                                                                        try {
                                                                            Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                            checkParameters.setAccessible(true);
                                                                            
                                                                            Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                            boundariesField.setAccessible(true);
                                                                            
                                                                            // This should detect finite bounds in original code
                                                                            // Mutant would miss it since it skips last element
                                                                            checkParameters.invoke(optimizer);
                                                                            
                                                                            // Verify boundaries were set (proves finite bounds were detected)
                                                                            double[][] boundaries = (double[][]) boundariesField.get(optimizer);
                                                                            assertNotNull("Boundaries should be set", boundaries);
                                                                            assertEquals(2, boundaries.length);
                                                                            assertEquals(lB, boundaries[0]);
                                                                            assertEquals(uB, boundaries[1]);
                                                                        } catch (Exception e) {
                                                                            fail("Exception during test: " + e.getMessage());
                                                                        }
                                                                    }

    @Test
                                                               public void testCheckParametersDetectsInfiniteBoundDifference() throws Exception {
                                                                   // Setup test with boundaries that will produce infinite difference
                                                                   CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                   
                                                                   // Mock the boundary methods to return test values
                                                                   // Lower bound: [0, 0], Upper bound: [Double.MAX_VALUE, Double.POSITIVE_INFINITY]
                                                                   // The second dimension will have infinite difference
                                                                   when(optimizer.getLowerBound()).thenReturn(new double[]{0, 0});
                                                                   when(optimizer.getUpperBound()).thenReturn(new double[]{Double.MAX_VALUE, Double.POSITIVE_INFINITY});
                                                                   
                                                                   // Mock start point
                                                                   when(optimizer.getStartPoint()).thenReturn(new double[]{0, 0});
                                                                   
                                                                   // Set input sigma (valid values) using reflection
                                                                   Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                   inputSigmaField.setAccessible(true);
                                                                   inputSigmaField.set(optimizer, new double[]{1.0, 1.0});
                                                                   
                                                                   // This should throw NumberIsTooLargeException due to infinite boundary difference
                                                                   try {
                                                                       Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                                       checkParametersMethod.setAccessible(true);
                                                                       checkParametersMethod.invoke(optimizer);
                                                                       fail("Expected NumberIsTooLargeException");
                                                                   } catch (InvocationTargetException e) {
                                                                       assertTrue(e.getCause() instanceof NumberIsTooLargeException);
                                                                   }
                                                               }

    @Test
                                                          public void testCheckParametersDetectsBoundaryOverflowWithLargeLowerBound1() throws Exception {
                                                              // Setup test data that would trigger the overflow check
                                                              double[] lowerBounds = {Double.MAX_VALUE / 2};
                                                              double[] upperBounds = {Double.MAX_VALUE};
                                                              double[] startPoint = {0};
                                                              double[] inputSigma = {1.0};
                                                              
                                                              // Create a partial mock of CMAESOptimizer to control the boundary methods
                                                              CMAESOptimizer optimizer = new CMAESOptimizer(0, inputSigma);
                                                              optimizer = spy(optimizer);
                                                              
                                                              // Mock the boundary methods to return our test data
                                                              doReturn(startPoint).when(optimizer).getStartPoint();
                                                              doReturn(lowerBounds).when(optimizer).getLowerBound();
                                                              doReturn(upperBounds).when(optimizer).getUpperBound();
                                                              
                                                              // Use reflection to call the private checkParameters method
                                                              Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                              checkParametersMethod.setAccessible(true);
                                                              
                                                              try {
                                                                  checkParametersMethod.invoke(optimizer);
                                                                  fail("Expected NumberIsTooLargeException");
                                                              } catch (InvocationTargetException e) {
                                                                  assertTrue(e.getCause() instanceof NumberIsTooLargeException);
                                                              }
                                                          }

    @Test
                                                     public void testCheckParametersDetectsBoundaryOverflow1() throws Exception {
                                                         // Setup test data where upperBound - lowerBound would overflow
                                                         double lowerBound = 1.0;
                                                         double upperBound = Double.MAX_VALUE + lowerBound; // This would overflow
                                                         
                                                         // Create mock CMAESOptimizer
                                                         CMAESOptimizer optimizer = new CMAESOptimizer(10);
                                                         
                                                         // Mock getLowerBound and getUpperBound to return our test bounds
                                                         when(optimizer.getLowerBound()).thenReturn(new double[]{lowerBound});
                                                         when(optimizer.getUpperBound()).thenReturn(new double[]{upperBound});
                                                         when(optimizer.getStartPoint()).thenReturn(new double[]{0.0});
                                                         
                                                         // Use reflection to set private inputSigma field
                                                         Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                         inputSigmaField.setAccessible(true);
                                                         inputSigmaField.set(optimizer, new double[]{1.0});
                                                         
                                                         // Use reflection to call private checkParameters method
                                                         Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                         checkParametersMethod.setAccessible(true);
                                                         
                                                         // This should throw NumberIsTooLargeException for original code
                                                         // The mutant would not throw because max is increased by 1
                                                         try {
                                                             checkParametersMethod.invoke(optimizer);
                                                             fail("Expected NumberIsTooLargeException");
                                                         } catch (InvocationTargetException e) {
                                                             assertTrue(e.getCause() instanceof NumberIsTooLargeException);
                                                         }
                                                     }

    @Test
                                        public void testCheckParametersOverflowExceptionMessages() throws Exception {
                                            // Setup test data that will trigger overflow condition
                                            double[] lowerBounds = new double[]{Double.MIN_VALUE};
                                            double[] upperBounds = new double[]{Double.MAX_VALUE};
                                            double[] initPoint = new double[]{0.0};
                                            
                                            // Create CMAESOptimizer instance with inputSigma through constructor
                                            double[] inputSigma = new double[]{1.0};
                                            CMAESOptimizer optimizer = new CMAESOptimizer(0, inputSigma);
                                            
                                            // Mock the get methods to return our test bounds
                                            CMAESOptimizer optimizerSpy = spy(optimizer);
                                            when(optimizerSpy.getLowerBound()).thenReturn(lowerBounds);
                                            when(optimizerSpy.getUpperBound()).thenReturn(upperBounds);
                                            when(optimizerSpy.getStartPoint()).thenReturn(initPoint);
                                            
                                            try {
                                                // Use reflection to invoke private checkParameters method
                                                Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                                                checkParametersMethod.setAccessible(true);
                                                checkParametersMethod.invoke(optimizerSpy);
                                                fail("Expected NumberIsTooLargeException");
                                            } catch (InvocationTargetException e) {
                                                Throwable cause = e.getCause();
                                                if (cause instanceof NumberIsTooLargeException) {
                                                    NumberIsTooLargeException ex = (NumberIsTooLargeException) cause;
                                                    // Verify both messages are present in the exception context
                                                    Object[] msgParts = ex.getLocalizedMessage().split(" > ");
                                                    boolean hasOverflow = ex.getLocalizedMessage().contains("overflow");
                                                    boolean hasIndex = ex.getLocalizedMessage().contains("0");
                                                    
                                                    assertTrue("Exception should contain OVERFLOW message", hasOverflow);
                                                    assertTrue("Exception should contain INDEX message", hasIndex);
                                                } else {
                                                    fail("Expected NumberIsTooLargeException but got " + cause.getClass().getSimpleName());
                                                }
                                            }
                                        }

    @Test
                       public void testCheckParametersOverflowReportsCorrectIndex() {
                           // Setup bounds that will cause overflow at index 1
                           double[] lowerBounds = new double[]{Double.MIN_VALUE, Double.MIN_VALUE};
                           double[] upperBounds = new double[]{Double.MAX_VALUE, Double.MAX_VALUE};
                           double[] inputSigma = null;
                           
                           // Mock the CMAESOptimizer to return our test bounds
                           CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                           when(optimizer.getLowerBound()).thenReturn(lowerBounds);
                           when(optimizer.getUpperBound()).thenReturn(upperBounds);
                           when(optimizer.getStartPoint()).thenReturn(new double[]{0, 0});
                           
                           // Use reflection to set private fields needed for the test
                           try {
                               Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                               boundariesField.setAccessible(true);
                               Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                               inputSigmaField.setAccessible(true);
                               inputSigmaField.set(optimizer, inputSigma);
                               
                               // The actual checkParameters method will be called
                               Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                               checkParameters.setAccessible(true);
                               
                               try {
                                   checkParameters.invoke(optimizer);
                                   fail("Expected NumberIsTooLargeException");
                               } catch (InvocationTargetException e) {
                                   // Verify the correct exception was thrown
                                   assertTrue(e.getCause() instanceof NumberIsTooLargeException);
                                   NumberIsTooLargeException ex = (NumberIsTooLargeException) e.getCause();
                                   
                                   // Verify the message contains the correct index (should be 1)
                                   assertTrue(ex.getMessage().contains("overflow"));
                                   assertTrue(ex.getMessage().contains("1"));
                               }
                           } catch (Exception e) {
                               fail("Test setup failed: " + e.getMessage());
                           }
                       }

    @Test
                  public void testCheckParametersThrowsWhenBoundaryRangeOverflows() {
                      // Setup test data that will cause boundary subtraction to overflow
                      double[] lowerBounds = new double[]{Double.MAX_VALUE};
                      double[] upperBounds = new double[]{Double.MAX_VALUE};
                      double[] initPoint = new double[]{0.0};
                      double[] inputSigma = new double[]{1.0}; // Valid sigma
                      
                      // Create mock CMAESOptimizer instance
                      CMAESOptimizer optimizer = new CMAESOptimizer();
                      
                      // Mock the getter methods to return our test bounds
                      when(optimizer.getLowerBound()).thenReturn(lowerBounds);
                      when(optimizer.getUpperBound()).thenReturn(upperBounds);
                      when(optimizer.getStartPoint()).thenReturn(initPoint);
                      
                      // Set input sigma using reflection
                      try {
                          Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
                          inputSigmaField.setAccessible(true);
                          inputSigmaField.set(optimizer, inputSigma);
                      } catch (Exception e) {
                          fail("Failed to set inputSigma field: " + e);
                      }
                      
                      try {
                          // Use reflection to access private method
                          Method checkParameters = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                          checkParameters.setAccessible(true);
                          checkParameters.invoke(optimizer);
                      } catch (InvocationTargetException e) {
                          // Unwrap the expected exception
                          throw (RuntimeException) e.getCause();
                      } catch (Exception e) {
                          fail("Unexpected exception: " + e);
                      }
                  }

    @Test(expected = NotPositiveException.class)
             public void testCheckParametersThrowsOnNegativeInputSigma() throws Exception {
                 // Setup test data with negative sigma value
                 double[] initPoint = new double[]{1.0, 2.0};
                 double[] lowerBound = new double[]{-10.0, -10.0};
                 double[] upperBound = new double[]{10.0, 10.0};
                 double[] negativeSigma = new double[]{0.1, -0.5}; // Second value is negative
                 
                 // Create partial mock of CMAESOptimizer
                 CMAESOptimizer optimizer = new CMAESOptimizer(10, negativeSigma);
                 
                 // Mock the getter methods to return our test data
                 CMAESOptimizer spyOptimizer = spy(optimizer);
                 when(spyOptimizer.getStartPoint()).thenReturn(initPoint);
                 when(spyOptimizer.getLowerBound()).thenReturn(lowerBound);
                 when(spyOptimizer.getUpperBound()).thenReturn(upperBound);
                 
                 // Use reflection to access private checkParameters method
                 Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
                 checkParametersMethod.setAccessible(true);
                 checkParametersMethod.invoke(spyOptimizer);
                 
                 // Additional verification that we actually checked the sigma values
                 verify(spyOptimizer, times(1)).getStartPoint();
                 verify(spyOptimizer, times(1)).getLowerBound();
                 verify(spyOptimizer, times(1)).getUpperBound();
             }

    @Test
    public void testCheckParametersWithSigmaEqualToBoundRange1() throws Exception {
        // Setup test data where inputSigma equals upper-lower bound
        double[] lowerBounds = {0.0, 0.0};
        double[] upperBounds = {1.0, 1.0};
        double[] startPoint = {0.5, 0.5};
        double[] inputSigma = {1.0, 1.0}; // Exactly equals upper-lower bound
        double delta = 0.0001; // Delta for floating-point comparisons
        
        // Create mock CMAESOptimizer
        CMAESOptimizer optimizer = new CMAESOptimizer(0, inputSigma);
        
        // Mock the get methods to return our test bounds
        optimizer = spy(optimizer);
        when(optimizer.getLowerBound()).thenReturn(lowerBounds);
        when(optimizer.getUpperBound()).thenReturn(upperBounds);
        when(optimizer.getStartPoint()).thenReturn(startPoint);
        
        try {
            // Use reflection to access private checkParameters method
            Method checkParametersMethod = CMAESOptimizer.class.getDeclaredMethod("checkParameters");
            checkParametersMethod.setAccessible(true);
            checkParametersMethod.invoke(optimizer);
            
            // Use reflection to verify boundaries were set properly
            Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
            boundariesField.setAccessible(true);
            double[][] boundaries = (double[][]) boundariesField.get(optimizer);
            
            assertNotNull(boundaries);
            assertArrayEquals(lowerBounds, boundaries[0], delta);
            assertArrayEquals(upperBounds, boundaries[1], delta);
        } catch (OutOfRangeException e) {
            // If we get here, mutant was detected
            fail("Mutant detected - threw exception when inputSigma equals bound range");
        }
    }


}
