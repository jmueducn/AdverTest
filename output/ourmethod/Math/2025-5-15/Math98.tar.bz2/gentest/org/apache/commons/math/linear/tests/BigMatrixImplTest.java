package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import java.math.BigDecimal;
 
public class BigMatrixImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                                                                                             public void testOperate_WithDecimalValues() {
                                                                                                                                 BigDecimal[][] decimalMatrix = {
                                                                                                                                     {new BigDecimal("0.1"), new BigDecimal("0.2"), new BigDecimal("0.3")},
                                                                                                                                     {new BigDecimal("0.4"), new BigDecimal("0.5"), new BigDecimal("0.6")}
                                                                                                                                 };
                                                                                                                                 BigDecimal[] decimalVector = {
                                                                                                                                     new BigDecimal("0.1"), new BigDecimal("0.2"), new BigDecimal("0.3")
                                                                                                                                 };
                                                                                                                                 BigMatrixImpl matrix = new BigMatrixImpl(decimalMatrix);
                                                                                                                                 BigDecimal[] result = matrix.operate(decimalVector);
                                                                                                                                 
                                                                                                                                 assertEquals(2, result.length);
                                                                                                                                 assertEquals(new BigDecimal("0.14"), result[0]); // 0.1*0.1 + 0.2*0.2 + 0.3*0.3 = 0.14
                                                                                                                                 assertEquals(new BigDecimal("0.32"), result[1]); // 0.4*0.1 + 0.5*0.2 + 0.6*0.3 = 0.32
                                                                                                                             }

 @Test
                                                                                                                             public void testOperate_WithEmptyVector() {
                                                                                                                                 BigDecimal[][] emptyMatrix = {{}, {}};
                                                                                                                                 BigMatrixImpl matrix = new BigMatrixImpl(emptyMatrix);
                                                                                                                                 BigDecimal[] emptyVector = {};
                                                                                                                                 
                                                                                                                                 BigDecimal[] result = matrix.operate(emptyVector);
                                                                                                                                 
                                                                                                                                 assertEquals(2, result.length);
                                                                                                                                 assertEquals(BigDecimal.ZERO, result[0]);
                                                                                                                                 assertEquals(BigDecimal.ZERO, result[1]);
                                                                                                                             }

 @Test
                                                                                                                             public void testOperate_DimensionMismatch() {
                                                                                                                                 // Create a 2x2 matrix
                                                                                                                                 BigDecimal[][] data = {
                                                                                                                                     {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                                                                     {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                                                                                 };
                                                                                                                                 BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                                 
                                                                                                                                 // Try to operate with vector of wrong length (3 instead of 2)
                                                                                                                                 double[] input = {1.0, 2.0, 3.0};
                                                                                                                                 
                                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                                 thrown.expectMessage("dimensions don't match");
                                                                                                                                 
                                                                                                                                 matrix.operate(input);
                                                                                                                             }

 @Test
                                                                                                                     public void testOperate_ValidInput_CorrectResult() {
                                                                                                                         // Define test matrix (2x3)
                                                                                                                         BigDecimal[][] TEST_MATRIX_2X3 = new BigDecimal[][] {
                                                                                                                             {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                                                                                                                             {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")}
                                                                                                                         };
                                                                                                                         // Define test vector (length 3)
                                                                                                                         BigDecimal[] TEST_VECTOR_3 = new BigDecimal[] {
                                                                                                                             new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")
                                                                                                                         };
                                                                                                                         
                                                                                                                         BigMatrixImpl matrix = new BigMatrixImpl(TEST_MATRIX_2X3);
                                                                                                                         BigDecimal[] result = matrix.operate(TEST_VECTOR_3);
                                                                                                                         
                                                                                                                         assertEquals(2, result.length);
                                                                                                                         assertEquals(new BigDecimal("14"), result[0]); // 1*1 + 2*2 + 3*3 = 14
                                                                                                                         assertEquals(new BigDecimal("32"), result[1]); // 4*1 + 5*2 + 6*3 = 32
                                                                                                                     }

 @Test
                                                                                                                     public void testOperate_WithZeroValues() {
                                                                                                                         BigDecimal[][] zeroMatrix = {
                                                                                                                             {BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO},
                                                                                                                             {BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO}
                                                                                                                         };
                                                                                                                         BigDecimal[] testVector = {
                                                                                                                             BigDecimal.ONE, 
                                                                                                                             BigDecimal.ONE, 
                                                                                                                             BigDecimal.ONE
                                                                                                                         };
                                                                                                                         BigMatrixImpl matrix = new BigMatrixImpl(zeroMatrix);
                                                                                                                         BigDecimal[] result = matrix.operate(testVector);
                                                                                                                         
                                                                                                                         assertEquals(2, result.length);
                                                                                                                         assertEquals(BigDecimal.ZERO, result[0]);
                                                                                                                         assertEquals(BigDecimal.ZERO, result[1]);
                                                                                                                     }

 @Test
                                                                                                                     public void testOperate_WithNegativeValues() {
                                                                                                                         BigDecimal[][] negativeMatrix = {
                                                                                                                             {new BigDecimal("-1"), new BigDecimal("-2"), new BigDecimal("-3")},
                                                                                                                             {new BigDecimal("-4"), new BigDecimal("-5"), new BigDecimal("-6")}
                                                                                                                         };
                                                                                                                         BigDecimal[] testVector = {
                                                                                                                             new BigDecimal("1"),
                                                                                                                             new BigDecimal("2"),
                                                                                                                             new BigDecimal("3")
                                                                                                                         };
                                                                                                                         BigMatrixImpl matrix = new BigMatrixImpl(negativeMatrix);
                                                                                                                         BigDecimal[] result = matrix.operate(testVector);
                                                                                                                         
                                                                                                                         assertEquals(2, result.length);
                                                                                                                         assertEquals(new BigDecimal("-14"), result[0]); // -1*1 + -2*2 + -3*3 = -14
                                                                                                                         assertEquals(new BigDecimal("-32"), result[1]); // -4*1 + -5*2 + -6*3 = -32
                                                                                                                     }

 @Test
                                                                                                                     public void testOperate_WithDifferentDimensions() {
                                                                                                                         // Define test matrix (3x2)
                                                                                                                         BigDecimal[][] TEST_MATRIX_3X2 = {
                                                                                                                             {new BigDecimal("1"), new BigDecimal("2")},
                                                                                                                             {new BigDecimal("3"), new BigDecimal("4")},
                                                                                                                             {new BigDecimal("5"), new BigDecimal("6")}
                                                                                                                         };
                                                                                                                         
                                                                                                                         // Define test vector (length 2)
                                                                                                                         BigDecimal[] TEST_VECTOR_2 = {
                                                                                                                             new BigDecimal("1"),
                                                                                                                             new BigDecimal("2")
                                                                                                                         };
                                                                                                                         
                                                                                                                         BigMatrixImpl matrix3x2 = new BigMatrixImpl(TEST_MATRIX_3X2);
                                                                                                                         BigDecimal[] result = matrix3x2.operate(TEST_VECTOR_2);
                                                                                                                         
                                                                                                                         assertEquals(3, result.length);
                                                                                                                         assertEquals(new BigDecimal("5"), result[0]);  // 1*1 + 2*2 = 5
                                                                                                                         assertEquals(new BigDecimal("11"), result[1]); // 3*1 + 4*2 = 11
                                                                                                                         assertEquals(new BigDecimal("17"), result[2]); // 5*1 + 6*2 = 17
                                                                                                                     }

 @Test
                                                                                                                     public void testOperate_WithIdentityMatrix() {
                                                                                                                         // Define test vector
                                                                                                                         BigDecimal[] testVector = {
                                                                                                                             new BigDecimal("1.0"),
                                                                                                                             new BigDecimal("2.0"),
                                                                                                                             new BigDecimal("3.0")
                                                                                                                         };
                                                                                                                         
                                                                                                                         BigDecimal[][] identityMatrix = {
                                                                                                                             {BigDecimal.ONE, BigDecimal.ZERO, BigDecimal.ZERO},
                                                                                                                             {BigDecimal.ZERO, BigDecimal.ONE, BigDecimal.ZERO},
                                                                                                                             {BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ONE}
                                                                                                                         };
                                                                                                                         BigMatrixImpl matrix = new BigMatrixImpl(identityMatrix);
                                                                                                                         BigDecimal[] result = matrix.operate(testVector);
                                                                                                                         
                                                                                                                         assertEquals(3, result.length);
                                                                                                                         assertEquals(testVector[0], result[0]);
                                                                                                                         assertEquals(testVector[1], result[1]);
                                                                                                                         assertEquals(testVector[2], result[2]);
                                                                                                                     }

 @Test
                                                                                                                     public void testOperate_EmptyArray() {
                                                                                                                         // Create a matrix (1x1 for simplicity)
                                                                                                                         BigMatrixImpl matrix = new BigMatrixImpl(new BigDecimal[][]{{new BigDecimal(1)}});
                                                                                                                         
                                                                                                                         // Set up expected exception
                                                                                                                         ExpectedException thrown = ExpectedException.none();
                                                                                                                         thrown.expect(IllegalArgumentException.class);
                                                                                                                         thrown.expectMessage("vector must have at least one element");
                                                                                                                         
                                                                                                                         // Test with empty array
                                                                                                                         double[] input = {};
                                                                                                                         matrix.operate(input);
                                                                                                                     }

 @Test
                                                                                                                 public void testOperate_ThrowsExceptionWhenVectorLengthMismatch() {
                                                                                                                     // Setup expected exception rule
                                                                                                                     ExpectedException exception = ExpectedException.none();
                                                                                                                     
                                                                                                                     // Define test matrix (2x3)
                                                                                                                     BigDecimal[][] TEST_MATRIX_2X3 = {
                                                                                                                         {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                                                                                                                         {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")}
                                                                                                                     };
                                                                                                                     BigMatrixImpl matrix = new BigMatrixImpl(TEST_MATRIX_2X3);
                                                                                                                     
                                                                                                                     // Define test vector (length 2)
                                                                                                                     BigDecimal[] TEST_VECTOR_2 = {
                                                                                                                         new BigDecimal("1"),
                                                                                                                         new BigDecimal("2")
                                                                                                                     };
                                                                                                                     
                                                                                                                     // Expect exception
                                                                                                                     exception.expect(IllegalArgumentException.class);
                                                                                                                     exception.expectMessage("vector has wrong length");
                                                                                                                     
                                                                                                                     // Try to operate with vector of length 2 when matrix has 3 columns
                                                                                                                     matrix.operate(TEST_VECTOR_2);
                                                                                                                 }

 @Test
                                                                                                                 public void testOperate_NullInput() {
                                                                                                                     org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                                                     BigMatrixImpl matrix = new BigMatrixImpl(new BigDecimal[0]);
                                                                                                                     thrown.expect(NullPointerException.class);
                                                                                                                     matrix.operate((BigDecimal[]) null);
                                                                                                                 }

 @Test
                                                                                                     public void testOperate_ValidInput() {
                                                                                                         // Create a matrix instance first
                                                                                                         BigMatrixImpl matrix = new BigMatrixImpl();
                                                                                                         double[] input = {1.5, 2.5};
                                                                                                         
                                                                                                         // Mock the operate(double[]) method to return predictable result
                                                                                                         BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                         BigDecimal[] expectedResult = {new BigDecimal("8.5"), new BigDecimal("14.5")};
                                                                                                         doReturn(expectedResult).when(spyMatrix).operate(any(double[].class));
                                                                                                         
                                                                                                         // Call operate(double[]) method
                                                                                                         BigDecimal[] result = spyMatrix.operate(input);
                                                                                                         
                                                                                                         assertNotNull(result);
                                                                                                         assertEquals(2, result.length);
                                                                                                         assertEquals(new BigDecimal("8.5"), result[0]);
                                                                                                         assertEquals(new BigDecimal("14.5"), result[1]);
                                                                                                         
                                                                                                         // Verify the conversion from double to BigDecimal was correct
                                                                                                         verify(spyMatrix).operate(argThat((double[] dArray) -> 
                                                                                                             dArray.length == 2 &&
                                                                                                             Math.abs(dArray[0] - 1.5) < 0.0001 &&
                                                                                                             Math.abs(dArray[1] - 2.5) < 0.0001
                                                                                                         ));
                                                                                                     }

 @Test
                                                                                                 public void testOperate_WithExtremeValues() {
                                                                                                     // Create a matrix instance first
                                                                                                     BigMatrixImpl matrix = new BigMatrixImpl();
                                                                                                     double[] input = {Double.MAX_VALUE, Double.MIN_VALUE};
                                                                                                     
                                                                                                     // Mock the internal operate method that takes double[]
                                                                                                     BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                     BigDecimal[] expectedResult = {new BigDecimal("1.0"), new BigDecimal("1.0")};
                                                                                                     doReturn(expectedResult).when(spyMatrix).operate(any(double[].class));
                                                                                                     
                                                                                                     BigDecimal[] result = spyMatrix.operate(input);
                                                                                                     
                                                                                                     assertNotNull(result);
                                                                                                     assertEquals(2, result.length);
                                                                                                     
                                                                                                     // Verify the conversion handled extreme values
                                                                                                     verify(spyMatrix).operate(argThat((double[] argument) -> {
                                                                                                         if (argument.length != 2) return false;
                                                                                                         BigDecimal bd1 = new BigDecimal(Double.toString(argument[0]));
                                                                                                         BigDecimal bd2 = new BigDecimal(Double.toString(argument[1]));
                                                                                                         return bd1.compareTo(new BigDecimal(Double.toString(Double.MAX_VALUE))) == 0 &&
                                                                                                                bd2.compareTo(new BigDecimal(Double.toString(Double.MIN_VALUE))) == 0;
                                                                                                     }));
                                                                                                 }

 @Test
                                                                                 public void testOperate_WithSpecialDoubleValues() {
                                                                                     // Create a matrix instance first
                                                                                     BigMatrixImpl matrix = new BigMatrixImpl();
                                                                                     double[] input = {Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY};
                                                                                     
                                                                                     // Mock the internal operate method
                                                                                     BigMatrixImpl spyMatrix = spy(matrix);
                                                                                     BigDecimal[] expectedResult = {BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO};
                                                                                     doReturn(expectedResult).when(spyMatrix).operate(any(double[].class));
                                                                                     
                                                                                     BigDecimal[] result = spyMatrix.operate(input);
                                                                                     
                                                                                     assertNotNull(result);
                                                                                     assertEquals(3, result.length);
                                                                                     
                                                                                     // Verify the conversion handled special double values by checking the mock interaction
                                                                                     verify(spyMatrix).operate(input);
                                                                                     
                                                                                     // Additional verification that special values are handled
                                                                                     try {
                                                                                         new BigDecimal(Double.NaN);
                                                                                         fail("Expected NumberFormatException for NaN");
                                                                                     } catch (NumberFormatException e) {
                                                                                         // expected
                                                                                     }
                                                                                     try {
                                                                                         new BigDecimal(Double.POSITIVE_INFINITY);
                                                                                         fail("Expected NumberFormatException for Infinity");
                                                                                     } catch (NumberFormatException e) {
                                                                                         // expected
                                                                                     }
                                                                                     try {
                                                                                         new BigDecimal(Double.NEGATIVE_INFINITY);
                                                                                         fail("Expected NumberFormatException for -Infinity");
                                                                                     } catch (NumberFormatException e) {
                                                                                         // expected
                                                                                     }
                                                                                 }

 @Test(expected = MatrixIndexException.class)
                                                                            public void testGetRowAsDoubleArray_InvalidRowForColumn() {
                                                                                // Create a 2x2 matrix for testing
                                                                                BigDecimal[][] testData = {
                                                                                    {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                    {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                                };
                                                                                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                                
                                                                                // Try to access row 2 which is invalid (valid rows are 0 and 1)
                                                                                // Should throw MatrixIndexException
                                                                                matrix.getRowAsDoubleArray(2);
                                                                                
                                                                                // If the mutation exists, the method would proceed to try accessing row 2
                                                                                // which would likely cause an ArrayIndexOutOfBoundsException
                                                                                // So we expect MatrixIndexException for original, but might get different
                                                                                // exception or no exception with mutation
                                                                            }

 @Test
                                                                            public void testGetRowAsDoubleArray_ValidRow() {
                                                                                // Create a test matrix with known values
                                                                                double[][] testData = {{1.0, 2.0}};
                                                                                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                                
                                                                                // Test getting the first row as double array
                                                                                double[] result = matrix.getRowAsDoubleArray(0);
                                                                                assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
                                                                            }

 @Test(expected = MatrixIndexException.class)
                                                                       public void testGetRowAsDoubleArrayWithInvalidRow() {
                                                                           // Create a test matrix
                                                                           double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
                                                                           BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                           
                                                                           // Test with row index -1 which should be invalid
                                                                           matrix.getRowAsDoubleArray(-1);
                                                                           
                                                                           // The test will pass if exception is thrown (original behavior)
                                                                           // The test will fail if no exception is thrown (mutated behavior)
                                                                       }

 @Test
                                                                       public void testGetRowAsDoubleArrayWithValidRow() {
                                                                           // Create test matrix with known values
                                                                           double[][] testData = {{1.0, 2.0}};
                                                                           BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                           
                                                                           // Test with valid row index 0
                                                                           double[] result = matrix.getRowAsDoubleArray(0);
                                                                           assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
                                                                           
                                                                           // This ensures valid rows still work correctly in both original and mutated code
                                                                       }

 @Test(expected = MatrixIndexException.class)
                                                                  public void testGetRowAsDoubleArrayThrowsMatrixIndexExceptionForInvalidRow() {
                                                                      // Create a 2x2 matrix (valid rows are 0 and 1)
                                                                      BigDecimal[][] data = {
                                                                          {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                          {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                      };
                                                                      BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                      
                                                                      // Test with row index that's too large (2)
                                                                      matrix.getRowAsDoubleArray(2); // Should throw MatrixIndexException
                                                                  }

 @Test(expected = MatrixIndexException.class)
                                                                  public void testGetRowAsDoubleArrayThrowsMatrixIndexExceptionForNegativeRow() {
                                                                      // Create a test matrix
                                                                      BigDecimal[][] testData = new BigDecimal[][] {
                                                                          {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                          {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                      };
                                                                      BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                      
                                                                      // Test with negative row index
                                                                      matrix.getRowAsDoubleArray(-1); // Should throw MatrixIndexException
                                                                  }

 @Test
                                                              public void testGetRowAsDoubleArrayDetectsColumnDimensionMutant() {
                                                                  // Create a 2x3 matrix with known values
                                                                  double[][] testData = {
                                                                      {1.0, 2.0, 3.0},
                                                                      {4.0, 5.0, 6.0}
                                                                  };
                                                                  BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                  
                                                                  // Test a valid row
                                                                  int testRow = 0;
                                                                  double[] expected = {1.0, 2.0, 3.0};
                                                                  double[] actual = matrix.getRowAsDoubleArray(testRow);
                                                                  
                                                                  // Verify array length (would fail with mutant returning empty array)
                                                                  assertEquals("Array length should match column dimension", 
                                                                              expected.length, actual.length);
                                                                  
                                                                  // Verify array contents (would fail with mutant returning empty array)
                                                                  assertArrayEquals("Array contents should match row data", 
                                                                                   expected, actual, 0.0001);
                                                                  
                                                                  // Additional test for another row to be thorough
                                                                  testRow = 1;
                                                                  expected = new double[]{4.0, 5.0, 6.0};
                                                                  actual = matrix.getRowAsDoubleArray(testRow);
                                                                  
                                                                  assertEquals("Second row array length should match column dimension", 
                                                                              expected.length, actual.length);
                                                                  assertArrayEquals("Second row array contents should match", 
                                                                                   expected, actual, 0.0001);
                                                              }

 @Test
                                                             public void testGetRowAsDoubleArrayDetectsColumnDimensionMutant1() {
                                                                 // Create a non-square matrix (2 rows x 3 columns)
                                                                 BigDecimal[][] testData = {
                                                                     {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                                                     {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                                                 };
                                                                 BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                 
                                                                 // Test first row
                                                                 double[] row0 = matrix.getRowAsDoubleArray(0);
                                                                 // Verify array length matches column dimension (3), not row dimension (2)
                                                                 assertEquals(3, row0.length);
                                                                 assertArrayEquals(new double[]{1.0, 2.0, 3.0}, row0, 0.0001);
                                                                 
                                                                 // Test second row
                                                                 double[] row1 = matrix.getRowAsDoubleArray(1);
                                                                 assertEquals(3, row1.length);
                                                                 assertArrayEquals(new double[]{4.0, 5.0, 6.0}, row1, 0.0001);
                                                                 
                                                                 // Verify invalid row throws exception
                                                                 try {
                                                                     matrix.getRowAsDoubleArray(2);
                                                                     fail("Expected MatrixIndexException for invalid row");
                                                                 } catch (MatrixIndexException e) {
                                                                     // Expected behavior
                                                                 }
                                                             }

 @Test
                                                            public void testGetRowAsDoubleArray_ArraySize() {
                                                                // Setup test matrix with known dimensions (2x3)
                                                                double[][] testData = {{1.0, 2.0, 3.0}, {4.0, 5.0, 6.0}};
                                                                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                
                                                                // Get row as double array
                                                                double[] rowArray = matrix.getRowAsDoubleArray(0);
                                                                
                                                                // Verify array length matches column dimension
                                                                assertEquals("Array length should match column dimension", 
                                                                             matrix.getColumnDimension(), 
                                                                             rowArray.length);
                                                                
                                                                // Additional verification that all elements were copied correctly
                                                                for (int i = 0; i < matrix.getColumnDimension(); i++) {
                                                                    assertEquals(testData[0][i], rowArray[i], 0.0001);
                                                                }
                                                            }

 @Test
                                                               public void testGetRowAsDoubleArray_ValidRow_ReturnsCorrectArray() {
                                                                   // Setup test data - create a 2x2 matrix
                                                                   BigDecimal[][] testData = {
                                                                       {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                       {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                   };
                                                                   BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                   
                                                                   // Call method under test
                                                                   double[] result = matrix.getRowAsDoubleArray(0);
                                                                   
                                                                   // Verify results
                                                                   assertNotNull("Returned array should not be null", result);
                                                                   assertEquals("Array length should match column dimension", 
                                                                                2, result.length);
                                                                   assertEquals(1.0, result[0], 0.0001);
                                                                   assertEquals(2.0, result[1], 0.0001);
                                                               }

 @Test(expected = NullPointerException.class)
                                                               public void testGetRowAsDoubleArray_MutatedVersion_ThrowsNPE() {
                                                                   // Setup test data - create a 2x2 matrix
                                                                   BigDecimal[][] testData = {
                                                                       {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                       {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                   };
                                                                   BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                   
                                                                   try {
                                                                       // This would normally work, but with the mutation it throws NPE
                                                                       matrix.getRowAsDoubleArray(0);
                                                                   } catch (NullPointerException e) {
                                                                       // Verify the exception message if needed
                                                                       // This assertion would fail in original version
                                                                       throw e;
                                                                   }
                                                               }

 @Test
                                                          public void testGetRowAsDoubleArrayDetectsBoundaryMutation() {
                                                              // Setup test matrix with known dimensions and values
                                                              BigDecimal[][] testData = {
                                                                  {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                  {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                              };
                                                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                              
                                                              // Test valid row access
                                                              double[] expected = {1.0, 2.0};
                                                              double[] actual = matrix.getRowAsDoubleArray(0);
                                                              
                                                              // Verify correct output
                                                              assertArrayEquals(expected, actual, 0.0001);
                                                              
                                                              // The mutation would cause ArrayIndexOutOfBoundsException here
                                                              // If no exception is thrown, the test passes (original behavior)
                                                              // If exception is thrown, the mutant is caught
                                                          }

 @Test
                                                         public void testGetRowAsDoubleArray_ShouldIncludeFirstColumn() {
                                                             // Setup test data - create a 2x2 matrix with known values
                                                             BigDecimal[][] testData = {
                                                                 {new BigDecimal("1.1"), new BigDecimal("2.2")},
                                                                 {new BigDecimal("3.3"), new BigDecimal("4.4")}
                                                             };
                                                             BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                             
                                                             // Call method under test
                                                             double[] result = matrix.getRowAsDoubleArray(0);
                                                             
                                                             // Verify results
                                                             assertEquals(2, result.length); // Should have 2 elements
                                                             assertEquals(1.1, result[0], 0.0001); // First element should be present
                                                             assertEquals(2.2, result[1], 0.0001); // Second element should be present
                                                             
                                                             // Additional test for another row to be thorough
                                                             double[] resultRow1 = matrix.getRowAsDoubleArray(1);
                                                             assertEquals(2, resultRow1.length);
                                                             assertEquals(3.3, resultRow1[0], 0.0001);
                                                             assertEquals(4.4, resultRow1[1], 0.0001);
                                                         }

 @Test(timeout = 1000) // Add timeout to catch infinite loop
                                                        public void testGetRowAsDoubleArrayDetectsIncrementMutant() {
                                                            // Setup test matrix with known values
                                                            BigDecimal[][] testData = {
                                                                {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                            };
                                                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                            
                                                            // Expected output for row 0
                                                            double[] expected = {1.0, 2.0};
                                                            
                                                            // Test the method
                                                            double[] result = matrix.getRowAsDoubleArray(0);
                                                            
                                                            // Verify correct output
                                                            assertArrayEquals(expected, result, 0.0001);
                                                            
                                                            // If mutant exists, either:
                                                            // 1. Test will timeout due to infinite loop
                                                            // 2. ArrayIndexOutOfBoundsException will be thrown
                                                            // Both cases will fail the test
                                                        }

 @Test
                                                       public void testGetRowAsDoubleArrayDetectsSwappedIndicesMutant() {
                                                           // Create a non-square 2x3 test matrix with distinct values
                                                           double[][] testData = {
                                                               {1.0, 2.0, 3.0},
                                                               {4.0, 5.0, 6.0}
                                                           };
                                                           BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                           
                                                           // Test row 0 - should return [1.0, 2.0, 3.0]
                                                           double[] row0 = matrix.getRowAsDoubleArray(0);
                                                           assertArrayEquals(new double[]{1.0, 2.0, 3.0}, row0, 0.0001);
                                                           
                                                           // Test row 1 - should return [4.0, 5.0, 6.0]
                                                           double[] row1 = matrix.getRowAsDoubleArray(1);
                                                           assertArrayEquals(new double[]{4.0, 5.0, 6.0}, row1, 0.0001);
                                                           
                                                           // The mutant would try to access data[i][row] which would:
                                                           // - For row0: try to access data[0][0], data[1][0], data[2][0] (out of bounds)
                                                           // - For row1: try to access data[0][1], data[1][1], data[2][1] (out of bounds)
                                                           // So this test would either fail on assertion or throw ArrayIndexOutOfBoundsException
                                                       }

 @Test
                                                      public void testGetRowAsDoubleArrayDetectsIntValueMutant() {
                                                          // Setup test data with decimal values that would show differences
                                                          // between intValue() and doubleValue()
                                                          BigDecimal[][] testData = {
                                                              {new BigDecimal("1.5"), new BigDecimal("2.999"), new BigDecimal("0.0001")}
                                                          };
                                                          
                                                          // Create the matrix under test
                                                          BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                          
                                                          // Call the method under test
                                                          double[] result = matrix.getRowAsDoubleArray(0);
                                                          
                                                          // Verify the results would fail if intValue() was used
                                                          assertEquals(1.5, result[0], 0.0001);  // 1.5 vs 1
                                                          assertEquals(2.999, result[1], 0.0001);  // 2.999 vs 2
                                                          assertEquals(0.0001, result[2], 0.00001);  // 0.0001 vs 0
                                                          
                                                          // Additional test with negative decimal
                                                          BigDecimal[][] testData2 = {
                                                              {new BigDecimal("-3.14159")}
                                                          };
                                                          matrix = new BigMatrixImpl(testData2);
                                                          result = matrix.getRowAsDoubleArray(0);
                                                          assertEquals(-3.14159, result[0], 0.00001);  // -3.14159 vs -3
                                                      }

 @Test
                                                     public void testGetRowAsDoubleArrayDetectsZeroValueMutation() {
                                                         // Setup test data with known non-zero values
                                                         BigDecimal[][] testData = {
                                                             {new BigDecimal("1.5"), new BigDecimal("2.7"), new BigDecimal("3.9")},
                                                             {new BigDecimal("4.1"), new BigDecimal("5.3"), new BigDecimal("6.5")}
                                                         };
                                                         
                                                         // Create matrix instance with test data
                                                         BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                         
                                                         // Call method under test
                                                         double[] result = matrix.getRowAsDoubleArray(0);
                                                         
                                                         // Verify the result matches expected values
                                                         assertEquals(3, result.length);
                                                         assertEquals(1.5, result[0], 0.0001);
                                                         assertEquals(2.7, result[1], 0.0001);
                                                         assertEquals(3.9, result[2], 0.0001);
                                                         
                                                         // Test another row to be thorough
                                                         result = matrix.getRowAsDoubleArray(1);
                                                         assertEquals(3, result.length);
                                                         assertEquals(4.1, result[0], 0.0001);
                                                         assertEquals(5.3, result[1], 0.0001);
                                                         assertEquals(6.5, result[2], 0.0001);
                                                     }

 @Test
                                                    public void testGetRowAsDoubleArrayReturnsCorrectArray() {
                                                        // Setup test data - create a 2x3 matrix with known values
                                                        double[][] testData = {{1.0, 2.0, 3.0}, {4.0, 5.0, 6.0}};
                                                        BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                        
                                                        // Test first row
                                                        double[] row0 = matrix.getRowAsDoubleArray(0);
                                                        assertEquals(3, row0.length); // Verify correct length
                                                        assertArrayEquals(new double[]{1.0, 2.0, 3.0}, row0, 0.0001); // Verify content
                                                        
                                                        // Test second row
                                                        double[] row1 = matrix.getRowAsDoubleArray(1);
                                                        assertEquals(3, row1.length); // Verify correct length
                                                        assertArrayEquals(new double[]{4.0, 5.0, 6.0}, row1, 0.0001); // Verify content
                                                        
                                                        // The mutant will fail both assertions by returning empty arrays
                                                    }

 @Test
                                                   public void testGetRowAsDoubleArray() {
                                                       // Setup test matrix with known values
                                                       BigDecimal[][] testData = {
                                                           {new BigDecimal("1.1"), new BigDecimal("2.2")},
                                                           {new BigDecimal("3.3"), new BigDecimal("4.4")}
                                                       };
                                                       BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                       
                                                       // Test valid row
                                                       double[] row0 = matrix.getRowAsDoubleArray(0);
                                                       assertEquals(2, row0.length); // Verify correct length
                                                       assertEquals(1.1, row0[0], 0.0001); // Verify exact values with delta for double comparison
                                                       assertEquals(2.2, row0[1], 0.0001);
                                                       
                                                       double[] row1 = matrix.getRowAsDoubleArray(1);
                                                       assertEquals(2, row1.length);
                                                       assertEquals(3.3, row1[0], 0.0001);
                                                       assertEquals(4.4, row1[1], 0.0001);
                                                       
                                                       // Test invalid row (negative)
                                                       try {
                                                           matrix.getRowAsDoubleArray(-1);
                                                           fail("Expected MatrixIndexException for negative row");
                                                       } catch (MatrixIndexException e) {
                                                           assertEquals("illegal row argument", e.getMessage());
                                                       }
                                                       
                                                       // Test invalid row (too large)
                                                       try {
                                                           matrix.getRowAsDoubleArray(2);
                                                           fail("Expected MatrixIndexException for row beyond dimension");
                                                       } catch (MatrixIndexException e) {
                                                           assertEquals("illegal row argument", e.getMessage());
                                                       }
                                                       
                                                       // Test with empty matrix (shouldn't be possible per constructor, but good to verify)
                                                       BigDecimal[][] emptyData = {{}};
                                                       BigMatrixImpl emptyMatrix = new BigMatrixImpl(emptyData);
                                                       try {
                                                           emptyMatrix.getRowAsDoubleArray(0);
                                                           fail("Expected IllegalArgumentException for empty matrix");
                                                       } catch (IllegalArgumentException e) {
                                                           // Expected
                                                       }
                                                   }

 @Test
                                                      public void testGetRowAsDoubleArrayValidRow() {
                                                          // Setup test data
                                                          BigDecimal[][] testData = {
                                                              {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                              {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                          };
                                                          BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                          
                                                          // Expected output
                                                          double[] expected = {1.0, 2.0};
                                                          
                                                          // Test execution
                                                          double[] result = matrix.getRowAsDoubleArray(0);
                                                          
                                                          // Verification
                                                          assertArrayEquals(expected, result, 0.0001);
                                                          
                                                          // Second row test
                                                          expected = new double[]{3.0, 4.0};
                                                          result = matrix.getRowAsDoubleArray(1);
                                                          assertArrayEquals(expected, result, 0.0001);
                                                      }

 @Test(expected = MatrixIndexException.class)
                                                      public void testGetRowAsDoubleArrayInvalidRow() {
                                                          BigDecimal[][] testData = {
                                                              {new BigDecimal("1.0"), new BigDecimal("2.0")}
                                                          };
                                                          BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                          
                                                          // This should throw MatrixIndexException
                                                          matrix.getRowAsDoubleArray(1);
                                                      }

 @Test
                                                      public void testGetRowAsDoubleArrayEmptyMatrix() {
                                                          BigDecimal[][] testData = {};
                                                          try {
                                                              new BigMatrixImpl(testData).getRowAsDoubleArray(0);
                                                              fail("Expected IllegalArgumentException");
                                                          } catch (IllegalArgumentException e) {
                                                              // Expected exception
                                                          }
                                                      }

 @Test
                                                 public void testGetRowAsDoubleArray_ValidRow_ReturnsCorrectArray1() {
                                                     // Setup test data
                                                     BigDecimal[][] testData = {
                                                         {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                         {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                     };
                                                     BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                     
                                                     // Call method under test
                                                     double[] result = matrix.getRowAsDoubleArray(1);
                                                     
                                                     // Verify results
                                                     assertNotNull(result);
                                                     assertEquals(2, result.length);
                                                     assertEquals(3.0, result[0], 0.0001);
                                                     assertEquals(4.0, result[1], 0.0001);
                                                 }

 @Test(expected = MatrixIndexException.class)
                                                 public void testGetRowAsDoubleArray_InvalidRow_ThrowsException() {
                                                     // Setup test data
                                                     BigDecimal[][] testData = {
                                                         {new BigDecimal("1.0"), new BigDecimal("2.0")}
                                                     };
                                                     BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                     
                                                     // Call method with invalid row (should throw exception)
                                                     matrix.getRowAsDoubleArray(1);
                                                 }

 @Test
                                                 public void testGetRowAsDoubleArray_EmptyRow_ReturnsEmptyArray() {
                                                     // Setup empty row test data
                                                     BigDecimal[][] testData = {
                                                         {}
                                                     };
                                                     BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                     
                                                     // Call method under test
                                                     double[] result = matrix.getRowAsDoubleArray(0);
                                                     
                                                     // Verify results
                                                     assertNotNull(result);
                                                     assertEquals(0, result.length);
                                                 }

 @Test
                                                    public void testGetRowAsDoubleArrayWithShorterInput() {
                                                        // This test will detect the mutant
                                                        // Create a matrix that would trigger the length check
                                                        BigDecimal[] shortRow = {new BigDecimal("1.0"), new BigDecimal("2.0")};
                                                        BigMatrixImpl smallMatrix = new BigMatrixImpl(new BigDecimal[][]{shortRow});
                                                        
                                                        // The mutated version would allow this while original would throw exception
                                                        double[] result = smallMatrix.getRowAsDoubleArray(0);
                                                        assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
                                                    }

 @Test
                                               public void testGetRowAsDoubleArrayWithValidRow1() {
                                                   // Create test matrix with known data
                                                   double[][] testData = {{1.0, 2.0, 3.0}};
                                                   BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                   
                                                   // Test normal case - should work in both original and mutated
                                                   double[] result = matrix.getRowAsDoubleArray(0);
                                                   assertArrayEquals(new double[]{1.0, 2.0, 3.0}, result, 0.0001);
                                               }

 @Test(expected = MatrixIndexException.class)
                                               public void testGetRowAsDoubleArrayWithInvalidRow1() {
                                                   // Test invalid row - should work in both original and mutated
                                                   // Create a 2x3 matrix (rows 0-1, columns 0-2)
                                                   BigDecimal[][] data = new BigDecimal[][] {
                                                       {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                                                       {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")}
                                                   };
                                                   BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                   // row 2 doesn't exist in 2x3 matrix - should throw exception
                                                   matrix.getRowAsDoubleArray(2);
                                               }

 @Test
                                          public void testGetRowAsDoubleArrayValidRow1() {
                                              // Create test matrix with known values
                                              double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
                                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                              
                                              double[] expected = {1.0, 2.0};
                                              double[] actual = matrix.getRowAsDoubleArray(0);
                                              assertArrayEquals(expected, actual, 0.0001);
                                          }

 @Test(expected = MatrixIndexException.class)
                                          public void testGetRowAsDoubleArrayInvalidRowNegative() {
                                              // Create a test matrix (2x2 matrix for simplicity)
                                              BigDecimal[][] testData = {
                                                  {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                  {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                              };
                                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                              
                                              // This should throw MatrixIndexException with "illegal row argument" message
                                              matrix.getRowAsDoubleArray(-1);
                                          }

 @Test
                                          public void testGetRowAsDoubleArrayInvalidRowTooLarge() {
                                              // Setup
                                              BigDecimal[][] testData = new BigDecimal[][] {
                                                  {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                  {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                              };
                                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                              
                                              // Exception testing setup
                                              ExpectedException exception = ExpectedException.none();
                                              exception.expect(MatrixIndexException.class);
                                              exception.expectMessage("illegal row argument");
                                              
                                              // Test - only rows 0 and 1 exist
                                              matrix.getRowAsDoubleArray(2);
                                          }

 @Test
                                          public void testGetRowAsDoubleArrayThrowsCorrectExceptionType() {
                                              // This test specifically checks the exception type is MatrixIndexException
                                              // and not RuntimeException or other types
                                              BigDecimal[][] testData = {
                                                  {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                  {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                              };
                                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                              
                                              try {
                                                  matrix.getRowAsDoubleArray(-1);
                                                  fail("Expected MatrixIndexException");
                                              } catch (MatrixIndexException e) {
                                                  assertEquals("illegal row argument", e.getMessage());
                                              } catch (RuntimeException e) {
                                                  fail("Expected MatrixIndexException but got " + e.getClass());
                                              }
                                          }

 @Test
                                     public void testGetRowAsDoubleArrayInvalidRowThrowsCorrectException() {
                                         // Create a matrix with sample data
                                         double[][] data = {{1.0, 2.0}, {3.0, 4.0}};
                                         BigMatrixImpl matrix = new BigMatrixImpl(data);
                                         
                                         int invalidRow = -1; // Clearly invalid row index
                                         
                                         try {
                                             matrix.getRowAsDoubleArray(invalidRow);
                                             fail("Expected MatrixIndexException");
                                         } catch (MatrixIndexException e) {
                                             // Verify the exact exception message
                                             assertEquals("illegal row argument", e.getMessage());
                                         }
                                     }

 @Test
                                     public void testGetRowAsDoubleArrayValidRowReturnsCorrectValues() {
                                         // Create test data
                                         double[][] testData = {{1.0, 2.0}};
                                         
                                         // Create matrix instance with test data
                                         BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                         
                                         // Expected and actual values
                                         double[] expected = {1.0, 2.0};
                                         double[] actual = matrix.getRowAsDoubleArray(0);
                                         
                                         // Assertion
                                         assertArrayEquals(expected, actual, 0.0001);
                                     }

 @Test
                                     public void testGetRowAsDoubleArrayBoundaryRow() {
                                         // Create a 2x2 test matrix
                                         double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
                                         BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                         
                                         // Test last valid row
                                         double[] expected = {3.0, 4.0};
                                         double[] actual = matrix.getRowAsDoubleArray(1);
                                         assertArrayEquals(expected, actual, 0.0001);
                                     }

 @Test
                                 public void testGetRowAsDoubleArray1() {
                                     // Setup test data
                                     BigDecimal[][] testData = {
                                         {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                         {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                     };
                                     BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                     
                                     // Test valid row
                                     double[] row0 = matrix.getRowAsDoubleArray(0);
                                     assertNotNull(row0);
                                     assertEquals(2, row0.length);
                                     assertEquals(1.0, row0[0], 0.0001);
                                     assertEquals(2.0, row0[1], 0.0001);
                                     
                                     double[] row1 = matrix.getRowAsDoubleArray(1);
                                     assertNotNull(row1);
                                     assertEquals(2, row1.length);
                                     assertEquals(3.0, row1[0], 0.0001);
                                     assertEquals(4.0, row1[1], 0.0001);
                                     
                                     // Test invalid row (negative)
                                     try {
                                         matrix.getRowAsDoubleArray(-1);
                                         fail("Expected MatrixIndexException for negative row");
                                     } catch (MatrixIndexException e) {
                                         assertEquals("illegal row argument", e.getMessage());
                                     }
                                     
                                     // Test invalid row (out of bounds)
                                     try {
                                         matrix.getRowAsDoubleArray(2);
                                         fail("Expected MatrixIndexException for out-of-bounds row");
                                     } catch (MatrixIndexException e) {
                                         assertEquals("illegal row argument", e.getMessage());
                                     }
                                     
                                     // Test empty matrix (shouldn't be possible based on constructors)
                                     // But included for completeness
                                     try {
                                         BigDecimal[][] emptyData = {};
                                         BigMatrixImpl emptyMatrix = new BigMatrixImpl(emptyData);
                                         emptyMatrix.getRowAsDoubleArray(0);
                                         fail("Expected IllegalArgumentException for empty matrix");
                                     } catch (IllegalArgumentException e) {
                                         // Expected
                                     }
                                 }

 @Test
                                public void testGetRowAsDoubleArray_ShouldDetectBraceMutation() {
                                    // Setup test data
                                    BigDecimal[][] testData = {
                                        {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                        {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                    };
                                    BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                    
                                    // Test valid row
                                    double[] result = matrix.getRowAsDoubleArray(0);
                                    assertNotNull(result);
                                    assertEquals(2, result.length);
                                    assertEquals(1.0, result[0], 0.0001);
                                    assertEquals(2.0, result[1], 0.0001);
                                    
                                    // Test another valid row to ensure full execution
                                    result = matrix.getRowAsDoubleArray(1);
                                    assertNotNull(result);
                                    assertEquals(2, result.length);
                                    assertEquals(3.0, result[0], 0.0001);
                                    assertEquals(4.0, result[1], 0.0001);
                                    
                                    // Test invalid row (should throw exception)
                                    try {
                                        matrix.getRowAsDoubleArray(-1);
                                        fail("Expected MatrixIndexException for invalid row");
                                    } catch (MatrixIndexException e) {
                                        assertEquals("illegal row argument", e.getMessage());
                                    }
                                    
                                    try {
                                        matrix.getRowAsDoubleArray(2); // out of bounds
                                        fail("Expected MatrixIndexException for invalid row");
                                    } catch (MatrixIndexException e) {
                                        assertEquals("illegal row argument", e.getMessage());
                                    }
                                    
                                    // Test empty matrix case
                                    BigDecimal[][] emptyData = {};
                                    BigMatrixImpl emptyMatrix = new BigMatrixImpl(emptyData);
                                    try {
                                        emptyMatrix.getRowAsDoubleArray(0);
                                        fail("Expected IllegalArgumentException for empty matrix");
                                    } catch (IllegalArgumentException e) {
                                        // Expected from constructor
                                    }
                                }

 @Test
                               public void testGetRowAsDoubleArray_ShouldReturnCorrectArray() {
                                   // Setup test data
                                   BigDecimal[][] testData = {
                                       {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                       {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                   };
                                   BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                   
                                   // Test valid row
                                   double[] result = matrix.getRowAsDoubleArray(1);
                                   
                                   // Verify array length matches column dimension
                                   assertEquals(3, result.length);
                                   
                                   // Verify all values are correctly copied
                                   assertEquals(4.0, result[0], 0.0001);
                                   assertEquals(5.0, result[1], 0.0001);
                                   assertEquals(6.0, result[2], 0.0001);
                                   
                                   // Test another row to ensure complete execution
                                   double[] result2 = matrix.getRowAsDoubleArray(0);
                                   assertEquals(3, result2.length);
                                   assertEquals(1.0, result2[0], 0.0001);
                                   assertEquals(2.0, result2[1], 0.0001);
                                   assertEquals(3.0, result2[2], 0.0001);
                               }

 @Test(expected = MatrixIndexException.class)
                               public void testGetRowAsDoubleArray_InvalidRow_ShouldThrowException() {
                                   BigDecimal[][] testData = {{new BigDecimal("1.0")}};
                                   BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                   
                                   // This should throw MatrixIndexException
                                   matrix.getRowAsDoubleArray(-1);
                               }

 @Test
                              public void testGetRowAsDoubleArrayCompilationCheck() {
                                  // Setup test data - create a simple 2x2 matrix
                                  BigDecimal[][] testData = {
                                      {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                      {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                  };
                                  BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                  
                                  // Test valid row access
                                  double[] row0 = matrix.getRowAsDoubleArray(0);
                                  assertNotNull(row0);
                                  assertEquals(2, row0.length);
                                  assertEquals(1.0, row0[0], 0.0001);
                                  assertEquals(2.0, row0[1], 0.0001);
                                  
                                  // Test another valid row
                                  double[] row1 = matrix.getRowAsDoubleArray(1);
                                  assertNotNull(row1);
                                  assertEquals(2, row1.length);
                                  assertEquals(3.0, row1[0], 0.0001);
                                  assertEquals(4.0, row1[1], 0.0001);
                                  
                                  // Test invalid row (should throw exception)
                                  try {
                                      matrix.getRowAsDoubleArray(2);
                                      fail("Expected MatrixIndexException");
                                  } catch (MatrixIndexException e) {
                                      // Expected behavior
                                  }
                              }

 @Test
                             public void testGetRowAsDoubleArray2() {
                                 // Setup test data
                                 BigDecimal[][] testData = {
                                     {new BigDecimal("1.1"), new BigDecimal("2.2")},
                                     {new BigDecimal("3.3"), new BigDecimal("4.4")}
                                 };
                                 BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                 
                                 // Test valid row
                                 double[] expectedRow0 = {1.1, 2.2};
                                 double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                                 assertArrayEquals(expectedRow0, actualRow0, 0.0001);
                                 
                                 double[] expectedRow1 = {3.3, 4.4};
                                 double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                                 assertArrayEquals(expectedRow1, actualRow1, 0.0001);
                                 
                                 // Test invalid row (negative)
                                 try {
                                     matrix.getRowAsDoubleArray(-1);
                                     fail("Expected MatrixIndexException for negative row");
                                 } catch (MatrixIndexException e) {
                                     assertEquals("illegal row argument", e.getMessage());
                                 }
                                 
                                 // Test invalid row (out of bounds)
                                 try {
                                     matrix.getRowAsDoubleArray(2);
                                     fail("Expected MatrixIndexException for out-of-bounds row");
                                 } catch (MatrixIndexException e) {
                                     assertEquals("illegal row argument", e.getMessage());
                                 }
                                 
                                 // Test empty matrix (shouldn't be possible based on constructors)
                                 BigDecimal[][] emptyData = {};
                                 try {
                                     BigMatrixImpl emptyMatrix = new BigMatrixImpl(emptyData);
                                     fail("Expected IllegalArgumentException for empty matrix");
                                 } catch (IllegalArgumentException e) {
                                     // Expected
                                 }
                             }

 @Test
                            public void testGetRowAsDoubleArray3() throws Exception {
                                // Setup test data
                                BigDecimal[][] testData = {
                                    {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                    {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                };
                                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                
                                // Test valid row
                                double[] expectedRow0 = {1.0, 2.0};
                                double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                                assertArrayEquals(expectedRow0, actualRow0, 0.0001);
                                
                                double[] expectedRow1 = {3.0, 4.0};
                                double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                                assertArrayEquals(expectedRow1, actualRow1, 0.0001);
                                
                                // Test invalid row (should throw exception)
                                try {
                                    matrix.getRowAsDoubleArray(2);
                                    fail("Expected MatrixIndexException for invalid row");
                                } catch (MatrixIndexException e) {
                                    assertEquals("illegal row argument", e.getMessage());
                                }
                                
                                // Test empty matrix
                                BigDecimal[][] emptyData = {{}};
                                BigMatrixImpl emptyMatrix = new BigMatrixImpl(emptyData);
                                double[] emptyRow = emptyMatrix.getRowAsDoubleArray(0);
                                assertEquals(0, emptyRow.length);
                            }

 @Test
                               public void testGetRowAsDoubleArrayValidInput() {
                                   // Setup test data
                                   BigDecimal[][] testData = {
                                       {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                       {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                   };
                                   BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                   
                                   // Test valid row access
                                   double[] row0 = matrix.getRowAsDoubleArray(0);
                                   assertEquals(1.0, row0[0], 0.0001);
                                   assertEquals(2.0, row0[1], 0.0001);
                                   
                                   double[] row1 = matrix.getRowAsDoubleArray(1);
                                   assertEquals(3.0, row1[0], 0.0001);
                                   assertEquals(4.0, row1[1], 0.0001);
                               }

 @Test
                          public void testGetRowAsDoubleArrayThrowsCorrectException() {
                              // Setup test data - create a matrix with invalid row access
                              BigDecimal[][] testData = {
                                  {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                  {new BigDecimal("3.0"), new BigDecimal("4.0")}
                              };
                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                              
                              // Test negative row index
                              try {
                                  matrix.getRowAsDoubleArray(-1);
                                  fail("Expected MatrixIndexException for negative row index");
                              } catch (MatrixIndexException e) {
                                  assertEquals("illegal row argument", e.getMessage());
                              }
                              
                              // Test row index beyond matrix dimensions
                              try {
                                  matrix.getRowAsDoubleArray(2); // Only rows 0 and 1 exist
                                  fail("Expected MatrixIndexException for row index beyond dimensions");
                              } catch (MatrixIndexException e) {
                                  assertEquals("illegal row argument", e.getMessage());
                              }
                              
                              // Test very large row index
                              try {
                                  matrix.getRowAsDoubleArray(100);
                                  fail("Expected MatrixIndexException for large row index");
                              } catch (MatrixIndexException e) {
                                  assertEquals("illegal row argument", e.getMessage());
                              }
                          }

 @Test
                          public void testGetRowAsDoubleArrayReturnsCorrectValues() {
                              // Create test data
                              BigDecimal[][] testData = new BigDecimal[2][2];
                              testData[0][0] = new BigDecimal("1.0");
                              testData[0][1] = new BigDecimal("2.0");
                              testData[1][0] = new BigDecimal("3.0");
                              testData[1][1] = new BigDecimal("4.0");
                              
                              BigMatrixImpl matrix = new BigMatrixImpl(testData, false);
                              
                              // Test valid row
                              double[] result = matrix.getRowAsDoubleArray(0);
                              assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
                              
                              result = matrix.getRowAsDoubleArray(1);
                              assertArrayEquals(new double[]{3.0, 4.0}, result, 0.0001);
                          }

 @Test
                     public void testGetRowAsDoubleArrayThrowsCorrectExceptionMessage() {
                         // Create a test matrix with mock data
                         BigDecimal[][] mockData = new BigDecimal[2][2];
                         mockData[0][0] = new BigDecimal("1.0");
                         mockData[0][1] = new BigDecimal("2.0");
                         mockData[1][0] = new BigDecimal("3.0");
                         mockData[1][1] = new BigDecimal("4.0");
                         
                         BigMatrixImpl matrix = new BigMatrixImpl(mockData, false);
                         
                         // Set up exception expectation
                         thrown.expect(MatrixIndexException.class);
                         thrown.expectMessage("illegal row argument");
                         
                         // Trigger the exception by passing invalid row number
                         // Matrix only has 2 rows (0 and 1), so 5 is invalid
                         matrix.getRowAsDoubleArray(5);
                     }

 @Test
                     public void testGetRowAsDoubleArray4() {
                         // Setup test matrix with known values
                         BigDecimal[][] testData = {
                             {new BigDecimal("1.1"), new BigDecimal("2.2")},
                             {new BigDecimal("3.3"), new BigDecimal("4.4")}
                         };
                         BigMatrixImpl matrix = new BigMatrixImpl(testData);
                         
                         // Test valid row
                         double[] row0 = matrix.getRowAsDoubleArray(0);
                         assertArrayEquals(new double[]{1.1, 2.2}, row0, 0.0001);
                         
                         double[] row1 = matrix.getRowAsDoubleArray(1);
                         assertArrayEquals(new double[]{3.3, 4.4}, row1, 0.0001);
                         
                         // Test row dimensions
                         assertEquals(2, row0.length);
                         assertEquals(2, row1.length);
                     }

 @Test(expected = MatrixIndexException.class)
                     public void testGetRowAsDoubleArrayInvalidRow1() {
                         BigDecimal[][] testData = {{new BigDecimal("1.0")}};
                         BigMatrixImpl matrix = new BigMatrixImpl(testData);
                         
                         // This should throw MatrixIndexException
                         matrix.getRowAsDoubleArray(-1);
                     }

 @Test(expected = MatrixIndexException.class)
                     public void testGetRowAsDoubleArrayRowOutOfBounds() {
                         BigDecimal[][] testData = {{new BigDecimal("1.0")}};
                         BigMatrixImpl matrix = new BigMatrixImpl(testData);
                         
                         // This should throw MatrixIndexException
                         matrix.getRowAsDoubleArray(1);
                     }

 @Test
                public void testGetRowAsDoubleArray5() throws Exception {
                    // Setup test data
                    BigDecimal[][] testData = {
                        {new BigDecimal("1.0"), new BigDecimal("2.0")},
                        {new BigDecimal("3.0"), new BigDecimal("4.0")}
                    };
                    BigMatrixImpl matrix = new BigMatrixImpl(testData);
                    
                    // Test valid row
                    double[] result = matrix.getRowAsDoubleArray(0);
                    assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
                    
                    // Test another valid row
                    result = matrix.getRowAsDoubleArray(1);
                    assertArrayEquals(new double[]{3.0, 4.0}, result, 0.0001);
                    
                    // Test invalid row (negative)
                    try {
                        matrix.getRowAsDoubleArray(-1);
                        fail("Expected MatrixIndexException");
                    } catch (MatrixIndexException e) {
                        assertEquals("illegal row argument", e.getMessage());
                    }
                    
                    // Test invalid row (out of bounds)
                    try {
                        matrix.getRowAsDoubleArray(2);
                        fail("Expected MatrixIndexException");
                    } catch (MatrixIndexException e) {
                        assertEquals("illegal row argument", e.getMessage());
                    }
                }

 @Test
                   public void testGetRowAsDoubleArrayReturnsCompleteArray() {
                       // Setup test matrix with known values
                       BigDecimal[][] testData = {
                           {new BigDecimal("1.1"), new BigDecimal("2.2")},
                           {new BigDecimal("3.3"), new BigDecimal("4.4")}
                       };
                       BigMatrixImpl matrix = new BigMatrixImpl(testData);
                       
                       // Expected values
                       double[] expectedRow0 = {1.1, 2.2};
                       double[] expectedRow1 = {3.3, 4.4};
                       
                       // Test first row
                       double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                       assertArrayEquals("First row values don't match", expectedRow0, actualRow0, 0.0001);
                       assertEquals("First row length doesn't match column dimension", 
                                   matrix.getColumnDimension(), actualRow0.length);
                       
                       // Test second row
                       double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                       assertArrayEquals("Second row values don't match", expectedRow1, actualRow1, 0.0001);
                       assertEquals("Second row length doesn't match column dimension", 
                                   matrix.getColumnDimension(), actualRow1.length);
                   }

 @Test(expected = MatrixIndexException.class)
                   public void testGetRowAsDoubleArrayThrowsExceptionForInvalidRow() {
                       BigDecimal[][] testData = {{new BigDecimal("1.0")}};
                       BigMatrixImpl matrix = new BigMatrixImpl(testData);
                       
                       // This should throw MatrixIndexException
                       matrix.getRowAsDoubleArray(-1);
                   }

 @Test
                  public void testGetRowAsDoubleArray6() {
                      // Setup test data
                      BigDecimal[][] testData = {
                          {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                          {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                      };
                      BigMatrixImpl matrix = new BigMatrixImpl(testData);
                      
                      // Test valid row
                      double[] expectedRow0 = {1.0, 2.0, 3.0};
                      double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                      assertArrayEquals("Row 0 contents don't match", expectedRow0, actualRow0, 0.0001);
                      
                      // Test another valid row
                      double[] expectedRow1 = {4.0, 5.0, 6.0};
                      double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                      assertArrayEquals("Row 1 contents don't match", expectedRow1, actualRow1, 0.0001);
                      
                      // Test array length matches column dimension
                      assertEquals("Array length should match column dimension", 
                                  matrix.getColumnDimension(), actualRow0.length);
                  }

 @Test(expected = MatrixIndexException.class)
                  public void testGetRowAsDoubleArrayInvalidRow2() {
                      BigDecimal[][] testData = {{new BigDecimal("1.0")}};
                      BigMatrixImpl matrix = new BigMatrixImpl(testData);
                      
                      // This should throw MatrixIndexException
                      matrix.getRowAsDoubleArray(-1);
                  }

 @Test
                  public void testGetRowAsDoubleArrayEmptyMatrix1() {
                      BigDecimal[][] emptyData = {{}};
                      BigMatrixImpl matrix = new BigMatrixImpl(emptyData);
                      
                      double[] result = matrix.getRowAsDoubleArray(0);
                      assertNotNull("Result should not be null", result);
                      assertEquals("Empty row should return empty array", 0, result.length);
                  }

 @Test
                 public void testGetRowAsDoubleArrayWithDifferentLengthInput() {
                     // Create a 2x3 matrix for testing
                     BigDecimal[][] testData = {
                         {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                         {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                     };
                     BigMatrixImpl matrix = new BigMatrixImpl(testData);
                     
                     // Test with array of correct length (3) - should pass
                     double[] correctLengthArray = {1.0, 2.0, 3.0};
                     double[] result = matrix.getRowAsDoubleArray(0);
                     assertArrayEquals(correctLengthArray, result, 0.0001);
                     
                     // Test with array longer than column dimension (4) - should throw exception
                     try {
                         double[] longArray = {1.0, 2.0, 3.0, 4.0};
                         matrix.getRowAsDoubleArray(0);
                         fail("Should have thrown exception for array longer than column dimension");
                     } catch (IllegalArgumentException e) {
                         // Expected
                     }
                     
                     // Test with array shorter than column dimension (2) - should throw exception
                     // This is the test that would catch the mutant
                     try {
                         double[] shortArray = {1.0, 2.0};
                         matrix.getRowAsDoubleArray(0);
                         fail("Should have thrown exception for array shorter than column dimension");
                     } catch (IllegalArgumentException e) {
                         // Expected
                     }
                 }

 @Test
           public void testGetRowAsDoubleArrayWithInvalidRowThrowsMatrixIndexException() {
               // Setup
               ExpectedException exception = ExpectedException.none();
               exception.expect(MatrixIndexException.class);
               exception.expectMessage("illegal row argument");
               
               // Create a test matrix (1x1 matrix for simplicity)
               BigDecimal[][] testData = {{new BigDecimal("1.0")}};
               BigMatrixImpl matrix = new BigMatrixImpl(testData);
               
               // Test invalid row access
               matrix.getRowAsDoubleArray(-1); // Invalid row
           }

 @Test
           public void testGetRowAsDoubleArrayWithValidRowReturnsCorrectArray() {
               // Create a test matrix with known values
               double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
               BigMatrixImpl matrix = new BigMatrixImpl(testData);
               
               // Define expected and actual results
               double[] expected = {1.0, 2.0};
               double[] actual = matrix.getRowAsDoubleArray(0);
               
               // Verify the result
               assertArrayEquals(expected, actual, 0.0001);
           }

 @Test
           public void testGetRowAsDoubleArrayWithTooLargeRowThrowsMatrixIndexException() {
               // Create a 1x1 matrix (only row 0 is valid)
               BigMatrixImpl matrix = new BigMatrixImpl(new double[][]{{1.0}});
               
               // Set up exception expectation
               ExpectedException exception = ExpectedException.none();
               exception.expect(MatrixIndexException.class);
               exception.expectMessage("illegal row argument");
               
               // Test with invalid row index (2)
               matrix.getRowAsDoubleArray(2); // Row index out of bounds
           }

 @Test
           public void testGetRowAsDoubleArrayValidInput1() {
               // Create a test matrix
               BigDecimal[][] testData = {
                   {new BigDecimal("1.0"), new BigDecimal("2.0")},
                   {new BigDecimal("3.0"), new BigDecimal("4.0")}
               };
               BigMatrixImpl matrix = new BigMatrixImpl(testData);
               
               // Test valid row access
               double[] row0 = matrix.getRowAsDoubleArray(0);
               assertArrayEquals(new double[]{1.0, 2.0}, row0, 0.0001);
               
               double[] row1 = matrix.getRowAsDoubleArray(1);
               assertArrayEquals(new double[]{3.0, 4.0}, row1, 0.0001);
           }

 @Test
      public void testGetRowAsDoubleArrayThrowsCorrectExceptionMessage1() {
          // Create a test matrix
          BigDecimal[][] testData = {
              {new BigDecimal("1.0"), new BigDecimal("2.0")},
              {new BigDecimal("3.0"), new BigDecimal("4.0")}
          };
          BigMatrixImpl matrix = new BigMatrixImpl(testData);
          
          // Set up expectation for the exception
          ExpectedException exception = ExpectedException.none();
          exception.expect(MatrixIndexException.class);
          exception.expectMessage("illegal row argument");
          
          // Call method with invalid row index that should throw exception
          matrix.getRowAsDoubleArray(-1);  // negative row index should be invalid
      }

 @Test
      public void testGetRowAsDoubleArrayInvalidRow3() {
          // Create a test matrix
          BigDecimal[][] testData = {
              {new BigDecimal("1.0"), new BigDecimal("2.0")}
          };
          BigMatrixImpl matrix = new BigMatrixImpl(testData);
          
          // Test invalid row access
          try {
              matrix.getRowAsDoubleArray(-1);
              fail("Expected MatrixIndexException");
          } catch (MatrixIndexException e) {
              assertEquals("illegal row argument", e.getMessage());
          }
      }

 @Test
      public void testGetRowAsDoubleArrayReturnsCorrectValues1() {
          // Setup test data
          BigDecimal[][] testData = {
              {new BigDecimal("1.1"), new BigDecimal("2.2")},
              {new BigDecimal("3.3"), new BigDecimal("4.4")}
          };
          BigMatrixImpl matrix = new BigMatrixImpl(testData);
          
          // Expected values
          double[] expectedRow0 = {1.1, 2.2};
          double[] expectedRow1 = {3.3, 4.4};
          
          // Test first row
          double[] actualRow0 = matrix.getRowAsDoubleArray(0);
          assertArrayEquals("First row values don't match", expectedRow0, actualRow0, 0.0001);
          
          // Test second row
          double[] actualRow1 = matrix.getRowAsDoubleArray(1);
          assertArrayEquals("Second row values don't match", expectedRow1, actualRow1, 0.0001);
      }

 @Test(expected = MatrixIndexException.class)
      public void testGetRowAsDoubleArrayThrowsExceptionForInvalidRow1() {
          BigDecimal[][] testData = {
              {new BigDecimal("1.0"), new BigDecimal("2.0")}
          };
          BigMatrixImpl matrix = new BigMatrixImpl(testData);
          
          // This should throw MatrixIndexException
          matrix.getRowAsDoubleArray(-1); // negative row
          matrix.getRowAsDoubleArray(1);  // row beyond size
      }

 @Test
 public void testGetRowAsDoubleArray7() throws Exception {
     // Setup test data
     BigDecimal[][] testData = {
         {new BigDecimal("1.0"), new BigDecimal("2.0")},
         {new BigDecimal("3.0"), new BigDecimal("4.0")}
     };
     BigMatrixImpl matrix = new BigMatrixImpl(testData);
     
     // Test valid row
     double[] result = matrix.getRowAsDoubleArray(0);
     assertNotNull(result);
     assertEquals(2, result.length);
     assertEquals(1.0, result[0], 0.0001);
     assertEquals(2.0, result[1], 0.0001);
     
     // Test another valid row
     result = matrix.getRowAsDoubleArray(1);
     assertNotNull(result);
     assertEquals(2, result.length);
     assertEquals(3.0, result[0], 0.0001);
     assertEquals(4.0, result[1], 0.0001);
     
     // Test invalid row (negative)
     try {
         matrix.getRowAsDoubleArray(-1);
         fail("Expected MatrixIndexException");
     } catch (MatrixIndexException e) {
         assertEquals("illegal row argument", e.getMessage());
     }
     
     // Test invalid row (out of bounds)
     try {
         matrix.getRowAsDoubleArray(2);
         fail("Expected MatrixIndexException");
     } catch (MatrixIndexException e) {
         assertEquals("illegal row argument", e.getMessage());
     }
     
     // Test empty matrix (shouldn't be possible based on constructors)
     BigDecimal[][] emptyData = {};
     try {
         new BigMatrixImpl(emptyData);
         fail("Expected IllegalArgumentException");
     } catch (IllegalArgumentException e) {
         // Expected
     }
 }

}
