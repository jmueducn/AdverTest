package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
import org.apache.commons.math.MathRuntimeException;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                        public void testGetPct_WithCustomComparator_ShouldWorkCorrectly() {
                                                            Comparator<String> comparator = String.CASE_INSENSITIVE_ORDER;
                                                            Frequency freqWithComparator = new Frequency(comparator);
                                                            
                                                            freqWithComparator.addValue("Apple");
                                                            freqWithComparator.addValue("apple");
                                                            freqWithComparator.addValue("Banana");
                                                            
                                                            // Both "Apple" and "apple" should be considered same
                                                            double result = freqWithComparator.getPct("APPLE");
                                                            assertEquals(2.0/3.0, result, 0.0001);
                                                        }

 @Test(expected = NullPointerException.class)
                                                public void testGetPct_WithNullObject() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.getPct((Object)null);
                                                }

 @Test
                                                public void testGetPct_WithNonComparableObject() {
                                                    Frequency frequency = new Frequency();
                                                    Object nonComparable = new Object();
                                                    assertEquals(0.0, frequency.getPct(nonComparable), 0.0001);
                                                }

 @Test
                                                public void testGetPct_WithNonExistingValue() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.addValue(1);
                                                    frequency.addValue(2);
                                                    frequency.addValue(2);
                                                    
                                                    assertEquals(0.0, frequency.getPct(3), 0.0001);
                                                }

 @Test
                                                public void testGetPct_WithExistingValue() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.addValue("A");
                                                    frequency.addValue("B");
                                                    frequency.addValue("B");
                                                    frequency.addValue("C");
                                                    
                                                    assertEquals(0.25, frequency.getPct("A"), 0.0001);
                                                    assertEquals(0.5, frequency.getPct("B"), 0.0001);
                                                    assertEquals(0.25, frequency.getPct("C"), 0.0001);
                                                }

 @Test
                                                public void testGetPct_WithEmptyFrequencyTable() {
                                                    Frequency frequency = new Frequency();
                                                    assertEquals(0.0, frequency.getPct(1), 0.0001);
                                                    assertEquals(0.0, frequency.getPct("test"), 0.0001);
                                                }

 @Test
                                                public void testGetPct_WithDifferentTypes() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.addValue(1);
                                                    frequency.addValue(2);
                                                    frequency.addValue(2);
                                                    frequency.addValue("A");
                                                    
                                                    assertEquals(0.25, frequency.getPct(1), 0.0001);
                                                    assertEquals(0.5, frequency.getPct(2), 0.0001);
                                                    assertEquals(0.25, frequency.getPct("A"), 0.0001);
                                                }

 @Test
                                                public void testGetPct_WithComparableObject() {
                                                    Frequency frequency = new Frequency();
                                                    Comparable<String> comparable = "Test";
                                                    frequency.addValue(comparable);
                                                    frequency.addValue("Other");
                                                    
                                                    assertEquals(0.5, frequency.getPct(comparable), 0.0001);
                                                }

 @Test
                                                public void testGetPct_WhenSumFreqIsZero_ShouldReturnNaN() {
                                                    // Create a new Frequency instance
                                                    Frequency frequency = new Frequency();
                                                    // Mock the getSumFreq() to return 0
                                                    Frequency spyFrequency = spy(frequency);
                                                    when(spyFrequency.getSumFreq()).thenReturn(0L);
                                                    
                                                    double result = spyFrequency.getPct("anyValue");
                                                    assertTrue(Double.isNaN(result));
                                                }

 @Test
                                                public void testGetPct_WhenValueNotPresent_ShouldReturnZero() {
                                                    Frequency frequency = new Frequency();
                                                    // Add some values to get non-zero sumFreq
                                                    frequency.addValue("presentValue");
                                                    frequency.addValue("presentValue");
                                                    
                                                    // Value not present should have count 0
                                                    double result = frequency.getPct("notPresentValue");
                                                    assertEquals(0.0, result, 0.0001);
                                                }

 @Test
                                                public void testGetPct_WhenValuePresent_ShouldReturnCorrectPercentage() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.addValue("A");
                                                    frequency.addValue("A");
                                                    frequency.addValue("B");
                                                    
                                                    // 2 out of 3 = 0.666...
                                                    double result = frequency.getPct("A");
                                                    assertEquals(2.0/3.0, result, 0.0001);
                                                }

 @Test
                                                public void testGetPct_WithIntegerValue_ShouldWorkCorrectly() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.addValue(1);
                                                    frequency.addValue(1);
                                                    frequency.addValue(2);
                                                    
                                                    double result = frequency.getPct(1);
                                                    assertEquals(2.0/3.0, result, 0.0001);
                                                }

 @Test
                                                public void testGetPct_WithLongValue_ShouldWorkCorrectly() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.addValue(100L);
                                                    frequency.addValue(100L);
                                                    frequency.addValue(200L);
                                                    
                                                    double result = frequency.getPct(100L);
                                                    assertEquals(2.0/3.0, result, 0.0001);
                                                }

 @Test
                                                public void testGetPct_WithCharValue_ShouldWorkCorrectly() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.addValue('a');
                                                    frequency.addValue('a');
                                                    frequency.addValue('b');
                                                    
                                                    double result = frequency.getPct('a');
                                                    assertEquals(2.0/3.0, result, 0.0001);
                                                }

 @Test
                                                public void testGetPct_WithNullValue_ShouldReturnZero() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.addValue("A");
                                                    frequency.addValue("B");
                                                    
                                                    double result = frequency.getPct(null);
                                                    assertEquals(0.0, result, 0.0001);
                                                }

 @Test
                                                public void testGetPct_WithMaxLongValues_ShouldNotOverflow() {
                                                    // Test with maximum long values to ensure no overflow
                                                    Frequency frequency = new Frequency();
                                                    frequency.addValue(Long.MAX_VALUE);
                                                    frequency.addValue(Long.MAX_VALUE);
                                                    
                                                    double result = frequency.getPct(Long.MAX_VALUE);
                                                    assertEquals(1.0, result, 0.0001);
                                                }

 @Test
                                                public void testGetPct_WhenValueExists() {
                                                    // Create frequency instance
                                                    Frequency frequency = new Frequency();
                                                    
                                                    // Setup frequency table with some values
                                                    TreeMap<Comparable<?>, Long> mockTable = new TreeMap<Comparable<?>, Long>();
                                                    mockTable.put(5L, 3L);
                                                    mockTable.put(10L, 7L);
                                                    
                                                    // Use reflection to set the private freqTable field for testing
                                                    try {
                                                        java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                                        field.setAccessible(true);
                                                        field.set(frequency, mockTable);
                                                    } catch (Exception e) {
                                                        fail("Failed to set up test due to reflection error");
                                                    }
                                                    
                                                    // Test cases
                                                    assertEquals(0.3, frequency.getPct(5L), 0.0001);  // 3 / (3+7) = 0.3
                                                    assertEquals(0.7, frequency.getPct(10L), 0.0001);  // 7 / (3+7) = 0.7
                                                }

 @Test
                                                public void testGetPct_WhenValueDoesNotExist() {
                                                    // Create new Frequency instance
                                                    Frequency frequency = new Frequency();
                                                    
                                                    // Setup empty frequency table
                                                    TreeMap<Comparable<?>, Long> mockTable = new TreeMap<>();
                                                    
                                                    try {
                                                        java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                                        field.setAccessible(true);
                                                        field.set(frequency, mockTable);
                                                    } catch (Exception e) {
                                                        fail("Failed to set up test due to reflection error");
                                                    }
                                                    
                                                    assertEquals(0.0, frequency.getPct(5L), 0.0001);
                                                }

 @Test
                                                public void testGetPct_WithEmptyFrequencyTable1() {
                                                    // Create new Frequency object with empty frequency table
                                                    Frequency frequency = new Frequency();
                                                    // freqTable is empty as per setUp()
                                                    assertEquals(0.0, frequency.getPct(1L), 0.0001);
                                                }

 @Test(expected = NullPointerException.class)
                                                public void testGetPct_WithNullInput() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.getPct((Comparable<Long>)null);
                                                }

 @Test
                                                public void testGetPct_WithSingleValue() {
                                                    // Create frequency instance
                                                    Frequency frequency = new Frequency();
                                                    
                                                    // Setup frequency table with one value
                                                    TreeMap<Comparable<?>, Long> mockTable = new TreeMap<>();
                                                    mockTable.put(100L, 5L);
                                                    
                                                    try {
                                                        java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                                        field.setAccessible(true);
                                                        field.set(frequency, mockTable);
                                                    } catch (Exception e) {
                                                        fail("Failed to set up test due to reflection error");
                                                    }
                                                    
                                                    assertEquals(1.0, frequency.getPct(100L), 0.0001);  // 5 / 5 = 1.0
                                                }

 @Test
                                                public void testGetPct_WithNegativeValues() {
                                                    // Setup frequency table with negative values (though this shouldn't happen in practice)
                                                    Frequency frequency = new Frequency();
                                                    TreeMap<Comparable<?>, Long> mockTable = new TreeMap<>();
                                                    mockTable.put(-5L, 2L);
                                                    mockTable.put(10L, 3L);
                                                    
                                                    try {
                                                        java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                                        field.setAccessible(true);
                                                        field.set(frequency, mockTable);
                                                    } catch (Exception e) {
                                                        fail("Failed to set up test due to reflection error");
                                                    }
                                                    
                                                    assertEquals(0.4, frequency.getPct(-5L), 0.0001);  // 2 / (2+3) = 0.4
                                                }

 @Test
                                                public void testGetPct_WithSingleValue1() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.addValue(10L);
                                                    
                                                    // Test with the existing value
                                                    assertEquals(1.0, frequency.getPct(10L), 0.0001);
                                                    
                                                    // Test with non-existing value
                                                    assertEquals(0.0, frequency.getPct(5L), 0.0001);
                                                }

 @Test
                                                public void testGetPct_WithMultipleValues() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.addValue(10L);
                                                    frequency.addValue(10L);
                                                    frequency.addValue(20L);
                                                    frequency.addValue(30L);
                                                    
                                                    // Test percentage calculation
                                                    assertEquals(0.5, frequency.getPct(10L), 0.0001);  // 2 out of 4
                                                    assertEquals(0.25, frequency.getPct(20L), 0.0001);  // 1 out of 4
                                                    assertEquals(0.25, frequency.getPct(30L), 0.0001);  // 1 out of 4
                                                    assertEquals(0.0, frequency.getPct(40L), 0.0001);   // 0 out of 4
                                                }

 @Test
                                                public void testGetPct_WithDifferentValueTypes() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.addValue(10L);
                                                    frequency.addValue(20L);
                                                    
                                                    // Test with different numeric types that can be converted to long
                                                    assertEquals(0.5, frequency.getPct(10L), 0.0001);      // long
                                                    assertEquals(0.5, frequency.getPct(new Integer(10)), 0.0001); // Integer
                                                    assertEquals(0.0, frequency.getPct('A'), 0.0001);      // char (ASCII 65) - not in frequency
                                                }

 @Test
                                                public void testGetPct_AfterClearingFrequencyTable() {
                                                    Frequency frequency = new Frequency();
                                                    frequency.addValue(10L);
                                                    frequency.addValue(10L);
                                                    frequency.clear();
                                                    
                                                    assertEquals(0.0, frequency.getPct(10L), 0.0001);
                                                }

 @Test
                                                public void testGetPct_WhenCharacterExists() {
                                                    // Create a new Frequency object
                                                    org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                    
                                                    // Add some values to create a frequency distribution
                                                    frequency.addValue('a');
                                                    frequency.addValue('a');
                                                    frequency.addValue('b');
                                                    frequency.addValue('c');
                                                    
                                                    // 'a' appears twice out of 4 total (50%)
                                                    assertEquals(0.5, frequency.getPct('a'), 0.0001);
                                                    // 'b' appears once out of 4 total (25%)
                                                    assertEquals(0.25, frequency.getPct('b'), 0.0001);
                                                    // 'c' appears once out of 4 total (25%)
                                                    assertEquals(0.25, frequency.getPct('c'), 0.0001);
                                                }

 @Test
                                                public void testGetPct_WhenCharacterDoesNotExist() {
                                                    // Create frequency table
                                                    Frequency frequency = new Frequency();
                                                    
                                                    // Add some values but not the one we're testing
                                                    frequency.addValue('x');
                                                    frequency.addValue('y');
                                                    
                                                    // 'z' doesn't exist in frequency table (0%)
                                                    assertEquals(0.0, frequency.getPct('z'), 0.0001);
                                                }

 @Test
                                            public void testGetPct_WithEmptyFrequencyTable2() {
                                                // Don't add any values
                                                Frequency frequency = new Frequency();
                                                assertEquals(0.0, frequency.getPct('a'), 0.0001);
                                            }

 @Test
                                            public void testGetPct_WithSingleCharacter() {
                                                // Create frequency object
                                                Frequency frequency = new Frequency();
                                                
                                                // Add only one character
                                                frequency.addValue('x');
                                                
                                                // 'x' is the only character (100%)
                                                assertEquals(1.0, frequency.getPct('x'), 0.0001);
                                                // Other characters should be 0%
                                                assertEquals(0.0, frequency.getPct('y'), 0.0001);
                                            }

 @Test
                                            public void testGetPct_WithUnicodeCharacters() {
                                                // Test with non-ASCII characters
                                                Frequency frequency = new Frequency();
                                                frequency.addValue('€');
                                                frequency.addValue('€');
                                                frequency.addValue('¥');
                                                
                                                assertEquals(0.6666, frequency.getPct('€'), 0.0001);
                                                assertEquals(0.3333, frequency.getPct('¥'), 0.0001);
                                            }

 @Test
                                            public void testGetPct_WithVeryLargeNumbers() {
                                                // Create frequency object
                                                Frequency frequency = new Frequency();
                                                
                                                // Test with large numbers to check for arithmetic issues
                                                for (int i = 0; i < 1000000; i++) {
                                                    frequency.addValue('a');
                                                }
                                                frequency.addValue('b');
                                                
                                                // 'a' should be 1000000/1000001 (99.9999%)
                                                assertEquals(0.999999, frequency.getPct('a'), 0.000001);
                                                // 'b' should be 1/1000001 (0.0001%)
                                                assertEquals(0.000001, frequency.getPct('b'), 0.000001);
                                            }

 @Test
                                            public void testGetPct_WithNullInput1() {
                                                Frequency frequency = new Frequency();
                                                ExpectedException expectedException = ExpectedException.none();
                                                expectedException.expect(NullPointerException.class);
                                                frequency.getPct((Object)null);
                                            }

 @Test
                                        public void testGetPct_WithEmptyFrequencyTable3() {
                                            // Create new empty frequency table
                                            Frequency frequency = new Frequency();
                                            // Don't add any values
                                            assertEquals(0.0, frequency.getPct('a'), 0.0001);
                                        }

 @Test
                                        public void testGetPct_WithVeryLargeNumbers1() {
                                            // Test with large numbers to check for arithmetic issues
                                            Frequency frequency = new Frequency();
                                            for (int i = 0; i < 1000000; i++) {
                                                frequency.addValue('a');
                                            }
                                            frequency.addValue('b');
                                            
                                            // 'a' should be 1000000/1000001 (99.9999%)
                                            assertEquals(0.999999, frequency.getPct('a'), 0.000001);
                                            // 'b' should be 1/1000001 (0.0001%)
                                            assertEquals(0.000001, frequency.getPct('b'), 0.000001);
                                        }

 @Test
            public void testGetPct_WithZeroTotalFrequency() throws Exception {
                // This shouldn't normally happen since addValue increments counts
                // But we'll test the behavior if somehow the table is empty
                @SuppressWarnings("unchecked")
                TreeMap<Comparable<?>, Long> mockTable = mock(TreeMap.class);
                when(mockTable.isEmpty()).thenReturn(true);
                
                // Create Frequency instance
                org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                
                // Use reflection to inject the mock table
                java.lang.reflect.Field freqTableField = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
                freqTableField.setAccessible(true);
                freqTableField.set(frequency, mockTable);
                
                // Test the behavior
                assertEquals(0.0, frequency.getPct(1), 0.0001);
            }

 @Test
        public void testGetPct_WithZeroTotalFrequency1() throws Exception {
            // This shouldn't normally happen since addValue increments counts
            // But we'll test the behavior if somehow the table is empty
            @SuppressWarnings("unchecked")
            java.util.TreeMap<java.lang.Comparable<?>, java.lang.Long> mockTable = 
                new java.util.TreeMap<java.lang.Comparable<?>, java.lang.Long>();
            
            // Create Frequency instance
            org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
            
            // Use reflection to inject the mock table
            try {
                java.lang.reflect.Field freqTableField = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
                freqTableField.setAccessible(true);
                freqTableField.set(frequency, mockTable);
            } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
                throw new RuntimeException(e);
            }
            
            // Test the behavior
            org.junit.Assert.assertEquals(0.0, frequency.getPct(1), 0.0001);
        }

 @Test
        public void testGetPct_WithZeroTotalFrequency2() throws Exception {
            // This shouldn't normally happen since addValue increments counts
            // But we'll test the behavior if somehow the table is empty
            @SuppressWarnings("unchecked")
            java.util.TreeMap<java.lang.Comparable<?>, java.lang.Long> mockTable = 
                new java.util.TreeMap<java.lang.Comparable<?>, java.lang.Long>();
            
            // Create Frequency instance
            org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
            
            // Use reflection to inject the mock table
            java.lang.reflect.Field freqTableField = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
            freqTableField.setAccessible(true);
            freqTableField.set(frequency, mockTable);
            
            // Test the behavior
            org.junit.Assert.assertEquals(0.0, frequency.getPct(1), 0.0001);
        }

 @Test
        public void testGetPct_WithZeroTotalFrequency3() throws Exception {
            // This shouldn't normally happen since addValue increments counts
            // But we'll test the behavior if somehow the table is empty
            @SuppressWarnings("unchecked")
            java.util.TreeMap<java.lang.Comparable<?>, java.lang.Long> mockTable = 
                new java.util.TreeMap<java.lang.Comparable<?>, java.lang.Long>();
        
            // Create Frequency instance
            org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
            
            // Use reflection to inject the mock table
            java.lang.reflect.Field freqTableField = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
            freqTableField.setAccessible(true);
            freqTableField.set(frequency, mockTable);
            
            // Test the behavior
            org.junit.Assert.assertEquals(0.0, frequency.getPct(1), 0.0001);
        }

 @Test
        public void testGetPctWithGenericComparable() {
            // Setup
            Frequency frequency = new Frequency();
            
            // Create a properly typed Comparable object
            class TypedComparable implements Comparable<String> {
                @Override
                public int compareTo(String o) {
                    return 0; // All instances are equal for this test
                }
            }
            TypedComparable typedComparable = new TypedComparable();
            
            // Add some values to the frequency table
            frequency.addValue(typedComparable);
            frequency.addValue(typedComparable);
            frequency.addValue(new Object()); // Add another value for diversity
            
            // Test - should properly handle the generic Comparable
            double pct = frequency.getPct(typedComparable);
            
            // Verify - should be 2 out of 3 (66.66%)
            assertEquals(2.0/3.0, pct, 0.0001);
            
            // Now test with raw Comparable
            class RawComparable implements Comparable {
                @Override
                public int compareTo(Object o) {
                    return 0;
                }
            }
            RawComparable rawComparable = new RawComparable();
            
            frequency.addValue(rawComparable);
            pct = frequency.getPct(rawComparable);
            
            // Verify - should be 1 out of 4 (25%)
            assertEquals(0.25, pct, 0.0001);
        }

 @Test
        public void testGetPctWithDifferentTypedComparables() {
            // Setup frequency with a custom comparator
            Frequency frequency = new Frequency(new Comparator<String>() {
                @Override
                public int compare(String o1, String o2) {
                    return o1.compareTo(o2);
                }
            });
            
            // Add String values (which are Comparable<String>)
            frequency.addValue("test");
            frequency.addValue("test");
            frequency.addValue("other");
            
            // Test with String input
            double pct = frequency.getPct("test");
            assertEquals(2.0/3.0, pct, 0.0001);
            
            // Test with raw Comparable input
            Comparable rawComparable = "test";
            pct = frequency.getPct(rawComparable);
            assertEquals(2.0/3.0, pct, 0.0001);
        }

 @Test
    public void testGetPctWithDifferentComparableTypes() {
        // Setup frequency object
        Frequency freq = new Frequency();
        
        // Add values of different Comparable types
        freq.addValue("stringValue");  // String implements Comparable<String>
        freq.addValue(42);             // Integer implements Comparable<Integer>
        
        // Test with String value
        double stringPct = freq.getPct((Object)"stringValue");
        assertEquals(0.5, stringPct, 0.0001);
        
        // Test with Integer value
        double intPct = freq.getPct((Object)42);
        assertEquals(0.5, intPct, 0.0001);
        
        // The mutation would still pass these basic tests, so we need to test type safety
        
        // Create a custom Comparable implementation
        class CustomComparable implements Comparable<CustomComparable> {
            @Override
            public int compareTo(CustomComparable o) {
                return 0;
            }
        }
        CustomComparable custom = new CustomComparable();
        
        // Add and test the custom comparable
        freq.addValue(custom);
        double customPct = freq.getPct((Object)custom);
        assertEquals(1.0/3.0, customPct, 0.0001);
        
        // The test will catch the mutant because:
        // 1. The original version properly handles different Comparable<?> types
        // 2. The mutated version loses generic type information which could cause
        //    issues with type safety in more complex scenarios
        // 3. By testing with multiple different Comparable implementations, we ensure
        //    the method maintains proper type safety
    }

 @Test
    public void testGetPctWithNonComparableObject() {
        // Setup
        Frequency frequency = new Frequency();
        Object nonComparableObject = new Object(); // Object doesn't implement Comparable
        
        // Exercise and Verify
        try {
            double result = frequency.getPct(nonComparableObject);
            // If we get here, the test passes (original behavior)
            // We can add an assertion about the expected value (0.0 for non-existent value)
            assertEquals(0.0, result, 0.0001);
        } catch (ClassCastException e) {
            // If we get here, the mutant is detected
            fail("Mutant detected: ClassCastException was thrown when it shouldn't be");
        }
    }

 @Test
    public void testGetPctWithComparableObject() {
        // Setup
        Frequency frequency = new Frequency();
        frequency.addValue(5L); // Add some value to the frequency table
        Comparable<?> comparableLong = 5L;
        
        // Exercise and Verify
        double result = frequency.getPct(comparableLong);
        // Should return the percentage for the existing value
        assertEquals(1.0, result, 0.0001);
    }

 @Test
    public void testGetPctWithStringObject() {
        // Setup
        Frequency frequency = new Frequency();
        frequency.addValue("test"); // Add some string value
        
        // Exercise and Verify
        try {
            double result = frequency.getPct("test");
            // Should work for String which is Comparable<?>
            assertEquals(1.0, result, 0.0001);
        } catch (ClassCastException e) {
            fail("Mutant detected: ClassCastException was thrown for String input");
        }
    }

 @Test
        public void testGetPctWithDifferentComparableTypes1() {
            // Setup frequency table with some values
            Frequency frequency = new Frequency();
            frequency.addValue(1L);
            frequency.addValue(2L);
            frequency.addValue(2L); // 1 appears once, 2 appears twice
            
            // Create a custom Comparable that isn't Long but implements Comparable
            Comparable<String> stringComparable = new Comparable<String>() {
                @Override
                public int compareTo(String o) {
                    return 0;
                }
            };
            
            // Test with the custom Comparable object
            try {
                double result = frequency.getPct(stringComparable);
                // If we get here, the mutant survived (should throw ClassCastException)
                fail("Expected ClassCastException but got result: " + result);
            } catch (ClassCastException e) {
                // This is expected for the original code
                assertTrue(true);
            }
            
            // Also test with proper Long value to ensure normal operation works
            assertEquals(1.0/3, frequency.getPct(1L), 0.0001);
            assertEquals(2.0/3, frequency.getPct(2L), 0.0001);
        }

 @Test
        public void testGetPctWithComparatorAndDifferentTypes() {
            // Setup frequency with custom comparator
            Frequency frequency = new Frequency(new Comparator<Long>() {
                @Override
                public int compare(Long o1, Long o2) {
                    return o1.compareTo(o2);
                }
            });
            frequency.addValue(10L);
            frequency.addValue(20L);
            frequency.addValue(20L);
            
            // Test with incompatible Comparable type
            try {
                frequency.getPct(new Comparable<Integer>() {
                    @Override
                    public int compareTo(Integer o) {
                        return 0;
                    }
                });
                fail("Expected ClassCastException for incompatible Comparable type");
            } catch (ClassCastException e) {
                // Expected for original code
            }
        }

 @Test
    public void testGetPctCharWithGenericTypeSafety() {
        // Create a frequency object and add some character values
        Frequency freq = new Frequency();
        freq.addValue('a');
        freq.addValue('b');
        freq.addValue('a'); // 'a' appears twice
        
        // Test with character input
        double pctA = freq.getPct('a');
        double pctB = freq.getPct('b');
        double pctC = freq.getPct('c');
        
        // Verify percentages (2/3 for 'a', 1/3 for 'b', 0 for 'c')
        assertEquals(2.0/3, pctA, 0.0001);
        assertEquals(1.0/3, pctB, 0.0001);
        assertEquals(0.0, pctC, 0.0001);
        
        // The key test is that the method properly resolves to getPct(Comparable<?>)
        // rather than getPct(Object) or other overloads
        // We can verify this by checking the counts match
        assertEquals(freq.getCount('a'), 2L);
        assertEquals(freq.getCount('b'), 1L);
        assertEquals(freq.getCount('c'), 0L);
        
        // Test with non-character comparable to ensure type safety
        // This would fail if the generic type information was lost
        try {
            freq.getPct((int)'a'); // should call getPct(int) not getPct(Comparable)
            // If we get here, the test should fail as it means the wrong method was called
            fail("Expected proper method resolution with generic type information");
        } catch (Exception e) {
            // Expected - verifies type safety is maintained
        }
    }

 @Test
   public void testGetPctObjectDetectsNullMutant() {
       // Setup frequency table with some values
       Frequency freq = new Frequency();
       freq.addValue("A");
       freq.addValue("B");
       freq.addValue("B"); // "B" appears twice
       
       // Test with a value that exists in the table
       double expectedPctForB = 2.0 / 3.0; // 2 out of 3 entries are "B"
       double actualPct = freq.getPct("B");
       
       // Assert the percentage is correct
       assertEquals(expectedPctForB, actualPct, 0.0001);
       
       // The mutant would return percentage for null (0.0) instead
       // So this assertion would fail for the mutant
   }

 @Test
   public void testGetPctObjectDetectsNullMutant1() {
       // Setup frequency table with some values
       Frequency freq = new Frequency();
       freq.addValue("A");
       freq.addValue("A");  // "A" appears twice
       freq.addValue("B");  // "B" appears once
       
       // Test with a non-null value that exists in table
       double expectedPct = 2.0 / 3.0;  // "A" appears 2 out of 3 times
       double actualPct = freq.getPct((Object)"A");
       
       // Original should return correct percentage for "A"
       // Mutant will return percentage for null (likely 0.0)
       assertEquals("Mutant detected - getPct(Object) should delegate to getPct(Comparable) with same value", 
                    expectedPct, actualPct, 0.0001);
       
       // Also test with a value not in table
       assertEquals(0.0, freq.getPct((Object)"C"), 0.0001);
   }

 @Test
   public void testGetPctObjectShouldNotReturnNullPercentage() {
       // Setup
       Frequency frequency = new Frequency();
       Long testValue = 42L;
       frequency.addValue(testValue);  // Add the value to the frequency table
       
       // Test with the actual value
       double expectedPct = frequency.getPct((Comparable<?>) testValue);  // What we expect to get
       double actualPct = frequency.getPct((Object) testValue);          // What the method returns
       
       // Verify
       assertEquals("getPct(Object) should return same percentage as getPct(Comparable)",
                   expectedPct, actualPct, 0.0001);
       
       // Additional verification that we're not getting null's percentage
       double nullPct = frequency.getPct((Comparable<?>) null);
       assertNotEquals("getPct(Object) should not return null's percentage",
                      nullPct, actualPct, 0.0001);
   }

 @Test
   public void testGetPctObjectDetectsNullMutant2() {
       // Setup frequency table with some data
       Frequency frequency = new Frequency();
       frequency.addValue(10L);  // Add some values to have a non-zero frequency
       frequency.addValue(20L);
       
       // Calculate expected percentage for a value (should be 0.5 if we add the same value twice)
       double expectedPct = frequency.getPct(10L);
       
       // Test with non-null object input
       Object input = 10L;
       double actualPct = frequency.getPct(input);
       
       // If mutant exists, actualPct would be frequency.getPct(null) which should be different
       assertEquals("Method should properly convert non-null input", 
                    expectedPct, actualPct, 0.0001);
       
       // Additional verification that null input gives different result
       double nullPct = frequency.getPct((Object)null);
       assertNotEquals("Null input should give different result than non-null",
                      nullPct, actualPct, 0.0001);
   }

 @Test
   public void testGetPctCharShouldNotPassNull() {
       // Setup frequency table with some test data
       Frequency frequency = new Frequency();
       frequency.addValue('a');
       frequency.addValue('a');
       frequency.addValue('b');
       
       // Expected behavior: should return percentage for 'a' (2/3 ≈ 0.666...)
       // Mutated behavior: would return percentage for null (0/3 = 0.0)
       double expected = 2.0 / 3.0;
       double actual = frequency.getPct('a');
       
       // Assert with delta for floating point comparison
       assertEquals("Should return percentage for character 'a'", 
                   expected, actual, 0.0001);
       
       // Also test with a character not in the table
       assertEquals("Should return 0 for character not in table", 
                   0.0, frequency.getPct('c'), 0.0001);
   }

 @Test
      public void testGetPctObjectDelegatesCorrectly() {
          // Setup
          Frequency frequency = new Frequency();
          Comparable<String> testValue = "test";
          
          // Add some values to establish frequency
          frequency.addValue(testValue);
          frequency.addValue(testValue);
          frequency.addValue("other");
          
          // Test delegation to Comparable version
          double expectedPct = 2.0 / 3.0; // 2 out of 3 entries are "test"
          double actualPct = frequency.getPct((Object)testValue);
          
          assertEquals("Percentage should be correctly calculated", 
                      expectedPct, actualPct, 0.0001);
      }

 @Test(expected = ClassCastException.class)
      public void testGetPctWithNonComparableObject1() {
          Frequency frequency = new Frequency();
          Object nonComparable = new Object();
          frequency.getPct(nonComparable);
      }

 @Test
      public void testGetPctWithNullInput() {
          Frequency frequency = new Frequency();
          // Should handle null without exception (assuming getPct(Comparable) handles null)
          frequency.getPct((Object)null);
      }

 @Test
      public void testGetPctDelegation() {
          // Mock setup to verify delegation
          Frequency frequencySpy = spy(new Frequency());
          Comparable<Integer> testValue = 42;
          
          // Call the method
          frequencySpy.getPct((Object)testValue);
          
          // Verify the delegation happened exactly once
          verify(frequencySpy, times(1)).getPct(testValue);
      }

 @Test
  public void testGetPctObjectVsComparable() {
      // Setup frequency table
      Frequency freq = new Frequency();
      String comparableValue = "test"; // String is Comparable
      Object nonComparableValue = new Object(); // Object is not Comparable
      
      // Add some values
      freq.addValue(comparableValue);
      freq.addValue(comparableValue); // count = 2
      freq.addValue("other"); // sumFreq = 3
      
      // Test with non-Comparable object - original would work, mutant would throw exception
      try {
          double result = freq.getPct(nonComparableValue);
          // Original would return 0.0 (count=0) / 3.0 = 0.0
          assertEquals(0.0, result, 0.0001);
      } catch (ClassCastException e) {
          fail("Original method should handle non-Comparable objects");
      }
      
      // Test with null - original might handle, mutant would throw NPE
      try {
          double result = freq.getPct(null);
          assertEquals(0.0, result, 0.0001);
      } catch (NullPointerException e) {
          fail("Original method should handle null values");
      }
      
      // Test with Comparable value - results should match direct Comparable call
      double directResult = freq.getPct((Comparable<?>) comparableValue);
      double objectResult = freq.getPct((Object) comparableValue);
      assertEquals(directResult, objectResult, 0.0001);
  }

 @Test(expected = NumberFormatException.class)
  public void testGetPctWithNonNumericComparable() {
      Frequency frequency = new Frequency();
      // Add some values to establish frequency
      frequency.addValue(1L);
      frequency.addValue(2L);
      
      // This should throw NumberFormatException in original code
      // because it tries Long.valueOf() on a String
      // Mutant would try to cast to Comparable which would succeed
      frequency.getPct("not-a-number");
      
      // If we reach here, the mutant survived (no exception thrown)
      // The @Test(expected) ensures original behavior is maintained
  }

 @Test
  public void testGetPct_ObjectWithIntegerInput_ShouldDetectMutant() {
      // Setup frequency table
      Frequency freq = new Frequency();
      freq.addValue(5L);  // Add some values
      freq.addValue(5L);
      freq.addValue(10L);
      
      // Create an Integer input (not Long)
      Integer input = Integer.valueOf(5);
      
      // Test - should convert to Long first in original, but mutant will pass as Comparable
      double result = freq.getPct(input);
      
      // Verify correct percentage (2 occurrences out of 3 total)
      assertEquals(2.0/3.0, result, 0.0001);
      
      // This test will catch the mutant because:
      // - Original: converts Integer to Long, finds 2 matches
      // - Mutant: treats Integer as Comparable, may not match the Long values in table
      // - If mutant survives, the count/percentage would be wrong
  }

 @Test
  public void testGetPctCharDetectsMutant() {
      // Setup frequency table with test data
      Frequency frequency = new Frequency();
      char testChar = 'A';
      long count = 5L;
      long total = 10L;
      
      // Add some values to establish a total frequency
      for (int i = 0; i < total; i++) {
          frequency.addValue(i % 2 == 0 ? testChar : 'B');
      }
      
      // Verify the count is correct
      assertEquals(count, frequency.getCount(testChar));
      
      // The key test - verify the percentage calculation works correctly
      // This would fail if the mutant's direct casting caused any issues
      double expectedPct = (double) count / total;
      assertEquals(expectedPct, frequency.getPct(testChar), 0.0001);
      
      // Test edge cases
      char minChar = Character.MIN_VALUE;
      char maxChar = Character.MAX_VALUE;
      frequency.addValue(minChar);
      frequency.addValue(maxChar);
      
      // Verify edge characters are handled correctly
      assertEquals(1.0/12, frequency.getPct(minChar), 0.0001);
      assertEquals(1.0/12, frequency.getPct(maxChar), 0.0001);
      
      // Verify the conversion preserves exact char value
      char unicodeChar = '\u00A9'; // copyright symbol
      frequency.addValue(unicodeChar);
      assertEquals(1.0/13, frequency.getPct(unicodeChar), 0.0001);
  }

 @Test
     public void testGetPctWithTypedComparable() {
         // Setup
         Frequency frequency = new Frequency();
         frequency.addValue("test");  // Add a value to have some frequency
         
         // Create a properly typed Comparable
         Comparable<String> typedComparable = "test";
         
         // Test
         double result = frequency.getPct(typedComparable);
         
         // Verify
         assertEquals(1.0, result, 0.0001);  // Should be 100% since we only added one value
     }

 @Test
     public void testGetPctWithRawComparable() {
         // Setup
         Frequency frequency = new Frequency();
         frequency.addValue("test");  // Add a value to have some frequency
         
         // Create a raw Comparable (this is what the mutant would handle differently)
         Comparable rawComparable = "test";
         
         // Test
         double result = frequency.getPct(rawComparable);
         
         // Verify
         assertEquals(1.0, result, 0.0001);
     }

 @Test
     public void testGetPctWithDifferentTypedComparable() {
         // Setup
         Frequency frequency = new Frequency();
         frequency.addValue(123);  // Add an integer value
         
         // Create a Comparable with different type
         Comparable<String> stringComparable = "123";
         
         // Test
         double result = frequency.getPct(stringComparable);
         
         // Verify
         assertEquals(0.0, result, 0.0001);  // Should be 0% since "123" != 123
     }

 @Test
 public void testGetPctWithGenericComparable1() {
     // Setup
     Frequency frequency = new Frequency();
     
     // Create a test Comparable implementation with specific type
     class TestComparable implements Comparable<String> {
         @Override
         public int compareTo(String o) {
             return 0;
         }
     }
     TestComparable testValue = new TestComparable();
     
     // Add some values to get a non-zero sum
     frequency.addValue("test1");
     frequency.addValue("test2");
     frequency.addValue(testValue);
     
     // Test - should properly handle the generic Comparable type
     double result = frequency.getPct(testValue);
     
     // Verify
     assertEquals(1.0/3.0, result, 0.0001);
     
     // The mutation would still pass this basic test, so we need to verify the type safety
     // by checking if the method properly delegates to getPct(Comparable<?>)
     try {
         // This should work with proper generic type handling
         frequency.getPct(new Object()); // Should throw ClassCastException
         fail("Expected ClassCastException when passing non-Comparable object");
     } catch (ClassCastException e) {
         // Expected behavior
     }
 }

 @Test
 public void testGetPctWithNonLongComparable() {
     // Create a custom Comparable that's not compatible with Long
     class CustomComparable implements Comparable<CustomComparable> {
         @Override
         public int compareTo(CustomComparable o) {
             return 0;
         }
     }
     
     Frequency frequency = new Frequency();
     CustomComparable customObj = new CustomComparable();
     
     // The original code with <?> would handle this gracefully
     // The mutated code without <?> might cause issues
     try {
         double result = frequency.getPct(customObj);
         // If we get here, the test should fail as we expect potential type issues
         fail("Expected potential type compatibility issues with raw Comparable cast");
     } catch (ClassCastException e) {
         // This is acceptable as it shows type safety is being enforced
     } catch (Exception e) {
         fail("Unexpected exception type: " + e.getClass().getName());
     }
     
     // Also test with proper Long input to ensure normal functionality
     Long normalInput = 123L;
     frequency.addValue(normalInput); // Add some data to the frequency table
     double pct = frequency.getPct(normalInput);
     assertEquals(1.0, pct, 0.0001); // Should be 100% since it's the only value
 }

 @Test
 public void testGetPctWithNonLongComparable1() {
     // Setup
     Frequency frequency = new Frequency();
     
     // Create a custom Comparable that isn't a Long
     Comparable<String> stringComparable = new Comparable<String>() {
         @Override
         public int compareTo(String o) {
             return 0;
         }
         
         @Override
         public String toString() {
             return "123"; // String that can be parsed to Long
         }
     };
     
     // Add some values to the frequency table
     frequency.addValue(123L);
     frequency.addValue(123L); // Make it have 2 counts
     
     // Test - should convert the string "123" to Long 123
     double result = frequency.getPct(stringComparable);
     
     // Verify - should find the 123L in frequency table
     assertEquals(1.0, result, 0.0001); // 2 counts of 123 / total 2 = 100%
     
     // The mutant would fail here because without proper generic typing,
     // the conversion might not happen correctly
 }

 @Test
 public void testGetPctCharWithMixedTypeComparables() {
     // Create frequency table with mixed comparable types
     Frequency freq = new Frequency();
     
     // Add some characters
     freq.addValue('a');
     freq.addValue('b');
     freq.addValue('a');
     
     // Add some other comparable type (String)
     freq.addValue("test");
     freq.addValue("test");
     
     // Test with character input
     double result = freq.getPct('a');
     
     // Verify the percentage is calculated correctly (2 occurrences out of 5 total)
     assertEquals(0.4, result, 0.0001);
     
     // Test with another character
     result = freq.getPct('b');
     assertEquals(0.2, result, 0.0001);
     
     // Test with non-existent character
     result = freq.getPct('c');
     assertEquals(0.0, result, 0.0001);
 }

}
