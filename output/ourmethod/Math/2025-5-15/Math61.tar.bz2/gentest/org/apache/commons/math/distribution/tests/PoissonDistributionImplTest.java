package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.special.Gamma;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class PoissonDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                 public void testConstructor_NegativeMean() {
                     double testMean = -1.0;
                     thrown.expect(IllegalArgumentException.class);
                     new PoissonDistributionImpl(testMean);
                 }

 @Test
                 public void testConstructor_NaNMean() {
                     double testMean = Double.NaN;
                     thrown.expect(IllegalArgumentException.class);
                     new PoissonDistributionImpl(testMean);
                 }

 @Test
                 public void testConstructor_PositiveInfinityMean() {
                     double testMean = Double.POSITIVE_INFINITY;
                     thrown.expect(IllegalArgumentException.class);
                     new PoissonDistributionImpl(testMean);
                 }

 @Test
                 public void testConstructor_ZeroMean() {
                     // Test with zero mean (should throw exception)
                     thrown.expect(NotStrictlyPositiveException.class);
                     thrown.expectMessage(LocalizedFormats.MEAN.toString());
                     
                     new PoissonDistributionImpl(0.0, 1e-12, 10000);
                 }

 @Test
                 public void testConstructor_NegativeMean1() {
                     // Test with negative mean (should throw exception)
                     thrown.expect(NotStrictlyPositiveException.class);
                     thrown.expectMessage(LocalizedFormats.MEAN.toString());
                     
                     new PoissonDistributionImpl(-1.0, 1e-12, 10000);
                 }

 @Test
                 public void testConstructor_NegativeMean_ThrowsException() {
                     // Arrange
                     double mean = -1.0;
                     double epsilon = 1e-12;
                     thrown.expect(IllegalArgumentException.class);
                     thrown.expectMessage("mean must be >= 0");
                     
                     // Act
                     new PoissonDistributionImpl(mean, epsilon);
                 }

 @Test
                 public void testConstructor_NegativeEpsilon_ThrowsException() {
                     // Arrange
                     double mean = 5.0;
                     double epsilon = -1e-12;
                     thrown.expect(IllegalArgumentException.class);
                     thrown.expectMessage("epsilon must be >= 0");
                     
                     // Act
                     new PoissonDistributionImpl(mean, epsilon);
                 }

 @Test
                 public void testConstructorWithNegativeMean() {
                     // Should throw exception for negative mean
                     thrown.expect(IllegalArgumentException.class);
                     new PoissonDistributionImpl(-1.0, 100);
                 }

 @Test
                 public void testConstructorWithZeroMaxIterations() {
                     // Edge case - zero max iterations
                     thrown.expect(IllegalArgumentException.class);
                     new PoissonDistributionImpl(2.0, 0);
                 }

 @Test
                 public void testConstructorWithNegativeMaxIterations() {
                     // Should throw exception for negative max iterations
                     thrown.expect(IllegalArgumentException.class);
                     new PoissonDistributionImpl(2.0, -1);
                 }

 @Test
         public void testConstructor_ValidPositiveMean() throws Exception {
             double testMean = 5.0;
             PoissonDistributionImpl dist = new PoissonDistributionImpl(testMean);
             
             assertEquals(testMean, dist.getMean(), 0.0);
             
             // Test epsilon using reflection
             Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
             epsilonField.setAccessible(true);
             assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, epsilonField.getDouble(dist), 0.0);
             
             // Test maxIterations using reflection
             Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
             maxIterationsField.setAccessible(true);
             assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, maxIterationsField.getInt(dist));
             
             // Test normal using reflection
             Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
             normalField.setAccessible(true);
             assertNotNull(normalField.get(dist));
         }

 @Test
         public void testConstructor_ZeroMean1() throws Exception {
             double testMean = 0.0;
             PoissonDistributionImpl dist = new PoissonDistributionImpl(testMean);
             
             assertEquals(testMean, dist.getMean(), 0.0);
             
             // Use reflection to access private fields
             Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
             epsilonField.setAccessible(true);
             double epsilonValue = epsilonField.getDouble(dist);
             assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, epsilonValue, 0.0);
             
             Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
             maxIterationsField.setAccessible(true);
             int maxIterationsValue = maxIterationsField.getInt(dist);
             assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, maxIterationsValue);
             
             // Verify normal distribution exists by checking it can calculate probability
             try {
                 dist.probability(0);  // This will use the normal field internally
                 assertTrue(true);  // If we get here, normal exists
             } catch (NullPointerException e) {
                 fail("normal field should not be null");
             }
         }

 @Test
         public void testConstructor_ValidParameters() {
             // Test with typical valid parameters
             double mean = 5.0;
             double epsilon = 1e-12;
             int maxIterations = 10000;
             
             PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
             
             assertEquals(mean, distribution.getMean(), 0.0);
             
             // Use reflection to access private field 'normal'
             try {
                 Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                 normalField.setAccessible(true);
                 NormalDistribution normal = (NormalDistribution) normalField.get(distribution);
                 
                 assertNotNull(normal);
                 assertTrue(normal instanceof NormalDistributionImpl);
                 assertEquals(mean, ((NormalDistributionImpl)normal).getMean(), 0.0);
                 assertEquals(Math.sqrt(mean), ((NormalDistributionImpl)normal).getStandardDeviation(), 0.0);
             } catch (NoSuchFieldException | IllegalAccessException e) {
                 fail("Failed to access private field 'normal' through reflection: " + e.getMessage());
             }
         }

 @Test
         public void testConstructor_DefaultEpsilonAndMaxIterations() throws Exception {
             // Test with only mean specified, using default epsilon and maxIterations
             double mean = 3.0;
             
             PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean,
                 PoissonDistributionImpl.DEFAULT_EPSILON,
                 PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS);
             
             assertEquals(mean, distribution.getMean(), 0.0);
             
             // Use reflection to access private fields
             Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
             epsilonField.setAccessible(true);
             double actualEpsilon = epsilonField.getDouble(distribution);
             assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, actualEpsilon, 0.0);
             
             Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
             maxIterationsField.setAccessible(true);
             int actualMaxIterations = maxIterationsField.getInt(distribution);
             assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, actualMaxIterations);
         }

 @Test
         public void testConstructor_ExtremelySmallEpsilon() throws Exception {
             // Test with very small epsilon
             double mean = 10.0;
             double epsilon = Double.MIN_VALUE;
             int maxIterations = 10000;
             
             PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
             
             // Use reflection to access private epsilon field
             Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
             epsilonField.setAccessible(true);
             double actualEpsilon = epsilonField.getDouble(distribution);
             
             assertEquals(epsilon, actualEpsilon, 0.0);
         }

 @Test
         public void testConstructor_LargeMaxIterations() {
             // Test with large max iterations
             double mean = 10.0;
             double epsilon = 1e-12;
             int maxIterations = Integer.MAX_VALUE;
             
             PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
             
             try {
                 Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                 maxIterationsField.setAccessible(true);
                 int actualMaxIterations = maxIterationsField.getInt(distribution);
                 assertEquals(maxIterations, actualMaxIterations);
             } catch (NoSuchFieldException | IllegalAccessException e) {
                 fail("Failed to access maxIterations field: " + e.getMessage());
             }
         }

 @Test
         public void testConstructor_ZeroMaxIterations() throws Exception {
             // Test with zero max iterations (should this be allowed?)
             double mean = 10.0;
             double epsilon = 1e-12;
             int maxIterations = 0;
             
             PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
             
             // Use reflection to access private maxIterations field
             Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
             maxIterationsField.setAccessible(true);
             int actualMaxIterations = (int) maxIterationsField.get(distribution);
             
             assertEquals(maxIterations, actualMaxIterations);
         }

 @Test
         public void testConstructor_NegativeEpsilon() {
             // Test with negative epsilon (should this be allowed?)
             double mean = 10.0;
             double epsilon = -1e-12;
             int maxIterations = 10000;
             
             PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
             
             try {
                 Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                 epsilonField.setAccessible(true);
                 double actualEpsilon = epsilonField.getDouble(distribution);
                 assertEquals(epsilon, actualEpsilon, 0.0);
             } catch (Exception e) {
                 fail("Failed to access private epsilon field: " + e.getMessage());
             }
         }

 @Test
         public void testConstructor_ValidPositiveMean1() {
             // Arrange
             double mean = 5.0;
             double epsilon = 1e-12;
             
             // Act
             PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon);
             
             // Assert
             assertEquals(mean, distribution.getMean(), 0.0);
             
             try {
                 // Verify epsilon using reflection
                 Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                 epsilonField.setAccessible(true);
                 assertEquals(epsilon, epsilonField.getDouble(distribution), 0.0);
                 
                 // Verify maxIterations using reflection
                 Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                 maxIterationsField.setAccessible(true);
                 assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, maxIterationsField.getInt(distribution));
                 
                 // Verify normal is not null using reflection
                 Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                 normalField.setAccessible(true);
                 assertNotNull(normalField.get(distribution));
             } catch (Exception e) {
                 fail("Reflection failed: " + e.getMessage());
             }
         }

 @Test
         public void testConstructor_ZeroMean2() {
             // Arrange
             double mean = 0.0;
             double epsilon = 1e-12;
             
             // Act
             PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon);
             
             // Assert
             assertEquals(mean, distribution.getMean(), 0.0);
             try {
                 Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                 epsilonField.setAccessible(true);
                 double actualEpsilon = epsilonField.getDouble(distribution);
                 assertEquals(epsilon, actualEpsilon, 0.0);
             } catch (Exception e) {
                 fail("Failed to access private field epsilon");
             }
         }

 @Test
         public void testConstructor_ZeroEpsilon() {
             // Arrange
             double mean = 5.0;
             double epsilon = 0.0;
             
             // Act
             PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon);
             
             // Assert
             assertEquals(mean, distribution.getMean(), 0.0);
             try {
                 Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                 epsilonField.setAccessible(true);
                 double actualEpsilon = epsilonField.getDouble(distribution);
                 assertEquals(epsilon, actualEpsilon, 0.0);
             } catch (Exception e) {
                 fail("Failed to access epsilon field: " + e.getMessage());
             }
         }

 @Test
         public void testConstructor_VerySmallEpsilon() {
             // Arrange
             double mean = 5.0;
             double epsilon = Double.MIN_VALUE;
             
             // Act
             PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon);
             
             // Assert
             assertEquals(mean, distribution.getMean(), 0.0);
             try {
                 Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                 epsilonField.setAccessible(true);
                 double actualEpsilon = epsilonField.getDouble(distribution);
                 assertEquals(epsilon, actualEpsilon, 0.0);
             } catch (NoSuchFieldException | IllegalAccessException e) {
                 fail("Failed to access private field epsilon: " + e.getMessage());
             }
         }

 @Test
         public void testConstructor_UsesDefaultMaxIterations() {
             // Arrange
             double mean = 5.0;
             double epsilon = 1e-12;
             
             // Act
             PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon);
             
             // Assert
             try {
                 Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                 maxIterationsField.setAccessible(true);
                 int actualMaxIterations = maxIterationsField.getInt(distribution);
                 assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, actualMaxIterations);
             } catch (Exception e) {
                 fail("Failed to access maxIterations field: " + e.getMessage());
             }
         }

 @Test
         public void testConstructorWithValidParameters() throws Exception {
             // Define test constants
             final double TEST_EPSILON = 1e-12;
             
             // Test with typical values
             PoissonDistributionImpl dist = new PoissonDistributionImpl(5.0, 1000);
             
             // Test public getter for mean
             assertEquals(5.0, dist.getMean(), TEST_EPSILON);
             
             // Test private fields using reflection
             Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
             maxIterationsField.setAccessible(true);
             assertEquals(1000, maxIterationsField.getInt(dist));
             
             Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
             epsilonField.setAccessible(true);
             Field defaultEpsilonField = PoissonDistributionImpl.class.getDeclaredField("DEFAULT_EPSILON");
             defaultEpsilonField.setAccessible(true);
             double defaultEpsilon = defaultEpsilonField.getDouble(null);
             assertEquals(defaultEpsilon, epsilonField.getDouble(dist), TEST_EPSILON);
             
             // Verify normal approximation exists by calling a method that uses it
             try {
                 dist.probability(0);  // This will use the normal approximation
                 assertTrue(true);  // If we get here, normal was initialized
             } catch (NullPointerException e) {
                 fail("Normal approximation was not initialized");
             }
         }

 @Test
         public void testConstructorWithZeroMean() throws Exception {
             // Edge case - zero mean
             double TEST_EPSILON = 1e-12;
             PoissonDistributionImpl dist = new PoissonDistributionImpl(0.0, 100);
             
             assertEquals(0.0, dist.getMean(), TEST_EPSILON);
             
             // Use reflection to access private fields
             Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
             maxIterationsField.setAccessible(true);
             int maxIterations = maxIterationsField.getInt(dist);
             assertEquals(100, maxIterations);
             
             Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
             epsilonField.setAccessible(true);
             double epsilon = epsilonField.getDouble(dist);
             assertEquals(1.0e-12, epsilon, TEST_EPSILON);
         }

 @Test
         public void testConstructorWithMaxIterationsEqualToDefault() throws Exception {
             // Define test constants
             final double TEST_EPSILON = 1e-12;
             
             // Using default max iterations value
             PoissonDistributionImpl dist = new PoissonDistributionImpl(3.0, PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS);
             
             // Test mean value
             assertEquals(3.0, dist.getMean(), TEST_EPSILON);
             
             // Test max iterations using reflection since it's private
             Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
             maxIterationsField.setAccessible(true);
             int actualMaxIterations = maxIterationsField.getInt(dist);
             assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, actualMaxIterations);
         }

 @Test
         public void testConstructorWithVerySmallMean() throws Exception {
             // Very small positive mean
             double TEST_EPSILON = 1e-12;
             PoissonDistributionImpl dist = new PoissonDistributionImpl(1e-10, 100);
             
             assertEquals(1e-10, dist.getMean(), TEST_EPSILON);
             
             // Use reflection to access private maxIterations field
             Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
             maxIterationsField.setAccessible(true);
             int maxIterationsValue = (int) maxIterationsField.get(dist);
             assertEquals(100, maxIterationsValue);
         }

 @Test
         public void testConstructorWithLargeMean() throws Exception {
             // Define test constants
             final double TEST_EPSILON = 1e-12;
             
             // Large mean value
             PoissonDistributionImpl dist = new PoissonDistributionImpl(1e10, 10000);
             
             // Test mean value
             assertEquals(1e10, dist.getMean(), TEST_EPSILON);
             
             // Test maxIterations using reflection
             Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
             maxIterationsField.setAccessible(true);
             int actualMaxIterations = maxIterationsField.getInt(dist);
             assertEquals(10000, actualMaxIterations);
         }

 @Test
     public void testConstructor_VeryLargeMean() throws MathException {
         double testMean = 1e10;
         PoissonDistributionImpl dist = new PoissonDistributionImpl(testMean);
         
         assertEquals(testMean, dist.getMean(), 0.0);
         // Test epsilon and maxIterations through their effects
         // Since we can't access private fields directly, we'll verify the constructor worked
         // by checking the object's behavior
         assertTrue(dist.probability(0) >= 0); // Verify basic functionality works
         assertTrue(dist.cumulativeProbability(0) >= 0); // Verify basic functionality works
     }

 @Test
     public void testConstructor_VerifyNormalDistributionInitialization() throws Exception {
         double testMean = 3.0;
         PoissonDistributionImpl dist = new PoissonDistributionImpl(testMean);
         
         // Test that normal approximation works correctly
         // For x = mean, the normal approximation should be close to 0.5
         double probability = dist.normalApproximateProbability((int) testMean);
         assertTrue(probability > 0.4 && probability < 0.6);
         
         // Verify mean through public getter
         assertEquals(testMean, dist.getMean(), 0.0);
     }

}
