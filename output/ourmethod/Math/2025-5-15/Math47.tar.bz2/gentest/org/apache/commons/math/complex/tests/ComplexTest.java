package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
            public void testDivide_TypicalValues() {
                Complex a = new Complex(4, 2);
                Complex b = new Complex(3, -1);
                Complex result = a.divide(b);
                
                assertEquals(1.0, result.getReal(), 0.0001);
                assertEquals(1.0, result.getImaginary(), 0.0001);
            }

 @Test
            public void testDivide_ByZeroWhenNumeratorNonZero() {
                Complex a = new Complex(1, 1);
                Complex zero = Complex.ZERO;
                Complex result = a.divide(zero);
                
                assertSame(Complex.INF, result);
            }

 @Test
            public void testDivide_ZeroByZero() {
                Complex zero = Complex.ZERO;
                Complex result = zero.divide(zero);
                
                assertSame(Complex.NaN, result);
            }

 @Test
            public void testDivide_NaNInNumerator() {
                Complex nan = new Complex(Double.NaN, 1);
                Complex b = new Complex(1, 1);
                Complex result = nan.divide(b);
                
                assertSame(Complex.NaN, result);
            }

 @Test
            public void testDivide_NaNInDenominator() {
                Complex a = new Complex(1, 1);
                Complex nan = new Complex(1, Double.NaN);
                Complex result = a.divide(nan);
                
                assertSame(Complex.NaN, result);
            }

 @Test
            public void testDivide_FiniteByInfinite() {
                Complex a = new Complex(1, 1);
                Complex inf = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                Complex result = a.divide(inf);
                
                assertSame(Complex.ZERO, result);
            }

 @Test
            public void testDivide_WhenAbsCIsLessThanAbsD() {
                // Test case where |c| < |d| in the denominator
                Complex a = new Complex(1, 1);
                Complex b = new Complex(0.5, 2); // |0.5| < |2|
                Complex result = a.divide(b);
                
                assertEquals(0.5, result.getReal(), 0.0001);
                assertEquals(-0.3, result.getImaginary(), 0.0001);
            }

 @Test
            public void testDivide_WhenAbsCIsGreaterThanAbsD() {
                // Test case where |c| >= |d| in the denominator
                Complex a = new Complex(1, 1);
                Complex b = new Complex(2, 0.5); // |2| > |0.5|
                Complex result = a.divide(b);
                
                assertEquals(0.5, result.getReal(), 0.0001);
                assertEquals(0.375, result.getImaginary(), 0.0001);
            }

 @Test
            public void testDivide_NullDivisor() {
                Complex a = new Complex(1, 1);
                
                thrown.expect(NullPointerException.class);
                thrown.expectMessage("divisor");
                a.divide(null);
            }

 @Test
            public void testDivide_RealNumbersOnly() {
                Complex a = new Complex(6, 0);
                Complex b = new Complex(3, 0);
                Complex result = a.divide(b);
                
                assertEquals(2.0, result.getReal(), 0.0001);
                assertEquals(0.0, result.getImaginary(), 0.0001);
            }

 @Test
            public void testDivide_ImaginaryNumbersOnly() {
                Complex a = new Complex(0, 4);
                Complex b = new Complex(0, 2);
                Complex result = a.divide(b);
                
                assertEquals(2.0, result.getReal(), 0.0001);
                assertEquals(0.0, result.getImaginary(), 0.0001);
            }

 @Test
            public void testDivide_ByOne() {
                Complex a = new Complex(3, 4);
                Complex result = a.divide(Complex.ONE);
                
                assertEquals(a.getReal(), result.getReal(), 0.0001);
                assertEquals(a.getImaginary(), result.getImaginary(), 0.0001);
            }

 @Test
            public void testDivide_ByItself() {
                Complex a = new Complex(3, 4);
                Complex result = a.divide(a);
                
                assertEquals(1.0, result.getReal(), 0.0001);
                assertEquals(0.0, result.getImaginary(), 0.0001);
            }

 @Test
            public void testDivide_NaNInput() {
                Complex complex = new Complex(3, 4);
                Complex result = complex.divide(Double.NaN);
                assertTrue(result.isNaN());
            }

 @Test
            public void testDivide_WhenComplexIsNaN() {
                Complex complex = new Complex(Double.NaN, Double.NaN);
                Complex result = complex.divide(5);
                assertTrue(result.isNaN());
            }

 @Test
            public void testDivide_ByZero_WhenComplexIsZero() {
                Complex complex = new Complex(0, 0);
                Complex result = complex.divide(0);
                assertTrue(result.isNaN());
            }

 @Test
            public void testDivide_ByZero_WhenComplexIsNonZero() {
                Complex complex = new Complex(3, 4);
                Complex result = complex.divide(0);
                assertEquals(Complex.INF, result);
            }

 @Test
            public void testDivide_ByInfinite_WhenComplexIsFinite() {
                Complex complex = new Complex(3, 4);
                Complex result = complex.divide(Double.POSITIVE_INFINITY);
                assertEquals(Complex.ZERO, result);
            }

 @Test
            public void testDivide_ByInfinite_WhenComplexIsInfinite() {
                Complex complex = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                Complex result = complex.divide(Double.POSITIVE_INFINITY);
                assertTrue(result.isNaN());
            }

 @Test
            public void testDivide_NormalDivision() {
                Complex complex = new Complex(6, 8);
                Complex result = complex.divide(2);
                assertEquals(3, result.getReal(), 0.0001);
                assertEquals(4, result.getImaginary(), 0.0001);
            }

 @Test
            public void testDivide_NegativeDivisor() {
                Complex complex = new Complex(6, 8);
                Complex result = complex.divide(-2);
                assertEquals(-3, result.getReal(), 0.0001);
                assertEquals(-4, result.getImaginary(), 0.0001);
            }

 @Test
            public void testDivide_ComplexWithZeroImaginary() {
                Complex complex = new Complex(6, 0);
                Complex result = complex.divide(2);
                assertEquals(3, result.getReal(), 0.0001);
                assertEquals(0, result.getImaginary(), 0.0001);
            }

 @Test
            public void testDivide_ComplexWithZeroReal() {
                Complex complex = new Complex(0, 8);
                Complex result = complex.divide(2);
                assertEquals(0, result.getReal(), 0.0001);
                assertEquals(4, result.getImaginary(), 0.0001);
            }

 @Test
            public void testDivide_ResultingInVerySmallValues() {
                Complex complex = new Complex(Double.MIN_VALUE, Double.MIN_VALUE);
                Complex result = complex.divide(Double.MAX_VALUE);
                assertEquals(0, result.getReal(), 0.0001);
                assertEquals(0, result.getImaginary(), 0.0001);
            }

 @Test
            public void testDivide_ResultingInVeryLargeValues() {
                Complex complex = new Complex(Double.MAX_VALUE, Double.MAX_VALUE);
                Complex result = complex.divide(Double.MIN_VALUE);
                assertTrue(Double.isInfinite(result.getReal()));
                assertTrue(Double.isInfinite(result.getImaginary()));
            }

 @Test
    public void testDivideWithNaNCases() {
        // Case 1: This complex is NaN, divisor is not NaN
        Complex nanComplex = new Complex(Double.NaN, 1.0);
        Complex normalDivisor = new Complex(1.0, 1.0);
        assertEquals(Complex.NaN, nanComplex.divide(normalDivisor));
        
        // Case 2: This complex is not NaN, divisor is NaN
        Complex normalComplex = new Complex(1.0, 1.0);
        Complex nanDivisor = new Complex(Double.NaN, 1.0);
        assertEquals(Complex.NaN, normalComplex.divide(nanDivisor));
        
        // Case 3: Both are NaN (both original and mutant should return NaN)
        assertEquals(Complex.NaN, nanComplex.divide(nanDivisor));
        
        // Case 4: Neither is NaN (both should perform normal division)
        Complex result = normalComplex.divide(normalDivisor);
        assertFalse(result.isNaN());
    }

 @Test
    public void testDivideWithNaNHandling() {
        // Case 1: Complex is NaN but divisor is valid
        Complex nanComplex = new Complex(Double.NaN, 1.0);
        double validDivisor = 2.0;
        assertEquals(Complex.NaN, nanComplex.divide(validDivisor));
        
        // Case 2: Complex is valid but divisor is NaN
        Complex validComplex = new Complex(1.0, 1.0);
        double nanDivisor = Double.NaN;
        assertEquals(Complex.NaN, validComplex.divide(nanDivisor));
        
        // Case 3: Both are NaN (should still return NaN)
        assertEquals(Complex.NaN, nanComplex.divide(nanDivisor));
        
        // Case 4: Neither is NaN (should do normal division)
        Complex normalComplex = new Complex(4.0, 8.0);
        double normalDivisor = 2.0;
        Complex expected = new Complex(2.0, 4.0);
        assertEquals(expected, normalComplex.divide(normalDivisor));
    }

 @Test
       public void testDivide_CurrentNumberIsNaN_ShouldReturnNaN() {
           // Create a NaN complex number (using Double.NaN in constructor)
           Complex nanNumber = new Complex(Double.NaN, 0.0);
           Complex validDivisor = new Complex(1.0, 1.0);
           
           // The original code should return NaN when current number is NaN
           // The mutant will proceed with division since it only checks divisor
           Complex result = nanNumber.divide(validDivisor);
           
           assertTrue("Dividing NaN by valid number should return NaN", 
                     result.isNaN());
       }

 @Test
       public void testDivide_BothNumbersAreNaN_ShouldReturnNaN() {
           Complex nanNumber1 = new Complex(Double.NaN, 0.0);
           Complex nanNumber2 = new Complex(0.0, Double.NaN);
           
           Complex result = nanNumber1.divide(nanNumber2);
           
           assertTrue("Dividing two NaN numbers should return NaN",
                     result.isNaN());
       }

 @Test
       public void testDivide_DivisorIsNaN_ShouldReturnNaN() {
           Complex validNumber = new Complex(1.0, 1.0);
           Complex nanDivisor = new Complex(Double.NaN, 0.0);
           
           Complex result = validNumber.divide(nanDivisor);
           
           assertTrue("Dividing valid number by NaN should return NaN",
                     result.isNaN());
       }

 @Test
       public void testDivideWhenComplexIsNaN() {
           // Create a NaN complex number (with NaN real part)
           Complex nanComplex = new Complex(Double.NaN, 1.0);
           double validDivisor = 2.0;
           
           // The original code should return NaN when either the complex is NaN or divisor is NaN
           // The mutant would skip this check and perform the division
           Complex result = nanComplex.divide(validDivisor);
           
           // Verify the result is NaN (which would catch the mutant)
           assertTrue(Double.isNaN(result.getReal()));
           assertTrue(Double.isNaN(result.getImaginary()));
       }

 @Test
       public void testDivideWhenComplexIsNaNWithImaginaryPart() {
           // Another test case with NaN in imaginary part
           Complex nanComplex = new Complex(1.0, Double.NaN);
           double validDivisor = 3.0;
           
           Complex result = nanComplex.divide(validDivisor);
           
           assertTrue(Double.isNaN(result.getReal()));
           assertTrue(Double.isNaN(result.getImaginary()));
       }

 @Test
  public void testDivideByNaNComplexShouldReturnNaN() {
      // Create a normal complex number (non-NaN)
      Complex dividend = new Complex(2.0, 3.0);
      
      // Create a divisor with NaN in real part
      Complex divisorWithNaNReal = new Complex(Double.NaN, 1.0);
      Complex result1 = dividend.divide(divisorWithNaNReal);
      assertTrue("Dividing by complex with NaN real part should return NaN", 
                 result1.isNaN());
      
      // Create a divisor with NaN in imaginary part
      Complex divisorWithNaNImaginary = new Complex(1.0, Double.NaN);
      Complex result2 = dividend.divide(divisorWithNaNImaginary);
      assertTrue("Dividing by complex with NaN imaginary part should return NaN", 
                 result2.isNaN());
      
      // Create a divisor with both parts NaN
      Complex divisorWithBothNaN = new Complex(Double.NaN, Double.NaN);
      Complex result3 = dividend.divide(divisorWithBothNaN);
      assertTrue("Dividing by complex with both parts NaN should return NaN", 
                 result3.isNaN());
  }

 @Test
      public void testDivideWithNaNDivisorShouldReturnNaN() {
          // Create a valid complex number (not NaN)
          Complex complex = new Complex(1.0, 2.0);
          
          // Use NaN as divisor
          double nanDivisor = Double.NaN;
          
          // The original code should return NaN when divisor is NaN
          // The mutant would try to perform division instead
          Complex result = complex.divide(nanDivisor);
          
          // Assert that the result is NaN (original behavior)
          assertTrue(result.isNaN());
          
          // Additional assertion to ensure it's exactly the NaN constant
          assertSame(Complex.NaN, result);
      }

 @Test
     public void testDivideWithNaN() {
         // Test case 1: Current complex number has NaN in real part
         Complex c1 = new Complex(Double.NaN, 1.0);
         Complex divisor1 = new Complex(1.0, 1.0);
         assertEquals(Complex.NaN, c1.divide(divisor1));
         
         // Test case 2: Current complex number has NaN in imaginary part
         Complex c2 = new Complex(1.0, Double.NaN);
         Complex divisor2 = new Complex(1.0, 1.0);
         assertEquals(Complex.NaN, c2.divide(divisor2));
         
         // Test case 3: Divisor has NaN in real part
         Complex c3 = new Complex(1.0, 1.0);
         Complex divisor3 = new Complex(Double.NaN, 1.0);
         assertEquals(Complex.NaN, c3.divide(divisor3));
         
         // Test case 4: Divisor has NaN in imaginary part
         Complex c4 = new Complex(1.0, 1.0);
         Complex divisor4 = new Complex(1.0, Double.NaN);
         assertEquals(Complex.NaN, c4.divide(divisor4));
         
         // Test case 5: Both have NaN
         Complex c5 = new Complex(Double.NaN, 1.0);
         Complex divisor5 = new Complex(1.0, Double.NaN);
         assertEquals(Complex.NaN, c5.divide(divisor5));
     }

 @Test
 public void testDivideWithNaN1() {
     // Test case 1: Complex number with NaN real part
     Complex nanComplex = new Complex(Double.NaN, 1.0);
     Complex result1 = nanComplex.divide(2.0);
     assertEquals(Complex.NaN, result1);
     
     // Test case 2: Complex number with NaN imaginary part
     Complex nanComplex2 = new Complex(1.0, Double.NaN);
     Complex result2 = nanComplex2.divide(2.0);
     assertEquals(Complex.NaN, result2);
     
     // Test case 3: Valid complex number divided by NaN
     Complex validComplex = new Complex(1.0, 1.0);
     Complex result3 = validComplex.divide(Double.NaN);
     assertEquals(Complex.NaN, result3);
     
     // Test case 4: Complex number with both parts NaN divided by valid number
     Complex nanComplex3 = new Complex(Double.NaN, Double.NaN);
     Complex result4 = nanComplex3.divide(2.0);
     assertEquals(Complex.NaN, result4);
     
     // Test case 5: Complex number with both parts NaN divided by NaN
     Complex result5 = nanComplex3.divide(Double.NaN);
     assertEquals(Complex.NaN, result5);
 }

}
