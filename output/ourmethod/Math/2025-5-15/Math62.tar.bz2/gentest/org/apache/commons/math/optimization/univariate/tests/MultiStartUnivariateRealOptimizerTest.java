package gentest.org.apache.commons.math.optimization.univariate.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.univariate.*;
import java.util.Arrays;
import java.util.Comparator;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.ConvergenceException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.random.RandomGenerator;
import org.apache.commons.math.optimization.GoalType;
import org.apache.commons.math.optimization.ConvergenceChecker;
import org.apache.commons.math.util.FastMath;
 
public class MultiStartUnivariateRealOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                    public void testOptimize_WithValidParameters() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        BaseUnivariateRealOptimizer<UnivariateRealFunction> baseOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                        RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                                        MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(baseOptimizer, 5, generator);
                                                                                                                                                        
                                                                                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                        GoalType goal = GoalType.MINIMIZE;
                                                                                                                                                        double min = 0.0;
                                                                                                                                                        double max = 10.0;
                                                                                                                                                        
                                                                                                                                                        UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(5.0, -10.0);
                                                                                                                                                        when(baseOptimizer.optimize(eq(function), eq(goal), eq(min), eq(max), anyDouble()))
                                                                                                                                                            .thenReturn(expectedResult);
                                                                                                                                                        
                                                                                                                                                        // Execute
                                                                                                                                                        UnivariateRealPointValuePair result = optimizer.optimize(function, goal, min, max);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        assertNotNull(result);
                                                                                                                                                        assertEquals(expectedResult.getValue(), result.getValue(), 0.0001);
                                                                                                                                                        assertEquals(expectedResult.getPoint(), result.getPoint(), 0.0001);
                                                                                                                                                        verify(baseOptimizer, times(5)).optimize(eq(function), eq(goal), eq(min), eq(max), anyDouble());
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testOptimize_WithSingleStart() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        BaseUnivariateRealOptimizer<UnivariateRealFunction> baseOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                        RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                                        MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(baseOptimizer, 1, generator);
                                                                                                                                                        
                                                                                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                        GoalType goal = GoalType.MINIMIZE;
                                                                                                                                                        double min = -5.0;
                                                                                                                                                        double max = 5.0;
                                                                                                                                                        double expectedStart = min + 0.5 * (max - min); // 0.0
                                                                                                                                                        
                                                                                                                                                        UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(0.0, -1.0);
                                                                                                                                                        when(baseOptimizer.optimize(function, goal, min, max, expectedStart))
                                                                                                                                                            .thenReturn(expectedResult);
                                                                                                                                                        
                                                                                                                                                        // Execute
                                                                                                                                                        UnivariateRealPointValuePair result = optimizer.optimize(function, goal, min, max);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        assertEquals(expectedResult, result);
                                                                                                                                                        verify(baseOptimizer).optimize(function, goal, min, max, expectedStart);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testOptimize_WithMaxEvaluations() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        BaseUnivariateRealOptimizer<UnivariateRealFunction> baseOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                        RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                                        MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(baseOptimizer, 2, generator);
                                                                                                                                                        
                                                                                                                                                        optimizer.setMaxEvaluations(100);
                                                                                                                                                        
                                                                                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                        GoalType goal = GoalType.MINIMIZE;
                                                                                                                                                        double min = 0.0;
                                                                                                                                                        double max = 1.0;
                                                                                                                                                        
                                                                                                                                                        UnivariateRealPointValuePair result1 = new UnivariateRealPointValuePair(0.3, -0.5);
                                                                                                                                                        UnivariateRealPointValuePair result2 = new UnivariateRealPointValuePair(0.7, -0.8);
                                                                                                                                                        when(baseOptimizer.optimize(eq(function), eq(goal), eq(min), eq(max), anyDouble()))
                                                                                                                                                            .thenReturn(result1)
                                                                                                                                                            .thenReturn(result2);
                                                                                                                                                        
                                                                                                                                                        // Execute
                                                                                                                                                        UnivariateRealPointValuePair result = optimizer.optimize(function, goal, min, max);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        assertEquals(result2, result); // Should return the better of the two results
                                                                                                                                                        assertEquals(100, optimizer.getMaxEvaluations());
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testOptimize_VerifiesOptimaStorage() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        BaseUnivariateRealOptimizer<UnivariateRealFunction> baseOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                        RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                                        MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(baseOptimizer, 2, generator);
                                                                                                                                                        
                                                                                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                        GoalType goal = GoalType.MINIMIZE;
                                                                                                                                                        double min = -10.0;
                                                                                                                                                        double max = 10.0;
                                                                                                                                                        
                                                                                                                                                        UnivariateRealPointValuePair result1 = new UnivariateRealPointValuePair(-5.0, -20.0);
                                                                                                                                                        UnivariateRealPointValuePair result2 = new UnivariateRealPointValuePair(5.0, -15.0);
                                                                                                                                                        when(baseOptimizer.optimize(eq(function), eq(goal), eq(min), eq(max), anyDouble()))
                                                                                                                                                            .thenReturn(result1)
                                                                                                                                                            .thenReturn(result2);
                                                                                                                                                        
                                                                                                                                                        // Execute
                                                                                                                                                        UnivariateRealPointValuePair result = optimizer.optimize(function, goal, min, max);
                                                                                                                                                        
                                                                                                                                                        // Verify optima storage
                                                                                                                                                        UnivariateRealPointValuePair[] optima = optimizer.getOptima();
                                                                                                                                                        assertNotNull(optima);
                                                                                                                                                        assertEquals(2, optima.length);
                                                                                                                                                        assertEquals(result1, optima[0]);
                                                                                                                                                        assertEquals(result2, optima[1]);
                                                                                                                                                    }

    @Test
                                                                                                                                            public void testOptimize_AllAttemptsFail() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                MultiStartUnivariateRealOptimizer multiStartOptimizer = new MultiStartUnivariateRealOptimizer(optimizer, 5, generator);
                                                                                                                                                
                                                                                                                                                when(optimizer.getEvaluations()).thenReturn(10);
                                                                                                                                                when(optimizer.getMaxEvaluations()).thenReturn(100);
                                                                                                                                                when(generator.nextDouble()).thenReturn(0.5);
                                                                                                                                                
                                                                                                                                                when(optimizer.optimize(eq(function), eq(GoalType.MINIMIZE), eq(0.0), eq(10.0), anyDouble()))
                                                                                                                                                    .thenThrow(new ConvergenceException(LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT, 5));
                                                                                                                                                
                                                                                                                                                // Expect exception
                                                                                                                                                try {
                                                                                                                                                    multiStartOptimizer.optimize(function, GoalType.MINIMIZE, 0.0, 10.0, 5.0);
                                                                                                                                                    fail("Expected ConvergenceException");
                                                                                                                                                } catch (ConvergenceException e) {
                                                                                                                                                    assertEquals("no convergence with any start point", e.getMessage());
                                                                                                                                                }
                                                                                                                                            }

    @Test
                                                                                                                                        public void testOptimize_ProperRandomStartValues() throws Exception {
                                                                                                                                            // Setup mocks and test objects
                                                                                                                                            BaseUnivariateRealOptimizer optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                            RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                            
                                                                                                                                            // Create the optimizer under test with 3 starts
                                                                                                                                            MultiStartUnivariateRealOptimizer multiStartOptimizer = 
                                                                                                                                                new MultiStartUnivariateRealOptimizer(optimizer, 3, generator);
                                                                                                                                            
                                                                                                                                            // Configure mocks
                                                                                                                                            when(optimizer.getEvaluations()).thenReturn(10);
                                                                                                                                            when(optimizer.getMaxEvaluations()).thenReturn(100);
                                                                                                                                            when(generator.nextDouble()).thenReturn(0.25, 0.75);
                                                                                                                                            
                                                                                                                                            UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(1.0, 2.0);
                                                                                                                                            when(optimizer.optimize(eq(function), eq(GoalType.MINIMIZE), eq(0.0), eq(10.0), anyDouble()))
                                                                                                                                                .thenReturn(expectedResult);
                                                                                                                                            
                                                                                                                                            // Test
                                                                                                                                            multiStartOptimizer.optimize(function, GoalType.MINIMIZE, 0.0, 10.0, 5.0);
                                                                                                                                            
                                                                                                                                            // Verify random start values
                                                                                                                                            verify(optimizer).optimize(function, GoalType.MINIMIZE, 0.0, 10.0, 5.0); // First attempt with startValue
                                                                                                                                            verify(optimizer).optimize(function, GoalType.MINIMIZE, 0.0, 10.0, 2.5); // 0 + 0.25 * (10-0)
                                                                                                                                            verify(optimizer).optimize(function, GoalType.MINIMIZE, 0.0, 10.0, 7.5); // 0 + 0.75 * (10-0)
                                                                                                                                        }

    @Test
                                                                                                                                    public void testOptimize_EvaluationsTracking() throws Exception {
                                                                                                                                        // Setup
                                                                                                                                        BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                        RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                        
                                                                                                                                        MultiStartUnivariateRealOptimizer multiStartOptimizer = 
                                                                                                                                            new MultiStartUnivariateRealOptimizer(optimizer, 3, generator);
                                                                                                                                        
                                                                                                                                        when(optimizer.getEvaluations()).thenReturn(15, 20, 10); // Different evaluations for each attempt
                                                                                                                                        when(optimizer.getMaxEvaluations()).thenReturn(100);
                                                                                                                                        when(generator.nextDouble()).thenReturn(0.5);
                                                                                                                                        
                                                                                                                                        when(optimizer.optimize(eq(function), eq(GoalType.MINIMIZE), eq(0.0), eq(10.0), anyDouble()))
                                                                                                                                            .thenReturn(new UnivariateRealPointValuePair(1.0, 2.0));
                                                                                                                                        
                                                                                                                                        // Test
                                                                                                                                        multiStartOptimizer.optimize(function, GoalType.MINIMIZE, 0.0, 10.0, 5.0);
                                                                                                                                        
                                                                                                                                        // Verify evaluations tracking through the optimizer mock calls
                                                                                                                                        verify(optimizer).setMaxEvaluations(100 - 15);
                                                                                                                                        verify(optimizer).setMaxEvaluations(85 - 20);
                                                                                                                                        verify(optimizer).setMaxEvaluations(65 - 10);
                                                                                                                                    }

    @Test
                                                                                                                                public void testOptimize_FunctionEvaluationException() throws Exception {
                                                                                                                                    // Setup mocks
                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                    BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                    RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                    
                                                                                                                                    // Create the multi-start optimizer with mocks
                                                                                                                                    int starts = 2;
                                                                                                                                    MultiStartUnivariateRealOptimizer multiStartOptimizer = 
                                                                                                                                        new MultiStartUnivariateRealOptimizer(optimizer, starts, generator);
                                                                                                                                    
                                                                                                                                    // Configure mocks
                                                                                                                                    when(optimizer.getEvaluations()).thenReturn(10);
                                                                                                                                    when(optimizer.getMaxEvaluations()).thenReturn(100);
                                                                                                                                    when(generator.nextDouble()).thenReturn(0.5);
                                                                                                                                    
                                                                                                                                    // First call throws exception, second call succeeds
                                                                                                                                    when(optimizer.optimize(eq(function), eq(GoalType.MINIMIZE), eq(0.0), eq(10.0), eq(5.0)))
                                                                                                                                        .thenThrow(new FunctionEvaluationException(1.0, "Error"));
                                                                                                                                    when(optimizer.optimize(eq(function), eq(GoalType.MINIMIZE), eq(0.0), eq(10.0), anyDouble()))
                                                                                                                                        .thenReturn(new UnivariateRealPointValuePair(1.0, 2.0));
                                                                                                                                    
                                                                                                                                    // Test
                                                                                                                                    UnivariateRealPointValuePair result = multiStartOptimizer.optimize(
                                                                                                                                        function, GoalType.MINIMIZE, 0.0, 10.0, 5.0);
                                                                                                                                    
                                                                                                                                    // Verify
                                                                                                                                    assertNotNull(result);
                                                                                                                                    assertEquals(20, multiStartOptimizer.getEvaluations());
                                                                                                                                }

    @Test
                                                                                                                    public void testOptimize_WithNullGoalType() throws Exception {
                                                                                                                        // Setup
                                                                                                                        @SuppressWarnings("unchecked")
                                                                                                                        BaseUnivariateRealOptimizer<UnivariateRealFunction> baseOptimizer = 
                                                                                                                            mock(BaseUnivariateRealOptimizer.class);
                                                                                                                        RandomGenerator generator = 
                                                                                                                            mock(RandomGenerator.class);
                                                                                                                        MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                            new MultiStartUnivariateRealOptimizer(baseOptimizer, 3, generator);
                                                                                                                        
                                                                                                                        UnivariateRealFunction function = 
                                                                                                                            mock(UnivariateRealFunction.class);
                                                                                                                        
                                                                                                                        // Expect exception
                                                                                                                        try {
                                                                                                                            optimizer.optimize(function, null, 0.0, 1.0);
                                                                                                                            fail("Expected IllegalArgumentException");
                                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                                            assertEquals("goal is null", e.getMessage());
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                            public void testOptimize_SuccessfulOptimization() throws Exception {
                                                                                                                // Setup
                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                
                                                                                                                MultiStartUnivariateRealOptimizer multiStartOptimizer = new MultiStartUnivariateRealOptimizer(optimizer, 3, generator);
                                                                                                                
                                                                                                                when(optimizer.getEvaluations()).thenReturn(10);
                                                                                                                when(optimizer.getMaxEvaluations()).thenReturn(100);
                                                                                                                when(generator.nextDouble()).thenReturn(0.5);
                                                                                                                
                                                                                                                UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(1.0, 2.0);
                                                                                                                when(optimizer.optimize(eq(function), eq(GoalType.MINIMIZE), eq(0.0), eq(10.0)))
                                                                                                                    .thenReturn(expectedResult);
                                                                                                                
                                                                                                                // Test
                                                                                                                UnivariateRealPointValuePair result = multiStartOptimizer.optimize(
                                                                                                                    function, GoalType.MINIMIZE, 0.0, 10.0);
                                                                                                                
                                                                                                                // Verify
                                                                                                                assertEquals(expectedResult, result);
                                                                                                                // Since each optimizer mock returns 10 evaluations and there are 3 starts
                                                                                                                assertEquals(30, optimizer.getEvaluations() * 3);
                                                                                                                verify(optimizer, times(3)).setMaxEvaluations(anyInt());
                                                                                                            }

    @Test
                                                                                                        public void testOptimize_WithInvalidRange() throws Exception {
                                                                                                            // Setup
                                                                                                            @SuppressWarnings("unchecked")
                                                                                                            BaseUnivariateRealOptimizer<UnivariateRealFunction> baseOptimizer = 
                                                                                                                mock(BaseUnivariateRealOptimizer.class);
                                                                                                            RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                            MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(baseOptimizer, 3, generator);
                                                                                                            
                                                                                                            @SuppressWarnings("unchecked")
                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                            GoalType goal = GoalType.MAXIMIZE;
                                                                                                            
                                                                                                            // Expect exception
                                                                                                            
                                                                                                            // Execute with invalid range (min > max)
                                                                                                            optimizer.optimize(function, goal, 10.0, 5.0);
                                                                                                        }

    @Test
                                                                                                        public void testOptimize_WithNullFunction() throws Exception {
                                                                                                            // Setup
                                                                                                            @SuppressWarnings("unchecked")
                                                                                                            BaseUnivariateRealOptimizer<UnivariateRealFunction> baseOptimizer = 
                                                                                                                mock(BaseUnivariateRealOptimizer.class);
                                                                                                            RandomGenerator generator = 
                                                                                                                mock(RandomGenerator.class);
                                                                                                            MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                new MultiStartUnivariateRealOptimizer(baseOptimizer, 3, generator);
                                                                                                            
                                                                                                            // Expect exception
                                                                                                            
                                                                                                            // Execute with null function
                                                                                                            optimizer.optimize(null, GoalType.MINIMIZE, 0.0, 1.0);
                                                                                                        }

    @Test
                                                                                                        public void testOptimize_FirstAttemptFailsButSecondSucceeds() throws Exception {
                                                                                                            // Setup
                                                                                                            BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = 
                                                                                                                mock(BaseUnivariateRealOptimizer.class);
                                                                                                            RandomGenerator generator = 
                                                                                                                mock(RandomGenerator.class);
                                                                                                            UnivariateRealFunction function = 
                                                                                                                mock(UnivariateRealFunction.class);
                                                                                                            
                                                                                                            MultiStartUnivariateRealOptimizer multiStartOptimizer = 
                                                                                                                new MultiStartUnivariateRealOptimizer(optimizer, 2, generator);
                                                                                                            
                                                                                                            when(optimizer.getEvaluations()).thenReturn(10);
                                                                                                            when(optimizer.getMaxEvaluations()).thenReturn(100);
                                                                                                            when(generator.nextDouble()).thenReturn(0.5);
                                                                                                            
                                                                                                            UnivariateRealPointValuePair expectedResult = 
                                                                                                                new UnivariateRealPointValuePair(1.0, 2.0);
                                                                                                            when(optimizer.optimize(
                                                                                                                eq(function), 
                                                                                                                eq(GoalType.MAXIMIZE), 
                                                                                                                eq(0.0), 
                                                                                                                eq(10.0), 
                                                                                                                eq(5.0)))
                                                                                                                .thenThrow(new ConvergenceException())
                                                                                                                .thenReturn(expectedResult)
                                                                                                                .thenReturn(new UnivariateRealPointValuePair(2.0, 3.0));
                                                                                                            
                                                                                                            // Test
                                                                                                            UnivariateRealPointValuePair result = 
                                                                                                                multiStartOptimizer.optimize(function, GoalType.MAXIMIZE, 0.0, 10.0, 5.0);
                                                                                                            
                                                                                                            // Verify
                                                                                                            assertEquals(expectedResult, result);
                                                                                                            assertEquals(20, multiStartOptimizer.getEvaluations());
                                                                                                        }

    @Test(expected = RuntimeException.class)
                                                                                                    public void testOptimize_ShouldNotCatchRuntimeException() throws Exception {
                                                                                                        // Setup
                                                                                                        BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                        RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                        MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                            new MultiStartUnivariateRealOptimizer(mockOptimizer, 2, mockGenerator);
                                                                                                        
                                                                                                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                        GoalType goal = GoalType.MINIMIZE;
                                                                                                        double min = 0;
                                                                                                        double max = 10;
                                                                                                        double startValue = 5;
                                                                                                        
                                                                                                        // Configure mock behavior
                                                                                                        when(mockOptimizer.optimize(mockFunction, goal, min, max, startValue))
                                                                                                            .thenThrow(new RuntimeException("Test exception"));
                                                                                                        when(mockGenerator.nextDouble()).thenReturn(0.5);
                                                                                                        
                                                                                                        // This should throw RuntimeException with original code
                                                                                                        // With mutant, it would catch the exception and continue
                                                                                                        optimizer.optimize(mockFunction, goal, min, max, startValue);
                                                                                                        
                                                                                                        // Verify interactions
                                                                                                        verify(mockOptimizer).optimize(mockFunction, goal, min, max, startValue);
                                                                                                    }

    @Test
                                                                                                   public void testOptimize_ShouldNotCatchNonConvergenceExceptions() throws Exception {
                                                                                                       // Setup
                                                                                                       @SuppressWarnings("unchecked")
                                                                                                       BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = 
                                                                                                           mock(BaseUnivariateRealOptimizer.class);
                                                                                                       RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                       MultiStartUnivariateRealOptimizer<UnivariateRealFunction> optimizer = 
                                                                                                           new MultiStartUnivariateRealOptimizer<>(mockOptimizer, 5, mockGenerator);
                                                                                                       
                                                                                                       UnivariateRealFunction mockF = mock(UnivariateRealFunction.class);
                                                                                                       GoalType mockGoal = GoalType.MAXIMIZE;
                                                                                                       double min = 0.0;
                                                                                                       double max = 10.0;
                                                                                                       
                                                                                                       // Configure the optimizer to throw a non-ConvergenceException
                                                                                                       when(mockOptimizer.optimize(
                                                                                                           same(mockF), 
                                                                                                           same(mockGoal), 
                                                                                                           eq(min), 
                                                                                                           eq(max), 
                                                                                                           eq(5.0) // midpoint between min and max
                                                                                                       )).thenThrow(new NullPointerException("Test exception"));
                                                                                                       
                                                                                                       // Expect the exception to propagate
                                                                                                       thrown.expect(NullPointerException.class);
                                                                                                       thrown.expectMessage("Test exception");
                                                                                                       
                                                                                                       // Test
                                                                                                       optimizer.optimize(mockF, mockGoal, min, max);
                                                                                                       
                                                                                                       // Verify the interaction
                                                                                                       verify(mockOptimizer).optimize(mockF, mockGoal, min, max, 5.0);
                                                                                                   }

    @Test
                                                                                                   public void testOptimize_ShouldStillCatchConvergenceExceptions() throws Exception {
                                                                                                       // Setup
                                                                                                       @SuppressWarnings("unchecked")
                                                                                                       BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = 
                                                                                                           mock(BaseUnivariateRealOptimizer.class);
                                                                                                       RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                       MultiStartUnivariateRealOptimizer<UnivariateRealFunction> optimizer = 
                                                                                                           new MultiStartUnivariateRealOptimizer<>(mockOptimizer, 5, mockGenerator);
                                                                                                       
                                                                                                       UnivariateRealFunction mockF = mock(UnivariateRealFunction.class);
                                                                                                       GoalType mockGoal = GoalType.MAXIMIZE;
                                                                                                       double min = 0.0;
                                                                                                       double max = 10.0;
                                                                                                       
                                                                                                       // Configure the optimizer to throw a ConvergenceException
                                                                                                       when(mockOptimizer.optimize(
                                                                                                           same(mockF), 
                                                                                                           same(mockGoal), 
                                                                                                           eq(min), 
                                                                                                           eq(max), 
                                                                                                           eq(5.0)
                                                                                                       )).thenThrow(new ConvergenceException());
                                                                                                       
                                                                                                       // Test - should not throw any exception
                                                                                                       optimizer.optimize(mockF, mockGoal, min, max);
                                                                                                       
                                                                                                       // Verify the interaction
                                                                                                       verify(mockOptimizer).optimize(mockF, mockGoal, min, max, 5.0);
                                                                                                   }

    @Test
                                                                                              public void testOptimizeHandlesFailedAttemptsCorrectly() throws Exception {
                                                                                                  // Setup
                                                                                                  @SuppressWarnings("unchecked")
                                                                                                  BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                  RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                  MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 3, mockGenerator);
                                                                                                  
                                                                                                  // Configure mock behavior
                                                                                                  UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                  GoalType goal = GoalType.MINIMIZE;
                                                                                                  double min = 0;
                                                                                                  double max = 10;
                                                                                                  double startValue = 5;
                                                                                                  
                                                                                                  // First attempt succeeds, others fail
                                                                                                  UnivariateRealPointValuePair successResult = new UnivariateRealPointValuePair(2.0, 1.0);
                                                                                                  when(mockOptimizer.optimize(mockFunction, goal, min, max, startValue))
                                                                                                      .thenReturn(successResult);
                                                                                                  when(mockOptimizer.optimize(mockFunction, goal, min, max, anyDouble()))
                                                                                                      .thenThrow(new ConvergenceException());
                                                                                                  
                                                                                                  // Test
                                                                                                  UnivariateRealPointValuePair result = optimizer.optimize(mockFunction, goal, min, max, startValue);
                                                                                                  
                                                                                                  // Verify
                                                                                                  UnivariateRealPointValuePair[] optima = optimizer.getOptima();
                                                                                                  assertEquals(successResult, optima[0]);  // First attempt succeeded
                                                                                                  assertNull(optima[1]);  // Second attempt should be null (would fail with mutant)
                                                                                                  assertNull(optima[2]);  // Third attempt should be null (would fail with mutant)
                                                                                                  assertEquals(successResult, result);  // Final result should be the successful one
                                                                                              }

    @Test
                                                                                          public void testOptimize_DetectOptimaArrayMutation() throws FunctionEvaluationException {
                                                                                              // Setup
                                                                                              BaseUnivariateRealOptimizer mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                              RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                              
                                                                                              // Create test subject with 3 starts
                                                                                              MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                  new MultiStartUnivariateRealOptimizer(mockOptimizer, 3, mockGenerator);
                                                                                              
                                                                                              // Mock the underlying optimizer to return different results
                                                                                              UnivariateRealPointValuePair result1 = new UnivariateRealPointValuePair(1.0, 10.0);
                                                                                              UnivariateRealPointValuePair result2 = new UnivariateRealPointValuePair(2.0, 20.0);
                                                                                              UnivariateRealPointValuePair result3 = new UnivariateRealPointValuePair(3.0, 30.0);
                                                                                              
                                                                                              when(mockOptimizer.optimize(any(), any(), anyDouble(), anyDouble(), anyDouble()))
                                                                                                  .thenReturn(result1)
                                                                                                  .thenReturn(result2)
                                                                                                  .thenReturn(result3);
                                                                                              
                                                                                              // Execute
                                                                                              optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, 0.0, 10.0);
                                                                                              
                                                                                              // Verify optima array contents
                                                                                              UnivariateRealPointValuePair[] optima = optimizer.getOptima();
                                                                                              assertNotNull(optima);
                                                                                              assertEquals(3, optima.length);
                                                                                              
                                                                                              // Check that all optima entries are distinct objects (not copies)
                                                                                              assertNotSame(optima[0], optima[1]);
                                                                                              assertNotSame(optima[0], optima[2]);
                                                                                              assertNotSame(optima[1], optima[2]);
                                                                                              
                                                                                              // Verify no array element is null (if mutation was present, some might reference optima[0])
                                                                                              for (int i = 0; i < optima.length; i++) {
                                                                                                  assertNotNull("Optima element " + i + " should not be null", optima[i]);
                                                                                              }
                                                                                              
                                                                                              // Verify values are as expected
                                                                                              assertEquals(1.0, optima[0].getPoint(), 0.0001);
                                                                                              assertEquals(2.0, optima[1].getPoint(), 0.0001);
                                                                                              assertEquals(3.0, optima[2].getPoint(), 0.0001);
                                                                                          }

    @Test
                                                                                     public void testMaxEvaluationsDecrement() throws FunctionEvaluationException, ConvergenceException {
                                                                                         // Setup
                                                                                         BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                         RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                         
                                                                                         // Configure mocks
                                                                                         when(mockOptimizer.getMaxEvaluations()).thenReturn(1000);
                                                                                         when(mockOptimizer.getEvaluations()).thenReturn(100);
                                                                                         when(mockOptimizer.optimize(any(), any(), anyDouble(), anyDouble(), anyDouble()))
                                                                                             .thenReturn(new UnivariateRealPointValuePair(0.0, 0.0));
                                                                                         when(mockGenerator.nextDouble()).thenReturn(0.5);
                                                                                         
                                                                                         // Create test instance
                                                                                         MultiStartUnivariateRealOptimizer optimizer = 
                                                                                             new MultiStartUnivariateRealOptimizer(mockOptimizer, 2, mockGenerator);
                                                                                         
                                                                                         // Test
                                                                                         optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MINIMIZE, 0.0, 1.0, 0.5);
                                                                                         
                                                                                         // Verify evaluation count is properly decremented
                                                                                         // Original should be 1000 - 100 = 900 after first iteration
                                                                                         // Mutant would be 1000 + 100 = 1100
                                                                                         verify(mockOptimizer, times(2)).setMaxEvaluations(900);
                                                                                         
                                                                                         // Also verify total evaluations is correctly accumulated
                                                                                         assertEquals(200, optimizer.getEvaluations());
                                                                                     }

    @Test
                                                                     public void testMaxEvaluationsAdjustment() throws FunctionEvaluationException {
                                                                         // Setup mock optimizer
                                                                         @SuppressWarnings("unchecked")
                                                                         BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = 
                                                                             (BaseUnivariateRealOptimizer<UnivariateRealFunction>) mock(BaseUnivariateRealOptimizer.class);
                                                                         when(mockOptimizer.getMaxEvaluations()).thenReturn(1000);
                                                                         when(mockOptimizer.getEvaluations()).thenReturn(200); // Simulate used evaluations
                                                                         
                                                                         // Create test instance
                                                                         MultiStartUnivariateRealOptimizer<UnivariateRealFunction> optimizer = 
                                                                             new MultiStartUnivariateRealOptimizer<UnivariateRealFunction>(mockOptimizer, 5, new org.apache.commons.math.random.JDKRandomGenerator());
                                                                         
                                                                         // Call the method that should adjust evaluations
                                                                         @SuppressWarnings("unchecked")
                                                                         UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                         optimizer.optimize(mockFunction, GoalType.MINIMIZE, 0.0, 1.0);
                                                                         
                                                                         // Verify the evaluation adjustment
                                                                         // Original behavior should set max evaluations to 800 (1000 - 200)
                                                                         // Mutant would set it to 1200 (1000 + 200)
                                                                         verify(mockOptimizer).setMaxEvaluations(800);
                                                                         
                                                                         // Additional verification that we don't exceed total budget
                                                                         org.mockito.ArgumentCaptor<Integer> evalCaptor = org.mockito.ArgumentCaptor.forClass(Integer.class);
                                                                         verify(mockOptimizer).setMaxEvaluations(evalCaptor.capture());
                                                                         assertTrue("Evaluations should decrease", evalCaptor.getValue() < 1000);
                                                                     }

    @Test
                                                                public void testOptimizeHandlesConvergenceException() throws Exception {
                                                                    // Setup
                                                                    @SuppressWarnings("unchecked")
                                                                    BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                    RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                    MultiStartUnivariateRealOptimizer<UnivariateRealFunction> optimizer = 
                                                                        new MultiStartUnivariateRealOptimizer<>(mockOptimizer, 1, mockGenerator);
                                                                    
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    GoalType goal = GoalType.MAXIMIZE;
                                                                    double min = 0;
                                                                    double max = 10;
                                                                    
                                                                    // Configure mock to throw ConvergenceException
                                                                    when(mockOptimizer.optimize(eq(f), eq(goal), anyDouble(), anyDouble(), anyDouble()))
                                                                        .thenThrow(new ConvergenceException());
                                                                    
                                                                    // Test - original should handle this gracefully, mutant would too
                                                                    optimizer.optimize(f, goal, min, max);
                                                                    
                                                                    // No exception expected - test passes if no exception is thrown
                                                                }

    @Test
                                                                public void testOptimizePropagatesOtherRuntimeExceptions() throws Exception {
                                                                    // Setup
                                                                    @SuppressWarnings("unchecked")
                                                                    BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                    RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                    MultiStartUnivariateRealOptimizer<UnivariateRealFunction> optimizer = 
                                                                        new MultiStartUnivariateRealOptimizer<>(mockOptimizer, 1, mockGenerator);
                                                                    
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    GoalType goal = GoalType.MAXIMIZE;
                                                                    double min = 0;
                                                                    double max = 10;
                                                                    
                                                                    // Configure mock to throw a different RuntimeException
                                                                    RuntimeException testException = new IllegalArgumentException("Test exception");
                                                                    when(mockOptimizer.optimize(eq(f), eq(goal), anyDouble(), anyDouble(), anyDouble()))
                                                                        .thenThrow(testException);
                                                                    
                                                                    // Expect the exception to be thrown
                                                                    thrown.expect(IllegalArgumentException.class);
                                                                    thrown.expectMessage("Test exception");
                                                                    
                                                                    // Test - original should propagate, mutant would catch it
                                                                    optimizer.optimize(f, goal, min, max);
                                                                }

    @Test
                                                                public void testOptimizeHandlesRuntimeException() throws FunctionEvaluationException {
                                                                    // Setup
                                                                    @SuppressWarnings("unchecked")
                                                                    BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                    RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                    MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 2, mockGenerator);
                                                                    
                                                                    // Mock behavior - first optimization throws ConvergenceException (should be caught)
                                                                    // Second optimization throws NullPointerException (RuntimeException, should now be caught)
                                                                    when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
                                                                        .thenThrow(new ConvergenceException())
                                                                        .thenThrow(new NullPointerException("test"));
                                                                    
                                                                    // Mock generator to return a value for second start point
                                                                    when(mockGenerator.nextDouble()).thenReturn(0.5);
                                                                    
                                                                    // Test
                                                                    UnivariateRealPointValuePair result = optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, 0, 1, 0.5);
                                                                    
                                                                    // Verify both exceptions were caught by checking optima array
                                                                    UnivariateRealPointValuePair[] optima = optimizer.getOptima();
                                                                    assertNull(optima[0]); // First optimization failed with ConvergenceException
                                                                    assertNull(optima[1]); // Second optimization failed with NullPointerException
                                                                    
                                                                    // Verify method throws when all optimizations fail
                                                                    try {
                                                                        optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, 0, 1, 0.5);
                                                                        fail("Expected ConvergenceException");
                                                                    } catch (ConvergenceException e) {
                                                                        // Expected
                                                                    }
                                                                }

    @Test
                                                           public void testOptimizeEvaluationCountingDetectsMutant() throws FunctionEvaluationException, ConvergenceException {
                                                               // Setup
                                                               @SuppressWarnings("unchecked")
                                                               BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                               RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                               
                                                               // Configure mock behavior
                                                               when(mockOptimizer.getMaxEvaluations()).thenReturn(1000);
                                                               when(mockOptimizer.getEvaluations()).thenReturn(100); // Each optimization uses 100 evaluations
                                                               when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
                                                                   .thenReturn(new UnivariateRealPointValuePair(1.0, 1.0));
                                                               when(mockGenerator.nextDouble()).thenReturn(0.5);
                                                               
                                                               MultiStartUnivariateRealOptimizer optimizer = 
                                                                   new MultiStartUnivariateRealOptimizer(mockOptimizer, 3, mockGenerator);
                                                               
                                                               // Execute
                                                               optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, 0.0, 10.0, 5.0);
                                                               
                                                               // Verify evaluation counting behavior
                                                               // Original code would call setMaxEvaluations with 900, then 800, then 700
                                                               // Mutant would call setMaxEvaluations with 1000 each time
                                                               verify(mockOptimizer, times(3)).setMaxEvaluations(anyInt());
                                                               verify(mockOptimizer).setMaxEvaluations(1000 - 100); // After first optimization
                                                               verify(mockOptimizer).setMaxEvaluations(900 - 100);  // After second optimization
                                                               verify(mockOptimizer).setMaxEvaluations(800 - 100);  // After third optimization
                                                               
                                                               // Also verify total evaluations is correct
                                                               assertEquals(300, optimizer.getEvaluations());
                                                           }

    @Test
                                           public void testOptimizeProperlyDecrementsMaxEvaluations() {
                                               // Setup mock optimizer
                                               BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = 
                                                   mock(BaseUnivariateRealOptimizer.class);
                                               
                                               // Initial max evaluations
                                               int initialMaxEvaluations = 1000;
                                               when(mockOptimizer.getMaxEvaluations()).thenReturn(initialMaxEvaluations);
                                               
                                               // Create test instance with proper RandomGenerator
                                               org.apache.commons.math.random.RandomGenerator randomGenerator = 
                                                   new org.apache.commons.math.random.JDKRandomGenerator();
                                               MultiStartUnivariateRealOptimizer<UnivariateRealFunction> optimizer = 
                                                   new MultiStartUnivariateRealOptimizer<UnivariateRealFunction>(mockOptimizer, 5, randomGenerator);
                                               
                                               // Setup test data
                                               UnivariateRealFunction function = 
                                                   mock(UnivariateRealFunction.class);
                                               GoalType goal = GoalType.MAXIMIZE;
                                               double min = 0;
                                               double max = 10;
                                               
                                               // First optimization attempt will use some evaluations
                                               int usedEvaluations = 200;
                                               when(mockOptimizer.getEvaluations()).thenReturn(usedEvaluations);
                                               
                                               // Call the method that should update max evaluations
                                               try {
                                                   optimizer.optimize(function, goal, min, max);
                                               } catch (FunctionEvaluationException e) {
                                                   fail("Unexpected FunctionEvaluationException");
                                               }
                                               
                                               // Verify the max evaluations was properly decremented
                                               org.mockito.ArgumentCaptor<Integer> maxEvalCaptor = org.mockito.ArgumentCaptor.forClass(Integer.class);
                                               verify(mockOptimizer, atLeastOnce()).setMaxEvaluations(maxEvalCaptor.capture());
                                               
                                               // The last setMaxEvaluations call should have the remaining evaluations
                                               int lastMaxEval = maxEvalCaptor.getValue();
                                               org.junit.Assert.assertEquals("Max evaluations should be decremented by used evaluations",
                                                           initialMaxEvaluations - usedEvaluations, lastMaxEval);
                                           }

    @Test
                      public void testOptimizeMaxEvaluationsDecrement() throws Exception {
                          // Setup
                          @SuppressWarnings("unchecked")
                          org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer<org.apache.commons.math.analysis.UnivariateRealFunction> optimizer = 
                              (org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer<org.apache.commons.math.analysis.UnivariateRealFunction>) 
                              mock(org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer.class);
                          org.apache.commons.math.random.RandomGenerator generator = mock(org.apache.commons.math.random.RandomGenerator.class);
                          org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer multiStartOptimizer = 
                              new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer(optimizer, 2, generator);
                          
                          org.apache.commons.math.analysis.UnivariateRealFunction f = new org.apache.commons.math.analysis.UnivariateRealFunction() {
                              @Override
                              public double value(double x) {
                                  return 0;
                              }
                          };
                          org.apache.commons.math.optimization.GoalType goal = org.apache.commons.math.optimization.GoalType.MINIMIZE;
                          double min = 0.0;
                          double max = 10.0;
                          double startValue = 5.0;
                          
                          // Mock behavior
                          when(optimizer.getMaxEvaluations()).thenReturn(1000);
                          when(optimizer.getEvaluations()).thenReturn(100);
                          when(generator.nextDouble()).thenReturn(0.5);
                          
                          org.apache.commons.math.optimization.univariate.UnivariateRealPointValuePair result = 
                              new org.apache.commons.math.optimization.univariate.UnivariateRealPointValuePair(5.0, 10.0);
                          when(optimizer.optimize(eq(f), eq(goal), eq(min), eq(max), anyDouble()))
                              .thenReturn(result);
                          
                          // Test
                          multiStartOptimizer.optimize(f, goal, min, max, startValue);
                          
                          // Verify max evaluations was properly decremented
                          // Original should set to 1000-100=900
                          // Mutant would set to 100-1000=-900
                          verify(optimizer, times(2)).setMaxEvaluations(900);
                          
                          // Also verify total evaluations tracking
                          assertEquals(200, multiStartOptimizer.getEvaluations());
                      }

    @Test
                  public void testOptimizeSetsCorrectRemainingEvaluations() throws FunctionEvaluationException {
                      // Setup mock optimizer
                      BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                      RandomGenerator mockGenerator = mock(RandomGenerator.class);
                      
                      // Create test instance with 10 starts
                      MultiStartUnivariateRealOptimizer optimizer = 
                          new MultiStartUnivariateRealOptimizer(mockOptimizer, 10, mockGenerator);
                      
                      // Set initial max evaluations to 1000
                      when(mockOptimizer.getMaxEvaluations()).thenReturn(1000);
                      
                      // Assume 200 evaluations used in first optimization attempt
                      int usedEvaluations = 200;
                      when(mockOptimizer.getEvaluations()).thenReturn(usedEvaluations);
                      
                      // Mock the optimize method to return some value
                      UnivariateRealPointValuePair mockResult = mock(UnivariateRealPointValuePair.class);
                      when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
                          .thenReturn(mockResult);
                      
                      // Execute optimization
                      optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, 0.0, 1.0);
                      
                      // Verify setMaxEvaluations was called with correct remaining evaluations (1000-200=800)
                      verify(mockOptimizer).setMaxEvaluations(800);
                      
                      // Also verify it was never called with the mutant's calculation (200-1000=-800)
                      verify(mockOptimizer, never()).setMaxEvaluations(-800);
                  }

    @Test
             public void testOptimizeHandlesFunctionEvaluationException() throws Exception {
                 // Setup
                 @SuppressWarnings("unchecked")
                 BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                 RandomGenerator mockGenerator = mock(RandomGenerator.class);
                 MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 2, mockGenerator);
                 
                 UnivariateRealFunction mockF = mock(UnivariateRealFunction.class);
                 GoalType goal = GoalType.MAXIMIZE;
                 double min = 0;
                 double max = 10;
                 double startValue = 5;
                 
                 // Mock behavior to throw FunctionEvaluationException on first attempt
                 when(mockOptimizer.optimize(mockF, goal, min, max, startValue))
                     .thenThrow(new FunctionEvaluationException(0, "Test exception"));
                 when(mockOptimizer.optimize(mockF, goal, min, max, anyDouble()))
                     .thenReturn(new UnivariateRealPointValuePair(3.0, 10.0));
                 when(mockOptimizer.getEvaluations()).thenReturn(100);
                 
                 // Test
                 UnivariateRealPointValuePair result = optimizer.optimize(mockF, goal, min, max, startValue);
                 
                 // Verify
                 assertNotNull(result);
                 assertEquals(3.0, result.getPoint(), 0.0001);
                 assertEquals(10.0, result.getValue(), 0.0001);
                 
                 // Verify exception was handled by checking optima array contains null for failed attempt
                 UnivariateRealPointValuePair[] optima = optimizer.getOptima();
                 assertNull(optima[0]);  // First attempt failed with exception
                 assertNotNull(optima[1]); // Second attempt succeeded
             }

    @Test
         public void testOptimizeHandlesFunctionEvaluationException1() throws Exception {
             // Arrange
             @SuppressWarnings("unchecked")
             BaseUnivariateRealOptimizer<UnivariateRealFunction> baseOptimizer = 
                 mock(BaseUnivariateRealOptimizer.class);
             RandomGenerator randomGenerator = mock(RandomGenerator.class);
             when(randomGenerator.nextDouble()).thenReturn(0.5);
             MultiStartUnivariateRealOptimizer optimizer = 
                 new MultiStartUnivariateRealOptimizer(baseOptimizer, 1, randomGenerator);
             
             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
             when(function.value(anyDouble())).thenThrow(new FunctionEvaluationException(0.0));
             
             // Set up the base optimizer to propagate the exception
             when(baseOptimizer.optimize(
                 any(UnivariateRealFunction.class), 
                 any(GoalType.class), 
                 anyDouble(), 
                 anyDouble(), 
                 anyDouble()
             )).thenThrow(new FunctionEvaluationException(0.0));
          
             // Act & Assert
             try {
                 optimizer.optimize(function, GoalType.MAXIMIZE, 0.0, 1.0);
                 fail("Expected FunctionEvaluationException");
             } catch (FunctionEvaluationException e) {
                 // Verify the exception is properly propagated
                 verify(baseOptimizer).optimize(
                     same(function), 
                     eq(GoalType.MAXIMIZE), 
                     eq(0.0), 
                     eq(1.0), 
                     anyDouble()
                 );
             }
         }

    @Test
    public void testOptimizeClearsOptimaArray() throws Exception {
        // Setup test data
        @SuppressWarnings("unchecked")
        BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
        RandomGenerator mockGenerator = mock(RandomGenerator.class);
        MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 3, mockGenerator);
        
        // Get access to private optima field via reflection
        Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
        optimaField.setAccessible(true);
        
        // Initialize optima array with dummy values
        UnivariateRealPointValuePair dummyPair = new UnivariateRealPointValuePair(0.0, 0.0);
        optimaField.set(optimizer, new UnivariateRealPointValuePair[] {dummyPair, dummyPair, dummyPair});
        
        // Mock the optimize method to return a result
        UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(1.0, 1.0);
        when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
            .thenReturn(expectedResult);
        
        // Call the method under test
        UnivariateRealFunction mockFunc = mock(UnivariateRealFunction.class);
        UnivariateRealPointValuePair result = optimizer.optimize(mockFunc, GoalType.MAXIMIZE, 0.0, 1.0);
        
        // Verify optima array was properly cleared (original behavior)
        UnivariateRealPointValuePair[] optima = (UnivariateRealPointValuePair[]) optimaField.get(optimizer);
        for (UnivariateRealPointValuePair pair : optima) {
            assertNull("Optima array elements should be null after optimization", pair);
        }
        
        // Also verify the optimization result is correct
        assertEquals(expectedResult, result);
    }

    @Test
    public void testOptimizeHandlesOptimizationFailure() throws Exception {
        // Setup
        @SuppressWarnings("unchecked")
        BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
        RandomGenerator mockGenerator = mock(RandomGenerator.class);
        MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 2, mockGenerator);
        
        // Mock behavior - first optimization succeeds, second fails
        UnivariateRealPointValuePair successResult = new UnivariateRealPointValuePair(1.0, 2.0);
        when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
            .thenReturn(successResult)
            .thenThrow(new ConvergenceException());
        when(mockOptimizer.getEvaluations()).thenReturn(10);
        
        // Test
        UnivariateRealPointValuePair result = optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, 0.0, 10.0, 5.0);
        
        // Verify
        UnivariateRealPointValuePair[] optima = optimizer.getOptima();
        assertNotNull("First optimization should succeed", optima[0]);
        assertNull("Second optimization should fail and set to null", optima[1]);
        assertEquals("Should return best result", successResult, result);
        
        // Verify evaluations were properly tracked
        Field totalEvaluationsField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("totalEvaluations");
        totalEvaluationsField.setAccessible(true);
        int totalEvaluations = totalEvaluationsField.getInt(optimizer);
        assertEquals(20, totalEvaluations);
    }


}
