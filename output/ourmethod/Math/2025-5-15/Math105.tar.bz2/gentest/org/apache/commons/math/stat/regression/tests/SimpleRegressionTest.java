package gentest.org.apache.commons.math.stat.regression.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.regression.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.DistributionFactory;
import org.apache.commons.math.distribution.TDistribution;
 
public class SimpleRegressionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                 public void testGetSumSquaredErrors_PositiveValues() throws Exception {
                     // Create regression instance
                     SimpleRegression regression = new SimpleRegression();
                     
                     // Use reflection to set private fields
                     Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                     sumXXField.setAccessible(true);
                     sumXXField.set(regression, 10.0);
                     
                     Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                     sumXYField.setAccessible(true);
                     sumXYField.set(regression, 5.0);
                     
                     Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                     sumYYField.setAccessible(true);
                     sumYYField.set(regression, 3.0);
                     
                     // Expected: 3 - (5*5)/10 = 3 - 2.5 = 0.5
                     assertEquals(0.5, regression.getSumSquaredErrors(), 0.0001);
                 }

 @Test
                 public void testGetSumSquaredErrors_ZeroResult() throws Exception {
                     // Create regression instance
                     SimpleRegression regression = new SimpleRegression();
                     
                     // Use reflection to set private fields
                     Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                     sumXXField.setAccessible(true);
                     sumXXField.set(regression, 4.0);
                     
                     Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                     sumXYField.setAccessible(true);
                     sumXYField.set(regression, 4.0);
                     
                     Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                     sumYYField.setAccessible(true);
                     sumYYField.set(regression, 4.0);
                     
                     // Expected: 4 - (4*4)/4 = 0
                     assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
                 }

 @Test
                 public void testGetSumSquaredErrors_NegativeResultClampedToZero() throws Exception {
                     // Create regression instance
                     SimpleRegression regression = new SimpleRegression();
                     
                     // Use reflection to set private fields
                     Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                     sumXXField.setAccessible(true);
                     sumXXField.set(regression, 5.0);
                     
                     Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                     sumXYField.setAccessible(true);
                     sumXYField.set(regression, 5.0);
                     
                     Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                     sumYYField.setAccessible(true);
                     sumYYField.set(regression, 4.0);
                     
                     // Expected: 4 - (5*5)/5 = -1, but clamped to 0 by Math.max
                     assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
                 }

 @Test
                 public void testGetSumSquaredErrors_WithNegativeValues() throws Exception {
                     // Create regression object
                     SimpleRegression regression = new SimpleRegression();
                     
                     // Use reflection to set private fields
                     Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                     sumXXField.setAccessible(true);
                     sumXXField.set(regression, -10.0);
                     
                     Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                     sumXYField.setAccessible(true);
                     sumXYField.set(regression, -5.0);
                     
                     Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                     sumYYField.setAccessible(true);
                     sumYYField.set(regression, -3.0);
                     
                     // Expected: -3 - (25)/-10 = -3 + 2.5 = -0.5, clamped to 0
                     assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
                 }

 @Test
                 public void testGetSumSquaredErrors_LargeNumbers() throws Exception {
                     // Test with very large numbers to check numerical stability
                     SimpleRegression regression = new SimpleRegression();
                     
                     // Use reflection to set private fields
                     Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                     sumXXField.setAccessible(true);
                     sumXXField.set(regression, Double.MAX_VALUE);
                     
                     Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                     sumXYField.setAccessible(true);
                     sumXYField.set(regression, Double.MAX_VALUE / 2);
                     
                     Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                     sumYYField.setAccessible(true);
                     sumYYField.set(regression, Double.MAX_VALUE / 4);
                     
                     // Calculate expected value carefully to avoid overflow
                     double term1 = Double.MAX_VALUE / 4;
                     double term2 = (Double.MAX_VALUE / 2) * (Double.MAX_VALUE / 2) / Double.MAX_VALUE;
                     double expected = term1 - term2;
                     expected = Math.max(0, expected);
                     
                     assertEquals(expected, regression.getSumSquaredErrors(), 0.0001);
                 }

 @Test
                 public void testGetSumSquaredErrors_SmallNumbers() throws Exception {
                     // Test with very small numbers
                     SimpleRegression regression = new SimpleRegression();
                     
                     // Use reflection to set private fields
                     Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                     sumXXField.setAccessible(true);
                     sumXXField.set(regression, Double.MIN_VALUE);
                     
                     Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                     sumXYField.setAccessible(true);
                     sumXYField.set(regression, Double.MIN_VALUE);
                     
                     Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                     sumYYField.setAccessible(true);
                     sumYYField.set(regression, Double.MIN_VALUE);
                     
                     double expected = Double.MIN_VALUE - 
                                      (Double.MIN_VALUE * Double.MIN_VALUE) / Double.MIN_VALUE;
                     expected = Math.max(0, expected);
                     assertEquals(expected, regression.getSumSquaredErrors(), 0.0001);
                 }

 @Test
                 public void testGetSumSquaredErrors_ZeroDenominator() throws Exception {
                     // Create regression instance
                     SimpleRegression regression = new SimpleRegression();
                     
                     // Use reflection to set private fields
                     Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                     sumXXField.setAccessible(true);
                     sumXXField.set(regression, 0.0);
                     
                     Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                     sumXYField.setAccessible(true);
                     sumXYField.set(regression, 5.0);
                     
                     Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                     sumYYField.setAccessible(true);
                     sumYYField.set(regression, 3.0);
                     
                     // Should return max(0, Infinity) which should be Infinity
                     assertEquals(Double.POSITIVE_INFINITY, regression.getSumSquaredErrors(), 0.0001);
                 }

 @Test
                 public void testGetSlopeWithTwoDataPoints() {
                     // Setup
                     SimpleRegression regression = new SimpleRegression();
                     
                     // Add exactly 2 data points with sufficient x variation
                     regression.addData(1.0, 2.0);
                     regression.addData(2.0, 4.0);  // This creates clear slope of 2
                     
                     // Test
                     double slope = regression.getSlope();
                     
                     // Verify - original should return 2.0, mutant would return NaN
                     assertEquals(2.0, slope, 0.0001);
                     
                     // Additional verification that it's not NaN
                     assertFalse(Double.isNaN(slope));
                 }

 @Test
                public void testGetSlopeWithOneDataPoint() {
                    // Setup - create regression with exactly 1 data point
                    SimpleRegression regression = new SimpleRegression();
                    regression.addData(1.0, 2.0); // n=1
                    
                    // Test the slope calculation
                    double slope = regression.getSlope();
                    
                    // Verify - should return NaN when n=1
                    assertTrue("Slope should be NaN when n=1", Double.isNaN(slope));
                    
                    // Additional verification that n is indeed 1
                    assertEquals("Number of data points should be 1", 1, regression.getN());
                }

 @Test
               public void testGetSlope_NotEnoughData_ShouldReturnNaN() {
                   // Create regression object with insufficient data (n < 2)
                   SimpleRegression regression = new SimpleRegression();
                   
                   // Case 1: No data added (n = 0)
                   double slope = regression.getSlope();
                   assertTrue("Slope should be NaN when no data points", Double.isNaN(slope));
                   
                   // Case 2: Only one data point added (n = 1)
                   regression.addData(1.0, 2.0);
                   slope = regression.getSlope();
                   assertTrue("Slope should be NaN when only one data point", Double.isNaN(slope));
               }

 @Test
              public void testGetSlope_BoundaryCaseForSumXX() {
                  // Create test case where sumXX exactly equals 10*Double.MIN_VALUE
                  SimpleRegression regression = new SimpleRegression();
                  
                  // We need to set up the internal state to meet our test conditions
                  // Since the fields are private, we'll use reflection to set them
                  try {
                      // Set n >= 2 to pass first condition
                      java.lang.reflect.Field nField = SimpleRegression.class.getDeclaredField("n");
                      nField.setAccessible(true);
                      nField.set(regression, 2L);
                      
                      // Set sumXX to exactly 10*Double.MIN_VALUE
                      java.lang.reflect.Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                      sumXXField.setAccessible(true);
                      sumXXField.set(regression, 10 * Double.MIN_VALUE);
                      
                      // Set sumXY to some non-zero value to make slope calculable
                      java.lang.reflect.Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                      sumXYField.setAccessible(true);
                      sumXYField.set(regression, 1.0);
                      
                      // Test the behavior
                      double slope = regression.getSlope();
                      
                      // Original should return a valid slope (1.0/(10*MIN_VALUE))
                      // Mutant would return NaN
                      assertFalse("Slope should not be NaN for sumXX = 10*MIN_VALUE", 
                                  Double.isNaN(slope));
                      
                      // Additional check to verify correct calculation
                      double expectedSlope = 1.0 / (10 * Double.MIN_VALUE);
                      assertEquals(expectedSlope, slope, 0.0);
                      
                  } catch (Exception e) {
                      fail("Failed to set up test due to reflection error: " + e.getMessage());
                  }
              }

 @Test
         public void testGetSlope_WithSumXXBetween5And10MinValue_ShouldReturnNaN() {
             // Setup
             SimpleRegression regression = new SimpleRegression();
             
             // Use reflection to set private fields since there's no direct API
             try {
                 // Set n >= 2 to avoid first NaN condition
                 Field nField = SimpleRegression.class.getDeclaredField("n");
                 nField.setAccessible(true);
                 nField.setLong(regression, 2L);
                 
                 // Set sumXX to 7*Double.MIN_VALUE (between 5 and 10)
                 Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                 sumXXField.setAccessible(true);
                 sumXXField.setDouble(regression, 7 * Double.MIN_VALUE);
                 
                 // Set sumXY to any non-zero value
                 Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                 sumXYField.setAccessible(true);
                 sumXYField.setDouble(regression, 1.0);
             } catch (Exception e) {
                 fail("Failed to set up test via reflection: " + e.getMessage());
             }
             
             // Test
             double result = regression.getSlope();
             
             // Verify
             assertTrue("Should return NaN for sumXX between 5 and 10*MIN_VALUE", 
                       Double.isNaN(result));
         }

 @Test
            public void testGetSlope_WhenSumXXIsVerySmall_ShouldReturnNaN() {
                // Arrange
                SimpleRegression regression = new SimpleRegression();
                
                // Add data points with minimal variation in x
                // Using same x values (or very close) to make sumXX very small
                regression.addData(1.0, 2.0);
                regression.addData(1.0 + Double.MIN_VALUE, 3.0); // Almost identical x values
                
                // Act
                double slope = regression.getSlope();
                
                // Assert
                // The original should return NaN for nearly identical x values
                // This will catch the mutant that returns POSITIVE_INFINITY instead
                assertTrue("Slope should be NaN when x values have no variation", 
                          Double.isNaN(slope));
            }

 @Test
           public void testGetSlopeDetectsDivisionMutant() {
               // Setup test data - two points that form a clear slope
               SimpleRegression regression = new SimpleRegression();
               regression.addData(1.0, 2.0);  // point (1,2)
               regression.addData(3.0, 6.0);  // point (3,6)
               
               // Calculate expected slope manually: (sumXY)/sumXX
               // sumXY = (1*2 + 3*6) - (1+3)*(2+6)/2 = (2+18) - (4*8)/2 = 20 - 16 = 4
               // sumXX = (1² + 3²) - (1+3)²/2 = (1+9) - 16/2 = 10 - 8 = 2
               // Expected slope = 4/2 = 2.0
               
               double expectedSlope = 2.0;
               double actualSlope = regression.getSlope();
               
               // This will fail if the mutant (multiplication) is present
               // because actualSlope would be 4*2=8 instead of 4/2=2
               assertEquals("Slope calculation should use division, not multiplication", 
                           expectedSlope, actualSlope, 0.0001);
           }

 @Test
     public void testGetSlope_DetectsMutant() throws Exception {
         // Setup test data where sumXX is small but valid
         SimpleRegression regression = new SimpleRegression();
         
         // Add data points that will create small but non-zero sumXX
         // Using points (0,0) and (1,1) would make sumXX = 0.5, sumXY = 0.5
         // But we need even smaller sumXX to make the mutant noticeable
         double tinyValue = 20 * Double.MIN_VALUE; // Just above the threshold
         regression.addData(0, 0);
         regression.addData(tinyValue, tinyValue);
         
         // Calculate expected and actual values
         double expectedSlope = 1.0; // Since y = x in our test data
         double actualSlope = regression.getSlope();
         
         // Verify the slope is exactly as expected (not affected by +1 mutation)
         assertEquals("Slope should be exactly 1.0 for y=x relationship", 
                     expectedSlope, actualSlope, 0.0);
         
         // Additional verification that sumXX is small but valid using reflection
         Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
         sumXXField.setAccessible(true);
         double sumXXValue = sumXXField.getDouble(regression);
         assertTrue("sumXX should be just above threshold", 
                   Math.abs(sumXXValue) >= 10 * Double.MIN_VALUE);
     }

 @Test
 public void testGetSlopeWithNegativeSumXX() {
     SimpleRegression regression = new SimpleRegression();
     
     // Add data points that will make sumXX negative
     // Using points where x decreases while y increases
     regression.addData(new double[][] {
         {2, 1},
         {1, 2},
         {0, 3}
     });
     
     // Verify sumXX is negative (calculation: (2² + 1² + 0²) - (2+1+0)²/3 = 5 - 3 = 2)
     // Wait, my initial thought was wrong - sumXX is actually sum(xi²) - (sum(xi))²/n
     // For these points: sumXX = (4+1+0) - (3)²/3 = 5 - 3 = 2 (positive)
     // Need different data
     
     // Let's try points where x values are negative
     regression.clear();
     regression.addData(new double[][] {
         {-2, 1},
         {-1, 2},
         {0, 3}
     });
     // sumXX = (4+1+0) - (-3)²/3 = 5 - 3 = 2 (still positive)
     
     // Need to make sumXX negative - let's try this:
     regression.clear();
     regression.addData(new double[][] {
         {-1, 1},
         {0, 2},
         {1, 3}
     });
     // sumXX = (1+0+1) - (0)²/3 = 2 (positive again)
     
     // Alternative approach - use only two points where x values are negative
     regression.clear();
     regression.addData(new double[][] {
         {-2, 1},
         {-1, 2}
     });
     // sumXX = (4+1) - (-3)²/2 = 5 - 4.5 = 0.5 (still positive)
     
     // Realization: sumXX can't be negative for real data points because it's essentially variance
     // which is always non-negative. Therefore, the mutation is actually equivalent to the original
     // for all valid inputs, which explains why it wasn't caught.
     
     // However, if we force sumXX to be negative through direct field manipulation (since it's private):
     try {
         Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
         sumXXField.setAccessible(true);
         
         // Create regression object
         SimpleRegression reg = new SimpleRegression();
         // Add minimum required data points (n >= 2)
         reg.addData(1, 1);
         reg.addData(2, 2);
         
         // Force sumXX to be negative
         sumXXField.set(reg, -5.0);
         
         // sumXY is positive (1*1 + 2*2 = 5)
         Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
         sumXYField.setAccessible(true);
         sumXYField.set(reg, 5.0);
         
         // Original would return 5/-5 = -1
         // Mutant would return 5/5 = 1
         double slope = reg.getSlope();
         assertTrue("Slope should be negative for negative sumXX", slope < 0);
     } catch (Exception e) {
         fail("Reflection failed: " + e.getMessage());
     }
 }

}
