package gentest.org.apache.commons.math.stat.descriptive.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.descriptive.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.moment.GeometricMean;
import org.apache.commons.math.stat.descriptive.moment.Mean;
import org.apache.commons.math.stat.descriptive.moment.SecondMoment;
import org.apache.commons.math.stat.descriptive.moment.Variance;
import org.apache.commons.math.stat.descriptive.rank.Max;
import org.apache.commons.math.stat.descriptive.rank.Min;
import org.apache.commons.math.stat.descriptive.summary.Sum;
import org.apache.commons.math.stat.descriptive.summary.SumOfLogs;
import org.apache.commons.math.stat.descriptive.summary.SumOfSquares;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.Precision;
import org.apache.commons.math.util.FastMath;
 
public class SummaryStatisticsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
         public void testAddValue_UpdatesAllStatistics() {
             // Test that adding a value updates all relevant statistics
             SummaryStatistics stats = new SummaryStatistics();
             double value = 5.0;
             
             // Get initial values
             long initialN = stats.getN();
             double initialSum = stats.getSum();
             double initialSumsq = stats.getSumsq();
             double initialSumLog = stats.getSumOfLogs();
             
             // Add value
             stats.addValue(value);
             
             // Verify updates
             assertEquals(initialN + 1, stats.getN());
             assertEquals(initialSum + value, stats.getSum(), 0.0001);
             assertEquals(initialSumsq + (value * value), stats.getSumsq(), 0.0001);
             assertEquals(initialSumLog + Math.log(value), stats.getSumOfLogs(), 0.0001);
             
             // For min/max, we need to test different scenarios
         }

 @Test
         public void testAddValue_FirstValueSetsMinAndMax() {
             // First value should set both min and max
             SummaryStatistics stats = new SummaryStatistics();
             double value = 3.5;
             stats.addValue(value);
             
             assertEquals(value, stats.getMin(), 0.0001);
             assertEquals(value, stats.getMax(), 0.0001);
         }

 @Test
         public void testAddValue_UpdatesMinWhenSmaller() {
             SummaryStatistics stats = new SummaryStatistics();
             stats.addValue(5.0);
             stats.addValue(3.0);
             
             assertEquals(3.0, stats.getMin(), 0.0001);
             assertEquals(5.0, stats.getMax(), 0.0001);
         }

 @Test
         public void testAddValue_UpdatesMaxWhenLarger() {
             SummaryStatistics stats = new SummaryStatistics();
             stats.addValue(5.0);
             stats.addValue(7.0);
             
             assertEquals(5.0, stats.getMin(), 0.0001);
             assertEquals(7.0, stats.getMax(), 0.0001);
         }

 @Test
         public void testAddValue_WithCustomImplementations() {
             // Test with overridden implementations
             SummaryStatistics stats = new SummaryStatistics();
             StorelessUnivariateStatistic customMean = mock(StorelessUnivariateStatistic.class);
             StorelessUnivariateStatistic customVariance = mock(StorelessUnivariateStatistic.class);
             StorelessUnivariateStatistic customGeoMean = mock(StorelessUnivariateStatistic.class);
             
             stats.setMeanImpl(customMean);
             stats.setVarianceImpl(customVariance);
             stats.setGeoMeanImpl(customGeoMean);
             
             double value = 2.5;
             stats.addValue(value);
             
             verify(customMean).increment(value);
             verify(customVariance).increment(value);
             verify(customGeoMean).increment(value);
         }

 @Test
         public void testAddValue_WithNaN() {
             // Create new SummaryStatistics object
             SummaryStatistics stats = new SummaryStatistics();
             
             // Adding NaN should be handled properly
             stats.addValue(Double.NaN);
             
             // Verify that count is incremented but other stats might be NaN
             assertEquals(1, stats.getN());
             assertTrue(Double.isNaN(stats.getSum()));
             assertTrue(Double.isNaN(stats.getSumsq()));
             assertTrue(Double.isNaN(stats.getSumOfLogs()));
         }

 @Test
         public void testAddValue_WithPositiveInfinity() {
             SummaryStatistics stats = new SummaryStatistics();
             stats.addValue(Double.POSITIVE_INFINITY);
             
             assertEquals(1, stats.getN());
             assertEquals(Double.POSITIVE_INFINITY, stats.getSum(), 0.0001);
             assertEquals(Double.POSITIVE_INFINITY, stats.getSumsq(), 0.0001);
             assertEquals(Double.POSITIVE_INFINITY, stats.getMax(), 0.0001);
         }

 @Test
         public void testAddValue_WithNegativeInfinity() {
             SummaryStatistics stats = new SummaryStatistics();
             stats.addValue(Double.NEGATIVE_INFINITY);
             
             assertEquals(1, stats.getN());
             assertEquals(Double.NEGATIVE_INFINITY, stats.getSum(), 0.0001);
             assertEquals(Double.POSITIVE_INFINITY, stats.getSumsq(), 0.0001);
             assertEquals(Double.NEGATIVE_INFINITY, stats.getMin(), 0.0001);
         }

 @Test
         public void testAddValue_WithZero() {
             SummaryStatistics stats = new SummaryStatistics();
             stats.addValue(0.0);
             
             assertEquals(1, stats.getN());
             assertEquals(0.0, stats.getSum(), 0.0001);
             assertEquals(0.0, stats.getSumsq(), 0.0001);
             assertEquals(Double.NEGATIVE_INFINITY, stats.getSumOfLogs(), 0.0001);
         }

 @Test
         public void testAddValue_MultipleValues() {
             SummaryStatistics stats = new SummaryStatistics();
             double[] values = {1.5, 2.5, 3.5, 4.5};
             double expectedSum = 0;
             double expectedSumsq = 0;
             double expectedSumLog = 0;
             
             for (double value : values) {
                 stats.addValue(value);
                 expectedSum += value;
                 expectedSumsq += value * value;
                 expectedSumLog += Math.log(value);
             }
             
             assertEquals(values.length, stats.getN());
             assertEquals(expectedSum, stats.getSum(), 0.0001);
             assertEquals(expectedSumsq, stats.getSumsq(), 0.0001);
             assertEquals(expectedSumLog, stats.getSumOfLogs(), 0.0001);
             assertEquals(1.5, stats.getMin(), 0.0001);
             assertEquals(4.5, stats.getMax(), 0.0001);
         }

 @Test
         public void testAddValue_AfterClear() {
             SummaryStatistics stats = new SummaryStatistics();
             stats.addValue(1.0);
             stats.addValue(2.0);
             stats.clear();
             
             stats.addValue(3.0);
             
             assertEquals(1, stats.getN());
             assertEquals(3.0, stats.getSum(), 0.0001);
             assertEquals(9.0, stats.getSumsq(), 0.0001);
             assertEquals(3.0, stats.getMin(), 0.0001);
             assertEquals(3.0, stats.getMax(), 0.0001);
         }

 @Test
         public void testAddValueDetectsSumSqMutant() {
             // Setup
             SummaryStatistics stats = new SummaryStatistics();
             
             // Add positive value
             double value1 = 5.0;
             stats.addValue(value1);
             
             // Verify sum of squares
             double expectedSumSq1 = value1 * value1;
             assertEquals("Sum of squares should be value squared for positive input", 
                         expectedSumSq1, stats.getSumsq(), 0.0001);
             
             // Add negative value
             double value2 = -3.0;
             stats.addValue(value2);
             
             // Verify sum of squares (should add square of original value, not -value)
             double expectedSumSq2 = expectedSumSq1 + (value2 * value2);
             assertEquals("Sum of squares should be value squared for negative input", 
                         expectedSumSq2, stats.getSumsq(), 0.0001);
             
             // Add zero
             double value3 = 0.0;
             stats.addValue(value3);
             
             // Verify sum of squares remains same (0 doesn't affect sum of squares)
             assertEquals("Sum of squares should remain same when adding zero", 
                         expectedSumSq2, stats.getSumsq(), 0.0001);
         }

 @Test
    public void testAddValueDetectsSecondMomentMutant() {
        // Setup
        SummaryStatistics stats = new SummaryStatistics();
        
        // Add non-zero values that would produce a non-zero second moment
        stats.addValue(2.0);
        stats.addValue(4.0);
        
        // Calculate expected second moment manually
        // For two values x1 and x2, second moment = [(x1-mean)^2 + (x2-mean)^2]
        double mean = (2.0 + 4.0) / 2;
        double expectedSecondMoment = Math.pow(2.0 - mean, 2) + Math.pow(4.0 - mean, 2);
        
        // Verify second moment is calculated correctly
        // This will fail if the mutant (incrementing 0 instead of value) is present
        assertEquals("Second moment should be calculated with actual values", 
                    expectedSecondMoment, 
                    stats.getSecondMoment(), 
                    0.0001);
        
        // Additional verification that n was incremented
        assertEquals("Count should be 2 after adding two values", 
                    2, 
                    stats.getN());
    }

 @Test
   public void testAddValueSecondMomentCalculation() {
       // Setup
       SummaryStatistics stats = new SummaryStatistics();
       
       // Add test values - using simple values that make verification easy
       stats.addValue(2.0);
       stats.addValue(4.0);
       
       // Calculate expected second moment manually
       // Mean of 2 and 4 is 3
       // Second moment should be sum of squared deviations from mean:
       // (2-3)^2 + (4-3)^2 = 1 + 1 = 2
       
       // Get actual second moment
       double actualSecondMoment = stats.getSecondMoment();
       
       // Verify
       assertEquals("Second moment calculation is incorrect", 
                    2.0, actualSecondMoment, 0.0001);
       
       // Additional verification that other stats are correct
       assertEquals(2, stats.getN());
       assertEquals(6.0, stats.getSum(), 0.0001);
       assertEquals(20.0, stats.getSumsq(), 0.0001); // 2^2 + 4^2
   }

 @Test
  public void testAddValueDoesNotIncrementMeanImplWhenSameAsMean() {
      // Setup
      SummaryStatistics stats = new SummaryStatistics();
      double testValue = 5.0;
      
      // Get initial counts (we'll need to mock or spy on the implementations)
      StorelessUnivariateStatistic meanImpl = mock(StorelessUnivariateStatistic.class);
      StorelessUnivariateStatistic mean = mock(StorelessUnivariateStatistic.class);
      
      // Set them to be the same implementation
      when(meanImpl.toString()).thenReturn("SameImplementation");
      when(mean.toString()).thenReturn("SameImplementation");
      
      // Use reflection to set the private fields since there are no setters
      try {
          Field meanImplField = SummaryStatistics.class.getDeclaredField("meanImpl");
          meanImplField.setAccessible(true);
          meanImplField.set(stats, meanImpl);
          
          Field meanField = SummaryStatistics.class.getDeclaredField("mean");
          meanField.setAccessible(true);
          meanField.set(stats, mean);
      } catch (Exception e) {
          fail("Failed to set up test via reflection: " + e.getMessage());
      }
      
      // Action
      stats.addValue(testValue);
      
      // Verification
      // The original code shouldn't call increment when implementations are same
      // The mutant would call it anyway
      verify(meanImpl, never()).increment(testValue);
      
      // Also verify other required increments were called
      verify(stats.getSumImpl()).increment(testValue);
      verify(stats.getSumsqImpl()).increment(testValue);
      verify(stats.getMinImpl()).increment(testValue);
      verify(stats.getMaxImpl()).increment(testValue);
  }

 @Test
 public void testAddValueDetectsGeoMeanImplMutation() {
     // Setup
     SummaryStatistics stats = new SummaryStatistics();
     
     // Create a mock geoMeanImpl that's different from geoMean
     StorelessUnivariateStatistic mockGeoMeanImpl = mock(StorelessUnivariateStatistic.class);
     stats.setGeoMeanImpl(mockGeoMeanImpl);
     
     // Ensure meanImpl equals mean to prevent false positives
     StorelessUnivariateStatistic sameMeanImpl = stats.getMeanImpl();
     stats.setMeanImpl(sameMeanImpl);
     
     // Add test value
     double testValue = 5.0;
     stats.addValue(testValue);
     
     // Verify geoMeanImpl was incremented (would fail with mutation)
     verify(mockGeoMeanImpl).increment(testValue);
     
     // Additional verification that meanImpl wasn't incorrectly checked
     verify(mockGeoMeanImpl, times(1)).increment(anyDouble());
 }

}
