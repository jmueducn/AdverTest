package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
 
public class FastMathTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
          public void testMax_Int_TypicalValues() {
              // Test with typical positive values
              assertEquals(5, FastMath.max(3, 5));
              assertEquals(5, FastMath.max(5, 3));
              
              // Test with typical negative values
              assertEquals(-1, FastMath.max(-3, -1));
              assertEquals(-1, FastMath.max(-1, -3));
              
              // Test with mixed positive and negative
              assertEquals(2, FastMath.max(-5, 2));
              assertEquals(2, FastMath.max(2, -5));
          }

 @Test
          public void testMax_Int_EdgeCases() {
              // Test with zero values
              assertEquals(0, FastMath.max(0, 0));
              assertEquals(0, FastMath.max(-1, 0));
              assertEquals(0, FastMath.max(0, -1));
              assertEquals(1, FastMath.max(0, 1));
              assertEquals(1, FastMath.max(1, 0));
              
              // Test with Integer.MAX_VALUE and Integer.MIN_VALUE
              assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, 0));
              assertEquals(Integer.MAX_VALUE, FastMath.max(0, Integer.MAX_VALUE));
              assertEquals(0, FastMath.max(Integer.MIN_VALUE, 0));
              assertEquals(0, FastMath.max(0, Integer.MIN_VALUE));
              assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MIN_VALUE, Integer.MAX_VALUE));
              assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, Integer.MIN_VALUE));
          }

 @Test
          public void testMax_Int_EqualValues() {
              // Test with equal values
              assertEquals(5, FastMath.max(5, 5));
              assertEquals(-3, FastMath.max(-3, -3));
              assertEquals(0, FastMath.max(0, 0));
          }

 @Test
          public void testMax_Long_TypicalValues() {
              // Test with typical positive values
              assertEquals(5000000000L, FastMath.max(3000000000L, 5000000000L));
              assertEquals(5000000000L, FastMath.max(5000000000L, 3000000000L));
              
              // Test with typical negative values
              assertEquals(-1000000000L, FastMath.max(-3000000000L, -1000000000L));
              assertEquals(-1000000000L, FastMath.max(-1000000000L, -3000000000L));
          }

 @Test
          public void testMax_Long_EdgeCases() {
              // Test with Long.MAX_VALUE and Long.MIN_VALUE
              assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, 0L));
              assertEquals(Long.MAX_VALUE, FastMath.max(0L, Long.MAX_VALUE));
              assertEquals(0L, FastMath.max(Long.MIN_VALUE, 0L));
              assertEquals(0L, FastMath.max(0L, Long.MIN_VALUE));
              assertEquals(Long.MAX_VALUE, FastMath.max(Long.MIN_VALUE, Long.MAX_VALUE));
              assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, Long.MIN_VALUE));
          }

 @Test
          public void testMax_Float_TypicalValues() {
              // Test with typical positive values
              assertEquals(5.5f, FastMath.max(3.2f, 5.5f), 0.0001f);
              assertEquals(5.5f, FastMath.max(5.5f, 3.2f), 0.0001f);
              
              // Test with typical negative values
              assertEquals(-1.1f, FastMath.max(-3.3f, -1.1f), 0.0001f);
              assertEquals(-1.1f, FastMath.max(-1.1f, -3.3f), 0.0001f);
              
              // Test with special float values
              assertEquals(Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, Float.MAX_VALUE), 0.0f);
              assertEquals(Float.MAX_VALUE, FastMath.max(Float.NEGATIVE_INFINITY, Float.MAX_VALUE), 0.0f);
              assertEquals(Float.NaN, FastMath.max(Float.NaN, 1.0f), 0.0f);
              assertEquals(Float.NaN, FastMath.max(1.0f, Float.NaN), 0.0f);
          }

 @Test
          public void testMax_Double_TypicalValues() {
              // Test with typical positive values
              assertEquals(5.55555, FastMath.max(3.22222, 5.55555), 0.00001);
              assertEquals(5.55555, FastMath.max(5.55555, 3.22222), 0.00001);
              
              // Test with typical negative values
              assertEquals(-1.11111, FastMath.max(-3.33333, -1.11111), 0.00001);
              assertEquals(-1.11111, FastMath.max(-1.11111, -3.33333), 0.00001);
              
              // Test with special double values
              assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, Double.MAX_VALUE), 0.0);
              assertEquals(Double.MAX_VALUE, FastMath.max(Double.NEGATIVE_INFINITY, Double.MAX_VALUE), 0.0);
              assertEquals(Double.NaN, FastMath.max(Double.NaN, 1.0), 0.0);
              assertEquals(Double.NaN, FastMath.max(1.0, Double.NaN), 0.0);
          }

 @Test
          public void testMax_Double_EdgeCases() {
              // Test with very small and very large numbers
              assertEquals(Double.MIN_VALUE, FastMath.max(0.0, Double.MIN_VALUE), 0.0);
              assertEquals(Double.MAX_VALUE, FastMath.max(Double.MAX_VALUE, Double.MIN_VALUE), 0.0);
              
              // Test with positive and negative zero
              assertEquals(0.0, FastMath.max(0.0, -0.0), 0.0);
              assertEquals(0.0, FastMath.max(-0.0, 0.0), 0.0);
          }

 @Test
          public void testMax_Int_TypicalValues1() {
              // Test with typical positive values
              assertEquals(5, FastMath.max(3, 5));
              assertEquals(5, FastMath.max(5, 3));
              
              // Test with negative values
              assertEquals(-3, FastMath.max(-5, -3));
              assertEquals(-3, FastMath.max(-3, -5));
              
              // Test with zero
              assertEquals(0, FastMath.max(0, -1));
              assertEquals(1, FastMath.max(0, 1));
          }

 @Test
          public void testMax_Int_EqualValues1() {
              // Test with equal values
              assertEquals(5, FastMath.max(5, 5));
              assertEquals(0, FastMath.max(0, 0));
              assertEquals(-3, FastMath.max(-3, -3));
          }

 @Test
          public void testMax_Int_EdgeCases1() {
              // Test with Integer.MAX_VALUE and Integer.MIN_VALUE
              assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, 0));
              assertEquals(Integer.MAX_VALUE, FastMath.max(0, Integer.MAX_VALUE));
              assertEquals(0, FastMath.max(Integer.MIN_VALUE, 0));
              assertEquals(0, FastMath.max(0, Integer.MIN_VALUE));
              
              // Test with both being max/min values
              assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, Integer.MAX_VALUE));
              assertEquals(Integer.MIN_VALUE, FastMath.max(Integer.MIN_VALUE, Integer.MIN_VALUE));
              assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MIN_VALUE, Integer.MAX_VALUE));
          }

 @Test
          public void testMax_Long_TypicalValues1() {
              // Test with typical positive values
              assertEquals(5000000000L, FastMath.max(3000000000L, 5000000000L));
              assertEquals(5000000000L, FastMath.max(5000000000L, 3000000000L));
              
              // Test with negative values
              assertEquals(-3000000000L, FastMath.max(-5000000000L, -3000000000L));
              assertEquals(-3000000000L, FastMath.max(-3000000000L, -5000000000L));
          }

 @Test
          public void testMax_Long_EdgeCases1() {
              // Test with Long.MAX_VALUE and Long.MIN_VALUE
              assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, 0L));
              assertEquals(Long.MAX_VALUE, FastMath.max(0L, Long.MAX_VALUE));
              assertEquals(0L, FastMath.max(Long.MIN_VALUE, 0L));
              assertEquals(0L, FastMath.max(0L, Long.MIN_VALUE));
              
              // Test with both being max/min values
              assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, Long.MAX_VALUE));
              assertEquals(Long.MIN_VALUE, FastMath.max(Long.MIN_VALUE, Long.MIN_VALUE));
              assertEquals(Long.MAX_VALUE, FastMath.max(Long.MIN_VALUE, Long.MAX_VALUE));
          }

 @Test
          public void testMax_Float_TypicalValues1() {
              // Test with typical positive values
              assertEquals(5.5f, FastMath.max(3.2f, 5.5f), 0.0f);
              assertEquals(5.5f, FastMath.max(5.5f, 3.2f), 0.0f);
              
              // Test with negative values
              assertEquals(-3.2f, FastMath.max(-5.5f, -3.2f), 0.0f);
              assertEquals(-3.2f, FastMath.max(-3.2f, -5.5f), 0.0f);
              
              // Test with special float values
              assertEquals(Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, Float.MAX_VALUE), 0.0f);
              assertEquals(Float.MAX_VALUE, FastMath.max(Float.NEGATIVE_INFINITY, Float.MAX_VALUE), 0.0f);
          }

 @Test
          public void testMax_Float_NaNHandling() {
              // Test with NaN - should return the other value when one is NaN
              assertEquals(5.5f, FastMath.max(Float.NaN, 5.5f), 0.0f);
              assertEquals(5.5f, FastMath.max(5.5f, Float.NaN), 0.0f);
              
              // Test with both NaN - should return NaN
              assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
          }

 @Test
          public void testMax_Double_TypicalValues1() {
              // Test with typical positive values
              assertEquals(5.555555555, FastMath.max(3.222222222, 5.555555555), 0.0);
              assertEquals(5.555555555, FastMath.max(5.555555555, 3.222222222), 0.0);
              
              // Test with negative values
              assertEquals(-3.222222222, FastMath.max(-5.555555555, -3.222222222), 0.0);
              assertEquals(-3.222222222, FastMath.max(-3.222222222, -5.555555555), 0.0);
              
              // Test with special double values
              assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, Double.MAX_VALUE), 0.0);
              assertEquals(Double.MAX_VALUE, FastMath.max(Double.NEGATIVE_INFINITY, Double.MAX_VALUE), 0.0);
          }

 @Test
          public void testMax_Double_NaNHandling() {
              // Test with NaN - should return the other value when one is NaN
              assertEquals(5.555555555, FastMath.max(Double.NaN, 5.555555555), 0.0);
              assertEquals(5.555555555, FastMath.max(5.555555555, Double.NaN), 0.0);
              
              // Test with both NaN - should return NaN
              assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
          }

 @Test
          public void testMax_TypicalValues() {
              // Test typical cases where a < b and a > b
              assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
              assertEquals(5.0f, FastMath.max(5.0f, 3.0f), 0.0f);
              assertEquals(-3.0f, FastMath.max(-3.0f, -5.0f), 0.0f);
              assertEquals(-3.0f, FastMath.max(-5.0f, -3.0f), 0.0f);
          }

 @Test
          public void testMax_EqualValues() {
              // Test when both values are equal
              assertEquals(7.0f, FastMath.max(7.0f, 7.0f), 0.0f);
              assertEquals(0.0f, FastMath.max(0.0f, 0.0f), 0.0f);
              assertEquals(-1.0f, FastMath.max(-1.0f, -1.0f), 0.0f);
          }

 @Test
          public void testMax_WithNaN() {
              // Test cases involving NaN
              assertTrue(Float.isNaN(FastMath.max(Float.NaN, 5.0f)));
              assertTrue(Float.isNaN(FastMath.max(5.0f, Float.NaN)));
              assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
          }

 @Test
          public void testMax_InfinityCases() {
              // Test with positive and negative infinity
              assertEquals(Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, 1000.0f), 0.0f);
              assertEquals(Float.POSITIVE_INFINITY, FastMath.max(1000.0f, Float.POSITIVE_INFINITY), 0.0f);
              assertEquals(1000.0f, FastMath.max(Float.NEGATIVE_INFINITY, 1000.0f), 0.0f);
              assertEquals(1000.0f, FastMath.max(1000.0f, Float.NEGATIVE_INFINITY), 0.0f);
              assertEquals(Float.POSITIVE_INFINITY, 
                           FastMath.max(Float.NEGATIVE_INFINITY, Float.POSITIVE_INFINITY), 0.0f);
              assertEquals(Float.POSITIVE_INFINITY, 
                           FastMath.max(Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY), 0.0f);
          }

 @Test
          public void testMax_EdgeCases() {
              // Test edge cases around zero and float boundaries
              assertEquals(Float.MIN_VALUE, FastMath.max(0.0f, Float.MIN_VALUE), 0.0f);
              assertEquals(Float.MIN_VALUE, FastMath.max(Float.MIN_VALUE, 0.0f), 0.0f);
              assertEquals(Float.MAX_VALUE, FastMath.max(Float.MAX_VALUE, 0.0f), 0.0f);
              assertEquals(Float.MAX_VALUE, FastMath.max(0.0f, Float.MAX_VALUE), 0.0f);
              assertEquals(-Float.MIN_VALUE, FastMath.max(-Float.MIN_VALUE, -1.0f), 0.0f);
          }

 @Test
          public void testMax_SpecialFloatValues() {
              // Test with special float values
              assertEquals(1.0f, FastMath.max(1.0f, Float.MIN_NORMAL), 0.0f);
              assertEquals(Float.MIN_NORMAL, FastMath.max(Float.MIN_NORMAL, 0.0f), 0.0f);
              assertEquals(0.0f, FastMath.max(-0.0f, 0.0f), 0.0f);
              assertEquals(0.0f, FastMath.max(0.0f, -0.0f), 0.0f);
          }

 @Test
          public void testMax_FirstArgumentGreater() {
              assertEquals(5.0, FastMath.max(5.0, 3.0), 0.0);
              assertEquals(0.0, FastMath.max(0.0, -1.0), 0.0);
              assertEquals(-1.0, FastMath.max(-1.0, -2.0), 0.0);
              assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, Double.MAX_VALUE), 0.0);
          }

 @Test
          public void testMax_SecondArgumentGreater() {
              assertEquals(5.0, FastMath.max(3.0, 5.0), 0.0);
              assertEquals(0.0, FastMath.max(-1.0, 0.0), 0.0);
              assertEquals(-1.0, FastMath.max(-2.0, -1.0), 0.0);
              assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.MAX_VALUE, Double.POSITIVE_INFINITY), 0.0);
          }

 @Test
          public void testMax_EqualValues1() {
              assertEquals(5.0, FastMath.max(5.0, 5.0), 0.0);
              assertEquals(0.0, FastMath.max(0.0, 0.0), 0.0);
              assertEquals(-1.0, FastMath.max(-1.0, -1.0), 0.0);
              assertEquals(Double.MAX_VALUE, FastMath.max(Double.MAX_VALUE, Double.MAX_VALUE), 0.0);
          }

 @Test
          public void testMax_NaNHandling() {
              assertTrue(Double.isNaN(FastMath.max(Double.NaN, 5.0)));
              assertTrue(Double.isNaN(FastMath.max(5.0, Double.NaN)));
              assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
              assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.POSITIVE_INFINITY)));
              assertTrue(Double.isNaN(FastMath.max(Double.NEGATIVE_INFINITY, Double.NaN)));
          }

 @Test
          public void testMax_InfinityCases1() {
              assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, Double.MAX_VALUE), 0.0);
              assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.MAX_VALUE, Double.POSITIVE_INFINITY), 0.0);
              assertEquals(0.0, FastMath.max(Double.NEGATIVE_INFINITY, 0.0), 0.0);
              assertEquals(0.0, FastMath.max(0.0, Double.NEGATIVE_INFINITY), 0.0);
              assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY), 0.0);
          }

 @Test
          public void testMax_SpecialDoubleValues() {
              assertEquals(Double.MIN_VALUE, FastMath.max(Double.MIN_VALUE, 0.0), 0.0);
              assertEquals(Double.MAX_VALUE, FastMath.max(Double.MAX_VALUE, 0.0), 0.0);
              assertEquals(0.0, FastMath.max(-0.0, 0.0), 0.0);
              assertEquals(0.0, FastMath.max(0.0, -0.0), 0.0);
          }

 @Test
  public void testMaxWithEqualValues() {
      // Test case that will catch the mutant
      double equalValue1 = 5.0;
      double equalValue2 = 5.0;
      
      // With original implementation (a <= b), should return second value (b)
      double expected = equalValue2;
      double actual = FastMath.max(equalValue1, equalValue2);
      
      assertEquals("When values are equal, max should return the second value", 
                  expected, actual, 0.0001);
      
      // Additional test cases for completeness
      // Test a < b
      double smaller = 3.0;
      double larger = 7.0;
      assertEquals(larger, FastMath.max(smaller, larger), 0.0001);
      
      // Test a > b
      assertEquals(larger, FastMath.max(larger, smaller), 0.0001);
      
      // Test with negative equal values
      double negativeEqual1 = -2.5;
      double negativeEqual2 = -2.5;
      assertEquals(negativeEqual2, FastMath.max(negativeEqual1, negativeEqual2), 0.0001);
  }

 @Test
      public void testMaxWhenValuesAreEqual() {
          // Test case where a equals b to catch the <= vs < mutation
          double value = 5.0;
          double result = FastMath.max(value, value);
          
          // The original implementation would return the second argument (b)
          // when a equals b due to the <= condition
          assertEquals("When values are equal, should return second argument", 
                      value, result, 0.0);
          
          // Additional assertion to ensure it's exactly the same value
          assertSame(Double.doubleToLongBits(value), 
                    Double.doubleToLongBits(result));
      }

 @Test
      public void testMaxFloatWithEqualValues() {
          // Test case to catch the a <= b -> a < b mutant
          float a = 5.0f;
          float b = 5.0f;
          
          // Original should return b when equal, mutant would return a
          assertEquals(b, FastMath.max(a, b), 0.0f);
      }

 @Test
      public void testMaxFloatWithDifferentValues() {
          // Regular cases to ensure basic functionality works
          assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
          assertEquals(5.0f, FastMath.max(5.0f, 3.0f), 0.0f);
      }

 @Test
      public void testMaxFloatWithNaN() {
          // Test NaN handling
          float nan = Float.NaN;
          float normal = 5.0f;
          
          assertTrue(Float.isNaN(FastMath.max(nan, normal)));
          assertTrue(Float.isNaN(FastMath.max(normal, nan)));
          assertTrue(Float.isNaN(FastMath.max(nan, nan)));
      }

 @Test
      public void testMaxFloatWithInfinity() {
          // Test infinity cases
          float posInf = Float.POSITIVE_INFINITY;
          float negInf = Float.NEGATIVE_INFINITY;
          float normal = 5.0f;
          
          assertEquals(posInf, FastMath.max(posInf, normal), 0.0f);
          assertEquals(posInf, FastMath.max(normal, posInf), 0.0f);
          assertEquals(normal, FastMath.max(negInf, normal), 0.0f);
      }

 @Test
      public void testMaxDouble() {
          // Test case where a equals b - this will catch the mutant
          double equal1 = 5.0;
          double equal2 = 5.0;
          assertEquals("Equal values should return b", equal2, FastMath.max(equal1, equal2), 0.0);
          
          // Test case where a < b
          double smaller = 3.0;
          double larger = 7.0;
          assertEquals("When a < b should return b", larger, FastMath.max(smaller, larger), 0.0);
          
          // Test case where a > b
          assertEquals("When a > b should return a", larger, FastMath.max(larger, smaller), 0.0);
          
          // Test case with NaN
          double nan = Double.NaN;
          double normal = 10.0;
          assertTrue("When a is NaN should return NaN", Double.isNaN(FastMath.max(nan, normal)));
          assertTrue("When b is NaN should return NaN", Double.isNaN(FastMath.max(normal, nan)));
          assertTrue("When both are NaN should return NaN", Double.isNaN(FastMath.max(nan, nan)));
      }

 @Test
 public void testMaxFloat() {
     // Test case where a equals b - this will detect the mutant
     float equal1 = 5.0f;
     float equal2 = 5.0f;
     assertEquals("Equal values should return second parameter", 
                 equal2, 
                 FastMath.max(equal1, equal2), 
                 0.0f);
     
     // Additional test cases for completeness
     float a = 3.0f;
     float b = 4.0f;
     assertEquals("When b is larger, should return b", 
                 b, 
                 FastMath.max(a, b), 
                 0.0f);
     
     float c = 6.0f;
     float d = 5.0f;
     assertEquals("When a is larger, should return a", 
                 c, 
                 FastMath.max(c, d), 
                 0.0f);
     
     // Test with NaN values
     float nan = Float.NaN;
     float normal = 1.0f;
     assertTrue("NaN with normal number should return NaN", 
                Float.isNaN(FastMath.max(nan, normal)));
     assertTrue("Normal number with NaN should return NaN", 
                Float.isNaN(FastMath.max(normal, nan)));
     assertTrue("Two NaNs should return NaN", 
                Float.isNaN(FastMath.max(nan, nan)));
 }

 @Test
     public void testMaxFloat1() {
         // Test case where a < b
         assertEquals(2.0f, FastMath.max(1.0f, 2.0f), 0.0f);
         
         // Test case where a > b
         assertEquals(2.0f, FastMath.max(2.0f, 1.0f), 0.0f);
         
         // Test case where a equals b - this will detect the mutant
         assertEquals(1.0f, FastMath.max(1.0f, 1.0f), 0.0f);
         
         // Test NaN cases
         assertTrue(Float.isNaN(FastMath.max(Float.NaN, 1.0f)));
         assertTrue(Float.isNaN(FastMath.max(1.0f, Float.NaN)));
         assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
     }

 @Test
     public void testMaxFloatWhenEqual() {
         // Test case where a equals b to catch the <= vs < mutant
         float a = 5.0f;
         float b = 5.0f;
         
         // Original should return b when a equals b (due to <=)
         // Mutant would return a (due to <)
         assertEquals("When a equals b, should return b", b, FastMath.max(a, b), 0.0f);
     }

 @Test
     public void testMaxFloatGeneralCases() {
         // Additional test cases for completeness
         // Normal case where a < b
         assertEquals(10.0f, FastMath.max(5.0f, 10.0f), 0.0f);
         
         // Normal case where a > b
         assertEquals(15.0f, FastMath.max(15.0f, 10.0f), 0.0f);
         
         // Case with NaN
         assertTrue(Float.isNaN(FastMath.max(Float.NaN, 10.0f)));
         assertTrue(Float.isNaN(FastMath.max(10.0f, Float.NaN)));
         assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
     }

 @Test
     public void testMaxDouble1() {
         // Test case to catch the a <= b -> a < b mutant
         // When a equals b, original returns b, mutant returns a
         double a = 5.0;
         double b = 5.0;
         assertEquals("When a equals b, should return b", b, FastMath.max(a, b), 0.0);
         
         // Additional test cases for full coverage
         // a < b case
         assertEquals(10.0, FastMath.max(5.0, 10.0), 0.0);
         // a > b case
         assertEquals(10.0, FastMath.max(10.0, 5.0), 0.0);
         // NaN cases
         assertTrue(Double.isNaN(FastMath.max(Double.NaN, 5.0)));
         assertTrue(Double.isNaN(FastMath.max(5.0, Double.NaN)));
         assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
     }

}
