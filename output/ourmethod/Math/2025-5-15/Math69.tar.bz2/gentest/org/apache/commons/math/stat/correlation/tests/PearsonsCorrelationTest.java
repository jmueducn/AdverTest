package gentest.org.apache.commons.math.stat.correlation.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.correlation.*;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.distribution.TDistribution;
import org.apache.commons.math.distribution.TDistributionImpl;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.BlockRealMatrix;
import org.apache.commons.math.stat.regression.SimpleRegression;
 
public class PearsonsCorrelationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                      public void testGetCorrelationPValues_DiagonalElementsZero() throws MathException {
                                          // Setup
                                          int nVars = 3;
                                          int nObs = 10;
                                          RealMatrix mockCorrelationMatrix = mock(RealMatrix.class);
                                          when(mockCorrelationMatrix.getColumnDimension()).thenReturn(nVars);
                                          
                                          // Diagonal elements should return 0
                                          for (int i = 0; i < nVars; i++) {
                                              when(mockCorrelationMatrix.getEntry(i, i)).thenReturn(0.5); // value shouldn't matter
                                          }
                                          
                                          PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(mockCorrelationMatrix, nObs);
                                          
                                          // Test
                                          RealMatrix result = pearsonsCorrelation.getCorrelationPValues();
                                          
                                          // Verify diagonal elements are 0
                                          for (int i = 0; i < nVars; i++) {
                                              assertEquals(0.0, result.getEntry(i, i), 0.0001);
                                          }
                                      }

    @Test
                                      public void testGetCorrelationPValues_PerfectCorrelation() throws Exception {
                                          // Setup
                                          int nVars = 2;
                                          int nObs = 10;
                                          
                                          // Create mock correlation matrix
                                          RealMatrix mockCorrelationMatrix = mock(RealMatrix.class);
                                          when(mockCorrelationMatrix.getColumnDimension()).thenReturn(nVars);
                                          when(mockCorrelationMatrix.getEntry(0, 1)).thenReturn(1.0); // perfect correlation
                                          when(mockCorrelationMatrix.getEntry(1, 0)).thenReturn(1.0);
                                          
                                          // Create PearsonsCorrelation instance
                                          PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(mockCorrelationMatrix, nObs);
                                          
                                          // Test
                                          RealMatrix result = pearsonsCorrelation.getCorrelationPValues();
                                          
                                          // Verify p-value for perfect correlation should be very small (approaching 0)
                                          assertEquals(0.0, result.getEntry(0, 1), 0.0001);
                                      }

    @Test
                                      public void testGetCorrelationPValues_EdgeCaseSmallSampleSize() throws MathException {
                                          // Setup
                                          int nVars = 2;
                                          int nObs = 3; // Minimum sample size for this calculation (nObs-2=1)
                                          
                                          // Create mock correlation matrix
                                          RealMatrix mockCorrelationMatrix = mock(RealMatrix.class);
                                          when(mockCorrelationMatrix.getColumnDimension()).thenReturn(nVars);
                                          when(mockCorrelationMatrix.getEntry(0, 1)).thenReturn(0.8); // strong correlation
                                          when(mockCorrelationMatrix.getEntry(1, 0)).thenReturn(0.8);
                                          
                                          // Create Pearson's correlation instance
                                          PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(mockCorrelationMatrix, nObs);
                                          
                                          // Test
                                          RealMatrix result = pearsonsCorrelation.getCorrelationPValues();
                                          
                                          // Verify calculation works with minimal sample size
                                          double pValue = result.getEntry(0, 1);
                                          assertTrue(pValue > 0 && pValue < 1);
                                      }

    @Test
                                      public void testGetCorrelationPValues_MatrixSymmetry() throws MathException {
                                          // Setup
                                          int nVars = 3;
                                          int nObs = 20;
                                          
                                          // Create mock correlation matrix
                                          RealMatrix mockCorrelationMatrix = mock(RealMatrix.class);
                                          when(mockCorrelationMatrix.getColumnDimension()).thenReturn(nVars);
                                          
                                          // Set up asymmetric correlation values to verify method handles symmetry
                                          when(mockCorrelationMatrix.getEntry(0, 1)).thenReturn(0.3);
                                          when(mockCorrelationMatrix.getEntry(1, 0)).thenReturn(0.3);
                                          when(mockCorrelationMatrix.getEntry(0, 2)).thenReturn(-0.4);
                                          when(mockCorrelationMatrix.getEntry(2, 0)).thenReturn(-0.4);
                                          when(mockCorrelationMatrix.getEntry(1, 2)).thenReturn(0.1);
                                          when(mockCorrelationMatrix.getEntry(2, 1)).thenReturn(0.1);
                                          
                                          // Initialize PearsonsCorrelation
                                          PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(mockCorrelationMatrix, nObs);
                                          
                                          // Test
                                          RealMatrix result = pearsonsCorrelation.getCorrelationPValues();
                                          
                                          // Verify matrix is symmetric
                                          for (int i = 0; i < nVars; i++) {
                                              for (int j = 0; j < nVars; j++) {
                                                  assertEquals(result.getEntry(i, j), result.getEntry(j, i), 0.0001);
                                              }
                                          }
                                      }

    @Test
                                      public void testGetCorrelationPValues_InvalidSampleSize() {
                                          // Setup
                                          RealMatrix mockCorrelationMatrix = mock(RealMatrix.class);
                                          int nVars = 2;
                                          int nObs = 2; // Too small (nObs-2=0)
                                          
                                          when(mockCorrelationMatrix.getColumnDimension()).thenReturn(nVars);
                                          
                                          try {
                                              PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(mockCorrelationMatrix, nObs);
                                              pearsonsCorrelation.getCorrelationPValues();
                                              fail("Expected IllegalArgumentException");
                                          } catch (IllegalArgumentException e) {
                                              // Expected exception
                                          } catch (MathException e) {
                                              fail("Unexpected MathException: " + e.getMessage());
                                          }
                                      }

    @Test
                                      public void testGetCorrelationPValues_ValidCorrelationValues() throws MathException {
                                          // Setup
                                          int nVars = 2;
                                          int nObs = 100; // Large enough for stable t-distribution
                                          
                                          // Create mock correlation matrix
                                          RealMatrix mockCorrelationMatrix = mock(RealMatrix.class);
                                          when(mockCorrelationMatrix.getColumnDimension()).thenReturn(nVars);
                                          when(mockCorrelationMatrix.getRowDimension()).thenReturn(nVars);
                                          
                                          // Set up correlation values
                                          when(mockCorrelationMatrix.getEntry(0, 1)).thenReturn(0.5);
                                          when(mockCorrelationMatrix.getEntry(1, 0)).thenReturn(0.5);
                                          when(mockCorrelationMatrix.getEntry(0, 0)).thenReturn(1.0);
                                          when(mockCorrelationMatrix.getEntry(1, 1)).thenReturn(1.0);
                                          
                                          // Create PearsonsCorrelation instance
                                          PearsonsCorrelation pearsonsCorrelation = 
                                              new PearsonsCorrelation(mockCorrelationMatrix, nObs);
                                          
                                          // Test
                                          RealMatrix result = pearsonsCorrelation.getCorrelationPValues();
                                          
                                          // Verify non-diagonal elements
                                          double pValue = result.getEntry(0, 1);
                                          assertTrue(pValue > 0 && pValue < 1); // p-value should be between 0 and 1
                                          assertEquals(pValue, result.getEntry(1, 0), 0.0001); // matrix should be symmetric
                                      }

    @Test
                                      public void testGetCorrelationPValues_NoCorrelation() throws org.apache.commons.math.MathException {
                                          // Setup
                                          int nVars = 2;
                                          int nObs = 100;
                                          
                                          // Create mock correlation matrix (identity matrix for no correlation)
                                          double[][] corrData = new double[nVars][nVars];
                                          for (int i = 0; i < nVars; i++) {
                                              for (int j = 0; j < nVars; j++) {
                                                  corrData[i][j] = (i == j) ? 1.0 : 0.0;
                                              }
                                          }
                                          org.apache.commons.math.linear.RealMatrix mockCorrelationMatrix = 
                                              new org.apache.commons.math.linear.Array2DRowRealMatrix(corrData);
                                          
                                          // Create Pearson's correlation instance
                                          org.apache.commons.math.stat.correlation.PearsonsCorrelation pearsonsCorrelation =
                                              new org.apache.commons.math.stat.correlation.PearsonsCorrelation(mockCorrelationMatrix, nObs);
                                          
                                          // Test
                                          org.apache.commons.math.linear.RealMatrix result = pearsonsCorrelation.getCorrelationPValues();
                                          
                                          // Verify p-value for no correlation should be 1 (no significant correlation)
                                          org.junit.Assert.assertEquals(1.0, result.getEntry(0, 1), 0.0001);
                                      }

    @Test
                                 public void testGetCorrelationPValuesWithRectangularMatrix() {
                                     // Create a rectangular correlation matrix (3 rows x 2 columns)
                                     double[][] corrData = {
                                         {1.0, 0.5},
                                         {0.5, 1.0},
                                         {0.3, 0.7}
                                     };
                                     RealMatrix corrMatrix = new BlockRealMatrix(corrData);
                                     
                                     // Create PearsonsCorrelation instance with rectangular matrix
                                     PearsonsCorrelation pc = new PearsonsCorrelation(corrMatrix);
                                     
                                     // Mock TDistribution to return predictable probabilities
                                     TDistribution tDistribution = mock(TDistribution.class);
                                     try {
                                         when(tDistribution.cumulativeProbability(anyDouble())).thenReturn(0.05);
                                     } catch (MathException e) {
                                         throw new RuntimeException(e);
                                     }
                                     
                                     // Use reflection to inject the mock tDistribution and test
                                     try {
                                         // Get the method and make it accessible
                                         Method method = PearsonsCorrelation.class.getDeclaredMethod("getCorrelationPValues");
                                         method.setAccessible(true);
                                         
                                         // Inject mock tDistribution
                                         Field tDistField = PearsonsCorrelation.class.getDeclaredField("tDistribution");
                                         tDistField.setAccessible(true);
                                         tDistField.set(pc, tDistribution);
                                         
                                         // Call the method
                                         RealMatrix result = (RealMatrix) method.invoke(pc);
                                         
                                         // Verify output matrix has correct dimensions (should be columns x columns)
                                         assertEquals(2, result.getRowDimension()); // 2 columns
                                         assertEquals(2, result.getColumnDimension()); // 2 columns
                                         
                                         // Verify diagonal is 0
                                         assertEquals(0.0, result.getEntry(0, 0), 1e-10);
                                         assertEquals(0.0, result.getEntry(1, 1), 1e-10);
                                         
                                         // Verify off-diagonal values (mock returns 0.05, 2*0.05=0.1)
                                         assertEquals(0.1, result.getEntry(0, 1), 1e-10);
                                         assertEquals(0.1, result.getEntry(1, 0), 1e-10);
                                         
                                     } catch (Exception e) {
                                         fail("Exception occurred: " + e.getMessage());
                                     }
                                 }

    @Test
                            public void testGetCorrelationPValuesMatrixDimensions() {
                                // Setup test data
                                int nVars = 3;
                                int nObs = 10;
                                double[][] corrData = {
                                    {1.0, 0.5, 0.3},
                                    {0.5, 1.0, 0.2},
                                    {0.3, 0.2, 1.0}
                                };
                                RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
                                
                                // Mock or create dependencies
                                // In this case, we'll create a real PearsonsCorrelation instance
                                // since we need to test the actual implementation
                                PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(correlationMatrix);
                                
                                // Use reflection to set nObs since it's private final
                                try {
                                    Field nObsField = PearsonsCorrelation.class.getDeclaredField("nObs");
                                    nObsField.setAccessible(true);
                                    nObsField.set(pearsonsCorrelation, nObs);
                                } catch (Exception e) {
                                    fail("Failed to set nObs field");
                                }
                                
                                // Call the method
                                RealMatrix result;
                                try {
                                    result = pearsonsCorrelation.getCorrelationPValues();
                                } catch (MathException e) {
                                    fail("Unexpected MathException: " + e.getMessage());
                                    return;
                                }
                                
                                // Verify the dimensions
                                assertEquals("Number of rows should equal number of variables", 
                                             nVars, result.getRowDimension());
                                assertEquals("Number of columns should equal number of variables", 
                                             nVars, result.getColumnDimension());
                                
                                // Additional check: verify diagonal elements are 0
                                for (int i = 0; i < nVars; i++) {
                                    assertEquals(0.0, result.getEntry(i, i), 1e-10);
                                }
                                
                                // Check that non-diagonal elements are calculated (not 0)
                                // This ensures we're not just getting a zero matrix
                                boolean nonZeroFound = false;
                                for (int i = 0; i < nVars; i++) {
                                    for (int j = 0; j < nVars; j++) {
                                        if (i != j && result.getEntry(i, j) != 0.0) {
                                            nonZeroFound = true;
                                            break;
                                        }
                                    }
                                    if (nonZeroFound) break;
                                }
                                assertTrue("At least one non-diagonal element should be non-zero", nonZeroFound);
                            }

    @Test
                   public void testGetCorrelationPValuesDetectsEntryOrderMutation() throws MathException {
                       // Create an asymmetric correlation matrix for testing
                       double[][] asymCorrData = {
                           {1.0, 0.5, 0.3},
                           {0.8, 1.0, 0.4},  // Note 0.8 ≠ 0.5 (row1 col0 vs row0 col1)
                           {0.2, 0.6, 1.0}   // Note 0.2 ≠ 0.3, 0.6 ≠ 0.4
                       };
                       RealMatrix asymMatrix = new BlockRealMatrix(asymCorrData);
                       
                       // Create test object with 100 observations (enough for t-distribution)
                       PearsonsCorrelation pc = new PearsonsCorrelation(asymMatrix, 100);
                       
                       // Get p-values matrix
                       RealMatrix pValues = pc.getCorrelationPValues();
                       
                       // Verify specific asymmetric pairs
                       // Original would use [0][1]=0.5, mutated would use [1][0]=0.8
                       double r01 = asymCorrData[0][1];
                       double expectedT01 = Math.abs(r01 * Math.sqrt(98/(1 - r01*r01)));
                       double expectedP01 = 2 * new TDistributionImpl(98).cumulativeProbability(-expectedT01);
                       assertEquals(expectedP01, pValues.getEntry(0, 1), 1e-10);
                       
                       // Verify the reverse pair would be different
                       double r10 = asymCorrData[1][0];
                       double expectedT10 = Math.abs(r10 * Math.sqrt(98/(1 - r10*r10)));
                       double expectedP10 = 2 * new TDistributionImpl(98).cumulativeProbability(-expectedT10);
                       assertEquals(expectedP10, pValues.getEntry(1, 0), 1e-10);
                       
                       // Verify they're not equal (which they would be if mutation was present)
                       assertNotEquals(pValues.getEntry(0, 1), pValues.getEntry(1, 0), 1e-10);
                   }

    @Test
              public void testGetCorrelationPValuesDetectsMutant() throws MathException {
                  // Setup test data
                  int nObs = 10; // Enough observations to show difference
                  double[][] corrData = {
                      {1.0, 0.5, 0.3},
                      {0.5, 1.0, 0.2},
                      {0.3, 0.2, 1.0}
                  };
                  RealMatrix corrMatrix = new BlockRealMatrix(corrData);
                  
                  // Create test instance
                  PearsonsCorrelation pc = new PearsonsCorrelation(corrMatrix, nObs);
                  
                  // Calculate expected p-values manually with correct formula
                  double[][] expectedPValues = new double[3][3];
                  TDistribution tDist = new TDistributionImpl(nObs - 2);
                  for (int i = 0; i < 3; i++) {
                      for (int j = 0; j < 3; j++) {
                          if (i == j) {
                              expectedPValues[i][j] = 0d;
                          } else {
                              double r = corrMatrix.getEntry(i, j);
                              double t = Math.abs(r * Math.sqrt((nObs - 2)/(1 - r * r)));
                              expectedPValues[i][j] = 2 * tDist.cumulativeProbability(-t);
                          }
                      }
                  }
                  
                  // Get actual p-values
                  RealMatrix actualPValues = pc.getCorrelationPValues();
                  
                  // Verify all values match (mutant will fail this)
                  for (int i = 0; i < 3; i++) {
                      for (int j = 0; j < 3; j++) {
                          assertEquals("P-value mismatch at ["+i+"]["+j+"]", 
                                      expectedPValues[i][j], 
                                      actualPValues.getEntry(i, j), 
                                      1e-10);
                      }
                  }
              }

    @Test
         public void testGetCorrelationPValuesWithNegativeCorrelation() throws MathException {
             // Setup test data with negative correlation
             double[][] corrData = {
                 {1.0, -0.5},
                 {-0.5, 1.0}
             };
             RealMatrix corrMatrix = new BlockRealMatrix(corrData);
             int observations = 10;
             
             // Create test object
             PearsonsCorrelation pc = new PearsonsCorrelation(corrMatrix, observations);
             
             // Get p-values
             RealMatrix pValues = pc.getCorrelationPValues();
             
             // Verify diagonal is 0
             assertEquals(0.0, pValues.getEntry(0, 0), 1e-10);
             assertEquals(0.0, pValues.getEntry(1, 1), 1e-10);
             
             // Verify off-diagonal p-values are equal (should be symmetric)
             double p1 = pValues.getEntry(0, 1);
             double p2 = pValues.getEntry(1, 0);
             assertEquals(p1, p2, 1e-10);
             
             // Verify p-value is same as for positive correlation (0.5)
             double[][] posCorrData = {
                 {1.0, 0.5},
                 {0.5, 1.0}
             };
             RealMatrix posCorrMatrix = new BlockRealMatrix(posCorrData);
             PearsonsCorrelation pcPos = new PearsonsCorrelation(posCorrMatrix, observations);
             RealMatrix posPValues = pcPos.getCorrelationPValues();
             assertEquals(p1, posPValues.getEntry(0, 1), 1e-10);
         }

    @Test
    public void testGetCorrelationPValuesDetectsDenominatorMutation() throws Exception {
        // Setup test data
        int nObs = 10; // Sample size
        double r = 0.5; // Correlation coefficient
        
        // Create a 2x2 correlation matrix with r on off-diagonals
        double[][] corrData = {{1.0, r}, {r, 1.0}};
        RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
        
        // Mock t-distribution to return known values for testing
        TDistribution tDistribution = mock(TDistribution.class);
        // Expected t-value with correct denominator: |0.5| * sqrt(8/(1-0.25)) ≈ 1.63299
        when(tDistribution.cumulativeProbability(-1.632993161855452)).thenReturn(0.068699);
        // Wrong t-value with mutant denominator: |0.5| * sqrt(8/(1+0.25)) ≈ 1.26491
        when(tDistribution.cumulativeProbability(-1.2649110640673518)).thenReturn(0.116433);
        
        // Create test instance
        PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, nObs);
        
        // Use reflection to inject our mock t-distribution
        Field tDistField = PearsonsCorrelation.class.getDeclaredField("tDistribution");
        tDistField.setAccessible(true);
        tDistField.set(pc, tDistribution);
        
        // Calculate p-values
        RealMatrix pValues = pc.getCorrelationPValues();
        
        // Verify results - should be 2*0.068699 ≈ 0.1374 for correct calculation
        // Mutant would give 2*0.116433 ≈ 0.2329
        assertEquals(0.0, pValues.getEntry(0, 0), 1e-10);
        assertEquals(0.0, pValues.getEntry(1, 1), 1e-10);
        assertEquals(0.137398, pValues.getEntry(0, 1), 1e-6);
        assertEquals(0.137398, pValues.getEntry(1, 0), 1e-6);
        
        // Verify mock interactions
        verify(tDistribution).cumulativeProbability(-1.632993161855452);
        verify(tDistribution, never()).cumulativeProbability(-1.2649110640673518);
    }


}
