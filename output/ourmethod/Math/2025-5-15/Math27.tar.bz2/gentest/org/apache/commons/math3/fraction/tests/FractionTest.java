package gentest.org.apache.commons.math3.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.fraction.*;
import java.io.Serializable;
import java.math.BigInteger;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
 
public class FractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                public void testPercentageValue_WithStaticConstants() {
                    // Test with predefined constants
                    assertEquals(100.0, Fraction.ONE.percentageValue(), 0.0001);
                    assertEquals(200.0, Fraction.TWO.percentageValue(), 0.0001);
                    assertEquals(0.0, Fraction.ZERO.percentageValue(), 0.0001);
                    assertEquals(-100.0, Fraction.MINUS_ONE.percentageValue(), 0.0001);
                    assertEquals(50.0, Fraction.ONE_HALF.percentageValue(), 0.0001);
                    assertEquals(25.0, Fraction.ONE_QUARTER.percentageValue(), 0.0001);
                    assertEquals(33.3333, Fraction.ONE_THIRD.percentageValue(), 0.0001);
                    assertEquals(20.0, Fraction.ONE_FIFTH.percentageValue(), 0.0001);
                    assertEquals(40.0, Fraction.TWO_FIFTHS.percentageValue(), 0.0001);
                    assertEquals(60.0, Fraction.THREE_FIFTHS.percentageValue(), 0.0001);
                    assertEquals(80.0, Fraction.FOUR_FIFTHS.percentageValue(), 0.0001);
                }

 @Test
                public void testPercentageValue_WithSimpleFractions() {
                    // Test with simple fractions
                    Fraction half = new Fraction(1, 2);
                    assertEquals(50.0, half.percentageValue(), 0.0001);
                    
                    Fraction quarter = new Fraction(1, 4);
                    assertEquals(25.0, quarter.percentageValue(), 0.0001);
                    
                    Fraction threeQuarters = new Fraction(3, 4);
                    assertEquals(75.0, threeQuarters.percentageValue(), 0.0001);
                }

 @Test
                public void testPercentageValue_WithWholeNumbers() {
                    // Test with whole numbers
                    Fraction five = new Fraction(5);
                    assertEquals(500.0, five.percentageValue(), 0.0001);
                    
                    Fraction negativeThree = new Fraction(-3);
                    assertEquals(-300.0, negativeThree.percentageValue(), 0.0001);
                }

 @Test
                public void testPercentageValue_WithDecimalInput() {
                    // Test with decimal constructor
                    Fraction pointFive = new Fraction(0.5);
                    assertEquals(50.0, pointFive.percentageValue(), 0.0001);
                    
                    Fraction pointThreeThree = new Fraction(0.3333, 0.0001, 100);
                    assertEquals(33.33, pointThreeThree.percentageValue(), 0.01);
                }

 @Test
                public void testPercentageValue_WithLargeNumbers() {
                    // Test with large numbers
                    Fraction largeFraction = new Fraction(Integer.MAX_VALUE - 1, Integer.MAX_VALUE);
                    double expected = 100.0 * ((double)(Integer.MAX_VALUE - 1) / Integer.MAX_VALUE);
                    assertEquals(expected, largeFraction.percentageValue(), 0.0001);
                    
                    Fraction negativeLargeFraction = new Fraction(-(Integer.MAX_VALUE - 1), Integer.MAX_VALUE);
                    assertEquals(-expected, negativeLargeFraction.percentageValue(), 0.0001);
                }

 @Test
                public void testPercentageValue_WithDoubleValueMocking() {
                    // Test the actual calculation by mocking doubleValue()
                    Fraction fraction = mock(Fraction.class);
                    when(fraction.doubleValue()).thenReturn(0.375);
                    when(fraction.percentageValue()).thenCallRealMethod();
                    
                    assertEquals(37.5, fraction.percentageValue(), 0.0001);
                    verify(fraction).doubleValue();
                }

 @Test
                public void testPercentageValue_EdgeCases() {
                    // Test edge cases
                    Fraction maxNumerator = new Fraction(Integer.MAX_VALUE, 1);
                    assertEquals(100.0 * Integer.MAX_VALUE, maxNumerator.percentageValue(), 0.0001);
                    
                    Fraction minNumerator = new Fraction(Integer.MIN_VALUE, 1);
                    assertEquals(100.0 * Integer.MIN_VALUE, minNumerator.percentageValue(), 0.0001);
                    
                    Fraction verySmallFraction = new Fraction(1, Integer.MAX_VALUE);
                    double expectedSmall = 100.0 / Integer.MAX_VALUE;
                    assertEquals(expectedSmall, verySmallFraction.percentageValue(), 0.0001);
                }

 @Test
        public void testDivideDetectsReciprocalMutation() {
            // Create test fractions
            Fraction oneHalf = new Fraction(1, 2);  // 1/2
            Fraction two = new Fraction(2, 1);     // 2/1
            
            // Test that dividing by 1/2 is same as multiplying by 2
            Fraction result = two.divide(oneHalf);
            
            // Should be 2 / (1/2) = 4
            assertEquals(4, result.getNumerator());
            assertEquals(1, result.getDenominator());
            
            // Also test with another fraction to be thorough
            Fraction oneThird = new Fraction(1, 3);
            Fraction three = new Fraction(3, 1);
            result = three.divide(oneThird);
            
            // Should be 3 / (1/3) = 9
            assertEquals(9, result.getNumerator());
            assertEquals(1, result.getDenominator());
        }

 @Test
            public void testDivideByIntegerDetectsMultiplicationMutant() {
                // Create a fraction 1/4 (0.25)
                Fraction original = new Fraction(1, 4);
                
                // Divide by 2 - should result in 1/8 (0.125)
                Fraction divided = original.divide(2);
                
                // Verify numerator and denominator
                assertEquals(1, divided.getNumerator());
                assertEquals(8, divided.getDenominator());
                
                // Also test with another value to be thorough
                Fraction original2 = new Fraction(3, 5);
                Fraction divided2 = original2.divide(3);
                assertEquals(3, divided2.getNumerator());
                assertEquals(15, divided2.getDenominator());
                
                // Edge case: divide by 1 (should return same fraction)
                Fraction original3 = new Fraction(2, 7);
                Fraction divided3 = original3.divide(1);
                assertEquals(2, divided3.getNumerator());
                assertEquals(7, divided3.getDenominator());
            }

 @Test
           public void testDivideDetectsMutant() {
               // Create a fraction to divide by (2/3)
               Fraction fractionToDivideBy = new Fraction(2, 3);
               
               // Create a test fraction (1/2)
               Fraction testFraction = new Fraction(1, 2);
               
               // Original behavior: (1/2) / (2/3) = (1/2) * (3/2) = 3/4
               // Mutant behavior: reciprocal would be (3/2+1) = (3/3) = 1/1
               // Then (1/2) * (1/1) = 1/2
               
               Fraction result = testFraction.divide(fractionToDivideBy);
               
               // Assert the correct result (should be 3/4)
               assertEquals(3, result.getNumerator());
               assertEquals(4, result.getDenominator());
               
               // Additional test case with different values
               Fraction fraction2 = new Fraction(3, 4);
               Fraction testFraction2 = new Fraction(1, 3);
               Fraction result2 = testFraction2.divide(fraction2);
               
               // Original: (1/3) / (3/4) = (1/3) * (4/3) = 4/9
               // Mutant: reciprocal would be (4/3+1) = (4/4) = 1/1
               // Then (1/3) * (1/1) = 1/3
               assertEquals(4, result2.getNumerator());
               assertEquals(9, result2.getDenominator());
           }

 @Test(expected = NullArgumentException.class)
           public void testDivideWithNull() {
               Fraction fraction = new Fraction(1, 2);
               fraction.divide(null);
           }

 @Test(expected = MathArithmeticException.class)
           public void testDivideByZeroFraction() {
               Fraction fraction = new Fraction(1, 2);
               Fraction zeroFraction = new Fraction(0, 1);
               fraction.divide(zeroFraction);
           }

 @Test
       public void testDivideIntDetectsMultiplicationMutant() {
           // Create a fraction that will clearly show the difference between * and +
           Fraction original = new Fraction(1, 3); // 1/3
           
           // Test dividing by 2 - should be 1/(3*2) = 1/6, not 1/(3+2) = 1/5
           Fraction divided = original.divide(2);
           
           // Verify the denominator is multiplied (6) not added (5)
           assertEquals(6, divided.getDenominator());
           assertEquals(1, divided.getNumerator());
           
           // Another test case with different values
           Fraction original2 = new Fraction(2, 5); // 2/5
           Fraction divided2 = original2.divide(3); // should be 2/(5*3) = 2/15
           
           assertEquals(15, divided2.getDenominator());
           assertEquals(2, divided2.getNumerator());
           
           // Test with negative numbers
           Fraction original3 = new Fraction(1, -4); // -1/4
           Fraction divided3 = original3.divide(2); // should be -1/(4*2) = -1/8
           
           assertEquals(8, divided3.getDenominator());
           assertEquals(-1, divided3.getNumerator());
       }

 @Test
      public void testDivideDetectsReciprocalMutation1() {
          // Create a fraction to be divided (3/4)
          Fraction fractionToDivide = new Fraction(3, 4);
          
          // Create a fraction to divide by (1/2)
          Fraction divisor = new Fraction(1, 2);
          
          // Perform division (3/4 ÷ 1/2 = 3/4 * 2/1 = 6/4 = 3/2)
          Fraction result = fractionToDivide.divide(divisor);
          
          // Verify numerator and denominator separately to catch the mutant
          assertEquals(3, result.getNumerator());
          assertEquals(2, result.getDenominator());
          
          // Also test with another fraction to be sure
          Fraction fraction2 = new Fraction(2, 3);
          Fraction divisor2 = new Fraction(1, 3);
          Fraction result2 = fraction2.divide(divisor2);
          
          assertEquals(2, result2.getNumerator());
          assertEquals(1, result2.getDenominator());
      }

 @Test
      public void testDivideByIntegerDetectsMutant() {
          // Create a simple fraction 1/2
          Fraction original = new Fraction(1, 2);
          
          // Divide by 2 - should result in 1/4 (1/(2*2))
          Fraction result = original.divide(2);
          
          // Verify numerator stays the same
          assertEquals(1, result.getNumerator());
          
          // This assertion will catch the mutant - original would have denominator 4,
          // mutant would have denominator 2
          assertEquals(4, result.getDenominator());
          
          // Test with different numerator to ensure it's not just working for 1
          Fraction threeQuarters = new Fraction(3, 4);
          result = threeQuarters.divide(3);
          assertEquals(3, result.getNumerator());
          assertEquals(12, result.getDenominator()); // 3/(4*3) = 3/12
          
          // Test with negative values
          Fraction negativeHalf = new Fraction(-1, 2);
          result = negativeHalf.divide(2);
          assertEquals(-1, result.getNumerator());
          assertEquals(4, result.getDenominator());
          
          // Edge case - divide by 1 should return same fraction
          result = original.divide(1);
          assertEquals(1, result.getNumerator());
          assertEquals(2, result.getDenominator());
      }

 @Test
     public void testDivideDetectsReciprocalMutation2() {
         // Create two simple fractions: 1/2 and 1/4
         Fraction half = new Fraction(1, 2);
         Fraction quarter = new Fraction(1, 4);
         
         // 1/2 divided by 1/4 should equal 2 (since 1/2 * 4/1 = 4/2 = 2)
         Fraction result = half.divide(quarter);
         
         // Verify numerator and denominator separately to catch the mutation
         assertEquals(2, result.getNumerator());
         assertEquals(1, result.getDenominator());
         
         // Also verify the double value to ensure correct division behavior
         assertEquals(2.0, result.doubleValue(), 0.00001);
         
         // Test another case: 3/4 divided by 1/2 should be 3/2
         Fraction threeQuarters = new Fraction(3, 4);
         Fraction oneHalf = new Fraction(1, 2);
         result = threeQuarters.divide(oneHalf);
         
         assertEquals(3, result.getNumerator());
         assertEquals(2, result.getDenominator());
         assertEquals(1.5, result.doubleValue(), 0.00001);
     }

 @Test
         public void testDivideByIntegerDetectsMutant1() {
             // Test with ONE_HALF (1/2) divided by 2
             Fraction original = Fraction.ONE_HALF;
             Fraction result = original.divide(2);
             
             // Original correct behavior: (1/2) / 2 = 1/(2*2) = 1/4
             // Mutated behavior: (1*2)/2 = 2/2 = 1/1
             assertEquals("Numerator should be 1", 1, result.getNumerator());
             assertEquals("Denominator should be 4", 4, result.getDenominator());
             
             // Test with ONE_THIRD (1/3) divided by 3
             original = Fraction.ONE_THIRD;
             result = original.divide(3);
             
             // Original correct behavior: (1/3) / 3 = 1/(3*3) = 1/9
             // Mutated behavior: (1*3)/3 = 3/3 = 1/1
             assertEquals("Numerator should be 1", 1, result.getNumerator());
             assertEquals("Denominator should be 9", 9, result.getDenominator());
             
             // Test with negative number
             original = new Fraction(3, 4); // 3/4
             result = original.divide(-2);
             
             // Original correct behavior: (3/4) / -2 = 3/(4*-2) = 3/-8 = -3/8
             // Mutated behavior: (3*-2)/4 = -6/4 = -3/2
             assertEquals("Numerator should be -3", -3, result.getNumerator());
             assertEquals("Denominator should be 8", 8, result.getDenominator());
         }

 @Test
        public void testDivideDetectsReciprocalMutation3() {
            // Create test fractions - using 1/2 divided by 1/4 should give 2/1
            Fraction numerator = new Fraction(1, 2);
            Fraction denominator = new Fraction(1, 4);
            
            // Perform division
            Fraction result = numerator.divide(denominator);
            
            // Verify the result - should be 2/1 (since (1/2)/(1/4) = (1/2)*(4/1) = 4/2 = 2/1)
            assertEquals(2, result.getNumerator());
            assertEquals(1, result.getDenominator());
            
            // Another test case with different values
            Fraction numerator2 = new Fraction(3, 4);
            Fraction denominator2 = new Fraction(2, 3);
            Fraction result2 = numerator2.divide(denominator2);
            
            // Should be (3/4)/(2/3) = (3/4)*(3/2) = 9/8
            assertEquals(9, result2.getNumerator());
            assertEquals(8, result2.getDenominator());
        }

 @Test(expected = NullArgumentException.class)
        public void testDivideWithNullFraction() {
            Fraction fraction = new Fraction(1, 2);
            fraction.divide(null);
        }

 @Test(expected = MathArithmeticException.class)
        public void testDivideByZeroFraction1() {
            Fraction fraction = new Fraction(1, 2);
            Fraction zeroFraction = new Fraction(0, 1);
            fraction.divide(zeroFraction);
        }

 @Test
        public void testDivideByIntegerShouldMultiplyDenominator() {
            // Create a test fraction 1/2
            Fraction fraction = new Fraction(1, 2);
            
            // Divide by 3 - should become 1/(2*3) = 1/6
            Fraction result = fraction.divide(3);
            
            // Verify numerator remains 1
            assertEquals(1, result.getNumerator());
            
            // Verify denominator was multiplied by 3 (2*3=6)
            assertEquals(6, result.getDenominator());
            
            // Also test with division by 1 (edge case)
            Fraction result2 = fraction.divide(1);
            assertEquals(1, result2.getNumerator());
            assertEquals(2, result2.getDenominator());
            
            // Test with another fraction to be thorough
            Fraction fraction2 = new Fraction(3, 4);
            Fraction result3 = fraction2.divide(2);
            assertEquals(3, result3.getNumerator());
            assertEquals(8, result3.getDenominator());
        }

 @Test
   public void testDivideDetectsReciprocalMutation4() {
       // Create test fractions - using non-1 numerators to ensure proper reciprocal
       Fraction threeHalves = new Fraction(3, 2);  // 3/2
       Fraction twoThirds = new Fraction(2, 3);   // 2/3
       
       // Test division in both directions
       Fraction result1 = threeHalves.divide(twoThirds);
       assertEquals("3/2 divided by 2/3 should be 9/4", new Fraction(9, 4), result1);
       
       Fraction result2 = twoThirds.divide(threeHalves);
       assertEquals("2/3 divided by 3/2 should be 4/9", new Fraction(4, 9), result2);
       
       // Test with negative fractions
       Fraction minusThreeHalves = new Fraction(-3, 2);
       Fraction result3 = minusThreeHalves.divide(twoThirds);
       assertEquals("-3/2 divided by 2/3 should be -9/4", new Fraction(-9, 4), result3);
       
       // Test division by whole numbers (through the divide(int i) method)
       Fraction result4 = threeHalves.divide(2);
       assertEquals("3/2 divided by 2 should be 3/4", new Fraction(3, 4), result4);
   }

 @Test
   public void testDivideIntPreservesNumerator() {
       // Test with positive numerator and denominator
       Fraction original = new Fraction(3, 4);  // 3/4
       Fraction result = original.divide(2);    // Should be 3/8
       assertEquals("Numerator should remain 3 after division", 3, result.getNumerator());
       assertEquals("Denominator should be multiplied by 2", 8, result.getDenominator());
       
       // Test with negative numerator
       original = new Fraction(-5, 7);  // -5/7
       result = original.divide(3);     // Should be -5/21
       assertEquals("Numerator should remain -5 after division", -5, result.getNumerator());
       assertEquals("Denominator should be multiplied by 3", 21, result.getDenominator());
       
       // Test with numerator 0 (edge case)
       original = new Fraction(0, 1);   // 0/1
       result = original.divide(5);     // Should be 0/5
       assertEquals("Numerator should remain 0 after division", 0, result.getNumerator());
       assertEquals("Denominator should be multiplied by 5", 5, result.getDenominator());
   }

 @Test
  public void testDivideDetectsReciprocalMutation5() {
      // Create a fraction with denominator != 1
      Fraction original = new Fraction(3, 4); // 3/4
      Fraction divisor = new Fraction(1, 2);  // 1/2
      
      // Perform division (should be equivalent to multiplying by 2/1)
      Fraction result = original.divide(divisor);
      
      // Verify the result's denominator is not 1 (which would indicate mutant survived)
      // Expected result is (3/4) / (1/2) = (3/4)*(2/1) = 6/4 = 3/2
      assertEquals(3, result.getNumerator());
      assertEquals(2, result.getDenominator());
      
      // Additional test case with different denominators
      Fraction original2 = new Fraction(2, 3); // 2/3
      Fraction divisor2 = new Fraction(3, 4);  // 3/4
      
      // (2/3) / (3/4) = (2/3)*(4/3) = 8/9
      Fraction result2 = original2.divide(divisor2);
      assertEquals(8, result2.getNumerator());
      assertEquals(9, result2.getDenominator());
  }

 @Test
      public void testDivideByIntegerDetectsMutant2() {
          // Create a fraction to test with (say 1/2)
          Fraction original = new Fraction(1, 2);
          
          // Test dividing by 2 - should become 1/(2*2) = 1/4
          Fraction result = original.divide(2);
          
          // Verify numerator remains the same
          assertEquals("Numerator should remain unchanged", 1, result.getNumerator());
          
          // Verify denominator is multiplied by divisor
          assertEquals("Denominator should be multiplied by divisor", 4, result.getDenominator());
          
          // Test with negative divisor
          Fraction negativeResult = original.divide(-3);
          assertEquals("Numerator should remain unchanged with negative divisor", 
                       1, negativeResult.getNumerator());
          assertEquals("Denominator should be multiplied by absolute value of negative divisor", 
                       6, negativeResult.getDenominator());
          
          // Test edge case of dividing by 1
          Fraction edgeCase = original.divide(1);
          assertEquals("Numerator should remain same when dividing by 1", 
                       1, edgeCase.getNumerator());
          assertEquals("Denominator should remain same when dividing by 1", 
                       2, edgeCase.getDenominator());
      }

 @Test(expected = NullPointerException.class)
     public void testDivideDetectsMutatedReciprocal() {
         // Create a valid fraction that would normally work
         Fraction fractionToDivideBy = new Fraction(2, 3); // 2/3
         
         // Create a fraction to test with
         Fraction testFraction = new Fraction(1, 2); // 1/2
         
         // This should throw NullPointerException if reciprocal() returns null
         // rather than the expected result of 3/4 (1/2 ÷ 2/3 = 1/2 * 3/2 = 3/4)
         testFraction.divide(fractionToDivideBy);
     }

 @Test
     public void testDivideWithValidFraction() {
         // Setup
         Fraction fractionToDivideBy = new Fraction(2, 3); // 2/3
         Fraction testFraction = new Fraction(1, 2); // 1/2
         
         // Expected result: 1/2 ÷ 2/3 = 3/4
         Fraction expected = new Fraction(3, 4);
         
         // Execution
         Fraction result = testFraction.divide(fractionToDivideBy);
         
         // Verification
         assertEquals(expected.getNumerator(), result.getNumerator());
         assertEquals(expected.getDenominator(), result.getDenominator());
     }

 @Test(expected = NullArgumentException.class)
     public void testDivideWithNullFraction1() {
         Fraction testFraction = new Fraction(1, 2);
         testFraction.divide(null);
     }

 @Test(expected = MathArithmeticException.class)
     public void testDivideWithZeroNumeratorFraction() {
         Fraction testFraction = new Fraction(1, 2);
         Fraction zeroFraction = new Fraction(0, 1);
         testFraction.divide(zeroFraction);
     }

 @Test
     public void testDivideByIntegerShouldNotReturnNull() {
         // Test with positive numbers
         Fraction original = new Fraction(1, 2); // 1/2
         Fraction result = original.divide(3);
         assertNotNull("Dividing by integer should not return null", result);
         assertEquals("Numerator should remain the same", 1, result.getNumerator());
         assertEquals("Denominator should be multiplied", 6, result.getDenominator());
 
         // Test with negative numbers
         Fraction negative = new Fraction(3, 4); // 3/4
         result = negative.divide(-2);
         assertNotNull("Dividing by negative integer should not return null", result);
         assertEquals("Numerator should remain the same", 3, result.getNumerator());
         assertEquals("Denominator should be multiplied", -8, result.getDenominator());
 
         // Test with 1 (identity operation)
         Fraction oneThird = new Fraction(1, 3); // 1/3
         result = oneThird.divide(1);
         assertNotNull("Dividing by 1 should not return null", result);
         assertEquals("Numerator should remain the same", 1, result.getNumerator());
         assertEquals("Denominator should remain the same", 3, result.getDenominator());
     }

}
