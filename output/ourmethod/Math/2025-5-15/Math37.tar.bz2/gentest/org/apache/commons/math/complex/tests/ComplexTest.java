package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                       public void testTan_NaNReal() {
                                                                                                                                                           Complex c = new Complex(Double.NaN, 1.0);
                                                                                                                                                           Complex result = c.tan();
                                                                                                                                                           assertTrue(result.isNaN());
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTan_NaNImaginary() {
                                                                                                                                                           Complex c = new Complex(1.0, Double.NaN);
                                                                                                                                                           Complex result = c.tan();
                                                                                                                                                           assertTrue(result.isNaN());
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTan_InfiniteReal() {
                                                                                                                                                           Complex c = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                                                                                                                                           Complex result = c.tan();
                                                                                                                                                           assertTrue(result.isNaN());
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTan_InfiniteImaginary() {
                                                                                                                                                           Complex c = new Complex(1.0, Double.NEGATIVE_INFINITY);
                                                                                                                                                           Complex result = c.tan();
                                                                                                                                                           assertTrue(result.isNaN());
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTan_LargePositiveImaginary() {
                                                                                                                                                           Complex c = new Complex(1.0, 25.0);
                                                                                                                                                           Complex result = c.tan();
                                                                                                                                                           assertEquals(0.0, result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(1.0, result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTan_LargeNegativeImaginary() {
                                                                                                                                                           Complex c = new Complex(1.0, -25.0);
                                                                                                                                                           Complex result = c.tan();
                                                                                                                                                           assertEquals(0.0, result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(-1.0, result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTan_ZeroValues() {
                                                                                                                                                           Complex c = new Complex(0.0, 0.0);
                                                                                                                                                           Complex result = c.tan();
                                                                                                                                                           assertEquals(0.0, result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(0.0, result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTan_RealOnly() {
                                                                                                                                                           Complex c = new Complex(Math.PI/4, 0.0);
                                                                                                                                                           Complex result = c.tan();
                                                                                                                                                           assertEquals(Math.tan(Math.PI/4), result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(0.0, result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTan_ImaginaryOnly() {
                                                                                                                                                           Complex c = new Complex(0.0, 1.0);
                                                                                                                                                           Complex result = c.tan();
                                                                                                                                                           assertEquals(0.0, result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(Math.tanh(1.0), result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTan_RegularComplex() {
                                                                                                                                                           Complex c = new Complex(1.0, 1.0);
                                                                                                                                                           Complex result = c.tan();
                                                                                                                                                           
                                                                                                                                                           // Expected values calculated using the formula
                                                                                                                                                           double real2 = 2.0 * c.getReal();
                                                                                                                                                           double imaginary2 = 2.0 * c.getImaginary();
                                                                                                                                                           double d = Math.cos(real2) + Math.cosh(imaginary2);
                                                                                                                                                           double expectedReal = Math.sin(real2) / d;
                                                                                                                                                           double expectedImaginary = Math.sinh(imaginary2) / d;
                                                                                                                                                           
                                                                                                                                                           assertEquals(expectedReal, result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(expectedImaginary, result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTan_BoundaryValues() {
                                                                                                                                                           // Test just below and above the 20/-20 thresholds
                                                                                                                                                           Complex c1 = new Complex(0.0, 19.999);
                                                                                                                                                           Complex result1 = c1.tan();
                                                                                                                                                           assertFalse(result1.equals(Complex.I));
                                                                                                                                                           
                                                                                                                                                           Complex c2 = new Complex(0.0, 20.001);
                                                                                                                                                           Complex result2 = c2.tan();
                                                                                                                                                           assertEquals(0.0, result2.getReal(), 1e-15);
                                                                                                                                                           assertEquals(1.0, result2.getImaginary(), 1e-15);
                                                                                                                                                           
                                                                                                                                                           Complex c3 = new Complex(0.0, -19.999);
                                                                                                                                                           Complex result3 = c3.tan();
                                                                                                                                                           assertFalse(result3.equals(Complex.I.negate()));
                                                                                                                                                           
                                                                                                                                                           Complex c4 = new Complex(0.0, -20.001);
                                                                                                                                                           Complex result4 = c4.tan();
                                                                                                                                                           assertEquals(0.0, result4.getReal(), 1e-15);
                                                                                                                                                           assertEquals(-1.0, result4.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTanh_NaN_RealPart() {
                                                                                                                                                           Complex c = new Complex(Double.NaN, 2.0);
                                                                                                                                                           assertEquals(Complex.NaN, c.tanh());
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTanh_NaN_ImaginaryPart() {
                                                                                                                                                           Complex c = new Complex(1.0, Double.NaN);
                                                                                                                                                           assertEquals(Complex.NaN, c.tanh());
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTanh_NaN_BothParts() {
                                                                                                                                                           Complex c = new Complex(Double.NaN, Double.NaN);
                                                                                                                                                           assertEquals(Complex.NaN, c.tanh());
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTanh_Infinite_RealPart() {
                                                                                                                                                           Complex c = new Complex(Double.POSITIVE_INFINITY, 2.0);
                                                                                                                                                           assertEquals(Complex.NaN, c.tanh());
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTanh_Infinite_ImaginaryPart() {
                                                                                                                                                           Complex c = new Complex(1.0, Double.POSITIVE_INFINITY);
                                                                                                                                                           assertEquals(Complex.NaN, c.tanh());
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTanh_LargePositiveReal() {
                                                                                                                                                           Complex c = new Complex(25.0, 3.0);
                                                                                                                                                           Complex result = c.tanh();
                                                                                                                                                           assertEquals(1.0, result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(0.0, result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTanh_LargeNegativeReal() {
                                                                                                                                                           Complex c = new Complex(-25.0, 3.0);
                                                                                                                                                           Complex result = c.tanh();
                                                                                                                                                           assertEquals(-1.0, result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(0.0, result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTanh_BoundaryPositive() {
                                                                                                                                                           // Just above 20
                                                                                                                                                           Complex c = new Complex(20.1, 0.0);
                                                                                                                                                           Complex result = c.tanh();
                                                                                                                                                           assertEquals(1.0, result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(0.0, result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTanh_BoundaryNegative() {
                                                                                                                                                           // Just below -20
                                                                                                                                                           Complex c = new Complex(-20.1, 0.0);
                                                                                                                                                           Complex result = c.tanh();
                                                                                                                                                           assertEquals(-1.0, result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(0.0, result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTanh_Zero() {
                                                                                                                                                           Complex c = new Complex(0.0, 0.0);
                                                                                                                                                           Complex result = c.tanh();
                                                                                                                                                           assertEquals(0.0, result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(0.0, result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTanh_TypicalCase() {
                                                                                                                                                           Complex c = new Complex(1.5, 0.5);
                                                                                                                                                           Complex result = c.tanh();
                                                                                                                                                           
                                                                                                                                                           // Expected values calculated using reference implementation
                                                                                                                                                           double expectedReal = 0.9497533478161376;
                                                                                                                                                           double expectedImag = 0.1231241687681276;
                                                                                                                                                           
                                                                                                                                                           assertEquals(expectedReal, result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(expectedImag, result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTanh_PureImaginary() {
                                                                                                                                                           Complex c = new Complex(0.0, 1.0);
                                                                                                                                                           Complex result = c.tanh();
                                                                                                                                                           
                                                                                                                                                           // tanh(iy) = i*tan(y)
                                                                                                                                                           double expectedReal = 0.0;
                                                                                                                                                           double expectedImag = Math.tan(1.0);
                                                                                                                                                           
                                                                                                                                                           assertEquals(expectedReal, result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(expectedImag, result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testTanh_ComplexWithBothParts() {
                                                                                                                                                           Complex c = new Complex(2.5, -1.25);
                                                                                                                                                           Complex result = c.tanh();
                                                                                                                                                           
                                                                                                                                                           // Expected values calculated using reference implementation
                                                                                                                                                           double expectedReal = 0.9870266449903548;
                                                                                                                                                           double expectedImag = -0.1417857692225277;
                                                                                                                                                           
                                                                                                                                                           assertEquals(expectedReal, result.getReal(), 1e-15);
                                                                                                                                                           assertEquals(expectedImag, result.getImaginary(), 1e-15);
                                                                                                                                                       }

    @Test
                                                                                                                                                   public void testTanWithNaNReal() {
                                                                                                                                                       // Case 1: isNaN true (via imaginary part), real finite
                                                                                                                                                       Complex c1 = new Complex(1.0, Double.NaN);
                                                                                                                                                       assertEquals(Complex.NaN, c1.tan());
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testTanWithInfiniteReal() {
                                                                                                                                                       // Case 2: real infinite, isNaN false
                                                                                                                                                       Complex c2 = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                                                                                                                                       assertEquals(Complex.NaN, c2.tan());
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testTanWithNaNAndInfiniteReal() {
                                                                                                                                                       // Case 3: Both conditions true (should still work)
                                                                                                                                                       Complex c3 = new Complex(Double.POSITIVE_INFINITY, Double.NaN);
                                                                                                                                                       assertEquals(Complex.NaN, c3.tan());
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testTanWithFiniteValues() {
                                                                                                                                                       // Case 4: Neither condition true (normal case)
                                                                                                                                                       Complex c4 = new Complex(1.0, 1.0);
                                                                                                                                                       assertNotEquals(Complex.NaN, c4.tan());
                                                                                                                                                   }

    @Test
                                                                                                                                              public void testTanWithNaN() {
                                                                                                                                                  // Create a complex number with NaN (real part is finite, but imaginary is NaN)
                                                                                                                                                  Complex nanComplex = new Complex(1.0, Double.NaN);
                                                                                                                                                  
                                                                                                                                                  // Verify the original behavior would return NaN
                                                                                                                                                  Complex result = nanComplex.tan();
                                                                                                                                                  
                                                                                                                                                  // Assert that the result should be NaN (which the original code would do)
                                                                                                                                                  // The mutant would not return NaN here since real is finite
                                                                                                                                                  assertTrue(result.isNaN());
                                                                                                                                                  
                                                                                                                                                  // Additional test case where real is NaN but finite imaginary
                                                                                                                                                  Complex nanComplex2 = new Complex(Double.NaN, 1.0);
                                                                                                                                                  Complex result2 = nanComplex2.tan();
                                                                                                                                                  assertTrue(result2.isNaN());
                                                                                                                                                  
                                                                                                                                                  // Test case where both parts are NaN
                                                                                                                                                  Complex nanComplex3 = new Complex(Double.NaN, Double.NaN);
                                                                                                                                                  Complex result3 = nanComplex3.tan();
                                                                                                                                                  assertTrue(result3.isNaN());
                                                                                                                                              }

    @Test
                                                                                                                                            public void testTanWithImaginaryExactly() {
                                                                                                                                                // Create a complex number with imaginary part exactly 20.0
                                                                                                                                                Complex c = new Complex(1.0, 20.0);
                                                                                                                                                
                                                                                                                                                // Calculate expected value using the normal formula (what original method should do)
                                                                                                                                                double real2 = 2.0 * c.getReal();
                                                                                                                                                double imaginary2 = 2.0 * c.getImaginary();
                                                                                                                                                double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                                                                                                Complex expected = new Complex(FastMath.sin(real2) / d, 
                                                                                                                                                                             FastMath.sinh(imaginary2) / d);
                                                                                                                                                
                                                                                                                                                // Call the method and get actual result
                                                                                                                                                Complex actual = c.tan();
                                                                                                                                                
                                                                                                                                                // Verify the result matches the expected calculation
                                                                                                                                                assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                                                                                                                                                assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                                                                                                                                                
                                                                                                                                                // Also verify it's not returning the special case (0.0, 1.0)
                                                                                                                                                assertNotEquals(0.0, actual.getReal(), 1e-10);
                                                                                                                                                assertNotEquals(1.0, actual.getImaginary(), 1e-10);
                                                                                                                                            }

    @Test
                                                                                                                                        public void testTanWithImaginaryBetween10And20ShouldNotReturnSpecialCase() {
                                                                                                                                            // Create a complex number with imaginary part between 10 and 20
                                                                                                                                            Complex c = new Complex(1.0, 15.0);
                                                                                                                                            
                                                                                                                                            // Calculate the tangent
                                                                                                                                            Complex result = c.tan();
                                                                                                                                            
                                                                                                                                            // Verify it didn't return the special case (0.0, 1.0)
                                                                                                                                            assertNotEquals(0.0, result.getReal(), 0.0001);
                                                                                                                                            assertNotEquals(1.0, result.getImaginary(), 0.0001);
                                                                                                                                            
                                                                                                                                            // Also verify it's not NaN or infinite
                                                                                                                                            assertFalse(result.isNaN());
                                                                                                                                            assertFalse(result.isInfinite());
                                                                                                                                            
                                                                                                                                            // For completeness, verify the actual calculation (approximate)
                                                                                                                                            // These values would need to be calculated or known expected values
                                                                                                                                            // Here we just verify the structure of the result
                                                                                                                                            assertEquals(FastMath.sin(2.0) / (FastMath.cos(2.0) + FastMath.cosh(30.0)), 
                                                                                                                                                         result.getReal(), 0.0001);
                                                                                                                                            assertEquals(FastMath.sinh(30.0) / (FastMath.cos(2.0) + FastMath.cosh(30.0)), 
                                                                                                                                                         result.getImaginary(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                      public void testTanWithImaginaryExactlyNegative() {
                                                                                                                                          // Create a complex number with imaginary exactly -20.0
                                                                                                                                          Complex c = new Complex(1.0, -20.0);
                                                                                                                                          
                                                                                                                                          // Calculate expected value using the normal formula (not special case)
                                                                                                                                          double real2 = 2.0 * c.getReal();
                                                                                                                                          double imaginary2 = 2.0 * c.getImaginary();
                                                                                                                                          double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                                                                                          Complex expected = new Complex(FastMath.sin(real2) / d,
                                                                                                                                                                       FastMath.sinh(imaginary2) / d);
                                                                                                                                          
                                                                                                                                          // Test the tan() method
                                                                                                                                          Complex result = c.tan();
                                                                                                                                          
                                                                                                                                          // Verify it didn't use the special case (0.0, -1.0)
                                                                                                                                          assertNotEquals(0.0, result.getReal(), 0.0001);
                                                                                                                                          assertNotEquals(-1.0, result.getImaginary(), 0.0001);
                                                                                                                                          
                                                                                                                                          // Verify it calculated the correct value
                                                                                                                                          assertEquals(expected.getReal(), result.getReal(), 0.0001);
                                                                                                                                          assertEquals(expected.getImaginary(), result.getImaginary(), 0.0001);
                                                                                                                                      }

    @Test
                                                                                                                                 public void testTanWithImaginaryBetweenNegative20AndNegative() {
                                                                                                                                     // Create a complex number with imaginary part between -20 and -10
                                                                                                                                     // where the mutation would change behavior
                                                                                                                                     Complex c = new Complex(1.0, -15.0);
                                                                                                                                     
                                                                                                                                     // Calculate expected value using normal formula (original behavior)
                                                                                                                                     double real2 = 2.0 * c.getReal();
                                                                                                                                     double imaginary2 = 2.0 * c.getImaginary();
                                                                                                                                     double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                                                                                     Complex expected = new Complex(
                                                                                                                                         FastMath.sin(real2) / d,
                                                                                                                                         FastMath.sinh(imaginary2) / d
                                                                                                                                     );
                                                                                                                                     
                                                                                                                                     // Actual result
                                                                                                                                     Complex result = c.tan();
                                                                                                                                     
                                                                                                                                     // Verify it's not using the special case (0.0, -1.0)
                                                                                                                                     assertNotEquals(0.0, result.getReal(), 0.0001);
                                                                                                                                     assertNotEquals(-1.0, result.getImaginary(), 0.0001);
                                                                                                                                     
                                                                                                                                     // Verify it matches the calculated expected value
                                                                                                                                     assertEquals(expected.getReal(), result.getReal(), 0.0001);
                                                                                                                                     assertEquals(expected.getImaginary(), result.getImaginary(), 0.0001);
                                                                                                                                 }

    @Test
                                                                                                                            public void testTanWithNonZeroRealPartDetectsRealDoublingMutation() {
                                                                                                                                // Create a complex number where both real and imaginary parts are non-zero
                                                                                                                                // and within the bounds (-20 < imaginary < 20)
                                                                                                                                double real = Math.PI/4;  // 45 degrees, chosen because tan(PI/4) is well known
                                                                                                                                double imaginary = 1.0;
                                                                                                                                Complex complex = new Complex(real, imaginary);
                                                                                                                                
                                                                                                                                // Calculate expected value manually using correct formula (with doubled real part)
                                                                                                                                double expectedReal2 = 2.0 * real;
                                                                                                                                double expectedImaginary2 = 2.0 * imaginary;
                                                                                                                                double expectedD = FastMath.cos(expectedReal2) + FastMath.cosh(expectedImaginary2);
                                                                                                                                Complex expected = new Complex(
                                                                                                                                    FastMath.sin(expectedReal2) / expectedD,
                                                                                                                                    FastMath.sinh(expectedImaginary2) / expectedD
                                                                                                                                );
                                                                                                                                
                                                                                                                                // Call the method under test
                                                                                                                                Complex actual = complex.tan();
                                                                                                                                
                                                                                                                                // Verify both real and imaginary parts
                                                                                                                                assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                                                                                                                                assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                                                                                                                                
                                                                                                                                // This test will fail if real2 isn't doubled (1.0*real instead of 2.0*real)
                                                                                                                                // because sin(real) != sin(2*real) and cos(real) != cos(2*real) in general
                                                                                                                            }

    @Test
                                                                                                                       public void testTanDetectsRealMultiplicationMutant() {
                                                                                                                           // Create a complex number where real part is π/4 (45 degrees)
                                                                                                                           // and imaginary part is in the normal range (-20 < im < 20)
                                                                                                                           double real = Math.PI / 4;  // 45 degrees
                                                                                                                           double imaginary = 1.0;
                                                                                                                           Complex complex = new Complex(real, imaginary);
                                                                                                                           
                                                                                                                           // Calculate expected value using original formula (2*real)
                                                                                                                           double expectedReal2 = 2.0 * real;
                                                                                                                           double imaginary2 = 2.0 * imaginary;
                                                                                                                           double d = Math.cos(expectedReal2) + Math.cosh(imaginary2);
                                                                                                                           Complex expected = new Complex(Math.sin(expectedReal2) / d,
                                                                                                                                                        Math.sinh(imaginary2) / d);
                                                                                                                           
                                                                                                                           // Get actual result from the method
                                                                                                                           Complex actual = complex.tan();
                                                                                                                           
                                                                                                                           // Verify the result would be different with the mutant (3*real)
                                                                                                                           double mutantReal2 = 3.0 * real;
                                                                                                                           double mutantD = Math.cos(mutantReal2) + Math.cosh(imaginary2);
                                                                                                                           Complex mutantResult = new Complex(Math.sin(mutantReal2) / mutantD,
                                                                                                                                                           Math.sinh(imaginary2) / mutantD);
                                                                                                                           
                                                                                                                           // Assert that actual matches expected and not the mutant result
                                                                                                                           assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                                                                                                                           assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                                                                                                                           assertNotEquals(mutantResult.getReal(), actual.getReal(), 1e-10);
                                                                                                                       }

    @Test
                                                                                                                       public void testTanWithNaNReal1() {
                                                                                                                           // Case where only isNaN is true (real is NaN)
                                                                                                                           Complex c = new Complex(Double.NaN, 1.0);
                                                                                                                           assertEquals(Complex.NaN, c.tan());
                                                                                                                       }

    @Test
                                                                                                                       public void testTanWithInfiniteReal1() {
                                                                                                                           // Case where only real is infinite
                                                                                                                           Complex c = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                                                                                                           assertEquals(Complex.NaN, c.tan());
                                                                                                                       }

    @Test
                                                                                                                       public void testTanWithNaNImaginary() {
                                                                                                                           // Case where only imaginary is NaN (should also return NaN)
                                                                                                                           Complex c = new Complex(1.0, Double.NaN);
                                                                                                                           assertEquals(Complex.NaN, c.tan());
                                                                                                                       }

    @Test
                                                                                                                       public void testTanWithInfiniteImaginary() {
                                                                                                                           // Case where only imaginary is infinite (should return (0, ±1))
                                                                                                                           // This also tests the boundary conditions
                                                                                                                           Complex c1 = new Complex(1.0, Double.POSITIVE_INFINITY);
                                                                                                                           assertEquals(new Complex(0.0, 1.0), c1.tan());
                                                                                                                           
                                                                                                                           Complex c2 = new Complex(1.0, Double.NEGATIVE_INFINITY);
                                                                                                                           assertEquals(new Complex(0.0, -1.0), c2.tan());
                                                                                                                       }

    @Test
                                                                                                                       public void testTanWithBothNaNAndInfinite() {
                                                                                                                           // Case where both isNaN and isInfinite are true
                                                                                                                           Complex c = new Complex(Double.NaN, Double.POSITIVE_INFINITY);
                                                                                                                           assertEquals(Complex.NaN, c.tan());
                                                                                                                       }

    @Test
                                                                                                                       public void testTanWithNormalValues() {
                                                                                                                           // Case where neither condition is true
                                                                                                                           Complex c = new Complex(1.0, 1.0);
                                                                                                                           // We can't predict exact values due to floating point calculations,
                                                                                                                           // but we can verify it's not NaN
                                                                                                                           assertFalse(c.tan().isNaN());
                                                                                                                       }

    @Test
                                                                                                                      public void testTanWithInfiniteReal2() {
                                                                                                                          // Test case where real part is infinite - should return NaN
                                                                                                                          Complex c = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                                                                                                          assertEquals(Complex.NaN, c.tan());
                                                                                                                      }

    @Test
                                                                                                                      public void testTanWithNaN1() {
                                                                                                                          // Test case where number is NaN - should return NaN
                                                                                                                          Complex c = new Complex(Double.NaN, 1.0);
                                                                                                                          assertEquals(Complex.NaN, c.tan());
                                                                                                                          
                                                                                                                          // Also test with NaN imaginary part
                                                                                                                          Complex c2 = new Complex(1.0, Double.NaN);
                                                                                                                          assertEquals(Complex.NaN, c2.tan());
                                                                                                                      }

    @Test
                                                                                                                      public void testTanWithInfiniteImaginary1() {
                                                                                                                          // Test case where imaginary part is infinite - both versions should handle
                                                                                                                          // This is just for completeness
                                                                                                                          Complex c = new Complex(1.0, Double.POSITIVE_INFINITY);
                                                                                                                          // Original would return (0.0, 1.0) for imaginary > 20.0
                                                                                                                          // So we need to verify it's not NaN
                                                                                                                          assertNotEquals(Complex.NaN, c.tan());
                                                                                                                      }

    @Test
                                                                                                                 public void testTanWithImaginaryExactly1() {
                                                                                                                     // Create complex number with imaginary part exactly 20.0
                                                                                                                     Complex c = new Complex(1.0, 20.0);
                                                                                                                     
                                                                                                                     // Calculate expected value using normal formula (what original should do)
                                                                                                                     double real2 = 2.0 * c.getReal();
                                                                                                                     double imaginary2 = 2.0 * c.getImaginary();
                                                                                                                     double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                                                                     Complex expected = new Complex(FastMath.sin(real2) / d, FastMath.sinh(imaginary2) / d);
                                                                                                                     
                                                                                                                     // Call the method
                                                                                                                     Complex result = c.tan();
                                                                                                                     
                                                                                                                     // Verify it didn't use the special case (would fail if mutant is present)
                                                                                                                     assertEquals(expected.getReal(), result.getReal(), 1e-10);
                                                                                                                     assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                                                                                                                     
                                                                                                                     // Also verify it's not equal to the special case value (0.0, 1.0)
                                                                                                                     assertNotEquals(0.0, result.getReal(), 1e-10);
                                                                                                                     assertNotEquals(1.0, result.getImaginary(), 1e-10);
                                                                                                                 }

    @Test
                                                                                                               public void testTanWithRealBetween10And() {
                                                                                                                   // Test case to catch the real > 10.0 mutant
                                                                                                                   // Choose a value between 10.0 and 20.0 (e.g., 15.0)
                                                                                                                   Complex c = new Complex(15.0, 0.0);
                                                                                                                   
                                                                                                                   // Calculate expected value using original behavior
                                                                                                                   double real2 = 2.0 * 15.0;
                                                                                                                   double imaginary2 = 2.0 * 0.0;
                                                                                                                   double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                                                                   Complex expected = new Complex(FastMath.sin(real2) / d,
                                                                                                                                                 FastMath.sinh(imaginary2) / d);
                                                                                                                   
                                                                                                                   // Actual result
                                                                                                                   Complex result = c.tan();
                                                                                                                   
                                                                                                                   // Verify the result matches expected calculation
                                                                                                                   assertEquals(expected.getReal(), result.getReal(), 1e-10);
                                                                                                                   assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                                                                                                                   
                                                                                                                   // Also test with real > 20.0 to ensure original behavior still works
                                                                                                                   Complex c2 = new Complex(25.0, 0.0);
                                                                                                                   real2 = 2.0 * 25.0;
                                                                                                                   d = FastMath.cos(real2) + FastMath.cosh(0.0);
                                                                                                                   expected = new Complex(FastMath.sin(real2) / d, 0.0);
                                                                                                                   result = c2.tan();
                                                                                                                   assertEquals(expected.getReal(), result.getReal(), 1e-10);
                                                                                                                   assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                                                                                                               }

    @Test
                                                                                                          public void testTanWithImaginaryExactlyNegative1() {
                                                                                                              // Create complex number with imaginary exactly -20.0
                                                                                                              Complex c = new Complex(1.0, -20.0);
                                                                                                              
                                                                                                              // Calculate expected value using normal formula (original behavior)
                                                                                                              double real2 = 2.0 * c.getReal();
                                                                                                              double imaginary2 = 2.0 * c.getImaginary();
                                                                                                              double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                                                              Complex expected = new Complex(
                                                                                                                  FastMath.sin(real2) / d,
                                                                                                                  FastMath.sinh(imaginary2) / d
                                                                                                              );
                                                                                                              
                                                                                                              // Call the method
                                                                                                              Complex result = c.tan();
                                                                                                              
                                                                                                              // Verify it didn't use the special case (would return (0.0, -1.0) if mutant is present)
                                                                                                              assertNotEquals(0.0, result.getReal(), 0.0001);
                                                                                                              assertNotEquals(-1.0, result.getImaginary(), 0.0001);
                                                                                                              
                                                                                                              // Verify it used the normal calculation
                                                                                                              assertEquals(expected.getReal(), result.getReal(), 0.0001);
                                                                                                              assertEquals(expected.getImaginary(), result.getImaginary(), 0.0001);
                                                                                                          }

    @Test
                                                                                                     public void testTanWithRealBetweenMinus20AndMinus() {
                                                                                                         // Create a complex number with real part between -20 and -10
                                                                                                         // and imaginary part that doesn't trigger other conditions
                                                                                                         Complex c = new Complex(-15.0, 5.0);
                                                                                                         
                                                                                                         // Calculate expected result using original behavior
                                                                                                         double real2 = 2.0 * c.getReal();
                                                                                                         double imaginary2 = 2.0 * c.getImaginary();
                                                                                                         double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                                                         Complex expected = new Complex(FastMath.sin(real2) / d,
                                                                                                                                      FastMath.sinh(imaginary2) / d);
                                                                                                         
                                                                                                         // Actual result
                                                                                                         Complex actual = c.tan();
                                                                                                         
                                                                                                         // Verify the result matches expected calculation
                                                                                                         assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                                                                                                         assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                                                                                                         
                                                                                                         // Additional verification that we didn't hit the boundary condition
                                                                                                         assertNotEquals(0.0, actual.getReal(), 1e-10);
                                                                                                         assertNotEquals(1.0, actual.getImaginary(), 1e-10);
                                                                                                         assertNotEquals(-1.0, actual.getImaginary(), 1e-10);
                                                                                                     }

    @Test
                                                                                                 public void testTanDetectsRealMultiplicationMutant1() {
                                                                                                     // Create a complex number where real part is π/4 (45 degrees)
                                                                                                     // tan(π/4 + iy) should have real part = sin(π/2)/d = 1/d
                                                                                                     // With mutant (1*real), it would calculate sin(π/4)/d' = 0.707/d'
                                                                                                     Complex c = new Complex(Math.PI/4, 1.0);  // imaginary=1.0 to avoid special cases
                                                                                                     
                                                                                                     // Calculate expected values
                                                                                                     double expectedReal = Math.sin(2 * Math.PI/4);  // sin(π/2) = 1
                                                                                                     double expectedImag = Math.sinh(2 * 1.0);       // sinh(2)
                                                                                                     double d = Math.cos(2 * Math.PI/4) + Math.cosh(2 * 1.0);  // cos(π/2)=0, cosh(2)
                                                                                                     expectedReal /= d;
                                                                                                     expectedImag /= d;
                                                                                                     
                                                                                                     Complex result = c.tan();
                                                                                                     
                                                                                                     // Verify both real and imaginary parts
                                                                                                     assertEquals("Real part should match calculated tan(π/4 + i)", 
                                                                                                                 expectedReal, result.getReal(), 1e-10);
                                                                                                     assertEquals("Imaginary part should match calculated tan(π/4 + i)", 
                                                                                                                 expectedImag, result.getImaginary(), 1e-10);
                                                                                                     
                                                                                                     // The mutant would calculate with 1*real instead of 2*real
                                                                                                     // So it would compute sin(π/4)=0.707 instead of sin(π/2)=1
                                                                                                     // This assertion would fail with the mutant
                                                                                                 }

    @Test
                                                                                                    public void testTanDetectsRealMultiplicationMutant2() {
                                                                                                        // Create a complex number where real part is non-zero
                                                                                                        // Using π/4 (45 degrees) as it gives clean tan values
                                                                                                        Complex c = new Complex(Math.PI/4, 0.5);
                                                                                                        
                                                                                                        // Calculate expected values manually using correct formula
                                                                                                        double expectedReal2 = 2.0 * c.getReal();
                                                                                                        double expectedImaginary2 = 2.0 * c.getImaginary();
                                                                                                        double expectedDenominator = Math.cos(expectedReal2) + Math.cosh(expectedImaginary2);
                                                                                                        Complex expected = new Complex(Math.sin(expectedReal2)/expectedDenominator,
                                                                                                                                      Math.sinh(expectedImaginary2)/expectedDenominator);
                                                                                                        
                                                                                                        // Get actual result
                                                                                                        Complex actual = c.tan();
                                                                                                        
                                                                                                        // Verify both real and imaginary parts
                                                                                                        assertEquals("Real part of tan() is incorrect", 
                                                                                                                    expected.getReal(), actual.getReal(), 1e-10);
                                                                                                        assertEquals("Imaginary part of tan() is incorrect",
                                                                                                                    expected.getImaginary(), actual.getImaginary(), 1e-10);
                                                                                                        
                                                                                                        // The mutant would calculate with 3*real instead of 2*real,
                                                                                                        // causing both assertions to fail with noticeable differences
                                                                                                    }

    @Test
                                                                                              public void testTanWithLargeRealButSmallImaginary() {
                                                                                                  // Create complex number with large real part but small imaginary part
                                                                                                  Complex c = new Complex(25.0, 5.0);
                                                                                                  
                                                                                                  // Calculate expected value (what the correct implementation should return)
                                                                                                  double real2 = 2.0 * 25.0;
                                                                                                  double imaginary2 = 2.0 * 5.0;
                                                                                                  double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                                                  Complex expected = new Complex(FastMath.sin(real2) / d, FastMath.sinh(imaginary2) / d);
                                                                                                  
                                                                                                  // Call the method
                                                                                                  Complex result = c.tan();
                                                                                                  
                                                                                                  // Verify it didn't return the special case (0.0, 1.0)
                                                                                                  assertNotEquals(new Complex(0.0, 1.0), result);
                                                                                                  
                                                                                                  // Verify it returns the correct calculated value
                                                                                                  assertEquals(expected.getReal(), result.getReal(), 1e-10);
                                                                                                  assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                                                                                              }

    @Test
                                                                                         public void testTanWithImaginaryExactly2() {
                                                                                             // Create complex number with imaginary part exactly 20.0
                                                                                             Complex c = new Complex(1.0, 20.0);
                                                                                             
                                                                                             // Calculate expected value using original behavior (not the special case)
                                                                                             double real2 = 2.0 * c.getReal();
                                                                                             double imaginary2 = 2.0 * c.getImaginary();
                                                                                             double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                                             Complex expected = new Complex(FastMath.sin(real2) / d, FastMath.sinh(imaginary2) / d);
                                                                                             
                                                                                             // Test against actual result
                                                                                             Complex actual = c.tan();
                                                                                             
                                                                                             // Verify the result is not the special case (0.0, 1.0)
                                                                                             assertNotEquals(new Complex(0.0, 1.0), actual);
                                                                                             
                                                                                             // Verify it matches the calculated expected value
                                                                                             assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                                                                                             assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                                                                                         }

    @Test
                                                                                    public void testTanWithImaginaryBetween10And20ShouldNotReturnSpecialCase1() {
                                                                                        // Test with imaginary part between 10 and 20 (15.0)
                                                                                        Complex complex = new Complex(1.0, 15.0);
                                                                                        Complex result = complex.tan();
                                                                                        
                                                                                        // Verify the result is not the special case (0.0, 1.0)
                                                                                        assertNotEquals(0.0, result.getReal(), 0.0001);
                                                                                        assertNotEquals(1.0, result.getImaginary(), 0.0001);
                                                                                        
                                                                                        // Also verify it's not NaN or the other special case
                                                                                        assertFalse(result.isNaN());
                                                                                        assertNotEquals(0.0, result.getReal(), 0.0001);
                                                                                        assertNotEquals(-1.0, result.getImaginary(), 0.0001);
                                                                                        
                                                                                        // For completeness, verify it's doing the normal calculation
                                                                                        double real2 = 2.0 * complex.getReal();
                                                                                        double imaginary2 = 2.0 * complex.getImaginary();
                                                                                        double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                                        Complex expected = new Complex(FastMath.sin(real2) / d,
                                                                                                                    FastMath.sinh(imaginary2) / d);
                                                                                        assertEquals(expected.getReal(), result.getReal(), 0.0001);
                                                                                        assertEquals(expected.getImaginary(), result.getImaginary(), 0.0001);
                                                                                    }

    @Test
                                                                               public void testTanWithImaginaryExactlyNegative2() {
                                                                                   // Create complex number with imaginary exactly -20.0
                                                                                   Complex c = new Complex(1.0, -20.0);
                                                                                   
                                                                                   // Call the tan method
                                                                                   Complex result = c.tan();
                                                                                   
                                                                                   // Verify it doesn't return (0.0, -1.0) - which would happen with the mutant
                                                                                   // Instead it should do the normal calculation
                                                                                   double real2 = 2.0 * c.getReal();
                                                                                   double imaginary2 = 2.0 * c.getImaginary();
                                                                                   double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                                   Complex expected = new Complex(
                                                                                       FastMath.sin(real2) / d,
                                                                                       FastMath.sinh(imaginary2) / d
                                                                                   );
                                                                                   
                                                                                   // Assert the actual calculation was performed, not the special case
                                                                                   assertEquals(expected.getReal(), result.getReal(), 1e-10);
                                                                                   assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                                                                                   
                                                                                   // Additional assertion to specifically check it's not the special case value
                                                                                   assertNotEquals(0.0, result.getReal(), 1e-10);
                                                                                   assertNotEquals(-1.0, result.getImaginary(), 1e-10);
                                                                               }

    @Test
                                                                          public void testTanWithImaginaryBetweenMinus20AndMinus() {
                                                                              // Create a complex number with imaginary part between -20.0 and -10.0
                                                                              // This is the range where the mutant would behave differently
                                                                              double real = 1.0;
                                                                              double imaginary = -15.0;  // Value between -20.0 and -10.0
                                                                              Complex complex = new Complex(real, imaginary);
                                                                              
                                                                              // Call the method under test
                                                                              Complex result = complex.tan();
                                                                              
                                                                              // With the original code, it should compute the actual tangent
                                                                              // With the mutant, it would return (0.0, -1.0)
                                                                              
                                                                              // First verify it's not returning (0.0, -1.0) which the mutant would do
                                                                              assertNotEquals(0.0, result.getReal(), 0.0001);
                                                                              assertNotEquals(-1.0, result.getImaginary(), 0.0001);
                                                                              
                                                                              // Then verify it returns the correct computed value
                                                                              // Calculate expected values based on the formula in the method
                                                                              double real2 = 2.0 * real;
                                                                              double imaginary2 = 2.0 * imaginary;
                                                                              double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                              Complex expected = new Complex(
                                                                                  FastMath.sin(real2) / d,
                                                                                  FastMath.sinh(imaginary2) / d
                                                                              );
                                                                              
                                                                              assertEquals(expected.getReal(), result.getReal(), 0.0001);
                                                                              assertEquals(expected.getImaginary(), result.getImaginary(), 0.0001);
                                                                          }

    @Test
                                                                      public void testTanDetectsRealMultiplicationMutant3() {
                                                                          // Setup - use π/4 (45 degrees) as real part since trigonometric values are well known
                                                                          double real = Math.PI / 4;
                                                                          double imaginary = 1.0; // Small enough to avoid special cases
                                                                          
                                                                          // Expected behavior (with correct 2.0*real multiplication)
                                                                          // tan(z) = sin(2x)/(cos(2x)+cosh(2y)) + i*sinh(2y)/(cos(2x)+cosh(2y))
                                                                          // For x=π/4, y=1:
                                                                          // sin(2x) = sin(π/2) = 1
                                                                          // cos(2x) = cos(π/2) = 0
                                                                          // So real part should be 1/cosh(2)
                                                                          // Imaginary part should be sinh(2)/cosh(2) = tanh(2)
                                                                          double expectedReal = 1.0 / Math.cosh(2.0);
                                                                          double expectedImaginary = Math.tanh(2.0);
                                                                          
                                                                          // Create complex number and compute tan
                                                                          Complex complex = new Complex(real, imaginary);
                                                                          Complex result = complex.tan();
                                                                          
                                                                          // Assertions - with delta for floating point precision
                                                                          assertEquals("Real part should match mathematical expectation", 
                                                                                      expectedReal, result.getReal(), 1e-10);
                                                                          assertEquals("Imaginary part should match mathematical expectation",
                                                                                      expectedImaginary, result.getImaginary(), 1e-10);
                                                                          
                                                                          // The mutant would compute with 1.0*real instead of 2.0*real
                                                                          // So it would calculate sin(π/4)/denominator instead of sin(π/2)/denominator
                                                                          // The expected values would be different, so this test would fail on the mutant
                                                                      }

    @Test
                                                                     public void testTanDetectsRealMultiplicationMutant4() {
                                                                         // Choose a real value where 2x and 3x give different trig results
                                                                         double real = Math.PI / 6;  // 30 degrees
                                                                         double imaginary = 1.0;     // Within (-20,20) range
                                                                         
                                                                         Complex input = new Complex(real, imaginary);
                                                                         Complex result = input.tan();
                                                                         
                                                                         // Calculate expected values with correct 2x multiplication
                                                                         double expectedReal2 = 2.0 * real;
                                                                         double expectedImaginary2 = 2.0 * imaginary;
                                                                         double expectedD = FastMath.cos(expectedReal2) + FastMath.cosh(expectedImaginary2);
                                                                         double expectedRealPart = FastMath.sin(expectedReal2) / expectedD;
                                                                         double expectedImaginaryPart = FastMath.sinh(expectedImaginary2) / expectedD;
                                                                         
                                                                         // Verify both real and imaginary parts
                                                                         assertEquals("Real part should match expected calculation", 
                                                                                      expectedRealPart, result.getReal(), 1e-10);
                                                                         assertEquals("Imaginary part should match expected calculation",
                                                                                      expectedImaginaryPart, result.getImaginary(), 1e-10);
                                                                     }

    @Test
                                                                        public void testTanWithNaNReal2() {
                                                                            // Case 1: isNaN is true but real is not infinite
                                                                            Complex c = new Complex(Double.NaN, 1.0);
                                                                            Complex result = c.tan();
                                                                            assertEquals("Should return NaN when real part is NaN", Complex.NaN, result);
                                                                        }

    @Test
                                                                        public void testTanWithInfiniteReal3() {
                                                                            // Case 2: real is infinite but isNaN is false
                                                                            Complex c = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                                                            Complex result = c.tan();
                                                                            assertEquals("Should return NaN when real part is infinite", Complex.NaN, result);
                                                                        }

    @Test
                                                                        public void testTanWithNaNAndInfiniteReal1() {
                                                                            // Case 3: Both NaN and infinite real part (though this case is impossible in practice)
                                                                            // We'll create a complex number with NaN real part, which makes isNaN true
                                                                            // and isInfinite false (as per constructor logic)
                                                                            Complex c = new Complex(Double.NaN, 1.0);
                                                                            // Then we'll try to force isInfinite to true (though this might not be possible)
                                                                            // This test case might not be practical due to how the constructor works
                                                                            Complex result = c.tan();
                                                                            assertEquals("Should return NaN when real part is NaN", Complex.NaN, result);
                                                                        }

    @Test
                                                                       public void testTanWithNaN2() {
                                                                           // Create a NaN complex number (either real or imaginary NaN)
                                                                           Complex nanComplex = new Complex(Double.NaN, 1.0);
                                                                           
                                                                           // Original should return NaN, mutant will proceed with calculation
                                                                           Complex result = nanComplex.tan();
                                                                           
                                                                           // Verify it returns the class's NaN constant
                                                                           assertSame(Complex.NaN, result);
                                                                       }

    @Test
                                                                       public void testTanWithInfiniteReal4() {
                                                                           // Create complex with infinite real part
                                                                           Complex infReal = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                                                           
                                                                           // Original should return NaN, mutant will proceed with calculation
                                                                           Complex result = infReal.tan();
                                                                           
                                                                           // Verify it returns the class's NaN constant
                                                                           assertSame(Complex.NaN, result);
                                                                       }

    @Test
                                                                       public void testTanWithInfiniteImaginary2() {
                                                                           // Create complex with infinite imaginary part
                                                                           Complex infImag = new Complex(1.0, Double.POSITIVE_INFINITY);
                                                                           
                                                                           // Both original and mutant should handle this case
                                                                           Complex result = infImag.tan();
                                                                           
                                                                           // Verify it returns the class's NaN constant
                                                                           assertSame(Complex.NaN, result);
                                                                       }

    @Test
                                                                 public void testTanWithImaginaryExactly3() {
                                                                     // Create complex number with imaginary part exactly 20.0
                                                                     Complex c = new Complex(1.0, 20.0);
                                                                     
                                                                     // Calculate expected value using the normal path (not the shortcut)
                                                                     double real2 = 2.0 * c.getReal();
                                                                     double imaginary2 = 2.0 * c.getImaginary();
                                                                     double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                     Complex expected = new Complex(FastMath.sin(real2) / d,
                                                                                                  FastMath.sinh(imaginary2) / d);
                                                                     
                                                                     // Actual result
                                                                     Complex result = c.tan();
                                                                     
                                                                     // Verify the result matches the expected calculation
                                                                     assertEquals(expected.getReal(), result.getReal(), 1e-10);
                                                                     assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                                                                     
                                                                     // Also verify it's not taking the shortcut (0.0, 1.0)
                                                                     assertNotEquals(0.0, result.getReal(), 1e-10);
                                                                     assertNotEquals(1.0, result.getImaginary(), 1e-10);
                                                                 }

    @Test
                                                            public void testTanWithRealBetween10And1() {
                                                                // Create a complex number with real part between 10 and 20
                                                                // and small imaginary part to avoid triggering those conditions
                                                                Complex c = new Complex(15.0, 1.0);
                                                                
                                                                // Calculate expected value using normal path (original behavior)
                                                                double real2 = 2.0 * 15.0;
                                                                double imaginary2 = 2.0 * 1.0;
                                                                double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                Complex expected = new Complex(FastMath.sin(real2) / d,
                                                                                          FastMath.sinh(imaginary2) / d);
                                                                
                                                                // Actual result
                                                                Complex result = c.tan();
                                                                
                                                                // Verify the result matches the expected calculation
                                                                assertEquals(expected.getReal(), result.getReal(), 1e-10);
                                                                assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                                                                
                                                                // If the mutant is present, the result would be different
                                                                // because it would take the special path for real > 10.0
                                                            }

    @Test
                                                       public void testTanWithImaginaryExactlyNegative3() {
                                                           // Create a complex number with imaginary exactly -20.0
                                                           Complex c = new Complex(1.0, -20.0);
                                                           
                                                           // Calculate expected value using the normal formula (original behavior)
                                                           double real2 = 2.0 * c.getReal();
                                                           double imaginary2 = 2.0 * c.getImaginary();
                                                           double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                           Complex expected = new Complex(FastMath.sin(real2) / d,
                                                                                        FastMath.sinh(imaginary2) / d);
                                                           
                                                           // Test that the actual result matches expected normal calculation
                                                           Complex actual = c.tan();
                                                           assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                                                           assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                                                           
                                                           // Also verify it's not returning the special case (0.0, -1.0)
                                                           assertNotEquals(0.0, actual.getReal(), 1e-10);
                                                           assertNotEquals(-1.0, actual.getImaginary(), 1e-10);
                                                       }

    @Test
                                                  public void testTanWithImaginaryBetweenMinus20AndMinus1() {
                                                      // Test with imaginary value between -20 and -10
                                                      // Original should compute normally, mutant would return special case
                                                      Complex c = new Complex(0.0, -15.0);
                                                      Complex result = c.tan();
                                                      
                                                      // Calculate expected values manually
                                                      double real2 = 2.0 * 0.0;
                                                      double imaginary2 = 2.0 * -15.0;
                                                      double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                      Complex expected = new Complex(
                                                          FastMath.sin(real2) / d,
                                                          FastMath.sinh(imaginary2) / d
                                                      );
                                                      
                                                      // Verify not returning special case (0.0, -1.0)
                                                      assertNotEquals(0.0, result.getReal(), 0.0001);
                                                      assertNotEquals(-1.0, result.getImaginary(), 0.0001);
                                                      
                                                      // Verify actual computation matches expected
                                                      assertEquals(expected.getReal(), result.getReal(), 0.0001);
                                                      assertEquals(expected.getImaginary(), result.getImaginary(), 0.0001);
                                                  }

    @Test
                                             public void testTanDetectsRealMultiplicationMutant5() {
                                                 // Create a complex number where real = π/4 and imaginary = 0
                                                 // This will make the difference between original and mutated behavior obvious
                                                 Complex c = new Complex(Math.PI/4, 0.0);
                                                 
                                                 // Calculate expected values using original behavior (2.0 * real)
                                                 double real2 = 2.0 * Math.PI/4;
                                                 double imaginary2 = 2.0 * 0.0;
                                                 double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                 Complex expected = new Complex(FastMath.sin(real2) / d,
                                                                         FastMath.sinh(imaginary2) / d);
                                                 
                                                 // Calculate actual value
                                                 Complex actual = c.tan();
                                                 
                                                 // Verify both real and imaginary parts
                                                 assertEquals("Real part should match expected value", 
                                                             expected.getReal(), actual.getReal(), 1e-10);
                                                 assertEquals("Imaginary part should match expected value",
                                                             expected.getImaginary(), actual.getImaginary(), 1e-10);
                                                 
                                                 // Additional assertion to specifically catch the mutant
                                                 // With the mutation (1.0 * real), the real part would be tan(π/4) ≈ 1.0
                                                 // While the correct value should approach infinity (tan(π/2))
                                                 assertTrue("Real part should be large (approaching infinity)", 
                                                            Math.abs(actual.getReal()) > 1e6);
                                             }

    @Test
                                        public void testTanDetectsRealMultiplicationMutant6() {
                                            // Create a complex number where real component is π/4 (45 degrees)
                                            // and imaginary component is moderate (between -20 and 20)
                                            double real = Math.PI / 4;  // 45 degrees
                                            double imaginary = 1.0;
                                            Complex complex = new Complex(real, imaginary);
                                            
                                            // Calculate expected values with correct formula (2*real)
                                            double expectedReal2 = 2.0 * real;
                                            double imaginary2 = 2.0 * imaginary;
                                            double expectedD = FastMath.cos(expectedReal2) + FastMath.cosh(imaginary2);
                                            Complex expected = new Complex(
                                                FastMath.sin(expectedReal2) / expectedD,
                                                FastMath.sinh(imaginary2) / expectedD
                                            );
                                            
                                            // Get actual result from method
                                            Complex actual = complex.tan();
                                            
                                            // Verify both real and imaginary parts
                                            assertEquals("Real part should match expected calculation", 
                                                expected.getReal(), actual.getReal(), 1e-10);
                                            assertEquals("Imaginary part should match expected calculation",
                                                expected.getImaginary(), actual.getImaginary(), 1e-10);
                                            
                                            // The mutant would calculate with 3*real instead of 2*real,
                                            // which would produce different trigonometric values
                                            // This assertion would fail if the mutant is present
                                        }

    @Test
                                   public void testTanImaginaryBoundary() {
                                       // Test case to catch the mutant where imaginary <= -20.0 instead of imaginary < -20.0
                                       
                                       // Create a complex number with imaginary exactly -20.0
                                       Complex c = new Complex(1.0, -20.0);
                                       
                                       // Calculate expected value for original behavior (should do normal calculation)
                                       double real2 = 2.0 * c.getReal();
                                       double imaginary2 = 2.0 * c.getImaginary();
                                       double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                       Complex expected = new Complex(FastMath.sin(real2) / d, FastMath.sinh(imaginary2) / d);
                                       
                                       // Get actual result
                                       Complex actual = c.tan();
                                       
                                       // Verify the result is not (0.0, -1.0) - which would indicate the mutant survived
                                       assertNotEquals(new Complex(0.0, -1.0), actual);
                                       
                                       // Verify it matches the expected calculated value
                                       assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                                       assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                                       
                                       // Additional test case with imaginary slightly above -20.0 to ensure boundary is correct
                                       Complex c2 = new Complex(1.0, -20.0 + 1e-10);
                                       Complex actual2 = c2.tan();
                                       assertNotEquals(new Complex(0.0, -1.0), actual2);
                                       
                                       // Test case with imaginary slightly below -20.0 to ensure it returns (0.0, -1.0)
                                       Complex c3 = new Complex(1.0, -20.0 - 1e-10);
                                       Complex actual3 = c3.tan();
                                       assertEquals(new Complex(0.0, -1.0), actual3);
                                   }

    @Test
                              public void testTanWithImaginaryBetweenMinus20AndMinus2() {
                                  // Create a complex number with imaginary part between -20.0 and -10.0
                                  Complex c = new Complex(1.0, -15.0);
                                  
                                  // Expected behavior (original code):
                                  // Should calculate the actual tangent value since -15.0 > -20.0
                                  double real2 = 2.0 * c.getReal();
                                  double imaginary2 = 2.0 * c.getImaginary();
                                  double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                  Complex expected = new Complex(FastMath.sin(real2) / d, 
                                                               FastMath.sinh(imaginary2) / d);
                                  
                                  // Actual result
                                  Complex actual = c.tan();
                                  
                                  // Assert that the result is not (0,-1) - which would indicate the mutant survived
                                  assertNotEquals(new Complex(0.0, -1.0), actual);
                                  
                                  // Also assert it matches the expected calculated value
                                  assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                                  assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                              }

    @Test
                          public void testTanDetectsRealMultiplicationMutant7() {
                              // Create a complex number where both real and imaginary parts are non-zero
                              // and imaginary part is between -20 and 20 to avoid special cases
                              Complex c = new Complex(Math.PI/4, 1.0);  // tan(π/4 + i)
                              
                              // Calculate expected values manually using correct formula
                              double expectedReal2 = 2.0 * Math.PI/4;  // Correct: 2*real
                              double expectedImaginary2 = 2.0 * 1.0;
                              double expectedD = Math.cos(expectedReal2) + Math.cosh(expectedImaginary2);
                              Complex expected = new Complex(Math.sin(expectedReal2)/expectedD, 
                                                           Math.sinh(expectedImaginary2)/expectedD);
                              
                              // The mutant would calculate with real2 = 1.0*real instead of 2.0*real
                              // So its results would be:
                              double mutantReal2 = 1.0 * Math.PI/4;
                              double mutantD = Math.cos(mutantReal2) + Math.cosh(expectedImaginary2);
                              Complex mutantResult = new Complex(Math.sin(mutantReal2)/mutantD,
                                                            Math.sinh(expectedImaginary2)/mutantD);
                              
                              // Verify the actual result matches expected (not mutant) values
                              Complex actual = c.tan();
                              
                              // Assert both real and imaginary parts
                              assertEquals("Real part of tan() incorrect - mutant not detected", 
                                          expected.getReal(), actual.getReal(), 1e-10);
                              assertEquals("Imaginary part of tan() incorrect - mutant not detected",
                                          expected.getImaginary(), actual.getImaginary(), 1e-10);
                              
                              // Additional check to ensure we're actually detecting the mutant
                              assertNotEquals("Test fails to detect mutant - real part matches mutant",
                                             mutantResult.getReal(), actual.getReal(), 1e-10);
                          }

    @Test
                         public void testTanDetectsRealMultiplicationMutant8() {
                             // Setup - use a value where 2x and 3x give different results
                             double real = Math.PI / 4;  // 45 degrees
                             double imaginary = 1.0;     // Non-extreme imaginary part
                             
                             // Expected values with correct 2x multiplication
                             double expectedReal2 = 2.0 * real;
                             double expectedImaginary2 = 2.0 * imaginary;
                             double expectedDenominator = FastMath.cos(expectedReal2) + FastMath.cosh(expectedImaginary2);
                             Complex expected = new Complex(FastMath.sin(expectedReal2) / expectedDenominator,
                                                           FastMath.sinh(expectedImaginary2) / expectedDenominator);
                             
                             // Actual calculation
                             Complex actual = new Complex(real, imaginary).tan();
                             
                             // Assertions - both parts should match expected values
                             assertEquals("Real part should match expected tan calculation", 
                                         expected.getReal(), actual.getReal(), 1e-10);
                             assertEquals("Imaginary part should match expected tan calculation",
                                         expected.getImaginary(), actual.getImaginary(), 1e-10);
                             
                             // Additional check that would fail with the mutant
                             // With mutant (3x), real2 would be 3*PI/4, giving different trig values
                             double mutantReal2 = 3.0 * real;
                             double mutantDenominator = FastMath.cos(mutantReal2) + FastMath.cosh(expectedImaginary2);
                             double mutantRealPart = FastMath.sin(mutantReal2) / mutantDenominator;
                             assertNotEquals("Test should detect real multiplication mutant",
                                            mutantRealPart, actual.getReal(), 1e-10);
                         }

    @Test
                            public void testTanWithNaNReal3() {
                                // Case where isNaN is true but real is finite
                                Complex c = new Complex(Double.NaN, 1.0);
                                assertEquals(Complex.NaN, c.tan());
                            }

    @Test
                            public void testTanWithInfiniteReal5() {
                                // Case where real is infinite but isNaN is false
                                Complex c = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                assertEquals(Complex.NaN, c.tan());
                            }

    @Test
                            public void testTanWithNaNImaginary1() {
                                // Additional test case where imaginary is NaN
                                Complex c = new Complex(1.0, Double.NaN);
                                assertEquals(Complex.NaN, c.tan());
                            }

    @Test
                            public void testTanWithInfiniteImaginary3() {
                                // Additional test case where imaginary is infinite
                                Complex c = new Complex(1.0, Double.POSITIVE_INFINITY);
                                assertEquals(Complex.NaN, c.tan());
                            }

    @Test
                       public void testTanWithNaNRealShouldReturnNaN() {
                           // Create a complex number with NaN real part (finite imaginary)
                           Complex c = new Complex(Double.NaN, 5.0);
                           
                           // Verify the result is NaN (original behavior)
                           Complex result = c.tan();
                           assertTrue(result.isNaN());
                           
                           // The mutant would proceed with calculation instead of returning NaN
                           // So this test would fail if the mutant is present
                       }

    @Test
                       public void testTanWithNaNImaginaryShouldReturnNaN() {
                           // Create a complex number with NaN imaginary part (finite real)
                           Complex c = new Complex(3.0, Double.NaN);
                           
                           // Verify the result is NaN (original behavior)
                           Complex result = c.tan();
                           assertTrue(result.isNaN());
                           
                           // The mutant would proceed with calculation instead of returning NaN
                           // So this test would fail if the mutant is present
                       }

    @Test
                       public void testTanWithInfiniteImaginaryShouldReturnNaN() {
                           // Create a complex number with infinite imaginary part
                           Complex c = new Complex(3.0, Double.POSITIVE_INFINITY);
                           
                           // Both original and mutant should return NaN
                           Complex result = c.tan();
                           assertTrue(result.isNaN());
                       }

    @Test
                       public void testTanWithFiniteValuesShouldCalculate() {
                           // Create a complex number with finite values
                           Complex c = new Complex(1.0, 1.0);
                           
                           // Both original and mutant should calculate the tangent
                           Complex result = c.tan();
                           assertFalse(result.isNaN());
                       }

    @Test
                     public void testTanBoundaryConditionForImaginaryPart() {
                         // Create a complex number with imaginary part exactly 20.0
                         Complex c = new Complex(1.0, 20.0);
                         
                         // Calculate expected value through normal path (not special case)
                         double real2 = 2.0 * 1.0;
                         double imaginary2 = 2.0 * 20.0;
                         double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                         Complex expected = new Complex(FastMath.sin(real2) / d,
                                                      FastMath.sinh(imaginary2) / d);
                         
                         // Test that actual result matches expected calculation
                         Complex actual = c.tan();
                         
                         // Verify both real and imaginary parts
                         assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                         assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                         
                         // Additional assertion that it's not returning the special case value
                         assertNotEquals(0.0, actual.getReal(), 1e-10);
                         assertNotEquals(1.0, actual.getImaginary(), 1e-10);
                     }

    @Test
                 public void testTanImaginaryBoundary1() {
                     // Test with imaginary value between 10.0 and 20.0 (15.0)
                     Complex c = new Complex(1.0, 15.0);
                     Complex result = c.tan();
                     
                     // Verify it doesn't return the special case (0.0, 1.0)
                     assertNotEquals(0.0, result.getReal(), 0.0001);
                     assertNotEquals(1.0, result.getImaginary(), 0.0001);
                     
                     // Also verify with exact boundary (10.0)
                     Complex cBoundary = new Complex(1.0, 10.0);
                     Complex resultBoundary = cBoundary.tan();
                     assertNotEquals(0.0, resultBoundary.getReal(), 0.0001);
                     assertNotEquals(1.0, resultBoundary.getImaginary(), 0.0001);
                     
                     // And verify with value just below boundary (9.999)
                     Complex cBelow = new Complex(1.0, 9.999);
                     Complex resultBelow = cBelow.tan();
                     assertNotEquals(0.0, resultBelow.getReal(), 0.0001);
                     assertNotEquals(1.0, resultBelow.getImaginary(), 0.0001);
                 }

    @Test
               public void testTanImaginaryBoundaryNegative() {
                   // Test case to detect mutant where imaginary <= -20.0 instead of imaginary < -20.0
                   Complex c = new Complex(1.0, -20.0);  // imaginary exactly -20.0
                   
                   // Calculate expected value using normal formula (original behavior)
                   double real2 = 2.0 * 1.0;
                   double imaginary2 = 2.0 * -20.0;
                   double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                   Complex expected = new Complex(FastMath.sin(real2) / d,
                                                  FastMath.sinh(imaginary2) / d);
                   
                   // Get actual result
                   Complex actual = c.tan();
                   
                   // Verify original behavior is maintained (mutant would return (0.0, -1.0))
                   assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                   assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                   
                   // Additional assertion to explicitly check it's not the mutant's output
                   assertNotEquals(0.0, actual.getReal(), 1e-10);
                   assertNotEquals(-1.0, actual.getImaginary(), 1e-10);
               }

    @Test
          public void testTanWithImaginaryBetweenMinus20AndMinus3() {
              // Create a complex number with imaginary part between -20 and -10
              // where the mutation would change behavior
              Complex c = new Complex(1.0, -15.0);
              
              // Calculate expected value using original behavior
              double real2 = 2.0 * c.getReal();
              double imaginary2 = 2.0 * c.getImaginary();
              double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
              Complex expected = new Complex(FastMath.sin(real2) / d,
                                    FastMath.sinh(imaginary2) / d);
              
              // Actual result
              Complex result = c.tan();
              
              // Verify the result matches expected normal calculation
              assertEquals(expected.getReal(), result.getReal(), 1e-10);
              assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
              
              // Also verify it's not returning the special case (0.0, -1.0)
              assertNotEquals(0.0, result.getReal(), 1e-10);
              assertNotEquals(-1.0, result.getImaginary(), 1e-10);
          }

    @Test
      public void testTanDetectsRealMultiplicationMutation() {
          // Create a complex number where real part is significant
          double real = Math.PI/4;  // 45 degrees, easy to calculate expected value
          double imaginary = 1.0;   // Not too large to avoid special cases
          Complex c = new Complex(real, imaginary);
          
          // Calculate expected value manually using correct formula (2*real)
          double expectedReal2 = 2.0 * real;
          double expectedImaginary2 = 2.0 * imaginary;
          double expectedD = FastMath.cos(expectedReal2) + FastMath.cosh(expectedImaginary2);
          Complex expected = new Complex(FastMath.sin(expectedReal2)/expectedD, 
                                        FastMath.sinh(expectedImaginary2)/expectedD);
          
          // Call the method under test
          Complex actual = c.tan();
          
          // Verify results with some tolerance for floating point calculations
          assertEquals(expected.getReal(), actual.getReal(), 1e-10);
          assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
      }

    @Test
    public void testTanDetectsRealMultiplicationMutant9() {
        // Test with non-zero real and imaginary parts
        double real = 1.0;  // Non-zero real part to trigger the mutation effect
        double imaginary = 1.0;
        Complex complex = new Complex(real, imaginary);
        
        // Expected calculations with correct formula (2.0 * real)
        double expectedReal2 = 2.0 * real;
        double expectedImaginary2 = 2.0 * imaginary;
        double expectedD = FastMath.cos(expectedReal2) + FastMath.cosh(expectedImaginary2);
        Complex expected = new Complex(
            FastMath.sin(expectedReal2) / expectedD,
            FastMath.sinh(expectedImaginary2) / expectedD
        );
        
        // Actual result from method under test
        Complex actual = complex.tan();
        
        // Verify both real and imaginary parts
        assertEquals("Real part should match expected calculation", 
            expected.getReal(), actual.getReal(), 1e-10);
        assertEquals("Imaginary part should match expected calculation",
            expected.getImaginary(), actual.getImaginary(), 1e-10);
    }


}
