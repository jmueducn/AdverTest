package gentest.org.apache.commons.math3.dfp.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.dfp.*;
import java.util.Arrays;
import org.apache.commons.math3.FieldElement;
 
public class DfpTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                 public void testMultiply_BelowRadixRange() {
                                                                                                                                                                                                                                                                                     // Test with x below RADIX range (negative)
                                                                                                                                                                                                                                                                                     int x = -1;
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Create mock DfpField and Dfp instances
                                                                                                                                                                                                                                                                                     DfpField mockField = mock(DfpField.class);
                                                                                                                                                                                                                                                                                     Dfp dfp = mock(Dfp.class);
                                                                                                                                                                                                                                                                                     Dfp mockDfp = mock(Dfp.class);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Mock the field and newInstance calls
                                                                                                                                                                                                                                                                                     when(dfp.getField()).thenReturn(mockField);
                                                                                                                                                                                                                                                                                     when(dfp.newInstance(x)).thenReturn(mockDfp);
                                                                                                                                                                                                                                                                                     when(mockDfp.multiply(any(Dfp.class))).thenReturn(mockDfp);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     assertSame(mockDfp, result);
                                                                                                                                                                                                                                                                                     verify(dfp).newInstance(x);
                                                                                                                                                                                                                                                                                     verify(mockDfp).multiply(any(Dfp.class));
                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                         public void testMultiply_InfiniteInput() throws Exception {
                                                                                                                                                                                                                                                                             // Create DfpField and infinite Dfp
                                                                                                                                                                                                                                                                             DfpField field = new DfpField(10); // Assuming 10 decimal digits
                                                                                                                                                                                                                                                                             // Create positive infinite Dfp using reflection to access protected constructor
                                                                                                                                                                                                                                                                             Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                                                                                                                             constructor.setAccessible(true);
                                                                                                                                                                                                                                                                             Dfp dfp = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             int x = 5;
                                                                                                                                                                                                                                                                             Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                                                                                                             // Use reflection to check protected fields
                                                                                                                                                                                                                                                                             Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                                                                                             nansField.setAccessible(true);
                                                                                                                                                                                                                                                                             Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                                                                                             signField.setAccessible(true);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             assertEquals(Dfp.INFINITE, nansField.get(result));
                                                                                                                                                                                                                                                                             assertEquals(1, signField.get(result)); // Positive infinity multiplied by positive number
                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                         public void testMultiply_SecondOperandNaN() throws Exception {
                                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                                             DfpField field = new DfpField(100); // Assuming 100 radix digits
                                                                                                                                                                                                                                                                             Dfp x = field.newDfp(1.0); // Create new Dfp instance with value 1.0
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Use reflection to set mantissa (if needed)
                                                                                                                                                                                                                                                                             java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                                                                                             mantField.setAccessible(true);
                                                                                                                                                                                                                                                                             mantField.set(x, new int[]{1, 2, 3, 4});
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Create NaN operand
                                                                                                                                                                                                                                                                             Dfp y = field.newDfp(Double.NaN);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Test
                                                                                                                                                                                                                                                                             Dfp result = x.multiply(y);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                                             assertTrue(result.isNaN()); // Should return NaN
                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                         public void testMultiply_SecondOperandInfiniteFirstFiniteNonZero() {
                                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                                             DfpField field = new DfpField(100); // Assuming 100 radix digits
                                                                                                                                                                                                                                                                             Dfp x = field.newDfp(-1); // Create finite number with negative sign
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                                                                 // Use reflection to set mantissa since it's protected
                                                                                                                                                                                                                                                                                 java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                                                                                                 mantField.setAccessible(true);
                                                                                                                                                                                                                                                                                 mantField.set(x, new int[]{1, 2, 3, 4});
                                                                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                                                                 fail("Failed to set mantissa via reflection");
                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Create infinite number using the proper constructor
                                                                                                                                                                                                                                                                             Dfp y;
                                                                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                                                                 java.lang.reflect.Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                                                                                                                                                                                                                     DfpField.class, byte.class, byte.class);
                                                                                                                                                                                                                                                                                 constructor.setAccessible(true);
                                                                                                                                                                                                                                                                                 y = constructor.newInstance(field, (byte)1, (byte)1); // positive infinite
                                                                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                                                                 fail("Failed to create infinite number via reflection: " + e.getMessage());
                                                                                                                                                                                                                                                                                 return;
                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Test
                                                                                                                                                                                                                                                                             Dfp result = x.multiply(y);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                                                                 java.lang.reflect.Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                                                                                                 nansField.setAccessible(true);
                                                                                                                                                                                                                                                                                 assertEquals(1, nansField.get(result)); // 1 represents INFINITE
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 java.lang.reflect.Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                                                                                                 signField.setAccessible(true);
                                                                                                                                                                                                                                                                                 assertEquals(-1, signField.get(result)); // Sign should be product of signs
                                                                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                                                                 fail("Failed to verify result via reflection: " + e.getMessage());
                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                         public void testMultiply_SecondOperandInfiniteFirstZero() throws Exception {
                                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                                             DfpField field = new DfpField(100); // Create DfpField with precision
                                                                                                                                                                                                                                                                             Dfp x = field.getZero(); // Create zero Dfp using factory method
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Create infinite Dfp using reflection to access protected constructor
                                                                                                                                                                                                                                                                             Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                                                                                                                             constructor.setAccessible(true);
                                                                                                                                                                                                                                                                             Dfp y = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Test
                                                                                                                                                                                                                                                                             Dfp result = x.multiply(y);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                                             // Use reflection to access protected nans field
                                                                                                                                                                                                                                                                             Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                                                                                             nansField.setAccessible(true);
                                                                                                                                                                                                                                                                             byte actualNans = (byte)nansField.get(result);
                                                                                                                                                                                                                                                                             assertEquals(Dfp.QNAN, actualNans); // Should return QNAN
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Verify flag was set
                                                                                                                                                                                                                                                                             Field flagsField = DfpField.class.getDeclaredField("flags");
                                                                                                                                                                                                                                                                             flagsField.setAccessible(true);
                                                                                                                                                                                                                                                                             int flags = (int)flagsField.get(field);
                                                                                                                                                                                                                                                                             assertEquals(DfpField.FLAG_INVALID, flags & DfpField.FLAG_INVALID);
                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                     public void testMultiply_MaxRadixMinusOne() throws Exception {
                                                                                                                                                                                                                                                                         // Create test Dfp instance and get RADIX
                                                                                                                                                                                                                                                                         DfpField field = new DfpField(10); // Assuming base 10 for simplicity
                                                                                                                                                                                                                                                                         Dfp dfp = field.newDfp(1); // Create Dfp with value 1 using factory method
                                                                                                                                                                                                                                                                         int RADIX = field.getRadixDigits(); // Get actual RADIX value
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Test with x = RADIX - 1 (edge case within RADIX range)
                                                                                                                                                                                                                                                                         int x = RADIX - 1;
                                                                                                                                                                                                                                                                         Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         assertNotNull(result);
                                                                                                                                                                                                                                                                         assertEquals(x, result.intValue()); // Verify the multiplication result
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Use reflection to access protected fields
                                                                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                                                                             Class<?> dfpClass = Dfp.class;
                                                                                                                                                                                                                                                                             java.lang.reflect.Field signField = dfpClass.getDeclaredField("sign");
                                                                                                                                                                                                                                                                             signField.setAccessible(true);
                                                                                                                                                                                                                                                                             java.lang.reflect.Field nansField = dfpClass.getDeclaredField("nans");
                                                                                                                                                                                                                                                                             nansField.setAccessible(true);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             assertEquals(1, signField.getInt(result)); // Assuming positive result
                                                                                                                                                                                                                                                                             assertEquals(Dfp.FINITE, nansField.getByte(result));
                                                                                                                                                                                                                                                                         } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                                                                                                                                                             fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                     public void testMultiply_AboveRadixRange() {
                                                                                                                                                                                                                                                                         // Test with x above RADIX range
                                                                                                                                                                                                                                                                         final int RADIX = 10; // Assuming RADIX is 10 based on common DFP implementations
                                                                                                                                                                                                                                                                         int x = RADIX + 1;
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Create test field and dfp instance
                                                                                                                                                                                                                                                                         DfpField field = new DfpField(10); // Assuming 10 decimal digits
                                                                                                                                                                                                                                                                         Dfp dfp = field.newDfp(1); // Create dfp with value 1
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Mock the Dfp class and its behavior
                                                                                                                                                                                                                                                                         Dfp mockDfp = mock(Dfp.class);
                                                                                                                                                                                                                                                                         Dfp spyDfp = spy(dfp);
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Mock the newInstance call
                                                                                                                                                                                                                                                                         when(spyDfp.newInstance(x)).thenReturn(mockDfp);
                                                                                                                                                                                                                                                                         when(mockDfp.multiply(any(Dfp.class))).thenReturn(mockDfp);
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         Dfp result = spyDfp.multiply(x);
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         assertSame(mockDfp, result);
                                                                                                                                                                                                                                                                         verify(spyDfp).newInstance(x);
                                                                                                                                                                                                                                                                         verify(mockDfp).multiply(any(Dfp.class));
                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                 public void testMultiply_SameRadixDigits() throws Exception {
                                                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                                                     DfpField field = new DfpField(10); // Using 10 decimal digits
                                                                                                                                                                                                                                                                     Dfp x = field.newDfp(); // Create new Dfp instance using the field
                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                     // Use reflection to set protected fields
                                                                                                                                                                                                                                                                     java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                                                                                     mantField.setAccessible(true);
                                                                                                                                                                                                                                                                     mantField.set(x, new int[]{1, 2, 3, 4});
                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                     java.lang.reflect.Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                                                                                                                                                                     expField.setAccessible(true);
                                                                                                                                                                                                                                                                     expField.set(x, 1);
                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                     java.lang.reflect.Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                                                                                     signField.setAccessible(true);
                                                                                                                                                                                                                                                                     signField.set(x, (byte)1);
                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                     Dfp y = field.newDfp(); // Create new Dfp instance using the field
                                                                                                                                                                                                                                                                     mantField.set(y, new int[]{5, 6, 7, 8});
                                                                                                                                                                                                                                                                     expField.set(y, 1);
                                                                                                                                                                                                                                                                     signField.set(y, (byte)1);
                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                     // Test
                                                                                                                                                                                                                                                                     Dfp result = x.multiply(y);
                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                                                                     int[] resultMant = (int[])mantField.get(result);
                                                                                                                                                                                                                                                                     assertArrayEquals(new int[]{0, 7, 0, 6}, resultMant); // Expected mantissa
                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                     int resultExp = (int)expField.get(result);
                                                                                                                                                                                                                                                                     assertEquals(3, resultExp); // Expected exponent
                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                     byte resultSign = (byte)signField.get(result);
                                                                                                                                                                                                                                                                     assertEquals(1, resultSign); // Expected sign
                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                             public void testMultiply_NaNInput() throws Exception {
                                                                                                                                                                                                                                                                 // Create a DfpField and Dfp instance
                                                                                                                                                                                                                                                                 DfpField field = new DfpField(10); // Assuming 10 digits precision
                                                                                                                                                                                                                                                                 // Create NaN Dfp using protected constructor via reflection
                                                                                                                                                                                                                                                                 Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                                                                                                                 constructor.setAccessible(true);
                                                                                                                                                                                                                                                                 Dfp dfp = constructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 int x = 5;
                                                                                                                                                                                                                                                                 Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 assertNotNull(result);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Use reflection to access protected nans field
                                                                                                                                                                                                                                                                 Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                                                                                 nansField.setAccessible(true);
                                                                                                                                                                                                                                                                 byte resultNans = (byte)nansField.get(result);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 assertEquals(Dfp.QNAN, resultNans);
                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                             public void testMultiply_BothOperandsInfinite() throws Exception {
                                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                                 org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(100); // Assuming 100 digits precision
                                                                                                                                                                                                                                                                 org.apache.commons.math3.dfp.Dfp x = field.newDfp(Double.NEGATIVE_INFINITY); // Create negative infinity
                                                                                                                                                                                                                                                                 org.apache.commons.math3.dfp.Dfp y = field.newDfp(Double.POSITIVE_INFINITY); // Create positive infinity
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Test
                                                                                                                                                                                                                                                                 org.apache.commons.math3.dfp.Dfp result = x.multiply(y);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                                 assertTrue(result.isInfinite());
                                                                                                                                                                                                                                                                 assertTrue(result.negativeOrNull()); // Check if result is negative
                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                         public void testMultiply_SignCombinations() throws Exception {
                                                                                                                                                                                                                                                             // Initialize required fields
                                                                                                                                                                                                                                                             DfpField field = new DfpField(100); // Assuming 100 digits precision
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create positive number using proper constructor
                                                                                                                                                                                                                                                             Dfp positive = field.newDfp(1); // Initialize with value 1
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create negative number using proper constructor and negate
                                                                                                                                                                                                                                                             Dfp negative = field.newDfp(1);
                                                                                                                                                                                                                                                             negative = negative.negate();
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Test all sign combinations
                                                                                                                                                                                                                                                             // positive * positive = positive
                                                                                                                                                                                                                                                             assertTrue(positive.multiply(positive).positiveOrNull());
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // positive * negative = negative
                                                                                                                                                                                                                                                             assertTrue(positive.multiply(negative).negativeOrNull());
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // negative * positive = negative
                                                                                                                                                                                                                                                             assertTrue(negative.multiply(positive).negativeOrNull());
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // negative * negative = positive
                                                                                                                                                                                                                                                             assertTrue(negative.multiply(negative).positiveOrNull());
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                 public void testMultiply_WithinRadixRange() throws Exception {
                                                                                                                                                                                                                                                     // Create Dfp instance and set up test values
                                                                                                                                                                                                                                                     DfpField field = new DfpField(100); // Assuming RADIX is 100 for this test
                                                                                                                                                                                                                                                     Dfp dfp = field.newDfp(1); // Create Dfp with value 1 using factory method
                                                                                                                                                                                                                                                     int x = 50; // Within RADIX range (assuming RADIX is 100)
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Perform multiplication
                                                                                                                                                                                                                                                     Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Verify result using reflection to access protected fields
                                                                                                                                                                                                                                                     Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                                                                     signField.setAccessible(true);
                                                                                                                                                                                                                                                     int sign = signField.getInt(result);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                                                                     nansField.setAccessible(true);
                                                                                                                                                                                                                                                     int nans = nansField.getInt(result);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Get FINITE constant through reflection if not accessible directly
                                                                                                                                                                                                                                                     Field finiteField = Dfp.class.getDeclaredField("FINITE");
                                                                                                                                                                                                                                                     finiteField.setAccessible(true);
                                                                                                                                                                                                                                                     int FINITE = finiteField.getInt(null);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Assertions
                                                                                                                                                                                                                                                     assertNotNull(result);
                                                                                                                                                                                                                                                     assertEquals(1, sign); // Assuming positive result
                                                                                                                                                                                                                                                     assertEquals(FINITE, nans);
                                                                                                                                                                                                                                                     assertEquals(50, result.intValue()); // Verify actual multiplication result
                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                             public void testMultiply_ResultZero() throws Exception {
                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                 org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(10); // Assuming 10 radix digits
                                                                                                                                                                                                                                                 org.apache.commons.math3.dfp.Dfp x = field.newDfp(1.0); // Create Dfp with value 1 using factory method
                                                                                                                                                                                                                                                 org.apache.commons.math3.dfp.Dfp y = field.newDfp(0.0); // Create Dfp with value 0 using factory method
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Test
                                                                                                                                                                                                                                                 org.apache.commons.math3.dfp.Dfp result = x.multiply(y);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                 assertTrue(result.isZero());
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Reflection verification removed as it's redundant when public methods are available
                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                         public void testMultiply_RoundingNeeded() throws Exception {
                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                             DfpField field = new DfpField(10); // Assuming 10 radix digits
                                                                                                                                                                                                                                             Dfp x = field.newDfp(0); // Initialize with 0
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Use reflection to set protected mant field
                                                                                                                                                                                                                                             java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                                                             mantField.setAccessible(true);
                                                                                                                                                                                                                                             int radix = field.getRadixDigits();
                                                                                                                                                                                                                                             mantField.set(x, new int[]{radix-1, radix-1, radix-1, radix-1});
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             java.lang.reflect.Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                                                                                                                                             expField.setAccessible(true);
                                                                                                                                                                                                                                             expField.set(x, 0);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             Dfp y = field.newDfp(0);
                                                                                                                                                                                                                                             mantField.set(y, new int[]{2, 0, 0, 0});
                                                                                                                                                                                                                                             expField.set(y, 0);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Create test instances using the original field
                                                                                                                                                                                                                                             Dfp testX = field.newDfp(0);
                                                                                                                                                                                                                                             mantField.set(testX, new int[]{radix-1, radix-1, radix-1, radix-1});
                                                                                                                                                                                                                                             expField.set(testX, 0);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             Dfp testY = field.newDfp(0);
                                                                                                                                                                                                                                             mantField.set(testY, new int[]{2, 0, 0, 0});
                                                                                                                                                                                                                                             expField.set(testY, 0);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Test
                                                                                                                                                                                                                                             Dfp result = testX.multiply(testY);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Verify that rounding was attempted
                                                                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                 public void testMultiply_Zero() {
                                                                                                                                                                                                                                     // Create required objects
                                                                                                                                                                                                                                     DfpField field = new DfpField(100); // Assuming 100 digits precision
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Create a Dfp number to test with using the proper factory method
                                                                                                                                                                                                                                     Dfp dfp = field.newDfp(5); // Any number would work here
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Test with x = 0 (edge case within RADIX range)
                                                                                                                                                                                                                                     int x = 0;
                                                                                                                                                                                                                                     Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     assertNotNull(result);
                                                                                                                                                                                                                                     // Check sign indirectly by comparing to zero (positive zero should equal zero)
                                                                                                                                                                                                                                     Dfp zero = field.getZero();
                                                                                                                                                                                                                                     assertEquals(zero, result);
                                                                                                                                                                                                                                     assertTrue(result.isZero());
                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                             public void testMultiply_DifferentRadixDigits() throws Exception {
                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                 DfpField field = new DfpField(4);  // Default field with 4 radix digits
                                                                                                                                                                                                                                 Dfp x = field.newDfp();  // Initialize x with the field
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 DfpField otherField = new DfpField(5);  // Create field with 5 radix digits
                                                                                                                                                                                                                                 Dfp y = otherField.newDfp();  // Create y with the other field
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Create x with radix digits = default (4)
                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                     Field xMantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                                                     xMantField.setAccessible(true);
                                                                                                                                                                                                                                     xMantField.set(x, new int[]{1, 2, 3, 4});
                                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                                     fail("Reflection failed for x mantissa setup");
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Create y with radix digits = 5
                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                     Field yMantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                                                     yMantField.setAccessible(true);
                                                                                                                                                                                                                                     yMantField.set(y, new int[]{5, 6, 7, 8, 9});
                                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                                     fail("Reflection failed for y mantissa setup");
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Test
                                                                                                                                                                                                                                 Dfp result = x.multiply(y);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                     Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                                                     nansField.setAccessible(true);
                                                                                                                                                                                                                                     assertEquals(DfpField.FLAG_INVALID, field.getIEEEFlags());
                                                                                                                                                                                                                                     assertEquals(Dfp.INFINITE, nansField.get(result));
                                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                                     fail("Reflection failed for verification");
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                     public void testMultiply_FirstOperandNaN() {
                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                         // Create DfpField with 100 radix digits
                                                                                                                                                                                                                         DfpField field = new DfpField(100);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Create NaN using the field's NaN constant
                                                                                                                                                                                                                         Dfp x = field.newDfp(Double.NaN);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Create a regular number
                                                                                                                                                                                                                         Dfp y = field.newDfp(2.0);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Test
                                                                                                                                                                                                                         Dfp result = x.multiply(y);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                                         assertTrue(result.isNaN()); // Should return NaN
                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                 public void testMultiply_FirstOperandInfiniteSecondZero() {
                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                     org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(100); // Create DfpField with 100 radix digits
                                                                                                                                                                                                                     org.apache.commons.math3.dfp.Dfp one = field.getOne(); // Get Dfp with value 1
                                                                                                                                                                                                                     org.apache.commons.math3.dfp.Dfp zero = field.getZero(); // Create zero Dfp
                                                                                                                                                                                                                     org.apache.commons.math3.dfp.Dfp x = one.divide(zero); // Create infinite Dfp by dividing 1 by 0
                                                                                                                                                                                                                     org.apache.commons.math3.dfp.Dfp y = field.getZero(); // Create zero Dfp
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Test
                                                                                                                                                                                                                     org.apache.commons.math3.dfp.Dfp result = x.multiply(y);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify result is NaN
                                                                                                                                                                                                                     assertTrue(result.isNaN());
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify invalid flag was set (alternative approach without reflection)
                                                                                                                                                                                                                     // Since we can't directly access the flags field, we can verify the behavior
                                                                                                                                                                                                                     // by checking if the operation produced a NaN result, which indicates
                                                                                                                                                                                                                     // an invalid operation occurred
                                                                                                                                                                                                                     assertTrue(result.isNaN());
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Additional verification through public methods
                                                                                                                                                                                                                     assertEquals(field, result.getField());
                                                                                                                                                                                                                     assertFalse(result.isInfinite());
                                                                                                                                                                                                                     assertFalse(result.isZero());
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                     public void testMultiply_FirstOperandInfiniteSecondFiniteNonZero() {
                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                         org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(100);
                                                                                                                                                                                                         // Create infinite Dfp with positive sign
                                                                                                                                                                                                         // Create finite negative Dfp
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Test
                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                             public void testMultiply_InfiniteInputNegativeMultiplier() throws Exception {
                                                                                                                                                                                 // Create Dfp field and instance
                                                                                                                                                                                 DfpField field = new DfpField(100);
                                                                                                                                                                                 
                                                                                                                                                                                 // Create infinite Dfp using reflection to access protected constructor
                                                                                                                                                                                 Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                                 constructor.setAccessible(true);
                                                                                                                                                                                 Dfp infinite = constructor.newInstance(field, (byte)1, (byte)1);
                                                                                                                                                                                 
                                                                                                                                                                                 // Define constants for comparison
                                                                                                                                                                                 final byte INFINITE = 1;  // Typical value for infinite in DFP implementations
                                                                                                                                                                                 final byte POSITIVE = 1;
                                                                                                                                                                                 final byte NEGATIVE = -1;
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify initial state using reflection
                                                                                                                                                                                 Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                 nansField.setAccessible(true);
                                                                                                                                                                                 
                                                                                                                                                                                 Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                 signField.setAccessible(true);
                                                                                                                                                                                 
                                                                                                                                                                                 // Test multiplication with negative number
                                                                                                                                                                                 int x = -5;
                                                                                                                                                                                 Dfp result = infinite.multiply(x);
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify result sign is negative
                                                                                                                                                                                 assertEquals("Result sign should be negative after multiplying positive infinity by negative number", 
                                                                                                                                                                                             NEGATIVE, signField.get(result));
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify result is still infinite
                                                                                                                                                                                 assertEquals("Result should remain infinite after multiplication", 
                                                                                                                                                                                             INFINITE, nansField.get(result));
                                                                                                                                                                             }

    @Test
                                                                                                                                                                        public void testMultiplySetsInvalidFlagWhenOperationInvalid() {
                                                                                                                                                                            // Create a Dfp field and instance
                                                                                                                                                                            DfpField field = new DfpField(10); // Assuming 10 digits for simplicity
                                                                                                                                                                            Dfp dfp = field.getOne(); // Get Dfp with value 1 using public method
                                                                                                                                                                            
                                                                                                                                                                            // Create a NaN Dfp to force invalid operation
                                                                                                                                                                            // Use reflection to access protected constructor
                                                                                                                                                                            Dfp nanDfp;
                                                                                                                                                                            try {
                                                                                                                                                                                Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                                                                                                                    DfpField.class, byte.class, byte.class);
                                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                                nanDfp = constructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                throw new RuntimeException("Failed to create NaN Dfp", e);
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            // Mock the newInstance to return NaN
                                                                                                                                                                            Dfp spyDfp = spy(dfp);
                                                                                                                                                                            when(spyDfp.newInstance(anyInt())).thenReturn(nanDfp);
                                                                                                                                                                            
                                                                                                                                                                            // Perform multiplication that will use the slow path and trigger invalid operation
                                                                                                                                                                            spyDfp.multiply(100); // Value outside RADIX range
                                                                                                                                                                            
                                                                                                                                                                            // Verify the invalid flag was set
                                                                                                                                                                            verify(field).setIEEEFlagsBits(DfpField.FLAG_INVALID);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                public void testMultiplyWithDifferentRadixDigitsSetsInvalidFlag() {
                                                                                                                                                                    // Create mock field with different radix digits
                                                                                                                                                                    DfpField field1 = mock(DfpField.class);
                                                                                                                                                                    when(field1.getRadixDigits()).thenReturn(10);
                                                                                                                                                                    Dfp zero1 = mock(Dfp.class);
                                                                                                                                                                    when(field1.getZero()).thenReturn(zero1);
                                                                                                                                                                    when(zero1.newInstance(0)).thenReturn(zero1);
                                                                                                                                                                    
                                                                                                                                                                    DfpField field2 = mock(DfpField.class);
                                                                                                                                                                    when(field2.getRadixDigits()).thenReturn(15);
                                                                                                                                                                    Dfp zero2 = mock(Dfp.class);
                                                                                                                                                                    when(field2.getZero()).thenReturn(zero2);
                                                                                                                                                                    when(zero2.newInstance(0)).thenReturn(zero2);
                                                                                                                                                                    
                                                                                                                                                                    // Create Dfp instances with different radix digits
                                                                                                                                                                    Dfp dfp1 = zero1.newInstance(0);
                                                                                                                                                                    Dfp dfp2 = zero2.newInstance(0);
                                                                                                                                                                    
                                                                                                                                                                    // Perform multiplication
                                                                                                                                                                    Dfp result = dfp1.multiply(dfp2);
                                                                                                                                                                    
                                                                                                                                                                    // Verify the invalid flag was set
                                                                                                                                                                    verify(field1).setIEEEFlagsBits(DfpField.FLAG_INVALID);
                                                                                                                                                                    
                                                                                                                                                                    // Verify QNaN result by checking isNaN() instead of accessing protected field
                                                                                                                                                                    assertTrue(result.isNaN());
                                                                                                                                                                }

    @Test
                                                                                                                                                       public void testMultiplyWithDifferentRadixDigits() throws Exception {
                                                                                                                                                           // Create fields with different radix digits
                                                                                                                                                           DfpField field1 = new DfpField(10); // Assuming constructor takes radix digits
                                                                                                                                                           DfpField field2 = new DfpField(20);
                                                                                                                                                           
                                                                                                                                                           // Create Dfp objects with different fields using proper constructor access
                                                                                                                                                           Dfp dfp1 = field1.newDfp(1); // value 1
                                                                                                                                                           Dfp dfp2 = field2.newDfp(2); // value 2
                                                                                                                                                           
                                                                                                                                                           // Get MULTIPLY_TRAP constant via reflection
                                                                                                                                                           Field multiplyTrapField = Dfp.class.getDeclaredField("MULTIPLY_TRAP");
                                                                                                                                                           multiplyTrapField.setAccessible(true);
                                                                                                                                                           String MULTIPLY_TRAP = (String) multiplyTrapField.get(null);
                                                                                                                                                           
                                                                                                                                                           // Mock the dotrap method to verify trap type
                                                                                                                                                           Dfp spyDfp1 = spy(dfp1);
                                                                                                                                                           doAnswer(invocation -> {
                                                                                                                                                               String trapType = invocation.getArgument(1);
                                                                                                                                                               assertEquals(MULTIPLY_TRAP, trapType); // Verify correct trap type
                                                                                                                                                               return invocation.callRealMethod();
                                                                                                                                                           }).when(spyDfp1).dotrap(anyInt(), anyString(), any(Dfp.class), any(Dfp.class));
                                                                                                                                                           
                                                                                                                                                           // Perform multiplication
                                                                                                                                                           Dfp result = spyDfp1.multiply(dfp2);
                                                                                                                                                           
                                                                                                                                                           // Verify results - access nans via reflection
                                                                                                                                                           Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                           nansField.setAccessible(true);
                                                                                                                                                           byte resultNans = (byte) nansField.get(result);
                                                                                                                                                           assertEquals(Dfp.QNAN, resultNans); // Should be QNaN
                                                                                                                                                           
                                                                                                                                                           // Verify invalid flag is set using getter
                                                                                                                                                           assertTrue((spyDfp1.getField().getIEEEFlags() & DfpField.FLAG_INVALID) != 0);
                                                                                                                                                           
                                                                                                                                                           // Verify dotrap was called with correct parameters
                                                                                                                                                           verify(spyDfp1).dotrap(DfpField.FLAG_INVALID, MULTIPLY_TRAP, dfp2, any(Dfp.class));
                                                                                                                                                       }

    @Test
                                                                                                                                                   public void testMultiplyInvalidOperationReportsCorrectTrapType() throws Exception {
                                                                                                                                                       // Setup
                                                                                                                                                       DfpField field = mock(DfpField.class);
                                                                                                                                                       Dfp dfp = mock(Dfp.class);
                                                                                                                                                       when(dfp.getField()).thenReturn(field);
                                                                                                                                                       when(dfp.newInstance(anyInt())).thenReturn(mock(Dfp.class));
                                                                                                                                                       
                                                                                                                                                       // Create real Dfp instance for testing
                                                                                                                                                       Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                                                                       constructor.setAccessible(true);
                                                                                                                                                       Dfp realDfp = constructor.newInstance(field, 0);
                                                                                                                                                       when(dfp.multiply(any(Dfp.class))).thenCallRealMethod();
                                                                                                                                                       
                                                                                                                                                       // Use reflection to access private constants
                                                                                                                                                       Field multiplyTrapField = Dfp.class.getDeclaredField("MULTIPLY_TRAP");
                                                                                                                                                       multiplyTrapField.setAccessible(true);
                                                                                                                                                       String MULTIPLY_TRAP = (String) multiplyTrapField.get(null);
                                                                                                                                                       
                                                                                                                                                       Field addTrapField = Dfp.class.getDeclaredField("ADD_TRAP");
                                                                                                                                                       addTrapField.setAccessible(true);
                                                                                                                                                       String ADD_TRAP = (String) addTrapField.get(null);
                                                                                                                                                       
                                                                                                                                                       Field flagInvalidField = DfpField.class.getDeclaredField("FLAG_INVALID");
                                                                                                                                                       flagInvalidField.setAccessible(true);
                                                                                                                                                       int FLAG_INVALID = flagInvalidField.getInt(null);
                                                                                                                                                       
                                                                                                                                                       Dfp result = mock(Dfp.class);
                                                                                                                                                       
                                                                                                                                                       // Mock the behavior to force trap path
                                                                                                                                                       Method multiplyFastMethod = Dfp.class.getDeclaredMethod("multiplyFast", int.class);
                                                                                                                                                       multiplyFastMethod.setAccessible(true);
                                                                                                                                                       when(dfp.multiply(anyInt())).thenAnswer(inv -> {
                                                                                                                                                           return multiplyFastMethod.invoke(realDfp, inv.getArgument(0));
                                                                                                                                                       });
                                                                                                                                                       when(result.isNaN()).thenReturn(true); // Force trap condition
                                                                                                                                                       
                                                                                                                                                       // Execute
                                                                                                                                                       dfp.multiply(5); // Use a value that would normally go to fast path
                                                                                                                                                       
                                                                                                                                                       // Verify the trap type was correct
                                                                                                                                                       verify(dfp).dotrap(eq(FLAG_INVALID), eq(MULTIPLY_TRAP), any(Dfp.class), eq(result));
                                                                                                                                                       
                                                                                                                                                       // Additional verification that ADD_TRAP was not used
                                                                                                                                                       verify(dfp, never()).dotrap(anyInt(), eq(ADD_TRAP), any(Dfp.class), any(Dfp.class));
                                                                                                                                                   }

    @Test
                                                                                                                                          public void testMultiplyDetectsMostSignificantDigitMutation() throws Exception {
                                                                                                                                              // Create a DfpField with sufficient radix digits
                                                                                                                                              DfpField field = new DfpField(10); // Assuming 10 radix digits
                                                                                                                                              
                                                                                                                                              // Create two numbers that will produce a product requiring more than mant.length digits
                                                                                                                                              // For example, numbers with most significant digits at opposite ends
                                                                                                                                              Dfp x = field.newDfp("1.234567890");
                                                                                                                                              Dfp y = field.newDfp("9.876543210");
                                                                                                                                              
                                                                                                                                              // Perform multiplication
                                                                                                                                              Dfp result = x.multiply(y);
                                                                                                                                              
                                                                                                                                              // Verify the result has correct most significant digits
                                                                                                                                              // The exact expected value depends on RADIX, but we can check it's not zero
                                                                                                                                              assertFalse("Result should not be zero", result.isZero());
                                                                                                                                              
                                                                                                                                              // Verify the exponent is calculated correctly
                                                                                                                                              // Original exponent sum is 0 + 0 = 0
                                                                                                                                              // For a product requiring full 2*mant.length digits, md would be 2*mant.length-1
                                                                                                                                              // So exp adjustment should be (2*mant.length-1) - 2*mant.length + 1 = 0
                                                                                                                                              
                                                                                                                                              // Use reflection to access protected exp field
                                                                                                                                              try {
                                                                                                                                                  Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                                                  expField.setAccessible(true);
                                                                                                                                                  int resultExp = expField.getInt(result);
                                                                                                                                                  assertEquals("Exponent should be correctly calculated", 0, resultExp);
                                                                                                                                              } catch (Exception e) {
                                                                                                                                                  fail("Failed to access exp field through reflection: " + e.getMessage());
                                                                                                                                              }
                                                                                                                                              
                                                                                                                                              // Verify the mantissa contains the full product
                                                                                                                                              // The exact product depends on RADIX implementation, but we can check some digits
                                                                                                                                              // For decimal-like behavior, we'd expect something like 12.193...
                                                                                                                                              Dfp ten = field.newDfp("10");
                                                                                                                                              Dfp thirteen = field.newDfp("13");
                                                                                                                                              assertTrue("Result should be greater than 10", result.greaterThan(ten));
                                                                                                                                              assertTrue("Result should be less than 13", result.lessThan(thirteen));
                                                                                                                                              
                                                                                                                                              // The mutant would fail to find the most significant digit properly,
                                                                                                                                              // likely resulting in a smaller number or zero
                                                                                                                                          }

    @Test
                                                                                                                              public void testMultiplyDetectsMutant() throws Exception {
                                                                                                                                  // Create a DfpField with sufficient radix digits to test the mutation
                                                                                                                                  DfpField field = new DfpField(20); // Using 20 digits for testing
                                                                                                                                  Dfp dfp = field.newDfp(0); // Create new Dfp instance initialized with 0
                                                                                                                                  
                                                                                                                                  // Use reflection to access protected fields
                                                                                                                                  java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                  mantField.setAccessible(true);
                                                                                                                                  int[] mant = (int[]) mantField.get(dfp);
                                                                                                                                  
                                                                                                                                  java.lang.reflect.Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                                  expField.setAccessible(true);
                                                                                                                                  
                                                                                                                                  // Fill the mantissa with maximum value (RADIX-1)
                                                                                                                                  int maxDigit = Dfp.RADIX - 1;
                                                                                                                                  for (int i = 0; i < mant.length; i++) {
                                                                                                                                      mant[i] = maxDigit;
                                                                                                                                  }
                                                                                                                                  expField.set(dfp, mant.length); // Set exponent to make this a large number
                                                                                                                                  
                                                                                                                                  // Multiply by a number that would require mant.length*2 digits
                                                                                                                                  // The original code would handle this correctly, mutant would fail
                                                                                                                                  int multiplier = Dfp.RADIX; // This forces use of multiplyFast when x >= RADIX
                                                                                                                                  
                                                                                                                                  // Calculate expected result - should be able to handle full multiplication
                                                                                                                                  Dfp expected = dfp.multiply(field.newDfp((double)multiplier));
                                                                                                                                  
                                                                                                                                  // Test the actual multiplication
                                                                                                                                  Dfp result = dfp.multiply(multiplier);
                                                                                                                                  
                                                                                                                                  // Verify the result matches expected
                                                                                                                                  assertEquals("Multiplication should handle carry-over correctly", 
                                                                                                                                             expected.toString(), result.toString());
                                                                                                                                  
                                                                                                                                  // Additional check - verify no digits were lost due to array bounds
                                                                                                                                  assertFalse("Result should not be zero for non-zero multiplication", 
                                                                                                                                            result.isZero());
                                                                                                                              }

    @Test
                                                                                                                         public void testMultiplyWithNegativeShouldUseSlowPath() {
                                                                                                                             // Setup
                                                                                                                             DfpField field = mock(DfpField.class);
                                                                                                                             Dfp dfp = mock(Dfp.class);
                                                                                                                             Dfp newInstance = mock(Dfp.class);
                                                                                                                             Dfp expectedResult = mock(Dfp.class);
                                                                                                                             
                                                                                                                             // Stub the slow path
                                                                                                                             when(dfp.newInstance(-1)).thenReturn(newInstance);
                                                                                                                             when(dfp.multiply(newInstance)).thenReturn(expectedResult);
                                                                                                                             
                                                                                                                             // Test
                                                                                                                             Dfp result = dfp.multiply(-1);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             verify(dfp, never()).newInstance(anyInt()); // Verify fast path wasn't used
                                                                                                                             verify(dfp).newInstance(-1);
                                                                                                                             verify(dfp).multiply(newInstance);
                                                                                                                             assertSame(expectedResult, result);
                                                                                                                         }

    @Test
                                                                                                                 public void testMultiplyWithZeroShouldUseFastPath() throws Exception {
                                                                                                                     // Setup
                                                                                                                     DfpField field = mock(DfpField.class);
                                                                                                                     when(field.getRadixDigits()).thenReturn(10); // Provide required mock behavior
                                                                                                                     
                                                                                                                     // Create real Dfp with value 1 using reflection to access protected constructor
                                                                                                                     Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                                     constructor.setAccessible(true);
                                                                                                                     Dfp dfp = spy(constructor.newInstance(field, 1));
                                                                                                                     
                                                                                                                     // Use reflection to access private multiplyFast method
                                                                                                                     Method multiplyFastMethod = Dfp.class.getDeclaredMethod("multiplyFast", int.class);
                                                                                                                     multiplyFastMethod.setAccessible(true);
                                                                                                                     
                                                                                                                     // Create expected result using newInstance
                                                                                                                     Dfp resultFromFastPath = dfp.newInstance(0);
                                                                                                                     
                                                                                                                     // Stub the fast path method using reflection
                                                                                                                     when(multiplyFastMethod.invoke(dfp, 0)).thenReturn(resultFromFastPath);
                                                                                                                     
                                                                                                                     // Test
                                                                                                                     Dfp result = dfp.multiply(0);
                                                                                                                     
                                                                                                                     // Verify
                                                                                                                     // Verify fast path was called using reflection
                                                                                                                     verify(dfp, times(1)).multiply(0);
                                                                                                                     verify(dfp, never()).newInstance(anyInt());
                                                                                                                     assertSame(resultFromFastPath, result);
                                                                                                                 }

    @Test
                                                                                                         public void testMultiplyWithPositiveInRangeShouldUseFastPath() {
                                                                                                             // Setup
                                                                                                             DfpField field = new DfpField(10); // Create real field with 10 radix digits
                                                                                                             Dfp dfp = field.getOne(); // Create Dfp with value 1 using field's factory method
                                                                                                             
                                                                                                             // Test with x=5 (0 < x < RADIX)
                                                                                                             Dfp expected = field.getOne().newInstance(5); // Expected result of 1 * 5 using factory method
                                                                                                             Dfp result = dfp.multiply(5);
                                                                                                             
                                                                                                             // Verify
                                                                                                             // Since we can't verify private method calls, we verify the behavior:
                                                                                                             // That multiplication with small positive numbers works correctly
                                                                                                             assertEquals(expected.toDouble(), result.toDouble(), 0.0001);
                                                                                                             
                                                                                                             // Alternative verification that doesn't rely on private methods:
                                                                                                             // The result should be equal to adding the number to itself x times
                                                                                                             Dfp manualResult = dfp;
                                                                                                             for (int i = 1; i < 5; i++) {
                                                                                                                 manualResult = manualResult.add(dfp);
                                                                                                             }
                                                                                                             assertEquals(manualResult.toDouble(), result.toDouble(), 0.0001);
                                                                                                         }

    @Test
                                                                                             public void testMultiplyWithZeroDigitInMantissa() throws Exception {
                                                                                                 // Create a DfpField with specific radix digits
                                                                                                 DfpField field = new DfpField(10); // Assuming 10 radix digits
                                                                                                 
                                                                                                 // Create first Dfp number with some zero digits in mantissa
                                                                                                 Dfp dfp1 = field.newDfp(); // Using newDfp() to create instance
                                                                                                 
                                                                                                 // Use reflection to set protected fields
                                                                                                 java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                 mantField.setAccessible(true);
                                                                                                 mantField.set(dfp1, new int[]{1, 0, 3, 0, 5, 0, 7, 0, 9, 0});
                                                                                                 
                                                                                                 java.lang.reflect.Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                 expField.setAccessible(true);
                                                                                                 expField.setInt(dfp1, 0);
                                                                                                 
                                                                                                 java.lang.reflect.Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                 signField.setAccessible(true);
                                                                                                 signField.setByte(dfp1, (byte)1);
                                                                                                 
                                                                                                 java.lang.reflect.Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                 nansField.setAccessible(true);
                                                                                                 nansField.setByte(dfp1, (byte)0); // Using 0 for FINITE
                                                                                                 
                                                                                                 // Create second Dfp number
                                                                                                 Dfp dfp2 = field.newDfp(); // Using newDfp() to create instance
                                                                                                 mantField.set(dfp2, new int[]{2, 4, 6, 8, 0, 2, 4, 6, 8, 0});
                                                                                                 expField.setInt(dfp2, 0);
                                                                                                 signField.setByte(dfp2, (byte)1);
                                                                                                 nansField.setByte(dfp2, (byte)0); // Using 0 for FINITE
                                                                                                 
                                                                                                 // Perform multiplication
                                                                                                 Dfp result = dfp1.multiply(dfp2);
                                                                                                 
                                                                                                 // Verify the result is not NaN
                                                                                                 assertFalse(result.isNaN());
                                                                                                 
                                                                                                 // Verify the multiplication was performed correctly
                                                                                                 assertFalse(result.isZero());
                                                                                                 
                                                                                                 // Additional verification - check sign is correct
                                                                                                 assertEquals(1, signField.getByte(result));
                                                                                                 
                                                                                                 // Verify no invalid flags were set
                                                                                                 final int FLAG_INVALID = 1; // Define FLAG_INVALID constant
                                                                                                 assertEquals(0, field.getIEEEFlags() & FLAG_INVALID);
                                                                                             }

    @Test
                                                                                    public void testMultiplyFiniteWithNonZeroMantissa() throws Exception {
                                                                                        // Create a field with some radix digits
                                                                                        DfpField field = new DfpField(10); // assuming 10 radix digits
                                                                                        final byte FINITE = 0; // Define FINITE constant
                                                                                        
                                                                                        // Create first finite Dfp with non-zero mantissa
                                                                                        Dfp dfp1 = field.newDfp(1.0); // non-zero value
                                                                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                        nansField.setAccessible(true);
                                                                                        nansField.set(dfp1, FINITE);
                                                                                        
                                                                                        // Create second finite Dfp (not infinite)
                                                                                        Dfp dfp2 = field.newDfp(2.0);
                                                                                        nansField.set(dfp2, FINITE);
                                                                                        
                                                                                        // Verify mantissa condition
                                                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                        mantField.setAccessible(true);
                                                                                        int[] mant1 = (int[]) mantField.get(dfp1);
                                                                                        assertNotEquals(0, mant1[mant1.length-1]);
                                                                                        
                                                                                        // Perform multiplication
                                                                                        Dfp result = dfp1.multiply(dfp2);
                                                                                        
                                                                                        // In original code, this would go to normal multiplication path
                                                                                        // In mutant, it would take the infinite path incorrectly
                                                                                        
                                                                                        // Verify it took the correct path by checking the result
                                                                                        // For finite * finite, result should be finite and equal to 2.0
                                                                                        assertEquals(FINITE, nansField.get(result));
                                                                                        assertEquals(2.0, result.toDouble(), 0.0001);
                                                                                        
                                                                                        // Also verify the sign is correct (1 * 1 = 1)
                                                                                        Field signField = Dfp.class.getDeclaredField("sign");
                                                                                        signField.setAccessible(true);
                                                                                        assertEquals(1, signField.get(result));
                                                                                    }

    @Test
                                                                                    public void testMultiplyDetectsMutant1() throws Exception {
                                                                                        // Create test objects
                                                                                        DfpField field = new DfpField(10); // Assuming 10 digits for simplicity
                                                                                        Dfp dfp = field.getZero(); // Use factory method instead of constructor
                                                                                        
                                                                                        // Use reflection to set protected fields
                                                                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                        nansField.setAccessible(true);
                                                                                        nansField.set(dfp, Dfp.FINITE);
                                                                                        
                                                                                        Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                        mantField.setAccessible(true);
                                                                                        int[] mant = new int[field.getRadixDigits()];
                                                                                        mant[mant.length-1] = 1; // Last digit non-zero
                                                                                        mantField.set(dfp, mant);
                                                                                        
                                                                                        // Create x parameter with FINITE nans
                                                                                        Dfp x = field.getZero(); // Use factory method
                                                                                        nansField.set(x, Dfp.FINITE);
                                                                                        
                                                                                        // Mock the multiply method to track if it's called
                                                                                        Dfp spyDfp = spy(dfp);
                                                                                        doReturn(field.getZero()).when(spyDfp).multiply(any(Dfp.class));
                                                                                        
                                                                                        // Call the method - should NOT take the fast path
                                                                                        int input = 5; // Within RADIX range
                                                                                        spyDfp.multiply(input);
                                                                                        
                                                                                        // Should call multiply with new instance
                                                                                        verify(spyDfp).multiply(any(Dfp.class));
                                                                                        
                                                                                        // Additional assertion to ensure mantissa condition is properly considered
                                                                                        int[] spyMant = (int[]) mantField.get(spyDfp);
                                                                                        assertNotEquals(0, spyMant[spyMant.length-1]);
                                                                                        assertEquals(Dfp.FINITE, nansField.get(spyDfp));
                                                                                        assertEquals(Dfp.FINITE, nansField.get(x));
                                                                                    }

    @Test
                                                                   public void testMultiplyInfiniteFiniteWithZeroLastDigit() throws Exception {
                                                                       // Create a finite Dfp with last mantissa digit = 0
                                                                       DfpField field = new DfpField(20); // Assuming 20 digits
                                                                       Dfp finite = field.getZero(); // Create zero using getZero()
                                                                       
                                                                       // Use reflection to access protected mant field
                                                                       Field mantField = Dfp.class.getDeclaredField("mant");
                                                                       mantField.setAccessible(true);
                                                                       int[] mant = (int[]) mantField.get(finite);
                                                                       mant[mant.length-1] = 0; // Force last digit to 0
                                                                       
                                                                       // Create an infinite Dfp using reflection
                                                                       Constructor<Dfp> infConstructor = Dfp.class.getDeclaredConstructor(
                                                                           DfpField.class, byte.class, byte.class);
                                                                       infConstructor.setAccessible(true);
                                                                       Dfp infinite = infConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                       
                                                                       // Test both multiplication orders
                                                                       Dfp result1 = finite.multiply(infinite);
                                                                       Dfp result2 = infinite.multiply(finite);
                                                                       
                                                                       // Both results should be infinite
                                                                       assertTrue(result1.isInfinite());
                                                                       assertTrue(result2.isInfinite());
                                                                       
                                                                       // Also test with non-zero last digit for completeness
                                                                       mant[mant.length-1] = 1;
                                                                       result1 = finite.multiply(infinite);
                                                                       result2 = infinite.multiply(finite);
                                                                       assertTrue(result1.isInfinite());
                                                                       assertTrue(result2.isInfinite());
                                                                   }

    @Test
                                               public void testMultiply_InfiniteTimesFiniteWithZeroMantissa() {
                                                   // Setup test objects
                                                   DfpField field = new DfpField(10); // Assuming 10 radix digits
                                                   
                                                   // Create infinite operand using public API
                                                   Dfp x = field.getOne().divide(field.getZero()); // This will create infinity
                                                   
                                                   // Create finite operand with zero last mantissa digit
                                                   Dfp finiteZero = field.getZero(); // Zero has all mantissa digits zero
                                                   
                                                   // Ensure it's finite and last mantissa digit is zero using public methods
                                                   assertFalse(finiteZero.isInfinite());
                                                   assertFalse(finiteZero.isNaN());
                                                   
                                                   // Get mantissa through reflection since it's protected
                                                   try {
                                                       Field mantField = Dfp.class.getDeclaredField("mant");
                                                       mantField.setAccessible(true);
                                                       int[] mant = (int[]) mantField.get(finiteZero);
                                                       assertEquals(0, mant[mant.length-1]);
                                                   } catch (Exception e) {
                                                       fail("Reflection failed: " + e.getMessage());
                                                   }
                                                   
                                                   // Clear any existing flags
                                                   field.setIEEEFlags(0);
                                                   
                                                   // Perform multiplication
                                                   Dfp result = finiteZero.multiply(x);
                                                   
                                                   // Verify results
                                                   // Should detect invalid operation and return QNAN
                                                   assertTrue(result.isNaN());
                                                   // Check that invalid operation flag was set
                                                   assertNotEquals(0, field.getIEEEFlags() & DfpField.FLAG_INVALID);
                                                   
                                                   // For mutant detection: The mutant would skip this case and potentially return wrong result
                                                   // So we specifically check the mantissa condition was properly handled
                                                   assertTrue(result.isNaN());
                                               }

    @Test
                                      public void testMultiplySetsInvalidFlagWhenNeeded() {
                                          // Setup
                                          DfpField field = new DfpField(10); // Assuming RADIX is 10 for this test
                                          Dfp dfp = field.newDfp(5); // Create Dfp with value 5 using newDfp
                                          
                                          // Test case that should trigger invalid flag
                                          // Using a value outside the fast path range to ensure we test the slow path
                                          int multiplier = 100; // Larger than RADIX
                                          
                                          // Mock the newInstance to return a problematic Dfp
                                          Dfp mockDfp = mock(Dfp.class);
                                          when(mockDfp.multiply(any(Dfp.class))).thenThrow(new ArithmeticException());
                                          
                                          Dfp spyDfp = spy(dfp);
                                          when(spyDfp.newInstance(multiplier)).thenReturn(mockDfp);
                                          
                                          try {
                                              // This should trigger the invalid flag
                                              spyDfp.multiply(multiplier);
                                              fail("Expected exception");
                                          } catch (ArithmeticException e) {
                                              // Verify the field flags were set
                                              verify(field).setIEEEFlagsBits(DfpField.FLAG_INVALID);
                                          }
                                          
                                          // Also test with NaN input
                                          Dfp nanDfp = field.newDfp((byte)1, Dfp.QNAN); // Create NaN using newDfp
                                          nanDfp.multiply(2);
                                          verify(field, atLeastOnce()).setIEEEFlagsBits(DfpField.FLAG_INVALID);
                                      }

    @Test
                                  public void testMultiplyDifferentRadixDigitsSetsInvalidFlag() {
                                      // Create two DfpField instances with different radix digits
                                      DfpField field1 = new DfpField(10);  // radix digits = 10
                                      DfpField field2 = new DfpField(20);  // radix digits = 20
                                      
                                      // Create Dfp instances from different fields
                                      Dfp dfp1 = field1.newDfp(1);  // value = 1
                                      Dfp dfp2 = field2.newDfp(2);  // value = 2
                                      
                                      // Clear any existing flags
                                      field1.clearIEEEFlags();
                                      
                                      // Perform multiplication - should trigger invalid flag
                                      Dfp result = dfp1.multiply(dfp2);
                                      
                                      try {
                                          // Use reflection to access protected nans field
                                          Field nansField = Dfp.class.getDeclaredField("nans");
                                          nansField.setAccessible(true);
                                          byte resultNans = (byte) nansField.get(result);
                                          
                                          // Verify the result is QNAN (assuming QNAN is 1)
                                          assertEquals(1, resultNans);
                                          
                                          // Verify the invalid flag was set
                                          assertTrue(field1.getIEEEFlags() != 0);  // Assuming any non-zero flag indicates error
                                          
                                          // Additional verification that the result is indeed NaN
                                          assertTrue(result.isNaN());
                                      } catch (Exception e) {
                                          fail("Reflection failed: " + e.getMessage());
                                      }
                                  }

    @Test
                         public void testMultiplyDetectsMostSignificantDigitMutation1() throws Exception {
                             // Create a DfpField with sufficient radix digits
                             DfpField field = new DfpField(10); // Assuming 10 radix digits for this test
                             
                             // Create two numbers that will produce a product with digits beyond mantissa length
                             // We'll use numbers close to the maximum value to ensure large product
                             Dfp num1 = field.newDfp("9999999999"); // 10-digit number
                             Dfp num2 = field.newDfp("9999999999"); // same 10-digit number
                             
                             // Multiply them - product should be 99999999980000000001 (20 digits)
                             Dfp result = num1.multiply(num2);
                             
                             // Verify the result contains the correct digits
                             // The most significant digits should be 9999999998
                             // If mutant is present, it would only look at first 10 digits and miss the '8'
                             
                             // Use reflection to access protected mant field
                             try {
                                 Field mantField = Dfp.class.getDeclaredField("mant");
                                 mantField.setAccessible(true);
                                 int[] mant = (int[]) mantField.get(result);
                                 
                                 // Check the mantissa contains the correct most significant digits
                                 // For a 10-digit mantissa, we expect the first digit to be 9999999998
                                 // (since product is 99999999980000000001)
                                 assertEquals(999999999, mant[mant.length - 1]);
                                 assertEquals(8, mant[mant.length - 2]);
                                 
                                 // Use reflection to access protected exp field
                                 Field expField = Dfp.class.getDeclaredField("exp");
                                 expField.setAccessible(true);
                                 int exp = (int) expField.get(result);
                                 
                                 // Verify the exponent is correctly calculated based on full product length
                                 // Original exponent would be (exp1 + exp2 + md - 2*mant.length + 1)
                                 // For md=19 (2*10-1), this would be correct
                                 // Mutant would use md=9, leading to wrong exponent
                                 assertEquals(1, exp); // Verify correct exponent calculation
                             } catch (NoSuchFieldException | IllegalAccessException e) {
                                 fail("Failed to access Dfp fields through reflection: " + e.getMessage());
                             }
                             
                             // Also verify the overall value is correct
                             assertEquals(field.newDfp("99999999980000000001").toString(), result.toString());
                         }

    @Test
                         public void testMultiplyFastWithLargeDigits() throws Exception {
                             // Create a DfpField with sufficient radix digits to test the mutation
                             DfpField field = new DfpField(20); // Using 20 digits to ensure we can test the boundary
                             
                             // Create a Dfp number with mantissa that will be affected by the mutation
                             // We need values that when multiplied will require processing of higher digits
                             Dfp dfp = field.getZero(); // Start with zero
                             
                             // Use reflection to access protected fields
                             java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                             mantField.setAccessible(true);
                             java.lang.reflect.Field expField = Dfp.class.getDeclaredField("exp");
                             expField.setAccessible(true);
                             
                             // Fill the mantissa with values that will overflow when multiplied
                             // Using maximum possible value for each digit (assuming base 10)
                             int multiplier = 9; // Using 9 as the maximum digit value in base 10
                             
                             // Get mantissa array and fill it
                             int[] mant = (int[]) mantField.get(dfp);
                             for (int i = 0; i < mant.length; i++) {
                                 mant[i] = multiplier;
                             }
                             mantField.set(dfp, mant);
                             
                             // Set exponent to make it a large number
                             expField.set(dfp, mant.length);
                             
                             // Multiply by a value that will cause carries beyond mant.length-1
                             // Using 2 (which is < 10) to ensure we take the fast path
                             Dfp result = dfp.multiply(2);
                             
                             // Verify the result is correct by checking it against the slow path
                             Dfp expected = dfp.multiply(field.getTwo());
                             
                             // The mutant will fail this assertion because it won't process all necessary digits
                             assertEquals(expected.toString(), result.toString());
                             
                             // Additional check - verify no digits were lost in multiplication
                             assertFalse(result.isZero()); // Ensure multiplication actually happened
                         }

    @Test
                    public void testMultiplyExponentMutation() throws Exception {
                        // Setup test environment
                        DfpField field = new DfpField(20); // Assuming DfpField constructor takes precision
                        Dfp base = field.getOne(); // Create Dfp with value 1
                        
                        // Set a known exponent (let's say 5) using reflection
                        Field expField = Dfp.class.getDeclaredField("exp");
                        expField.setAccessible(true);
                        expField.setInt(base, 5);
                        
                        // Multiply by a value that will trigger slow path (x >= RADIX)
                        // Assuming RADIX is 10000 from typical DFP implementations
                        int multiplier = 10000; 
                        Dfp result = base.multiply(multiplier);
                        
                        // Verify exponent is correct using reflection
                        // Original should be: base.exp (5) + multiplier's exponent (1) = 6
                        // Mutant would give: 7
                        int resultExp = expField.getInt(result);
                        assertEquals("Exponent should be base.exp + multiplier's exponent", 
                                     6, resultExp);
                        
                        // Also verify mantissa is correct to ensure full test coverage
                        Field mantField = Dfp.class.getDeclaredField("mant");
                        mantField.setAccessible(true);
                        int[] mant = (int[]) mantField.get(result);
                        assertTrue("Mantissa should be non-zero", mant[mant.length - 1] != 0);
                    }

    @Test
    public void testMultiplyResultZeroExponent() throws Exception {
        // Setup test field
        DfpField field = new DfpField(20); // Using arbitrary radix digits
        
        // Case 1: Simple zero multiplication (0 * x)
        Dfp zero = field.getZero();
        Dfp nonZero = field.newDfp(5); // Using int constructor
        Dfp result1 = zero.multiply(nonZero);
        assertTrue("Result should be zero for 0*5", result1.isZero());
        
        // Case 2: Another zero multiplication (x * 0)
        Dfp result2 = nonZero.multiply(zero);
        assertTrue("Result should be zero for 5*0", result2.isZero());
        
        // Case 3: Zero multiplied by infinity (0 * INFINITE)
        Dfp inf = field.newDfp(Double.POSITIVE_INFINITY); // Using double constructor
        Dfp result3 = zero.multiply(inf);
        assertTrue("Result should be NaN for 0*INFINITE", result3.isNaN());
        
        // Case 4: Infinity multiplied by zero (INFINITE * 0)
        Dfp result4 = inf.multiply(zero);
        assertTrue("Result should be NaN for INFINITE*0", result4.isNaN());
        
        // Case 5: Two very small numbers that multiply to zero
        Dfp verySmall1 = field.newDfp("1e-1000"); // Using String constructor
        Dfp verySmall2 = field.newDfp("1e-1000"); // Using String constructor
        Dfp result5 = verySmall1.multiply(verySmall2);
        if (result5.toString().contains("0.0")) {
            assertTrue("Result should be zero when product underflows", 
                      result5.isZero());
        }
    }


}
