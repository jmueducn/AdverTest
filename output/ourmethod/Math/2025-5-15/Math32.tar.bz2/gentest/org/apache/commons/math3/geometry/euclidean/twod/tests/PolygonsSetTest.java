package gentest.org.apache.commons.math3.geometry.euclidean.twod.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.twod.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.apache.commons.math3.exception.MathInternalError;
import org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D;
import org.apache.commons.math3.geometry.euclidean.oned.Interval;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane;
import org.apache.commons.math3.geometry.partitioning.BSPTree;
import org.apache.commons.math3.geometry.partitioning.BSPTreeVisitor;
import org.apache.commons.math3.geometry.partitioning.BoundaryAttribute;
import org.apache.commons.math3.geometry.partitioning.SubHyperplane;
import org.apache.commons.math3.geometry.partitioning.AbstractRegion;
import org.apache.commons.math3.geometry.partitioning.utilities.AVLTree;
import org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple;
import org.apache.commons.math3.util.FastMath;
 
public class PolygonsSetTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                               public void testComputeGeometricalProperties_EmptyVertices_EmptySpace() throws Exception {
                                   // Setup
                                   BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                   when(tree.getCut()).thenReturn(null);
                                   when(tree.getAttribute()).thenReturn(false);
                                   
                                   // Create real PolygonsSet with the mocked tree
                                   PolygonsSet polygon = new PolygonsSet(tree);
                                   
                                   // Mock getVertices to return empty array
                                   PolygonsSet polygonSpy = spy(polygon);
                                   when(polygonSpy.getVertices()).thenReturn(new Vector2D[0][]);
                                   
                                   // Execute
                                   Method method = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                   method.setAccessible(true);
                                   method.invoke(polygonSpy);
                                   
                                   // Verify results through public methods
                                   assertEquals(0, polygonSpy.getSize(), 1.0e-10);
                                   assertEquals(new Vector2D(0, 0), polygonSpy.getBarycenter());
                               }

    @Test
                               public void testComputeGeometricalProperties_OpenLoop() throws Exception {
                                   // Setup - create a PolygonsSet with open-loop vertices
                                   Vector2D[][] vertices = new Vector2D[1][];
                                   vertices[0] = new Vector2D[1]; // null first element indicates open loop
                                   PolygonsSet polygon = new PolygonsSet();
                                   
                                   // Use reflection to set vertices
                                   Field verticesField = PolygonsSet.class.getDeclaredField("vertices");
                                   verticesField.setAccessible(true);
                                   verticesField.set(polygon, vertices);
                                   
                                   // Execute
                                   Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                   computeMethod.setAccessible(true);
                                   computeMethod.invoke(polygon);
                                   
                                   // Verify using reflection
                                   Field sizeField = AbstractRegion.class.getDeclaredField("size");
                                   sizeField.setAccessible(true);
                                   assertEquals(Double.POSITIVE_INFINITY, sizeField.getDouble(polygon));
                                   
                                   Field barycenterField = AbstractRegion.class.getDeclaredField("barycenter");
                                   barycenterField.setAccessible(true);
                                   Vector2D barycenter = (Vector2D) barycenterField.get(polygon);
                                   assertTrue(Double.isNaN(barycenter.getX()));
                                   assertTrue(Double.isNaN(barycenter.getY()));
                               }

    @Test
                               public void testComputeGeometricalProperties_SingleClosedLoop_FiniteArea() {
                                   // Setup
                                   PolygonsSet polygon = new PolygonsSet();
                                   Vector2D[][] vertices = {
                                       {
                                           new Vector2D(0, 0),
                                           new Vector2D(1, 0),
                                           new Vector2D(1, 1),
                                           new Vector2D(0, 1)
                                       }
                                   };
                                   
                                   // Use reflection to set private vertices field
                                   try {
                                       java.lang.reflect.Field field = PolygonsSet.class.getDeclaredField("vertices");
                                       field.setAccessible(true);
                                       field.set(polygon, vertices);
                                   } catch (Exception e) {
                                       fail("Failed to set vertices field via reflection");
                                   }
                                   
                                   // Execute computeGeometricalProperties via reflection
                                   try {
                                       java.lang.reflect.Method method = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                       method.setAccessible(true);
                                       method.invoke(polygon);
                                   } catch (Exception e) {
                                       fail("Failed to invoke computeGeometricalProperties via reflection");
                                   }
                                   
                                   // Verify size should be 1.0 for 1x1 square
                                   assertEquals(1.0, polygon.getSize(), 1e-10);
                                   
                                   // Verify barycenter should be at (0.5, 0.5)
                                   Vector2D barycenter = (Vector2D) polygon.getBarycenter();
                                   assertEquals(0.5, barycenter.getX(), 1e-10);
                                   assertEquals(0.5, barycenter.getY(), 1e-10);
                               }

    @Test
                               public void testComputeGeometricalProperties_MultipleClosedLoops_FiniteArea() {
                                   // Setup
                                   PolygonsSet polygon = new PolygonsSet();
                                   Vector2D[][] vertices = {
                                       { // Outer square
                                           new Vector2D(0, 0),
                                           new Vector2D(2, 0),
                                           new Vector2D(2, 2),
                                           new Vector2D(0, 2)
                                       },
                                       { // Inner square (hole)
                                           new Vector2D(0.5, 0.5),
                                           new Vector2D(0.5, 1.5),
                                           new Vector2D(1.5, 1.5),
                                           new Vector2D(1.5, 0.5)
                                       }
                                   };
                                   
                                   // Use reflection to set private vertices field
                                   try {
                                       java.lang.reflect.Field field = PolygonsSet.class.getDeclaredField("vertices");
                                       field.setAccessible(true);
                                       field.set(polygon, vertices);
                                   } catch (Exception e) {
                                       fail("Failed to set vertices field via reflection");
                                   }
                                   
                                   // Execute - call protected method via reflection
                                   try {
                                       java.lang.reflect.Method method = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                       method.setAccessible(true);
                                       method.invoke(polygon);
                                   } catch (Exception e) {
                                       fail("Failed to invoke computeGeometricalProperties via reflection");
                                   }
                                   
                                   // Verify size should be 4 (outer) - 1 (inner) = 3
                                   assertEquals(3.0, polygon.getSize(), 1e-10);
                                   
                                   // Verify barycenter should be at (1, 1)
                                   Vector2D barycenter = (Vector2D) polygon.getBarycenter();
                                   assertEquals(1.0, barycenter.getX(), 1e-10);
                                   assertEquals(1.0, barycenter.getY(), 1e-10);
                               }

    @Test
                               public void testComputeGeometricalProperties_DegeneratePolygon_ZeroArea() {
                                   // Setup - a line segment (degenerate polygon)
                                   PolygonsSet polygon = new PolygonsSet();
                                   Vector2D[][] vertices = {
                                       {
                                           new Vector2D(0, 0),
                                           new Vector2D(1, 1),
                                           new Vector2D(2, 2)
                                       }
                                   };
                                   
                                   // Use reflection to set private vertices field
                                   try {
                                       java.lang.reflect.Field field = PolygonsSet.class.getDeclaredField("vertices");
                                       field.setAccessible(true);
                                       field.set(polygon, vertices);
                                   } catch (Exception e) {
                                       fail("Failed to set vertices field via reflection");
                                   }
                                   
                                   // Execute computeGeometricalProperties via reflection
                                   try {
                                       java.lang.reflect.Method method = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                       method.setAccessible(true);
                                       method.invoke(polygon);
                                   } catch (Exception e) {
                                       fail("Failed to invoke computeGeometricalProperties via reflection");
                                   }
                                   
                                   // Verify
                                   assertEquals(0.0, polygon.getSize(), 1e-10);
                                   // Barycenter should still be calculated (average of points)
                                   Vector2D barycenter = (Vector2D) polygon.getBarycenter();
                                   assertEquals(1.0, barycenter.getX(), 1e-10);
                                   assertEquals(1.0, barycenter.getY(), 1e-10);
                               }

    @Test
                           public void testComputeGeometricalProperties_NegativeSum_InfiniteArea() {
                               // Setup - a clockwise square (negative area)
                               PolygonsSet polygon = new PolygonsSet();
                               org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vertices = {
                                   {
                                       new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0, 0),
                                       new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0, 1),
                                       new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1, 1),
                                       new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1, 0)
                                   }
                               };
                               
                               // Use reflection to set private vertices field
                               try {
                                   java.lang.reflect.Field field = PolygonsSet.class.getDeclaredField("vertices");
                                   field.setAccessible(true);
                                   field.set(polygon, vertices);
                               } catch (Exception e) {
                                   fail("Failed to set vertices field via reflection");
                               }
                               
                               // Use reflection to call protected computeGeometricalProperties method
                               try {
                                   java.lang.reflect.Method method = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                   method.setAccessible(true);
                                   method.invoke(polygon);
                               } catch (Exception e) {
                                   fail("Failed to invoke computeGeometricalProperties via reflection");
                               }
                               
                               // Verify
                               assertEquals(Double.POSITIVE_INFINITY, polygon.getSize(), 1e-10);
                               
                               // Verify barycenter is not finite (NaN or infinite)
                               try {
                                   java.lang.reflect.Method getBarycenter = PolygonsSet.class.getDeclaredMethod("getBarycenter");
                                   getBarycenter.setAccessible(true);
                                   Object barycenter = getBarycenter.invoke(polygon);
                                   if (barycenter instanceof org.apache.commons.math3.geometry.euclidean.twod.Vector2D) {
                                       org.apache.commons.math3.geometry.euclidean.twod.Vector2D v = 
                                           (org.apache.commons.math3.geometry.euclidean.twod.Vector2D)barycenter;
                                       assertTrue(Double.isNaN(v.getX()) || Double.isInfinite(v.getX()));
                                       assertTrue(Double.isNaN(v.getY()) || Double.isInfinite(v.getY()));
                                   } else {
                                       fail("Barycenter is not a Vector2D");
                                   }
                               } catch (Exception e) {
                                   fail("Failed to verify barycenter properties");
                               }
                           }

    @Test
                   public void testComputeGeometricalProperties_EmptyVertices_WholeSpace() throws Exception {
                       // Setup
                       PolygonsSet polygon = mock(PolygonsSet.class);
                       when(polygon.getVertices()).thenReturn(new Vector2D[0][]);
                       
                       BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                       when(tree.getCut()).thenReturn(null);
                       when(tree.getAttribute()).thenReturn(true);
                       when(polygon.getTree(false)).thenReturn(tree);
                       
                       // Create a real instance to verify behavior
                       PolygonsSet realPolygon = new PolygonsSet(tree);
                       
                       // Use reflection to access protected method
                       Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                       computeMethod.setAccessible(true);
                       
                       // Execute
                       computeMethod.invoke(realPolygon);
                       
                       // Verify the expected behavior through public methods
                       assertEquals(Double.POSITIVE_INFINITY, realPolygon.getSize(), 0.0);
                       
                       // Alternative verification since getBarycenter() might not be available
                       // Check if barycenter is stored in a field
                       try {
                           Field barycenterField = PolygonsSet.class.getDeclaredField("barycenter");
                           barycenterField.setAccessible(true);
                           Vector2D barycenter = (Vector2D) barycenterField.get(realPolygon);
                           assertTrue(Double.isNaN(barycenter.getX()));
                           assertTrue(Double.isNaN(barycenter.getY()));
                       } catch (NoSuchFieldException e) {
                           // If barycenter field doesn't exist, skip those assertions
                           // or verify through other means
                       }
                   }

    @Test
              public void testComputeGeometricalProperties_DetectsY1Mutation() throws Exception {
                  // Create a simple quadrilateral polygon where first and last Y coordinates differ
                  Vector2D[] loop = new Vector2D[] {
                      new Vector2D(0, 0),    // first point (y=0)
                      new Vector2D(2, 0),
                      new Vector2D(2, 2),
                      new Vector2D(0, 1)     // last point (y=1)
                  };
                  Vector2D[][] vertices = new Vector2D[][] { loop };
                  
                  // Create a real PolygonsSet but mock just the getVertices() method
                  PolygonsSet polygon = mock(PolygonsSet.class);
                  when(polygon.getVertices()).thenReturn(vertices);
                  
                  // Expected values calculated using correct shoelace formula
                  double expectedSize = 3.0;  // Correct area for this polygon
                  Vector2D expectedBarycenter = new Vector2D(1.0, 1.0);  // Correct centroid
                  
                  // Call the method (using reflection since it's protected)
                  Method method = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                  method.setAccessible(true);
                  method.invoke(polygon);
                  
                  // Verify the results by checking the fields that would be set by the protected methods
                  Field sizeField = AbstractRegion.class.getDeclaredField("size");
                  sizeField.setAccessible(true);
                  double actualSize = sizeField.getDouble(polygon);
                  
                  Field barycenterField = AbstractRegion.class.getDeclaredField("barycenter");
                  barycenterField.setAccessible(true);
                  Vector2D actualBarycenter = (Vector2D) barycenterField.get(polygon);
                  
                  assertEquals(expectedSize, actualSize, 1.0e-10);
                  assertEquals(expectedBarycenter.getX(), actualBarycenter.getX(), 1.0e-10);
                  assertEquals(expectedBarycenter.getY(), actualBarycenter.getY(), 1.0e-10);
              }

    @Test
         public void testComputeGeometricalProperties_ZeroSum() {
             // Create a degenerate polygon (triangle with zero area)
             Vector2D[] loop = new Vector2D[] {
                 new Vector2D(0, 0),
                 new Vector2D(1, 1),
                 new Vector2D(2, 2),
                 new Vector2D(0, 0)  // closing the loop
             };
             Vector2D[][] vertices = new Vector2D[][] { loop };
             
             // Create a real PolygonsSet instance
             PolygonsSet polygon = new PolygonsSet();
             
             // Mock the getVertices() method to return our test vertices
             PolygonsSet spyPolygon = spy(polygon);
             when(spyPolygon.getVertices()).thenReturn(vertices);
             
             // Use reflection to test the protected method
             try {
                 Method method = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                 method.setAccessible(true);
                 method.invoke(spyPolygon);
                 
                 // Verify the results through public methods or reflection
                 // Since size is protected, we need to get it through reflection
                 Method getSizeMethod = AbstractRegion.class.getDeclaredMethod("getSize");
                 getSizeMethod.setAccessible(true);
                 double size = (Double) getSizeMethod.invoke(spyPolygon);
                 assertEquals(0.0, size, 1.0e-15);
                 
                 Method getBarycenterMethod = AbstractRegion.class.getDeclaredMethod("getBarycenter");
                 getBarycenterMethod.setAccessible(true);
                 Vector2D barycenter = (Vector2D) getBarycenterMethod.invoke(spyPolygon);
                 assertNotNull(barycenter);
             } catch (Exception e) {
                 fail("Exception occurred during test: " + e.getMessage());
             }
         }

    @Test
    public void testComputeGeometricalProperties_NegativeSum() {
        // Create a simple triangle with clockwise vertices (will produce negative area)
        Vector2D[] triangle = new Vector2D[] {
            new Vector2D(0, 0),
            new Vector2D(1, 0),
            new Vector2D(0, 1)
        };
        Vector2D[][] vertices = new Vector2D[][] { triangle };
        
        // Create a real PolygonsSet instance
        PolygonsSet polygon = new PolygonsSet();
        
        // Use reflection to set the vertices
        try {
            // Set the vertices field
            Field verticesField = PolygonsSet.class.getDeclaredField("vertices");
            verticesField.setAccessible(true);
            verticesField.set(polygon, vertices);
            
            // Test the protected method
            Method method = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
            method.setAccessible(true);
            method.invoke(polygon);
            
            // Verify the results by checking the internal state
            Method getSize = PolygonsSet.class.getDeclaredMethod("getSize");
            getSize.setAccessible(true);
            double size = (Double) getSize.invoke(polygon);
            assertEquals(Double.POSITIVE_INFINITY, size, 0.0);
            
            Method getBarycenter = PolygonsSet.class.getDeclaredMethod("getBarycenter");
            getBarycenter.setAccessible(true);
            Vector2D barycenter = (Vector2D) getBarycenter.invoke(polygon);
            assertTrue(Double.isNaN(barycenter.getX()) && Double.isNaN(barycenter.getY()));
            
        } catch (Exception e) {
            fail("Exception occurred during test: " + e.getMessage());
        }
    }


}
