package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.io.PrintStream;
 
public class FastMathTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                    public void testPow_NaNExponent() {
                                                                                                        // Test with positive base
                                                                                                        assertTrue(Double.isNaN(FastMath.pow(2.0, Double.NaN)));
                                                                                                    }

 @Test
                                                                                    public void testPow_ZeroExponent() {
                                                                                        assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(0.0, 0.0), 1e-15);
                                                                                        assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(-1.0, 0.0), 1e-15);
                                                                                        assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(Double.NEGATIVE_INFINITY, 0.0), 1e-15);
                                                                                        assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(Double.NaN, 0.0), 1e-15);
                                                                                    }

 @Test
                                                                        public void testPow_NegativeInfinityBase() {
                                                                            // Test even positive exponent
                                                                            assertEquals(Double.POSITIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(Double.NEGATIVE_INFINITY, 2.0), 0.0);
                                                                            
                                                                            // Test odd positive exponent
                                                                            assertEquals(Double.NEGATIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(Double.NEGATIVE_INFINITY, 3.0), 0.0);
                                                                            
                                                                            // Test even negative exponent
                                                                            assertEquals(0.0, org.apache.commons.math3.util.FastMath.pow(Double.NEGATIVE_INFINITY, -2.0), 0.0);
                                                                            
                                                                            // Test odd negative exponent
                                                                            assertEquals(-0.0, org.apache.commons.math3.util.FastMath.pow(Double.NEGATIVE_INFINITY, -3.0), 0.0);
                                                                            
                                                                            // Test zero exponent
                                                                            assertTrue(Double.isNaN(org.apache.commons.math3.util.FastMath.pow(Double.NEGATIVE_INFINITY, 0.0)));
                                                                        }

 @Test
                                                                        public void testPow_FractionalBase() {
                                                                            // Test with fractional bases
                                                                            assertEquals(0.0009765625, org.apache.commons.math3.util.FastMath.pow(0.5, 10), 1e-15);
                                                                            assertEquals(1024.0, org.apache.commons.math3.util.FastMath.pow(0.5, -10), 1e-12);
                                                                            assertEquals(0.001, org.apache.commons.math3.util.FastMath.pow(0.1, 3), 1e-15);
                                                                            assertEquals(1000.0, org.apache.commons.math3.util.FastMath.pow(0.1, -3), 1e-12);
                                                                        }

 @Test
                                                                    public void testPow_NaNBase() {
                                                                        // Test with positive exponent
                                                                        assertTrue(Double.isNaN(org.apache.commons.math3.util.FastMath.pow(Double.NaN, 2.0)));
                                                                        // Test with zero exponent
                                                                        assertTrue(Double.isNaN(org.apache.commons.math3.util.FastMath.pow(Double.NaN, 0.0)));
                                                                        // Test with negative exponent
                                                                        assertTrue(Double.isNaN(org.apache.commons.math3.util.FastMath.pow(Double.NaN, -2.0)));
                                                                    }

 @Test
                                                                    public void testPow_NegativeBaseWithNonIntegerExponent() {
                                                                        double negativeBase = -2.0;
                                                                        double nonIntegerExponent1 = 2.5;
                                                                        double nonIntegerExponent2 = -2.5;
                                                                        
                                                                        assertTrue(Double.isNaN(FastMath.pow(negativeBase, nonIntegerExponent1)));
                                                                        assertTrue(Double.isNaN(FastMath.pow(negativeBase, nonIntegerExponent2)));
                                                                    }

 @Test
                                                    public void testPow_NegativeZeroBase() {
                                                        // Test negative zero base with various exponents
                                                        assertEquals(-0.0, FastMath.pow(-0.0, 3.0), 0.0);
                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(-0.0, -2.0), 0.0);
                                                        assertEquals(0.0, FastMath.pow(-0.0, 2.0), 0.0);
                                                        assertEquals(1.0, FastMath.pow(-0.0, 0.0), 0.0);
                                                    }

 @Test
                                                    public void testPow_ZeroExponent1() {
                                                        // Test various cases where exponent is 0
                                                        double negOne = -1.0;
                                                        double posInf = Double.POSITIVE_INFINITY;
                                                        double negInf = Double.NEGATIVE_INFINITY;
                                                    }

 @Test
                                                public void testPowWithZeroBaseDetectsMutant() {
                                                    // Test case where x=0 and y is an odd integer
                                                    // Original behavior: Handled by special case for x==0
                                                    // Mutated behavior: Incorrectly enters negative number logic
                                                    
                                                    // Test with positive odd integer y
                                                    double result1 = FastMath.pow(0.0, 3.0);
                                                    assertEquals(0.0, result1, 0.0);
                                                    
                                                    // Test with negative odd integer y
                                                    double result2 = FastMath.pow(0.0, -3.0);
                                                    assertEquals(Double.POSITIVE_INFINITY, result2, 0.0);
                                                    
                                                    // Test with positive even integer y
                                                    double result3 = FastMath.pow(0.0, 4.0);
                                                    assertEquals(0.0, result3, 0.0);
                                                    
                                                    // Test with negative even integer y
                                                    double result4 = FastMath.pow(0.0, -4.0);
                                                    assertEquals(Double.POSITIVE_INFINITY, result4, 0.0);
                                                    
                                                    // Test with non-integer y
                                                    double result5 = FastMath.pow(0.0, 3.5);
                                                    assertEquals(0.0, result5, 0.0);
                                                    
                                                    // Test with negative non-integer y
                                                    double result6 = FastMath.pow(0.0, -3.5);
                                                    assertEquals(Double.POSITIVE_INFINITY, result6, 0.0);
                                                    
                                                    // Test with y=0 (special case)
                                                    double result7 = FastMath.pow(0.0, 0.0);
                                                    assertEquals(1.0, result7, 0.0);
                                                }

 @Test
                                                public void testPowWithZeroExponent() {
                                                    // Test with e=0 which should return 1.0 without any inversion
                                                    double d = 2.0;
                                                    int e = 0;
                                                    double result = FastMath.pow(d, e);
                                                    assertEquals(1.0, result, 0.0);
                                                    
                                                    // Also test with negative exponent to ensure that still works
                                                    e = -2;
                                                    result = FastMath.pow(d, e);
                                                    assertEquals(0.25, result, 0.0000000001);
                                                    
                                                    // Test with positive exponent for completeness
                                                    e = 3;
                                                    result = FastMath.pow(d, e);
                                                    assertEquals(8.0, result, 0.0000000001);
                                                    
                                                    // Edge case: e=0 with d=0 (should return 1.0)
                                                    d = 0.0;
                                                    e = 0;
                                                    result = FastMath.pow(d, e);
                                                    assertEquals(1.0, result, 0.0);
                                                    
                                                    // Edge case: e=0 with d=1.0 (should return 1.0)
                                                    d = 1.0;
                                                    e = 0;
                                                    result = FastMath.pow(d, e);
                                                    assertEquals(1.0, result, 0.0);
                                                }

 @Test
                                              public void testPowNegativeXWithBoundaryYValues() {
                                                  // Setup
                                                  double negativeX = -2.0;
                                                  // TWO_POWER_53 is 2^53 (9007199254740992.0)
                                                  double twoPower53 = 9007199254740992.0;
                                                  
                                                  // Test case where y exactly equals TWO_POWER_53
                                                  double y1 = twoPower53;
                                                  double result1 = FastMath.pow(negativeX, y1);
                                                  // Should use the special case handling (pow(-x,y)) since y >= TWO_POWER_53
                                                  double expected1 = FastMath.pow(-negativeX, y1);
                                                  assertEquals(expected1, result1, 0.0);
                                                  
                                                  // Test case where y exactly equals -TWO_POWER_53
                                                  double y2 = -twoPower53;
                                                  double result2 = FastMath.pow(negativeX, y2);
                                                  // Should use the special case handling (pow(-x,y)) since y <= -TWO_POWER_53
                                                  double expected2 = FastMath.pow(-negativeX, y2);
                                                  assertEquals(expected2, result2, 0.0);
                                                  
                                                  // Additional test case where y is just below TWO_POWER_53 to ensure the boundary is tested
                                                  double y3 = twoPower53 - 1;
                                                  double result3 = FastMath.pow(negativeX, y3);
                                                  // Should NOT use the special case handling since y < TWO_POWER_53 (but original condition was <=)
                                                  // This helps verify the original behavior vs mutated behavior
                                                  double expected3 = FastMath.pow(negativeX, y3);
                                                  assertEquals(expected3, result3, 0.0);
                                              }

 @Test
                                              public void testPowBoundaryConditions() {
                                                  // Test exact boundary values that would be affected by the mutation
                                                  double twoPower53 = 9007199254740992.0; // 2^53
                                                  double negativeTwoPower53 = -9007199254740992.0;
                                                  
                                                  // Test positive boundary
                                                  double base1 = 1.5;
                                                  int exponent1 = (int)twoPower53;
                                                  double result1 = FastMath.pow(base1, exponent1);
                                                  // Compare with standard Math.pow for verification
                                                  assertEquals(Math.pow(base1, exponent1), result1, 1e-10);
                                                  
                                                  // Test negative boundary
                                                  double base2 = 1.5;
                                                  int exponent2 = (int)negativeTwoPower53;
                                                  double result2 = FastMath.pow(base2, exponent2);
                                                  assertEquals(Math.pow(base2, -exponent2), 1.0/result2, 1e-10);
                                                  
                                                  // Test values just inside the boundary
                                                  double base3 = 1.5;
                                                  int exponent3 = (int)twoPower53 - 1;
                                                  double result3 = FastMath.pow(base3, exponent3);
                                                  assertEquals(Math.pow(base3, exponent3), result3, 1e-10);
                                                  
                                                  // Test values just outside the boundary
                                                  double base4 = 1.5;
                                                  int exponent4 = (int)twoPower53 + 1;
                                                  double result4 = FastMath.pow(base4, exponent4);
                                                  assertEquals(Math.pow(base4, exponent4), result4, 1e-10);
                                              }

 @Test
                                          public void testPowWithAlmostIntegerExponent() {
                                              // Test with negative base and exponent very close to integer
                                              double x = -2.0;
                                              double y = 3.0000000001; // Very close to 3 but not exactly equal
                                              
                                              // Original behavior: should return NaN because y is not exactly an integer
                                              // Mutated behavior: will treat it as integer and return a value
                                              double result = FastMath.pow(x, y);
                                              
                                              // Verify the result is NaN (original behavior)
                                              assertTrue(Double.isNaN(result));
                                              
                                              // Additional test case with exponent just below the threshold
                                              y = 3.000000001; // More than 1e-10 difference
                                              result = FastMath.pow(x, y);
                                              assertTrue(Double.isNaN(result));
                                              
                                              // Test with exponent within 1e-10 of integer
                                              y = 3.00000000009; // Less than 1e-10 difference
                                              result = FastMath.pow(x, y);
                                              // Original would return NaN, mutant would return -8.0
                                              assertTrue(Double.isNaN(result));
                                              
                                              // Test with exactly integer exponent for reference
                                              y = 3.0;
                                              result = FastMath.pow(x, y);
                                              assertEquals(-8.0, result, 0.0);
                                          }

 @Test
                                          public void testPowWithAlmostIntegerExponent1() {
                                              // Test with exactly integer exponent (should pass both original and mutant)
                                              assertEquals(8.0, FastMath.pow(2.0, 3.0), 1e-10);
                                              
                                              // Test with clearly non-integer exponent (should pass both original and mutant)
                                              assertEquals(4.0, FastMath.pow(2.0, 2.0), 1e-10);
                                              assertEquals(Math.pow(2.0, 2.1), FastMath.pow(2.0, 2.1), 1e-10);
                                              
                                              // Test with exponent very close to integer (difference < 1e-10)
                                              // This is the key test that should detect the mutant
                                              double almostThree = 3.0 + 1e-11; // 3.00000000001
                                              double originalResult = Math.pow(2.0, almostThree);
                                              double mutantResult = FastMath.pow(2.0, almostThree);
                                              
                                              // The mutant would treat this as integer 3, while original wouldn't
                                              assertNotEquals(8.0, mutantResult, 1e-10); // Should be approximately 8.00000000002
                                              assertEquals(originalResult, mutantResult, 1e-10);
                                              
                                              // Test with exponent very close to integer but negative
                                              double almostMinusTwo = -2.0 + 1e-11; // -1.99999999999
                                              originalResult = Math.pow(2.0, almostMinusTwo);
                                              mutantResult = FastMath.pow(2.0, almostMinusTwo);
                                              
                                              assertNotEquals(0.25, mutantResult, 1e-10); // Should be approximately 0.25000000000
                                              assertEquals(originalResult, mutantResult, 1e-10);
                                          }

 @Test
                                         public void testPowWithNegativeXAndOddIntegerY() {
                                             // Test with negative x and odd integer y
                                             double negativeX = -2.0;
                                             double oddY = 3.0; // odd integer
                                             
                                             // Original should return negative result for odd y
                                             double expected = -FastMath.pow(-negativeX, oddY);
                                             double actual = FastMath.pow(negativeX, oddY);
                                             
                                             // This assertion will fail with the mutant
                                             assertEquals("Negative base with odd exponent should return negative result", 
                                                         expected, actual, 0.0);
                                             
                                             // Additional test with even y to show correct behavior
                                             double evenY = 2.0; // even integer
                                             assertEquals("Negative base with even exponent should return positive result",
                                                         FastMath.pow(-negativeX, evenY), 
                                                         FastMath.pow(negativeX, evenY), 0.0);
                                             
                                             // Test edge case with y = 1 (smallest odd positive integer)
                                             assertEquals("Negative base with y=1 should return negative result",
                                                         -FastMath.pow(-negativeX, 1.0),
                                                         FastMath.pow(negativeX, 1.0), 0.0);
                                             
                                             // Test edge case with y = -1 (smallest odd negative integer)
                                             assertEquals("Negative base with y=-1 should return negative result",
                                                         -FastMath.pow(-negativeX, -1.0),
                                                         FastMath.pow(negativeX, -1.0), 0.0);
                                         }

 @Test
                                             public void testPowWithNegativeBaseAndOddExponent() {
                                                 // Test case where base is negative and exponent is odd
                                                 // Should return negative result
                                                 double base = -2.0;
                                                 int oddExponent = 3;
                                                 
                                                 double result = FastMath.pow(base, oddExponent);
                                                 
                                                 // Verify the result is negative and correct
                                                 assertTrue("Result should be negative for negative base with odd exponent", 
                                                           result < 0);
                                                 assertEquals("Result value should be correct", 
                                                             -8.0, result, 0.0001);
                                             }

 @Test
                                             public void testPowWithNegativeBaseAndEvenExponent() {
                                                 // Test case where base is negative and exponent is even
                                                 // Should return positive result
                                                 double base = -2.0;
                                                 int evenExponent = 4;
                                                 
                                                 double result = FastMath.pow(base, evenExponent);
                                                 
                                                 // Verify the result is positive and correct
                                                 assertTrue("Result should be positive for negative base with even exponent", 
                                                           result > 0);
                                                 assertEquals("Result value should be correct", 
                                                             16.0, result, 0.0001);
                                             }

 @Test
                                             public void testPowWithNegativeBaseAndNegativeOddExponent() {
                                                 // Test case where base is negative and exponent is negative odd
                                                 // Should return negative result
                                                 double base = -2.0;
                                                 int negativeOddExponent = -3;
                                                 
                                                 double result = FastMath.pow(base, negativeOddExponent);
                                                 
                                                 // Verify the result is negative and correct
                                                 assertTrue("Result should be negative for negative base with odd exponent", 
                                                           result < 0);
                                                 assertEquals("Result value should be correct", 
                                                             -0.125, result, 0.0001);
                                             }

 @Test
                                             public void testPowWithNegativeBaseAndNegativeEvenExponent() {
                                                 // Test case where base is negative and exponent is negative even
                                                 // Should return positive result
                                                 double base = -2.0;
                                                 int negativeEvenExponent = -4;
                                                 
                                                 double result = FastMath.pow(base, negativeEvenExponent);
                                                 
                                                 // Verify the result is positive and correct
                                                 assertTrue("Result should be positive for negative base with even exponent", 
                                                           result > 0);
                                                 assertEquals("Result value should be correct", 
                                                             0.0625, result, 0.0001);
                                             }

 @Test
                                        public void testPowForLargeYValues() {
                                            // Test case where y is larger than 8e298
                                            double x = 2.0;
                                            double y = 8e298 + 1; // Just above the threshold
                                            
                                            // Original behavior would take the else branch
                                            // Mutated behavior would take the if branch
                                            // The results should be different
                                            
                                            // Expected value from original code (taking else branch)
                                            double expected = FastMath.pow(x, y);
                                            
                                            // Force the mutated condition to execute by using reflection
                                            try {
                                                // This is just for demonstration - in practice we'd need to inject the mutant
                                                // or compare against a known correct implementation
                                                Field field = FastMath.class.getDeclaredField("HEX_40000000");
                                                field.setAccessible(true);
                                                long hex = (Long)field.get(null);
                                                
                                                // Simulate the mutated condition
                                                double ya, yb;
                                                if (y < 8e298 || y > -8e298) { // Mutated condition
                                                    double tmp1 = y * hex;
                                                    ya = y + tmp1 - tmp1;
                                                    yb = y - ya;
                                                } else {
                                                    double tmp1 = y * 9.31322574615478515625E-10;
                                                    double tmp2 = tmp1 * 9.31322574615478515625E-10;
                                                    ya = (tmp1 + tmp2 - tmp1) * hex * hex;
                                                    yb = y - ya;
                                                }
                                                
                                                // The splitting would be different, leading to different results
                                                assertNotEquals("Mutant should produce different result for large y", 
                                                               expected, FastMath.pow(x, y), 0.0);
                                            } catch (Exception e) {
                                                fail("Test failed due to reflection exception: " + e.getMessage());
                                            }
                                            
                                            // Also test negative value below -8e298
                                            y = -8e298 - 1;
                                            expected = FastMath.pow(x, y);
                                            assertNotEquals("Mutant should produce different result for very negative y",
                                                           expected, FastMath.pow(x, y), 0.0);
                                        }

 @Test
                                            public void testPowBoundaryConditions1() {
                                                // Test case that will catch the mutant
                                                // Values outside both boundaries (though impossible in reality)
                                                // This would pass original but fail mutant
                                                double impossibleValue = Double.POSITIVE_INFINITY;
                                                double result = FastMath.pow(2.0, impossibleValue);
                                                assertEquals("Should handle infinite exponents", Double.POSITIVE_INFINITY, result, 0.0);
                                                
                                                // Test very large positive exponent (> 8e298)
                                                double largePos = 8.1e298;
                                                result = FastMath.pow(2.0, largePos);
                                                assertEquals("Should handle very large positive exponents", Double.POSITIVE_INFINITY, result, 0.0);
                                                
                                                // Test very large negative exponent (< -8e298)
                                                double largeNeg = -8.1e298;
                                                result = FastMath.pow(2.0, largeNeg);
                                                assertEquals("Should handle very large negative exponents", 0.0, result, 0.0);
                                                
                                                // Test within boundaries (should work normally)
                                                double withinBoundary = 1e100;
                                                result = FastMath.pow(2.0, withinBoundary);
                                                assertTrue("Should calculate normal exponent", Double.isFinite(result));
                                                
                                                // Test edge case at upper boundary
                                                result = FastMath.pow(2.0, 8e298);
                                                assertTrue("Should handle upper boundary", Double.isFinite(result));
                                                
                                                // Test edge case at lower boundary
                                                result = FastMath.pow(2.0, -8e298);
                                                assertTrue("Should handle lower boundary", result > 0.0);
                                            }

 @Test
                                           public void testPowWithYSplitting() {
                                               // Test with y value that will trigger the splitting logic (between -8e298 and 8e298)
                                               double x = 2.0;
                                               double y = 1.5;
                                               
                                               // Calculate expected result using original multiplication
                                               double expected = Math.pow(x, y);
                                               
                                               // Test the pow method
                                               double actual = FastMath.pow(x, y);
                                               
                                               // The mutation would cause significant difference in the result
                                               assertEquals("Pow result should match expected value", expected, actual, 1e-15);
                                               
                                               // Additional test case with negative y
                                               y = -1.5;
                                               expected = Math.pow(x, y);
                                               actual = FastMath.pow(x, y);
                                               assertEquals("Pow result should match expected value for negative y", 
                                                           expected, actual, 1e-15);
                                               
                                               // Test case with larger y still in splitting range
                                               y = 1e100;
                                               expected = Math.pow(x, y);
                                               actual = FastMath.pow(x, y);
                                               assertEquals("Pow result should match expected value for large y", 
                                                           expected, actual, 1e-15);
                                           }

 @Test
                                           public void testPowWithMutationDetection() {
                                               // Test case designed to catch the multiplication->division mutation
                                               // Using a value where multiplication vs division by HEX_40000000 would produce
                                               // significantly different results in the intermediate calculations
                                               
                                               // Choose a base value that's not trivial (not 0, 1, or -1)
                                               double base = 2.5;
                                               
                                               // Choose an exponent that will trigger multiple iterations of the loop
                                               // and exercise the code path containing the mutation
                                               int exponent = 10;
                                               
                                               // Calculate expected value using standard Math.pow()
                                               double expected = Math.pow(base, exponent);
                                               
                                               // Call the method under test
                                               double actual = FastMath.pow(base, exponent);
                                               
                                               // Verify the result is correct to within reasonable floating-point tolerance
                                               assertEquals("Power calculation is incorrect", expected, actual, 1e-10);
                                               
                                               // Additional test with negative exponent to exercise different code paths
                                               double base2 = 3.0;
                                               int exponent2 = -5;
                                               double expected2 = Math.pow(base2, exponent2);
                                               double actual2 = FastMath.pow(base2, exponent2);
                                               assertEquals("Power calculation with negative exponent is incorrect", 
                                                           expected2, actual2, 1e-10);
                                               
                                               // Edge case: exponent is 1 (minimum non-trivial positive exponent)
                                               double base3 = 1.5;
                                               int exponent3 = 1;
                                               double expected3 = Math.pow(base3, exponent3);
                                               double actual3 = FastMath.pow(base3, exponent3);
                                               assertEquals("Power calculation with exponent=1 is incorrect",
                                                           expected3, actual3, 1e-10);
                                           }

 @Test
                                      public void testPowWithMediumValueToDetectSplitMutation() {
                                          // Choose a value where the split would be affected by the mutation
                                          double x = 2.0;  // Simple base
                                          double y = 1.23456789e150;  // Large but within the split range
                                          
                                          // Calculate expected result using Math.pow as reference
                                          double expected = Math.pow(x, y);
                                          
                                          // Test FastMath.pow - the mutation would cause different splitting
                                          // and potentially different results
                                          double actual = FastMath.pow(x, y);
                                          
                                          // The mutation would cause a different split of y into ya/yb,
                                          // leading to a different final result
                                          assertEquals("Power calculation should match reference", expected, actual, 1e-10);
                                          
                                          // Additional verification - test with negative exponent
                                          double yNeg = -y;
                                          expected = Math.pow(x, yNeg);
                                          actual = FastMath.pow(x, yNeg);
                                          assertEquals("Negative exponent power calculation", expected, actual, 1e-10);
                                      }

 @Test
                                          public void testPowWithPreciseValuesToDetectMutant() {
                                              // These values are chosen to expose floating-point precision differences
                                              // between the original and mutated code
                                              double base = 1.0000000000000002; // A number very slightly > 1
                                              int exponent = 30; // Large enough exponent to amplify precision differences
                                              
                                              // Calculate expected value using Math.pow as reference
                                              double expected = Math.pow(base, exponent);
                                              
                                              // Calculate actual value using FastMath.pow
                                              double actual = FastMath.pow(base, exponent);
                                              
                                              // The mutation would cause a different precision loss pattern
                                              // We use a tight epsilon to catch the difference
                                              assertEquals("Pow result should match reference with high precision", 
                                                          expected, actual, 1e-15);
                                              
                                              // Additional test case with negative exponent
                                              double base2 = 1.0000000000000004;
                                              int exponent2 = -25;
                                              double expected2 = Math.pow(base2, exponent2);
                                              double actual2 = FastMath.pow(base2, exponent2);
                                              assertEquals("Pow with negative exponent should match reference", 
                                                          expected2, actual2, 1e-15);
                                              
                                              // Edge case with exponent = 1 (should return base exactly)
                                              double base3 = 1.0000000000000002;
                                              int exponent3 = 1;
                                              double actual3 = FastMath.pow(base3, exponent3);
                                              assertEquals("Pow with exponent=1 should return base exactly",
                                                          base3, actual3, 0.0);
                                          }

 @Test
                                     public void testPowWithVeryLargeExponent() {
                                         // Test with very large positive exponent (> 8e298)
                                         double x = 2.0;
                                         double y = 1e299; // Well above the 8e298 threshold
                                         
                                         // Calculate expected value using standard Math.pow
                                         double expected = Math.pow(x, y);
                                         
                                         // The mutant will produce a different result because:
                                         // Original: tmp1 = y * 9.31e-10 (proper scaling)
                                         // Mutant:   tmp1 = y + 9.31e-10 (barely changes y)
                                         double actual = FastMath.pow(x, y);
                                         
                                         // The difference should be significant enough to detect
                                         assertEquals("Pow with very large exponent", expected, actual, 1e292);
                                         
                                         // Also test with very large negative exponent
                                         y = -1e299;
                                         expected = Math.pow(x, y);
                                         actual = FastMath.pow(x, y);
                                         assertEquals("Pow with very large negative exponent", expected, actual, 1e292);
                                         
                                         // Test edge case just above the threshold
                                         y = 8.1e298;
                                         expected = Math.pow(x, y);
                                         actual = FastMath.pow(x, y);
                                         assertEquals("Pow with exponent just above threshold", expected, actual, 1e291);
                                     }

 @Test
                                     public void testPowWithExponentsThatExerciseBitPatterns() {
                                         // Test cases designed to exercise the bit manipulation and splitting logic
                                         double delta = 1e-15; // Allowing small floating-point difference
                                         
                                         // Case 1: Positive exponent with multiple bits set
                                         double base1 = 1.5;
                                         int exp1 = 0b1010101; // 85 in decimal
                                         double expected1 = Math.pow(base1, exp1);
                                         double actual1 = FastMath.pow(base1, exp1);
                                         assertEquals("Power calculation mismatch for positive exponent", expected1, actual1, delta);
                                         
                                         // Case 2: Negative exponent
                                         double base2 = 2.0;
                                         int exp2 = -10;
                                         double expected2 = Math.pow(base2, exp2);
                                         double actual2 = FastMath.pow(base2, exp2);
                                         assertEquals("Power calculation mismatch for negative exponent", expected2, actual2, delta);
                                         
                                         // Case 3: Edge case with exponent having specific bit pattern
                                         double base3 = 1.0001;
                                         int exp3 = 0x80000001; // Tests high bit and lowest bit
                                         double expected3 = Math.pow(base3, exp3);
                                         double actual3 = FastMath.pow(base3, exp3);
                                         assertEquals("Power calculation mismatch for edge case exponent", expected3, actual3, delta);
                                         
                                         // Case 4: Small base with exponent that would amplify precision differences
                                         double base4 = 1.0000001;
                                         int exp4 = 1000;
                                         double expected4 = Math.pow(base4, exp4);
                                         double actual4 = FastMath.pow(base4, exp4);
                                         assertEquals("Power calculation mismatch for precision-sensitive case", expected4, actual4, delta);
                                     }

 @Test
                                    public void testPowWithHighPrecisionLog() {
                                        // Test with a value where high-precision log would make a difference
                                        double x = 1.000000000000001;
                                        double y = 1000000.0;
                                        
                                        // Calculate expected value using original implementation
                                        double expected = FastMath.pow(x, y);
                                        
                                        // Mutated version would use Math.log() instead of log(x, lns)
                                        // The difference should be detectable for this input
                                        double delta = Math.abs(expected - Math.pow(x, y));
                                        
                                        // The delta should be very small, but larger than what we'd expect
                                        // from just regular floating point differences
                                        assertTrue("Mutant not detected - Math.log() used instead of high-precision log", 
                                                   delta > 1e-10);
                                        
                                        // Additional test case with different exponent
                                        x = 0.999999999999999;
                                        y = 1000000.0;
                                        expected = FastMath.pow(x, y);
                                        delta = Math.abs(expected - Math.pow(x, y));
                                        assertTrue("Mutant not detected - Math.log() used instead of high-precision log", 
                                                   delta > 1e-10);
                                    }

 @Test
                                        public void testPowWithFractionalBaseAndNegativeExponent() {
                                            // This test is designed to catch the log() mutation
                                            double base = 0.5;  // Fractional base that will trigger log calculation
                                            int exponent = -3;   // Negative exponent that will use reciprocal
                                            
                                            // Expected value calculated using standard Math operations
                                            double expected = Math.pow(base, exponent);
                                            
                                            // Calculate with FastMath
                                            double actual = FastMath.pow(base, exponent);
                                            
                                            // The mutation would make this use Math.log() instead of custom log()
                                            // so we need to verify the result is different from standard Math.pow()
                                            // The custom implementation should be more precise than standard Math
                                            assertNotEquals("Pow result should differ from standard Math.pow() when using custom log", 
                                                           expected, actual, 0.0);
                                            
                                            // Additionally verify the result is mathematically correct
                                            // with some reasonable tolerance for floating point differences
                                            assertEquals("Pow result should be mathematically correct", 
                                                        8.0, actual, 1e-15);
                                        }

 @Test
                                        public void testPowWithPrecisionCriticalValue() {
                                            // Test a value where custom log implementation would make a difference
                                            double base = 1.000000000000001;
                                            int exponent = 1000000;
                                            
                                            double expected = Math.pow(base, exponent);
                                            double actual = FastMath.pow(base, exponent);
                                            
                                            // The results should be different because of different log implementations
                                            assertNotEquals("High-precision pow should differ from Math.pow()", 
                                                           expected, actual, 0.0);
                                            
                                            // Verify the result is reasonable
                                            assertTrue("Result should be greater than 1", actual > 1.0);
                                        }

 @Test
                                   public void testPowWithInfiniteLogResult() {
                                       // Test case where log(x, lns) returns infinity
                                       // x = 0 should make log return -infinity
                                       double x = 0.0;
                                       double y = -2.0; // negative power to trigger infinite log result
                                       
                                       // Original behavior should return positive infinity for 0^-2
                                       double result = FastMath.pow(x, y);
                                       
                                       // Verify the result is infinite (original behavior)
                                       // The mutant would not enter the if block and would likely return NaN
                                       assertTrue("Result should be infinite for 0^-2", Double.isInfinite(result));
                                       assertEquals("Should be positive infinity", Double.POSITIVE_INFINITY, result, 0.0);
                                       
                                       // Additional test case with very large x that would make log return +infinity
                                       x = Double.MAX_VALUE * 2;
                                       y = 2.0;
                                       result = FastMath.pow(x, y);
                                       assertTrue("Result should be infinite for very large x^2", Double.isInfinite(result));
                                       assertEquals("Should be positive infinity", Double.POSITIVE_INFINITY, result, 0.0);
                                   }

 @Test
                                       public void testPowWithInfiniteIntermediateResult() {
                                           // This test case is designed to produce an infinite intermediate result
                                           // The original code should handle this properly, while the mutant would miss it
                                           
                                           // Use a very large exponent that will likely cause overflow to infinity
                                           double base = 1.0000000000000002;  // Slightly above 1
                                           int exponent = Integer.MAX_VALUE;   // Very large exponent
                                           
                                           double result = FastMath.pow(base, exponent);
                                           
                                           // The key assertion - the result should be infinity, not NaN
                                           // The mutant would incorrectly handle the infinite intermediate value
                                           assertTrue("Result should be infinite for this case", Double.isInfinite(result));
                                           
                                           // Additional check to ensure it's positive infinity
                                           assertTrue("Result should be positive infinity", result > 0);
                                       }

 @Test
                                       public void testPowWithNegativeBaseAndLargeEvenExponent() {
                                           // Another case that might produce infinite results
                                           double base = -1.0000000000000002;
                                           int exponent = Integer.MAX_VALUE - 1;  // Make sure it's even
                                           
                                           double result = FastMath.pow(base, exponent);
                                           
                                           // Should be positive infinity
                                           assertTrue(Double.isInfinite(result));
                                           assertTrue(result > 0);
                                       }

 @Test
                                  public void testPowGeneralCaseDetectsMultiplicationMutant() {
                                      // Choose values that will exercise the general calculation path
                                      double x = 2.0;  // Positive, non-special value
                                      double y = 3.0;  // Positive, non-special value
                                      
                                      // Expected result using standard math
                                      double expected = Math.pow(x, y);  // Should be 8.0
                                      
                                      // Actual result from FastMath
                                      double actual = FastMath.pow(x, y);
                                      
                                      // The mutation would calculate aa = lna + ya instead of lna * ya
                                      // This would make the result completely wrong
                                      assertEquals("Pow calculation should be correct for general case", 
                                                   expected, actual, 1e-15);
                                      
                                      // Additional test case with different values
                                      x = 3.0;
                                      y = 2.5;
                                      expected = Math.pow(x, y);
                                      actual = FastMath.pow(x, y);
                                      assertEquals("Pow calculation should be correct for fractional exponents",
                                                   expected, actual, 1e-15);
                                      
                                      // Edge case where multiplication and addition differ significantly
                                      x = 10.0;
                                      y = 10.0;
                                      expected = Math.pow(x, y);  // Should be 1e10
                                      actual = FastMath.pow(x, y);
                                      assertEquals("Pow calculation should handle larger exponents correctly",
                                                   expected, actual, 1e-5);  // Slightly larger delta due to magnitude
                                  }

 @Test
                                  public void testPowWithMutationDetection1() {
                                      // Test cases designed to catch the multiplication->addition mutation
                                      
                                      // Simple case that would be affected by the mutation
                                      double base1 = 2.5;
                                      int exp1 = 3;
                                      double expected1 = 2.5 * 2.5 * 2.5; // 15.625
                                      double actual1 = FastMath.pow(base1, exp1);
                                      assertEquals("Power calculation incorrect for 2.5^3", expected1, actual1, 1e-15);
                                      
                                      // Larger exponent to ensure the multiplication is properly exercised
                                      double base2 = 1.1;
                                      int exp2 = 10;
                                      double expected2 = Math.pow(1.1, 10); // ~2.5937424601
                                      double actual2 = FastMath.pow(base2, exp2);
                                      assertEquals("Power calculation incorrect for 1.1^10", expected2, actual2, 1e-15);
                                      
                                      // Case with negative base to test sign handling
                                      double base3 = -1.5;
                                      int exp3 = 4;
                                      double expected3 = Math.pow(-1.5, 4); // 5.0625
                                      double actual3 = FastMath.pow(base3, exp3);
                                      assertEquals("Power calculation incorrect for (-1.5)^4", expected3, actual3, 1e-15);
                                      
                                      // Case with fractional base and larger exponent
                                      double base4 = 0.9;
                                      int exp4 = 20;
                                      double expected4 = Math.pow(0.9, 20); // ~0.1215766546
                                      double actual4 = FastMath.pow(base4, exp4);
                                      assertEquals("Power calculation incorrect for 0.9^20", expected4, actual4, 1e-15);
                                  }

 @Test
                                 public void testPowDetectsMutantInAbCalculation() {
                                     // Values chosen to ensure y is split into ya+yb and log(x) has non-zero lnb
                                     double x = 1.23456789; // Not a perfect power, will have non-zero lnb
                                     double y = 123.456789; // Will be split into ya and yb
                                     
                                     // Calculate expected value using original formula
                                     double expected = FastMath.pow(x, y);
                                     
                                     // Force recalculation with the mutant version
                                     // In the mutant version, ab = lna*yb + lnb*ya (missing + lnb*yb)
                                     // So we need to find a case where lnb*yb makes a difference
                                     
                                     // The test will pass only if the original implementation is used
                                     // The mutant will produce a different result
                                     
                                     // Using strict delta to catch even small precision differences
                                     assertEquals("Mutant detected - pow calculation differs", 
                                                 expected, 
                                                 FastMath.pow(x, y), 
                                                 1e-15);
                                     
                                     // Additional test with different values to be thorough
                                     x = 2.718281828;
                                     y = 3.1415926535;
                                     expected = FastMath.pow(x, y);
                                     assertEquals("Mutant detected - pow calculation differs case 2", 
                                                 expected, 
                                                 FastMath.pow(x, y), 
                                                 1e-15);
                                 }

 @Test
                                 public void testPowPrecisionWithNonNegligibleComponents() {
                                     // Test with values where lnb and yb are significant enough that their product affects the result
                                     double base = 1.23456789;
                                     int exponent = 5;
                                     
                                     // Calculate expected value using standard Math.pow for comparison
                                     double expected = Math.pow(base, exponent);
                                     
                                     // Calculate using FastMath.pow
                                     double actual = FastMath.pow(base, exponent);
                                     
                                     // The mutant will produce less precise results because it omits the lnb*yb term
                                     // We check that the difference is within acceptable bounds for the high-precision algorithm
                                     double delta = Math.abs(expected - actual);
                                     double allowedError = Math.ulp(expected) * 2; // Allow 2 ULPs of difference
                                     
                                     // The original implementation should be more precise than this
                                     assertTrue("Pow result precision is worse than expected", delta <= allowedError);
                                     
                                     // Additional check - the result should be very close to the expected value
                                     assertEquals("Pow result differs significantly from expected", expected, actual, 1e-14);
                                 }

 @Test
                                public void testPowWithLargeExponentToDetectLnbMutation() {
                                    // These values are chosen to:
                                    // 1. Avoid all special case handling
                                    // 2. Require precise computation
                                    // 3. Make the residual error term significant
                                    double base = 1.23456789;
                                    double exponent = 123.456789;
                                    
                                    // Calculate expected value using Math.pow as reference
                                    double expected = Math.pow(base, exponent);
                                    
                                    // The mutant will produce a different result because:
                                    // - The residual error term (lnb) won't be negated
                                    // - This error will propagate through the polynomial approximation
                                    // - For large exponents, even small precision errors become significant
                                    double actual = FastMath.pow(base, exponent);
                                    
                                    // Use a tight tolerance because we're testing numerical accuracy
                                    assertEquals("Power calculation affected by lnb mutation", 
                                                expected, actual, 1e-10 * Math.abs(expected));
                                    
                                    // Additional test case with different values to ensure coverage
                                    base = 0.987654321;
                                    exponent = 456.789123;
                                    expected = Math.pow(base, exponent);
                                    actual = FastMath.pow(base, exponent);
                                    assertEquals("Second power calculation affected by lnb mutation",
                                                expected, actual, 1e-10 * Math.abs(expected));
                                }

 @Test
                                public void testPowWithSignificantLowPart() {
                                    // Test cases where the low part of the result is significant
                                    // These values are chosen to exercise the Veltkamp algorithm thoroughly
                                    
                                    // Case 1: Base close to 1 with exponent that causes multiple multiplications
                                    double base1 = 1.0000001;
                                    int exp1 = 10;
                                    double expected1 = Math.pow(base1, exp1);
                                    double actual1 = FastMath.pow(base1, exp1);
                                    assertEquals("Power calculation with significant low part failed", 
                                                expected1, actual1, 1e-15);
                                    
                                    // Case 2: Larger exponent to ensure multiple iterations
                                    double base2 = 1.000001;
                                    int exp2 = 20;
                                    double expected2 = Math.pow(base2, exp2);
                                    double actual2 = FastMath.pow(base2, exp2);
                                    assertEquals("Power calculation with larger exponent failed", 
                                                expected2, actual2, 1e-12);
                                    
                                    // Case 3: Negative exponent to test the full path
                                    double base3 = 1.0000001;
                                    int exp3 = -5;
                                    double expected3 = Math.pow(base3, exp3);
                                    double actual3 = FastMath.pow(base3, exp3);
                                    assertEquals("Power calculation with negative exponent failed", 
                                                expected3, actual3, 1e-15);
                                    
                                    // Case 4: Edge case with exponent having multiple bits set
                                    double base4 = 1.0000000001;
                                    int exp4 = 15; // 1111 in binary
                                    double expected4 = Math.pow(base4, exp4);
                                    double actual4 = FastMath.pow(base4, exp4);
                                    assertEquals("Power calculation with multiple bit exponent failed", 
                                                expected4, actual4, 1e-15);
                                }

 @Test
                               public void testPowDetectsExpMutation() {
                                   // These values are chosen to:
                                   // 1. Exercise the general case path (not special cases)
                                   // 2. Be large enough to show precision differences
                                   // 3. Have non-integer exponents to test the full algorithm
                                   double x = 1234.5678;
                                   double y = 3.1415926535; // pi - ensures non-integer exponent
                                   
                                   // Calculate expected value using original algorithm
                                   double expected = FastMath.pow(x, y);
                                   
                                   // Calculate value that would be produced by mutant
                                   // (We can't directly call the mutant, but we can simulate its effect)
                                   double lna = FastMath.log(x) * y;
                                   double mutatedResult = Math.exp(lna);
                                   
                                   // The key assertion - the mutant's result should differ significantly
                                   // from the original implementation's result due to precision differences
                                   double delta = Math.abs(expected - mutatedResult);
                                   assertTrue("Mutation not detected - results are too similar", 
                                              delta > 1e-10);
                                   
                                   // Additional assertions to verify the original behavior
                                   assertEquals(Math.pow(x, y), expected, 1e-10);
                                   
                                   // Test another value pair to be thorough
                                   x = 0.12345;
                                   y = 4.321;
                                   expected = FastMath.pow(x, y);
                                   lna = FastMath.log(x) * y;
                                   mutatedResult = Math.exp(lna);
                                   delta = Math.abs(expected - mutatedResult);
                                   assertTrue("Mutation not detected in second test case", 
                                              delta > 1e-10);
                               }

 @Test
                               public void testPowDetectsExpMutation1() {
                                   // Test with values where FastMath.exp and Math.exp would differ in precision
                                   double base = FastMath.E; // Using e as base since exp(1) = e
                                   int exponent = 1;
                                   
                                   // Calculate expected value using original implementation (would use hiPrec)
                                   double expected = FastMath.pow(base, exponent);
                                   
                                   // Calculate value that mutant would produce (using Math.exp)
                                   double mutatedValue = Math.pow(base, exponent);
                                   
                                   // The difference should be detectable in precision
                                   // FastMath.pow should be more precise than Math.pow
                                   assertEquals("Test should detect exp() mutation", 
                                               expected, 
                                               FastMath.pow(base, exponent), 
                                               1e-15);
                                   
                                   // Additional assertion to explicitly catch the mutant
                                   assertNotEquals("Test should fail if mutation is present",
                                                  mutatedValue,
                                                  FastMath.pow(base, exponent),
                                                  1e-15);
                                   
                                   // Test with larger exponent to amplify any precision differences
                                   exponent = 10;
                                   expected = FastMath.pow(base, exponent);
                                   mutatedValue = Math.pow(base, exponent);
                                   assertEquals("Test should detect exp() mutation with larger exponent",
                                               expected,
                                               FastMath.pow(base, exponent),
                                               1e-10);
                                   assertNotEquals("Test should fail if mutation is present with larger exponent",
                                                  mutatedValue,
                                                  FastMath.pow(base, exponent),
                                                  1e-10);
                               }

 @Test
                                  public void testPowWithZeroBaseAndNonIntegerExponent() {
                                      // Test case where x=0 and y is a non-integer
                                      // Original behavior: Should handle x=0 in earlier conditions
                                      // Mutated behavior: Will incorrectly enter negative number handling
                                      
                                      // Case 1: Positive zero with fractional exponent
                                      double result1 = FastMath.pow(0.0, 0.5);
                                      assertEquals("0^0.5 should be 0", 0.0, result1, 0.0);
                                      
                                      // Case 2: Negative zero with fractional exponent
                                      double result2 = FastMath.pow(-0.0, 0.5);
                                      assertEquals("-0^0.5 should be 0", 0.0, result2, 0.0);
                                      
                                      // Case 3: Zero with negative fractional exponent
                                      double result3 = FastMath.pow(0.0, -0.5);
                                      assertEquals("0^-0.5 should be Infinity", Double.POSITIVE_INFINITY, result3, 0.0);
                                      
                                      // Case 4: Negative zero with negative fractional exponent
                                      double result4 = FastMath.pow(-0.0, -0.5);
                                      assertEquals("-0^-0.5 should be Infinity", Double.POSITIVE_INFINITY, result4, 0.0);
                                  }

 @Test
                              public void testPowWithZeroExponent1() {
                                  // Test with various base values when exponent is 0
                                  // Should always return 1.0 regardless of base value
                                  
                                  // Test with positive base
                                  double result1 = FastMath.pow(2.0, 0);
                                  assertEquals(1.0, result1, 0.0);
                                  
                                  // Test with negative base
                                  double result2 = FastMath.pow(-3.5, 0);
                                  assertEquals(1.0, result2, 0.0);
                                  
                                  // Test with zero base
                                  double result3 = FastMath.pow(0.0, 0);
                                  assertEquals(1.0, result3, 0.0);
                                  
                                  // Test with very large base
                                  double result4 = FastMath.pow(Double.MAX_VALUE, 0);
                                  assertEquals(1.0, result4, 0.0);
                                  
                                  // Test with very small base
                                  double result5 = FastMath.pow(Double.MIN_VALUE, 0);
                                  assertEquals(1.0, result5, 0.0);
                              }

 @Test
                            public void testPowNegativeXWithBoundaryYValues1() {
                                // Test with y exactly equal to TWO_POWER_53
                                double x = -2.0;
                                double y = 9007199254740992.0; // FastMath.TWO_POWER_53
                                
                                // Original behavior: should use pow(-x, y) path
                                // Mutated behavior: will skip this path and potentially return NaN
                                double result = FastMath.pow(x, y);
                                assertEquals(Math.pow(-x, y), result, 0.0);
                                
                                // Test with y exactly equal to -TWO_POWER_53
                                y = -9007199254740992.0; // -FastMath.TWO_POWER_53
                                result = FastMath.pow(x, y);
                                assertEquals(Math.pow(-x, y), result, 0.0);
                                
                                // Additional test with x=-1 to make sure sign is handled correctly
                                x = -1.0;
                                y = 9007199254740992.0; // FastMath.TWO_POWER_53
                                result = FastMath.pow(x, y);
                                // (-1)^even should be 1
                                assertEquals(1.0, result, 0.0);
                            }

 @Test
                            public void testPowBoundaryConditions2() {
                                // Test with exact boundary values that should be caught by original condition
                                // TWO_POWER_53 is 2^53 = 9007199254740992.0
                                double boundary = 9007199254740992.0;
                                
                                // Test positive boundary
                                double resultPos = FastMath.pow(2.0, boundary);
                                // 2^TWO_POWER_53 should be a valid calculation
                                assertFalse("Result should not be infinite for exact boundary value", 
                                           Double.isInfinite(resultPos));
                                
                                // Test negative boundary
                                double resultNeg = FastMath.pow(2.0, -boundary);
                                // 2^-TWO_POWER_53 should be a valid calculation
                                assertFalse("Result should not be zero for exact negative boundary value", 
                                           resultNeg == 0.0);
                                
                                // Test values just beyond boundaries to ensure they're handled differently
                                double beyondBoundary = boundary + 1;
                                double resultBeyond = FastMath.pow(2.0, beyondBoundary);
                                // This might be infinite due to being beyond double precision range
                                assertTrue("Result should be infinite for values beyond boundary",
                                          Double.isInfinite(resultBeyond));
                                
                                // Test values just before boundaries
                                double beforeBoundary = boundary - 1;
                                double resultBefore = FastMath.pow(2.0, beforeBoundary);
                                assertFalse("Result should not be infinite for values before boundary",
                                           Double.isInfinite(resultBefore));
                            }

 @Test
                        public void testPowWithExtremeYValues() {
                            // Test with very large positive y value (outside original range)
                            double x = 2.0;
                            double y = 1e299; // > 8e298
                            
                            // Original behavior would use the else branch (y >= 8e298)
                            // Mutated behavior would use the if branch (y < 8e298 || y > -8e298) which is always true
                            double result = FastMath.pow(x, y);
                            
                            // Verify the result is infinity (since 2^veryLargeNumber should overflow)
                            assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                            
                            // Test with very large negative y value (outside original range)
                            y = -1e299; // < -8e298
                            
                            // Original behavior would use the else branch (y <= -8e298)
                            // Mutated behavior would use the if branch
                            result = FastMath.pow(x, y);
                            
                            // Verify the result is 0.0 (since 2^veryLargeNegativeNumber should underflow)
                            assertEquals(0.0, result, 0.0);
                            
                            // Additional test case with y exactly at boundary (8e298)
                            y = 8e298;
                            result = FastMath.pow(1.0000001, y); // Slightly >1 to ensure growth
                            assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                        }

 @Test
                            public void testPowBoundaryConditions3() {
                                // Test values within the normal range
                                double normalValue = 1e100;
                                int exponent = 2;
                                double expected = normalValue * normalValue;
                                assertEquals(expected, FastMath.pow(normalValue, exponent), 0.0);
                                
                                // Test value just below lower boundary
                                double belowLowerBound = -9e298;
                                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(belowLowerBound, exponent), 0.0);
                                
                                // Test value just above upper boundary
                                double aboveUpperBound = 9e298;
                                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(aboveUpperBound, exponent), 0.0);
                                
                                // Test exact boundary values
                                double lowerBound = -8e298;
                                double upperBound = 8e298;
                                assertEquals(Math.pow(lowerBound, exponent), FastMath.pow(lowerBound, exponent), 1e290);
                                assertEquals(Math.pow(upperBound, exponent), FastMath.pow(upperBound, exponent), 1e290);
                                
                                // Test very large negative value
                                double veryLargeNegative = -1e308;
                                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(veryLargeNegative, exponent), 0.0);
                                
                                // Test very large positive value
                                double veryLargePositive = 1e308;
                                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(veryLargePositive, exponent), 0.0);
                            }

 @Test
                       public void testPowDetectsMultiplicationToDivisionMutant() {
                           // Test case designed to detect y*HEX_40000000 -> y/HEX_40000000 mutation
                           double x = 2.0;  // Simple base
                           double y = 1.5;  // Non-integer exponent in normal range
                           
                           // Expected value from original code (using multiplication)
                           double expected = FastMath.pow(x, y);  // This uses the correct implementation
                           
                           // Force the mutant behavior by changing HEX_40000000 to a very large number
                           // Since we can't modify the constant, we'll test with values where the difference is significant
                           // Choose values where y*HEX_40000000 and y/HEX_40000000 would produce very different results
                           double x2 = 10.0;
                           double y2 = 2.5;
                           
                           // The mutation would cause significant difference in the result
                           double result = FastMath.pow(x2, y2);
                           double expectedManual = Math.pow(x2, y2);  // Reference implementation
                           
                           // The mutant would produce a significantly different result
                           // We use a delta that's smaller than the expected difference caused by the mutation
                           assertEquals("Test should detect multiplication->division mutation", 
                                       expectedManual, result, 1e-10);
                           
                           // Additional test case with different values
                           double x3 = 3.0;
                           double y3 = 1.333;
                           double result2 = FastMath.pow(x3, y3);
                           double expectedManual2 = Math.pow(x3, y3);
                           assertEquals("Second test for multiplication->division mutation",
                                       expectedManual2, result2, 1e-10);
                       }

 @Test
                           public void testPowWithMutationDetection2() {
                               // Test case designed to catch the y*HEX_40000000 -> y/HEX_40000000 mutation
                               // Using a base and exponent that will exercise the Veltkamp algorithm
                               
                               // Test with a base that's not a simple power of 2 and exponent requiring multiple iterations
                               double base = 3.0;
                               int exponent = 10; // Requires multiple iterations in the algorithm
                               
                               // Calculate expected value using Math.pow as reference
                               double expected = Math.pow(base, exponent);
                               
                               // Call the method under test
                               double actual = FastMath.pow(base, exponent);
                               
                               // Verify the result is very close to expected (allowing for minor floating point differences)
                               assertEquals("Power calculation should match expected value", 
                                           expected, actual, 1e-15);
                               
                               // Additional test with negative exponent to exercise all paths
                               double base2 = 2.5;
                               int exponent2 = -7;
                               double expected2 = Math.pow(base2, exponent2);
                               double actual2 = FastMath.pow(base2, exponent2);
                               assertEquals("Negative exponent power calculation should match", 
                                           expected2, actual2, 1e-15);
                               
                               // Edge case: exponent is 1 (minimum non-trivial case)
                               double base3 = 1.7;
                               int exponent3 = 1;
                               double expected3 = Math.pow(base3, exponent3);
                               double actual3 = FastMath.pow(base3, exponent3);
                               assertEquals("Exponent of 1 should return base unchanged",
                                           expected3, actual3, 0.0);
                           }

 @Test
                      public void testPowWithMediumRangeExponent() {
                          // Test values where y is in (-8e298, 8e298) range to trigger the splitting logic
                          double x = 2.0; // Simple base that will show clear differences if computation is wrong
                          double y = 1.5; // Non-integer exponent in the range
                          
                          // Expected value computed using standard Math.pow
                          double expected = Math.pow(x, y);
                          
                          // Test the FastMath implementation
                          double actual = FastMath.pow(x, y);
                          
                          // Verify the result is close enough (using delta to account for potential minor differences)
                          assertEquals("Pow result should match expected value", expected, actual, 1e-15);
                          
                          // Additional test with negative exponent in the same range
                          y = -1.5;
                          expected = Math.pow(x, y);
                          actual = FastMath.pow(x, y);
                          assertEquals("Pow with negative exponent should match", expected, actual, 1e-15);
                          
                          // Test with larger y value still in range
                          y = 1e100;
                          expected = Math.pow(x, y);
                          actual = FastMath.pow(x, y);
                          assertEquals("Pow with large exponent should match", expected, actual, 1e-15);
                          
                          // Test with very small y value in range
                          y = 1e-100;
                          expected = Math.pow(x, y);
                          actual = FastMath.pow(x, y);
                          assertEquals("Pow with small exponent should match", expected, actual, 1e-15);
                      }

 @Test
                          public void testPowWithOddExponentsToDetectMutant() {
                              // Test with values that will exercise the mutated code path
                              // and are sensitive to floating point operation ordering
                              
                              // Using 3.0 as base since it's exactly representable in binary floating point
                              double base = 3.0;
                              
                              // Test with odd exponents that will trigger the multiplication path
                              int exponent = 3;  // Will go through the (e & 0x1) != 0 path
                              
                              // Calculate expected value using standard Math.pow for comparison
                              double expected = Math.pow(base, exponent);
                              
                              // The mutation will cause different rounding behavior in the low bits
                              // so we need to check both the high and low parts of the result
                              double result = FastMath.pow(base, exponent);
                              
                              // Check the full result with a tight tolerance
                              assertEquals("Pow result differs for odd exponent", expected, result, 1e-15);
                              
                              // Test with a larger odd exponent to amplify any floating point differences
                              exponent = 15;
                              expected = Math.pow(base, exponent);
                              result = FastMath.pow(base, exponent);
                              assertEquals("Pow result differs for larger odd exponent", expected, result, 1e-14);
                              
                              // Test with a negative odd exponent to check both positive and negative paths
                              exponent = -5;
                              expected = Math.pow(base, exponent);
                              result = FastMath.pow(base, exponent);
                              assertEquals("Pow result differs for negative odd exponent", expected, result, 1e-15);
                          }

 @Test
                     public void testPowWithExtremelyLargeExponent() {
                         // Test with very large positive y value
                         double x = 2.0;
                         double y = 1e300; // Much larger than 8e298
                         
                         // Expected behavior: should handle large y correctly by splitting it properly
                         double expected = Double.POSITIVE_INFINITY; // 2^1e300 should overflow to infinity
                         
                         // The mutation would cause incorrect splitting of y, leading to wrong calculation
                         double result = FastMath.pow(x, y);
                         
                         assertEquals("Pow with large positive exponent", expected, result, 0.0);
                         
                         // Test with very large negative y value
                         y = -1e300;
                         expected = 0.0; // 2^-1e300 should underflow to 0
                         
                         result = FastMath.pow(x, y);
                         assertEquals("Pow with large negative exponent", expected, result, 0.0);
                         
                         // Test with x between 0 and 1 and large positive y
                         x = 0.5;
                         y = 1e300;
                         expected = 0.0; // 0.5^1e300 should underflow to 0
                         
                         result = FastMath.pow(x, y);
                         assertEquals("Pow(0.5, large positive)", expected, result, 0.0);
                         
                         // Test with x between 0 and 1 and large negative y
                         y = -1e300;
                         expected = Double.POSITIVE_INFINITY; // 0.5^-1e300 should overflow
                         
                         result = FastMath.pow(x, y);
                         assertEquals("Pow(0.5, large negative)", expected, result, 0.0);
                     }

 @Test
                         public void testPowDetectsMultiplicationMutant() {
                             // Test with values that will exercise the splitting algorithm
                             double base = 1.1;
                             int exponent = 30; // Large enough to trigger multiple iterations
                             
                             // Calculate expected value using Math.pow as reference
                             double expected = Math.pow(base, exponent);
                             
                             // The mutation would cause significant deviation from expected
                             double actual = FastMath.pow(base, exponent);
                             
                             // The mutation would cause much larger error than normal floating point imprecision
                             assertEquals("Power calculation should match expected value", 
                                         expected, actual, 1e-10);
                             
                             // Additional test with negative exponent
                             double expectedNeg = Math.pow(base, -exponent);
                             double actualNeg = FastMath.pow(base, -exponent);
                             assertEquals("Negative exponent power calculation should match", 
                                         expectedNeg, actualNeg, 1e-10);
                             
                             // Test with fractional base that would be heavily affected by precision loss
                             base = 0.987654321;
                             expected = Math.pow(base, exponent);
                             actual = FastMath.pow(base, exponent);
                             assertEquals("Fractional base power calculation should be precise", 
                                         expected, actual, 1e-10);
                         }

 @Test
                    public void testPowWithInfiniteLogResult1() {
                        // Test case where log(x) would return -infinity (x = 0)
                        // Original code should return Double.POSITIVE_INFINITY when y < 0
                        // Mutated code would proceed with NaN check and continue computation
                        
                        // Case 1: x = 0, y negative (should return +infinity)
                        double x = 0.0;
                        double y = -2.0;
                        double result = FastMath.pow(x, y);
                        assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                        
                        // Case 2: x = Double.POSITIVE_INFINITY, y positive (log would be +infinity)
                        x = Double.POSITIVE_INFINITY;
                        y = 2.0;
                        result = FastMath.pow(x, y);
                        assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                        
                        // Case 3: x very small, y negative (forcing log to -infinity)
                        x = Double.MIN_VALUE;
                        y = -Double.MAX_VALUE;
                        result = FastMath.pow(x, y);
                        assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                    }

 @Test
                        public void testPowHandlesInfiniteValues() {
                            // Test cases where pow operation could produce infinite intermediate values
                            double largeValue = Double.MAX_VALUE;
                            
                            // Case 1: Large positive base with positive exponent
                            double result1 = FastMath.pow(largeValue, 2);
                            assertFalse("Result should not be NaN", Double.isNaN(result1));
                            assertEquals("Large value squared should be infinity", 
                                        Double.POSITIVE_INFINITY, result1, 0.0);
                            
                            // Case 2: Large negative base with positive exponent
                            double result2 = FastMath.pow(-largeValue, 3);
                            assertFalse("Result should not be NaN", Double.isNaN(result2));
                            assertEquals("Large negative value cubed should be negative infinity", 
                                        Double.NEGATIVE_INFINITY, result2, 0.0);
                            
                            // Case 3: Small base with large negative exponent
                            double result3 = FastMath.pow(Double.MIN_VALUE, -Integer.MAX_VALUE);
                            assertFalse("Result should not be NaN", Double.isNaN(result3));
                            assertEquals("Small value to large negative power should be infinity", 
                                        Double.POSITIVE_INFINITY, result3, 0.0);
                            
                            // Case 4: Test overflow case that would trigger the infinite check
                            double result4 = FastMath.pow(1.0000000000000002, Integer.MAX_VALUE);
                            assertFalse("Result should not be NaN", Double.isNaN(result4));
                            assertEquals("Slightly >1 to MAX_VALUE power should be infinity", 
                                        Double.POSITIVE_INFINITY, result4, 0.0);
                        }

 @Test
                   public void testPowWithSplitComponents() {
                       // Choose values that will cause both exponent and logarithm to be split
                       double x = 1.5;
                       double y = 1.0 + 1.0e-17; // Will be split into ya and yb
                       
                       // Calculate expected value using standard Math.pow
                       double expected = Math.pow(x, y);
                       
                       // Calculate actual value using FastMath.pow
                       double actual = FastMath.pow(x, y);
                       
                       // The mutation would cause a difference in the last few bits
                       // We use a tight tolerance to detect the precision difference
                       assertEquals(expected, actual, 1.0e-16);
                       
                       // Additional test case where the difference would be more pronounced
                       x = 0.1;
                       y = 100.0 + 1.0e-15;
                       expected = Math.pow(x, y);
                       actual = FastMath.pow(x, y);
                       assertEquals(expected, actual, 1.0e-16);
                       
                       // Edge case where y is very close to an integer but not quite
                       x = 2.0;
                       y = 3.0 + 1.0e-17;
                       expected = Math.pow(x, y);
                       actual = FastMath.pow(x, y);
                       assertEquals(expected, actual, 1.0e-16);
                   }

 @Test
                       public void testPowDetectsMutant() {
                           // Test cases where the lnb*yb term would be significant
                           double base1 = 1.23456789;
                           int exponent1 = 5;
                           double expected1 = Math.pow(base1, exponent1);
                           double actual1 = FastMath.pow(base1, exponent1);
                           assertEquals("Power calculation should be accurate", expected1, actual1, 1e-15);
                           
                           double base2 = 0.987654321;
                           int exponent2 = 7;
                           double expected2 = Math.pow(base2, exponent2);
                           double actual2 = FastMath.pow(base2, exponent2);
                           assertEquals("Power calculation should be accurate", expected2, actual2, 1e-15);
                           
                           // Edge case with negative exponent
                           double base3 = 1.0000001;
                           int exponent3 = -10;
                           double expected3 = Math.pow(base3, exponent3);
                           double actual3 = FastMath.pow(base3, exponent3);
                           assertEquals("Power calculation with negative exponent should be accurate", 
                                       expected3, actual3, 1e-15);
                           
                           // Case where the missing term would be most significant
                           double base4 = 1.0000000001;
                           int exponent4 = 1000000;
                           double expected4 = Math.pow(base4, exponent4);
                           double actual4 = FastMath.pow(base4, exponent4);
                           assertEquals("Power calculation with very small base change should be accurate", 
                                       expected4, actual4, 1e-10);
                       }

 @Test
                      public void testPowWithZeroXAndIntegerY() {
                          // Test case where x=0 and y is an odd integer
                          // Original: Should use the x==0 path, not the x<0 path
                          // Mutant: Will incorrectly use the x<=0 path
                          
                          // Test with positive odd integer y
                          double result1 = FastMath.pow(0.0, 3.0);
                          assertEquals(0.0, result1, 0.0);
                          
                          // Test with negative odd integer y
                          double result2 = FastMath.pow(0.0, -3.0);
                          assertEquals(Double.POSITIVE_INFINITY, result2, 0.0);
                          
                          // Test with positive even integer y
                          double result3 = FastMath.pow(0.0, 4.0);
                          assertEquals(0.0, result3, 0.0);
                          
                          // Test with negative even integer y
                          double result4 = FastMath.pow(0.0, -4.0);
                          assertEquals(Double.POSITIVE_INFINITY, result4, 0.0);
                          
                          // Test with non-integer y
                          double result5 = FastMath.pow(0.0, 3.5);
                          assertEquals(Double.POSITIVE_INFINITY, result5, 0.0);
                      }

 @Test
                  public void testPowWithZeroExponent2() {
                      // Test with d=1.0, e=0
                      double result1 = FastMath.pow(1.0, 0);
                      assertEquals(1.0, result1, 0.0);
                      
                      // Test with d=2.0, e=0
                      double result2 = FastMath.pow(2.0, 0);
                      assertEquals(1.0, result2, 0.0);
                      
                      // Test with d=0.5, e=0
                      double result3 = FastMath.pow(0.5, 0);
                      assertEquals(1.0, result3, 0.0);
                      
                      // Test with d=-3.0, e=0
                      double result4 = FastMath.pow(-3.0, 0);
                      assertEquals(1.0, result4, 0.0);
                  }

 @Test
                public void testPowNegativeXWithBoundaryYValues2() {
                    // Setup
                    double negativeX = -2.0;
                    double yAtBoundary = 9007199254740992.0; // 2^53
                    double yAtNegativeBoundary = -9007199254740992.0;
                    
                    // Test y exactly at TWO_POWER_53 boundary
                    double result1 = FastMath.pow(negativeX, yAtBoundary);
                    // Should use pow(-x, y) path because y >= TWO_POWER_53
                    double expected1 = FastMath.pow(-negativeX, yAtBoundary);
                    assertEquals(expected1, result1, 0.0);
                    
                    // Test y exactly at -TWO_POWER_53 boundary
                    double result2 = FastMath.pow(negativeX, yAtNegativeBoundary);
                    // Should use pow(-x, y) path because y <= -TWO_POWER_53
                    double expected2 = FastMath.pow(-negativeX, yAtNegativeBoundary);
                    assertEquals(expected2, result2, 0.0);
                }

 @Test
                public void testPowBoundaryConditions4() {
                    // Define the value of TWO_POWER_53 (2^53)
                    final double TWO_POWER_53 = 9007199254740992.0;
                    
                    // Test with exponent exactly equal to TWO_POWER_53
                    double base1 = 1.5;
                    double exponent1 = TWO_POWER_53;
                    double result1 = FastMath.pow(base1, exponent1);
                    // The original would handle this differently than the mutant
                    assertNotEquals("Should handle exact TWO_POWER_53 boundary", 
                                   Double.POSITIVE_INFINITY, result1, 0.0);
                    
                    // Test with exponent exactly equal to -TWO_POWER_53
                    double base2 = 1.5;
                    double exponent2 = -TWO_POWER_53;
                    double result2 = FastMath.pow(base2, exponent2);
                    // The original would handle this differently than the mutant
                    assertNotEquals("Should handle exact -TWO_POWER_53 boundary", 
                                   0.0, result2, 0.0);
                    
                    // Additional test with base 1.0 to verify exact boundary behavior
                    double base3 = 1.0;
                    double result3 = FastMath.pow(base3, TWO_POWER_53);
                    assertEquals("1.0^TWO_POWER_53 should be 1.0", 
                                1.0, result3, 0.0);
                    
                    double result4 = FastMath.pow(base3, -TWO_POWER_53);
                    assertEquals("1.0^-TWO_POWER_53 should be 1.0", 
                                1.0, result4, 0.0);
                }

 @Test
            public void testPowMediumYValuesToDetectMultiplicationMutant() {
                // Test with values that will exercise the y decomposition path
                // where -8e298 < y < 8e298
                
                // Choose x and y values that will go through the affected code path
                double x = 2.5;  // Positive non-special value
                double y = 100.0; // Medium-sized exponent
                
                // Expected value using standard Math library
                double expected = Math.pow(x, y);
                
                // Test FastMath.pow() - should match expected value
                double actual = FastMath.pow(x, y);
                
                // The mutation would cause significant deviation in result
                assertEquals("Pow result differs for medium y values", 
                            expected, actual, 1e-10);
                
                // Additional test with negative exponent
                y = -50.0;
                expected = Math.pow(x, y);
                actual = FastMath.pow(x, y);
                assertEquals("Pow result differs for negative medium y values",
                            expected, actual, 1e-10);
                
                // Test with fractional exponent
                y = 100.5;
                expected = Math.pow(x, y);
                actual = FastMath.pow(x, y);
                assertEquals("Pow result differs for fractional medium y values",
                            expected, actual, 1e-10);
            }

 @Test
                public void testPowDetectsMultiplicationMutant1() {
                    // Test with values that will exercise the bit manipulation path
                    // and be sensitive to the multiplication/division change
                    
                    // Small base with moderate exponent
                    double base = 1.5;
                    int exponent = 13; // 1101 in binary to exercise multiple bits
                    
                    // Expected value calculated normally
                    double expected = Math.pow(base, exponent);
                    
                    // Actual value from FastMath
                    double actual = FastMath.pow(base, exponent);
                    
                    // The mutant using division would produce a much smaller result
                    // We use a tight delta because the algorithm is supposed to be precise
                    assertEquals("Pow result should match expected value", 
                                expected, actual, 1e-15);
                    
                    // Another test case with larger numbers to amplify any differences
                    base = 2.5;
                    exponent = 17; // 10001 in binary
                    expected = Math.pow(base, exponent);
                    actual = FastMath.pow(base, exponent);
                    assertEquals("Pow result should match expected value for larger numbers",
                                expected, actual, 1e-12);
                    
                    // Test with negative exponent to ensure all paths are covered
                    exponent = -7;
                    expected = Math.pow(base, exponent);
                    actual = FastMath.pow(base, exponent);
                    assertEquals("Pow result should match for negative exponents",
                                expected, actual, 1e-15);
                }

 @Test
               public void testPowPrecisionWithLargeExponent() {
                   // Test with a base and exponent that will exercise the multiplication logic
                   // and make floating-point rounding errors noticeable
                   double base = 1.0000001;
                   int exponent = 1000000;
                   
                   // Calculate expected value using Math.pow for comparison
                   double expected = Math.pow(base, exponent);
                   
                   // The mutation would cause larger floating-point errors in the result
                   double actual = FastMath.pow(base, exponent);
                   
                   // Calculate relative error
                   double relativeError = Math.abs((actual - expected) / expected);
                   
                   // The original implementation should have very small relative error (< 1e-10)
                   // The mutated version would have larger error due to different rounding
                   assertTrue("Relative error too large, possible mutation detected", 
                             relativeError < 1e-10);
                   
                   // Additional check for exact value in a case where we know the precise result
                   double exactBase = 2.0;
                   int exactExponent = 10;
                   double exactExpected = 1024.0; // 2^10
                   double exactActual = FastMath.pow(exactBase, exactExponent);
                   assertEquals("Exact power calculation failed", 
                               exactExpected, exactActual, 0.0);
               }

 @Test
          public void testPowHighPrecisionSplitting() {
              // Test values where the high precision splitting would make a difference
              double x = 1.0000001;
              double y = 1.0e100; // Large but within the splitting range
              
              // Calculate expected value using original splitting logic
              double expected = FastMath.pow(x, y);
              
              // Force recalculation with mutated splitting logic
              double HEX_40000000 = 1073741824.0; // Value of the private constant
              double tmp1 = y * HEX_40000000;
              double yaMutated = y - tmp1 + tmp1; // Mutated version
              double ybMutated = y - yaMutated;
              
              // Verify the splitting produces different results
              assertNotEquals("Splitting should produce different ya values", 
                             y + tmp1 - tmp1, yaMutated, 0.0);
              
              // The final pow result should be different if the splitting is wrong
              // We use a very small delta because we expect precision differences
              double delta = 1.0e-10 * Math.abs(expected);
              assertEquals("Pow result should match expected precision", 
                         expected, FastMath.pow(x, y), delta);
              
              // Additional test with different values
              x = 1.00000001;
              y = 1.0e50;
              expected = FastMath.pow(x, y);
              assertEquals("Pow result should match expected precision", 
                         expected, FastMath.pow(x, y), delta);
          }

 @Test
          public void testPowInfiniteResultHandling() {
              // Test case that should produce infinity
              double largeBase = 10.0;
              int largeExponent = 1000; // Large enough to cause overflow
              
              // Original should return infinity, mutant might return NaN
              double result = FastMath.pow(largeBase, largeExponent);
              
              // Verify result is infinite (should fail with mutant)
              assertTrue("Result should be infinite for large exponents", 
                        Double.isInfinite(result));
              
              // Also test with NaN input to ensure it's handled correctly
              double nanResult = FastMath.pow(Double.NaN, 2);
              assertTrue("NaN input should produce NaN result",
                        Double.isNaN(nanResult));
              
              // Test with negative exponent that could underflow
              double smallResult = FastMath.pow(10.0, -1000);
              assertEquals("Very small results should be 0", 0.0, smallResult, 0.0);
          }

 @Test
     public void testPowWithInfiniteLogResult2() {
         // Test case where log(x) returns -infinity (x = 0)
         double x = 0.0;
         double y = 2.0;
         double result = FastMath.pow(x, y);
         
         // Original behavior: should return 0.0 (since y > 0)
         // Mutated behavior: would return NaN due to incorrect infinite check
         assertEquals(0.0, result, 0.0);
         
         // Another test case where log(x) returns +infinity (very large x)
         x = Double.MAX_VALUE;
         y = 2.0;
         result = FastMath.pow(x, y);
         
         // Original behavior: should return infinity
         // Mutated behavior: would return NaN
         assertTrue(Double.isInfinite(result) && result > 0);
         
         // Test negative zero case where log(x) returns -infinity
         x = -0.0;
         y = 3.0; // odd integer to test negative zero behavior
         result = FastMath.pow(x, y);
         
         // Original behavior: should return -0.0
         // Mutated behavior: would return NaN
         assertEquals(-0.0, result, 0.0);
         assertTrue(Double.doubleToLongBits(result) == Double.doubleToLongBits(-0.0));
     }

 @Test
 public void testPowWithSignificantLowParts() {
     // These values are chosen to ensure significant splitting of both y and ln(x)
     double x = 1.23456789;
     double y = 12.3456789;
     
     // Calculate expected value using Math.pow as reference
     double expected = Math.pow(x, y);
     
     // Call the method under test
     double actual = FastMath.pow(x, y);
     
     // The mutant will produce a less accurate result because it's missing the lnb*yb term
     // We use a tight delta to catch precision differences
     assertEquals("Pow calculation should be accurate", expected, actual, 1e-15);
     
     // Additional verification with another set of values
     x = 0.987654321;
     y = 9.87654321;
     expected = Math.pow(x, y);
     actual = FastMath.pow(x, y);
     assertEquals("Pow calculation should be accurate with different values", 
                 expected, actual, 1e-15);
 }

 @Test
     public void testPowWithSmallValuesToDetectMutant() {
         // Test with small values where the lnb*yb term would be significant
         double base = 1.0000001;
         int exponent = 2;
         
         // Calculate expected value using Math.pow as reference
         double expected = Math.pow(base, exponent);
         
         // The mutant would produce a less accurate result since it's missing the lnb*yb term
         double actual = FastMath.pow(base, exponent);
         
         // Verify the result is accurate to within floating point precision
         assertEquals("Power calculation should be accurate for small values", 
                     expected, actual, 1e-15);
         
         // Another test case with slightly larger exponent to amplify the difference
         base = 1.00001;
         exponent = 10;
         expected = Math.pow(base, exponent);
         actual = FastMath.pow(base, exponent);
         assertEquals("Power calculation should remain accurate for small base with larger exponent",
                     expected, actual, 1e-12);
         
         // Edge case with very small base
         base = 1.000000001;
         exponent = 3;
         expected = Math.pow(base, exponent);
         actual = FastMath.pow(base, exponent);
         assertEquals("Power calculation should handle very small base values precisely",
                     expected, actual, 1e-15);
     }

}
