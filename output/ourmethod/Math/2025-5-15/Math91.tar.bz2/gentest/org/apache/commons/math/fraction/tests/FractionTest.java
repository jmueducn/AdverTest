package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.math.BigInteger;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.util.MathUtils;
 
public class FractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                public void testCompareTo_EqualFractions() {
                    Fraction f1 = new Fraction(1, 2);
                    Fraction f2 = new Fraction(1, 2);
                    assertEquals(0, f1.compareTo(f2));
                    
                    Fraction f3 = new Fraction(2, 4); // reduced form of 1/2
                    assertEquals(0, f1.compareTo(f3));
                    
                    Fraction f4 = new Fraction(-1, -2); // also equals 1/2
                    assertEquals(0, f1.compareTo(f4));
                }

 @Test
                public void testCompareTo_FirstFractionSmaller() {
                    Fraction f1 = new Fraction(1, 3);
                    Fraction f2 = new Fraction(1, 2);
                    assertTrue(f1.compareTo(f2) < 0);
                    
                    Fraction f3 = new Fraction(-1, 2);
                    Fraction f4 = new Fraction(1, 2);
                    assertTrue(f3.compareTo(f4) < 0);
                    
                    Fraction f5 = new Fraction(-1, 2);
                    Fraction f6 = new Fraction(-1, 3); // -1/2 < -1/3
                    assertTrue(f5.compareTo(f6) < 0);
                }

 @Test
                public void testCompareTo_FirstFractionLarger() {
                    Fraction f1 = new Fraction(3, 4);
                    Fraction f2 = new Fraction(2, 3);
                    assertTrue(f1.compareTo(f2) > 0);
                    
                    Fraction f3 = new Fraction(1, 2);
                    Fraction f4 = new Fraction(-1, 2);
                    assertTrue(f3.compareTo(f4) > 0);
                    
                    Fraction f5 = new Fraction(-1, 3);
                    Fraction f6 = new Fraction(-1, 2); // -1/3 > -1/2
                    assertTrue(f5.compareTo(f6) > 0);
                }

 @Test
                public void testCompareTo_WithConstants() {
                    assertTrue(Fraction.ZERO.compareTo(Fraction.ONE) < 0);
                    assertTrue(Fraction.ONE.compareTo(Fraction.TWO) < 0);
                    assertTrue(Fraction.MINUS_ONE.compareTo(Fraction.ZERO) < 0);
                    assertEquals(0, Fraction.ONE.compareTo(new Fraction(1, 1)));
                }

 @Test
                public void testCompareTo_EdgeCases() {
                    // Large numbers that could cause overflow if not using long
                    Fraction f1 = new Fraction(Integer.MAX_VALUE, 1);
                    Fraction f2 = new Fraction(Integer.MAX_VALUE - 1, 1);
                    assertTrue(f1.compareTo(f2) > 0);
                    
                    Fraction f3 = new Fraction(1, Integer.MAX_VALUE);
                    Fraction f4 = new Fraction(2, Integer.MAX_VALUE);
                    assertTrue(f3.compareTo(f4) < 0);
                    
                    // Comparing with MIN_VALUE
                    Fraction f5 = new Fraction(Integer.MIN_VALUE, 1);
                    Fraction f6 = new Fraction(Integer.MIN_VALUE + 1, 1);
                    assertTrue(f5.compareTo(f6) < 0);
                }

 @Test
                public void testCompareTo_NullInput() {
                    thrown.expect(NullPointerException.class);
                    Fraction f = new Fraction(1, 2);
                    f.compareTo(null);
                }

 @Test
                public void testCompareTo_CrossMultiplyEdgeCases() {
                    // Test cases where cross multiplication is needed to properly compare
                    Fraction f1 = new Fraction(1, Integer.MAX_VALUE);
                    Fraction f2 = new Fraction(Integer.MAX_VALUE, 1);
                    assertTrue(f1.compareTo(f2) < 0);
                    
                    Fraction f3 = new Fraction(Integer.MIN_VALUE, 1);
                    Fraction f4 = new Fraction(1, Integer.MAX_VALUE);
                    assertTrue(f3.compareTo(f4) < 0);
                }

 @Test
                public void testCompareTo_EquivalentFractionsDifferentForms() {
                    Fraction f1 = new Fraction(2, 3);
                    Fraction f2 = new Fraction(4, 6);
                    assertEquals(0, f1.compareTo(f2));
                    
                    Fraction f3 = new Fraction(-2, 3);
                    Fraction f4 = new Fraction(2, -3);
                    assertEquals(0, f3.compareTo(f4));
                }

 @Test
            public void testAbsWithZeroNumerator() {
                // Create a fraction with numerator 0 (e.g., 0/1)
                Fraction zeroFraction = new Fraction(0, 1);
                
                // Call abs() and verify it returns the same object
                Fraction result = zeroFraction.abs();
                
                // Verify it's the same object (not negated)
                assertSame("abs() should return same object when numerator is 0", 
                          zeroFraction, result);
                
                // Also verify the numerator is still 0 (though negating 0 would also give 0)
                assertEquals(0, result.getNumerator());
                assertEquals(1, result.getDenominator());
            }

 @Test
            public void testAbsWithPositiveNumerator() {
                // Create a fraction with positive numerator (e.g., 3/4)
                Fraction positiveFraction = new Fraction(3, 4);
                
                // Call abs() and verify it returns the same object
                Fraction result = positiveFraction.abs();
                
                // Verify it's the same object
                assertSame("abs() should return same object when numerator is positive", 
                          positiveFraction, result);
            }

 @Test
            public void testAbsWithNegativeNumerator() {
                // Create a fraction with negative numerator (e.g., -3/4)
                Fraction negativeFraction = new Fraction(-3, 4);
                
                // Call abs() and verify it returns a different object (the negated version)
                Fraction result = negativeFraction.abs();
                
                // Verify it's a different object
                assertNotSame("abs() should return negated object when numerator is negative", 
                            negativeFraction, result);
                
                // Verify the numerator is now positive
                assertEquals(3, result.getNumerator());
                assertEquals(4, result.getDenominator());
            }

 @Test
           public void testAbsDetectsMutant() {
               // Test with positive numerator (5/1)
               Fraction positive = new Fraction(5, 1);
               Fraction resultPositive = positive.abs();
               // Original: should return same fraction (5/1)
               // Mutant: would return negated (-5/1)
               assertEquals(5, resultPositive.getNumerator());
               assertEquals(1, resultPositive.getDenominator());
               
               // Test with negative numerator (-3/1)
               Fraction negative = new Fraction(-3, 1);
               Fraction resultNegative = negative.abs();
               // Original: should return negated (3/1)
               // Mutant: would return same fraction (-3/1)
               assertEquals(3, resultNegative.getNumerator());
               assertEquals(1, resultNegative.getDenominator());
               
               // Test with zero numerator (0/1) - won't detect mutant but good for completeness
               Fraction zero = new Fraction(0, 1);
               Fraction resultZero = zero.abs();
               assertEquals(0, resultZero.getNumerator());
               assertEquals(1, resultZero.getDenominator());
           }

 @Test
          public void testAbs() {
              // Test positive numerator
              Fraction positive = new Fraction(3, 4);
              Fraction resultPos = positive.abs();
              assertSame("Positive fraction should return itself", positive, resultPos);
              
              // Test negative numerator
              Fraction negative = new Fraction(-3, 4);
              Fraction resultNeg = negative.abs();
              assertNotSame("Negative fraction should return negated version", negative, resultNeg);
              assertEquals("Numerator should be positive", 3, resultNeg.getNumerator());
              assertEquals("Denominator should remain same", 4, resultNeg.getDenominator());
              
              // Test zero numerator
              Fraction zero = new Fraction(0, 1);
              Fraction resultZero = zero.abs();
              assertSame("Zero fraction should return itself", zero, resultZero);
          }

 @Test
         public void testAbsWithPositiveNumerator1() {
             // Create a fraction with positive numerator (5/1)
             Fraction fraction = new Fraction(5, 1);
             
             // Call abs() - should return same fraction for original code
             Fraction result = fraction.abs();
             
             // Verify numerator is still positive (would be negative in mutant)
             assertEquals(5, result.getNumerator());
             assertEquals(1, result.getDenominator());
             
             // Verify it's the same object reference (original returns this)
             assertSame(fraction, result);
         }

 @Test
         public void testAbsWithZeroNumerator1() {
             // Create fraction with zero numerator (0/1)
             Fraction fraction = new Fraction(0, 1);
             
             // Call abs() - should return same fraction in both original and mutant
             Fraction result = fraction.abs();
             
             assertEquals(0, result.getNumerator());
             assertEquals(1, result.getDenominator());
             assertSame(fraction, result);
         }

 @Test
         public void testAbsWithNegativeNumerator1() {
             // Create fraction with negative numerator (-3/1)
             Fraction fraction = new Fraction(-3, 1);
             
             // Call abs() - should return negated fraction in both original and mutant
             Fraction result = fraction.abs();
             
             assertEquals(3, result.getNumerator());
             assertEquals(1, result.getDenominator());
             // Should not be same object since negate() creates new instance
             assertNotSame(fraction, result);
         }

 @Test
    public void testAbsPositiveNumerator() {
        // Create a fraction with positive numerator
        Fraction fraction = new Fraction(3, 4);
        
        // Call abs() - should return same fraction for original code
        Fraction result = fraction.abs();
        
        // Verify it's the same object (not negated)
        assertSame("abs() should return same instance for positive numerator", fraction, result);
        
        // Verify numerator remains positive
        assertEquals(3, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

 @Test
    public void testAbsNegativeNumerator() {
        // Create a fraction with negative numerator
        Fraction fraction = new Fraction(-3, 4);
        
        // Call abs() - should return negated version
        Fraction result = fraction.abs();
        
        // Verify it's a different object
        assertNotSame("abs() should return new instance for negative numerator", fraction, result);
        
        // Verify numerator is now positive
        assertEquals(3, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

 @Test
   public void testAbsWithPositiveNumeratorShouldReturnSameObject() {
       // Create a fraction with positive numerator
       Fraction fraction = new Fraction(3, 4);
       
       // Call abs()
       Fraction result = fraction.abs();
       
       // Verify the result is not null (would fail with mutant)
       assertNotNull(result);
       
       // Verify it returns the same object (would fail with mutant)
       assertSame(fraction, result);
       
       // Verify the actual value is correct
       assertEquals(3, result.getNumerator());
       assertEquals(4, result.getDenominator());
   }

 @Test
   public void testAbsWithZeroNumeratorShouldReturnSameObject() {
       // Create a fraction with zero numerator (edge case)
       Fraction fraction = new Fraction(0, 1);
       
       // Call abs()
       Fraction result = fraction.abs();
       
       // Verify the result is not null (would fail with mutant)
       assertNotNull(result);
       
       // Verify it returns the same object (would fail with mutant)
       assertSame(fraction, result);
       
       // Verify the actual value is correct
       assertEquals(0, result.getNumerator());
       assertEquals(1, result.getDenominator());
   }

 @Test
  public void testAbsWithNegativeNumerator2() {
      // Create a fraction with negative numerator
      Fraction negativeFraction = new Fraction(-3, 4);
      
      // Call abs()
      Fraction result = negativeFraction.abs();
      
      // Verify numerator is positive (should be negated)
      assertEquals(3, result.getNumerator());
      assertEquals(4, result.getDenominator());
      
      // Also verify it's not the same object as original (though not strictly necessary)
      assertNotSame(negativeFraction, result);
  }

 @Test
 public void testAbsWithNegativeNumeratorShouldNotReturnNull() {
     // Create a fraction with negative numerator
     Fraction negativeFraction = new Fraction(-3, 4);
     
     // Call abs()
     Fraction result = negativeFraction.abs();
     
     // Verify the result is not null (this would catch the mutant)
     assertNotNull("abs() should not return null for negative fractions", result);
     
     // Additional verification that the result is correct
     Fraction expected = new Fraction(3, 4);
     assertEquals("abs() of -3/4 should be 3/4", expected, result);
     
     // Verify numerator is positive
     assertTrue("Numerator should be positive after abs()", 
                result.getNumerator() > 0);
 }

}
