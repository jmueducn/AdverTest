package gentest.org.apache.commons.math3.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.threed.*;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.geometry.Vector;
import org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.Embedding;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Precision;
 
public class LineTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                   public void testRevert_PositiveDirection() {
                       // Setup
                       Vector3D origin = new Vector3D(1, 2, 3);
                       Vector3D direction = new Vector3D(4, 5, 6);
                       Line originalLine = new Line(origin, direction);
                       
                       // Execute
                       Line revertedLine = originalLine.revert();
                       
                       // Verify
                       assertEquals("Origin should remain the same", 
                                    originalLine.getOrigin(), revertedLine.getOrigin());
                       assertEquals("Direction should be negated",
                                    originalLine.getDirection().negate(), revertedLine.getDirection());
                       
                       // Verify original line wasn't modified
                       assertEquals("Original direction should remain unchanged",
                                    direction, originalLine.getDirection());
                       assertEquals("Original origin should remain unchanged",
                                    origin, originalLine.getOrigin());
                   }

 @Test
                   public void testRevert_NegativeDirection() {
                       // Setup
                       Vector3D origin = new Vector3D(0, 0, 0);
                       Vector3D direction = new Vector3D(-1, -2, -3);
                       Line originalLine = new Line(origin, direction);
                       
                       // Execute
                       Line revertedLine = originalLine.revert();
                       
                       // Verify
                       assertEquals("Origin should remain the same", 
                                    origin, revertedLine.getOrigin());
                       assertEquals("Direction should be positive",
                                    new Vector3D(1, 2, 3), revertedLine.getDirection());
                   }

 @Test
                   public void testRevert_ZeroDirection() {
                       // Setup
                       Vector3D origin = new Vector3D(1, 1, 1);
                       Vector3D direction = new Vector3D(0, 0, 0);
                       Line originalLine = new Line(origin, direction);
                       
                       // Execute
                       Line revertedLine = originalLine.revert();
                       
                       // Verify
                       assertEquals("Origin should remain the same", 
                                    origin, revertedLine.getOrigin());
                       assertEquals("Direction should remain zero",
                                    direction, revertedLine.getDirection());
                   }

 @Test
                   public void testRevert_DoubleRevertReturnsOriginal() {
                       // Setup
                       Vector3D p1 = new Vector3D(1, 0, 0);
                       Vector3D p2 = new Vector3D(0, 1, 0);
                       Line originalLine = new Line(p1, p2);
                       
                       // Execute
                       Line revertedOnce = originalLine.revert();
                       Line revertedTwice = revertedOnce.revert();
                       
                       // Verify
                       assertEquals("Double revert should return equivalent to original",
                                    originalLine.getDirection(), revertedTwice.getDirection());
                       assertEquals("Double revert should return equivalent to original",
                                    originalLine.getOrigin(), revertedTwice.getOrigin());
                   }

 @Test
                   public void testRevert_UsingCopyConstructor() {
                       // Setup
                       Vector3D p1 = new Vector3D(1, 2, 3);
                       Vector3D p2 = new Vector3D(4, 5, 6);
                       Line originalLine = new Line(p1, p2);
                       
                       // Execute
                       Line revertedLine = originalLine.revert();
                       Line lineCopy = new Line(revertedLine);
                       
                       // Verify
                       assertEquals("Copied line should have same origin as reverted",
                                    revertedLine.getOrigin(), lineCopy.getOrigin());
                       assertEquals("Copied line should have same direction as reverted",
                                    revertedLine.getDirection(), lineCopy.getDirection());
                   }

 @Test
               public void testResetDirectionVector() {
                   // Create two distinct points
                   Vector3D p1 = new Vector3D(1.0, 0.0, 0.0);
                   Vector3D p2 = new Vector3D(2.0, 0.0, 0.0);
                   
                   // Create line and reset with p1 and p2
                   Line line = new Line(p1, p2);
                   
                   // Get the direction vector
                   Vector3D direction = line.getDirection();
                   
                   // Expected direction should be from p1 to p2 (p2 - p1)
                   Vector3D expectedDirection = p2.subtract(p1).normalize();
                   
                   // Verify direction matches expected
                   assertEquals(expectedDirection.getX(), direction.getX(), 1e-10);
                   assertEquals(expectedDirection.getY(), direction.getY(), 1e-10);
                   assertEquals(expectedDirection.getZ(), direction.getZ(), 1e-10);
                   
                   // Also verify a point along the line
                   Vector3D pointAt1 = line.pointAt(1.0);
                   Vector3D expectedPointAt1 = p2;
                   assertEquals(expectedPointAt1.getX(), pointAt1.getX(), 1e-10);
                   assertEquals(expectedPointAt1.getY(), pointAt1.getY(), 1e-10);
                   assertEquals(expectedPointAt1.getZ(), pointAt1.getZ(), 1e-10);
               }

 @Test
              public void testResetDetectsNormSqToNormMutation() {
                  // Create two points where the squared norm and norm would produce different results
                  Vector3D p1 = new Vector3D(1, 2, 3);
                  Vector3D p2 = new Vector3D(4, 5, 6);
                  
                  // Calculate expected values using getNormSq()
                  Vector3D delta = p2.subtract(p1);
                  double expectedNorm2 = delta.getNormSq();
                  Vector3D expectedDirection = new Vector3D(1.0 / Math.sqrt(expectedNorm2), delta);
                  Vector3D expectedZero = new Vector3D(1.0, p1, -p1.dotProduct(delta) / expectedNorm2, delta);
                  
                  // Create line and reset with these points
                  Line line = new Line(p1, p2);
                  
                  // Verify direction and zero point would be different if getNorm() was used instead
                  // The actual values would be different if the mutation was present
                  assertEquals(expectedDirection.getX(), line.getDirection().getX(), 1e-10);
                  assertEquals(expectedDirection.getY(), line.getDirection().getY(), 1e-10);
                  assertEquals(expectedDirection.getZ(), line.getDirection().getZ(), 1e-10);
                  
                  assertEquals(expectedZero.getX(), line.getOrigin().getX(), 1e-10);
                  assertEquals(expectedZero.getY(), line.getOrigin().getY(), 1e-10);
                  assertEquals(expectedZero.getZ(), line.getOrigin().getZ(), 1e-10);
              }

 @Test(expected = MathIllegalArgumentException.class)
              public void testResetWithSamePointsThrowsException() {
                  Vector3D p1 = new Vector3D(1, 1, 1);
                  Line line = new Line(p1, p1);
              }

 @Test
             public void testResetWithVeryClosePoints() {
                 // Create two points that are very close but not identical
                 Vector3D p1 = new Vector3D(1.0, 1.0, 1.0);
                 Vector3D p2 = new Vector3D(1.0 + 1e-10, 1.0 + 1e-10, 1.0 + 1e-10);
                 
                 // This should work fine with original code but mutant would throw exception
                 Line line = new Line(p1, p2);
                 
                 // Verify the line was properly constructed
                 Vector3D direction = line.getDirection();
                 Vector3D zero = line.getOrigin();
                 
                 // Basic sanity checks
                 assertTrue(direction.getNorm() > 0.999 && direction.getNorm() < 1.001); // normalized
                 assertTrue(zero.distance(p1) < 1e-8); // origin should be close to p1
             }

 @Test
             public void testResetWithCoincidentPoints() {
                 Vector3D p1 = new Vector3D(1.0, 2.0, 3.0);
                 Vector3D p2 = new Vector3D(1.0, 2.0, 3.0);
                 
                 thrown.expect(MathIllegalArgumentException.class);
                 thrown.expectMessage(LocalizedFormats.ZERO_NORM.toString());
                 
                 new Line(p1, p2);
             }

 @Test
        public void testResetDirectionVectorNormalization() {
            // Create two distinct points
            Vector3D p1 = new Vector3D(1, 0, 0);
            Vector3D p2 = new Vector3D(2, 0, 0);
            
            // Create line and reset with these points
            Line line = new Line(p1, p2);
            
            // Get the direction vector
            Vector3D direction = line.getDirection();
            
            // Calculate its norm
            double directionNorm = direction.getNorm();
            
            // Original code should normalize to length 1
            // Mutated code would give length equal to norm2 (which is 1 in this case)
            // To better catch the mutant, let's use points where norm2 != 1
            Vector3D p3 = new Vector3D(1, 2, 3);
            Vector3D p4 = new Vector3D(4, 5, 6);
            line.reset(p3, p4);
            direction = line.getDirection();
            directionNorm = direction.getNorm();
            
            // The direction vector should be normalized (length 1)
            assertEquals(1.0, directionNorm, 1e-10);
            
            // Additionally verify the direction is correct by checking it's parallel to delta
            Vector3D delta = p4.subtract(p3);
            double dotProduct = direction.dotProduct(delta);
            double angle = FastMath.acos(dotProduct / (direction.getNorm() * delta.getNorm()));
            assertEquals(0.0, angle, 1e-10);  // should be parallel
        }

 @Test
       public void testResetDirectionVectorNormalization1() {
           // Setup test points
           Vector3D p1 = new Vector3D(1.0, 2.0, 3.0);
           Vector3D p2 = new Vector3D(4.0, 5.0, 6.0);
           
           // Create line and reset with test points
           Line line = new Line(p1, p2);
           line.reset(p1, p2);
           
           // Get the direction vector
           Vector3D direction = line.getDirection();
           
           // Verify the direction vector is normalized (unit length)
           // Original code would make this ~1.0, mutant would make it much larger
           assertEquals(1.0, direction.getNorm(), 1e-10);
           
           // Additional verification that the direction is correct
           Vector3D expectedDirection = p2.subtract(p1).normalize();
           assertEquals(expectedDirection.getX(), direction.getX(), 1e-10);
           assertEquals(expectedDirection.getY(), direction.getY(), 1e-10);
           assertEquals(expectedDirection.getZ(), direction.getZ(), 1e-10);
       }

 @Test
      public void testResetDetectsSignMutant() {
          // Create two non-zero, non-parallel vectors
          Vector3D p1 = new Vector3D(1.0, 2.0, 3.0);
          Vector3D p2 = new Vector3D(4.0, 5.0, 6.0);
          
          // Create line and reset it with these points
          Line line = new Line(p1, p2);
          
          // Calculate expected zero point manually
          Vector3D delta = p2.subtract(p1);
          double norm2 = delta.getNormSq();
          double expectedCoeff = -p1.dotProduct(delta)/norm2;
          Vector3D expectedZero = new Vector3D(1.0, p1, expectedCoeff, delta);
          
          // Get actual zero point from line
          Vector3D actualZero = line.getOrigin();
          
          // Verify zero point is calculated correctly (would fail with mutant)
          assertEquals(expectedZero.getX(), actualZero.getX(), 1.0e-10);
          assertEquals(expectedZero.getY(), actualZero.getY(), 1.0e-10);
          assertEquals(expectedZero.getZ(), actualZero.getZ(), 1.0e-10);
          
          // Additional verification - check that zero point lies on the line between p1 and p2
          Vector3D lineDirection = line.getDirection();
          Vector3D zeroToP1 = p1.subtract(actualZero);
          // Should be parallel to direction
          assertEquals(0.0, zeroToP1.crossProduct(lineDirection).getNorm(), 1.0e-10);
      }

 @Test
     public void testResetZeroPointCalculation() {
         // Setup test points
         Vector3D p1 = new Vector3D(1.0, 2.0, 3.0);
         Vector3D p2 = new Vector3D(4.0, 5.0, 6.0);
         
         // Create line and reset with test points
         Line line = new Line(p1, p2);
         line.reset(p1, p2);
         
         // Get the calculated zero point
         Vector3D zeroPoint = line.getOrigin();
         
         // Verify zero point is correctly calculated
         // The zero point should be p1 plus some delta adjustment
         // Check that zero point is not equal to p1 (since there's an adjustment)
         assertNotEquals(p1, zeroPoint);
         
         // Check that zero point lies on the line between p1 and p2
         Vector3D direction = line.getDirection();
         double abscissa = line.getAbscissa(zeroPoint);
         assertEquals(0.0, abscissa, 1e-10);  // zero point should have abscissa 0
         
         // Verify the specific calculation: zero = 1.0*p1 + adjustment*delta
         Vector3D delta = p2.subtract(p1);
         double norm2 = delta.getNormSq();
         Vector3D expectedZero = new Vector3D(1.0, p1, -p1.dotProduct(delta)/norm2, delta);
         assertEquals(expectedZero, zeroPoint);
     }

 @Test
    public void testResetZeroPointCalculation1() {
        // Create initial line (won't affect test since we're resetting)
        Vector3D initialP1 = new Vector3D(0, 0, 0);
        Vector3D initialP2 = new Vector3D(1, 0, 0);
        Line line = new Line(initialP1, initialP2);
        
        // Test points - distinct and non-zero length
        Vector3D p1 = new Vector3D(1, 2, 3);
        Vector3D p2 = new Vector3D(4, 5, 6);
        
        // Reset the line with new points
        line.reset(p1, p2);
        
        // Calculate expected zero point manually
        Vector3D delta = p2.subtract(p1);
        double norm2 = delta.getNormSq();
        Vector3D expectedZero = new Vector3D(1.0, p1, -p1.dotProduct(delta) / norm2, delta);
        
        // Verify zero point is calculated correctly using p1
        assertEquals("Zero point should be calculated based on p1", 
                     expectedZero, 
                     line.getOrigin());
        
        // Additional verification that it's not using p2
        Vector3D wrongZeroUsingP2 = new Vector3D(1.0, p2, -p1.dotProduct(delta) / norm2, delta);
        assertNotEquals("Zero point should not be calculated based on p2",
                       wrongZeroUsingP2,
                       line.getOrigin());
    }

 @Test
   public void testRevertCreatesIndependentCopy() {
       // Create original line
       Vector3D p1 = new Vector3D(1, 0, 0);
       Vector3D p2 = new Vector3D(0, 1, 0);
       Line original = new Line(p1, p2);
       
       // Get reverted line
       Line reverted = original.revert();
       
       // Store original values
       Vector3D originalDirection = original.getDirection();
       Vector3D originalZero = original.getOrigin();
       
       // Modify the reverted line's internal state through reset
       Vector3D newP1 = new Vector3D(0, 0, 0);
       Vector3D newP2 = new Vector3D(0, 0, 1);
       reverted.reset(newP1, newP2);
       
       // Verify original line remains unchanged
       assertEquals("Original direction should not change", 
                    originalDirection, original.getDirection());
       assertEquals("Original origin should not change",
                    originalZero, original.getOrigin());
       
       // Verify reverted line changed
       assertNotEquals("Reverted line direction should change",
                      originalDirection, reverted.getDirection());
       assertNotEquals("Reverted line origin should change",
                      originalZero, reverted.getOrigin());
   }

 @Test
      public void testRevertChangesDirection() {
          // Create two distinct points
          Vector3D p1 = new Vector3D(1, 0, 0);
          Vector3D p2 = new Vector3D(2, 0, 0);
          
          // Create original line
          Line originalLine = new Line(p1, p2);
          Vector3D originalDirection = originalLine.getDirection();
          
          // Revert the line
          Line revertedLine = originalLine.revert();
          Vector3D revertedDirection = revertedLine.getDirection();
          
          // Verify directions are opposite (original should be negated)
          assertEquals(-1, revertedDirection.dotProduct(originalDirection), 1e-15);
          
          // Verify they are exactly opposite (each component should be negated)
          assertEquals(-originalDirection.getX(), revertedDirection.getX(), 1e-15);
          assertEquals(-originalDirection.getY(), revertedDirection.getY(), 1e-15);
          assertEquals(-originalDirection.getZ(), revertedDirection.getZ(), 1e-15);
          
          // Also verify the zero point remains the same
          assertEquals(originalLine.getOrigin(), revertedLine.getOrigin());
      }

 @Test
 public void testRevertDirection() {
     // Setup test points
     Vector3D p1 = new Vector3D(1, 0, 0);
     Vector3D p2 = new Vector3D(2, 0, 0);
     
     // Create original line
     Line originalLine = new Line(p1, p2);
     Vector3D originalDirection = originalLine.getDirection();
     
     // Create reverted line
     Line revertedLine = originalLine.revert();
     Vector3D revertedDirection = revertedLine.getDirection();
     
     // Verify directions
     // Original line direction should be (1,0,0)
     assertEquals(1.0, originalDirection.getX(), 1e-10);
     assertEquals(0.0, originalDirection.getY(), 1e-10);
     assertEquals(0.0, originalDirection.getZ(), 1e-10);
     
     // Reverted line direction should be (-1,0,0)
     assertEquals(-1.0, revertedDirection.getX(), 1e-10);
     assertEquals(0.0, revertedDirection.getY(), 1e-10);
     assertEquals(0.0, revertedDirection.getZ(), 1e-10);
     
     // Additional verification - revert again should give original direction
     Line revertedAgain = revertedLine.revert();
     Vector3D revertedAgainDirection = revertedAgain.getDirection();
     assertEquals(originalDirection, revertedAgainDirection);
 }

}
