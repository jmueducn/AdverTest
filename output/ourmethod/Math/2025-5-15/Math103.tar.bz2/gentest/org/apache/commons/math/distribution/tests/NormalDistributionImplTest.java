package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.special.Erf;
 
public class NormalDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                        public void testCumulativeProbability_ExceptionHandling() throws Exception {
                                                                                                                                                                                                                            // Mock static Erf class to throw exception
                                                                                                                                                                                                                            mockStatic(Erf.class);
                                                                                                                                                                                                                            when(Erf.erf(anyDouble())).thenThrow(new MaxIterationsExceededException(100));
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Create test distribution
                                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test values within 20 SD - should throw exception
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                dist.cumulativeProbability(0.5);
                                                                                                                                                                                                                                fail("Expected MaxIterationsExceededException");
                                                                                                                                                                                                                            } catch (MaxIterationsExceededException e) {
                                                                                                                                                                                                                                // expected
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                        public void testCumulativeProbability_ExceptionHandlingEdgeCases() throws Exception {
                                                                                                                                                                                                            // Mock static Erf class to throw exception
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Create test distribution
                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test values beyond 20 SD - should return 0 or 1 despite exception
                                                                                                                                                                                                            assertEquals(0.0, dist.cumulativeProbability(-21.0), 1e-6);
                                                                                                                                                                                                            assertEquals(1.0, dist.cumulativeProbability(21.0), 1e-6);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Verify static mock
                                                                                                                                                                                                            Erf.erf(anyDouble());
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                    public void testCumulativeProbability_TypicalValues() throws MathException {
                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0); // Standard normal distribution
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test typical values
                                                                                                                                                                                                        assertEquals(0.5, dist.cumulativeProbability(0.0), 1e-6);
                                                                                                                                                                                                        assertEquals(0.841344746, dist.cumulativeProbability(1.0), 1e-6);
                                                                                                                                                                                                        assertEquals(0.158655254, dist.cumulativeProbability(-1.0), 1e-6);
                                                                                                                                                                                                        assertEquals(0.977249868, dist.cumulativeProbability(2.0), 1e-6);
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testCumulativeProbability_NonStandardDistribution() throws MathException {
                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(5.0, 2.0); // Mean=5, SD=2
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertEquals(0.5, dist.cumulativeProbability(5.0), 1e-6);
                                                                                                                                                                                                        assertEquals(0.691462461, dist.cumulativeProbability(6.0), 1e-6);
                                                                                                                                                                                                        assertEquals(0.308537539, dist.cumulativeProbability(4.0), 1e-6);
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testCumulativeProbability_ExtremeValues() throws MathException {
                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test values far from mean (beyond 20 standard deviations)
                                                                                                                                                                                                        assertEquals(0.0, dist.cumulativeProbability(-21.0), 1e-6);
                                                                                                                                                                                                        assertEquals(1.0, dist.cumulativeProbability(21.0), 1e-6);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test values very close to mean
                                                                                                                                                                                                        assertEquals(0.519938806, dist.cumulativeProbability(0.05), 1e-6);
                                                                                                                                                                                                        assertEquals(0.480061194, dist.cumulativeProbability(-0.05), 1e-6);
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testCumulativeProbability_EdgeCases() throws MathException {
                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test with very small standard deviation
                                                                                                                                                                                                        NormalDistributionImpl smallSD = new NormalDistributionImpl(0.0, 0.0001);
                                                                                                                                                                                                        assertEquals(0.0, smallSD.cumulativeProbability(-0.0021), 1e-6); // -21 SD
                                                                                                                                                                                                        assertEquals(1.0, smallSD.cumulativeProbability(0.0021), 1e-6);  // +21 SD
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test with large standard deviation
                                                                                                                                                                                                        NormalDistributionImpl largeSD = new NormalDistributionImpl(0.0, 1000.0);
                                                                                                                                                                                                        assertEquals(0.5, largeSD.cumulativeProbability(0.0), 1e-6);
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testSetStandardDeviation_ZeroValueShouldThrowException() {
                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                        NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Expect exception
                                                                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                        thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Act
                                                                                                                                                                                                        distribution.setStandardDeviation(0.0);
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testSetStandardDeviation_NegativeValueShouldThrowException() {
                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                        NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Expect exception
                                                                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                        thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Act
                                                                                                                                                                                                        distribution.setStandardDeviation(-1.0);
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testSetStandardDeviation_PositiveValueShouldBeAccepted() {
                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                        NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Act
                                                                                                                                                                                                        distribution.setStandardDeviation(1.0);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                        // No exception should be thrown
                                                                                                                                                                                                        // We can optionally verify the value was set
                                                                                                                                                                                                        // assertEquals(1.0, distribution.getStandardDeviation(), 0.0);
                                                                                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                              public void testSetStandardDeviation_NegativeValue_ShouldThrowException() {
                                                                                                                                                                                                  // This test will detect the mutant because:
                                                                                                                                                                                                  // Original code: throws exception for sd <= 0.0 (including negative values)
                                                                                                                                                                                                  // Mutated code: only throws for sd == 0.0 (accepts negative values)
                                                                                                                                                                                                  NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                  normalDistribution.setStandardDeviation(-1.0);
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                              public void testSetStandardDeviation_PositiveValue_ShouldSetCorrectly() {
                                                                                                                                                                                                  NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                  double validSd = 1.5;
                                                                                                                                                                                                  normalDistribution.setStandardDeviation(validSd);
                                                                                                                                                                                                  assertEquals(validSd, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                              public void testSetStandardDeviation_ZeroValue_ShouldThrowException() {
                                                                                                                                                                                                  NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                  normalDistribution.setStandardDeviation(0.0);
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                              public void testSetStandardDeviation_NegativeValue_ThrowsException() {
                                                                                                                                                                                                  NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                  thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                  thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                  distribution.setStandardDeviation(-1.0);
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                              public void testSetStandardDeviation_ZeroValue_ThrowsException() {
                                                                                                                                                                                                  NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                  thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                  thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                  distribution.setStandardDeviation(0.0);
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                              public void testSetStandardDeviation_PositiveValue_SetsCorrectly() {
                                                                                                                                                                                                  NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                  distribution.setStandardDeviation(1.0);
                                                                                                                                                                                                  assertEquals(1.0, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                             public void testSetStandardDeviation_ZeroValue_ThrowsExceptionWithCorrectMessage() {
                                                                                                                                                                                                 // Arrange
                                                                                                                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                 double invalidSd = 0.0;
                                                                                                                                                                                         
                                                                                                                                                                                                 // Expect exception
                                                                                                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                 thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                         
                                                                                                                                                                                                 // Act
                                                                                                                                                                                                 normalDistribution.setStandardDeviation(invalidSd);
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                             public void testSetStandardDeviation_NegativeValue_ThrowsException1() {
                                                                                                                                                                                                 // Arrange
                                                                                                                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                 double invalidSd = -1.0;
                                                                                                                                                                                         
                                                                                                                                                                                                 // Expect exception
                                                                                                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                 thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                         
                                                                                                                                                                                                 // Act
                                                                                                                                                                                                 normalDistribution.setStandardDeviation(invalidSd);
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                             public void testSetStandardDeviation_PositiveValue_SetsCorrectly1() {
                                                                                                                                                                                                 // Arrange
                                                                                                                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                 double validSd = 1.5;
                                                                                                                                                                                         
                                                                                                                                                                                                 // Act
                                                                                                                                                                                                 normalDistribution.setStandardDeviation(validSd);
                                                                                                                                                                                         
                                                                                                                                                                                                 // Assert
                                                                                                                                                                                                 assertEquals(validSd, normalDistribution.getStandardDeviation(), 0.0);
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                            public void testSetStandardDeviation_InvalidInput_ExceptionMessage() {
                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                double invalidSd = -1.0;
                                                                                                                                                                                                
                                                                                                                                                                                                // Set expectation for exception
                                                                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                
                                                                                                                                                                                                // Act
                                                                                                                                                                                                distribution.setStandardDeviation(invalidSd);
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testSetStandardDeviation_ZeroInput_ExceptionMessage() {
                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                double zeroSd = 0.0;
                                                                                                                                                                                                
                                                                                                                                                                                                // Set expectation for exception
                                                                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                
                                                                                                                                                                                                // Act
                                                                                                                                                                                                distribution.setStandardDeviation(zeroSd);
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testSetStandardDeviation_ValidInput_NoException() {
                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                double validSd = 1.0;
                                                                                                                                                                                                
                                                                                                                                                                                                // Act
                                                                                                                                                                                                distribution.setStandardDeviation(validSd);
                                                                                                                                                                                                
                                                                                                                                                                                                // No exception expected for valid input
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                           public void testConstructorWithNegativeSD() {
                                                                                                                                                                                               try {
                                                                                                                                                                                                   new NormalDistributionImpl(0.0, -1.0);
                                                                                                                                                                                                   fail("Expected IllegalArgumentException");
                                                                                                                                                                                               } catch (IllegalArgumentException e) {
                                                                                                                                                                                                   // Expected behavior - test passes
                                                                                                                                                                                               }
                                                                                                                                                                                           }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                      public void testSetStandardDeviation_NonPositiveValue() {
                                                                                                                                                                                          NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                                                                                          normalDist.setStandardDeviation(0.0); // should throw exception
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                      public void testSetStandardDeviation_NegativeValue() {
                                                                                                                                                                                          NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                                                                                          try {
                                                                                                                                                                                              normalDist.setStandardDeviation(-1.0);
                                                                                                                                                                                              fail("Expected IllegalArgumentException");
                                                                                                                                                                                          } catch (IllegalArgumentException e) {
                                                                                                                                                                                              // Expected behavior - test passes
                                                                                                                                                                                          }
                                                                                                                                                                                          
                                                                                                                                                                                          // Additional check to ensure field wasn't modified
                                                                                                                                                                                          assertEquals(1.0, normalDist.getStandardDeviation(), 0.0001);
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                      public void testSetStandardDeviation_PositiveValue() {
                                                                                                                                                                                          NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                                                                                          normalDist.setStandardDeviation(2.5);
                                                                                                                                                                                          assertEquals(2.5, normalDist.getStandardDeviation(), 0.0001);
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                      public void testSetStandardDeviationInConstructor() {
                                                                                                                                                                                          // Test that constructor properly validates through setStandardDeviation
                                                                                                                                                                                          try {
                                                                                                                                                                                              new NormalDistributionImpl(0.0, 0.0);
                                                                                                                                                                                              fail("Expected IllegalArgumentException for zero sd in constructor");
                                                                                                                                                                                          } catch (IllegalArgumentException e) {
                                                                                                                                                                                              assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                          }
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                 public void testSetStandardDeviationPositiveValue() {
                                                                                                                                                                                     NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                     double validSd = 1.5;
                                                                                                                                                                                     normalDistribution.setStandardDeviation(validSd);
                                                                                                                                                                                     assertEquals(validSd, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                                 }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                 public void testSetStandardDeviationZeroValue() {
                                                                                                                                                                                     NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                     normalDistribution.setStandardDeviation(0.0);
                                                                                                                                                                                 }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                 public void testSetStandardDeviationNegativeValue() {
                                                                                                                                                                                     NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                     normalDistribution.setStandardDeviation(-1.0);
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                 public void testSetStandardDeviationValidation() {
                                                                                                                                                                                     NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                     
                                                                                                                                                                                     // Test positive value
                                                                                                                                                                                     dist.setStandardDeviation(1.0);
                                                                                                                                                                                     assertEquals(1.0, dist.getStandardDeviation(), 0.0);
                                                                                                                                                                                     
                                                                                                                                                                                     // Test zero value
                                                                                                                                                                                     try {
                                                                                                                                                                                         dist.setStandardDeviation(0.0);
                                                                                                                                                                                         fail("Expected IllegalArgumentException");
                                                                                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                                                                                         assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                     }
                                                                                                                                                                                     
                                                                                                                                                                                     // Test negative value
                                                                                                                                                                                     try {
                                                                                                                                                                                         dist.setStandardDeviation(-1.0);
                                                                                                                                                                                         fail("Expected IllegalArgumentException");
                                                                                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                                                                                         assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                     }
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                            public void testCumulativeProbabilityBoundaryCondition() throws MathException {
                                                                                                                                                                                // Setup with mean 0 and sd 1 for simplicity
                                                                                                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                
                                                                                                                                                                                // Test value that is between -20 and -10 standard deviations from mean
                                                                                                                                                                                double testValue = -15.0;
                                                                                                                                                                                
                                                                                                                                                                                // The original would treat -15 differently from the mutant
                                                                                                                                                                                // For the original: -15 > mean - 20*sd (0 - 20*1 = -20) => different calculation path
                                                                                                                                                                                // For the mutant: -15 < mean - 10*sd (0 - 10*1 = -10) => different calculation path
                                                                                                                                                                                
                                                                                                                                                                                // We can't know the exact expected value, but we can verify it's not zero
                                                                                                                                                                                // (which it might be for very extreme values)
                                                                                                                                                                                double probability = dist.cumulativeProbability(testValue);
                                                                                                                                                                                
                                                                                                                                                                                // Assert that the probability is very small but non-zero
                                                                                                                                                                                assertTrue("Probability should be greater than 0", probability > 0.0);
                                                                                                                                                                                assertTrue("Probability should be very small", probability < 1e-10);
                                                                                                                                                                                
                                                                                                                                                                                // Additional test case right at the boundary
                                                                                                                                                                                double boundaryValue = -10.0;
                                                                                                                                                                                double boundaryProbability = dist.cumulativeProbability(boundaryValue);
                                                                                                                                                                                assertTrue(boundaryProbability > 0.0);
                                                                                                                                                                            }

    @Test
                                                                                                                                                                       public void testCumulativeProbabilityForExtremeLowValues() throws MathException {
                                                                                                                                                                           // Setup with mean 0 and standard deviation 1 for simplicity
                                                                                                                                                                           NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                           
                                                                                                                                                                           // Test value between 20 and 30 standard deviations below mean
                                                                                                                                                                           double testValue = -25.0;
                                                                                                                                                                           
                                                                                                                                                                           // Original should return 0 (too extreme), mutant would return non-zero
                                                                                                                                                                           double probability = dist.cumulativeProbability(testValue);
                                                                                                                                                                           
                                                                                                                                                                           // Assert that probability is 0 (should be considered extreme)
                                                                                                                                                                           assertEquals(0.0, probability, 0.000001);
                                                                                                                                                                           
                                                                                                                                                                           // Also test exactly at 20 standard deviations (boundary case)
                                                                                                                                                                           double boundaryValue = -20.0;
                                                                                                                                                                           double boundaryProbability = dist.cumulativeProbability(boundaryValue);
                                                                                                                                                                           assertEquals(0.0, boundaryProbability, 0.000001);
                                                                                                                                                                           
                                                                                                                                                                           // Test just inside the boundary (19 std devs)
                                                                                                                                                                           double insideValue = -19.0;
                                                                                                                                                                           double insideProbability = dist.cumulativeProbability(insideValue);
                                                                                                                                                                           assertTrue(insideProbability > 0.0);
                                                                                                                                                                       }

    @Test
                                                                                                                                                                  public void testCumulativeProbabilityForExtremeLeftTail() throws MathException {
                                                                                                                                                                      // Setup normal distribution with mean 0 and sd 1
                                                                                                                                                                      NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                      
                                                                                                                                                                      // Test value more than 20 standard deviations below mean
                                                                                                                                                                      double extremeValue = -21.0;
                                                                                                                                                                      
                                                                                                                                                                      // In original code, this should return a very small probability (near 0)
                                                                                                                                                                      // In mutated code (x > ...), it would return a different value
                                                                                                                                                                      double probability = dist.cumulativeProbability(extremeValue);
                                                                                                                                                                      
                                                                                                                                                                      // The probability should be extremely small (effectively 0) for such an extreme value
                                                                                                                                                                      assertEquals(0.0, probability, 1e-20);
                                                                                                                                                                      
                                                                                                                                                                      // Also test boundary case exactly at 20 standard deviations below mean
                                                                                                                                                                      double boundaryValue = -20.0;
                                                                                                                                                                      double boundaryProbability = dist.cumulativeProbability(boundaryValue);
                                                                                                                                                                      assertTrue(boundaryProbability > 0.0); // Should be small but non-zero
                                                                                                                                                                  }

    @Test
                                                                                                                                                             public void testSetStandardDeviationWithInvalidValue() {
                                                                                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                 try {
                                                                                                                                                                     normalDistribution.setStandardDeviation(0.0);
                                                                                                                                                                     fail("Should have thrown IllegalArgumentException");
                                                                                                                                                                 } catch (IllegalArgumentException e) {
                                                                                                                                                                     assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                 }
                                                                                                                                                             }

    @Test
                                                                                                                                                             public void testSetStandardDeviationWithValidValue() {
                                                                                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                 normalDistribution.setStandardDeviation(2.5);
                                                                                                                                                                 assertEquals(2.5, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                                             }

    @Test
                                                                                                                                                         public void testCumulativeProbabilityWithMutantCondition() throws MathException {
                                                                                                                                                             // Create normal distribution instance with mean=0 and sd=1
                                                                                                                                                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                             
                                                                                                                                                             // Test with x value that is NOT less than (mean - 20*sd)
                                                                                                                                                             // mean - 20*sd = 0 - 20*1 = -20
                                                                                                                                                             double x = -19.0; // should not trigger original condition but will trigger mutated condition
                                                                                                                                                             
                                                                                                                                                             // The mutated version will treat this as true regardless of x value
                                                                                                                                                             double result = normalDistribution.cumulativeProbability(x);
                                                                                                                                                             
                                                                                                                                                             // In original version, this x value wouldn't trigger the special case
                                                                                                                                                             // So we expect a normal probability calculation
                                                                                                                                                             // We can't predict exact probability value, but it should be > 0 and < 1
                                                                                                                                                             assertTrue("Probability should be greater than 0", result > 0);
                                                                                                                                                             assertTrue("Probability should be less than 1", result < 1);
                                                                                                                                                             
                                                                                                                                                             // Additional test with another value that would clearly not satisfy original condition
                                                                                                                                                             double x2 = 0.0; // mean value
                                                                                                                                                             double result2 = normalDistribution.cumulativeProbability(x2);
                                                                                                                                                             assertEquals("Probability at mean should be 0.5", 0.5, result2, 0.0001);
                                                                                                                                                         }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                    public void testSetStandardDeviation_ZeroValue() {
                                                                                                                                                        // This test will catch the mutant because:
                                                                                                                                                        // Original: throws exception for 0.0
                                                                                                                                                        // Mutated: will accept 0.0 and not throw exception
                                                                                                                                                        NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                                                        normalDist.setStandardDeviation(0.0);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testSetStandardDeviation_PositiveValue1() {
                                                                                                                                                        NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                                                        double testValue = 1.5;
                                                                                                                                                        normalDist.setStandardDeviation(testValue);
                                                                                                                                                        assertEquals(testValue, normalDist.getStandardDeviation(), 0.0001);
                                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                    public void testSetStandardDeviation_NegativeValue1() {
                                                                                                                                                        NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                                                        normalDist.setStandardDeviation(-0.5);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testSetStandardDeviation_SmallPositiveValue() {
                                                                                                                                                        NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                                                        double smallValue = 0.0001;
                                                                                                                                                        normalDist.setStandardDeviation(smallValue);
                                                                                                                                                        assertEquals(smallValue, normalDist.getStandardDeviation(), 0.0001);
                                                                                                                                                    }

    @Test
                                                                                                                                               public void testSetStandardDeviation_ShouldThrowForZero() {
                                                                                                                                                   org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                                                                                   org.apache.commons.math.distribution.NormalDistributionImpl normalDistribution = 
                                                                                                                                                       new org.apache.commons.math.distribution.NormalDistributionImpl();
                                                                                                                                                   
                                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                                   thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                   normalDistribution.setStandardDeviation(0.0);
                                                                                                                                               }

    @Test
                                                                                                                                               public void testSetStandardDeviation_ShouldThrowForNegative() {
                                                                                                                                                   NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                   ExpectedException thrown = ExpectedException.none();
                                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                                   thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                   normalDistribution.setStandardDeviation(-1.0);
                                                                                                                                               }

    @Test
                                                                                                                                               public void testSetStandardDeviation_ShouldThrowForSmallPositive() {
                                                                                                                                                   NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                   try {
                                                                                                                                                       normalDistribution.setStandardDeviation(0.1);
                                                                                                                                                       fail("Expected IllegalArgumentException");
                                                                                                                                                   } catch (IllegalArgumentException e) {
                                                                                                                                                       assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                   }
                                                                                                                                               }

    @Test
                                                                                                                                               public void testSetStandardDeviation_ShouldAcceptValidValue() {
                                                                                                                                                   NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                   normalDistribution.setStandardDeviation(1.0);
                                                                                                                                                   assertEquals(1.0, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                               }

    @Test
                                                                                                                                               public void testSetStandardDeviation_ShouldAcceptBoundaryValue() {
                                                                                                                                                   // Create new normal distribution instance
                                                                                                                                                   NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                   
                                                                                                                                                   // Test with value just above 0.0 (original boundary)
                                                                                                                                                   normalDistribution.setStandardDeviation(Double.MIN_VALUE);
                                                                                                                                                   assertEquals(Double.MIN_VALUE, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                               }

    @Test
                                                                                                                                          public void testCumulativeProbabilityForLargeDeviation() throws MathException {
                                                                                                                                              // Setup with mean=0 and standard deviation=1 for simplicity
                                                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                              
                                                                                                                                              // Test a value that's between 10σ and 20σ from the mean
                                                                                                                                              double x = 15.0; // 15σ from mean
                                                                                                                                              
                                                                                                                                              // In original code, this should return a very small but non-zero probability
                                                                                                                                              // In mutated code, this would be treated differently (as an outlier)
                                                                                                                                              double probability = dist.cumulativeProbability(x);
                                                                                                                                              
                                                                                                                                              // Verify the probability is very small but greater than 0
                                                                                                                                              assertTrue("Probability should be greater than 0 for x=15σ", probability > 0);
                                                                                                                                              assertTrue("Probability should be very small for x=15σ", probability < 1e-10);
                                                                                                                                              
                                                                                                                                              // Also test exactly at 10σ boundary
                                                                                                                                              double xBoundary = 10.0;
                                                                                                                                              double boundaryProbability = dist.cumulativeProbability(xBoundary);
                                                                                                                                              assertTrue("Probability at 10σ boundary should be > 0", boundaryProbability > 0);
                                                                                                                                          }

    @Test
                                                                                                                                     public void testCumulativeProbabilityAtOutlierBoundary() throws Exception {
                                                                                                                                         // Setup
                                                                                                                                         double mean = 0.0;
                                                                                                                                         double sd = 1.0;
                                                                                                                                         NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                         
                                                                                                                                         // Test values around both boundaries
                                                                                                                                         double x1 = mean + 19 * sd;  // just below 20*sd
                                                                                                                                         double x2 = mean + 21 * sd;  // just above 20*sd
                                                                                                                                         double x3 = mean + 29 * sd;  // just below 30*sd
                                                                                                                                         double x4 = mean + 31 * sd;  // just above 30*sd
                                                                                                                                         
                                                                                                                                         // Get probabilities
                                                                                                                                         double p1 = dist.cumulativeProbability(x1);
                                                                                                                                         double p2 = dist.cumulativeProbability(x2);
                                                                                                                                         double p3 = dist.cumulativeProbability(x3);
                                                                                                                                         double p4 = dist.cumulativeProbability(x4);
                                                                                                                                         
                                                                                                                                         // Original behavior: p2 should be 1.0 (treated as extreme outlier)
                                                                                                                                         // Mutant behavior: p2 will be calculated normally
                                                                                                                                         assertEquals(1.0, p2, 0.0001);
                                                                                                                                         
                                                                                                                                         // Additional assertions to verify behavior at 30*sd boundary
                                                                                                                                         assertEquals(1.0, p4, 0.0001);
                                                                                                                                         
                                                                                                                                         // These values should be the same in both original and mutant
                                                                                                                                         assertTrue(p1 < 1.0);
                                                                                                                                         assertTrue(p3 < 1.0);
                                                                                                                                     }

    @Test
                                                                                                                                public void testCumulativeProbabilityBoundaryCondition1() throws MathException {
                                                                                                                                    // Setup normal distribution with mean=0, sd=1
                                                                                                                                    NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                    
                                                                                                                                    // Boundary value is mean + 20*sd = 20
                                                                                                                                    double boundary = 20.0;
                                                                                                                                    
                                                                                                                                    // Test value just above boundary
                                                                                                                                    double aboveBoundary = boundary + 0.1;
                                                                                                                                    // For x > boundary, should return probability very close to 1
                                                                                                                                    assertEquals(1.0, dist.cumulativeProbability(aboveBoundary), 1e-10);
                                                                                                                                    
                                                                                                                                    // Test value just below boundary
                                                                                                                                    double belowBoundary = boundary - 0.1;
                                                                                                                                    // For x < boundary, should return probability less than 1
                                                                                                                                    assertTrue(dist.cumulativeProbability(belowBoundary) < 1.0);
                                                                                                                                    
                                                                                                                                    // Test value at boundary
                                                                                                                                    // Should treat boundary as part of the upper tail (x > boundary)
                                                                                                                                    assertEquals(1.0, dist.cumulativeProbability(boundary), 1e-10);
                                                                                                                                }

    @Test
                                                                                                                           public void testCumulativeProbabilityForLargeX() throws Exception {
                                                                                                                               // Setup
                                                                                                                               double mean = 0.0;
                                                                                                                               double sd = 1.0;
                                                                                                                               NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                               
                                                                                                                               // Test value that's way beyond mean + 20*sd
                                                                                                                               double veryLargeX = mean + 50 * sd;
                                                                                                                               
                                                                                                                               // The cumulative probability should be very close to 1.0 for such large x
                                                                                                                               double probability = dist.cumulativeProbability(veryLargeX);
                                                                                                                               
                                                                                                                               // Verify the probability is as expected (should be 1.0 for practical purposes)
                                                                                                                               assertEquals(1.0, probability, 1e-10);
                                                                                                                               
                                                                                                                               // Also test a value just above mean + 20*sd to ensure the boundary is correct
                                                                                                                               double boundaryX = mean + 20.1 * sd;
                                                                                                                               double boundaryProb = dist.cumulativeProbability(boundaryX);
                                                                                                                               assertTrue(boundaryProb > 0.999999); // Should be extremely close to 1
                                                                                                                           }

    @Test
                                                                                                                      public void testSetStandardDeviation_PositiveValue_ShouldSetField() {
                                                                                                                          // Arrange
                                                                                                                          NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                          double validSd = 1.5;
                                                                                                                          
                                                                                                                          // Act
                                                                                                                          normalDistribution.setStandardDeviation(validSd);
                                                                                                                          
                                                                                                                          // Assert
                                                                                                                          assertEquals(validSd, normalDistribution.getStandardDeviation(), 0.0);
                                                                                                                      }

    @Test
                                                                                                                      public void testSetStandardDeviation_NegativeValue_ShouldThrowException1() {
                                                                                                                          // Arrange
                                                                                                                          NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                          double negativeSd = -0.5;
                                                                                                                          
                                                                                                                          // Assert exception is thrown
                                                                                                                          thrown.expect(IllegalArgumentException.class);
                                                                                                                          thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                          
                                                                                                                          // Act
                                                                                                                          normalDistribution.setStandardDeviation(negativeSd);
                                                                                                                      }

    @Test
                                                                                                                  public void testSetStandardDeviation_ZeroValue_ShouldThrowException1() {
                                                                                                                      // Arrange
                                                                                                                      NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                      double zeroSd = 0.0;
                                                                                                                      
                                                                                                                      try {
                                                                                                                          // Act
                                                                                                                          normalDistribution.setStandardDeviation(zeroSd);
                                                                                                                          fail("Expected IllegalArgumentException to be thrown");
                                                                                                                      } catch (IllegalArgumentException e) {
                                                                                                                          // Assert
                                                                                                                          assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                      }
                                                                                                                      
                                                                                                                      // Additional verification that field wasn't set
                                                                                                                      assertNotEquals(zeroSd, normalDistribution.getStandardDeviation(), 0.0);
                                                                                                                  }

    @Test
                                                                                                             public void testSetStandardDeviation_shouldRejectZero() {
                                                                                                                 ExpectedException thrown = ExpectedException.none();
                                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                 
                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                 thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                 normalDistribution.setStandardDeviation(0.0);
                                                                                                             }

    @Test
                                                                                                             public void testSetStandardDeviation_shouldRejectNegative() {
                                                                                                                 ExpectedException thrown = ExpectedException.none();
                                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                 
                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                 thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                 normalDistribution.setStandardDeviation(-1.0);
                                                                                                             }

    @Test
                                                                                                             public void testSetStandardDeviation_shouldAcceptPositive() {
                                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                 normalDistribution.setStandardDeviation(1.0);
                                                                                                                 assertEquals(1.0, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                             }

    @Test
                                                                                                             public void testSetStandardDeviation_shouldRejectSmallPositive() {
                                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                 try {
                                                                                                                     normalDistribution.setStandardDeviation(0.25);
                                                                                                                     fail("Expected IllegalArgumentException");
                                                                                                                 } catch (IllegalArgumentException e) {
                                                                                                                     assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                 }
                                                                                                             }

    @Test
                                                                                                             public void testSetStandardDeviation_shouldAcceptBoundaryValue() {
                                                                                                                 // Test the exact boundary case (0.5 for mutant, 0.0 for original)
                                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                 normalDistribution.setStandardDeviation(0.5);
                                                                                                                 assertEquals(0.5, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                             }

    @Test
                                                                                                        public void testSetStandardDeviationWithNonPositiveValue() {
                                                                                                            // Create a normal distribution object for testing
                                                                                                            NormalDistributionImpl normalDistribution = new NormalDistributionImpl(0.0, 1.0);
                                                                                                            
                                                                                                            // Save original value before test
                                                                                                            double originalSd = normalDistribution.getStandardDeviation();
                                                                                                            
                                                                                                            try {
                                                                                                                // This should throw IllegalArgumentException in original code
                                                                                                                normalDistribution.setStandardDeviation(0.0);
                                                                                                                
                                                                                                                // If we get here, the mutant survived (no exception thrown)
                                                                                                                // Verify the field wasn't changed
                                                                                                                assertEquals("Standard deviation should not change for invalid input", 
                                                                                                                            originalSd, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                
                                                                                                                // Explicitly fail the test since we expected an exception
                                                                                                                fail("Expected IllegalArgumentException for sd <= 0.0");
                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                // Verify exception message
                                                                                                                assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                
                                                                                                                // Verify field remains unchanged
                                                                                                                assertEquals(originalSd, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                throw e; // rethrow to satisfy @Test annotation
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                        public void testSetStandardDeviationWithNegativeValue() {
                                                                                                            // Create new distribution instance
                                                                                                            NormalDistributionImpl normalDistribution = new NormalDistributionImpl(0.0, 1.0);
                                                                                                            
                                                                                                            // Save original value before test
                                                                                                            double originalSd = normalDistribution.getStandardDeviation();
                                                                                                            
                                                                                                            try {
                                                                                                                // This should throw IllegalArgumentException in original code
                                                                                                                normalDistribution.setStandardDeviation(-1.0);
                                                                                                                
                                                                                                                // If we get here, the mutant survived (no exception thrown)
                                                                                                                // Verify the field wasn't changed
                                                                                                                assertEquals("Standard deviation should not change for invalid input", 
                                                                                                                             originalSd, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                
                                                                                                                // Explicitly fail the test since we expected an exception
                                                                                                                fail("Expected IllegalArgumentException for sd <= 0.0");
                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                // Verify exception message
                                                                                                                assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                
                                                                                                                // Verify field remains unchanged
                                                                                                                assertEquals(originalSd, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                   public void testSetStandardDeviationAndCalculations() throws MathException {
                                                                                                       // Test basic setting and getting
                                                                                                       NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                       dist.setStandardDeviation(2.0);
                                                                                                       assertEquals(2.0, dist.getStandardDeviation(), 0.0001);
                                                                                                       
                                                                                                       // Test invalid values
                                                                                                       try {
                                                                                                           dist.setStandardDeviation(0.0);
                                                                                                           fail("Expected IllegalArgumentException");
                                                                                                       } catch (IllegalArgumentException e) {
                                                                                                           assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                       }
                                                                                                       
                                                                                                       try {
                                                                                                           dist.setStandardDeviation(-1.0);
                                                                                                           fail("Expected IllegalArgumentException");
                                                                                                       } catch (IllegalArgumentException e) {
                                                                                                           assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                       }
                                                                                                       
                                                                                                       // Test calculations that use standardDeviation * sqrt(2)
                                                                                                       // Using inverseCumulativeProbability which likely uses this calculation
                                                                                                       dist.setStandardDeviation(2.0);
                                                                                                       double result = dist.inverseCumulativeProbability(0.97725); // ~2 sigma
                                                                                                       // Expected value is mean + 2*stdDev = 0 + 2*2 = 4
                                                                                                       assertEquals(4.0, result, 0.01);
                                                                                                       
                                                                                                       // Another test with different std dev
                                                                                                       dist.setStandardDeviation(3.0);
                                                                                                       result = dist.inverseCumulativeProbability(0.97725);
                                                                                                       // Expected value is mean + 2*stdDev = 0 + 2*3 = 6
                                                                                                       assertEquals(6.0, result, 0.01);
                                                                                                   }

    @Test(expected = IllegalArgumentException.class)
                                                                                              public void testSetStandardDeviation_ZeroValue1() {
                                                                                                  NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                  normalDistribution.setStandardDeviation(0.0);
                                                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                                                              public void testSetStandardDeviation_NegativeValue2() {
                                                                                                  NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                  normalDistribution.setStandardDeviation(-1.0);
                                                                                              }

    @Test
                                                                                              public void testSetStandardDeviation_PositiveValue2() {
                                                                                                  NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                  normalDistribution.setStandardDeviation(1.5);
                                                                                                  assertEquals(1.5, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                              }

    @Test
                                                                                              public void testSetStandardDeviationWithValidValue1() {
                                                                                                  NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                  dist.setStandardDeviation(2.5);
                                                                                                  assertEquals(2.5, dist.getStandardDeviation(), 0.0);
                                                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                                                              public void testSetStandardDeviationWithZero() {
                                                                                                  NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                  dist.setStandardDeviation(0.0);
                                                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                                                              public void testSetStandardDeviationWithNegativeValue1() {
                                                                                                  NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                  dist.setStandardDeviation(-1.0);
                                                                                              }

    @Test
                                                                                         public void testCumulativeProbabilityForExtremeValues() throws Exception {
                                                                                             // Setup normal distribution with mean 0 and sd 1
                                                                                             NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                             
                                                                                             // Test value that's between -20 and -10 standard deviations from mean
                                                                                             double testValue = -15.0;
                                                                                             
                                                                                             // In original version, this should return very small probability (near 0)
                                                                                             // In mutated version, it might return a different value
                                                                                             double probability = dist.cumulativeProbability(testValue);
                                                                                             
                                                                                             // Verify the probability is extremely small (original behavior)
                                                                                             // The exact value might vary, but it should be very close to 0
                                                                                             // For standard normal distribution, P(X < -15) is approximately 3.67e-51
                                                                                             assertTrue("Probability for extreme value should be very small", 
                                                                                                       probability < 1e-50);
                                                                                             
                                                                                             // Additional assertion to ensure it's not exactly 0
                                                                                             assertTrue("Probability should not be exactly 0", 
                                                                                                       probability > 0.0);
                                                                                         }

    @Test
                                                                                    public void testCumulativeProbabilityForExtremeLeftTailValues() throws MathException {
                                                                                        // Setup
                                                                                        double mean = 0.0;
                                                                                        double sd = 1.0;
                                                                                        NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                        
                                                                                        // Test value between 20 and 30 standard deviations below mean
                                                                                        double testValue = mean - 25 * sd;
                                                                                        
                                                                                        // Get the probability
                                                                                        double probability = distribution.cumulativeProbability(testValue);
                                                                                        
                                                                                        // The original implementation would treat this as extreme (likely 0)
                                                                                        // The mutant would treat it as a normal value (non-zero)
                                                                                        // So we assert it should be 0 (or some very small value)
                                                                                        assertEquals(0.0, probability, 0.0);
                                                                                        
                                                                                        // Additional test case exactly at 20 standard deviations
                                                                                        testValue = mean - 20 * sd;
                                                                                        probability = distribution.cumulativeProbability(testValue);
                                                                                        assertEquals(0.0, probability, 0.0);
                                                                                        
                                                                                        // Test case just inside the boundary (19 standard deviations)
                                                                                        testValue = mean - 19 * sd;
                                                                                        probability = distribution.cumulativeProbability(testValue);
                                                                                        // This should be a very small but non-zero probability
                                                                                        assertTrue(probability > 0.0);
                                                                                    }

    @Test
                                                                                    public void testConstructorWithZeroStandardDeviation_ShouldThrowException() {
                                                                                        try {
                                                                                            new NormalDistributionImpl(0.0, 0.0);
                                                                                            fail("Expected IllegalArgumentException for zero standard deviation");
                                                                                        } catch (IllegalArgumentException e) {
                                                                                            assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                        }
                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                               public void testSetStandardDeviation_ZeroValue_ShouldThrowException2() {
                                                                                   // This test will catch the mutant because:
                                                                                   // Original code throws exception for 0.0
                                                                                   // Mutated code would accept 0.0
                                                                                   NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                   normalDistribution.setStandardDeviation(0.0);
                                                                               }

    @Test
                                                                               public void testSetStandardDeviation_PositiveValue_ShouldSetField1() {
                                                                                   double testValue = 1.5;
                                                                                   NormalDistributionImpl normalDistribution = new NormalDistributionImpl(); // Using default constructor
                                                                                   normalDistribution.setStandardDeviation(testValue);
                                                                                   assertEquals(testValue, normalDistribution.getStandardDeviation(), 0.0001);
                                                                               }

    @Test(expected = IllegalArgumentException.class)
                                                                               public void testSetStandardDeviation_NegativeValue_ShouldThrowException2() {
                                                                                   NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                   normalDistribution.setStandardDeviation(-0.5);
                                                                               }

    @Test
                                                                          public void testSetStandardDeviation_ZeroValue_ThrowsException1() {
                                                                              org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                              thrown.expect(IllegalArgumentException.class);
                                                                              thrown.expectMessage("Standard deviation must be positive.");
                                                                              org.apache.commons.math.distribution.NormalDistributionImpl normalDistribution = 
                                                                                  new org.apache.commons.math.distribution.NormalDistributionImpl();
                                                                              normalDistribution.setStandardDeviation(0.0);
                                                                          }

    @Test(expected = IllegalArgumentException.class)
                                                                          public void testSetStandardDeviation_NegativeValue_ThrowsException2() {
                                                                              NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                              normalDistribution.setStandardDeviation(-1.0);
                                                                          }

    @Test
                                                                          public void testSetStandardDeviation_PositiveValue_SetsCorrectly2() {
                                                                              NormalDistributionImpl normalDistribution = new NormalDistributionImpl(0.0, 1.0);
                                                                              normalDistribution.setStandardDeviation(1.0);
                                                                              assertEquals(1.0, normalDistribution.getStandardDeviation(), 0.0001);
                                                                          }

    @Test
                                                                          public void testSetStandardDeviation_SmallPositiveValue_ThrowsException() {
                                                                              NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                              try {
                                                                                  // This value (0.1) should throw exception in original but pass in mutant
                                                                                  normalDistribution.setStandardDeviation(0.1);
                                                                                  fail("Expected IllegalArgumentException");
                                                                              } catch (IllegalArgumentException e) {
                                                                                  // Expected exception
                                                                              }
                                                                          }

    @Test
                                                                          public void testSetStandardDeviation_BoundaryJustAboveZero_SetsCorrectly() {
                                                                              // This tests the original behavior at boundary
                                                                              NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                              normalDistribution.setStandardDeviation(Double.MIN_VALUE);
                                                                              assertEquals(Double.MIN_VALUE, normalDistribution.getStandardDeviation(), 0.0);
                                                                          }

    @Test
                                                                          public void testSetStandardDeviation_BoundaryJustAboveHalf_ShouldSet() {
                                                                              // This tests mutant-specific boundary
                                                                              NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                              normalDistribution.setStandardDeviation(0.5001);
                                                                              assertEquals(0.5001, normalDistribution.getStandardDeviation(), 0.0001);
                                                                          }

    @Test
                                                                     public void testCumulativeProbabilityForLargeX1() throws MathException {
                                                                         // Setup normal distribution with mean=0, sd=1
                                                                         NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                         
                                                                         // Test value is 15 standard deviations above mean
                                                                         // This is between 10σ and 20σ where the mutant differs
                                                                         double x = 15.0;
                                                                         
                                                                         // Calculate cumulative probability
                                                                         double probability = dist.cumulativeProbability(x);
                                                                         
                                                                         // For x=15σ, the probability should be extremely close to 1 (practically certain)
                                                                         // The mutant using 10σ would return a different value
                                                                         assertEquals(1.0, probability, 1e-16);
                                                                         
                                                                         // Also test a value just above 20σ to ensure original boundary is correct
                                                                         double x2 = 21.0;
                                                                         double probability2 = dist.cumulativeProbability(x2);
                                                                         assertEquals(1.0, probability2, 1e-16);
                                                                     }

    @Test
                                                                public void testCumulativeProbabilityAt20To30StandardDeviations() throws Exception {
                                                                    double mean = 0.0;
                                                                    double sd = 1.0;
                                                                    NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                    
                                                                    // Test value at exactly 20 standard deviations
                                                                    double x20 = mean + 20 * sd;
                                                                    double prob20 = dist.cumulativeProbability(x20);
                                                                    
                                                                    // Test value at exactly 30 standard deviations
                                                                    double x30 = mean + 30 * sd;
                                                                    double prob30 = dist.cumulativeProbability(x30);
                                                                    
                                                                    // Test value between 20-30 standard deviations
                                                                    double x25 = mean + 25 * sd;
                                                                    double prob25 = dist.cumulativeProbability(x25);
                                                                    
                                                                    // For a normal distribution, probability should be very close to 1 at 20 SDs
                                                                    // The original would treat all these as effectively 1.0
                                                                    // The mutant would show different behavior between 20-30 SDs
                                                                    assertEquals(1.0, prob20, 1e-10);
                                                                    assertEquals(1.0, prob25, 1e-10);
                                                                    assertEquals(1.0, prob30, 1e-10);
                                                                    
                                                                    // Alternatively, we could test that prob20 and prob30 are effectively equal
                                                                    // since in original they should both be treated as "far outliers"
                                                                    assertEquals(prob20, prob30, 1e-10);
                                                                }

    @Test
                                                           public void testCumulativeProbabilityForExtremeValues1() throws Exception {
                                                               // Setup normal distribution with mean=0 and sd=1
                                                               NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                               
                                                               // Test value that is more than 20 standard deviations above mean
                                                               double extremeValue = 0 + 21 * 1.0; // mean + 21*sd
                                                               
                                                               // In original code, probability should be very close to 1 (practically 1.0)
                                                               double expectedProbability = 1.0;
                                                               double actualProbability = dist.cumulativeProbability(extremeValue);
                                                               
                                                               // Allow for small floating point differences
                                                               assertEquals("Probability for extreme value should be 1.0", 
                                                                          expectedProbability, actualProbability, 1e-10);
                                                               
                                                               // Test another extreme value below mean
                                                               extremeValue = 0 - 21 * 1.0; // mean - 21*sd
                                                               expectedProbability = 0.0; // Should be practically 0.0
                                                               actualProbability = dist.cumulativeProbability(extremeValue);
                                                               
                                                               assertEquals("Probability for extreme negative value should be 0.0",
                                                                          expectedProbability, actualProbability, 1e-10);
                                                           }

    @Test
                                                      public void testSetStandardDeviation_ValidInput() {
                                                          NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                          double validSd = 1.5;
                                                          normalDistribution.setStandardDeviation(validSd);
                                                          assertEquals(validSd, normalDistribution.getStandardDeviation(), 0.0);
                                                      }

    @Test
                                                      public void testSetStandardDeviation_ZeroInput() {
                                                          NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                          ExpectedException thrown = ExpectedException.none();
                                                          thrown.expect(IllegalArgumentException.class);
                                                          thrown.expectMessage("Standard deviation must be positive.");
                                                          normalDistribution.setStandardDeviation(0.0);
                                                          // If mutant is present, this will fail because:
                                                          // 1. No exception will be thrown
                                                          // 2. standardDeviation will be set to 0.5 instead
                                                      }

    @Test
                                                      public void testSetStandardDeviation_InvalidInputDoesNotChangeValue() {
                                                          NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                          try {
                                                              normalDistribution.setStandardDeviation(-1.0);
                                                              fail("Expected IllegalArgumentException");
                                                          } catch (IllegalArgumentException e) {
                                                              // Verify that standard deviation wasn't changed
                                                              assertEquals(1.0, normalDistribution.getStandardDeviation(), 0.0);
                                                          }
                                                          // If mutant is present, this will fail because:
                                                          // 1. No exception will be thrown
                                                          // 2. standardDeviation will be set to 0.5 instead of remaining 1.0
                                                      }

    @Test
                                                  public void testSetStandardDeviation_NegativeInput() {
                                                      NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                      
                                                      try {
                                                          normalDistribution.setStandardDeviation(-1.0);
                                                          fail("Expected IllegalArgumentException to be thrown");
                                                      } catch (IllegalArgumentException e) {
                                                          assertEquals("Standard deviation must be positive.", e.getMessage());
                                                      }
                                                      // If mutant is present, this will fail because:
                                                      // 1. No exception will be thrown
                                                      // 2. standardDeviation will be set to 0.5 instead
                                                  }

    @Test(expected = IllegalArgumentException.class)
                                             public void testSetStandardDeviation_NegativeValue_ThrowsException3() {
                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                 normalDistribution.setStandardDeviation(-1.0);
                                             }

    @Test
                                             public void testSetStandardDeviation_NegativeValue_DetectsMutant() {
                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                 try {
                                                     normalDistribution.setStandardDeviation(-1.0);
                                                     // If we get here, the exception wasn't thrown (mutant behavior)
                                                     // Now verify the standard deviation wasn't set to absolute value
                                                     assertNotEquals("Standard deviation should not be set to absolute value of negative input",
                                                             1.0, normalDistribution.getStandardDeviation(), 0.0);
                                                 } catch (IllegalArgumentException e) {
                                                     // This is expected behavior for original code
                                                     assertTrue(true);
                                                 }
                                             }

    @Test
                                             public void testSetStandardDeviation_PositiveValue_SetsCorrectly3() {
                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                 normalDistribution.setStandardDeviation(2.0);
                                                 assertEquals(2.0, normalDistribution.getStandardDeviation(), 0.0);
                                             }

    @Test(expected = IllegalArgumentException.class)
                                             public void testSetStandardDeviation_ZeroValue_ThrowsException2() {
                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                 normalDistribution.setStandardDeviation(0.0);
                                             }

    @Test(expected = IllegalArgumentException.class)
                                        public void testSetStandardDeviation_NonPositiveValue1() {
                                            NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                            normalDistribution.setStandardDeviation(0.0);
                                        }

    @Test
                                        public void testSetStandardDeviation_PositiveValue3() {
                                            NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                            normalDistribution.setStandardDeviation(1.5);
                                            assertEquals(1.5, normalDistribution.getStandardDeviation(), 0.0001);
                                        }

    @Test
                                        public void testSetStandardDeviation_ExceptionHandling() {
                                            NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                            try {
                                                // This test verifies that IllegalArgumentException is thrown for invalid input
                                                // and that no other unexpected exceptions are caught
                                                normalDistribution.setStandardDeviation(1.0);
                                            } catch (Exception e) {
                                                if (!(e instanceof IllegalArgumentException)) {
                                                    fail("Unexpected exception type caught: " + e.getClass().getName());
                                                }
                                            }
                                        }

    @Test
                                   public void testCumulativeProbabilityBoundaryCondition2() throws MathException {
                                       // Setup with mean=0 and sd=1 for simplicity
                                       NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                       
                                       // Test value between -20 and -10 standard deviations from mean
                                       double testValue = -15.0;
                                       
                                       // Original behavior: -15 > -20, so condition x < (mean - 20*sd) is false
                                       // Mutated behavior: -15 < -10, so condition x < (mean - 10*sd) is true
                                       
                                       // The cumulative probability should be very close to 0 for both cases,
                                       // but the internal calculation path would be different
                                       
                                       // We can test this by checking the actual value is extremely small
                                       double result = dist.cumulativeProbability(testValue);
                                       assertTrue("Probability should be very small", result < 1e-20);
                                       
                                       // More precise test - the original and mutant might produce slightly different values
                                       // due to different calculation paths
                                       NormalDistributionImpl dist2 = new NormalDistributionImpl(0.0, 1.0);
                                       double expected = dist2.cumulativeProbability(-20.0); // Original boundary
                                       double actual = dist.cumulativeProbability(testValue);
                                       
                                       // The result for -15 should be between the results for -20 and -10
                                       assertTrue(actual > dist2.cumulativeProbability(-20.0));
                                       assertTrue(actual < dist2.cumulativeProbability(-10.0));
                                   }

    @Test
                              public void testCumulativeProbabilityBoundaryCondition3() throws org.apache.commons.math.MathException {
                                  // Setup
                                  double mean = 100.0;
                                  double sd = 1.0;
                                  NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                  
                                  // Test value that is between mean-30*sd and mean-20*sd
                                  // For mean=100, sd=1:
                                  // mean-30*sd = 70
                                  // mean-20*sd = 80
                                  double testValue = 75.0;  // between 70 and 80
                                  
                                  // The original code would evaluate x < (mean - 20*sd) as true (75 < 80)
                                  // The mutated code would evaluate x < (mean - 30*sd) as false (75 < 70 is false)
                                  // Therefore this should detect the mutation
                                  
                                  // We need to verify the behavior is as expected
                                  // Since we don't know the exact implementation of cumulativeProbability,
                                  // we'll assume it should return a very small probability for values this far from mean
                                  double probability = distribution.cumulativeProbability(testValue);
                                  
                                  // Verify the probability is very small (less than 1e-20)
                                  assertTrue("Probability should be extremely small for values this far from mean", 
                                             probability < 1e-20);
                                  
                                  // Alternatively, if we know the original implementation would return 0 for x < mean-20*sd
                                  // and the mutated would return some other value, we could test for exactly 0
                                  // assertEquals(0.0, probability, 0.0);
                              }

    @Test(expected = IllegalArgumentException.class)
                         public void testSetStandardDeviation_ZeroValue_ShouldThrowException3() {
                             // This test will catch the mutant because:
                             // Original: throws exception for 0.0
                             // Mutant: would accept 0.0
                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                             normalDistribution.setStandardDeviation(0.0);
                         }

    @Test
                         public void testSetStandardDeviation_ZeroValue_FieldNotSet() {
                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                             try {
                                 normalDistribution.setStandardDeviation(0.0);
                                 fail("Expected IllegalArgumentException");
                             } catch (IllegalArgumentException e) {
                                 // Verify field wasn't changed
                                 assertEquals(1.0, normalDistribution.getStandardDeviation(), 0.0001);
                             }
                         }

    @Test
                         public void testSetStandardDeviation_PositiveValue_SetsCorrectly4() {
                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                             normalDistribution.setStandardDeviation(5.0);
                             assertEquals(5.0, normalDistribution.getStandardDeviation(), 0.0001);
                         }

    @Test(expected = IllegalArgumentException.class)
                         public void testSetStandardDeviation_NegativeValue_ThrowsException4() {
                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                             normalDistribution.setStandardDeviation(-1.0);
                         }

    @Test
                         public void testSetStandardDeviation_ShouldRejectNonPositiveValues() {
                             NormalDistributionImpl dist = new NormalDistributionImpl();
                             
                             // Test exact 0.0 - should throw exception
                             thrown.expect(IllegalArgumentException.class);
                             thrown.expectMessage("Standard deviation must be positive.");
                             dist.setStandardDeviation(0.0);
                             
                             // Test negative value - should throw exception
                             thrown.expect(IllegalArgumentException.class);
                             dist.setStandardDeviation(-1.0);
                             
                             // Test small positive value (0.1) that would be accepted by mutant but should be rejected
                             // This is the key test to catch the mutant
                             thrown.expect(IllegalArgumentException.class);
                             dist.setStandardDeviation(0.1);
                         }

    @Test
                         public void testSetStandardDeviation_ShouldAcceptPositiveValues() {
                             NormalDistributionImpl dist = new NormalDistributionImpl();
                             
                             // Test valid positive value (1.0)
                             dist.setStandardDeviation(1.0);
                             assertEquals(1.0, dist.getStandardDeviation(), 0.0001);
                             
                             // Test value just above mutant threshold (0.6)
                             dist.setStandardDeviation(0.6);
                             assertEquals(0.6, dist.getStandardDeviation(), 0.0001);
                         }

    @Test
                   public void testCumulativeProbabilityAtExtremeValues() throws MathException {
                       double mean = 0.0;
                       double sd = 1.0;
                       NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                       
                       // Test values at critical boundaries
                       double x1 = mean + 10 * sd;  // Boundary for mutant
                       double x2 = mean + 15 * sd;  // Intermediate value
                       double x3 = mean + 20 * sd;  // Boundary for original
                       
                       // For normal distribution, cumulative probability should be very close to 1
                       // at these extreme values, with x3 being even closer to 1 than x1
                       double prob1 = dist.cumulativeProbability(x1);
                       double prob2 = dist.cumulativeProbability(x2);
                       double prob3 = dist.cumulativeProbability(x3);
                       
                       // Verify probabilities are very close to 1 and properly ordered
                       assertTrue(prob1 > 0.999999);
                       assertTrue(prob2 > prob1);
                       assertTrue(prob3 > prob2);
                       
                       // The mutant would treat x1 and x3 the same (as both > 10*sd)
                       // while original treats them differently (x3 > 20*sd)
                       // So this test would fail if the mutant is present
                   }

    @Test
              public void testCumulativeProbabilityAt20StandardDeviations() throws MathException {
                  // Setup normal distribution with mean=0, sd=1 for simplicity
                  NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                  
                  // Test value at exactly 20 standard deviations
                  double x = 20.0;
                  double prob = dist.cumulativeProbability(x);
                  
                  // For values this far in the tail, probability should be very close to 1
                  // (original would return exactly 1 for x > mean + 20*sd)
                  assertEquals(1.0, prob, 0.000001);
                  
                  // Test value between 20-30 standard deviations (25)
                  x = 25.0;
                  prob = dist.cumulativeProbability(x);
                  // This should still be 1.0 (would fail with mutant)
                  assertEquals(1.0, prob, 0.000001);
                  
                  // Test value at 30 standard deviations
                  x = 30.0;
                  prob = dist.cumulativeProbability(x);
                  assertEquals(1.0, prob, 0.000001);
              }

    @Test
              public void testCumulativeProbabilityNearThreshold() throws Exception {
                  NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                  
                  // Test value just below 20 standard deviations
                  double x = 19.999;
                  double prob = dist.cumulativeProbability(x);
                  // Should be very close to 1 but not exactly 1
                  assertTrue(prob < 1.0);
                  assertTrue(prob > 0.999999);
                  
                  // Test value just above 20 standard deviations
                  x = 20.001;
                  prob = dist.cumulativeProbability(x);
                  // Original would return exactly 1, mutant would return <1
                  assertEquals(1.0, prob, 0.000001);
              }

    @Test
         public void testCumulativeProbabilityBeyond20StdDev() throws MathException {
             // Setup normal distribution with mean=0 and std dev=1
             NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
             
             // Test value that is more than 20 std devs above mean
             double extremeValue = 21.0;
             
             // In original code, cumulative probability for values beyond 20 std devs 
             // should be very close to 1.0 (but not exactly 1.0)
             double originalProbability = dist.cumulativeProbability(extremeValue);
             
             // The mutant changes the condition to always true, which might affect the calculation
             // We expect the original probability to be very close to 1.0
             // The mutant might return exactly 1.0 or some other fixed value
             
             // Assert that the probability is very close to 1.0 but not exactly 1.0
             // (since mathematically it approaches but never reaches 1.0)
             assertEquals(1.0, originalProbability, 1e-10);
             assertTrue(originalProbability < 1.0);
             
             // For values below 20 std devs, both original and mutant should behave similarly
             double normalValue = 1.0;
             double normalProbability = dist.cumulativeProbability(normalValue);
             assertTrue(normalProbability > 0.8 && normalProbability < 0.85);
         }

    @Test(expected = IllegalArgumentException.class)
    public void testSetStandardDeviation_NonPositiveValue_ShouldThrowException() {
        // Arrange
        NormalDistributionImpl normalDistribution = new NormalDistributionImpl(0.0, 1.0); // default mean=0, sd=1
        double originalSd = normalDistribution.getStandardDeviation();
        double invalidSd = -1.0;
        
        // Act
        try {
            normalDistribution.setStandardDeviation(invalidSd);
        } catch (IllegalArgumentException e) {
            // Assert exception message
            assertEquals("Standard deviation must be positive.", e.getMessage());
            // Assert field remains unchanged
            assertEquals(originalSd, normalDistribution.getStandardDeviation(), 0.0001);
            throw e; // rethrow to satisfy @Test(expected)
        }
        
        // If we get here, no exception was thrown (mutant behavior)
        // Verify the field wasn't set to 0.5 (mutant behavior)
        assertNotEquals(0.5, normalDistribution.getStandardDeviation(), 0.0001);
        // Verify field remains unchanged
        assertEquals(originalSd, normalDistribution.getStandardDeviation(), 0.0001);
    }

    @Test
    public void testSetStandardDeviation_PositiveValue_ShouldSetCorrectly1() {
        // Arrange
        double validSd = 2.5;
        NormalDistributionImpl normalDistribution = new NormalDistributionImpl(); // Create instance
        
        // Act
        normalDistribution.setStandardDeviation(validSd);
        
        // Assert
        assertEquals(validSd, normalDistribution.getStandardDeviation(), 0.0001);
    }


}
