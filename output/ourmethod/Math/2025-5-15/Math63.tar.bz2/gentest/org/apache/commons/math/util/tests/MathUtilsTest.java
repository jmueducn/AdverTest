package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.util.Localizable;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.exception.NonMonotonousSequenceException;
 
public class MathUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                   public void testEquals_IdenticalValues() {
                       assertTrue(MathUtils.equals(0.0, 0.0));
                       assertTrue(MathUtils.equals(1.0, 1.0));
                       assertTrue(MathUtils.equals(-1.0, -1.0));
                       assertTrue(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE));
                       assertTrue(MathUtils.equals(Double.MIN_VALUE, Double.MIN_VALUE));
                   }

 @Test
                   public void testEquals_WithinOneUlps() {
                       // Test values that are very close but not exactly equal
                       double a = 1.0;
                       double b = a + Math.ulp(a);
                       assertTrue(MathUtils.equals(a, b));
                       
                       double c = -1.0;
                       double d = c - Math.ulp(c);
                       assertTrue(MathUtils.equals(c, d));
                   }

 @Test
                   public void testEquals_OutsideOneUlps() {
                       // Test values that are more than 1 ULP apart
                       double a = 1.0;
                       double b = a + 2 * Math.ulp(a);
                       assertFalse(MathUtils.equals(a, b));
                       
                       double c = -1.0;
                       double d = c - 2 * Math.ulp(c);
                       assertFalse(MathUtils.equals(c, d));
                   }

 @Test
                   public void testEquals_WithNaN() {
                       // NaN should not equal NaN (unless using equalsIncludingNaN)
                       assertFalse(MathUtils.equals(Double.NaN, Double.NaN));
                       assertFalse(MathUtils.equals(1.0, Double.NaN));
                       assertFalse(MathUtils.equals(Double.NaN, 1.0));
                   }

 @Test
                   public void testEquals_WithInfinities() {
                       // Positive infinity cases
                       assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY));
                       assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY));
                       assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.MAX_VALUE));
                       
                       // Negative infinity cases
                       assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY));
                       assertFalse(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY));
                       assertFalse(MathUtils.equals(Double.NEGATIVE_INFINITY, -Double.MAX_VALUE));
                   }

 @Test
                   public void testEquals_ZeroCases() {
                       // Positive and negative zero should be considered equal
                       assertTrue(MathUtils.equals(0.0, -0.0));
                       assertTrue(MathUtils.equals(-0.0, 0.0));
                       
                       // Very small numbers near zero
                       assertTrue(MathUtils.equals(0.0, Double.MIN_VALUE));
                       assertTrue(MathUtils.equals(0.0, -Double.MIN_VALUE));
                   }

 @Test
                   public void testEquals_LargeNumbers() {
                       // Large numbers with small relative difference
                       double large1 = 1.0e20;
                       double large2 = large1 + 1.0;
                       assertTrue(MathUtils.equals(large1, large2));
                       
                       // Large numbers with larger relative difference
                       double large3 = large1 + 1.0e5;
                       assertFalse(MathUtils.equals(large1, large3));
                   }

 @Test
                   public void testEquals_SmallNumbers() {
                       // Small numbers with small absolute difference
                       double small1 = 1.0e-20;
                       double small2 = small1 + 1.0e-22;
                       assertTrue(MathUtils.equals(small1, small2));
                       
                       // Small numbers with larger absolute difference
                       double small3 = small1 + 1.0e-18;
                       assertFalse(MathUtils.equals(small1, small3));
                   }

 @Test
                   public void testEquals_ExtremeValues() {
                       // Test with extreme values
                       assertTrue(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE - Math.ulp(Double.MAX_VALUE)));
                       assertFalse(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE / 2));
                       
                       assertTrue(MathUtils.equals(-Double.MAX_VALUE, -Double.MAX_VALUE + Math.ulp(Double.MAX_VALUE)));
                       assertFalse(MathUtils.equals(-Double.MAX_VALUE, -Double.MAX_VALUE / 2));
                   }

 @Test
                   public void testEquals_ExactMatch() {
                       assertTrue(MathUtils.equals(1.0, 1.0, 0.0001));
                       assertTrue(MathUtils.equals(0.0, 0.0, 0.0001));
                       assertTrue(MathUtils.equals(-1.0, -1.0, 0.0001));
                   }

 @Test
                   public void testEquals_WithinEpsilon() {
                       assertTrue(MathUtils.equals(1.0, 1.00009, 0.0001));
                       assertTrue(MathUtils.equals(1.00009, 1.0, 0.0001));
                       assertTrue(MathUtils.equals(-1.0, -1.00009, 0.0001));
                   }

 @Test
                   public void testEquals_OutsideEpsilon() {
                       assertFalse(MathUtils.equals(1.0, 1.00011, 0.0001));
                       assertFalse(MathUtils.equals(1.00011, 1.0, 0.0001));
                       assertFalse(MathUtils.equals(-1.0, -1.00011, 0.0001));
                   }

 @Test
                   public void testEquals_EdgeCases() {
                       // Test with very small epsilon
                       assertTrue(MathUtils.equals(1.0, 1.0, Double.MIN_VALUE));
                       assertFalse(MathUtils.equals(1.0, 1.0 + Double.MIN_VALUE, Double.MIN_VALUE));
               
                       // Test with very large epsilon
                       assertTrue(MathUtils.equals(1.0, 100.0, 100.0));
                       assertTrue(MathUtils.equals(1.0, -100.0, 101.0));
               
                       // Test with zero epsilon
                       assertTrue(MathUtils.equals(1.0, 1.0, 0.0));
                       assertFalse(MathUtils.equals(1.0, 1.0000000000000001, 0.0));
                   }

 @Test
                   public void testEquals_SpecialValues() {
                       // NaN cases
                       assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 0.0001));
                       assertFalse(MathUtils.equals(Double.NaN, 1.0, 0.0001));
                       assertFalse(MathUtils.equals(1.0, Double.NaN, 0.0001));
               
                       // Infinity cases
                       assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 0.0001));
                       assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, 0.0001));
                       assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 0.0001));
                       assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, 1.0, 0.0001));
                       assertFalse(MathUtils.equals(1.0, Double.NEGATIVE_INFINITY, 0.0001));
               
                       // Mixed cases
                       assertFalse(MathUtils.equals(Double.NaN, Double.POSITIVE_INFINITY, 0.0001));
                       assertFalse(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NaN, 0.0001));
                   }

 @Test
                   public void testEquals_UsingClassEpsilon() {
                       // Test with MathUtils.EPSILON
                       double smallValue = MathUtils.EPSILON / 2;
                       assertTrue(MathUtils.equals(1.0, 1.0 + smallValue, MathUtils.EPSILON));
                       assertFalse(MathUtils.equals(1.0, 1.0 + MathUtils.EPSILON * 2, MathUtils.EPSILON));
                   }

 @Test
                   public void testEquals_WithMaxUlps() {
                       // This tests the case where equals(x, y, 1) is called
                       // For doubles that are adjacent in their binary representation
                       double x = 1.0;
                       double y = Double.longBitsToDouble(Double.doubleToLongBits(x) + 1);
                       assertTrue(MathUtils.equals(x, y, Double.MIN_VALUE));
                   }

 @Test
                   public void testEquals_ExactSameValues() {
                       assertTrue(MathUtils.equals(1.0, 1.0, 1));
                       assertTrue(MathUtils.equals(0.0, 0.0, 1));
                       assertTrue(MathUtils.equals(-1.0, -1.0, 1));
                   }

 @Test
                   public void testEquals_WithinUlps() {
                       // Values that are very close but not exactly equal
                       double a = 1.000000000000001;
                       double b = 1.000000000000002;
                       assertTrue(MathUtils.equals(a, b, 5));
                       
                       double c = 123456789.123456789;
                       double d = 123456789.123456788;
                       assertTrue(MathUtils.equals(c, d, 2));
                   }

 @Test
                   public void testEquals_OutsideUlps() {
                       // Values that are beyond the specified ULP tolerance
                       double a = 1.0000001;
                       double b = 1.0000002;
                       assertFalse(MathUtils.equals(a, b, 1));
                       
                       double c = 0.000000001;
                       double d = 0.000000002;
                       assertFalse(MathUtils.equals(c, d, 1));
                   }

 @Test
                   public void testEquals_OppositeSigns() {
                       // Values with opposite signs should never be equal regardless of ULP
                       assertFalse(MathUtils.equals(1.0, -1.0, 1000));
                       assertFalse(MathUtils.equals(0.0001, -0.0001, 1000));
                   }

 @Test
                   public void testEquals_WithNaN1() {
                       // NaN should never equal anything, even another NaN
                       assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 1));
                       assertFalse(MathUtils.equals(1.0, Double.NaN, 1));
                       assertFalse(MathUtils.equals(Double.NaN, 1.0, 1));
                   }

 @Test
                   public void testEquals_WithInfiniteValues() {
                       // Same infinities should be equal
                       assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 1));
                       assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, 1));
                       
                       // Different infinities should not be equal
                       assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 1));
                       
                       // Infinity should not equal finite numbers
                       assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, 1.0, 1));
                       assertFalse(MathUtils.equals(1.0, Double.POSITIVE_INFINITY, 1));
                   }

 @Test
                   public void testEquals_ZeroAndNegativeZero() {
                       // +0.0 and -0.0 should be considered equal
                       assertTrue(MathUtils.equals(0.0, -0.0, 1));
                   }

 @Test
                   public void testEquals_VerySmallNumbers() {
                       // Test with very small numbers near Double.MIN_VALUE
                       double tiny1 = Double.MIN_VALUE;
                       double tiny2 = Double.MIN_VALUE * 1.0001;
                       assertTrue(MathUtils.equals(tiny1, tiny2, 10));
                       assertFalse(MathUtils.equals(tiny1, tiny2, 1));
                   }

 @Test
                   public void testEquals_VeryLargeNumbers() {
                       // Test with very large numbers near Double.MAX_VALUE
                       double huge1 = Double.MAX_VALUE;
                       double huge2 = Double.MAX_VALUE * 0.999999999999999;
                       assertTrue(MathUtils.equals(huge1, huge2, 1000));
                       assertFalse(MathUtils.equals(huge1, huge2, 1));
                   }

 @Test(expected = IllegalArgumentException.class)
                   public void testEquals_InvalidMaxUlpsZero() {
                       MathUtils.equals(1.0, 1.0, 0);
                   }

 @Test(expected = IllegalArgumentException.class)
                   public void testEquals_InvalidMaxUlpsNegative() {
                       MathUtils.equals(1.0, 1.0, -1);
                   }

 @Test(expected = IllegalArgumentException.class)
                   public void testEquals_InvalidMaxUlpsTooLarge() {
                       // Assuming NAN_GAP is a large number like Integer.MAX_VALUE
                       MathUtils.equals(1.0, 1.0, Integer.MAX_VALUE);
                   }

 @Test
                   public void testEquals_BothArraysNull() {
                       assertTrue(MathUtils.equals(null, null));
                   }

 @Test
                   public void testEquals_FirstArrayNull() {
                       double[] y = {1.0, 2.0};
                       assertFalse(MathUtils.equals(null, y));
                   }

 @Test
                   public void testEquals_SecondArrayNull() {
                       double[] x = {1.0, 2.0};
                       assertFalse(MathUtils.equals(x, null));
                   }

 @Test
                   public void testEquals_DifferentLengths() {
                       double[] x = {1.0, 2.0, 3.0};
                       double[] y = {1.0, 2.0};
                       assertFalse(MathUtils.equals(x, y));
                   }

 @Test
                   public void testEquals_EmptyArrays() {
                       double[] x = {};
                       double[] y = {};
                       assertTrue(MathUtils.equals(x, y));
                   }

 @Test
                   public void testEquals_EqualArrays() {
                       double[] x = {1.0, 2.0, 3.0};
                       double[] y = {1.0, 2.0, 3.0};
                       assertTrue(MathUtils.equals(x, y));
                   }

 @Test
                   public void testEquals_UnequalArrays() {
                       double[] x = {1.0, 2.0, 3.0};
                       double[] y = {1.0, 2.0, 4.0};
                       assertFalse(MathUtils.equals(x, y));
                   }

 @Test
                   public void testEquals_ArraysWithNaN() {
                       double[] x = {1.0, Double.NaN, 3.0};
                       double[] y = {1.0, Double.NaN, 3.0};
                       // Note: This depends on how equals() handles NaN values
                       // If it uses Double.compare, NaN == NaN will be true
                       // If it uses ==, NaN == NaN will be false
                       // Since we don't see the equals(double, double) implementation, we'll test both possibilities
                       try {
                           assertTrue(MathUtils.equals(x, y));
                       } catch (AssertionError e) {
                           assertFalse(MathUtils.equals(x, y));
                       }
                   }

 @Test
                   public void testEquals_ArraysWithDifferentNaN() {
                       double[] x = {1.0, Double.NaN, 3.0};
                       double[] y = {1.0, 2.0, 3.0};
                       assertFalse(MathUtils.equals(x, y));
                   }

 @Test
                   public void testEquals_ArraysWithInfiniteValues() {
                       double[] x = {1.0, Double.POSITIVE_INFINITY, 3.0};
                       double[] y = {1.0, Double.POSITIVE_INFINITY, 3.0};
                       assertTrue(MathUtils.equals(x, y));
                   }

 @Test
                   public void testEquals_ArraysWithDifferentInfiniteValues() {
                       double[] x = {1.0, Double.POSITIVE_INFINITY, 3.0};
                       double[] y = {1.0, Double.NEGATIVE_INFINITY, 3.0};
                       assertFalse(MathUtils.equals(x, y));
                   }

 @Test
                   public void testEquals_ArraysWithEpsilonDifference() {
                       double[] x = {1.0, 2.0, 3.0};
                       double[] y = {1.0, 2.0 + MathUtils.EPSILON/2, 3.0};
                       // This depends on whether equals() uses an epsilon comparison
                       // Since we don't see the equals(double, double) implementation, we'll test both possibilities
                       try {
                           assertTrue(MathUtils.equals(x, y));
                       } catch (AssertionError e) {
                           assertFalse(MathUtils.equals(x, y));
                       }
                   }

 @Test
               public void testCoshDetectsSignChangeMutation() {
                   // Test case that will catch the + to - mutation
                   double zeroInput = 0.0;
                   double positiveInput = 1.5;
                   double negativeInput = -1.5;
                   
                   // cosh(0) should be 1, but mutant would return 0
                   assertEquals(1.0, MathUtils.cosh(zeroInput), MathUtils.EPSILON);
                   
                   // Test positive value where cosh and sinh differ
                   double expectedPositive = (Math.exp(positiveInput) + Math.exp(-positiveInput)) / 2.0;
                   assertEquals(expectedPositive, MathUtils.cosh(positiveInput), MathUtils.EPSILON);
                   
                   // Test negative value (cosh is even function, should be same as positive)
                   double expectedNegative = (Math.exp(negativeInput) + Math.exp(-negativeInput)) / 2.0;
                   assertEquals(expectedNegative, MathUtils.cosh(negativeInput), MathUtils.EPSILON);
                   
                   // Additional test with larger value to ensure robustness
                   double largeInput = 5.0;
                   double expectedLarge = (Math.exp(largeInput) + Math.exp(-largeInput)) / 2.0;
                   assertEquals(expectedLarge, MathUtils.cosh(largeInput), MathUtils.EPSILON);
               }

 @Test
              public void testCosh() {
                  // Test case for x = 0 (should be 1.0)
                  double result0 = MathUtils.cosh(0.0);
                  assertEquals("cosh(0) should equal 1.0", 1.0, result0, 1e-15);
                  
                  // Test case for x = 1 (known value)
                  double result1 = MathUtils.cosh(1.0);
                  assertEquals("cosh(1) should equal ~1.543080634815244", 
                              1.543080634815244, result1, 1e-15);
                  
                  // Test case for x = -1 (should be same as cosh(1))
                  double resultNeg1 = MathUtils.cosh(-1.0);
                  assertEquals("cosh(-1) should equal cosh(1)", 
                              result1, resultNeg1, 1e-15);
                  
                  // Test case for x = 2 (another known value)
                  double result2 = MathUtils.cosh(2.0);
                  assertEquals("cosh(2) should equal ~3.7621956910836314", 
                              3.7621956910836314, result2, 1e-15);
              }

 @Test
             public void testCoshDetectsMutant() {
                 // Test with positive value where original and mutant differ
                 double x1 = 1.0;
                 double expected1 = (Math.exp(x1) + Math.exp(-x1)) / 2.0;
                 double mutantResult1 = (Math.exp(x1) + Math.exp(x1)) / 2.0;
                 assertNotEquals("Mutant should be detected for positive x", 
                                mutantResult1, MathUtils.cosh(x1), 0.0001);
                 
                 // Test with negative value where original and mutant differ
                 double x2 = -1.0;
                 double expected2 = (Math.exp(x2) + Math.exp(-x2)) / 2.0;
                 double mutantResult2 = (Math.exp(x2) + Math.exp(x2)) / 2.0;
                 assertNotEquals("Mutant should be detected for negative x", 
                                mutantResult2, MathUtils.cosh(x2), 0.0001);
                 
                 // Also verify the correct behavior matches expected
                 assertEquals(expected1, MathUtils.cosh(x1), 0.0001);
                 assertEquals(expected2, MathUtils.cosh(x2), 0.0001);
                 
                 // Edge case where both versions would give same result
                 double x3 = 0.0;
                 assertEquals(1.0, MathUtils.cosh(x3), 0.0001);
             }

 @Test
            public void testCoshDetectsMutant1() {
                // Test with positive value where e^x dominates e^-x
                double x = 2.0;
                double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                double actual = MathUtils.cosh(x);
                assertEquals("Cosh calculation is incorrect for positive x", expected, actual, 1e-10);
                
                // Test with negative value (though mutant would still be wrong)
                x = -2.0;
                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                actual = MathUtils.cosh(x);
                assertEquals("Cosh calculation is incorrect for negative x", expected, actual, 1e-10);
                
                // Test with zero (edge case where mutant would coincidentally work)
                x = 0.0;
                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                actual = MathUtils.cosh(x);
                assertEquals("Cosh calculation is incorrect for x=0", expected, actual, 1e-10);
                
                // Test with larger positive value where difference is more pronounced
                x = 5.0;
                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                actual = MathUtils.cosh(x);
                assertEquals("Cosh calculation is incorrect for larger x", expected, actual, 1e-10);
            }

 @Test
           public void testCosh1() {
               // Test x = 0 (should be 1.0)
               assertEquals(1.0, MathUtils.cosh(0.0), 1e-15);
               
               // Test x = 1 (known value)
               double expected1 = (Math.exp(1) + Math.exp(-1)) / 2.0;
               assertEquals(expected1, MathUtils.cosh(1.0), 1e-15);
               
               // Test x = -1 (should be same as positive 1 due to even function property)
               assertEquals(expected1, MathUtils.cosh(-1.0), 1e-15);
               
               // Test x = 2 (another known value)
               double expected2 = (Math.exp(2) + Math.exp(-2)) / 2.0;
               assertEquals(expected2, MathUtils.cosh(2.0), 1e-15);
           }

 @Test
          public void testCosh2() {
              // Test with 0 - simplest case where result should be exactly 1.0
              assertEquals(1.0, MathUtils.cosh(0.0), 0.000001);
              
              // Test with 1 - known value (e + 1/e)/2 ≈ 1.5430806348152437
              assertEquals(1.5430806348152437, MathUtils.cosh(1.0), 0.000001);
              
              // Test with -1 - should be same as positive 1 (even function)
              assertEquals(1.5430806348152437, MathUtils.cosh(-1.0), 0.000001);
              
              // Test with larger value (2.0)
              assertEquals(3.7621956910836314, MathUtils.cosh(2.0), 0.000001);
              
              // Test with small value (0.5)
              assertEquals(1.1276259652063807, MathUtils.cosh(0.5), 0.000001);
          }

 @Test
         public void testCoshDetectsAdditionToMultiplicationMutant() {
             // Test with positive value
             double x1 = 1.0;
             double expected1 = (Math.exp(x1) + Math.exp(-x1)) / 2.0;
             double actual1 = MathUtils.cosh(x1);
             assertEquals("Cosh calculation incorrect for positive value", expected1, actual1, 1e-10);
             
             // Test with negative value
             double x2 = -1.0;
             double expected2 = (Math.exp(x2) + Math.exp(-x2)) / 2.0;
             double actual2 = MathUtils.cosh(x2);
             assertEquals("Cosh calculation incorrect for negative value", expected2, actual2, 1e-10);
             
             // Test with larger value to ensure significant difference
             double x3 = 5.0;
             double expected3 = (Math.exp(x3) + Math.exp(-x3)) / 2.0;
             double actual3 = MathUtils.cosh(x3);
             assertEquals("Cosh calculation incorrect for larger value", expected3, actual3, 1e-10);
         }

 @Test
        public void testCoshDetectsMutant2() {
            // Test with x = 0 where the difference should be most obvious
            // Original: (e^0 + e^-0)/2 = (1 + 1)/2 = 1
            // Mutant: (e^0 + e^(-0+1))/2 = (1 + e^1)/2 ≈ (1 + 2.718)/2 ≈ 1.859
            double x = 0.0;
            double expected = 1.0; // Known value of cosh(0)
            double actual = MathUtils.cosh(x);
            assertEquals("Cosh(0) should be 1.0", expected, actual, 1e-10);
            
            // Test with x = 1 where the difference is also significant
            // Original: (e^1 + e^-1)/2 ≈ (2.718 + 0.3679)/2 ≈ 1.543
            // Mutant: (e^1 + e^(-1+1))/2 = (2.718 + e^0)/2 ≈ (2.718 + 1)/2 ≈ 1.859
            x = 1.0;
            expected = (Math.exp(1) + Math.exp(-1)) / 2.0; // True value
            actual = MathUtils.cosh(x);
            assertEquals("Cosh(1) should match mathematical definition", expected, actual, 1e-10);
            
            // Test with negative value x = -1
            // Original: (e^-1 + e^1)/2 ≈ (0.3679 + 2.718)/2 ≈ 1.543
            // Mutant: (e^-1 + e^(1+1))/2 ≈ (0.3679 + e^2)/2 ≈ (0.3679 + 7.389)/2 ≈ 3.878
            x = -1.0;
            expected = (Math.exp(-1) + Math.exp(1)) / 2.0; // True value
            actual = MathUtils.cosh(x);
            assertEquals("Cosh(-1) should match mathematical definition", expected, actual, 1e-10);
        }

 @Test
       public void testCoshDetectsMutant3() {
           // Test with x=0 (simplest case)
           double x = 0.0;
           double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
           double actual = MathUtils.cosh(x);
           assertEquals("Cosh(0) should be 1.0", 1.0, actual, 1e-15);
           assertEquals(expected, actual, 1e-15);
           
           // Test with positive x where difference is significant
           x = 1.0;
           expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
           actual = MathUtils.cosh(x);
           assertEquals(expected, actual, 1e-15);
           
           // Test with negative x
           x = -1.0;
           expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
           actual = MathUtils.cosh(x);
           assertEquals(expected, actual, 1e-15);
           
           // Test with larger positive value where mutant would be very different
           x = 5.0;
           expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
           actual = MathUtils.cosh(x);
           assertEquals(expected, actual, 1e-10); // Slightly relaxed delta for larger values
       }

 @Test
      public void testCoshDivisionByZeroMutant() {
          // Test with 0 (cosh(0) = 1)
          double result = MathUtils.cosh(0);
          assertFalse("Result should not be infinite", Double.isInfinite(result));
          assertFalse("Result should not be NaN", Double.isNaN(result));
          assertEquals("cosh(0) should be 1", 1.0, result, 1e-10);
          
          // Test with positive value
          double x = 1.5;
          double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
          result = MathUtils.cosh(x);
          assertFalse("Result should not be infinite", Double.isInfinite(result));
          assertFalse("Result should not be NaN", Double.isNaN(result));
          assertEquals("cosh(x) calculation incorrect", expected, result, 1e-10);
          
          // Test with negative value (should be same as positive)
          x = -1.5;
          expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
          result = MathUtils.cosh(x);
          assertFalse("Result should not be infinite", Double.isInfinite(result));
          assertFalse("Result should not be NaN", Double.isNaN(result));
          assertEquals("cosh(-x) should equal cosh(x)", expected, result, 1e-10);
      }

 @Test
     public void testCosh3() {
         // Test with positive value
         double x1 = 1.0;
         double expected1 = (Math.exp(x1) + Math.exp(-x1)) / 2.0;
         assertEquals(expected1, MathUtils.cosh(x1), 1e-15);
         
         // Test with negative value (cosh is even function)
         double x2 = -1.0;
         assertEquals(MathUtils.cosh(x1), MathUtils.cosh(x2), 1e-15);
         
         // Test with zero
         double x3 = 0.0;
         double expected3 = 1.0; // cosh(0) = 1
         assertEquals(expected3, MathUtils.cosh(x3), 1e-15);
         
         // Test with large value
         double x4 = 10.0;
         double expected4 = (Math.exp(x4) + Math.exp(-x4)) / 2.0;
         assertEquals(expected4, MathUtils.cosh(x4), 1e-10);
         
         // Test with small value
         double x5 = 0.0001;
         double expected5 = (Math.exp(x5) + Math.exp(-x5)) / 2.0;
         assertEquals(expected5, MathUtils.cosh(x5), 1e-15);
         
         // Test symmetry property: cosh(x) == cosh(-x)
         double x6 = 2.5;
         assertEquals(MathUtils.cosh(x6), MathUtils.cosh(-x6), 1e-15);
     }

}
