package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
            public void testFactorial_ValidValues() {
                // Test typical valid values
                assertEquals(1, MathUtils.factorial(0));  // 0! = 1
                assertEquals(1, MathUtils.factorial(1));  // 1! = 1
                assertEquals(2, MathUtils.factorial(2));  // 2! = 2
                assertEquals(6, MathUtils.factorial(3));  // 3! = 6
                assertEquals(24, MathUtils.factorial(4));  // 4! = 24
                assertEquals(120, MathUtils.factorial(5)); // 5! = 120
                
                // Test boundary value (20)
                assertEquals(2432902008176640000L, MathUtils.factorial(20));
            }

 @Test
            public void testFactorial_NegativeValue() {
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("must have n >= 0 for n!");
                MathUtils.factorial(-1);
            }

 @Test
            public void testFactorial_ValueTooLarge() {
                thrown.expect(ArithmeticException.class);
                thrown.expectMessage("factorial value is too large to fit in a long");
                MathUtils.factorial(21);  // 21! is too large for long
            }

 @Test
            public void testFactorial_UpperBoundary() {
                // Test the maximum allowed value (20)
                // This should not throw an exception
                long result = MathUtils.factorial(20);
                assertEquals(2432902008176640000L, result);
            }

 @Test
            public void testFactorial_LowerBoundary() {
                // Test the minimum allowed value (0)
                // This should not throw an exception
                long result = MathUtils.factorial(0);
                assertEquals(1, result);
            }

 @Test
            public void testFactorial_JustAboveUpperBoundary() {
                thrown.expect(ArithmeticException.class);
                thrown.expectMessage("factorial value is too large to fit in a long");
                MathUtils.factorial(21);  // One above the boundary
            }

 @Test
            public void testFactorial_JustBelowLowerBoundary() {
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("must have n >= 0 for n!");
                MathUtils.factorial(-1);  // One below the boundary
            }

 @Test
            public void testFactorialDouble_NegativeInput() {
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("must have n >= 0 for n!");
                MathUtils.factorialDouble(-1);
            }

 @Test
            public void testFactorialDouble_ZeroInput() {
                assertEquals(1.0, MathUtils.factorialDouble(0), MathUtils.EPSILON);
            }

 @Test
            public void testFactorialDouble_SmallValues() {
                // Test values below 21 (uses factorial method)
                assertEquals(1.0, MathUtils.factorialDouble(1), MathUtils.EPSILON);
                assertEquals(2.0, MathUtils.factorialDouble(2), MathUtils.EPSILON);
                assertEquals(6.0, MathUtils.factorialDouble(3), MathUtils.EPSILON);
                assertEquals(24.0, MathUtils.factorialDouble(4), MathUtils.EPSILON);
                assertEquals(120.0, MathUtils.factorialDouble(5), MathUtils.EPSILON);
                assertEquals(2432902008176640000.0, MathUtils.factorialDouble(20), MathUtils.EPSILON);
            }

 @Test
            public void testFactorialDouble_LargeValues() {
                // Test values 21 and above (uses factorialLog and Math.exp)
                // Using known factorial values for verification
                assertEquals(5.109094217170944E19, MathUtils.factorialDouble(21), MathUtils.EPSILON);
                assertEquals(1.1240007277776077E21, MathUtils.factorialDouble(22), MathUtils.EPSILON);
                assertEquals(2.585201673888498E22, MathUtils.factorialDouble(23), MathUtils.EPSILON);
                assertEquals(6.204484017332394E23, MathUtils.factorialDouble(24), MathUtils.EPSILON);
                
                // Test a very large value (boundary case)
                double result = MathUtils.factorialDouble(100);
                assertTrue(result > 9.0E157 && result < 1.0E158); // 100! is approximately 9.3326E157
            }

 @Test
            public void testFactorialDouble_BoundaryValue() {
                // Test exactly at the boundary between small and large values (20 and 21)
                assertEquals(2432902008176640000.0, MathUtils.factorialDouble(20), MathUtils.EPSILON);
                assertEquals(5.109094217170944E19, MathUtils.factorialDouble(21), MathUtils.EPSILON);
            }

 @Test
            public void testFactorialDouble_Precision() {
                // Test precision of the calculation for large values
                double result21 = MathUtils.factorialDouble(21);
                double expected21 = 51090942171709440000.0;
                assertEquals(expected21, result21, expected21 * MathUtils.EPSILON);
                
                double result30 = MathUtils.factorialDouble(30);
                double expected30 = 2.6525285981219103E32;
                assertEquals(expected30, result30, expected30 * MathUtils.EPSILON);
            }

 @Test
            public void testFactorialLog_NegativeInput() {
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("must have n > 0 for n!");
                MathUtils.factorialLog(-1);
            }

 @Test
            public void testFactorialLog_ZeroInput() {
                double result = MathUtils.factorialLog(0);
                assertEquals(0.0, result, MathUtils.EPSILON);
            }

 @Test
            public void testFactorialLog_SmallValues() {
                // Test values below 21 (uses factorial(n))
                assertEquals(Math.log(1), MathUtils.factorialLog(1), MathUtils.EPSILON);
                assertEquals(Math.log(2), MathUtils.factorialLog(2), MathUtils.EPSILON);
                assertEquals(Math.log(6), MathUtils.factorialLog(3), MathUtils.EPSILON);
                assertEquals(Math.log(24), MathUtils.factorialLog(4), MathUtils.EPSILON);
                assertEquals(Math.log(120), MathUtils.factorialLog(5), MathUtils.EPSILON);
                assertEquals(Math.log(2432902008176640000L), MathUtils.factorialLog(20), MathUtils.EPSILON);
            }

 @Test
            public void testFactorialLog_BoundaryValue() {
                // Test the boundary case where n = 20 (still uses factorial(n))
                double expected = Math.log(2432902008176640000L);
                double actual = MathUtils.factorialLog(20);
                assertEquals(expected, actual, MathUtils.EPSILON);
            }

 @Test
            public void testFactorialLog_BoundaryValue1() {
                // Test the boundary case where n = 21 (switches to iterative log sum)
                double expected = 0.0;
                for (int i = 2; i <= 21; i++) {
                    expected += Math.log(i);
                }
                double actual = MathUtils.factorialLog(21);
                assertEquals(expected, actual, MathUtils.EPSILON);
            }

 @Test
            public void testFactorialLog_LargeValues() {
                // Test values above 20 (uses iterative log sum)
                double expected30 = 0.0;
                for (int i = 2; i <= 30; i++) {
                    expected30 += Math.log(i);
                }
                assertEquals(expected30, MathUtils.factorialLog(30), MathUtils.EPSILON);
                
                double expected50 = 0.0;
                for (int i = 2; i <= 50; i++) {
                    expected50 += Math.log(i);
                }
                assertEquals(expected50, MathUtils.factorialLog(50), MathUtils.EPSILON);
                
                double expected100 = 0.0;
                for (int i = 2; i <= 100; i++) {
                    expected100 += Math.log(i);
                }
                assertEquals(expected100, MathUtils.factorialLog(100), MathUtils.EPSILON);
            }

 @Test
            public void testFactorialLog_ConsistencyBetweenMethods() {
                // Verify that both methods (factorial then log vs iterative log sum) 
                // produce the same result at the boundary (n=20)
                double factorialThenLog = Math.log(MathUtils.factorial(20));
                double iterativeLogSum = 0.0;
                for (int i = 2; i <= 20; i++) {
                    iterativeLogSum += Math.log(i);
                }
                assertEquals(factorialThenLog, iterativeLogSum, MathUtils.EPSILON);
            }

 @Test
    public void testFactorialLogBoundaryCondition() {
        // Test the boundary case where n=20
        int n = 20;
        
        // Expected value using direct factorial calculation (original behavior)
        double expected = Math.log(MathUtils.factorial(n));
        
        // Actual value from the method
        double actual = MathUtils.factorialLog(n);
        
        // Verify they match (would fail if mutant is present)
        assertEquals("For n=20, should use direct factorial calculation", 
                    expected, actual, 1e-15);
        
        // Additional verification that iterative calculation would give slightly different result
        double iterativeSum = 0;
        for (int i = 2; i <= n; i++) {
            iterativeSum += Math.log((double)i);
        }
        assertNotEquals("For n=20, iterative sum should differ from direct calculation",
                       iterativeSum, actual, 1e-15);
    }

 @Test
       public void testFactorialLogEdgeCase() {
           // Test with n=1 (should not include log(1.0) in calculation)
           double result = MathUtils.factorialLog(1);
           assertEquals(0.0, result, 1e-10); // log(1!) = 0
       }

 @Test
       public void testFactorialLogEdgeCase1() {
           // Test with n=2 (should only include log(2.0))
           double result = MathUtils.factorialLog(2);
           assertEquals(Math.log(2), result, 1e-10);
       }

 @Test
       public void testFactorialLogLargeNumber() {
           // Test with n=21 (boundary where it switches to loop method)
           double expected = 0.0;
           for (int i = 2; i <= 21; i++) {
               expected += Math.log(i);
           }
           double result = MathUtils.factorialLog(21);
           assertEquals(expected, result, 1e-10);
       }

 @Test(expected = IllegalArgumentException.class)
       public void testFactorialLogNegativeInput() {
           MathUtils.factorialLog(-1);
       }

 @Test
  public void testFactorialLogLargeNumberPrecision() {
      // Test with n=21 to ensure we hit the loop case
      // The key is that for large enough n, (int) casting will lose precision
      // compared to (double) casting before taking log
      
      // Calculate expected value using precise method
      double expected = 0.0;
      for (int i = 2; i <= 21; i++) {
          expected += Math.log((double)i);
      }
      
      // Get actual value from method
      double actual = MathUtils.factorialLog(21);
      
      // Verify they match with high precision
      assertEquals(expected, actual, 1e-15);
      
      // Additional test with larger number to emphasize precision difference
      double expectedLarge = 0.0;
      for (int i = 2; i <= 100; i++) {
          expectedLarge += Math.log((double)i);
      }
      double actualLarge = MathUtils.factorialLog(100);
      assertEquals(expectedLarge, actualLarge, 1e-15);
  }

 @Test
     public void testFactorialLogPrecisionForLargeN() {
         // Choose a value where float precision loss would be noticeable
         int n = 100;
         
         // Calculate expected value using original implementation (double)
         double expected = 0;
         for (int i = 2; i <= n; i++) {
             expected += Math.log((double)i);
         }
         
         // Get actual value from the method
         double actual = MathUtils.factorialLog(n);
         
         // Verify the result matches with high precision
         assertEquals("Log factorial should maintain double precision", 
                     expected, actual, 1e-15);
         
         // Additional check to ensure the mutant would fail
         // The mutant using float would have larger error
         double mutantValue = 0;
         for (int i = 2; i <= n; i++) {
             mutantValue += Math.log((float)i);
         }
         assertNotEquals("Test should detect float precision loss", 
                        mutantValue, actual, 0);
     }

}
