package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.util.MathUtils;
 
public class EigenDecompositionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                          public void testFlipIfWarranted_WithDifferentStepValues() throws Exception {
                                                                                                                                                                                                                              // Test with step=2 to verify partial flipping
                                                                                                                                                                                                                              int n = 3;
                                                                                                                                                                                                                              int step = 2;
                                                                                                                                                                                                                              int pingPong = 0; // Assuming pingPong is 0 based on test logic
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Create work array with sufficient size (4*(n-1) + pingPong + 1 = 9)
                                                                                                                                                                                                                              double[] work = new double[8];
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Setup flip condition
                                                                                                                                                                                                                              work[pingPong] = 10.0;
                                                                                                                                                                                                                              work[4 * (n - 1) + pingPong] = 5.0;
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Fill array with test values
                                                                                                                                                                                                                              for (int i = 0; i < work.length; i++) {
                                                                                                                                                                                                                                  work[i] = i * 1.0;
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Create EigenDecompositionImpl instance with dummy data
                                                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Use reflection to access private method
                                                                                                                                                                                                                              Method flipIfWarranted = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                                  "flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                                              flipIfWarranted.setAccessible(true);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Get work field to set our test array
                                                                                                                                                                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                              workField.setAccessible(true);
                                                                                                                                                                                                                              workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              boolean result = (boolean) flipIfWarranted.invoke(eigenDecomposition, n, step);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              assertTrue(result);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Verify only every second element was flipped
                                                                                                                                                                                                                              // Original array: [0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0]
                                                                                                                                                                                                                              // With step=2, only elements at k=0 and k=2 in each block are flipped
                                                                                                                                                                                                                              assertEquals(8.0, work[0], 0.0001); // k=0 flipped
                                                                                                                                                                                                                              assertEquals(1.0, work[1], 0.0001);  // k=1 unchanged
                                                                                                                                                                                                                              assertEquals(10.0, work[2], 0.0001); // k=2 flipped
                                                                                                                                                                                                                              assertEquals(3.0, work[3], 0.0001);  // k=3 unchanged
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              assertEquals(4.0, work[4], 0.0001);  // k=0 in second block
                                                                                                                                                                                                                              assertEquals(5.0, work[5], 0.0001);  // k=1 unchanged
                                                                                                                                                                                                                              assertEquals(6.0, work[6], 0.0001);  // k=2 in second block
                                                                                                                                                                                                                              assertEquals(7.0, work[7], 0.0001);  // k=3 unchanged
                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                      public void testFlipIfWarranted_ShouldFlipWhenConditionMet() {
                                                                                                                                                                                                                          // Setup test case where flip is warranted
                                                                                                                                                                                                                          int n = 3; // Array size parameter
                                                                                                                                                                                                                          int step = 1; // Step size
                                                                                                                                                                                                                          int pingPong = 0; // Initialize pingPong
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Initialize work array with sufficient size (4*(n-1)+1 = 9 elements)
                                                                                                                                                                                                                          double[] work = new double[9];
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Initialize work array to trigger flip condition
                                                                                                                                                                                                                          // work[4*(n-1) + pingPong] should be less than 1.5*work[pingPong]
                                                                                                                                                                                                                          work[pingPong] = 10.0;
                                                                                                                                                                                                                          work[4 * (n - 1) + pingPong] = 5.0; // 5.0 < 1.5*10.0 (15.0)
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Fill the array with test values that will be flipped
                                                                                                                                                                                                                          for (int i = 0; i < work.length; i++) {
                                                                                                                                                                                                                              work[i] = i * 1.0;
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Create EigenDecompositionImpl instance with dummy data
                                                                                                                                                                                                                          double[] main = new double[0];
                                                                                                                                                                                                                          double[] secondary = new double[0];
                                                                                                                                                                                                                          double splitTolerance = 0.0;
                                                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to set the work array since it's likely a private field
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                              workField.setAccessible(true);
                                                                                                                                                                                                                              workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                              fail("Failed to set work array via reflection");
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to call the private flipIfWarranted method
                                                                                                                                                                                                                          boolean result = false;
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                                              flipMethod.setAccessible(true);
                                                                                                                                                                                                                              result = (boolean) flipMethod.invoke(eigenDecomposition, n, step);
                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                              fail("Failed to invoke flipIfWarranted method via reflection");
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          assertTrue("Method should return true when flip occurs", result);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Verify the array was flipped correctly
                                                                                                                                                                                                                          // Original array: [0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0]
                                                                                                                                                                                                                          // After flip (for n=3, step=1):
                                                                                                                                                                                                                          // Should swap elements in blocks of 4 with step=1
                                                                                                                                                                                                                          assertEquals(8.0, work[0], 0.0001); // First element in first block
                                                                                                                                                                                                                          assertEquals(7.0, work[1], 0.0001);
                                                                                                                                                                                                                          assertEquals(6.0, work[2], 0.0001);
                                                                                                                                                                                                                          assertEquals(5.0, work[3], 0.0001);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          assertEquals(4.0, work[4], 0.0001); // First element in second block
                                                                                                                                                                                                                          assertEquals(3.0, work[5], 0.0001);
                                                                                                                                                                                                                          assertEquals(2.0, work[6], 0.0001);
                                                                                                                                                                                                                          assertEquals(1.0, work[7], 0.0001);
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                      public void testFlipIfWarranted_ShouldNotFlipWhenConditionNotMet() {
                                                                                                                                                                                                                          // Setup test case where flip is not warranted
                                                                                                                                                                                                                          int n = 3;
                                                                                                                                                                                                                          int step = 1;
                                                                                                                                                                                                                          int pingPong = 0; // Assuming pingPong is 0 based on typical usage
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Initialize work array with sufficient size
                                                                                                                                                                                                                          double[] work = new double[4 * n]; // Enough space for n=3
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Set values to not trigger flip condition
                                                                                                                                                                                                                          work[pingPong] = 10.0;
                                                                                                                                                                                                                          work[4 * (n - 1) + pingPong] = 20.0; // 20.0 > 1.5*10.0 (15.0)
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Create eigen decomposition instance with dummy data
                                                                                                                                                                                                                          double[] main = new double[n];
                                                                                                                                                                                                                          double[] secondary = new double[n-1];
                                                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to set the work array if needed (assuming it's private)
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                              workField.setAccessible(true);
                                                                                                                                                                                                                              workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                              fail("Failed to set work array via reflection");
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Save original array for comparison
                                                                                                                                                                                                                          double[] originalWork = work.clone();
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to call the private method
                                                                                                                                                                                                                          boolean result = false;
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                                              flipMethod.setAccessible(true);
                                                                                                                                                                                                                              result = (boolean) flipMethod.invoke(eigenDecomposition, n, step);
                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                              fail("Failed to invoke flipIfWarranted method via reflection");
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          assertFalse("Method should return false when no flip occurs", result);
                                                                                                                                                                                                                          assertArrayEquals("Work array should remain unchanged", originalWork, work, 0.0001);
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                      public void testFlipIfWarranted_WithEdgeCaseValues() {
                                                                                                                                                                                                                          // Initialize required objects and variables
                                                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                                                                          int pingPong = 0;  // typical initial value for pingPong
                                                                                                                                                                                                                          double[] work = new double[8];  // size needs to be at least 4*(n-1)+pingPong+1 (for n=2, min size is 5)
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Test with edge case values (zeros, very small numbers)
                                                                                                                                                                                                                          int n = 2;
                                                                                                                                                                                                                          int step = 1;
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Setup flip condition with very small numbers
                                                                                                                                                                                                                          work[pingPong] = Double.MIN_VALUE;
                                                                                                                                                                                                                          work[4 * (n - 1) + pingPong] = Double.MIN_VALUE / 2;
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Fill array with test values
                                                                                                                                                                                                                          for (int i = 0; i < work.length; i++) {
                                                                                                                                                                                                                              work[i] = i * 0.000001;
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to set the work array since it's likely private
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                              workField.setAccessible(true);
                                                                                                                                                                                                                              workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                              fail("Failed to set work array via reflection: " + e.getMessage());
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to call the private flipIfWarranted method
                                                                                                                                                                                                                          boolean result = false;
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                                              flipMethod.setAccessible(true);
                                                                                                                                                                                                                              result = (boolean) flipMethod.invoke(eigenDecomposition, n, step);
                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                              fail("Failed to invoke flipIfWarranted method via reflection: " + e.getMessage());
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          assertTrue(result);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Verify flip occurred correctly with small numbers
                                                                                                                                                                                                                          assertEquals(0.000004, work[0], 0.0000001);
                                                                                                                                                                                                                          assertEquals(0.000005, work[1], 0.0000001);
                                                                                                                                                                                                                          assertEquals(0.000002, work[2], 0.0000001);
                                                                                                                                                                                                                          assertEquals(0.000003, work[3], 0.0000001);
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                      public void testFlipIfWarranted_WithInvalidN() throws Exception {
                                                                                                                                                                                                                          // Create EigenDecompositionImpl with required parameters
                                                                                                                                                                                                                          double[] main = new double[4]; // minimum size needed for n=1
                                                                                                                                                                                                                          double[] secondary = new double[3];
                                                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-12);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Set up required internal state using reflection
                                                                                                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                                                                                          double[] work = new double[4 * 4]; // enough space for n=1 case
                                                                                                                                                                                                                          workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          int step = 1;
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Get the private method using reflection
                                                                                                                                                                                                                          Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                                          flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // n <= 0 should throw exception
                                                                                                                                                                                                                          thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                          flipIfWarrantedMethod.invoke(eigenDecomposition, 0, step);
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                 public void testFlipIfWarranted_ShouldNotFlipWhenValuesAreEqual() {
                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to access private fields and methods since we need to test them
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                         workField.setAccessible(true);
                                                                                                                                                                                                                         Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                         pingPongField.setAccessible(true);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Get the private method
                                                                                                                                                                                                                         Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                                         flipMethod.setAccessible(true);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Create test case where 1.5 * work[pingPong] == work[4*(n-1)+pingPong]
                                                                                                                                                                                                                         int n = 2;  // So 4*(n-1) = 4
                                                                                                                                                                                                                         int pingPong = 0;
                                                                                                                                                                                                                         double[] work = new double[10];
                                                                                                                                                                                                                         work[pingPong] = 2.0;  // work[0] = 2.0
                                                                                                                                                                                                                         work[4*(n-1) + pingPong] = 3.0;  // work[4] = 3.0 (since 1.5*2.0 = 3.0)
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         workField.set(eigen, work);
                                                                                                                                                                                                                         pingPongField.setInt(eigen, pingPong);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Test using reflection to invoke the private method
                                                                                                                                                                                                                         boolean result = (boolean) flipMethod.invoke(eigen, n, 1);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Verify - original should return false, mutant would return true
                                                                                                                                                                                                                         assertFalse("Method should return false when values are equal", result);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Additionally verify array wasn't modified
                                                                                                                                                                                                                         assertEquals(2.0, work[0], 0.0001);
                                                                                                                                                                                                                         assertEquals(3.0, work[4], 0.0001);
                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                         fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                            public void testFlipIfWarrantedDetectsMutant() {
                                                                                                                                                                                                                // Setup test data where:
                                                                                                                                                                                                                // 1.5 * work[pingPong] is between work[4*(n-1)+pingPong] and work[4*n+pingPong]
                                                                                                                                                                                                                // This will make original return false but mutant return true
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Create test instance
                                                                                                                                                                                                                EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Set up test parameters
                                                                                                                                                                                                                int n = 2;  // Choose n=2 so 4*(n-1)=4 and 4*n=8
                                                                                                                                                                                                                int step = 1;
                                                                                                                                                                                                                int pingPong = 0;
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Create work array with specific values
                                                                                                                                                                                                                double[] work = new double[20];  // Large enough to avoid index issues
                                                                                                                                                                                                                work[pingPong] = 10.0;           // 1.5*work[pingPong] = 15.0
                                                                                                                                                                                                                work[4*(n-1) + pingPong] = 20.0; // Original checks this (20 > 15 → false)
                                                                                                                                                                                                                work[4*n + pingPong] = 10.0;     // Mutant checks this (10 < 15 → true)
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Set fields via reflection since they're private
                                                                                                                                                                                                                try {
                                                                                                                                                                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                    workField.setAccessible(true);
                                                                                                                                                                                                                    workField.set(eigen, work);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                    pingPongField.setAccessible(true);
                                                                                                                                                                                                                    pingPongField.set(eigen, pingPong);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Get and invoke the private method
                                                                                                                                                                                                                    Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                                    flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                                                                    boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Test - original should return false, mutant would return true
                                                                                                                                                                                                                    assertFalse("Test should detect mutant by returning false", result);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                    fail("Failed to set private fields or invoke private method via reflection: " + e.getMessage());
                                                                                                                                                                                                                }
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify work array wasn't modified (since flip shouldn't happen)
                                                                                                                                                                                                                assertEquals(10.0, work[pingPong], 0.0001);
                                                                                                                                                                                                                assertEquals(20.0, work[4*(n-1) + pingPong], 0.0001);
                                                                                                                                                                                                                assertEquals(10.0, work[4*n + pingPong], 0.0001);
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                       public void testFlipIfWarrantedDetectsMutant1() throws Exception {
                                                                                                                                                                                                           // Setup test data where the flip condition is true
                                                                                                                                                                                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[10], new double[9], 1.0e-10);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Use reflection to access private fields
                                                                                                                                                                                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                           workField.setAccessible(true);
                                                                                                                                                                                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                           pingPongField.setAccessible(true);
                                                                                                                                                                                                           Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                           flipMethod.setAccessible(true);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Set up work array where flip condition will be true
                                                                                                                                                                                                           // We need work[4*(n-1)+pingPong] > 1.5*work[pingPong]
                                                                                                                                                                                                           double[] work = new double[20]; // Large enough array
                                                                                                                                                                                                           workField.set(eigen, work);
                                                                                                                                                                                                           pingPongField.set(eigen, 0); // Simple case
                                                                                                                                                                                                           work[0] = 1.0; // work[pingPong] = 1.0
                                                                                                                                                                                                           int n = 3; // Chosen so 4*(n-1)=8 and 4*n=12 are different
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Set work[8] (4*(3-1)) to be > 1.5
                                                                                                                                                                                                           work[8] = 2.0; // 2.0 > 1.5*1.0
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Make a copy of original array to compare
                                                                                                                                                                                                           double[] originalWork = work.clone();
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Test with step=1 (simplest case)
                                                                                                                                                                                                           boolean result = (boolean) flipMethod.invoke(eigen, n, 1);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify flipping occurred
                                                                                                                                                                                                           assertTrue(result);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Get updated work array
                                                                                                                                                                                                           work = (double[]) workField.get(eigen);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify flipping was correct:
                                                                                                                                                                                                           // Original method would flip elements 0-7 with 8-15
                                                                                                                                                                                                           // Mutant would try to flip 0-11 with 12-23 (but array only has 20)
                                                                                                                                                                                                           if (originalWork[0] != work[8] || originalWork[8] != work[0]) {
                                                                                                                                                                                                               // Original behavior detected
                                                                                                                                                                                                               // This is what we want - test passes
                                                                                                                                                                                                           } else {
                                                                                                                                                                                                               // Mutant behavior detected - test should fail
                                                                                                                                                                                                               fail("Mutant behavior detected - array flipping didn't occur as expected");
                                                                                                                                                                                                           }
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Additional check for array bounds safety
                                                                                                                                                                                                           try {
                                                                                                                                                                                                               // Try with larger n that would make mutant exceed array bounds
                                                                                                                                                                                                               n = 6; // 4*6=24 > array length 20
                                                                                                                                                                                                               work[4*(n-1)] = 2.0; // work[20] - but array length is 20 (0-19)
                                                                                                                                                                                                               flipMethod.invoke(eigen, n, 1);
                                                                                                                                                                                                               // If we get here, mutant survived (original would have j=20 which is valid)
                                                                                                                                                                                                               fail("Mutant survived - didn't throw ArrayIndexOutOfBoundsException");
                                                                                                                                                                                                           } catch (InvocationTargetException e) {
                                                                                                                                                                                                               if (e.getCause() instanceof ArrayIndexOutOfBoundsException) {
                                                                                                                                                                                                                   // Expected for mutant, test passes
                                                                                                                                                                                                               } else {
                                                                                                                                                                                                                   throw e;
                                                                                                                                                                                                               }
                                                                                                                                                                                                           }
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                  public void testFlipIfWarrantedDetectsMutatedLoopCondition() throws Exception {
                                                                                                                                                                                                      // Setup test data where flip will be warranted
                                                                                                                                                                                                      int n = 2;  // Results in j = 4*(2-1) = 4
                                                                                                                                                                                                      int step = 1;
                                                                                                                                                                                                      int pingPong = 0;
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Create work array where flip condition is true
                                                                                                                                                                                                      double[] work = new double[8];  // Need at least 4*(n-1)+pingPong+1 = 5 elements
                                                                                                                                                                                                      work[pingPong] = 1.0;           // work[0] = 1.0
                                                                                                                                                                                                      work[4 * (n - 1) + pingPong] = 2.0; // work[4] = 2.0 (1.5*1 < 2 → true)
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Fill with test values that will show if extra swap occurs
                                                                                                                                                                                                      for (int i = 0; i < work.length; i++) {
                                                                                                                                                                                                          work[i] = i;
                                                                                                                                                                                                      }
                                                                                                                                                                                                      double[] originalWork = work.clone();
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Create instance and set required fields using reflection
                                                                                                                                                                                                      EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Set private work field
                                                                                                                                                                                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                      workField.setAccessible(true);
                                                                                                                                                                                                      workField.set(eigen, work);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Set private pingPong field
                                                                                                                                                                                                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                      pingPongField.setAccessible(true);
                                                                                                                                                                                                      pingPongField.set(eigen, pingPong);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Get private flipIfWarranted method
                                                                                                                                                                                                      Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                      flipMethod.setAccessible(true);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Execute the method
                                                                                                                                                                                                      boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Verify results
                                                                                                                                                                                                      assertTrue(result);  // Flip should have occurred
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Verify correct number of swaps occurred (should be 1 iteration with 4 swaps)
                                                                                                                                                                                                      // Original: i=0,j=4 → swaps (0,4), (1,3), (2,2), (3,1)
                                                                                                                                                                                                      // Mutated: would also do i=4,j=0 → swap (4,0), (5,-1) → which would fail
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Check specific positions to ensure correct swapping
                                                                                                                                                                                                      assertEquals(4.0, work[0], 0.0001);  // Should be swapped with original work[4]
                                                                                                                                                                                                      assertEquals(3.0, work[1], 0.0001);  // Should be swapped with original work[3]
                                                                                                                                                                                                      assertEquals(2.0, work[2], 0.0001);  // Should remain unchanged (middle element)
                                                                                                                                                                                                      assertEquals(1.0, work[3], 0.0001);  // Should be swapped with original work[1]
                                                                                                                                                                                                      assertEquals(0.0, work[4], 0.0001);  // Should be swapped with original work[0]
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Elements beyond should remain unchanged
                                                                                                                                                                                                      assertEquals(5.0, work[5], 0.0001);
                                                                                                                                                                                                      assertEquals(6.0, work[6], 0.0001);
                                                                                                                                                                                                      assertEquals(7.0, work[7], 0.0001);
                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                             public void testFlipIfWarrantedDetectsIncrementMutation() throws Exception {
                                                                                                                                                                                                 // Setup test data that will trigger the flip
                                                                                                                                                                                                 int n = 3;  // This makes j = 4*(3-1) = 8 in the method
                                                                                                                                                                                                 int step = 1;
                                                                                                                                                                                                 int pingPong = 0;
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Create a work array where the flip condition is true
                                                                                                                                                                                                 // The array is structured so the mutation's different increment will produce different results
                                                                                                                                                                                                 double[] work = new double[20];  // Large enough to avoid index issues
                                                                                                                                                                                                 work[pingPong] = 10.0;          // 1.5 * 10 = 15
                                                                                                                                                                                                 work[4 * (n - 1) + pingPong] = 20.0;  // 20 > 15, so flip will occur
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Fill the array with distinct values that will show if flipping is correct
                                                                                                                                                                                                 for (int i = 0; i < 8; i += 4) {
                                                                                                                                                                                                     work[i] = 100 + i;
                                                                                                                                                                                                     work[i+1] = 200 + i;
                                                                                                                                                                                                     work[i+2] = 300 + i;
                                                                                                                                                                                                     work[i+3] = 400 + i;
                                                                                                                                                                                                 }
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Expected array after correct flipping (i += 4)
                                                                                                                                                                                                 double[] expected = work.clone();
                                                                                                                                                                                                 int j = 4 * (n - 1);
                                                                                                                                                                                                 for (int i = 0; i < j; i += 4) {
                                                                                                                                                                                                     for (int k = 0; k < 4; k += step) {
                                                                                                                                                                                                         final double tmp = expected[i + k];
                                                                                                                                                                                                         expected[i + k] = expected[j - k];
                                                                                                                                                                                                         expected[j - k] = tmp;
                                                                                                                                                                                                     }
                                                                                                                                                                                                     j -= 4;
                                                                                                                                                                                                 }
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Create test instance
                                                                                                                                                                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Use reflection to set private fields
                                                                                                                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                 workField.setAccessible(true);
                                                                                                                                                                                                 workField.set(eigen, work);
                                                                                                                                                                                                 
                                                                                                                                                                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                                                                                                 pingPongField.set(eigen, pingPong);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Use reflection to invoke private method
                                                                                                                                                                                                 Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                 flipMethod.setAccessible(true);
                                                                                                                                                                                                 boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Verify results
                                                                                                                                                                                                 assertTrue(result);  // Verify flip occurred
                                                                                                                                                                                                 assertArrayEquals(expected, work, 0.0001);  // Verify exact array state
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                        public void testFlipIfWarrantedDetectsMutatedLoopCondition1() {
                                                                                                                                                                                            // Setup
                                                                                                                                                                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                                            
                                                                                                                                                                                            // Use reflection to set private fields and call private method
                                                                                                                                                                                            try {
                                                                                                                                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                pingPongField.setAccessible(true);
                                                                                                                                                                                                
                                                                                                                                                                                                // Create a work array that will trigger the flip condition
                                                                                                                                                                                                // The array needs to be large enough for the indices being accessed
                                                                                                                                                                                                double[] work = new double[20];
                                                                                                                                                                                                work[0] = 1.0;  // pingPong index
                                                                                                                                                                                                work[4 * (3 - 1) + 0] = 10.0;  // 4*(n-1)+pingPong where n=3
                                                                                                                                                                                                
                                                                                                                                                                                                workField.set(eigen, work);
                                                                                                                                                                                                pingPongField.setInt(eigen, 0);  // set pingPong to 0
                                                                                                                                                                                                
                                                                                                                                                                                                // The condition 1.5*work[0] < work[8] => 1.5 < 10 is true
                                                                                                                                                                                                // So flip should occur
                                                                                                                                                                                                
                                                                                                                                                                                                // Get the private method using reflection
                                                                                                                                                                                                Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                flipMethod.setAccessible(true);
                                                                                                                                                                                                
                                                                                                                                                                                                // Test with step=1 to ensure we hit the boundary condition
                                                                                                                                                                                                boolean result = (boolean) flipMethod.invoke(eigen, 3, 1);
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify
                                                                                                                                                                                                assertTrue(result);  // flip should have occurred
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify array contents were properly flipped
                                                                                                                                                                                                // Original array would have successfully flipped elements
                                                                                                                                                                                                // Mutant would throw ArrayIndexOutOfBoundsException
                                                                                                                                                                                                
                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                fail("Test setup failed: " + e.getMessage());
                                                                                                                                                                                            }
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                   public void testFlipIfWarranted_DetectsStepMutation() {
                                                                                                                                                                                       // Setup
                                                                                                                                                                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                                       
                                                                                                                                                                                       // Use reflection to access private fields and methods since we need to test them
                                                                                                                                                                                       try {
                                                                                                                                                                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                           workField.setAccessible(true);
                                                                                                                                                                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                           pingPongField.setAccessible(true);
                                                                                                                                                                                           
                                                                                                                                                                                           // Get the private method we want to test
                                                                                                                                                                                           Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                           flipMethod.setAccessible(true);
                                                                                                                                                                                           
                                                                                                                                                                                           // Create a work array that will trigger the flip (1.5 * work[pingPong] < work[4*(n-1)+pingPong])
                                                                                                                                                                                           double[] work = new double[20];
                                                                                                                                                                                           work[0] = 1.0;  // pingPong position
                                                                                                                                                                                           work[16] = 2.0; // 4*(5-1)+0 = 16 (assuming n=5)
                                                                                                                                                                                           workField.set(eigen, work);
                                                                                                                                                                                           pingPongField.setInt(eigen, 0); // set pingPong to 0
                                                                                                                                                                                           
                                                                                                                                                                                           // Set step > 1 to make the mutation detectable
                                                                                                                                                                                           int n = 5;
                                                                                                                                                                                           int step = 2;
                                                                                                                                                                                           
                                                                                                                                                                                           // Fill the array with known values to verify flipping pattern
                                                                                                                                                                                           for (int i = 0; i < work.length; i++) {
                                                                                                                                                                                               work[i] = i; // fill with indices for easy verification
                                                                                                                                                                                           }
                                                                                                                                                                                           
                                                                                                                                                                                           // Act - call the method via reflection
                                                                                                                                                                                           boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                                                                           
                                                                                                                                                                                           // Assert
                                                                                                                                                                                           assertTrue("Flip should have occurred", result);
                                                                                                                                                                                           
                                                                                                                                                                                           // Verify the flipping pattern - with step=2, only even indices should be flipped
                                                                                                                                                                                           // Original array before flip: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]
                                                                                                                                                                                           // After flip with step=2, the even indices should be reversed in blocks of 4
                                                                                                                                                                                           // Expected after flip: [16,1,12,3,8,5,4,7,0,9,10,11,12,13,14,15,0,17,4,19]
                                                                                                                                                                                           assertEquals(16.0, work[0], 0.0001); // first element flipped
                                                                                                                                                                                           assertEquals(1.0, work[1], 0.0001);   // odd index unchanged
                                                                                                                                                                                           assertEquals(12.0, work[2], 0.0001);  // even index flipped
                                                                                                                                                                                           assertEquals(3.0, work[3], 0.0001);   // odd index unchanged
                                                                                                                                                                                           assertEquals(8.0, work[4], 0.0001);   // even index flipped
                                                                                                                                                                                           assertEquals(5.0, work[5], 0.0001);   // odd index unchanged
                                                                                                                                                                                           
                                                                                                                                                                                           // The mutant with k+=1 would flip ALL elements, not just every step-th one
                                                                                                                                                                                           // So this test would fail on the mutant because odd indices would also be flipped
                                                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                                                           fail("Exception during test: " + e.getMessage());
                                                                                                                                                                                       }
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                              public void testFlipIfWarrantedDetectsArrayAccessMutant() throws Exception {
                                                                                                                                                                                  // Setup test data
                                                                                                                                                                                  int n = 3;  // This makes j = 4*(3-1) = 8 in the method
                                                                                                                                                                                  int step = 1;
                                                                                                                                                                                  int pingPong = 0;
                                                                                                                                                                                  
                                                                                                                                                                                  // Create work array with values that will trigger the flip
                                                                                                                                                                                  // The condition is: 1.5 * work[0] < work[8]
                                                                                                                                                                                  // Let's set work[0] = 1.0, so work[8] needs to be > 1.5
                                                                                                                                                                                  double[] work = new double[20];  // Large enough to avoid index issues
                                                                                                                                                                                  work[0] = 1.0;  // work[pingPong]
                                                                                                                                                                                  work[8] = 2.0;  // work[4*(n-1) + pingPong]
                                                                                                                                                                                  
                                                                                                                                                                                  // Fill the array with distinct values that will show if swapping is correct
                                                                                                                                                                                  for (int i = 0; i < work.length; i++) {
                                                                                                                                                                                      work[i] = i;  // Each element equals its index
                                                                                                                                                                                  }
                                                                                                                                                                                  
                                                                                                                                                                                  // Create instance
                                                                                                                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                                  
                                                                                                                                                                                  // Use reflection to set private fields
                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                  workField.set(eigen, work);
                                                                                                                                                                                  
                                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                  pingPongField.set(eigen, pingPong);
                                                                                                                                                                                  
                                                                                                                                                                                  // Expected array after correct flipping
                                                                                                                                                                                  double[] expectedWork = work.clone();
                                                                                                                                                                                  // Correct swapping should happen in blocks of 4:
                                                                                                                                                                                  // i=0, j=8: swap elements 0-3 with 8-5
                                                                                                                                                                                  // i=4, j=4: swap elements 4-7 with 4-1 (but j <= i so loop ends)
                                                                                                                                                                                  expectedWork[0] = 8.0;  // work[8]
                                                                                                                                                                                  expectedWork[1] = 7.0;  // work[7]
                                                                                                                                                                                  expectedWork[2] = 6.0;  // work[6]
                                                                                                                                                                                  expectedWork[3] = 5.0;  // work[5]
                                                                                                                                                                                  expectedWork[5] = 3.0;  // work[3]
                                                                                                                                                                                  expectedWork[6] = 2.0;  // work[2]
                                                                                                                                                                                  expectedWork[7] = 1.0;  // work[1]
                                                                                                                                                                                  expectedWork[8] = 0.0;  // work[0]
                                                                                                                                                                                  
                                                                                                                                                                                  // Use reflection to invoke private method
                                                                                                                                                                                  Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                  flipMethod.setAccessible(true);
                                                                                                                                                                                  boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                                                                  
                                                                                                                                                                                  // Verify
                                                                                                                                                                                  assertTrue("Method should return true when flip occurs", result);
                                                                                                                                                                                  assertArrayEquals("Work array should be correctly flipped", expectedWork, work, 0.0);
                                                                                                                                                                                  
                                                                                                                                                                                  // The mutant would try to access work[0-1], work[0-2], etc. which would either:
                                                                                                                                                                                  // 1. Throw ArrayIndexOutOfBoundsException (if not caught)
                                                                                                                                                                                  // 2. Produce wrong array contents if negative indices are allowed
                                                                                                                                                                                  // Our assertion would fail in either case
                                                                                                                                                                              }

    @Test
                                                                                                                                                                         public void testFlipIfWarrantedDetectsArrayFlipMutation() throws Exception {
                                                                                                                                                                             // Setup test data
                                                                                                                                                                             int n = 3;  // This will create j = 4*(3-1) = 8
                                                                                                                                                                             int step = 1;
                                                                                                                                                                             int pingPong = 0;
                                                                                                                                                                             
                                                                                                                                                                             // Create a work array where the flip condition will be true
                                                                                                                                                                             // We need 1.5 * work[0] < work[8], so set work[0]=2, work[8]=4
                                                                                                                                                                             double[] work = new double[12];  // Need at least 9 elements (4*(3-1)+0+1)
                                                                                                                                                                             work[0] = 2.0;
                                                                                                                                                                             work[4] = 1.0;
                                                                                                                                                                             work[8] = 4.0;
                                                                                                                                                                             
                                                                                                                                                                             // Fill the array with distinct values to detect incorrect swaps
                                                                                                                                                                             for (int i = 1; i < 8; i++) {
                                                                                                                                                                                 work[i] = i * 10.0;  // 10, 20, 30, etc.
                                                                                                                                                                             }
                                                                                                                                                                             
                                                                                                                                                                             // Create instance
                                                                                                                                                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                             
                                                                                                                                                                             // Use reflection to set private fields
                                                                                                                                                                             Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                             workField.setAccessible(true);
                                                                                                                                                                             workField.set(eigen, work);
                                                                                                                                                                             
                                                                                                                                                                             Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                             pingPongField.setAccessible(true);
                                                                                                                                                                             pingPongField.set(eigen, pingPong);
                                                                                                                                                                             
                                                                                                                                                                             // Use reflection to call private method
                                                                                                                                                                             Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                             flipMethod.setAccessible(true);
                                                                                                                                                                             boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                                                             
                                                                                                                                                                             // Verify the flip occurred
                                                                                                                                                                             assertTrue(result);
                                                                                                                                                                             
                                                                                                                                                                             // Verify the array was flipped correctly
                                                                                                                                                                             // Original should be: [2,10,20,30,1,50,60,70,4,...]
                                                                                                                                                                             // After flip (swapping blocks of 4):
                                                                                                                                                                             // work[0] should swap with work[8]
                                                                                                                                                                             // work[1] should swap with work[7]
                                                                                                                                                                             // work[2] should swap with work[6]
                                                                                                                                                                             // work[3] should swap with work[5]
                                                                                                                                                                             assertEquals(4.0, work[0], 0.0001);  // work[0] should now be original work[8]
                                                                                                                                                                             assertEquals(70.0, work[1], 0.0001); // work[1] should now be original work[7]
                                                                                                                                                                             assertEquals(60.0, work[2], 0.0001); // work[2] should now be original work[6]
                                                                                                                                                                             assertEquals(50.0, work[3], 0.0001); // work[3] should now be original work[5]
                                                                                                                                                                             assertEquals(1.0, work[4], 0.0001);  // work[4] remains unchanged
                                                                                                                                                                         }

    @Test
                                                                                                                                                                    public void testFlipIfWarrantedDetectsMutant2() throws Exception {
                                                                                                                                                                        // Setup test data
                                                                                                                                                                        EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                        
                                                                                                                                                                        // Set up work array with known values that will trigger the flip
                                                                                                                                                                        // n=2 means j will be 4*(2-1)=4, so we need at least 8 elements (0-7)
                                                                                                                                                                        double[] work = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0};
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to set private fields
                                                                                                                                                                        Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                        workField.setAccessible(true);
                                                                                                                                                                        workField.set(decomposition, work);
                                                                                                                                                                        
                                                                                                                                                                        Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                        pingPongField.setAccessible(true);
                                                                                                                                                                        pingPongField.setInt(decomposition, 0); // using first element for comparison
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to invoke private method
                                                                                                                                                                        Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                        flipMethod.setAccessible(true);
                                                                                                                                                                        boolean result = (boolean) flipMethod.invoke(decomposition, 2, 1);
                                                                                                                                                                        
                                                                                                                                                                        // Verify the flip occurred
                                                                                                                                                                        assertTrue(result);
                                                                                                                                                                        
                                                                                                                                                                        // Verify the swapping was done correctly (not mutated to 0.0)
                                                                                                                                                                        // Original positions and expected values after flip:
                                                                                                                                                                        // [0,1,2,3] should swap with [4,5,6,7]
                                                                                                                                                                        assertEquals(5.0, work[0], 0.0001); // first element should be from position 4
                                                                                                                                                                        assertEquals(8.0, work[3], 0.0001); // last in first block should be from position 7
                                                                                                                                                                        assertEquals(1.0, work[4], 0.0001); // first in second block should be from position 0
                                                                                                                                                                        assertEquals(4.0, work[7], 0.0001); // last in second block should be from position 3
                                                                                                                                                                        
                                                                                                                                                                        // The mutant would have set work[4], work[5], work[6], work[7] to 0.0
                                                                                                                                                                        // So these assertions would fail if the mutant is present
                                                                                                                                                                        assertNotEquals(0.0, work[4], 0.0001);
                                                                                                                                                                        assertNotEquals(0.0, work[5], 0.0001);
                                                                                                                                                                        assertNotEquals(0.0, work[6], 0.0001);
                                                                                                                                                                        assertNotEquals(0.0, work[7], 0.0001);
                                                                                                                                                                    }

    @Test
                                                                                                                                                               public void testFlipIfWarrantedDetectsMutant3() throws Exception {
                                                                                                                                                                   // Setup test data that will trigger the flip condition
                                                                                                                                                                   int n = 3; // For j = 4*(3-1) = 8
                                                                                                                                                                   int step = 1;
                                                                                                                                                                   int pingPong = 0;
                                                                                                                                                                   double[] work = new double[20]; // Large enough array
                                                                                                                                                                   
                                                                                                                                                                   // Set values to satisfy flip condition: 1.5*work[0] < work[8]
                                                                                                                                                                   work[pingPong] = 10.0;    // work[0] = 10
                                                                                                                                                                   work[4 * (n - 1) + pingPong] = 20.0; // work[8] = 20 (1.5*10 < 20)
                                                                                                                                                                   
                                                                                                                                                                   // Fill array with distinct values to verify flipping
                                                                                                                                                                   for (int i = 0; i < work.length; i++) {
                                                                                                                                                                       work[i] = i;
                                                                                                                                                                   }
                                                                                                                                                                   
                                                                                                                                                                   // Create instance and set required fields using reflection
                                                                                                                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                   
                                                                                                                                                                   // Set private work field using reflection
                                                                                                                                                                   Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                   workField.setAccessible(true);
                                                                                                                                                                   workField.set(eigen, work);
                                                                                                                                                                   
                                                                                                                                                                   // Set private pingPong field using reflection
                                                                                                                                                                   Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                   pingPongField.setAccessible(true);
                                                                                                                                                                   pingPongField.set(eigen, pingPong);
                                                                                                                                                                   
                                                                                                                                                                   // Get private flipIfWarranted method using reflection
                                                                                                                                                                   Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                   flipMethod.setAccessible(true);
                                                                                                                                                                   
                                                                                                                                                                   // Test the method using reflection
                                                                                                                                                                   boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                                                   
                                                                                                                                                                   // Verify the flip was performed correctly
                                                                                                                                                                   assertTrue(result); // Method should return true
                                                                                                                                                                   
                                                                                                                                                                   // Verify the array was flipped correctly
                                                                                                                                                                   // Original should have: work[0] ↔ work[8], work[1] ↔ work[7], etc.
                                                                                                                                                                   // Then next block: work[4] ↔ work[4] (middle)
                                                                                                                                                                   assertEquals(8.0, work[0], 0.0001);  // Originally work[8]
                                                                                                                                                                   assertEquals(7.0, work[1], 0.0001);  // Originally work[7]
                                                                                                                                                                   assertEquals(6.0, work[2], 0.0001);  // Originally work[6]
                                                                                                                                                                   assertEquals(5.0, work[3], 0.0001);  // Originally work[5]
                                                                                                                                                                   assertEquals(4.0, work[4], 0.0001);  // Middle stays same
                                                                                                                                                                   assertEquals(3.0, work[5], 0.0001);  // Originally work[3]
                                                                                                                                                                   assertEquals(2.0, work[6], 0.0001);  // Originally work[2]
                                                                                                                                                                   assertEquals(1.0, work[7], 0.0001);  // Originally work[1]
                                                                                                                                                                   assertEquals(0.0, work[8], 0.0001);  // Originally work[0]
                                                                                                                                                                   
                                                                                                                                                                   // The mutant with j += 4 would either:
                                                                                                                                                                   // 1. Not swap correctly (these assertions would fail)
                                                                                                                                                                   // 2. Throw ArrayIndexOutOfBoundsException
                                                                                                                                                                   // 3. Loop infinitely (test would timeout)
                                                                                                                                                               }

    @Test
                                                                                                                                                          public void testFlipIfWarrantedDetectsJDecrementMutant() {
                                                                                                                                                              // Setup
                                                                                                                                                              EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                              
                                                                                                                                                              // Create a work array that will trigger the flip condition
                                                                                                                                                              // Use reflection to set private fields since we need specific values
                                                                                                                                                              try {
                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                  
                                                                                                                                                                  // n=3 means we'll have 4*(3-1) = 8 elements to consider
                                                                                                                                                                  // Create array where flip condition is true (1.5*work[0] < work[8])
                                                                                                                                                                  double[] work = new double[20]; // Large enough to avoid index issues
                                                                                                                                                                  work[0] = 10.0;  // pingPong position
                                                                                                                                                                  work[8] = 20.0;   // 1.5*10 < 20 → true
                                                                                                                                                                  // Fill with distinct values to track swapping
                                                                                                                                                                  for (int i = 0; i < 8; i++) {
                                                                                                                                                                      work[i] = i + 1; // 1,2,3,4,5,6,7,8
                                                                                                                                                                  }
                                                                                                                                                                  
                                                                                                                                                                  workField.set(eigen, work);
                                                                                                                                                                  pingPongField.setInt(eigen, 0); // pingPong = 0
                                                                                                                                                                  
                                                                                                                                                                  // Get and invoke the private method
                                                                                                                                                                  Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                  flipMethod.setAccessible(true);
                                                                                                                                                                  boolean result = (boolean) flipMethod.invoke(eigen, 3, 1); // n=3, step=1
                                                                                                                                                                  
                                                                                                                                                                  // Verify
                                                                                                                                                                  assertTrue(result); // flip should occur
                                                                                                                                                                  
                                                                                                                                                                  // Check exact positions after flip
                                                                                                                                                                  // Original should be: [1,2,3,4,5,6,7,8,...]
                                                                                                                                                                  // Correct flip (j-=4) should produce: [8,7,6,5,4,3,2,1,...]
                                                                                                                                                                  // Mutated flip (j-=2) would produce something else
                                                                                                                                                                  double[] expected = {8.0, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0};
                                                                                                                                                                  for (int i = 0; i < 8; i++) {
                                                                                                                                                                      assertEquals("Element at position " + i + " incorrect", 
                                                                                                                                                                                  expected[i], work[i], 0.0001);
                                                                                                                                                                  }
                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                  fail("Reflection failed: " + e.getMessage());
                                                                                                                                                              }
                                                                                                                                                          }

    @Test
                                                                                                                                                     public void testFlipIfWarranted_ShouldReturnTrueWhenFlipOccurs() {
                                                                                                                                                         // Setup
                                                                                                                                                         EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                                                                                         
                                                                                                                                                         // Create a work array that will trigger the flip condition
                                                                                                                                                         // We need 1.5 * work[pingPong] < work[4*(n-1)+pingPong]
                                                                                                                                                         // Let's set pingPong to 0 and n=2 (so 4*(2-1)+0 = 4)
                                                                                                                                                         // Set work[0] = 1.0, work[4] = 2.0 (1.5*1 < 2 is true)
                                                                                                                                                         double[] work = new double[8]; // Need at least 5 elements (0-4)
                                                                                                                                                         work[0] = 1.0;
                                                                                                                                                         work[4] = 2.0;
                                                                                                                                                         
                                                                                                                                                         // Use reflection to set private fields and invoke private method
                                                                                                                                                         try {
                                                                                                                                                             Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                             workField.setAccessible(true);
                                                                                                                                                             workField.set(eigen, work);
                                                                                                                                                             
                                                                                                                                                             Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                             pingPongField.setAccessible(true);
                                                                                                                                                             pingPongField.set(eigen, 0);
                                                                                                                                                             
                                                                                                                                                             // Get and invoke the private method
                                                                                                                                                             Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                             flipMethod.setAccessible(true);
                                                                                                                                                             boolean result = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
                                                                                                                                                             
                                                                                                                                                             // Verify
                                                                                                                                                             assertTrue("Method should return true when flip occurs", result);
                                                                                                                                                             
                                                                                                                                                             // Verify array was actually flipped
                                                                                                                                                             // Original positions: work[0] and work[4] would be swapped
                                                                                                                                                             assertEquals(2.0, work[0], 0.0001);
                                                                                                                                                             assertEquals(1.0, work[4], 0.0001);
                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                             fail("Failed to access private fields or method: " + e.getMessage());
                                                                                                                                                         }
                                                                                                                                                     }

    @Test
                                                                                                                                                public void testFlipIfWarranted_ShouldReturnFalseWhenConditionNotMet() {
                                                                                                                                                    // Setup
                                                                                                                                                    EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to set private fields since they're not accessible directly
                                                                                                                                                    try {
                                                                                                                                                        Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                        workField.setAccessible(true);
                                                                                                                                                        double[] work = new double[100]; // Large enough array
                                                                                                                                                        work[0] = 10.0; // pingPong will be 0
                                                                                                                                                        work[4 * (5 - 1)] = 5.0; // 1.5 * 10 = 15 which is > 5
                                                                                                                                                        workField.set(eigen, work);
                                                                                                                                                        
                                                                                                                                                        Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                        pingPongField.setAccessible(true);
                                                                                                                                                        pingPongField.set(eigen, 0);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                        Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                        flipMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Test - condition is false (15 < 5 is false)
                                                                                                                                                        boolean result = (boolean) flipMethod.invoke(eigen, 5, 1);
                                                                                                                                                        
                                                                                                                                                        // Verify - should return false when condition not met
                                                                                                                                                        assertFalse("Method should return false when flip condition is not met", result);
                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                        fail("Failed to set up test due to reflection issues: " + e.getMessage());
                                                                                                                                                    }
                                                                                                                                                }

    @Test
                                                                                                                                       public void testFlipIfWarranted_ShouldNotFlipWhenValuesAreEqual1() {
                                                                                                                                           // Setup
                                                                                                                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                           
                                                                                                                                           // Use reflection to access private fields and methods
                                                                                                                                           try {
                                                                                                                                               Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                               workField.setAccessible(true);
                                                                                                                                               Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                               pingPongField.setAccessible(true);
                                                                                                                                               
                                                                                                                                               // Get the flipIfWarranted method
                                                                                                                                               Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                               flipMethod.setAccessible(true);
                                                                                                                                               
                                                                                                                                               // Create test case where 1.5*work[pingPong] equals work[4*(n-1)+pingPong]
                                                                                                                                               int n = 2;  // So 4*(n-1) = 4
                                                                                                                                               int pingPong = 0;
                                                                                                                                               double[] work = new double[10];
                                                                                                                                               work[pingPong] = 2.0;  // work[0] = 2.0
                                                                                                                                               work[4*(n-1) + pingPong] = 3.0;  // work[4] = 3.0 (since 1.5*2.0 = 3.0)
                                                                                                                                               
                                                                                                                                               workField.set(eigen, work);
                                                                                                                                               pingPongField.setInt(eigen, pingPong);
                                                                                                                                               
                                                                                                                                               // Make a copy to compare later
                                                                                                                                               double[] originalWork = work.clone();
                                                                                                                                               
                                                                                                                                               // Test
                                                                                                                                               boolean result = (boolean) flipMethod.invoke(eigen, n, 1);  // step=1
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertFalse("Method should return false when values are equal", result);
                                                                                                                                               assertArrayEquals("Work array should remain unchanged when values are equal", 
                                                                                                                                                                originalWork, work, 0.0);
                                                                                                                                           } catch (Exception e) {
                                                                                                                                               fail("Exception during test setup: " + e.getMessage());
                                                                                                                                           }
                                                                                                                                       }

    @Test
                                                                                                                                  public void testFlipIfWarrantedDetectsMutant4() {
                                                                                                                                      // Setup test data where work[4*(n-1) + pingPong] != work[4*n + pingPong]
                                                                                                                                      // and 1.5*work[pingPong] is between them
                                                                                                                                      int n = 2;  // Using n=2 so 4*(n-1)=4 and 4*n=8
                                                                                                                                      int step = 1;
                                                                                                                                      int pingPong = 0;
                                                                                                                                      
                                                                                                                                      // Create work array where:
                                                                                                                                      // work[pingPong] = 10
                                                                                                                                      // work[4*(n-1) + pingPong] = 20 (original checks this)
                                                                                                                                      // work[4*n + pingPong] = 16 (mutant checks this)
                                                                                                                                      // 1.5*work[pingPong] = 15 which is between 16 and 20
                                                                                                                                      double[] work = new double[20];
                                                                                                                                      work[pingPong] = 10;
                                                                                                                                      work[4*(n-1) + pingPong] = 20;  // Original checks this (20 > 15 → flip)
                                                                                                                                      work[4*n + pingPong] = 16;      // Mutant checks this (16 > 15 → no flip)
                                                                                                                                      
                                                                                                                                      // Set up the object under test
                                                                                                                                      EigenDecompositionImpl ed = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                      
                                                                                                                                      // Use reflection to set private fields since we can't access them directly
                                                                                                                                      try {
                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                          workField.setAccessible(true);
                                                                                                                                          workField.set(ed, work);
                                                                                                                                          
                                                                                                                                          Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                          pingPongField.setAccessible(true);
                                                                                                                                          pingPongField.setInt(ed, pingPong);
                                                                                                                                          
                                                                                                                                          // Get and invoke the private method
                                                                                                                                          Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                          flipMethod.setAccessible(true);
                                                                                                                                          boolean originalResult = (boolean) flipMethod.invoke(ed, n, step);
                                                                                                                                          assertTrue("Original method should return true", originalResult);
                                                                                                                                          
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          fail("Failed to set private fields or invoke private method via reflection: " + e.getMessage());
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      // Now test with the mutant (would return false)
                                                                                                                                      // We can't actually inject the mutant, but this test would catch it
                                                                                                                                      // because with these values, the mutant would behave differently
                                                                                                                                  }

    @Test
                                                                                                                              public void testFlipIfWarrantedDetectsMutant5() {
                                                                                                                                  // Setup
                                                                                                                                  EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                  
                                                                                                                                  // Use reflection to set private fields since we're testing a private method
                                                                                                                                  try {
                                                                                                                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                      workField.setAccessible(true);
                                                                                                                                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                      pingPongField.setAccessible(true);
                                                                                                                                      
                                                                                                                                      // Create a work array that will trigger the flip condition
                                                                                                                                      // For n=2, original j=4*(2-1)=4, mutated j=4*2=8
                                                                                                                                      double[] work = new double[20]; // Large enough for indices
                                                                                                                                      work[0] = 10; // pingPong=0, so work[0] is used in condition
                                                                                                                                      work[4] = 1;  // 1.5*10 > 1, so condition is true
                                                                                                                                      
                                                                                                                                      // Set some distinct values to verify swapping
                                                                                                                                      work[0] = 1.0; work[1] = 2.0; work[2] = 3.0; work[3] = 4.0; // First block
                                                                                                                                      work[4] = 5.0; work[5] = 6.0; work[6] = 7.0; work[7] = 8.0; // Second block
                                                                                                                                      
                                                                                                                                      workField.set(decomposition, work);
                                                                                                                                      pingPongField.setInt(decomposition, 0);
                                                                                                                                      
                                                                                                                                      // Test with n=2, step=1
                                                                                                                                      Method flipIfWarranted = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                      flipIfWarranted.setAccessible(true);
                                                                                                                                      boolean result = (boolean) flipIfWarranted.invoke(decomposition, 2, 1);
                                                                                                                                      
                                                                                                                                      // Verify
                                                                                                                                      assertTrue("Method should return true when flip occurs", result);
                                                                                                                                      
                                                                                                                                      // Check array was properly flipped (original behavior)
                                                                                                                                      // Original would swap blocks at indices 0-3 and 4-7
                                                                                                                                      assertEquals(5.0, work[0], 0.0001);
                                                                                                                                      assertEquals(6.0, work[1], 0.0001);
                                                                                                                                      assertEquals(7.0, work[2], 0.0001);
                                                                                                                                      assertEquals(8.0, work[3], 0.0001);
                                                                                                                                      assertEquals(1.0, work[4], 0.0001);
                                                                                                                                      assertEquals(2.0, work[5], 0.0001);
                                                                                                                                      assertEquals(3.0, work[6], 0.0001);
                                                                                                                                      assertEquals(4.0, work[7], 0.0001);
                                                                                                                                      
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                  }
                                                                                                                              }

    @Test
                                                                                                                            public void testFlipIfWarranted_CatchesLoopConditionMutant() throws Exception {
                                                                                                                                // Setup test data where flip condition is true and j is divisible by 4
                                                                                                                                // This will make i equal j at some point in the loop
                                                                                                                                int n = 3;  // j = 4*(3-1) = 8
                                                                                                                                int step = 1;
                                                                                                                                int pingPong = 0;
                                                                                                                                
                                                                                                                                // Create work array where flip condition is true (1.5*work[0] < work[8])
                                                                                                                                double[] work = new double[20];  // Large enough to avoid index issues
                                                                                                                                work[pingPong] = 1.0;           // work[0] = 1.0
                                                                                                                                work[4 * (n - 1) + pingPong] = 2.0;  // work[8] = 2.0 (1.5*1 < 2 is true)
                                                                                                                                
                                                                                                                                // Fill array with distinct values to detect swapping
                                                                                                                                for (int i = 0; i < work.length; i++) {
                                                                                                                                    work[i] = i;
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Create instance and set required fields using reflection
                                                                                                                                EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                
                                                                                                                                // Set private work field
                                                                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                workField.setAccessible(true);
                                                                                                                                workField.set(eigen, work);
                                                                                                                                
                                                                                                                                // Set private pingPong field
                                                                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                pingPongField.setAccessible(true);
                                                                                                                                pingPongField.set(eigen, pingPong);
                                                                                                                                
                                                                                                                                // Get private flipIfWarranted method
                                                                                                                                Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                flipMethod.setAccessible(true);
                                                                                                                                
                                                                                                                                // Execute the method
                                                                                                                                boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                
                                                                                                                                // Verify the flip occurred
                                                                                                                                assertTrue(result);
                                                                                                                                
                                                                                                                                // Verify the array was flipped correctly (original behavior)
                                                                                                                                // The mutation would cause an extra swap when i=j=4
                                                                                                                                // Check specific positions that would be affected by the extra swap
                                                                                                                                assertEquals(8.0, work[0], 0.0001);  // First element should be swapped with last
                                                                                                                                assertEquals(0.0, work[8], 0.0001);  // Last element should be swapped with first
                                                                                                                                
                                                                                                                                // Check middle elements that would be affected by the extra swap in mutant
                                                                                                                                // Original would stop before i=4, mutant would do one more swap
                                                                                                                                assertEquals(4.0, work[4], 0.0001);  // Should remain unchanged in original
                                                                                                                                assertEquals(5.0, work[3], 0.0001);  // Adjacent element should be swapped
                                                                                                                                assertEquals(3.0, work[5], 0.0001);  // Adjacent element should be swapped
                                                                                                                            }

    @Test
                                                                                                                       public void testFlipIfWarrantedDetectsIncrementMutation1() throws Exception {
                                                                                                                           // Setup test data that will show difference between i+=4 and i+=2
                                                                                                                           int n = 3; // creates j = 4*(3-1) = 8
                                                                                                                           int step = 1; // inner loop will process all 4 elements
                                                                                                                           double[] work = new double[4 * (n - 1) + 2]; // size = 10
                                                                                                                           work[0] = 10; work[1] = 20; work[2] = 30; work[3] = 40;
                                                                                                                           work[4] = 50; work[5] = 60; work[6] = 70; work[7] = 80;
                                                                                                                           work[8] = 90; work[9] = 100;
                                                                                                                           
                                                                                                                           // Set condition to be true (1.5*work[pingPong] < work[8 + pingPong])
                                                                                                                           int pingPong = 0;
                                                                                                                           work[pingPong] = 10; // 1.5*10 = 15
                                                                                                                           work[8 + pingPong] = 20; // 20 > 15
                                                                                                                           
                                                                                                                           // Create instance and set required fields using reflection
                                                                                                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                           
                                                                                                                           // Set private work field
                                                                                                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                           workField.setAccessible(true);
                                                                                                                           workField.set(eigen, work);
                                                                                                                           
                                                                                                                           // Set private pingPong field
                                                                                                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                           pingPongField.setAccessible(true);
                                                                                                                           pingPongField.set(eigen, pingPong);
                                                                                                                           
                                                                                                                           // Get private flipIfWarranted method
                                                                                                                           Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                           flipMethod.setAccessible(true);
                                                                                                                           
                                                                                                                           // Execute method
                                                                                                                           boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                           
                                                                                                                           // Verify flipping occurred
                                                                                                                           assertTrue(result);
                                                                                                                           
                                                                                                                           // Verify exact array state after flipping
                                                                                                                           // Original (i+=4) would flip:
                                                                                                                           // - First iteration (i=0, j=8): swap 0-3 with 8-5
                                                                                                                           // - Second iteration (i=4, j=4): no swap (i < j fails)
                                                                                                                           // Mutant (i+=2) would do additional flips at i=2,6
                                                                                                                           double[] expectedOriginal = {
                                                                                                                               90, 80, 70, 60, // flipped from positions 8-5
                                                                                                                               50, 60, 70, 80, // original (not flipped)
                                                                                                                               10, 20, 30, 40  // flipped from positions 0-3
                                                                                                                           };
                                                                                                                           
                                                                                                                           // Verify the array wasn't over-processed by mutant
                                                                                                                           // Check first 4 elements were properly flipped
                                                                                                                           assertEquals(90.0, work[0], 0.0001);
                                                                                                                           assertEquals(80.0, work[1], 0.0001);
                                                                                                                           assertEquals(70.0, work[2], 0.0001);
                                                                                                                           assertEquals(60.0, work[3], 0.0001);
                                                                                                                           // Check middle elements weren't flipped
                                                                                                                           assertEquals(50.0, work[4], 0.0001);
                                                                                                                           assertEquals(60.0, work[5], 0.0001);
                                                                                                                           assertEquals(70.0, work[6], 0.0001);
                                                                                                                           assertEquals(80.0, work[7], 0.0001);
                                                                                                                           // Check last 2 elements were properly flipped
                                                                                                                           assertEquals(10.0, work[8], 0.0001);
                                                                                                                           assertEquals(20.0, work[9], 0.0001);
                                                                                                                       }

    @Test
                                                                                                                  public void testFlipIfWarranted_DetectsMutatedLoopCondition() {
                                                                                                                      // Setup test data that will trigger the flip condition
                                                                                                                      EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                                                      
                                                                                                                      // Use reflection to set private fields since we need specific values
                                                                                                                      try {
                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                          workField.setAccessible(true);
                                                                                                                          double[] work = new double[8]; // Small enough to trigger boundary condition
                                                                                                                          work[0] = 10; work[1] = 10; work[2] = 10; work[3] = 10; // First block
                                                                                                                          work[4] = 1;  work[5] = 1;  work[6] = 1;  work[7] = 1;  // Second block
                                                                                                                          workField.set(eigen, work);
                                                                                                                          
                                                                                                                          Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                          pingPongField.setAccessible(true);
                                                                                                                          pingPongField.setInt(eigen, 0); // Set pingPong to 0
                                                                                                                          
                                                                                                                          // The condition 1.5*work[0] < work[4] will be true (15 < 1 is false, but adjust values as needed)
                                                                                                                          // Adjust values so the flip condition is true
                                                                                                                          work[0] = 1; work[4] = 2; // Now 1.5*1 < 2 is true
                                                                                                                          
                                                                                                                          // Get the private method via reflection
                                                                                                                          Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                          flipMethod.setAccessible(true);
                                                                                                                          
                                                                                                                          // Test with step=1 to ensure we hit all iterations
                                                                                                                          boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);
                                                                                                                          
                                                                                                                          // Verify the flip occurred and no exception was thrown
                                                                                                                          assertTrue(result);
                                                                                                                          
                                                                                                                          // Verify the array was properly flipped
                                                                                                                          double[] updatedWork = (double[]) workField.get(eigen);
                                                                                                                          // Original first block (index 0-3) should be swapped with last block (index 4-7)
                                                                                                                          assertEquals(2.0, updatedWork[0], 0.0001);
                                                                                                                          assertEquals(1.0, updatedWork[4], 0.0001);
                                                                                                                      } catch (Exception e) {
                                                                                                                          fail("Test failed with exception: " + e.getMessage());
                                                                                                                      }
                                                                                                                  }

    @Test
                                                                                                             public void testFlipIfWarrantedWithStepGreaterThanOne() throws Exception {
                                                                                                                 // Setup
                                                                                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1}, new double[]{1}, 0.0);
                                                                                                                 
                                                                                                                 // Create a work array where the flip condition will be true
                                                                                                                 // pingPong = 0, n = 2 (so j = 4*(2-1) = 4)
                                                                                                                 // Condition: 1.5*work[0] < work[4*(2-1)+0] => 1.5*1 < 5 => true
                                                                                                                 double[] work = {1, 2, 3, 4, 5, 6, 7, 8, 9};
                                                                                                                 
                                                                                                                 // Use reflection to set private fields
                                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                 workField.setAccessible(true);
                                                                                                                 workField.set(eigen, work);
                                                                                                                 
                                                                                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                 pingPongField.setInt(eigen, 0);
                                                                                                                 
                                                                                                                 // Set step to 2 to make the difference visible
                                                                                                                 int step = 2;
                                                                                                                 int n = 2;
                                                                                                                 
                                                                                                                 // Use reflection to invoke private method
                                                                                                                 Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                 flipMethod.setAccessible(true);
                                                                                                                 boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                 
                                                                                                                 // Verify
                                                                                                                 assertTrue(result); // Should have flipped
                                                                                                                 
                                                                                                                 // In original code with step=2, only elements at positions 0 and 2 would be swapped in each block
                                                                                                                 // In mutated code (step=1), elements at 0,1,2,3 would all be swapped
                                                                                                                 // Verify only every other element was swapped (original behavior)
                                                                                                                 assertEquals(5.0, work[0], 0.0001); // First element should be swapped
                                                                                                                 assertEquals(2.0, work[1], 0.0001); // Second element should NOT be swapped (step=2)
                                                                                                                 assertEquals(7.0, work[2], 0.0001); // Third element should be swapped
                                                                                                                 assertEquals(4.0, work[3], 0.0001); // Fourth element should NOT be swapped
                                                                                                                 assertEquals(1.0, work[4], 0.0001); // First element from end should be swapped
                                                                                                                 assertEquals(6.0, work[5], 0.0001); // Second from end should NOT be swapped
                                                                                                                 assertEquals(3.0, work[6], 0.0001); // Third from end should be swapped
                                                                                                                 assertEquals(8.0, work[7], 0.0001); // Fourth from end should NOT be swapped
                                                                                                             }

    @Test
                                                                                                        public void testFlipIfWarrantedDetectsArrayAccessMutant1() throws Exception {
                                                                                                            // Setup test data where flip condition is true
                                                                                                            int n = 3;  // For 4*(n-1) = 8 elements to process
                                                                                                            int step = 1;
                                                                                                            int pingPong = 0;
                                                                                                            
                                                                                                            // Create work array where flip condition is true
                                                                                                            // work[0] = 1.0, work[8] = 2.0 -> 1.5*1.0 < 2.0 -> true
                                                                                                            double[] work = new double[20];  // Large enough to avoid bounds issues
                                                                                                            work[pingPong] = 1.0;
                                                                                                            work[4 * (n - 1) + pingPong] = 2.0;
                                                                                                            
                                                                                                            // Fill array with distinct values that will reveal incorrect access
                                                                                                            for (int i = 0; i < 8; i += 4) {
                                                                                                                for (int k = 0; k < 4; k++) {
                                                                                                                    work[i + k] = 10 * i + k;  // Unique values for each position
                                                                                                                }
                                                                                                            }
                                                                                                            
                                                                                                            // Create test instance and set required fields using reflection
                                                                                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                            
                                                                                                            // Set private work field
                                                                                                            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                            workField.setAccessible(true);
                                                                                                            workField.set(eigen, work);
                                                                                                            
                                                                                                            // Set private pingPong field
                                                                                                            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                            pingPongField.setAccessible(true);
                                                                                                            pingPongField.set(eigen, pingPong);
                                                                                                            
                                                                                                            // Make a copy of original array for comparison
                                                                                                            double[] originalWork = work.clone();
                                                                                                            
                                                                                                            // Execute method using reflection
                                                                                                            Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                            flipMethod.setAccessible(true);
                                                                                                            boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                            
                                                                                                            // Verify results
                                                                                                            assertTrue("Flip should have occurred", result);
                                                                                                            
                                                                                                            // Verify array was flipped correctly
                                                                                                            // For original code, elements should be properly swapped
                                                                                                            // For mutant, i-k would access wrong indices and cause incorrect swaps
                                                                                                            for (int i = 0; i < 4; i++) {
                                                                                                                int j = 8 - i;
                                                                                                                assertEquals("Element at position " + i + " not properly swapped", 
                                                                                                                             originalWork[j], work[i], 0.0001);
                                                                                                                assertEquals("Element at position " + j + " not properly swapped",
                                                                                                                             originalWork[i], work[j], 0.0001);
                                                                                                            }
                                                                                                            
                                                                                                            // Verify middle elements (if any) remain unchanged
                                                                                                            for (int i = 4; i < 4; i++) {
                                                                                                                assertEquals("Middle element at " + i + " changed unexpectedly",
                                                                                                                            originalWork[i], work[i], 0.0001);
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                   public void testFlipIfWarrantedDetectsMutant6() throws Exception {
                                                                                                       // Setup test data
                                                                                                       int n = 2; // Ensures the loop will execute (j = 4*(2-1) = 4)
                                                                                                       int step = 1;
                                                                                                       int pingPong = 0;
                                                                                                       
                                                                                                       // Create a work array where the flip condition is true
                                                                                                       // Original array: [0, 1, 2, 3, 4, 5, 6, 7]
                                                                                                       // After correct flip should be: [7, 6, 5, 4, 3, 2, 1, 0]
                                                                                                       // With mutant, would become: [4, 5, 6, 7, 4, 5, 6, 7]
                                                                                                       double[] work = {0, 1, 2, 3, 4, 5, 6, 7};
                                                                                                       
                                                                                                       // Set condition to be true: 1.5*work[0] < work[4*(2-1)+0] => 0 < 4 => true
                                                                                                       assertTrue(1.5 * work[pingPong] < work[4 * (n - 1) + pingPong]);
                                                                                                       
                                                                                                       // Create instance
                                                                                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                       
                                                                                                       // Use reflection to set private fields
                                                                                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                       workField.setAccessible(true);
                                                                                                       workField.set(eigen, work);
                                                                                                       
                                                                                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                       pingPongField.setAccessible(true);
                                                                                                       pingPongField.set(eigen, pingPong);
                                                                                                       
                                                                                                       // Use reflection to invoke private method
                                                                                                       Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                       flipMethod.setAccessible(true);
                                                                                                       boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                       
                                                                                                       // Verify the array was flipped correctly
                                                                                                       assertTrue(result); // Should have flipped
                                                                                                       // Check specific positions to detect the mutant
                                                                                                       assertEquals(7.0, work[0], 0.0001); // First element should be last
                                                                                                       assertEquals(6.0, work[1], 0.0001); // Second element should be second last
                                                                                                       assertEquals(5.0, work[2], 0.0001);
                                                                                                       assertEquals(4.0, work[3], 0.0001);
                                                                                                       assertEquals(3.0, work[4], 0.0001);
                                                                                                       assertEquals(2.0, work[5], 0.0001);
                                                                                                       assertEquals(1.0, work[6], 0.0001);
                                                                                                       assertEquals(0.0, work[7], 0.0001); // Last element should be first
                                                                                                       
                                                                                                       // The mutant would fail these assertions because it would copy from wrong positions
                                                                                                   }

    @Test
                                                                                              public void testFlipIfWarrantedDetectsZeroingMutant() throws Exception {
                                                                                                  // Setup test data that will trigger the flip condition
                                                                                                  int n = 3;  // For 4*(n-1) indexing
                                                                                                  int step = 1;
                                                                                                  int pingPong = 0;
                                                                                                  
                                                                                                  // Create a work array where the flip condition will be true
                                                                                                  // work[4*(n-1)+pingPong] = work[8] should be > 1.5*work[0]
                                                                                                  double[] work = new double[9];
                                                                                                  work[0] = 1.0;  // work[pingPong]
                                                                                                  work[8] = 2.0;   // 2.0 > 1.5*1.0 → condition true
                                                                                                  
                                                                                                  // Fill the array with distinct values we can verify
                                                                                                  for (int i = 1; i < 8; i++) {
                                                                                                      work[i] = i + 1.0;  // Values 2.0 through 8.0
                                                                                                  }
                                                                                                  
                                                                                                  // Create the test instance and set required fields using reflection
                                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                  
                                                                                                  // Set private work field
                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                  workField.setAccessible(true);
                                                                                                  workField.set(eigen, work);
                                                                                                  
                                                                                                  // Set private pingPong field
                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                  pingPongField.setAccessible(true);
                                                                                                  pingPongField.set(eigen, pingPong);
                                                                                                  
                                                                                                  // Get private flipIfWarranted method
                                                                                                  Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                  flipMethod.setAccessible(true);
                                                                                                  
                                                                                                  // Execute the method
                                                                                                  boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                  
                                                                                                  // Verify the flip occurred (return value)
                                                                                                  assertTrue(result);
                                                                                                  
                                                                                                  // Verify the array was properly flipped (not zeroed)
                                                                                                  // Original array: [1,2,3,4,5,6,7,8,2]
                                                                                                  // Expected after flip:
                                                                                                  // work[0] and work[8] stay same (condition values)
                                                                                                  // work[1] ↔ work[7]
                                                                                                  // work[2] ↔ work[6]
                                                                                                  // work[3] ↔ work[5]
                                                                                                  // work[4] stays same (middle element)
                                                                                                  assertEquals(1.0, work[0], 0.0001);
                                                                                                  assertEquals(8.0, work[1], 0.0001);  // Originally 2.0
                                                                                                  assertEquals(7.0, work[2], 0.0001);  // Originally 3.0
                                                                                                  assertEquals(6.0, work[3], 0.0001);  // Originally 4.0
                                                                                                  assertEquals(5.0, work[4], 0.0001);  // Middle stays same
                                                                                                  assertEquals(4.0, work[5], 0.0001);  // Originally 6.0
                                                                                                  assertEquals(3.0, work[6], 0.0001);  // Originally 7.0
                                                                                                  assertEquals(2.0, work[7], 0.0001);  // Originally 8.0
                                                                                                  assertEquals(2.0, work[8], 0.0001);
                                                                                                  
                                                                                                  // The mutant would zero out work[7], work[6], work[5] etc.
                                                                                                  // So any of these assertions would fail with the mutant
                                                                                              }

    @Test
                                                                                         public void testFlipIfWarrantedDetectsJIncrementMutant() {
                                                                                             // Setup test data
                                                                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                             
                                                                                             // Create a work array large enough for the test
                                                                                             // We need at least 8 elements (n=2) to trigger the flipping logic
                                                                                             double[] work = new double[12];
                                                                                             work[0] = 1.0;  // These values will be flipped
                                                                                             work[1] = 2.0;
                                                                                             work[2] = 3.0;
                                                                                             work[3] = 4.0;
                                                                                             work[4] = 5.0;  // These values will be flipped
                                                                                             work[5] = 6.0;
                                                                                             work[6] = 7.0;
                                                                                             work[7] = 8.0;
                                                                                             // Set condition to true (1.5 * work[0] < work[4])
                                                                                             work[0] = 1.0;
                                                                                             work[4] = 2.0;
                                                                                             
                                                                                             // Set required fields through reflection since they're private
                                                                                             try {
                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                 workField.setAccessible(true);
                                                                                                 workField.set(eigen, work);
                                                                                                 
                                                                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                 pingPongField.setAccessible(true);
                                                                                                 pingPongField.setInt(eigen, 0);  // Using index 0 for pingPong
                                                                                                 
                                                                                                 // Get and invoke the private method
                                                                                                 Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                 flipMethod.setAccessible(true);
                                                                                                 boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);  // n=2, step=1
                                                                                                 
                                                                                                 // Verify the array was correctly flipped
                                                                                                 assertTrue("Method should return true when flipping occurs", result);
                                                                                                 assertEquals("First element not flipped correctly", 5.0, work[0], 0.0001);
                                                                                                 assertEquals("Second element not flipped correctly", 6.0, work[1], 0.0001);
                                                                                                 assertEquals("Third element not flipped correctly", 7.0, work[2], 0.0001);
                                                                                                 assertEquals("Fourth element not flipped correctly", 8.0, work[3], 0.0001);
                                                                                                 assertEquals("Fifth element not flipped correctly", 1.0, work[4], 0.0001);
                                                                                                 assertEquals("Sixth element not flipped correctly", 2.0, work[5], 0.0001);
                                                                                                 assertEquals("Seventh element not flipped correctly", 3.0, work[6], 0.0001);
                                                                                                 assertEquals("Eighth element not flipped correctly", 4.0, work[7], 0.0001);
                                                                                             } catch (Exception e) {
                                                                                                 fail("Failed to set private fields or invoke private method via reflection: " + e.getMessage());
                                                                                             }
                                                                                         }

    @Test
                                                                                    public void testFlipIfWarrantedDetectsJDecrementMutant1() throws Exception {
                                                                                        // Setup
                                                                                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                        
                                                                                        // Create a work array that will trigger the flip condition
                                                                                        // Use distinct values that will reveal incorrect flipping
                                                                                        double[] work = new double[12]; // Enough for n=3 (4*(3-1)+4=12)
                                                                                        work[0] = 10;  // Will be swapped with work[8]
                                                                                        work[1] = 20;  // Will be swapped with work[9]
                                                                                        work[2] = 30;  // Will be swapped with work[10]
                                                                                        work[3] = 40;  // Will be swapped with work[11]
                                                                                        work[4] = 50;  // Middle elements shouldn't be touched
                                                                                        work[5] = 60;
                                                                                        work[6] = 70;
                                                                                        work[7] = 80;
                                                                                        work[8] = 1;   // Should end up at work[0]
                                                                                        work[9] = 2;   // Should end up at work[1]
                                                                                        work[10] = 3;  // Should end up at work[2]
                                                                                        work[11] = 4;  // Should end up at work[3]
                                                                                        
                                                                                        // Set condition to trigger flip (1.5 * work[0] < work[8])
                                                                                        work[0] = 1;
                                                                                        work[8] = 2;
                                                                                        
                                                                                        // Use reflection to set private fields
                                                                                        Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                        pingPongField.setAccessible(true);
                                                                                        pingPongField.setInt(eigen, 0); // Set pingPong to 0
                                                                                        
                                                                                        Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                        workField.setAccessible(true);
                                                                                        workField.set(eigen, work); // Inject work array
                                                                                        
                                                                                        // Use reflection to invoke private method
                                                                                        Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                        flipMethod.setAccessible(true);
                                                                                        boolean result = (boolean) flipMethod.invoke(eigen, 3, 1); // n=3, step=1
                                                                                        
                                                                                        // Verify
                                                                                        assertTrue(result); // Flip should occur
                                                                                        
                                                                                        // Check exact positions after flip
                                                                                        assertEquals(2.0, work[0], 0.0001); // From work[8]
                                                                                        assertEquals(2.0, work[1], 0.0001); // From work[9]
                                                                                        assertEquals(3.0, work[2], 0.0001); // From work[10]
                                                                                        assertEquals(4.0, work[3], 0.0001); // From work[11]
                                                                                        assertEquals(1.0, work[8], 0.0001); // From work[0]
                                                                                        assertEquals(20.0, work[9], 0.0001); // From work[1]
                                                                                        assertEquals(30.0, work[10], 0.0001); // From work[2]
                                                                                        assertEquals(40.0, work[11], 0.0001); // From work[3]
                                                                                        
                                                                                        // Middle elements should remain unchanged
                                                                                        assertEquals(50.0, work[4], 0.0001);
                                                                                        assertEquals(60.0, work[5], 0.0001);
                                                                                        assertEquals(70.0, work[6], 0.0001);
                                                                                        assertEquals(80.0, work[7], 0.0001);
                                                                                    }

    @Test
                                                                               public void testFlipIfWarranted_ShouldReturnTrueWhenFlippingOccurs() {
                                                                                   // Setup
                                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                   
                                                                                   // Create a work array that will trigger the flip condition
                                                                                   // We need 1.5 * work[pingPong] < work[4*(n-1)+pingPong]
                                                                                   // Let's set pingPong=0, n=2 (so 4*(n-1)+pingPong = 4)
                                                                                   double[] work = new double[8]; // Need at least 5 elements (0-4)
                                                                                   work[0] = 10.0;  // pingPong position
                                                                                   work[4] = 20.0;  // 1.5*10=15 < 20 → condition true
                                                                                   
                                                                                   // Set some values that will be flipped to verify the operation
                                                                                   work[0] = 1.0; work[1] = 2.0; work[2] = 3.0; work[3] = 4.0; // First block
                                                                                   work[4] = 5.0; // Second block (only first element since j=4, i=0, k=0)
                                                                                   
                                                                                   // Use reflection to set private fields since they're not accessible
                                                                                   try {
                                                                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                       workField.setAccessible(true);
                                                                                       workField.set(eigen, work);
                                                                                       
                                                                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                       pingPongField.setAccessible(true);
                                                                                       pingPongField.set(eigen, 0);
                                                                                       
                                                                                       // Get and invoke the private method
                                                                                       Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                       flipMethod.setAccessible(true);
                                                                                       boolean result = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
                                                                                       
                                                                                       // Verify
                                                                                       assertTrue("Method should return true when flipping occurs", result);
                                                                                       
                                                                                       // Additional verification that flipping actually occurred
                                                                                       // After flip, work[0] should be swapped with work[4]
                                                                                       assertEquals(5.0, work[0], 0.0001);
                                                                                       assertEquals(1.0, work[4], 0.0001);
                                                                                   } catch (Exception e) {
                                                                                       fail("Failed to set private fields or invoke private method via reflection: " + e.getMessage());
                                                                                   }
                                                                               }

    @Test
                                                                          public void testFlipIfWarranted_ShouldReturnFalseWhenConditionNotMet1() {
                                                                              // Setup
                                                                              EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                              
                                                                              // Use reflection to set private fields since they're needed for the test
                                                                              try {
                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                  workField.setAccessible(true);
                                                                                  double[] work = new double[10]; // Size large enough for test case
                                                                                  work[0] = 10.0; // pingPong index (assuming 0)
                                                                                  work[4] = 5.0;  // 4*(2-1)+0 = 4 when n=2
                                                                                  workField.set(decomposition, work);
                                                                                  
                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                  pingPongField.setAccessible(true);
                                                                                  pingPongField.setInt(decomposition, 0); // set pingPong to 0
                                                                                  
                                                                                  // Get the private method via reflection
                                                                                  Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                  flipMethod.setAccessible(true);
                                                                                  
                                                                                  // Test case where 1.5*work[0] (15) is NOT less than work[4] (5)
                                                                                  // So condition is false and should return false
                                                                                  boolean result = (boolean) flipMethod.invoke(decomposition, 2, 1); // n=2, step=1
                                                                                  
                                                                                  // Verify
                                                                                  assertFalse("Method should return false when condition is not met", result);
                                                                              } catch (Exception e) {
                                                                                  fail("Failed to set up test due to reflection issues: " + e.getMessage());
                                                                              }
                                                                          }

    @Test
                                                                     public void testFlipIfWarranted_ShouldNotFlipWhenValuesAreEqual2() {
                                                                         // Setup
                                                                         EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                         
                                                                         // Set n=2 (since 4*(n-1)+pingPong needs to be valid index)
                                                                         int n = 2;
                                                                         int step = 1;
                                                                         int pingPong = 0;
                                                                         
                                                                         // Create work array where 1.5*work[pingPong] equals work[4*(n-1)+pingPong]
                                                                         // Using pingPong=0, so work[0] and work[4*(2-1)+0] = work[4]
                                                                         double[] work = new double[5]; // needs at least 5 elements (0-4)
                                                                         work[pingPong] = 2.0;          // work[0] = 2.0
                                                                         work[4*(n-1)+pingPong] = 3.0;  // work[4] = 3.0 (since 1.5*2.0 = 3.0)
                                                                         
                                                                         // Set other array elements to detect if flip occurs
                                                                         work[1] = 1.0;
                                                                         work[2] = 2.0;
                                                                         work[3] = 3.0;
                                                                         
                                                                         // Set private fields using reflection
                                                                         try {
                                                                             Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                             workField.setAccessible(true);
                                                                             workField.set(eigen, work);
                                                                             
                                                                             Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                             pingPongField.setAccessible(true);
                                                                             pingPongField.set(eigen, pingPong);
                                                                             
                                                                             // Get and invoke the private method
                                                                             Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                             flipMethod.setAccessible(true);
                                                                             boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                             
                                                                             // Verify
                                                                             assertFalse("Method should return false when values are equal", result);
                                                                             
                                                                             // Verify array wasn't modified
                                                                             assertEquals(2.0, work[0], 0.0001);
                                                                             assertEquals(1.0, work[1], 0.0001);
                                                                             assertEquals(2.0, work[2], 0.0001);
                                                                             assertEquals(3.0, work[3], 0.0001);
                                                                             assertEquals(3.0, work[4], 0.0001);
                                                                         } catch (Exception e) {
                                                                             fail("Failed to set private fields or invoke method via reflection: " + e.getMessage());
                                                                         }
                                                                     }

    @Test
                                                                public void testFlipIfWarrantedDetectsIndexMutation() {
                                                                    // Setup test data where:
                                                                    // - work[pingPong] = 10 (so 1.5*work[pingPong] = 15)
                                                                    // - work[4*(n-1)+pingPong] = 14 (original condition false)
                                                                    // - work[4*n+pingPong] = 16 (mutant condition true)
                                                                    
                                                                    // Create test instance
                                                                    EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                    
                                                                    // Set up test parameters
                                                                    int n = 2;  // So 4*(n-1) = 4 and 4*n = 8
                                                                    int step = 1;
                                                                    int pingPong = 1;
                                                                    
                                                                    // Create work array with carefully chosen values
                                                                    double[] work = new double[20];
                                                                    work[pingPong] = 10;       // work[1] = 10
                                                                    work[4*(n-1)+pingPong] = 14; // work[5] = 14 (15 < 14 is false)
                                                                    work[4*n+pingPong] = 16;     // work[9] = 16 (15 < 16 is true)
                                                                    
                                                                    // Set required fields through reflection since they're private
                                                                    try {
                                                                        Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                        workField.setAccessible(true);
                                                                        workField.set(eigen, work);
                                                                        
                                                                        Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                        pingPongField.setAccessible(true);
                                                                        pingPongField.set(eigen, pingPong);
                                                                        
                                                                        // Get and invoke the private method
                                                                        Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                        flipIfWarrantedMethod.setAccessible(true);
                                                                        boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                        
                                                                        // Assert the original behavior (false)
                                                                        assertFalse("Method should return false with original condition", result);
                                                                        
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set private fields or invoke private method via reflection: " + e.getMessage());
                                                                    }
                                                                    
                                                                    // If mutant is present, it would return true, so this test would fail
                                                                    // thereby detecting the mutant
                                                                }

    @Test
                                                           public void testFlipIfWarrantedDetectsMutant7() throws Exception {
                                                               // Setup test data
                                                               int n = 3; // Choose n > 1 to show difference between original and mutant
                                                               int step = 1;
                                                               double[] work = new double[4 * n]; // Array size needs to accommodate both versions
                                                               
                                                               // Set values that will trigger the flip condition
                                                               // Make sure 1.5 * work[pingPong] < work[4*(n-1) + pingPong]
                                                               int pingPong = 0;
                                                               work[pingPong] = 1.0;
                                                               work[4 * (n - 1) + pingPong] = 2.0; // 1.5 * 1.0 < 2.0 → condition true
                                                               
                                                               // Set distinctive values to verify flipping
                                                               for (int i = 0; i < work.length; i++) {
                                                                   work[i] = i; // Each element gets its index as value
                                                               }
                                                               
                                                               // Create instance and set required fields using reflection
                                                               EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                               
                                                               // Set private work field
                                                               Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                               workField.setAccessible(true);
                                                               workField.set(eigen, work);
                                                               
                                                               // Set private pingPong field
                                                               Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                               pingPongField.setAccessible(true);
                                                               pingPongField.set(eigen, pingPong);
                                                               
                                                               // Get private flipIfWarranted method
                                                               Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                               flipMethod.setAccessible(true);
                                                               
                                                               // Execute the method
                                                               boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                               
                                                               // Verify results
                                                               assertTrue("Method should have flipped array", result);
                                                               
                                                               // Verify exact flipping behavior - this will catch the mutant
                                                               // Original version (j=4*(n-1)=8) should flip elements 0-7
                                                               // Mutant version (j=4*n=12) would try to flip elements 0-11 (but array size is 12)
                                                               // Check that last block wasn't flipped (would be flipped in mutant)
                                                               int lastBlockStart = 4 * (n - 1);
                                                               assertEquals("Last block should not be flipped", 
                                                                           lastBlockStart, work[lastBlockStart], 0.0001);
                                                               assertEquals("Last block should not be flipped", 
                                                                           lastBlockStart + 1, work[lastBlockStart + 1], 0.0001);
                                                               assertEquals("Last block should not be flipped", 
                                                                           lastBlockStart + 2, work[lastBlockStart + 2], 0.0001);
                                                               assertEquals("Last block should not be flipped", 
                                                                           lastBlockStart + 3, work[lastBlockStart + 3], 0.0001);
                                                               
                                                               // Verify some flipped elements
                                                               assertEquals("First element should be flipped", 
                                                                           4 * (n - 1), work[0], 0.0001);
                                                               assertEquals("Second element should be flipped", 
                                                                           4 * (n - 1) - 3, work[1], 0.0001);
                                                           }

    @Test
                                                      public void testFlipIfWarrantedDetectsLoopBoundaryMutant() throws Exception {
                                                          // Setup test data where flip condition is true and j is exactly divisible by 4
                                                          int n = 3;  // j = 4*(3-1) = 8
                                                          int step = 1;
                                                          int pingPong = 0;
                                                          
                                                          // Create work array where flip condition is true (1.5*work[0] < work[8])
                                                          double[] work = new double[20];  // large enough to avoid index issues
                                                          work[pingPong] = 10.0;          // work[0] = 10
                                                          work[4 * (n - 1) + pingPong] = 20.0; // work[8] = 20 (1.5*10 < 20 is true)
                                                          
                                                          // Fill array with distinct values to detect swapping
                                                          for (int i = 0; i < work.length; i++) {
                                                              work[i] = i;
                                                          }
                                                          
                                                          // Create instance and set required fields using reflection
                                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                          
                                                          // Set private work field
                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                          workField.setAccessible(true);
                                                          workField.set(eigen, work);
                                                          
                                                          // Set private pingPong field
                                                          Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                          pingPongField.setAccessible(true);
                                                          pingPongField.set(eigen, pingPong);
                                                          
                                                          // Get private flipIfWarranted method
                                                          Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                          flipMethod.setAccessible(true);
                                                          
                                                          // Execute the method
                                                          boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                          
                                                          // Verify the flipping occurred (method returns true)
                                                          assertTrue(result);
                                                          
                                                          // Verify the exact number of swaps occurred (2 iterations in original, 3 in mutant)
                                                          // Original: i=0,j=8 and i=4,j=4 (loop stops since i is not < j)
                                                          // Mutant:   i=0,j=8; i=4,j=4; i=8,j=0 (extra iteration)
                                                          
                                                          // Check specific elements that would be double-swapped in mutant
                                                          // In original, element 8 is swapped once (with 0)
                                                          // In mutant, element 8 would be swapped twice (ending up back in original position)
                                                          assertEquals(0.0, work[8], 0.0001);  // Original: 0 and 8 are swapped once
                                                                                               // Mutant: swapped twice (back to original)
                                                      }

    @Test
                                                 public void testFlipIfWarrantedDetectsIncrementMutation2() throws Exception {
                                                     // Setup test data
                                                     int n = 3; // Creates j = 4*(3-1) = 8
                                                     int step = 1;
                                                     int pingPong = 0;
                                                     
                                                     // Create work array where condition is true (1.5*work[0] < work[8])
                                                     double[] work = new double[20]; // Large enough array
                                                     work[0] = 10.0;  // work[pingPong]
                                                     work[8] = 20.0;  // work[4*(n-1) + pingPong] = work[8]
                                                     
                                                     // Fill array with distinct values to detect flipping
                                                     for (int i = 0; i < work.length; i++) {
                                                         work[i] = i;
                                                     }
                                                     
                                                     // Create instance and set required fields using reflection
                                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                     
                                                     // Set private work field
                                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                     workField.setAccessible(true);
                                                     workField.set(eigen, work);
                                                     
                                                     // Set private pingPong field
                                                     Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                     pingPongField.setAccessible(true);
                                                     pingPongField.set(eigen, pingPong);
                                                     
                                                     // Get private flipIfWarranted method
                                                     Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                     flipMethod.setAccessible(true);
                                                     
                                                     // Execute method
                                                     boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                     
                                                     // Verify flipping occurred
                                                     assertTrue(result);
                                                     
                                                     // Verify exact array state after flipping
                                                     // Original should flip pairs: (0,8), (1,7), (2,6), (3,5)
                                                     // Then j becomes 4, next flip pairs: (4,4) - no change
                                                     double[] expected = work.clone();
                                                     // First flip (i=0)
                                                     double tmp = expected[0]; expected[0] = expected[8]; expected[8] = tmp;
                                                     tmp = expected[1]; expected[1] = expected[7]; expected[7] = tmp;
                                                     tmp = expected[2]; expected[2] = expected[6]; expected[6] = tmp;
                                                     tmp = expected[3]; expected[3] = expected[5]; expected[5] = tmp;
                                                     // Second flip (i=4) would be (4,4) - no change
                                                     
                                                     // The mutant would do additional flips at i=2,6 etc. which would make the array different
                                                     assertArrayEquals(expected, work, 0.0001);
                                                 }

    @Test
                                            public void testFlipIfWarrantedDetectsMutatedLoopCondition2() throws Exception {
                                                // Setup test data
                                                int n = 2; // Minimum n that will trigger flip (4*(n-1) must be valid index)
                                                int step = 1; // Step size that will expose the mutation
                                                int pingPong = 0; // Arbitrary pingPong value
                                                
                                                // Create work array large enough for the operations
                                                double[] work = new double[8]; // Need at least 4*(n-1)+4 = 4*1+4=8 elements
                                                // Set values to trigger flip condition (1.5*work[0] < work[4])
                                                work[0] = 1.0;
                                                work[4] = 2.0; // 1.5*1 < 2 → true
                                                
                                                // Initialize other array positions to distinct values for verification
                                                for (int i = 1; i < work.length; i++) {
                                                    if (i != 4) work[i] = i + 10; // Distinct values
                                                }
                                                
                                                // Create instance
                                                EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                
                                                // Use reflection to set private fields
                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                workField.setAccessible(true);
                                                workField.set(eigen, work);
                                                
                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                pingPongField.setAccessible(true);
                                                pingPongField.set(eigen, pingPong);
                                                
                                                // Use reflection to invoke private method
                                                Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                flipMethod.setAccessible(true);
                                                boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                
                                                // Verify
                                                assertTrue(result); // Flip should have occurred
                                                // Additional verification that flipping worked correctly
                                                assertEquals(work[4], work[0], 0.0001); // First and last should be swapped
                                                assertEquals(work[3], work[1], 0.0001); // Inner elements should be swapped
                                            }

    @Test
                                       public void testFlipIfWarrantedWithStepGreaterThanOne1() {
                                           // Setup
                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                           
                                           // Create a work array that will trigger the flip condition
                                           // pingPong = 0, n = 2 (so 4*(n-1) = 4)
                                           // Condition: 1.5*work[0] < work[4]
                                           double[] work = new double[8];
                                           work[0] = 1.0;  // 1.5*1.0 = 1.5
                                           work[4] = 2.0;   // 1.5 < 2.0 -> will flip
                                           // Fill with distinct values to track swaps
                                           for (int i = 0; i < work.length; i++) {
                                               work[i] = i;
                                           }
                                           
                                           // Use reflection to set private fields and invoke private method
                                           try {
                                               Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                               workField.setAccessible(true);
                                               workField.set(eigen, work);
                                               
                                               Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                               pingPongField.setAccessible(true);
                                               pingPongField.set(eigen, 0);
                                               
                                               // Get the private method and invoke it
                                               Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                               flipMethod.setAccessible(true);
                                               boolean result = (boolean) flipMethod.invoke(eigen, 2, 2);
                                               
                                               // Verify
                                               assertTrue(result);  // Should have performed the flip
                                               
                                               // Check the swapping pattern - with step=2, only elements at positions 0 and 2 should be swapped in each block
                                               // Original array: [0,1,2,3,4,5,6,7]
                                               // Expected after flip with step=2:
                                               // First outer loop (i=0, j=4):
                                               //   Swap 0<->4 (k=0)
                                               //   Skip k=1 (step=2)
                                               //   Swap 2<->6 (k=2)
                                               //   Skip k=3 (step=2)
                                               // Second outer loop (i=4, j=0) - doesn't run (i < j condition)
                                               // So final array should be: [4,1,6,3,0,5,2,7]
                                               assertEquals(4.0, work[0], 0.0001);
                                               assertEquals(1.0, work[1], 0.0001);  // Should remain unchanged
                                               assertEquals(6.0, work[2], 0.0001);
                                               assertEquals(3.0, work[3], 0.0001);  // Should remain unchanged
                                               assertEquals(0.0, work[4], 0.0001);
                                               assertEquals(5.0, work[5], 0.0001);  // Should remain unchanged
                                               assertEquals(2.0, work[6], 0.0001);
                                               assertEquals(7.0, work[7], 0.0001);  // Should remain unchanged
                                               
                                           } catch (Exception e) {
                                               fail("Failed to access private fields/methods via reflection: " + e.getMessage());
                                           }
                                       }

    @Test
                                  public void testFlipIfWarrantedDetectsArrayAccessMutation() throws Exception {
                                      // Setup test data where flip condition is true
                                      int n = 3; // For array size calculation
                                      int step = 1; // Step size for inner loop
                                      int pingPong = 0; // Array index offset
                                      
                                      // Create work array where flip condition is true (1.5*work[0] < work[8])
                                      // Array size needs to be at least 4*(n-1)+pingPong+1 = 9 elements
                                      double[] work = new double[12]; // Extra space to avoid bounds issues
                                      work[0] = 1.0;  // work[pingPong]
                                      work[8] = 2.0;   // work[4*(n-1)+pingPong] (1.5*1 < 2 -> true)
                                      
                                      // Fill array with distinct values to detect incorrect swaps
                                      for (int i = 0; i < work.length; i++) {
                                          work[i] = i + 1; // Values 1..12
                                      }
                                      
                                      // Create instance and set required fields using reflection
                                      EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                      
                                      // Set private work field
                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                      workField.setAccessible(true);
                                      workField.set(eigen, work);
                                      
                                      // Set private pingPong field
                                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                      pingPongField.setAccessible(true);
                                      pingPongField.set(eigen, pingPong);
                                      
                                      // Get private flipIfWarranted method
                                      Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                      flipMethod.setAccessible(true);
                                      
                                      // Execute the method
                                      boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                      
                                      // Verify the flip occurred
                                      assertTrue(result);
                                      
                                      // Verify exact array state after flip
                                      // Original should swap:
                                      // i=0: swap 0+0 with 8-0 (1 ↔ 9), 0+1 with 8-1 (2 ↔ 8), etc.
                                      // i=4: swap 4+0 with 4-0 (5 ↔ 5), etc.
                                      // Mutant would try to access negative indices when k > i
                                      
                                      // Check specific swaps that would fail with i-k mutation
                                      assertEquals(9.0, work[0], 0.0001); // First element should be swapped
                                      assertEquals(1.0, work[8], 0.0001); // Corresponding element at other end
                                      assertEquals(8.0, work[1], 0.0001); // Second element swapped
                                      assertEquals(2.0, work[7], 0.0001); // Corresponding element
                                      
                                      // Check middle elements remain unchanged
                                      assertEquals(5.0, work[4], 0.0001);
                                      assertEquals(6.0, work[5], 0.0001);
                                  }

    @Test
                             public void testFlipIfWarrantedDetectsMutant8() throws Exception {
                                 // Setup test data where flip condition is true
                                 int n = 3;  // Array size parameter
                                 int step = 1; // Step parameter
                                 int pingPong = 0; // Assume pingPong is 0 for this test
                                 
                                 // Create work array with distinct values that will show the mutation
                                 // The array needs to be large enough for the indices used in the method
                                 double[] work = new double[4 * (n - 1) + 1];
                                 
                                 // Fill the array with distinct values
                                 for (int i = 0; i < work.length; i++) {
                                     work[i] = i * 10.0; // Distinct values that will show position changes
                                 }
                                 
                                 // Make sure flip condition is true
                                 work[pingPong] = 1.0;
                                 work[4 * (n - 1) + pingPong] = 10.0; // 1.5*1.0 < 10.0 -> condition true
                                 
                                 // Create instance and set required fields using reflection
                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                 
                                 // Set private work field
                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                 workField.setAccessible(true);
                                 workField.set(eigen, work);
                                 
                                 // Set private pingPong field
                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                 pingPongField.setAccessible(true);
                                 pingPongField.set(eigen, pingPong);
                                 
                                 // Call the private method using reflection
                                 Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                 flipMethod.setAccessible(true);
                                 boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                 
                                 // Verify the flip occurred
                                 assertTrue(result);
                                 
                                 // Verify the array was flipped correctly (would fail with mutant)
                                 // Original would swap positions symmetrically, mutant would not
                                 // Check specific positions that would differ between original and mutant
                                 assertEquals(80.0, work[0], 0.0001); // First element should be swapped with last in block
                                 assertEquals(0.0, work[8], 0.0001);   // Last element should be swapped with first
                                 assertEquals(40.0, work[4], 0.0001);  // Middle element should stay same (would differ in mutant)
                             }

    @Test
                        public void testFlipIfWarrantedDetectsMutant9() throws Exception {
                            // Setup test data that will trigger the flip condition
                            int n = 3;  // For 4*(3-1) = 8 elements to process
                            int step = 1;
                            int pingPong = 0;
                            
                            // Create a work array where flip condition is true
                            // work[0] = 1.0, work[8] = 2.0 -> 1.5*1.0 < 2.0 -> true
                            double[] work = new double[9]; // index 0-8
                            work[pingPong] = 1.0;
                            work[4 * (n - 1) + pingPong] = 2.0;
                            
                            // Fill the array with test values that will be flipped
                            for (int i = 0; i < 8; i++) {
                                work[i] = i + 1.0; // Values 1.0 to 8.0
                            }
                            
                            // Create instance
                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                            
                            // Use reflection to set private fields
                            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                            workField.setAccessible(true);
                            workField.set(eigen, work);
                            
                            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                            pingPongField.setAccessible(true);
                            pingPongField.set(eigen, pingPong);
                            
                            // Use reflection to invoke private method
                            Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                            flipMethod.setAccessible(true);
                            boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                            
                            // Verify the flip occurred
                            assertTrue(result);
                            
                            // Verify the array was properly flipped (not zeroed out by mutant)
                            // Original array: [1,2,3,4,5,6,7,8,2]
                            // Expected after flip: [8,7,6,5,4,3,2,1,2]
                            assertEquals(8.0, work[0], 0.0001);
                            assertEquals(7.0, work[1], 0.0001);
                            assertEquals(6.0, work[2], 0.0001);
                            assertEquals(5.0, work[3], 0.0001);
                            assertEquals(4.0, work[4], 0.0001);
                            assertEquals(3.0, work[5], 0.0001);
                            assertEquals(2.0, work[6], 0.0001);
                            assertEquals(1.0, work[7], 0.0001);
                            assertEquals(2.0, work[8], 0.0001); // This element shouldn't change
                        }

    @Test
                   public void testFlipIfWarrantedDetectsMutant10() {
                       // Setup test data
                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                       
                       // Use reflection to set private fields since they're not accessible directly
                       try {
                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                           workField.setAccessible(true);
                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                           pingPongField.setAccessible(true);
                           
                           // Create a work array that will trigger the flip condition
                           // The condition is: 1.5 * work[pingPong] < work[4 * (n - 1) + pingPong]
                           double[] work = new double[20]; // Large enough for the test
                           work[0] = 10.0;  // pingPong will be 0
                           work[4 * (2 - 1) + 0] = 20.0; // For n=2, this makes condition true (1.5*10 < 20)
                           
                           workField.set(eigen, work);
                           pingPongField.setInt(eigen, 0); // pingPong = 0
                           
                           // Set up array contents to verify flipping
                           for (int i = 0; i < work.length; i++) {
                               work[i] = i; // Fill with index values for easy verification
                           }
                           
                           // Get and invoke the private method using reflection
                           Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                           flipMethod.setAccessible(true);
                           boolean result = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
                           
                           // Verify the method returned true (flip occurred)
                           assertTrue(result);
                           
                           // Verify the array was flipped correctly
                           // Original array would be properly flipped with j decreasing
                           // Mutant with j increasing would either throw exception or produce wrong results
                           // Expected flip for n=2:
                           // Should swap elements in blocks of 4 from start and end moving inward
                           assertEquals(4.0, work[0], 0.0001); // First block first element
                           assertEquals(0.0, work[4], 0.0001); // First block last element
                           // Add more assertions as needed
                           
                       } catch (Exception e) {
                           fail("Test setup failed: " + e.getMessage());
                       }
                   }

    @Test
              public void testFlipIfWarrantedDetectsJDecrementMutant2() {
                  // Setup test data
                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                  
                  // Create a work array that will trigger the flip condition
                  // Size needs to be large enough to show the effect of the mutation
                  double[] work = new double[20]; // 5 blocks of 4 elements
                  
                  // Set values so the flip condition is true (1.5 * work[pingPong] < work[4*(n-1)+pingPong])
                  // Let's use n=3 (so 4*(3-1) = 8), pingPong=0
                  work[0] = 1.0;  // pingPong position
                  work[8] = 2.0;  // 4*(n-1)+pingPong position (1.5*1 < 2)
                  
                  // Fill array with distinct values to track swaps
                  for (int i = 0; i < work.length; i++) {
                      work[i] = i;
                  }
                  
                  // Set required fields through reflection since they're private
                  try {
                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                      workField.setAccessible(true);
                      workField.set(eigen, work);
                      
                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                      pingPongField.setAccessible(true);
                      pingPongField.setInt(eigen, 0); // pingPong = 0
                      
                      // Call private method via reflection
                      Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                      flipMethod.setAccessible(true);
                      boolean result = (boolean) flipMethod.invoke(eigen, 3, 1); // n=3, step=1
                      
                      // Verify flipping occurred
                      assertTrue(result);
                      
                      // Verify exact array state after flipping
                      // Original should swap blocks: 
                      // block 0 (0-3) with block 2 (8-11)
                      // block 1 (4-7) with block 1 (4-7) - no change
                      double[] expected = new double[20];
                      System.arraycopy(work, 0, expected, 0, 20); // copy original
                      
                      // Manually perform expected swaps (j decreases by 4)
                      // First swap: i=0, j=8
                      for (int k = 0; k < 4; k++) {
                          double tmp = expected[0 + k];
                          expected[0 + k] = expected[8 + (3 - k)]; // Note: j-k when j=8 and k=0-3
                          expected[8 + (3 - k)] = tmp;
                      }
                      
                      // Compare with actual
                      assertArrayEquals(expected, work, 0.0001);
                      
                  } catch (Exception e) {
                      fail("Test failed due to reflection error: " + e.getMessage());
                  }
                  
                  // The mutant with j-=2 would produce different results because:
                  // First swap: i=0, j=8 (same)
                  // Next swap: i=4, j=6 (8-2=6) - would incorrectly swap wrong blocks
                  // This would make the final array different from expected
              }

    @Test
         public void testFlipIfWarranted_ShouldReturnTrueWhenFlipped() {
             // Setup
             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
             
             // Create a work array where the condition 1.5*work[pingPong] < work[4*(n-1)+pingPong] is true
             // Let's use n=2 (so 4*(2-1) = 4), pingPong=0
             // Set work[0] = 1, work[4] = 2 (since 1.5*1 < 2 is true)
             double[] work = new double[8]; // Need at least 5 elements (4*(2-1)+0+1)
             work[0] = 1.0;  // work[pingPong]
             work[4] = 2.0;  // work[4*(n-1)+pingPong]
             
             // Set some distinct values that will be flipped
             work[1] = 10.0;
             work[2] = 20.0;
             work[3] = 30.0;
             
             // Set the class fields using reflection since they're private
             try {
                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                 workField.setAccessible(true);
                 workField.set(eigen, work);
                 
                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                 pingPongField.setAccessible(true);
                 pingPongField.set(eigen, 0);
                 
                 // Get and invoke the private method
                 Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                 flipMethod.setAccessible(true);
                 boolean result = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
                 
                 // Verify
                 assertTrue("Method should return true when array is flipped", result);
                 
                 // Additional verification that array was actually flipped
                 // Original positions: [1,10,20,30,...] should be swapped with [...,30,20,10]
                 assertEquals(30.0, work[0], 0.0001); // First element should now be last
                 assertEquals(20.0, work[1], 0.0001);
                 assertEquals(10.0, work[2], 0.0001);
                 assertEquals(1.0, work[4], 0.0001);  // Last element should now be first
                 
             } catch (Exception e) {
                 fail("Failed to set private fields or invoke private method via reflection: " + e.getMessage());
             }
         }

    @Test
    public void testFlipIfWarranted_ShouldReturnFalseWhenConditionNotMet2() {
        // Setup
        EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
        
        // Set up work array where condition will be false (1.5*work[pingPong] >= work[4*(n-1)+pingPong])
        // Using reflection to set private fields since they're not accessible directly
        try {
            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
            workField.setAccessible(true);
            double[] work = new double[10]; // Size large enough for our test
            work[0] = 10.0; // pingPong will be 0 by default
            work[4*(2-1)+0] = 5.0; // 1.5*10=15 which is > 5
            workField.set(decomposition, work);
            
            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
            pingPongField.setAccessible(true);
            pingPongField.set(decomposition, 0);
            
            // Get and invoke the private method
            Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
            flipMethod.setAccessible(true);
            boolean result = (boolean) flipMethod.invoke(decomposition, 2, 1);
            
            // Verify - should return false since condition isn't met
            assertFalse("Method should return false when condition isn't met", result);
        } catch (Exception e) {
            fail("Failed to set up or execute test due to reflection error: " + e.getMessage());
        }
    }


}
