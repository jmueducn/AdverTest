package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import org.apache.commons.math.exception.DimensionMismatchException;
import org.apache.commons.math.exception.OutOfRangeException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.util.MathUtils;
 
public class MultidimensionalCounterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                              public void testGetCounts_ValidIndex2D() {
                                                                                                  // 2D counter with sizes [2, 3] (total size = 6)
                                                                                                  MultidimensionalCounter counter = new MultidimensionalCounter(new int[]{2, 3});
                                                                                                  
                                                                                                  // Test various indices
                                                                                                  assertArrayEquals(new int[]{0, 0}, counter.getCounts(0));
                                                                                                  assertArrayEquals(new int[]{0, 1}, counter.getCounts(1));
                                                                                                  assertArrayEquals(new int[]{0, 2}, counter.getCounts(2));
                                                                                                  assertArrayEquals(new int[]{1, 0}, counter.getCounts(3));
                                                                                                  assertArrayEquals(new int[]{1, 1}, counter.getCounts(4));
                                                                                                  assertArrayEquals(new int[]{1, 2}, counter.getCounts(5));
                                                                                              }

    @Test
                                                                                              public void testGetCounts_ValidIndex3D() {
                                                                                                  // 3D counter with sizes [2, 3, 4] (total size = 24)
                                                                                                  MultidimensionalCounter counter = new MultidimensionalCounter(new int[]{2, 3, 4});
                                                                                                  
                                                                                                  // Test various indices
                                                                                                  assertArrayEquals(new int[]{0, 0, 0}, counter.getCounts(0));
                                                                                                  assertArrayEquals(new int[]{0, 0, 1}, counter.getCounts(1));
                                                                                                  assertArrayEquals(new int[]{0, 0, 3}, counter.getCounts(3));
                                                                                                  assertArrayEquals(new int[]{0, 1, 0}, counter.getCounts(4));
                                                                                                  assertArrayEquals(new int[]{0, 2, 3}, counter.getCounts(11));
                                                                                                  assertArrayEquals(new int[]{1, 0, 0}, counter.getCounts(12));
                                                                                                  assertArrayEquals(new int[]{1, 2, 3}, counter.getCounts(23));
                                                                                              }

    @Test
                                                                                              public void testGetCounts_IndexTooSmall() {
                                                                                                  MultidimensionalCounter counter = new MultidimensionalCounter(new int[]{2, 3});
                                                                                                  
                                                                                                  thrown.expect(OutOfRangeException.class);
                                                                                                  thrown.expectMessage("-1 out of [0, 6)");
                                                                                                  counter.getCounts(-1);
                                                                                              }

    @Test
                                                                                              public void testGetCounts_IndexTooLarge() {
                                                                                                  MultidimensionalCounter counter = new MultidimensionalCounter(new int[]{2, 3});
                                                                                                  
                                                                                                  thrown.expect(OutOfRangeException.class);
                                                                                                  thrown.expectMessage("6 out of [0, 6)");
                                                                                                  counter.getCounts(6);
                                                                                              }

    @Test
                                                                                              public void testGetCounts_EdgeCases() {
                                                                                                  // 1D counter (edge case for dimensionality)
                                                                                                  MultidimensionalCounter counter1D = new MultidimensionalCounter(new int[]{5});
                                                                                                  
                                                                                                  assertArrayEquals(new int[]{0}, counter1D.getCounts(0));
                                                                                                  assertArrayEquals(new int[]{4}, counter1D.getCounts(4));
                                                                                                  
                                                                                                  // Counter with size 1 in all dimensions
                                                                                                  MultidimensionalCounter counterAllOnes = new MultidimensionalCounter(new int[]{1, 1, 1});
                                                                                                  assertArrayEquals(new int[]{0, 0, 0}, counterAllOnes.getCounts(0));
                                                                                              }

    @Test(expected = NotStrictlyPositiveException.class)
                                                                                              public void testConstructor_InvalidSize() {
                                                                                                  // Should throw NotStrictlyPositiveException
                                                                                                  new MultidimensionalCounter(new int[]{0, 2});
                                                                                              }

    @Test
                                                                                              public void testGetCounts_LargeDimensions() {
                                                                                                  // 4D counter with sizes [3, 2, 3, 2] (total size = 36)
                                                                                                  MultidimensionalCounter counter = new MultidimensionalCounter(new int[]{3, 2, 3, 2});
                                                                                                  
                                                                                                  // Test various indices
                                                                                                  assertArrayEquals(new int[]{0, 0, 0, 0}, counter.getCounts(0));
                                                                                                  assertArrayEquals(new int[]{0, 0, 0, 1}, counter.getCounts(1));
                                                                                                  assertArrayEquals(new int[]{0, 0, 1, 0}, counter.getCounts(2));
                                                                                                  assertArrayEquals(new int[]{0, 0, 2, 1}, counter.getCounts(5));
                                                                                                  assertArrayEquals(new int[]{0, 1, 0, 0}, counter.getCounts(6));
                                                                                                  assertArrayEquals(new int[]{1, 0, 0, 0}, counter.getCounts(12));
                                                                                                  assertArrayEquals(new int[]{2, 1, 2, 1}, counter.getCounts(35));
                                                                                              }

    @Test
                                                                                              public void testGetCounts_AfterCounterModification() {
                                                                                                  // This test assumes there are ways to modify the counter (though not shown in interface)
                                                                                                  // Since we can't see methods to modify counter, we'll skip this scenario
                                                                                                  // In a real implementation, we would test that getCounts() reflects any changes
                                                                                              }

    @Test
                                                                                  public void testGetCounts_VerifyCopyBehavior() {
                                                                                      MultidimensionalCounter counter = new MultidimensionalCounter(new int[]{1, 2, 3});
                                                                                      
                                                                                      // Create a valid index (0 is always valid for this counter)
                                                                                      int testIndex = 0;
                                                                                      
                                                                                      // Get initial counts
                                                                                      int[] counts1 = counter.getCounts(testIndex);
                                                                                      
                                                                                      // Get counts again
                                                                                      int[] counts2 = counter.getCounts(testIndex);
                                                                                      
                                                                                      // Verify both calls return equal but distinct arrays
                                                                                      assertNotSame(counts1, counts2);
                                                                                      assertArrayEquals(counts1, counts2);
                                                                                  }

    @Test
                                                                          public void testGetCounts_EmptyCounter() {
                                                                              // Create counter with empty dimensions
                                                                              int[] emptyDimensions = new int[0];
                                                                              MultidimensionalCounter counter = new MultidimensionalCounter(emptyDimensions);
                                                                              
                                                                              // Call getCounts() with a valid index (0 in this case)
                                                                              // Since the counter is empty, we expect an empty array
                                                                              int[] result = counter.getCounts(0);
                                                                              
                                                                              assertNotNull(result);
                                                                              assertEquals(0, result.length);
                                                                          }

    @Test
                                                      public void testGetCounts_SingleDimension() {
                                                          // Create counter with single dimension
                                                          MultidimensionalCounter counter = new MultidimensionalCounter(new int[]{5});
                                                          
                                                          // Since getCounts() requires an index, we'll test with index 0
                                                          // First verify basic properties
                                                          int[] result = counter.getCounts(0);
                                                          assertNotNull(result);
                                                          assertEquals(1, result.length);
                                                          assertEquals(0, result[0]); // Initial count should be 0
                                                          
                                                          // Verify it returns a new array each time
                                                          int[] firstCall = counter.getCounts(0);
                                                          int[] secondCall = counter.getCounts(0);
                                                          assertNotSame(firstCall, secondCall);
                                                          
                                                          // Additional verification that contents are equal
                                                          assertArrayEquals(firstCall, secondCall);
                                                      }

    @Test
                                  public void testGetCounts_MultipleDimensions() {
                                      // Import required classes (these would be at class level in actual file)
                                      // import org.apache.commons.math.util.MultidimensionalCounter;
                                      // import static org.junit.Assert.*;
                                      
                                      // Create counter with multiple dimensions
                                      MultidimensionalCounter counter = new MultidimensionalCounter(new int[]{2, 3, 4});
                                      
                                      // Initialize the counter by iterating through it
                                      MultidimensionalCounter.Iterator iterator = counter.iterator();
                                      if (iterator.hasNext()) {
                                          iterator.next(); // Advance through first position to initialize
                                      }
                                      
                                      // Get counts for index 0
                                      int[] result = counter.getCounts(0);
                                      
                                      assertNotNull(result);
                                      assertEquals(3, result.length);
                                      assertArrayEquals(new int[]{0, 0, 0}, result); // Initial counts should all be 0
                                      
                                      // Verify modifications to returned array don't affect original
                                      int[] firstCopy = counter.getCounts(0);
                                      firstCopy[0] = 5;
                                      int[] secondCopy = counter.getCounts(0);
                                      assertEquals(0, secondCopy[0]); // Original should remain unchanged
                                  }

    @Test(expected = OutOfRangeException.class)
                              public void testGetCounts_IndexGreaterThanTotalSize_ShouldThrowException() {
                                  // Setup a simple 2D counter with sizes [2,3] (totalSize = 6)
                                  int[] sizes = {2, 3};
                                  MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                  
                                  // Test with index = 7 which is > totalSize (6)
                                  // With original code, this should throw OutOfRangeException
                                  // With mutated code (index == totalSize), this won't throw exception
                                  counter.getCounts(7);
                              }

    @Test
                             public void testGetCountsNormalCase() {
                                 // Test normal case where index < totalSize
                                 int[] dimensions = {3, 3, 3}; // Sample dimensions for 3D counter
                                 MultidimensionalCounter counter = new MultidimensionalCounter(dimensions);
                                 int[] result = counter.getCounts(2); // valid index
                                 assertNotNull(result);
                                 // Additional assertions could be made about the contents if needed
                             }

    @Test(expected = IndexOutOfBoundsException.class)
                             public void testGetCountsBoundaryCase() {
                                 // Test boundary case where index == totalSize
                                 // This should throw exception in both original and mutant
                                 int[] dimensions = {2, 2}; // Example dimensions
                                 MultidimensionalCounter counter = new MultidimensionalCounter(dimensions);
                                 counter.getCounts(4); // equals totalSize (2*2=4)
                             }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                             public void testGetCountsAboveBoundary() {
                                 // Create a MultidimensionalCounter with size 3 (totalSize = 3)
                                 int[] dimensions = {3};
                                 MultidimensionalCounter counter = new MultidimensionalCounter(dimensions);
                                 
                                 // Test case where index > totalSize
                                 // This should throw ArrayIndexOutOfBoundsException
                                 counter.getCounts(4); // greater than totalSize
                             }

    @Test
                             public void testGetCountsReturnsCopy() {
                                 // Create a test counter instance
                                 int[] sizes = {2, 3}; // Example sizes for the counter
                                 MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                 
                                 // Verify that it returns a copy, not the original array
                                 int[] firstCall = counter.getCounts(0);
                                 int[] secondCall = counter.getCounts(0);
                                 assertNotSame("Should return new array each time", firstCall, secondCall);
                             }

    @Test
                         public void testGetCountsDetectsIdxIncrementMutant() {
                             // Setup a simple 2D counter with sizes [2,3] (total size 6)
                             int[] sizes = {2, 3};
                             MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                             
                             // Test with index 4 which will exercise the loop
                             int[] expected = {1, 1}; // Expected result for index 4 in 2x3 counter
                             int[] actual = counter.getCounts(4);
                             
                             // Verify the final result
                             assertArrayEquals(expected, actual);
                             
                             // The key verification - check the intermediate state by testing with index 3
                             // For index 3 in 2x3 counter, the first dimension should be 1 (3/3 = 1)
                             expected = new int[]{1, 0};
                             actual = counter.getCounts(3);
                             assertArrayEquals(expected, actual);
                             
                             // Test another boundary case where idx increment matters
                             expected = new int[]{0, 2};
                             actual = counter.getCounts(2);
                             assertArrayEquals(expected, actual);
                         }

    @Test
    public void testGetCountsReturnsCopyNotOriginal() {
        // Setup - create a counter with known values
        int[] sizes = {2, 3};
        MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
        
        // Initialize the counter by getting counts at some index
        int[] initialCounts = counter.getCounts(0);
        
        // Get the counts array (should return a copy)
        int[] counts = counter.getCounts(0);
        
        // Modify the returned array
        counts[0] = 999;
        
        // Get the counts again
        int[] newCounts = counter.getCounts(0);
        
        // Verify the original wasn't modified
        assertNotEquals("The original counter array should not be modified", 
                        999, newCounts[0]);
        
        // Also verify they are different array objects
        assertNotSame("Should return a new array instance each time", 
                     counts, newCounts);
    }


}
