package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.MathInternalError;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
 
public class MathArraysTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                            public void testLinearCombination_SingleElementArrays() {
                                                                double[] a = {2.5};
                                                                double[] b = {3.0};
                                                                double result = MathArrays.linearCombination(a, b);
                                                                assertEquals(7.5, result, 0.0);
                                                            }

 @Test
                                                            public void testLinearCombination_TwoElementArrays() {
                                                                double[] a = {1.0, 2.0};
                                                                double[] b = {3.0, 4.0};
                                                                double result = MathArrays.linearCombination(a, b);
                                                                assertEquals(11.0, result, 1e-15);
                                                            }

 @Test
                                                            public void testLinearCombination_MultipleElementArrays() {
                                                                double[] a = {1.0, 2.0, 3.0, 4.0};
                                                                double[] b = {5.0, 6.0, 7.0, 8.0};
                                                                double result = MathArrays.linearCombination(a, b);
                                                                assertEquals(70.0, result, 1e-15);
                                                            }

 @Test
                                                            public void testLinearCombination_WithZeroElements() {
                                                                double[] a = {0.0, 1.0, 0.0};
                                                                double[] b = {2.0, 3.0, 4.0};
                                                                double result = MathArrays.linearCombination(a, b);
                                                                assertEquals(3.0, result, 0.0);
                                                            }

 @Test
                                                            public void testLinearCombination_WithNegativeNumbers() {
                                                                double[] a = {-1.0, 2.0, -3.0};
                                                                double[] b = {4.0, -5.0, 6.0};
                                                                double result = MathArrays.linearCombination(a, b);
                                                                assertEquals(-32.0, result, 1e-15);
                                                            }

 @Test
                                                            public void testLinearCombination_WithVerySmallNumbers() {
                                                                double[] a = {1e-300, 2e-300};
                                                                double[] b = {3e-300, 4e-300};
                                                                double result = MathArrays.linearCombination(a, b);
                                                                assertEquals(11e-300, result, 0.0);
                                                            }

 @Test
                                                            public void testLinearCombination_WithVeryLargeNumbers() {
                                                                double[] a = {1e300, 2e300};
                                                                double[] b = {3e300, 4e300};
                                                                double result = MathArrays.linearCombination(a, b);
                                                                assertEquals(11e300, result, 1e285); // Using relaxed delta due to floating point precision
                                                            }

 @Test
                                                            public void testLinearCombination_WithNaNValues() {
                                                                double[] a = {1.0, Double.NaN, 3.0};
                                                                double[] b = {4.0, 5.0, 6.0};
                                                                double result = MathArrays.linearCombination(a, b);
                                                                assertEquals(1.0*4.0 + 3.0*6.0, result, 0.0); // Should fall back to simple multiplication
                                                            }

 @Test
                                                            public void testLinearCombination_WithInfiniteValues() {
                                                                double[] a = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                                double[] b = {4.0, 5.0, 6.0};
                                                                double result = MathArrays.linearCombination(a, b);
                                                                assertTrue(Double.isInfinite(result));
                                                            }

 @Test
                                                            public void testLinearCombination_DimensionMismatch() {
                                                                double[] a = {1.0, 2.0};
                                                                double[] b = {3.0};
                                                                
                                                                thrown.expect(DimensionMismatchException.class);
                                                                thrown.expectMessage("2 != 1");
                                                                
                                                                MathArrays.linearCombination(a, b);
                                                            }

 @Test
                                                            public void testLinearCombination_EmptyArrays() {
                                                                double[] a = {};
                                                                double[] b = {};
                                                                
                                                                thrown.expect(DimensionMismatchException.class);
                                                                thrown.expectMessage("0 != 1"); // Special case when length is 1
                                                                
                                                                MathArrays.linearCombination(a, b);
                                                            }

 @Test
                                                            public void testLinearCombination_TypicalValues() {
                                                                // Test with typical positive values
                                                                double result1 = MathArrays.linearCombination(2.0, 3.0, 5.0, 7.0);
                                                                assertEquals(2.0 * 3.0 + 5.0 * 7.0, result1, 1.0e-15);
                                                        
                                                                // Test with mixed positive and negative values
                                                                double result2 = MathArrays.linearCombination(-2.0, 3.0, 5.0, -7.0);
                                                                assertEquals(-2.0 * 3.0 + 5.0 * -7.0, result2, 1.0e-15);
                                                        
                                                                // Test with small values
                                                                double result3 = MathArrays.linearCombination(1.0e-10, 2.0e-10, 3.0e-10, 4.0e-10);
                                                                assertEquals(1.0e-10 * 2.0e-10 + 3.0e-10 * 4.0e-10, result3, 1.0e-25);
                                                            }

 @Test
                                                            public void testLinearCombination_EdgeCases() {
                                                                // Test with zeros
                                                                double result1 = MathArrays.linearCombination(0.0, 3.0, 5.0, 0.0);
                                                                assertEquals(0.0 * 3.0 + 5.0 * 0.0, result1, 0.0);
                                                        
                                                                // Test with one zero coefficient
                                                                double result2 = MathArrays.linearCombination(0.0, 0.0, 1.0, 1.0);
                                                                assertEquals(1.0, result2, 1.0e-15);
                                                        
                                                                // Test with very large values
                                                                double result3 = MathArrays.linearCombination(Double.MAX_VALUE, 1.0, -Double.MAX_VALUE, 1.0);
                                                                assertEquals(0.0, result3, 1.0e-15);
                                                        
                                                                // Test with values near Double.MIN_VALUE
                                                                double result4 = MathArrays.linearCombination(Double.MIN_VALUE, 1.0, Double.MIN_VALUE, 1.0);
                                                                assertEquals(2 * Double.MIN_VALUE, result4, 1.0e-15);
                                                            }

 @Test
                                                            public void testLinearCombination_SpecialValues() {
                                                                // Test with NaN values
                                                                double result1 = MathArrays.linearCombination(Double.NaN, 1.0, 1.0, 1.0);
                                                                assertTrue(Double.isNaN(result1));
                                                        
                                                                // Test with infinite values
                                                                double result2 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 1.0, 1.0);
                                                                assertTrue(Double.isInfinite(result2));
                                                        
                                                                // Test with combination of infinite values that should cancel out
                                                                double result3 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 
                                                                                                             Double.NEGATIVE_INFINITY, 1.0);
                                                                assertTrue(Double.isNaN(result3));
                                                        
                                                                // Test with overflow scenario
                                                                double result4 = MathArrays.linearCombination(Double.MAX_VALUE, 2.0, Double.MAX_VALUE, 2.0);
                                                                assertEquals(Double.POSITIVE_INFINITY, result4, 0.0);
                                                            }

 @Test
                                                            public void testLinearCombination_Accuracy() {
                                                                // Test accuracy with values that would lose precision with naive implementation
                                                                double a1 = 1.0e20;
                                                                double b1 = 1.0;
                                                                double a2 = 1.0;
                                                                double b2 = -1.0e20;
                                                                
                                                                // Naive implementation would return 0.0 due to catastrophic cancellation
                                                                double naiveResult = a1 * b1 + a2 * b2;
                                                                assertEquals(0.0, naiveResult, 0.0);
                                                                
                                                                // linearCombination should return the correct non-zero result
                                                                double preciseResult = MathArrays.linearCombination(a1, b1, a2, b2);
                                                                assertEquals(1.0, preciseResult, 1.0e-15);
                                                            }

 @Test
                                                            public void testLinearCombination_WithExtremeValues() {
                                                                // Test with values that would cause overflow in intermediate calculations
                                                                double a1 = Double.MAX_VALUE / 2;
                                                                double b1 = 2.0;
                                                                double a2 = Double.MAX_VALUE / 2;
                                                                double b2 = 2.0;
                                                                
                                                                double result = MathArrays.linearCombination(a1, b1, a2, b2);
                                                                assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                                            }

 @Test
                                                            public void testLinearCombination_TypicalValues1() {
                                                                // Test with typical positive values
                                                                double result1 = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, 5.0, 6.0);
                                                                assertEquals(1.0*2.0 + 3.0*4.0 + 5.0*6.0, result1, 1e-15);
                                                                
                                                                // Test with mixed positive and negative values
                                                                double result2 = MathArrays.linearCombination(-1.0, 2.0, 3.0, -4.0, 5.0, 6.0);
                                                                assertEquals(-1.0*2.0 + 3.0*-4.0 + 5.0*6.0, result2, 1e-15);
                                                                
                                                                // Test with very small values
                                                                double result3 = MathArrays.linearCombination(1e-20, 2e-20, 3e-20, 4e-20, 5e-20, 6e-20);
                                                                assertEquals(1e-20*2e-20 + 3e-20*4e-20 + 5e-20*6e-20, result3, 1e-35);
                                                            }

 @Test
                                                            public void testLinearCombination_EdgeCases1() {
                                                                // Test with zeros
                                                                double result1 = MathArrays.linearCombination(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
                                                                assertEquals(0.0, result1, 0.0);
                                                                
                                                                // Test with one zero pair
                                                                double result2 = MathArrays.linearCombination(1.0, 2.0, 0.0, 0.0, 3.0, 4.0);
                                                                assertEquals(1.0*2.0 + 3.0*4.0, result2, 1e-15);
                                                                
                                                                // Test with very large values
                                                                double large = Double.MAX_VALUE / 4;
                                                                double result3 = MathArrays.linearCombination(large, large, large, large, large, large);
                                                                assertEquals(3 * large * large, result3, large * 1e-10);
                                                            }

 @Test
                                                            public void testLinearCombination_SpecialValues1() {
                                                                // Test with NaN values
                                                                double result1 = MathArrays.linearCombination(Double.NaN, 1.0, 2.0, 3.0, 4.0, 5.0);
                                                                assertTrue(Double.isNaN(result1));
                                                                
                                                                // Test with infinite values
                                                                double result2 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 2.0, 3.0, 4.0, 5.0);
                                                                assertEquals(Double.POSITIVE_INFINITY, result2, 0.0);
                                                                
                                                                double result3 = MathArrays.linearCombination(1.0, Double.POSITIVE_INFINITY, 2.0, 3.0, 4.0, 5.0);
                                                                assertEquals(Double.POSITIVE_INFINITY, result3, 0.0);
                                                                
                                                                // Test with mixed infinite values
                                                                double result4 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 
                                                                                                             Double.NEGATIVE_INFINITY, 1.0, 
                                                                                                             1.0, 1.0);
                                                                assertTrue(Double.isNaN(result4));
                                                            }

 @Test
                                                            public void testLinearCombination_CancellationEffects() {
                                                                // Test cases where cancellation occurs to verify precision handling
                                                                double a = 1.0 + 1e-10;
                                                                double b = 1.0 - 1e-10;
                                                                
                                                                // (1 + ε)*(1 - ε) = 1 - ε² ≈ 1 for small ε
                                                                double exact = a*b + b*a + (-2.0)*1.0;  // Should be -2ε² ≈ 0
                                                                double result = MathArrays.linearCombination(a, b, b, a, -2.0, 1.0);
                                                                
                                                                // Verify the high-precision method gives better results than naive computation
                                                                double naive = a*b + b*a + (-2.0)*1.0;
                                                                assertTrue(Math.abs(result - exact) < Math.abs(naive - exact));
                                                                assertEquals(-2e-20, result, 1e-25);
                                                            }

 @Test
                                                            public void testLinearCombination_Precision() {
                                                                // Test precision with values that would cause loss of precision in naive implementation
                                                                double x = 1e18;
                                                                double y = 1e-18;
                                                                
                                                                // (x + y) * (x - y) = x² - y² ≈ x² (since y² is negligible)
                                                                // But x*y would overflow in naive implementation
                                                                double exact = x*x;
                                                                double result = MathArrays.linearCombination(x, x, y, -y, 0.0, 0.0);
                                                                
                                                                assertEquals(exact, result, 0.0);
                                                            }

 @Test
                                                            public void testLinearCombination_TypicalValues2() {
                                                                // Test with typical values
                                                                double result = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0);
                                                                assertEquals(1.0*2.0 + 3.0*4.0 + 5.0*6.0 + 7.0*8.0, result, 1e-15);
                                                                
                                                                // Test with mixed signs
                                                                result = MathArrays.linearCombination(1.5, -2.5, 3.5, -4.5, 5.5, -6.5, 7.5, -8.5);
                                                                assertEquals(1.5*-2.5 + 3.5*-4.5 + 5.5*-6.5 + 7.5*-8.5, result, 1e-15);
                                                            }

 @Test
                                                            public void testLinearCombination_ExtremeValues() {
                                                                // Test with very large values
                                                                double large = 1e100;
                                                                double result = MathArrays.linearCombination(large, large, large, large, large, large, large, large);
                                                                assertEquals(4 * large * large, result, 1e85); // Relaxed delta due to magnitude
                                                                
                                                                // Test with very small values
                                                                double small = 1e-100;
                                                                result = MathArrays.linearCombination(small, small, small, small, small, small, small, small);
                                                                assertEquals(4 * small * small, result, 1e-115);
                                                            }

 @Test
                                                            public void testLinearCombination_MixedMagnitudes() {
                                                                // Test with mixed large and small values
                                                                double large = 1e100;
                                                                double small = 1e-100;
                                                                double result = MathArrays.linearCombination(large, small, small, large, large, large, small, small);
                                                                assertEquals(large*small + small*large + large*large + small*small, result, 1e-15);
                                                            }

 @Test
                                                            public void testLinearCombination_SpecialCases() {
                                                                // Test with zeros
                                                                double result = MathArrays.linearCombination(0.0, 2.0, 0.0, 4.0, 0.0, 6.0, 0.0, 8.0);
                                                                assertEquals(0.0, result, 0.0);
                                                                
                                                                // Test with ones
                                                                result = MathArrays.linearCombination(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0);
                                                                assertEquals(4.0, result, 1e-15);
                                                                
                                                                // Test with NaN values (should fall back to simple multiplication)
                                                                result = MathArrays.linearCombination(Double.NaN, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0);
                                                                assertTrue(Double.isNaN(result));
                                                            }

 @Test
                                                            public void testLinearCombination_CancellationEffects1() {
                                                                // Test cases designed to cause cancellation
                                                                double a = 1.0 + 1e-10;
                                                                double b = 1.0 - 1e-10;
                                                                
                                                                // Should be approximately 2.0
                                                                double result = MathArrays.linearCombination(a, 1.0, b, 1.0, a, -1.0, b, -1.0);
                                                                assertEquals(2.0, result, 1e-15);
                                                                
                                                                // More extreme cancellation case
                                                                double x = 1e8;
                                                                result = MathArrays.linearCombination(x+1, 1.0, x-1, 1.0, -(x+1), 1.0, -(x-1), 1.0);
                                                                assertEquals(0.0, result, 1e-15);
                                                            }

 @Test
                                                            public void testLinearCombination_InfinityHandling() {
                                                                // Test with infinite values
                                                                double result = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0);
                                                                assertTrue(Double.isInfinite(result));
                                                                
                                                                // Mixed finite and infinite
                                                                result = MathArrays.linearCombination(1.0, 1.0, Double.POSITIVE_INFINITY, 0.0, 1.0, 1.0, 1.0, 1.0);
                                                                assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                                                
                                                                // Opposite infinities should produce NaN
                                                                result = MathArrays.linearCombination(1.0, Double.POSITIVE_INFINITY, 1.0, Double.NEGATIVE_INFINITY, 
                                                                                                     1.0, 1.0, 1.0, 1.0);
                                                                assertTrue(Double.isNaN(result));
                                                            }

 @Test
                                                            public void testLinearCombination_Precision1() {
                                                                // Test precision by comparing with exact arithmetic
                                                                // Use values that would cause problems with naive implementation
                                                                double a = 1.0 + 1e-16;
                                                                double b = 1.0 - 1e-16;
                                                                
                                                                // The exact result should be 2.0
                                                                double naive = a*1.0 + b*1.0 + a*-1.0 + b*-1.0; // Would be 0.0 with naive implementation
                                                                double result = MathArrays.linearCombination(a, 1.0, b, 1.0, a, -1.0, b, -1.0);
                                                                
                                                                // The linearCombination method should give a much better result
                                                                assertEquals(2.0, result, 1e-15);
                                                                assertNotEquals(naive, result, 0.0);
                                                            }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                public void testLinearCombinationEmptyArrays() {
                    // This test will pass on mutant (throws ArrayIndexOutOfBoundsException)
                    // but fail on original (should throw DimensionMismatchException)
                    double[] emptyA = new double[0];
                    double[] emptyB = new double[0];
                    MathArrays.linearCombination(emptyA, emptyB);
                }

 @Test
                public void testLinearCombinationLength() {
                    // This test passes on both original and mutant
                    double[] a = {2.5};
                    double[] b = {3.5};
                    double expected = 2.5 * 3.5;
                    assertEquals(expected, MathArrays.linearCombination(a, b), 0.0);
                }

 @Test
                public void testLinearCombinationLongerArrays() {
                    // This test passes on both original and mutant
                    double[] a = {1.0, 2.0, 3.0};
                    double[] b = {4.0, 5.0, 6.0};
                    double expected = 1.0*4.0 + 2.0*5.0 + 3.0*6.0;
                    assertEquals(expected, MathArrays.linearCombination(a, b), 0.0);
                }

 @Test(expected = DimensionMismatchException.class)
                public void testLinearCombinationDifferentLengths() {
                    // This test passes on both original and mutant
                    double[] a = {1.0, 2.0};
                    double[] b = {1.0};
                    MathArrays.linearCombination(a, b);
                }

 @Test(expected = IllegalArgumentException.class)
                public void testLinearCombinationEmptyArray() {
                    // This should throw exception in original code
                    // But would pass with len <= 1 mutant
                    double[] a = new double[0];
                    double[] b = new double[0];
                    MathArrays.linearCombination(a, b);
                }

 @Test
                public void testLinearCombinationSingleElement() {
                    // This should work normally in both original and mutant
                    double[] a = {2.0};
                    double[] b = {3.0};
                    double expected = 6.0; // 2.0 * 3.0
                    assertEquals(expected, MathArrays.linearCombination(a, b), 1e-15);
                }

 @Test
                public void testLinearCombinationMultipleElements() {
                    // This should work normally in both original and mutant
                    double[] a = {1.0, 2.0, 3.0};
                    double[] b = {4.0, 5.0, 6.0};
                    double expected = 32.0; // 1*4 + 2*5 + 3*6
                    assertEquals(expected, MathArrays.linearCombination(a, b), 1e-15);
                }

 @Test
                public void testLinearCombinationArrayLengthZero() {
                    // Test empty arrays case that would be affected by len <= 1 mutation
                    double[] emptyA = new double[0];
                    double[] emptyB = new double[0];
                    
                    try {
                        double result = MathArrays.linearCombination(emptyA, emptyB);
                        // If we get here, the mutant len <= 1 passed (incorrectly)
                        // Original should throw exception for empty arrays
                        fail("Expected IllegalArgumentException for empty arrays");
                    } catch (IllegalArgumentException e) {
                        // This is expected behavior for original code
                        assertTrue(e.getMessage().contains("empty"));
                    }
                }

 @Test
                public void testLinearCombinationArrayLengthOne() {
                    // Test length 1 arrays - should behave same in both original and mutant
                    double[] a = {2.5};
                    double[] b = {3.5};
                    double expected = 2.5 * 3.5;
                    double result = MathArrays.linearCombination(a, b);
                    assertEquals(expected, result, 1e-15);
                }

 @Test
                public void testLinearCombinationArrayLengthTwo() {
                    // Test length >1 arrays - should behave same in both original and mutant
                    double[] a = {1.0, 2.0};
                    double[] b = {3.0, 4.0};
                    double expected = 1.0*3.0 + 2.0*4.0;
                    double result = MathArrays.linearCombination(a, b);
                    assertEquals(expected, result, 1e-15);
                }

 @Test
                public void testLinearCombinationArrayLengthCheck() {
                    // Test case for len == 1 (should pass both original and mutant)
                    double[] a1 = {1.0};
                    double[] b1 = {2.0};
                    double result1 = MathArrays.linearCombination(a1, b1);
                    assertEquals(2.0, result1, 1e-15);
                    
                    // Test case for len == 0 (should throw exception in original, might pass in mutant)
                    double[] a0 = {};
                    double[] b0 = {};
                    try {
                        MathArrays.linearCombination(a0, b0);
                        fail("Expected IllegalArgumentException for empty arrays");
                    } catch (IllegalArgumentException e) {
                        // Expected behavior for original
                    }
                    
                    // Test case for len > 1 (should pass both)
                    double[] a2 = {1.0, 2.0};
                    double[] b2 = {3.0, 4.0};
                    double result2 = MathArrays.linearCombination(a2, b2);
                    assertEquals(11.0, result2, 1e-15);
                }

 @Test
           public void testLinearCombinationDetectsProdLowMutation() {
               // Setup test data that will expose the mutation
               double[] a = {1.23456789, 2.34567891, 3.45678912};
               double[] b = {4.56789123, 5.67891234, 6.78912345};
               
               // Calculate expected value using alternative method
               double expected = 0;
               for (int i = 0; i < a.length; i++) {
                   expected += a[i] * b[i];
               }
               
               // The high-precision calculation should be very close to the expected value
               double result = MathArrays.linearCombination(a, b);
               
               // The mutation would cause significant deviation in this case
               assertEquals("Linear combination should match expected value", 
                           expected, result, 1e-15);
               
               // Additional assertion to specifically catch the mutation
               // The mutant would produce a value that's too large
               assertTrue("Result should not be larger than expected", 
                          result <= expected + 1e-15);
           }

 @Test
           public void testLinearCombinationDetectsProdLowMutation1() {
               // These values are chosen to make the low parts significant
               double a1 = 1.000000000000001;
               double b1 = 1.000000000000001;
               double a2 = 1.000000000000002;
               double b2 = 1.000000000000002;
               
               // Calculate expected value using simple multiplication (reference)
               double expected = a1 * b1 + a2 * b2;
               
               // Call the method
               double result = MathArrays.linearCombination(a1, b1, a2, b2);
               
               // The mutation will cause a significant difference in the result
               // We use a tight tolerance because we're testing high-precision calculation
               assertEquals("Mutation in prodLow calculation not detected", 
                           expected, result, 1e-30);
               
               // Additional assertion to verify the high-precision nature
               double naiveResult = a1 * b1 + a2 * b2;
               assertNotEquals("Test values don't show precision benefits", 
                              naiveResult, result, 0.0);
           }

 @Test
           public void testLinearCombinationDetectsProdLowMutation2() {
               // These values are chosen to have significant low-order bits
               // and will produce different results with the mutated calculation
               double a1 = 1.23456789012345;
               double b1 = 9.87654321098765;
               double a2 = 2.34567890123456;
               double b2 = 8.76543210987654;
               double a3 = 3.45678901234567;
               double b3 = 7.65432109876543;
               
               // Calculate expected value using simple multiplication (what the method falls back to for NaN)
               double expected = a1 * b1 + a2 * b2 + a3 * b3;
               
               // The actual implementation should be more precise than the simple multiplication
               double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
               
               // The mutated version would produce a different result due to the changed prodLow calculation
               // We verify that the actual result is indeed more precise than the simple multiplication
               // by checking it's not equal to the simple multiplication result (unless we have NaN)
               assertFalse(Double.isNaN(actual));
               
               // The key assertion - the actual result should be very close to the expected,
               // but with the mutation, it would be significantly different
               assertEquals(expected, actual, 1e-15);
               
               // Additional check - verify the result is more precise than simple multiplication
               // by comparing with a less precise calculation
               double simpleResult = a1 * b1 + a2 * b2 + a3 * b3;
               assertTrue(Math.abs(actual - expected) < Math.abs(simpleResult - expected));
           }

 @Test
           public void testLinearCombinationDetectsProdLowMutation3() {
               // These values are chosen to have significant low parts when split
               // and will make the mutation produce noticeably different results
               double a1 = 1.000000000000001;
               double b1 = 1.000000000000001;
               double a2 = 1.000000000000002;
               double b2 = 1.000000000000002;
               double a3 = 1.000000000000003;
               double b3 = 1.000000000000003;
               double a4 = 1.000000000000004;
               double b4 = 1.000000000000004;
               
               // Calculate expected value using standard arithmetic
               double expected = a1*b1 + a2*b2 + a3*b3 + a4*b4;
               
               // Call the method under test
               double result = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
               
               // The mutation will cause a significant difference in the result
               // because it affects all four product low calculations
               assertEquals("Mutant should be detected by difference in low part accumulation", 
                           expected, result, 1e-30);
               
               // Additional assertion to verify the high part is correct
               double naiveResult = a1*b1 + a2*b2 + a3*b3 + a4*b4;
               assertEquals("High part should match naive calculation", 
                           naiveResult, result, 1e-15);
           }

 @Test
          public void testLinearCombinationDetectsProdLowSumMutant() {
              // Setup test data where low-precision parts are significant
              double[] a = {1.0e-20, 2.0e-20, 3.0e-20};
              double[] b = {4.0e-20, 5.0e-20, 6.0e-20};
              
              // Calculate expected value using simple multiplication (since low parts are significant)
              double expected = 0.0;
              for (int i = 0; i < a.length; i++) {
                  expected += a[i] * b[i];
              }
              
              // Call the method
              double result = MathArrays.linearCombination(a, b);
              
              // Verify the result matches expected value with tolerance
              // The mutant would produce a completely wrong result due to subtraction
              assertEquals("Linear combination should correctly handle low-precision parts", 
                          expected, result, 1.0e-30);
              
              // Additional test with values that would show clear difference
              double[] c = {1.0 + 1.0e-17, 2.0 + 2.0e-17};
              double[] d = {3.0 + 3.0e-17, 4.0 + 4.0e-17};
              
              double expected2 = (1.0 * 3.0) + (2.0 * 4.0) + 
                                (1.0e-17 * 3.0) + (1.0 * 3.0e-17) +
                                (2.0e-17 * 4.0) + (2.0 * 4.0e-17);
              
              double result2 = MathArrays.linearCombination(c, d);
              assertEquals("Linear combination should correctly accumulate low-precision parts",
                          expected2, result2, 1.0e-30);
          }

 @Test
          public void testLinearCombinationDetectsProdLowSumMutant1() {
              // These values are chosen to produce significant low-precision components
              double a1 = 0.1;
              double b1 = 0.1;
              double a2 = 0.1;
              double b2 = 0.1;
              
              // Calculate expected value using simple multiplication (naive implementation)
              double expected = a1 * b1 + a2 * b2;
              
              // Call the method under test
              double result = MathArrays.linearCombination(a1, b1, a2, b2);
              
              // The mutant would produce a significantly different result because:
              // 1) The low-precision components are being subtracted instead of added
              // 2) For these small numbers, the low-precision components are significant
              // 3) The difference should be large enough to detect
              
              // We use a tight tolerance because the method is supposed to be high-precision
              assertEquals("Linear combination with significant low-precision components", 
                          expected, result, 1e-16);
              
              // Additional check - the result should be close to the naive implementation
              // but more precise. The mutant would fail this check.
              double naiveResult = a1 * b1 + a2 * b2;
              assertTrue("High-precision result should be more accurate than naive implementation",
                         Math.abs(result - expected) <= Math.abs(naiveResult - expected));
          }

 @Test
          public void testLinearCombinationWithSignificantLowParts() {
              // These values are chosen to have significant low parts when split by SPLIT_FACTOR
              double a1 = 1.23456789012345;
              double b1 = 9.87654321098765;
              double a2 = 2.34567890123456;
              double b2 = 8.76543210987654;
              double a3 = 3.45678901234567;
              double b3 = 7.65432109876543;
              
              // Calculate expected value using simple multiplication (the fallback case)
              double expected = a1 * b1 + a2 * b2 + a3 * b3;
              
              // The method's precise calculation should be very close to this
              double result = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
              
              // With the mutation (subtracting low parts), the result would be significantly different
              // We use a tight tolerance because the precise calculation should be very accurate
              assertEquals(expected, result, 1.0e-15);
              
              // Additionally, verify that the precise calculation is indeed more accurate than naive
              double naive = a1 * b1 + a2 * b2 + a3 * b3;
              double preciseError = Math.abs(result - expected);
              double naiveError = Math.abs(naive - expected);
              assertTrue(preciseError < naiveError);
          }

 @Test
              public void testLinearCombinationWithSignificantLowPrecisionComponents() {
                  // These values are chosen such that the low-precision components are significant
                  // and would produce noticeably different results when added vs subtracted
                  double a1 = 1.000000000000001;
                  double b1 = 1.000000000000001;
                  double a2 = 1.000000000000002;
                  double b2 = 1.000000000000002;
                  double a3 = 1.000000000000003;
                  double b3 = 1.000000000000003;
                  double a4 = 1.000000000000004;
                  double b4 = 1.000000000000004;
                  
                  // Calculate expected value using simple arithmetic (without the precision handling)
                  double expected = a1 * b1 + a2 * b2 + a3 * b3 + a4 * b4;
                  
                  // The method's result should be very close to the expected value
                  double result = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
                  
                  // With the mutation (subtracting low-precision components), the result would be significantly different
                  // We use a tight delta because we expect high precision
                  assertEquals("Linear combination with significant low-precision components failed", 
                              expected, result, 1e-15);
                  
                  // Additional assertion to specifically catch the mutant
                  // The correct implementation should be greater than the simple arithmetic result
                  // because it adds the low-precision components
                  assertTrue("Result should be greater than simple arithmetic (detects subtraction mutant)",
                            result > expected);
              }

 @Test
         public void testLinearCombinationDetectsMutant() {
             // Setup test data that will expose the mutation
             double[] a = {1.0e18, 1.0, 1.0};  // Large value followed by small values
             double[] b = {1.0, 1.0, 1.0};
             
             // Calculate expected result manually
             // Original calculation would be:
             // prodHigh = [1.0e18, 1.0, 1.0]
             // First iteration:
             // sHighPrev = 1.0e18 + 1.0 = 1.0e18 (due to floating point precision)
             // sPrime = 1.0e18 - 1.0 = 1.0e18
             // sLowSum = (1.0 - (1.0e18 - 1.0e18)) + (1.0e18 - 1.0e18) = 1.0
             // Second iteration:
             // sHighCur = 1.0e18 + 1.0 = 1.0e18
             // sPrime = 1.0e18 - 1.0 = 1.0e18
             // sLowSum += (1.0 - (1.0e18 - 1.0e18)) + (1.0e18 - 1.0e18) = 1.0 + 1.0 = 2.0
             // Final result = 1.0e18 + (0 + 2.0) = 1.0e18 + 2.0
             
             // With mutant (using + instead of -):
             // First iteration:
             // sPrime = 1.0e18 + 1.0 = 1.0e18
             // sLowSum = (1.0 - (1.0e18 - 1.0e18)) + (1.0e18 - 1.0e18) = 1.0
             // Second iteration:
             // sPrime = 1.0e18 + 1.0 = 1.0e18
             // sLowSum += (1.0 - (1.0e18 - 1.0e18)) + (1.0e18 - 1.0e18) = 1.0 + 1.0 = 2.0
             // Interestingly, for this case the mutant produces same result
             
             // Need different test case where subtraction vs addition matters
             // Let's try with values where the difference is more significant
             a = new double[]{1.0, 2.0, 3.0};
             b = new double[]{4.0, 5.0, 6.0};
             
             // Original expected result: 32.0 (4 + 10 + 18)
             // With mutant, the calculation of sPrime affects sLowSum differently
             double expected = 32.0;  // Correct result
             double result = MathArrays.linearCombination(a, b);
             
             // The mutant would produce a different result due to incorrect sPrime calculation
             assertEquals("Linear combination should match expected value", 
                         expected, result, 1.0e-15);
             
             // More precise test with values that will expose the difference
             a = new double[]{1.0e-16, 1.0e16, 1.0};
             b = new double[]{1.0e16, 1.0e-16, 1.0};
             
             // Expected result should be approximately 2.0 + 1.0e-32 (but 1.0e-32 is negligible)
             expected = 2.0;
             result = MathArrays.linearCombination(a, b);
             assertEquals("Linear combination should handle extreme value differences",
                         expected, result, 1.0e-15);
         }

 @Test
         public void testLinearCombinationWithOppositeSignProducts() {
             // Setup values where a1*b1 and a2*b2 are large but nearly cancel each other
             double a1 = 1.0e20;
             double b1 = 1.0;
             double a2 = -1.0e20;
             double b2 = 1.0 + 1.0e-15;  // Small difference to test precision
             
             // Expected result should be (a1*b1 + a2*b2) = 1.0e20 * 1.0 + (-1.0e20)*(1.0 + 1.0e-15)
             // = 1.0e20 - 1.0e20 - 1.0e5 = -1.0e5
             double expected = -1.0e5;
             
             // Actual result from the method
             double actual = MathArrays.linearCombination(a1, b1, a2, b2);
             
             // The mutation would produce a completely wrong result (approximately 2.0e20)
             // because it adds instead of subtracts in the error compensation term
             assertEquals("Linear combination with opposite signs should handle cancellation properly",
                         expected, actual, 1.0e-10);
             
             // Additional test with values that would expose the mutation more clearly
             a1 = 1.23456789e30;
             b1 = 1.0;
             a2 = -1.23456789e30;
             b2 = 1.0 + 1.0e-20;
             
             expected = -1.23456789e10;  // 1.23456789e30 * 1.0e-20
             actual = MathArrays.linearCombination(a1, b1, a2, b2);
             assertEquals("Precision test for opposite sign cancellation",
                         expected, actual, 1.0e-10);
         }

 @Test
             public void testLinearCombinationAccurateAddition() {
                 // Test case designed to detect the sPrime mutation (subtraction -> addition)
                 // Using values where accurate addition compensation is crucial
                 
                 // These values are chosen such that:
                 // 1. They have different magnitudes to cause cancellation
                 // 2. The accurate addition compensation terms would be significant
                 // 3. The mutation would cause a noticeable difference in the result
                 
                 double a1 = 1.0e20;
                 double b1 = 1.0;
                 double a2 = -1.0e20;
                 double b2 = 1.0 + 1.0e-10;
                 double a3 = 1.0;
                 double b3 = 1.0;
                 
                 // Expected result: (1.0e20 * 1.0) + (-1.0e20 * (1.0 + 1.0e-10)) + (1.0 * 1.0)
                 // = 1.0e20 - 1.0e20 - 1.0e10 + 1.0 = -1.0e10 + 1.0 ≈ -1.0e10
                 
                 double expected = -1.0e10 + 1.0;
                 double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
                 
                 // With the mutation (sPrime = sHighPrev + prodHighNext), the compensation terms
                 // would be wrong, leading to a significantly different result
                 assertEquals("Accurate addition compensation failed", expected, actual, 0.0);
                 
                 // Additional test with different values to ensure detection
                 a1 = 1.0e16;
                 b1 = 1.0;
                 a2 = -1.0e16;
                 b2 = 1.0 + 1.0e-8;
                 a3 = 1.0;
                 b3 = 1.0;
                 
                 expected = -1.0e8 + 1.0;
                 actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
                 assertEquals("Accurate addition compensation failed in second case", 
                             expected, actual, 0.0);
             }

 @Test
         public void testLinearCombinationDetectsAdditionMutant() {
             // These values are chosen to make the mutation produce a noticeably different result
             double a1 = 1.23456789;
             double b1 = 9.87654321;
             double a2 = 1.11111111;
             double b2 = 2.22222222;
             double a3 = 3.33333333;
             double b3 = 4.44444444;
             double a4 = 5.55555555;
             double b4 = 6.66666666;
             
             // Expected result calculated using standard arithmetic
             double expected = a1*b1 + a2*b2 + a3*b3 + a4*b4;
             
             // Actual result from the method (will be different if mutation is present)
             double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
             
             // The mutation will cause a significant difference in precision
             // We use a tight delta because the method is supposed to be high-precision
             assertEquals("Linear combination should be calculated with high precision", 
                         expected, actual, 1e-15);
             
             // Additional assertion to specifically catch the mutation
             // The mutated version would produce a result that's off by more than 1e-10
             assertTrue("Result precision should be better than 1e-10", 
                        Math.abs(expected - actual) < 1e-10);
         }

 @Test
        public void testLinearCombinationDetectsSignChangeMutant() {
            // Setup arrays that will produce non-trivial low-precision components
            double[] a = {0.1, 0.1, 0.1, 0.1};
            double[] b = {0.1, 0.1, 0.1, 0.1};
            
            // Calculate expected result using simple multiplication (since we can't access the internal calculations)
            double expected = 0.0;
            for (int i = 0; i < a.length; i++) {
                expected += a[i] * b[i];
            }
            
            // The mutant would produce a significantly different result due to sign change
            double actual = MathArrays.linearCombination(a, b);
            
            // Verify the result is close to expected (allowing for floating point differences)
            assertEquals("Mutant not detected - sign change in low precision components", 
                        expected, actual, 1e-15);
            
            // Additional verification that the result isn't what the mutant would produce
            double mutantResult = 0.1*0.1*4 - 4*(0.1*0.1 - Math.nextDown(0.1*0.1)); // Approximate mutant behavior
            assertNotEquals("Mutant not detected - result matches mutant output",
                           mutantResult, actual, 1e-15);
        }

 @Test
        public void testLinearCombinationDetectsSignChangeMutant1() {
            // Setup - use values that will produce significant low-precision components
            double a1 = 1.23456789012345e15;
            double b1 = 1.23456789012345e15;
            double a2 = 1.23456789012345e15;
            double b2 = 1.23456789012345e15;
            
            // Calculate expected value using standard arithmetic
            double expected = a1 * b1 + a2 * b2;
            
            // Call the method
            double actual = MathArrays.linearCombination(a1, b1, a2, b2);
            
            // Verify the result is close to expected (with tolerance for floating point differences)
            assertEquals("Linear combination should match expected value", 
                        expected, actual, 1e-10 * expected);
            
            // Additional verification that the low-precision components were significant
            double naiveResult = a1 * b1 + a2 * b2;
            assertNotEquals("Test values should produce significant low-precision components",
                           naiveResult, actual, 0.0);
            
            // The key assertion that would fail with the mutant:
            // The mutant would produce result = s12High - (prod1Low + prod2Low + s12Low)
            // which would be significantly different from expected
            double mutantResult = 2 * (a1 * b1 + a2 * b2) - actual;
            assertNotEquals("Mutant would produce different result", 
                           expected, mutantResult, 1e-10 * expected);
        }

 @Test
        public void testLinearCombinationDetectsSignMutation() {
            // These values are chosen to have significant low-precision components
            double a1 = 0.1;
            double b1 = 0.1;
            double a2 = 0.2;
            double b2 = 0.2;
            double a3 = 0.3;
            double b3 = 0.3;
            
            // Calculate expected value using simple arithmetic (reference implementation)
            double expected = a1 * b1 + a2 * b2 + a3 * b3;
            
            // Call the method under test
            double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
            
            // The mutation would make the result significantly different
            // We use a tight delta because we expect high precision
            assertEquals("Linear combination should correctly handle low-precision components",
                        expected, actual, 1e-16);
            
            // Additional check: verify the result is not just the high parts
            // If the low parts were subtracted instead of added, this would fail
            double highPartsOnly = a1 * b1 + a2 * b2 + a3 * b3;
            assertNotEquals("Result should include low-precision components",
                           highPartsOnly, actual, 1e-16);
        }

 @Test
        public void testLinearCombinationWithSignificantLowBits() {
            // These values are chosen to have significant low bits in their products
            double a1 = 1.0000000000000002;
            double b1 = 1.0000000000000002;
            double a2 = 1.0000000000000004;
            double b2 = 1.0000000000000004;
            double a3 = 1.0000000000000006;
            double b3 = 1.0000000000000006;
            double a4 = 1.0000000000000008;
            double b4 = 1.0000000000000008;
            
            // Calculate expected value using alternative implementation
            double expected = a1 * b1 + a2 * b2 + a3 * b3 + a4 * b4;
            
            // Call the method under test
            double result = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
            
            // The mutation would make the result significantly different
            // We use a tight tolerance because we expect high precision
            assertEquals("Linear combination with significant low bits should be accurate", 
                        expected, result, 1.0e-30);
            
            // Additional check - the mutated version would produce a result that's too small
            assertTrue("Result should be greater than naive implementation", 
                       result > expected);
        }

 @Test
       public void testLinearCombinationNaNCase() {
           // Setup
           double[] a = {Double.NaN, 2.0, 3.0};
           double[] b = {1.0, Double.NaN, 4.0};
           
           // Expected result is the simple dot product (NaN * 1 + 2 * NaN + 3 * 4 = NaN)
           // But the mutant would calculate (NaN * 1 - 2 * NaN - 3 * 4) which is very different
           
           // Execute
           double result = MathArrays.linearCombination(a, b);
           
           // Verify
           // The correct implementation should return NaN (since any operation with NaN is NaN)
           // The mutant would return -12.0 (completely wrong)
           assertTrue(Double.isNaN(result));
           
           // Additional test with infinite values that might get split
           double[] infA = {Double.POSITIVE_INFINITY, 1.0};
           double[] infB = {1.0, 1.0};
           double infResult = MathArrays.linearCombination(infA, infB);
           // Should be Infinity, mutant would return -Infinity
           assertEquals(Double.POSITIVE_INFINITY, infResult, 0.0);
           
           // Test with regular values that might produce NaN during calculation
           double[] c = {Double.MAX_VALUE, Double.MAX_VALUE};
           double[] d = {Double.MAX_VALUE, Double.MAX_VALUE};
           double maxResult = MathArrays.linearCombination(c, d);
           // Should be approximately 2*Double.MAX_VALUE^2, mutant would return 0
           assertFalse(Double.isNaN(maxResult));
           assertTrue(maxResult > Double.MAX_VALUE);
       }

 @Test
           public void testLinearCombinationDetectsAdditionMutation() {
               // Test with different values where sum != difference
               double a1 = 2.5;
               double b1 = 3.0;
               double a2 = 1.5;
               double b2 = 4.0;
               
               // Expected result: 2.5*3.0 + 1.5*4.0 = 7.5 + 6.0 = 13.5
               double expected = 13.5;
               
               // If mutation exists (using subtraction): 2.5*3.0 - 1.5*4.0 = 7.5 - 6.0 = 1.5
               double mutatedResult = 1.5;
               
               double actual = MathArrays.linearCombination(a1, b1, a2, b2);
               
               // This will fail if mutation exists because 13.5 != 1.5
               assertEquals("Linear combination should compute sum of products", 
                           expected, actual, 1e-15);
               
               // Additional test with negative numbers
               a1 = -2.0;
               b1 = 5.0;
               a2 = 3.0;
               b2 = -4.0;
               
               // Expected: -2*5 + 3*-4 = -10 + -12 = -22
               // Mutated: -2*5 - 3*-4 = -10 - (-12) = 2
               assertEquals("Should handle negative numbers correctly",
                           -22.0, MathArrays.linearCombination(a1, b1, a2, b2), 1e-15);
               
               // Edge case with very large numbers
               a1 = Double.MAX_VALUE/2;
               b1 = 2.0;
               a2 = Double.MAX_VALUE/2;
               b2 = 2.0;
               
               // Expected: (MAX/2)*2 + (MAX/2)*2 = MAX + MAX = Infinity
               // Mutated: (MAX/2)*2 - (MAX/2)*2 = MAX - MAX = 0
               assertEquals("Should handle large numbers correctly",
                           Double.POSITIVE_INFINITY, 
                           MathArrays.linearCombination(a1, b1, a2, b2), 1e-15);
           }

 @Test
           public void testLinearCombinationDetectsSignMutation1() {
               // Test case with mixed positive and negative numbers
               // Original should return: (2*3) + (-4*5) + (6*-7) = 6 - 20 - 42 = -56
               // Mutated would return: -6 + 20 + 42 = 56 (complete sign flip)
               double a1 = 2.0, b1 = 3.0;
               double a2 = -4.0, b2 = 5.0;
               double a3 = 6.0, b3 = -7.0;
               
               double expected = -56.0; // Correct result
               double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
               
               // Verify exact value to catch sign flip
               assertEquals("Linear combination sign incorrect", expected, actual, 0.0);
               
               // Additional verification that it's not the positive version
               assertNotEquals("Mutation not detected - result has wrong sign", 
                              Math.abs(expected), actual, 0.0);
           }

 @Test
           public void testLinearCombinationWithAllPositive() {
               // Test case with all positive numbers
               // Original: (1*2) + (3*4) + (5*6) = 2 + 12 + 30 = 44
               // Mutated: -2 -12 -30 = -44
               double a1 = 1.0, b1 = 2.0;
               double a2 = 3.0, b2 = 4.0;
               double a3 = 5.0, b3 = 6.0;
               
               double expected = 44.0;
               double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
               
               assertEquals("Linear combination incorrect for all positive", 
                           expected, actual, 0.0);
           }

 @Test
           public void testLinearCombinationWithZeroValues() {
               // Test case with zero values mixed in
               // Original: (0*2) + (3*0) + (5*6) = 0 + 0 + 30 = 30
               // Mutated: -0 -0 -30 = -30
               double a1 = 0.0, b1 = 2.0;
               double a2 = 3.0, b2 = 0.0;
               double a3 = 5.0, b3 = 6.0;
               
               double expected = 30.0;
               double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
               
               assertEquals("Linear combination incorrect with zero values", 
                           expected, actual, 0.0);
           }

 @Test
           public void testLinearCombinationDetectsSignMutation2() {
               // Test case that will clearly show the difference between += and -=
               // Using simple values where a1*b1 + a2*b2 + a3*b3 + a4*b4 ≠ a1*b1 - a2*b2 - a3*b3 - a4*b4
               
               // Case 1: All positive values
               double result1 = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0);
               assertEquals(1.0*2.0 + 3.0*4.0 + 5.0*6.0 + 7.0*8.0, result1, 1e-15);
               
               // Case 2: Mixed positive and negative values
               double result2 = MathArrays.linearCombination(1.0, -2.0, -3.0, 4.0, 5.0, -6.0, -7.0, 8.0);
               assertEquals(1.0*-2.0 + -3.0*4.0 + 5.0*-6.0 + -7.0*8.0, result2, 1e-15);
               
               // Case 3: Very small values (tests precision handling)
               double result3 = MathArrays.linearCombination(1e-20, 2e-20, 3e-20, 4e-20, 
                                                             5e-20, 6e-20, 7e-20, 8e-20);
               assertEquals(1e-20*2e-20 + 3e-20*4e-20 + 5e-20*6e-20 + 7e-20*8e-20, 
                           result3, 1e-35);
               
               // Case 4: Very large values (tests overflow handling)
               double result4 = MathArrays.linearCombination(1e20, 2e20, 3e20, 4e20, 
                                                            5e20, 6e20, 7e20, 8e20);
               assertEquals(1e20*2e20 + 3e20*4e20 + 5e20*6e20 + 7e20*8e20, 
                           result4, 1e35);
               
               // Case 5: NaN handling path
               double result5 = MathArrays.linearCombination(Double.NaN, 1.0, 1.0, 1.0, 
                                                            1.0, 1.0, 1.0, 1.0);
               assertEquals(Double.NaN, result5, 0.0);
           }

 @Test
      public void testLinearCombinationDetectsSplitFactorMutation() {
          // Setup test data that will expose the mutation
          double[] a = {1.0, 2.0, 3.0};
          double[] b = {4.0, 5.0, 6.0};
          
          // Calculate expected result (using the correct multiplication behavior)
          double expected = 0.0;
          for (int i = 0; i < a.length; i++) {
              expected += a[i] * b[i];
          }
          
          // Call the method and get actual result
          double actual = MathArrays.linearCombination(a, b);
          
          // The mutation will cause a different result because:
          // - The high/low parts will be calculated incorrectly
          // - The error compensation will be wrong
          // - The final result will differ from the expected dot product
          assertEquals("Linear combination should correctly calculate dot product", 
                      expected, actual, 1e-15);
          
          // Additional test with values that would show more dramatic difference
          double[] largeA = {1e100, 2e100, 3e100};
          double[] largeB = {4e100, 5e100, 6e100};
          double expectedLarge = 0.0;
          for (int i = 0; i < largeA.length; i++) {
              expectedLarge += largeA[i] * largeB[i];
          }
          double actualLarge = MathArrays.linearCombination(largeA, largeB);
          assertEquals("Linear combination should handle large numbers correctly",
                      expectedLarge, actualLarge, 1e285);
      }

 @Test
      public void testLinearCombinationDetectsSplitFactorMutation1() {
          // Use large values where multiplication vs addition with SPLIT_FACTOR makes a big difference
          double a1 = 1e20;
          double b1 = 1e20;
          double a2 = 1e20;
          double b2 = 1e20;
          
          // Expected result using correct multiplication (a1*b1 + a2*b2)
          double expected = a1 * b1 + a2 * b2;
          
          // Actual result from the method (will be wrong if mutation exists)
          double actual = MathArrays.linearCombination(a1, b1, a2, b2);
          
          // The mutation will cause a significant difference in results
          assertEquals("Mutation should be detected by difference in results", 
                      expected, actual, 1e-10);
          
          // Additional test with different values to ensure robustness
          a1 = 123456789.0;
          b1 = 987654321.0;
          a2 = 555555555.0;
          b2 = 111111111.0;
          expected = a1 * b1 + a2 * b2;
          actual = MathArrays.linearCombination(a1, b1, a2, b2);
          assertEquals("Mutation should be detected with different values",
                      expected, actual, 1e-10);
      }

 @Test
      public void testLinearCombinationDetectsSplitFactorMutation2() {
          // These values are chosen because:
          // 1. They are large enough to require precise calculation
          // 2. The difference between multiplication and addition is significant
          // 3. They will expose errors in the splitting algorithm
          double a1 = 1.23456789e8;
          double b1 = 9.87654321e8;
          double a2 = 1.11111111e8;
          double b2 = 2.22222222e8;
          double a3 = 3.33333333e8;
          double b3 = 4.44444444e8;
          
          // Calculate expected value using standard arithmetic
          double expected = a1 * b1 + a2 * b2 + a3 * b3;
          
          // Call the method under test
          double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
          
          // The mutation will cause a significant difference in results
          // We use a tight delta because the method is supposed to be high precision
          assertEquals("Linear combination should be calculated precisely", 
                      expected, actual, 1.0e-10);
          
          // Additional assertion to verify the error would be large with mutation
          // With the mutation, the error would typically be > 1e6
          assertTrue("Precision should be very high", 
                     Math.abs(expected - actual) < 1.0e-10);
      }

 @Test
          public void testLinearCombinationDetectsSplitFactorMutation3() {
              // Choose values where multiplication vs addition of SPLIT_FACTOR makes a big difference
              double a1 = 1.0e8;
              double b1 = 1.0e8;
              double a2 = 1.0e8;
              double b2 = 1.0e8;
              double a3 = 1.0e8;
              double b3 = 1.0e8;
              double a4 = 1.0e8;
              double b4 = 1.0e8;
              
              // Expected result when using correct multiplication (original code)
              double expected = a1 * b1 + a2 * b2 + a3 * b3 + a4 * b4;
              
              // Calculate with original method
              double originalResult = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
              
              // The mutation would produce a completely different result because:
              // - Splitting would be wrong (using addition instead of multiplication)
              // - All prodHigh and prodLow calculations would be incorrect
              // - The final sum would accumulate these errors
              
              // Verify the original method produces the expected result
              assertEquals(expected, originalResult, 0.0);
              
              // If the mutation was present, the result would be significantly different
              // For these large values, the mutated version would produce a completely wrong result
              // The assertion would fail if the mutation was present
          }

 @Test
     public void testLinearCombinationDetectsProductToSumMutant() {
         // Setup test data where products and sums differ significantly
         double[] a = {2.0, 3.0, 4.0};
         double[] b = {5.0, 6.0, 7.0};
         
         // Expected result is dot product: 2*5 + 3*6 + 4*7 = 10 + 18 + 28 = 56
         double expected = 56.0;
         
         // Actual result from method (will be wrong with mutant)
         double actual = MathArrays.linearCombination(a, b);
         
         // Assert exact equality since we're using simple values
         assertEquals("Linear combination should calculate correct dot product", 
                     expected, actual, 0.0);
         
         // Additional check with different values
         double[] c = {1.5, 2.5};
         double[] d = {3.5, 4.5};
         assertEquals(1.5*3.5 + 2.5*4.5, 
                     MathArrays.linearCombination(c, d), 
                     0.0);
     }

 @Test
     public void testLinearCombinationDetectsMultiplicationMutant() {
         // Test with values where multiplication and addition give different results
         double a1 = 2.0;
         double b1 = 3.0;
         double a2 = 4.0;
         double b2 = 5.0;
         
         // Expected result: 2*3 + 4*5 = 6 + 20 = 26
         // Mutant would calculate: 2+3 + 4+5 = 5 + 9 = 14
         double expected = 26.0;
         double actual = MathArrays.linearCombination(a1, b1, a2, b2);
         
         // Assert with delta for floating point comparison
         assertEquals("Linear combination should use multiplication, not addition", 
                     expected, actual, 1e-15);
         
         // Additional test case with negative numbers
         a1 = -2.0;
         b1 = 3.0;
         a2 = 4.0;
         b2 = -5.0;
         
         // Expected: -2*3 + 4*-5 = -6 + -20 = -26
         // Mutant: -2+3 + 4+-5 = 1 + -1 = 0
         expected = -26.0;
         actual = MathArrays.linearCombination(a1, b1, a2, b2);
         assertEquals("Linear combination with negative numbers should use multiplication", 
                     expected, actual, 1e-15);
     }

 @Test
         public void testLinearCombinationDetectsMultiplicationMutant1() {
             // Test case where product is very different from sum
             double a1 = 10.0, b1 = 20.0;  // 10*20=200 vs 10+20=30
             double a2 = 30.0, b2 = 40.0;  // 30*40=1200 vs 30+40=70
             double a3 = 50.0, b3 = 60.0;  // 50*60=3000 vs 50+60=110
             
             // Expected result is sum of products: 200 + 1200 + 3000 = 4400
             double expected = a1 * b1 + a2 * b2 + a3 * b3;
             
             // Actual result from method (would be 30+70+110=210 if mutant survives)
             double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
             
             // Assert with delta for floating point comparison
             assertEquals("Linear combination should compute sum of products", 
                         expected, actual, 1e-10);
             
             // Additional test with negative numbers
             double a4 = -5.0, b4 = 3.0;  // -5*3=-15 vs -5+3=-2
             double a5 = 2.0, b5 = -4.0;  // 2*-4=-8 vs 2+-4=-2
             double a6 = -1.0, b6 = -2.0; // -1*-2=2 vs -1+-2=-3
             
             expected = a4 * b4 + a5 * b5 + a6 * b6;
             actual = MathArrays.linearCombination(a4, b4, a5, b5, a6, b6);
             assertEquals("Linear combination should handle negative numbers correctly",
                         expected, actual, 1e-10);
         }

 @Test
     public void testLinearCombinationDetectsMultiplicationMutation() {
         // Test values where multiplication and addition produce different results
         double a1 = 2.0, b1 = 3.0;  // 2*3=6 vs 2+3=5
         double a2 = 4.0, b2 = 5.0;  // 4*5=20 vs 4+5=9
         double a3 = 6.0, b3 = 7.0;  // 6*7=42 vs 6+7=13
         double a4 = 8.0, b4 = 9.0;  // 8*9=72 vs 8+9=17
         
         // Expected result: 2*3 + 4*5 + 6*7 + 8*9 = 6 + 20 + 42 + 72 = 140
         double expected = 140.0;
         
         // If mutation exists (using addition instead of multiplication):
         // 2+3 + 4+5 + 6+7 + 8+9 = 5 + 9 + 13 + 17 = 44
         
         double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
         
         // This will fail if mutation exists (44 vs 140)
         assertEquals("Linear combination should use multiplication, not addition", 
                     expected, actual, 1e-15);
         
         // Additional verification with different values
         double a = 10.0, b = 0.5;  // 10*0.5=5 vs 10+0.5=10.5
         double singleTermResult = MathArrays.linearCombination(a, b, 0, 0, 0, 0, 0, 0);
         assertEquals("Single term should be product", 
                     a * b, singleTermResult, 1e-15);
     }

 @Test
    public void testLinearCombinationDetectsProdLowSumMutation() {
        // Setup arrays with values that will produce significant low-precision components
        double[] a = {1.1, 2.2, 3.3};
        double[] b = {4.4, 5.5, 6.6};
        
        // Calculate expected result using naive implementation
        double expected = 0;
        for (int i = 0; i < a.length; i++) {
            expected += a[i] * b[i];
        }
        
        // Call the method under test
        double actual = MathArrays.linearCombination(a, b);
        
        // Verify the result matches expected within reasonable tolerance
        assertEquals("Linear combination result incorrect - possible prodLowSum mutation", 
                    expected, actual, 1e-15);
        
        // Additional verification - test with values that would make the mutation obvious
        double[] c = {0.1, 0.1, 0.1};
        double[] d = {0.1, 0.1, 0.1};
        double expectedSmall = 0.03; // 0.1*0.1*3
        double actualSmall = MathArrays.linearCombination(c, d);
        
        // The mutation would make this result negative (-0.03)
        assertEquals("Small value combination incorrect - definite prodLowSum mutation",
                    expectedSmall, actualSmall, 1e-15);
    }

 @Test
    public void testLinearCombinationWithSignificantLowParts1() {
        // Values chosen to produce significant low-precision components
        double a1 = 0.1;
        double b1 = 0.1;
        double a2 = 0.1;
        double b2 = 0.1;
        
        // Expected result using standard arithmetic (less precise but good enough for this test)
        double expected = a1 * b1 + a2 * b2;
        
        // Actual result from the method
        double actual = MathArrays.linearCombination(a1, b1, a2, b2);
        
        // The mutant would produce a significantly different result due to wrong accumulation
        assertEquals("Linear combination with significant low parts should be accurate", 
                    expected, actual, 1e-16);
        
        // Additional test with values that would make the error more pronounced
        a1 = Math.nextUp(1.0) - 1.0;  // Small number just above 0
        b1 = Math.nextUp(1.0) - 1.0;
        a2 = Math.nextUp(1.0) - 1.0;
        b2 = Math.nextUp(1.0) - 1.0;
        
        expected = a1 * b1 + a2 * b2;
        actual = MathArrays.linearCombination(a1, b1, a2, b2);
        
        // The mutant would fail this assertion as the error would be doubled
        assertEquals("Linear combination with very small numbers should be accurate",
                    expected, actual, 1e-16);
    }

 @Test
    public void testLinearCombinationWithSignificantLowBits1() {
        // These values are chosen to have significant low-precision components
        double a1 = 1.2345678901234567e100;
        double b1 = 9.8765432109876543e100;
        double a2 = 1.1111111111111111e100;
        double b2 = 8.8888888888888888e100;
        double a3 = 7.7777777777777777e100;
        double b3 = 6.6666666666666666e100;
        
        // Calculate expected result using simple arithmetic (naive implementation)
        double expected = a1 * b1 + a2 * b2 + a3 * b3;
        
        // Call the method under test
        double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
        
        // The mutant would produce a significantly different result due to subtracting low bits
        // We use a tight tolerance because the method is supposed to be high precision
        assertEquals("Linear combination with significant low bits should match expected value", 
                    expected, actual, expected * 1.0e-30);
        
        // Additional check that the result isn't wildly off (which the mutant would be)
        assertTrue("Result should be in reasonable range", 
                   Math.abs(actual - expected) < Math.abs(expected) * 1.0e-15);
    }

 @Test
        public void testLinearCombinationWithSignificantLowParts2() {
            // These values are chosen to have significant low-precision parts
            double a1 = 0x1.0p53 + 1;  // 2^53 + 1 (has non-zero low part)
            double b1 = 1.0;
            double a2 = 0x1.0p53 + 2;  // 2^53 + 2
            double b2 = 1.0;
            double a3 = 0x1.0p53 + 3;  // 2^53 + 3
            double b3 = 1.0;
            double a4 = 0x1.0p53 + 4;  // 2^53 + 4
            double b4 = 1.0;
    
            // Expected result is (2^53+1)*1 + (2^53+2)*1 + (2^53+3)*1 + (2^53+4)*1
            // = 4*2^53 + 10
            double expected = 4 * (1L << 53) + 10;
            
            // Calculate with the original method
            double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
            
            // The mutant would subtract the low parts instead of adding them,
            // resulting in a significantly different value
            assertEquals("Linear combination with significant low parts failed", 
                        expected, actual, 0.0);
            
            // Additional check with values that would show the error more clearly
            // Using numbers where the low parts would accumulate differently
            double a = 0x1.0p26 + 1;  // Numbers that will have significant low parts when split
            double b = 0x1.0p26 + 1;
            double smallTest = MathArrays.linearCombination(a, b, a, b, a, b, a, b);
            double expectedSmall = 4 * (a * b);
            assertEquals("Small value linear combination failed", 
                        expectedSmall, smallTest, 1e-10);
        }

 @Test
   public void testLinearCombinationDetectsSubtractionMutant() {
       // Setup test data that will expose the mutation
       double[] a = {1.0e100, 1.0e100, 1.0e100};
       double[] b = {1.0e100, 1.0e100, 1.0e100};
       
       // Expected result is 3.0e200 (sum of 1.0e100 * 1.0e100 three times)
       // With the mutant (using subtraction), the result would be significantly different
       double expected = 3.0e200;
       double actual = MathArrays.linearCombination(a, b);
       
       // Verify the result matches expected value with a small tolerance
       assertEquals("Linear combination should correctly handle large values", 
                   expected, actual, expected * 1.0e-15);
       
       // Additional test case with different values to ensure robustness
       double[] c = {1.23456789e50, 9.87654321e50, 1.11111111e50};
       double[] d = {9.87654321e50, 1.23456789e50, 1.11111111e50};
       expected = (1.23456789e50 * 9.87654321e50) + 
                  (9.87654321e50 * 1.23456789e50) + 
                  (1.11111111e50 * 1.11111111e50);
       actual = MathArrays.linearCombination(c, d);
       assertEquals("Linear combination should maintain high precision", 
                   expected, actual, expected * 1.0e-15);
   }

 @Test
   public void testLinearCombinationDetectsAdditionMutation1() {
       // Test case designed to catch the addition->subtraction mutation
       // Using values where a1*b1 and a2*b2 are significant but not extreme
       double a1 = 1.23456789;
       double b1 = 9.87654321;
       double a2 = 5.43219876;
       double b2 = 3.45678912;
       
       // Expected result using correct addition
       double expected = a1 * b1 + a2 * b2;
       
       // Actual result from the method (would be different if mutation is present)
       double actual = MathArrays.linearCombination(a1, b1, a2, b2);
       
       // Verify the result matches expected within reasonable precision
       assertEquals("Linear combination should correctly compute a1*b1 + a2*b2", 
                   expected, actual, 1e-15);
       
       // Additional verification - check that the result is not what we'd get with subtraction
       double mutatedExpected = a1 * b1 - a2 * b2;
       assertNotEquals("Result should not match mutated version (subtraction)", 
                      mutatedExpected, actual, 1e-15);
       
       // Edge case with one product being negative
       double a3 = -2.3456789;
       double b3 = 4.5678912;
       double a4 = 6.7891234;
       double b4 = -8.9123456;
       expected = a3 * b3 + a4 * b4;
       actual = MathArrays.linearCombination(a3, b3, a4, b4);
       assertEquals("Should handle negative products correctly", 
                   expected, actual, 1e-15);
   }

 @Test
   public void testLinearCombinationDetectsAdditionMutant1() {
       // Test case designed to catch the addition->subtraction mutant
       // Using values where sum and difference would produce very different results
       
       // Case 1: All positive numbers
       double a1 = 2.0, b1 = 3.0;  // product = 6.0
       double a2 = 4.0, b2 = 5.0;  // product = 20.0
       double a3 = 6.0, b3 = 7.0;  // product = 42.0
       
       // Original should return 6 + 20 + 42 = 68
       // Mutant would return 6 - 20 + 42 = 28
       double expected = 68.0;
       double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
       assertEquals("Linear combination should correctly sum products", expected, actual, 1e-15);
       
       // Case 2: Mixed positive and negative numbers
       a1 = 1.5; b1 = 2.5;  // product = 3.75
       a2 = -3.5; b2 = 4.5; // product = -15.75
       a3 = 5.5; b3 = 6.5;  // product = 35.75
       
       // Original should return 3.75 - 15.75 + 35.75 = 23.75
       // Mutant would return 3.75 - (-15.75) + 35.75 = 55.25
       expected = 23.75;
       actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
       assertEquals("Linear combination should handle mixed signs correctly", expected, actual, 1e-15);
       
       // Case 3: Values that would cause significant cancellation
       a1 = 1e20; b1 = 1.0;
       a2 = 1.0; b2 = -1e20;
       a3 = 1.0; b3 = 1.0;
       
       // Original should return 1e20 - 1e20 + 1 = 1
       // Mutant would return 1e20 - (-1e20) + 1 ≈ 2e20
       expected = 1.0;
       actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
       assertEquals("Linear combination should handle cancellation properly", expected, actual, 1e-15);
   }

 @Test
   public void testLinearCombinationDetectsAdditionMutant2() {
       // Values chosen so that the sum and difference would produce significantly different results
       double a1 = 1.5, b1 = 2.5;  // product = 3.75
       double a2 = 3.5, b2 = 4.5;  // product = 15.75
       double a3 = 5.5, b3 = 6.5;  // product = 35.75
       double a4 = 7.5, b4 = 8.5;  // product = 63.75
       
       // Expected result: 3.75 + 15.75 + 35.75 + 63.75 = 119.0
       double expected = 119.0;
       
       // With the mutant (using subtraction), the calculation would be:
       // First step: 3.75 - 15.75 = -12.0 (wrong)
       // Second step: -12.0 - 35.75 = -47.75 (wrong)
       // Third step: -47.75 - 63.75 = -111.5 (wrong)
       // Final result would be significantly different
       
       double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
       
       // Assert with delta to account for potential floating-point precision differences
       assertEquals("Linear combination should correctly sum products", 
                   expected, actual, 1e-15);
       
       // Additional assertion to ensure the result is positive (mutant would produce negative)
       assertTrue("Result should be positive", actual > 0);
   }

 @Test
  public void testLinearCombinationDetectsSLowSumMutation() {
      // Setup arrays that will produce significant low-order bits
      double[] a = {1.0, 0.1, 0.01};
      double[] b = {1.0, 0.1, 0.01};
      
      // Calculate expected result using simple multiplication
      double expected = 0;
      for (int i = 0; i < a.length; i++) {
          expected += a[i] * b[i];
      }
      
      // Call the method - the mutation would make the result diverge from expected
      double result = MathArrays.linearCombination(a, b);
      
      // The original method should be very close to the expected value
      // We use a tight delta because the high-precision method should be accurate
      assertEquals(expected, result, 1e-15);
      
      // Additional verification - the result should not be exactly the same as simple multiplication
      // because the high-precision method does extra work
      assertNotEquals(expected, result);
      
      // Test with another set of values
      double[] c = {1.0, 2.0, 3.0};
      double[] d = {4.0, 5.0, 6.0};
      double expected2 = 0;
      for (int i = 0; i < c.length; i++) {
          expected2 += c[i] * d[i];
      }
      double result2 = MathArrays.linearCombination(c, d);
      assertEquals(expected2, result2, 1e-15);
      assertNotEquals(expected2, result2);
  }

 @Test
  public void testLinearCombinationDetectsLowSumMutant() {
      // These values are chosen to produce significant low-precision components
      double a1 = 1.0000000000000002;
      double b1 = 1.0000000000000004;
      double a2 = 1.0000000000000006;
      double b2 = 1.0000000000000008;
      
      // Expected value calculated using exact arithmetic
      double expected = (a1 * b1) + (a2 * b2);
      
      // The mutant would produce a different result because:
      // Original: result = s12High + (prod1Low + prod2Low + s12Low)
      // Mutant:   result = s12High - (prod1Low + prod2Low + s12Low)
      double actual = MathArrays.linearCombination(a1, b1, a2, b2);
      
      // Verify the result matches expected value with high precision
      assertEquals(expected, actual, 1e-30);
      
      // Additional verification that the low components were significant
      double naive = a1 * b1 + a2 * b2;
      assertNotEquals(naive, actual, 1e-30);
  }

 @Test
  public void testLinearCombinationDetectsLowSumMutation() {
      // These values are chosen to have significant low-precision components
      // and will make the mutation produce a clearly different result
      double a1 = 1.0000000000000002;
      double b1 = 1.0000000000000004;
      double a2 = 1.0000000000000006;
      double b2 = 1.0000000000000008;
      double a3 = 1.0000000000000010;
      double b3 = 1.0000000000000012;
      
      // Calculate expected value using simple multiplication (naive implementation)
      double expected = a1 * b1 + a2 * b2 + a3 * b3;
      
      // Call the method under test
      double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
      
      // The mutation would cause the low-precision parts to be subtracted instead of added,
      // resulting in a value significantly different from expected
      assertEquals("Mutation in low sum calculation not detected", 
                   expected, actual, 1e-15);
      
      // Additional assertion to verify the high-precision nature is working
      // The method should be more precise than the naive implementation
      double naive = a1 * b1 + a2 * b2 + a3 * b3;
      assertTrue("Method should be more precise than naive implementation",
                 Math.abs(actual - naive) < 1e-30);
  }

 @Test
  public void testLinearCombinationWithSignificantLowParts3() {
      // These values are chosen to produce significant low-precision components
      double a1 = 1.000000000000001;
      double b1 = 1.000000000000001;
      double a2 = 1.000000000000002;
      double b2 = 1.000000000000002;
      double a3 = 1.000000000000003;
      double b3 = 1.000000000000003;
      double a4 = 1.000000000000004;
      double b4 = 1.000000000000004;
      
      // Calculate expected value using simple arithmetic (less precise but good enough for this test)
      double expected = a1*b1 + a2*b2 + a3*b3 + a4*b4;
      
      // Call the method
      double result = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
      
      // Verify the result is very close to expected (with tolerance for floating point differences)
      assertEquals(expected, result, 1e-15);
      
      // Additional verification that the low parts are significant
      // If the mutant is present, the difference will be much larger than tolerance
      double naiveResult = a1*b1 + a2*b2 + a3*b3 + a4*b4;
      assertTrue(Math.abs(result - naiveResult) > 1e-20);
  }

 @Test
 public void testLinearCombinationDetectsSignMutation3() {
     // Setup test data where low-precision components are significant
     double[] a = {1.0e-100, 2.0e100, 3.0e100};
     double[] b = {4.0e100, 5.0e-100, 6.0e-100};
     
     // Calculate expected result manually
     double expected = 0.0;
     for (int i = 0; i < a.length; i++) {
         expected += a[i] * b[i];
     }
     
     // The mutation would produce a completely wrong result because:
     // sHighPrev would be approximately 4.0e100 (from 1.0e-100 * 4.0e100)
     // prodLowSum + sLowSum would contain the other significant terms
     // Using subtraction instead of addition would make the result completely wrong
     
     double actual = MathArrays.linearCombination(a, b);
     
     // Verify exact equality since we're testing the exact computation
     assertEquals("Linear combination should correctly sum all components", 
                 expected, actual, 0.0);
     
     // Additional verification that the result isn't what the mutant would produce
     double mutantResult = 4.0e100 - (2.0e100*5.0e-100 + 3.0e100*6.0e-100 
                         + (2.0e100*5.0e-100 + 3.0e100*6.0e-100));
     assertNotEquals("Test should detect the subtraction mutant", 
                    mutantResult, actual, 0.0);
 }

 @Test
 public void testLinearCombinationDetectsSubtractionMutant1() {
     // These values are chosen to produce significant low-order bits in the calculation
     double a1 = 1.0000000000000002;
     double b1 = 1.0000000000000004;
     double a2 = 1.0000000000000006;
     double b2 = 1.0000000000000008;
     
     // Calculate expected value using standard arithmetic
     double expected = a1 * b1 + a2 * b2;
     
     // Call the method (will use the precise calculation unless NaN occurs)
     double actual = MathArrays.linearCombination(a1, b1, a2, b2);
     
     // Verify the result is close to expected (with tolerance for floating point differences)
     assertEquals("Linear combination should match expected value", 
                 expected, actual, 1e-15);
     
     // Additional verification that the precise calculation was used
     assertFalse("Result should not be NaN", Double.isNaN(actual));
     
     // This test will fail if the mutant is present because:
     // - The low-order bits will be subtracted instead of added
     // - The difference will be large enough to detect
     // - The standard arithmetic result differs significantly from the mutated result
 }

 @Test
 public void testLinearCombinationDetectsSignFlipInCorrectionTerms() {
     // These values are chosen to produce significant low-precision correction terms
     double a1 = 1.23456789012345;
     double b1 = 9.87654321098765;
     double a2 = 1.11111111111111;
     double b2 = 2.22222222222222;
     double a3 = 3.33333333333333;
     double b3 = 4.44444444444444;
     
     // Calculate expected result using the naive implementation
     double naiveResult = a1 * b1 + a2 * b2 + a3 * b3;
     
     // Calculate result using the tested method
     double result = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
     
     // The accurate result should be different from the naive result
     assertNotEquals(naiveResult, result, 0.0);
     
     // Calculate what the mutated version would produce
     double mutatedResult = (a1 * b1 + a2 * b2 + a3 * b3) - 
                          ((result - (a1 * b1 + a2 * b2 + a3 * b3)) * 2);
     
     // Verify our result is not equal to what the mutated version would produce
     assertNotEquals(mutatedResult, result, 1e-10);
     
     // Additional verification - check against known accurate value
     // Computed using BigDecimal arithmetic for reference
     double expected = 29.53086419753086;
     assertEquals(expected, result, 1e-14);
 }

 @Test
 public void testLinearCombinationWithNonExactValues() {
     // These values are chosen to produce significant low-precision correction terms
     double a1 = 0.1;
     double b1 = 0.1;
     double a2 = 0.2;
     double b2 = 0.2;
     double a3 = 0.3;
     double b3 = 0.3;
     double a4 = 0.4;
     double b4 = 0.4;
     
     // Expected result (0.1*0.1 + 0.2*0.2 + 0.3*0.3 + 0.4*0.4)
     double expected = 0.1*0.1 + 0.2*0.2 + 0.3*0.3 + 0.4*0.4;
     
     // Calculate using the method
     double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
     
     // The mutant would subtract the correction terms instead of adding them,
     // resulting in a significantly different value
     assertEquals(expected, actual, 1e-15);
     
     // Additional assertion to specifically catch the mutant
     // The mutant's result would be approximately s1234High - (correction terms)
     // which would be much smaller than the correct result
     assertTrue(actual > expected * 0.9); // Mutant would fail this
 }

}
