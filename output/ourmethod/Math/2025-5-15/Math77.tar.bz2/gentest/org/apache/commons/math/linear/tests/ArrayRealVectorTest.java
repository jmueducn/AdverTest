package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.util.MathUtils;
 
public class ArrayRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                               public void testMapInvToSelf_NormalValues() {
                                                                                   double[] input = {1.0, 2.0, 4.0, -1.0, -2.0};
                                                                                   double[] expected = {1.0, 0.5, 0.25, -1.0, -0.5};
                                                                                   
                                                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                                                   ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                                   
                                                                                   assertArrayEquals(expected, result.getData(), 0.0001);
                                                                                   // Verify it's the same object (returned this)
                                                                                   assertSame(vector, result);
                                                                               }

 @Test
                                                                               public void testMapInvToSelf_SmallNumbers() {
                                                                                   double[] input = {1e-10, -1e-10, 1e10, -1e10};
                                                                                   double[] expected = {1e10, -1e10, 1e-10, -1e-10};
                                                                                   
                                                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                                                   ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                                   
                                                                                   assertArrayEquals(expected, result.getData(), 0.0001);
                                                                               }

 @Test
                                                                               public void testMapInvToSelf_NaNHandling() {
                                                                                   double[] input = {1.0, Double.NaN, 2.0};
                                                                                   double[] expected = {1.0, Double.NaN, 0.5};
                                                                                   
                                                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                                                   ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                                   
                                                                                   assertArrayEquals(expected, result.getData(), 0.0001);
                                                                                   assertTrue(Double.isNaN(result.getData()[1]));
                                                                               }

 @Test
                                                                               public void testMapInvToSelf_InfinityHandling() {
                                                                                   double[] input = {1.0, Double.POSITIVE_INFINITY, 0.5};
                                                                                   double[] expected = {1.0, 0.0, 2.0};
                                                                                   
                                                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                                                   ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                                   
                                                                                   assertArrayEquals(expected, result.getData(), 0.0001);
                                                                               }

 @Test
                                                                               public void testMapInvToSelf_EmptyVector() {
                                                                                   double[] input = {};
                                                                                   
                                                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                                                   ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                                   
                                                                                   assertEquals(0, result.getDimension());
                                                                                   assertSame(vector, result);
                                                                               }

 @Test
                                                                               public void testMapInvToSelf_SingleElement() {
                                                                                   double[] input = {5.0};
                                                                                   double[] expected = {0.2};
                                                                                   
                                                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                                                   ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                                   
                                                                                   assertArrayEquals(expected, result.getData(), 0.0001);
                                                                               }

 @Test
                                                                               public void testGetLInfNorm_EmptyArray() {
                                                                                   ArrayRealVector vector = new ArrayRealVector(new double[0]);
                                                                                   assertEquals(0.0, vector.getLInfNorm(), 0.0);
                                                                               }

 @Test
                                                                               public void testGetLInfNorm_SingleElement() {
                                                                                   ArrayRealVector vector = new ArrayRealVector(new double[]{5.0});
                                                                                   assertEquals(5.0, vector.getLInfNorm(), 0.0);
                                                                                   
                                                                                   vector = new ArrayRealVector(new double[]{-3.0});
                                                                                   assertEquals(3.0, vector.getLInfNorm(), 0.0);
                                                                               }

 @Test
                                                                               public void testGetLInfNorm_AllZeros() {
                                                                                   ArrayRealVector vector = new ArrayRealVector(new double[]{0.0, 0.0, 0.0});
                                                                                   assertEquals(0.0, vector.getLInfNorm(), 0.0);
                                                                               }

 @Test
                                                                               public void testGetLInfNorm_PositiveValues() {
                                                                                   ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, 2.5, 3.2, 1.8});
                                                                                   assertEquals(3.2, vector.getLInfNorm(), 0.0);
                                                                               }

 @Test
                                                                               public void testGetLInfNorm_NegativeValues() {
                                                                                   ArrayRealVector vector = new ArrayRealVector(new double[]{-1.0, -2.5, -3.2, -1.8});
                                                                                   assertEquals(3.2, vector.getLInfNorm(), 0.0);
                                                                               }

 @Test
                                                                               public void testGetLInfNorm_MixedValues() {
                                                                                   ArrayRealVector vector = new ArrayRealVector(new double[]{-1.0, 2.5, -3.2, 1.8});
                                                                                   assertEquals(3.2, vector.getLInfNorm(), 0.0);
                                                                               }

 @Test
                                                                               public void testGetLInfNorm_WithNaN() {
                                                                                   ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, 2.0, Double.NaN, 3.0});
                                                                                   assertTrue(Double.isNaN(vector.getLInfNorm()));
                                                                               }

 @Test
                                                                               public void testGetLInfNorm_WithPositiveInfinity() {
                                                                                   ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, 2.0, Double.POSITIVE_INFINITY, 3.0});
                                                                                   assertEquals(Double.POSITIVE_INFINITY, vector.getLInfNorm(), 0.0);
                                                                               }

 @Test
                                                                               public void testGetLInfNorm_WithNegativeInfinity() {
                                                                                   ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, 2.0, Double.NEGATIVE_INFINITY, 3.0});
                                                                                   assertEquals(Double.POSITIVE_INFINITY, vector.getLInfNorm(), 0.0);
                                                                               }

 @Test
                                                                               public void testGetLInfNorm_LargeArray() {
                                                                                   double[] largeArray = new double[1000];
                                                                                   for (int i = 0; i < largeArray.length; i++) {
                                                                                       largeArray[i] = i % 100;
                                                                                   }
                                                                                   ArrayRealVector vector = new ArrayRealVector(largeArray);
                                                                                   assertEquals(99.0, vector.getLInfNorm(), 0.0);
                                                                               }

 @Test
                                                                               public void testGetLInfNorm_EqualAbsoluteValues() {
                                                                                   ArrayRealVector vector = new ArrayRealVector(new double[]{-5.0, 5.0, -5.0, 5.0});
                                                                                   assertEquals(5.0, vector.getLInfNorm(), 0.0);
                                                                               }

 @Test(expected = ArithmeticException.class)
                                                                       public void testMapInvToSelf_ZeroElementThrowsException() {
                                                                           double[] input = {1.0, 0.0, 2.0};
                                                                           
                                                                           ArrayRealVector vector = new ArrayRealVector(input);
                                                                           vector.mapInvToSelf();
                                                                       }

 @Test
                                                                  public void testMapAtanToSelfBoundaryCondition() {
                                                                      // Create a non-empty vector
                                                                      double[] testData = {1.0, 2.0, 3.0};
                                                                      ArrayRealVector vector = new ArrayRealVector(testData);
                                                                      
                                                                      // This should complete successfully with original code
                                                                      // But would throw ArrayIndexOutOfBoundsException with mutated code
                                                                      ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                                                      
                                                                      // Verify the operation was applied correctly to all elements
                                                                      assertEquals(testData.length, result.getDimension());
                                                                      for (int i = 0; i < testData.length; i++) {
                                                                          assertEquals(Math.atan(testData[i]), result.getEntry(i), 0.0001);
                                                                      }
                                                                      
                                                                      // Also test with empty array to ensure it handles zero-length case
                                                                      ArrayRealVector emptyVector = new ArrayRealVector(new double[0]);
                                                                      ArrayRealVector emptyResult = (ArrayRealVector) emptyVector.mapAtanToSelf();
                                                                      assertEquals(0, emptyResult.getDimension());
                                                                  }

 @Test
                                                             public void testMapAtanToSelf() {
                                                                 // Create test data with distinct values that will change when atan is applied
                                                                 double[] testData = {1.0, 2.0, 3.0}; // First element is important for detecting the mutant
                                                                 
                                                                 // Create vector and apply the operation
                                                                 ArrayRealVector vector = new ArrayRealVector(testData);
                                                                 ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                                                 
                                                                 // Verify the vector itself was returned (in-place modification)
                                                                 assertSame(vector, result);
                                                                 
                                                                 // Verify ALL elements were processed (this will fail if mutant is present)
                                                                 assertEquals(Math.atan(1.0), result.getEntry(0), 0.0001); // First element check - detects mutant
                                                                 assertEquals(Math.atan(2.0), result.getEntry(1), 0.0001);
                                                                 assertEquals(Math.atan(3.0), result.getEntry(2), 0.0001);
                                                                 
                                                                 // Additional test with single element array to ensure full coverage
                                                                 double[] singleElement = {5.0};
                                                                 ArrayRealVector singleVector = new ArrayRealVector(singleElement);
                                                                 singleVector.mapAtanToSelf();
                                                                 assertEquals(Math.atan(5.0), singleVector.getEntry(0), 0.0001);
                                                             }

 @Test
                                                        public void testMapAtanToSelfProcessesAllElements() {
                                                            // Create a vector with 3 elements to ensure we can detect the mutation
                                                            double[] testData = {1.0, 0.5, -0.5};
                                                            ArrayRealVector vector = new ArrayRealVector(testData);
                                                            
                                                            // Call the method under test
                                                            ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                                            
                                                            // Verify all elements were processed (original behavior)
                                                            // Check first element
                                                            assertEquals(Math.atan(testData[0]), result.getEntry(0), 0.0001);
                                                            // Check middle element
                                                            assertEquals(Math.atan(testData[1]), result.getEntry(1), 0.0001);
                                                            // Check last element - this would fail if mutation is present
                                                            assertEquals(Math.atan(testData[2]), result.getEntry(2), 0.0001);
                                                            
                                                            // Also verify the same object is returned (chaining support)
                                                            assertSame(vector, result);
                                                        }

 @Test
                                                   public void testMapAtanToSelfDetectsSkippedElementsMutant() {
                                                       // Create test data with distinct values at even and odd indices
                                                       double[] testData = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0};
                                                       ArrayRealVector vector = new ArrayRealVector(testData);
                                                       
                                                       // Call the method and cast the result
                                                       ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                                       
                                                       // Verify all elements were processed (mutant will fail for odd indices)
                                                       double[] resultData = result.getDataRef();
                                                       assertEquals(Math.atan(1.0), resultData[0], 0.0001);  // even index
                                                       assertEquals(Math.atan(2.0), resultData[1], 0.0001);  // odd index (mutant would fail here)
                                                       assertEquals(Math.atan(3.0), resultData[2], 0.0001);  // even index
                                                       assertEquals(Math.atan(4.0), resultData[3], 0.0001);  // odd index (mutant would fail here)
                                                       assertEquals(Math.atan(5.0), resultData[4], 0.0001);  // even index
                                                       assertEquals(Math.atan(6.0), resultData[5], 0.0001);  // odd index (mutant would fail here)
                                                       
                                                       // Also verify the returned object is the same instance (per method contract)
                                                       assertSame(vector, result);
                                                   }

 @Test
                                              public void testMapAtanToSelfDetectsAsinMutation() {
                                                  // Create test input where atan and asin produce different results
                                                  double[] input = {0.5, -0.5, 0.0, 0.707}; // 0.707 is ~sin(π/4)
                                                  
                                                  // Create vector and apply the operation
                                                  ArrayRealVector vector = new ArrayRealVector(input.clone());
                                                  ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                                  
                                                  // Verify each element was transformed with atan (not asin)
                                                  double[] expected = new double[input.length];
                                                  for (int i = 0; i < input.length; i++) {
                                                      expected[i] = Math.atan(input[i]);
                                                  }
                                                  
                                                  // Assert the actual results match expected atan values
                                                  assertArrayEquals(expected, result.getData(), 0.000001);
                                                  
                                                  // Additional check: verify it's not using asin
                                                  // This would fail if the mutation was present
                                                  for (int i = 0; i < input.length; i++) {
                                                      assertNotEquals("Element " + i + " was transformed with asin instead of atan",
                                                                    Math.asin(input[i]), result.getData()[i], 0.000001);
                                                  }
                                              }

 @Test
                                         public void testMapAtanToSelfDetectsNegationMutation() {
                                             // Create test data with values that will show difference between atan(x) and atan(-x)
                                             double[] testData = {0.5, 1.0, -0.5, -1.0, 0.0};
                                             ArrayRealVector vector = new ArrayRealVector(testData);
                                             
                                             // Make a copy of original data for comparison
                                             double[] originalData = testData.clone();
                                             
                                             // Apply the method
                                             ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                             
                                             // Verify the original vector was modified
                                             assertNotEquals(originalData, result.getData());
                                             
                                             // Verify each element was transformed correctly
                                             double[] expected = new double[testData.length];
                                             for (int i = 0; i < testData.length; i++) {
                                                 expected[i] = Math.atan(testData[i]);
                                                 assertEquals("Element at index " + i + " differs", 
                                                              expected[i], result.getData()[i], 1e-10);
                                             }
                                             
                                             // Additional check that would fail with the mutation
                                             // Since atan(-x) = -atan(x), the mutated version would produce negatives
                                             // of the expected values (except for 0)
                                             for (int i = 0; i < testData.length; i++) {
                                                 if (testData[i] != 0) {
                                                     assertNotEquals("Mutation not detected at index " + i,
                                                                    -expected[i], result.getData()[i], 1e-10);
                                                 }
                                             }
                                         }

 @Test
                                    public void testMapAtanToSelfDetectsMutant() {
                                        // Create test data with values where atan(x) is significantly different from atan(x+1)
                                        double[] testData = {0.0, 0.5, 1.0, 2.0, -1.0, -0.5};
                                        ArrayRealVector vector = new ArrayRealVector(testData.clone());
                                        
                                        // Apply the method
                                        ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                        
                                        // Verify each element was transformed correctly
                                        double[] expected = new double[testData.length];
                                        for (int i = 0; i < testData.length; i++) {
                                            expected[i] = Math.atan(testData[i]);
                                        }
                                        
                                        // This will fail if the mutant (data[i] + 1) is present
                                        assertArrayEquals(expected, result.getData(), 0.000001);
                                        
                                        // Additional check to ensure the method returns the same object (for chaining)
                                        assertSame(vector, result);
                                    }

 @Test
                               public void testMapAtanToSelf1() {
                                   // Create test data with values that will clearly show the difference
                                   double[] testData = {0.0, 0.5, 1.0, -0.5, -1.0};
                                   ArrayRealVector vector = new ArrayRealVector(testData);
                                   
                                   // Calculate expected results
                                   double[] expected = new double[testData.length];
                                   for (int i = 0; i < testData.length; i++) {
                                       expected[i] = Math.atan(testData[i]);
                                   }
                                   
                                   // Apply the method
                                   ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                   
                                   // Verify the results
                                   assertArrayEquals(expected, result.getData(), 1e-15);
                                   
                                   // Also verify the original vector was modified (since it's "ToSelf")
                                   assertArrayEquals(expected, vector.getData(), 1e-15);
                                   
                                   // Verify the method returns the same object (for method chaining)
                                   assertSame(vector, result);
                               }

 @Test
                          public void testMapAtanToSelfDetectsMutant1() {
                              // Create input array with distinct values
                              double[] input = {1.0, 2.0, 3.0};
                              ArrayRealVector vector = new ArrayRealVector(input);
                              
                              // Apply the operation
                              ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                              
                              // Verify each element has its own atan value
                              // This will fail if mutant is present (all values would be Math.atan(1.0))
                              assertEquals(Math.atan(1.0), result.getEntry(0), 0.0001);
                              assertEquals(Math.atan(2.0), result.getEntry(1), 0.0001);
                              assertEquals(Math.atan(3.0), result.getEntry(2), 0.0001);
                              
                              // Also verify the object identity for method chaining
                              assertSame(vector, result);
                          }

 @Test
                          public void testMapAtanToSelf2() {
                              // Create test data with various values including positive, negative and non-zero
                              double[] testData = {1.0, -1.0, 0.5, -0.5, 10.0, -10.0};
                              ArrayRealVector vector = new ArrayRealVector(testData);
                              
                              // Store expected results (atan of each element)
                              double[] expected = new double[testData.length];
                              for (int i = 0; i < testData.length; i++) {
                                  expected[i] = Math.atan(testData[i]);
                              }
                              
                              // Call the method
                              vector.mapAtanToSelf();
                              
                              // Get actual results
                              double[] actual = vector.getData();
                              
                              // Verify each element was properly transformed
                              for (int i = 0; i < testData.length; i++) {
                                  assertEquals("Element at index " + i + " should be atan of original value",
                                               expected[i], actual[i], 0.0001);
                              }
                              
                              // Additional check: verify no element is 0.0 (which would happen with the mutant)
                              for (int i = 0; i < testData.length; i++) {
                                  assertNotEquals("Element at index " + i + " should not be 0.0",
                                                 0.0, actual[i], 0.0001);
                              }
                          }

 @Test
                    public void testMapAtanToSelf_shouldReturnThisInstance() {
                        // Arrange
                        double[] testData = {1.0, 0.5, -0.5, -1.0};
                        ArrayRealVector vector = new ArrayRealVector(testData);
                        
                        // Act
                        ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                        
                        // Assert
                        // Verify the same instance is returned (not null)
                        assertSame("Method should return this instance", vector, result);
                        
                        // Verify the data was modified correctly (bonus verification)
                        double[] expectedData = new double[testData.length];
                        for (int i = 0; i < testData.length; i++) {
                            expectedData[i] = Math.atan(testData[i]);
                        }
                        assertArrayEquals(expectedData, result.getData(), 0.0001);
                    }

}
