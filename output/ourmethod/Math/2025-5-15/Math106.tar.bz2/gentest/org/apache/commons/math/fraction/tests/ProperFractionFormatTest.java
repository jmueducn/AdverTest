package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParsePosition;
import org.apache.commons.math.util.MathUtils;
 
public class ProperFractionFormatTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                           public void testParse_ValidFractionWithoutWholeNumber() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               String source = "3/4";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertEquals(3, result.getNumerator());
                               assertEquals(4, result.getDenominator());
                               assertEquals(source.length(), pos.getIndex());
                           }

 @Test
                           public void testParse_ValidFractionWithWholeNumber() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               String source = "1 3/4";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertEquals(7, result.getNumerator());  // (1*4 + 3)/4
                               assertEquals(4, result.getDenominator());
                               assertEquals(source.length(), pos.getIndex());
                           }

 @Test
                           public void testParse_NegativeWholeNumber() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               String source = "-2 1/2";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertEquals(-5, result.getNumerator());  // (-2*2 + 1)/2
                               assertEquals(2, result.getDenominator());
                               assertEquals(source.length(), pos.getIndex());
                           }

 @Test
                           public void testParse_JustWholeNumber() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               String source = "5";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertEquals(5, result.getNumerator());
                               assertEquals(1, result.getDenominator());
                               assertEquals(source.length(), pos.getIndex());
                           }

 @Test
                           public void testParse_WithWhitespace() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               String source = "  2   3  /  4  ";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertEquals(11, result.getNumerator());  // (2*4 + 3)/4
                               assertEquals(4, result.getDenominator());
                               assertEquals(source.length(), pos.getIndex());
                           }

 @Test
                           public void testParse_InvalidWholeNumber() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               String source = "abc 1/2";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertNull(result);
                               assertEquals(0, pos.getIndex());
                           }

 @Test
                           public void testParse_InvalidNumerator() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               String source = "1 abc/2";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertNull(result);
                               assertEquals(0, pos.getIndex());
                           }

 @Test
                           public void testParse_NegativeNumerator() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               String source = "1 -3/4";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertNull(result);
                               assertEquals(0, pos.getIndex());
                           }

 @Test
                           public void testParse_MissingSlash() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               String source = "1 34";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertNull(result);
                               assertEquals(0, pos.getIndex());
                           }

 @Test
                           public void testParse_InvalidDenominator() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               String source = "1 3/abc";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertNull(result);
                               assertEquals(0, pos.getIndex());
                           }

 @Test
                           public void testParse_NegativeDenominator() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               String source = "1 3/-4";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertNull(result);
                               assertEquals(0, pos.getIndex());
                           }

 @Test
                           public void testParse_InvalidCharacterAfterSlash() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               String source = "1 3:4";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertNull(result);
                               assertEquals(0, pos.getIndex());
                           }

 @Test
                           public void testParse_EmptyString() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               String source = "";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertNull(result);
                               assertEquals(0, pos.getIndex());
                           }

 @Test
                           public void testParse_NullString() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               ParsePosition pos = new ParsePosition(0);
                               
                               thrown.expect(NullPointerException.class);
                               format.parse(null, pos);
                           }

 @Test
                           public void testParse_NullParsePosition() {
                               ProperFractionFormat format = new ProperFractionFormat();
                               String source = "1/2";
                               
                               thrown.expect(NullPointerException.class);
                               format.parse(source, null);
                           }

 @Test
                           public void testParse_WithCustomNumberFormat() {
                               NumberFormat customFormat = NumberFormat.getInstance();
                               ProperFractionFormat format = new ProperFractionFormat(customFormat);
                               ParsePosition pos = new ParsePosition(0);
                               String source = "1,000 3/4";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertEquals(10003, result.getNumerator());  // (1000*4 + 3)/4
                               assertEquals(4, result.getDenominator());
                               assertEquals(source.length(), pos.getIndex());
                           }

 @Test
                           public void testParse_WithDifferentFormats() {
                               NumberFormat wholeFormat = NumberFormat.getInstance();
                               NumberFormat numFormat = NumberFormat.getInstance();
                               NumberFormat denFormat = NumberFormat.getInstance();
                               ProperFractionFormat format = new ProperFractionFormat(wholeFormat, numFormat, denFormat);
                               ParsePosition pos = new ParsePosition(0);
                               String source = "1 3/4";
                               
                               Fraction result = format.parse(source, pos);
                               
                               assertEquals(7, result.getNumerator());
                               assertEquals(4, result.getDenominator());
                               assertEquals(source.length(), pos.getIndex());
                           }

 @Test
                   public void testParseWithWhitespaceBetweenComponents() {
                       // Setup
                       ProperFractionFormat parser = new ProperFractionFormat();
                       ParsePosition pos = new ParsePosition(0);
                       
                       // Test input with whitespace between whole, numerator and denominator
                       String input = "1 2 / 3"; // Note the spaces
                       
                       // Execute
                       Fraction result = parser.parse(input, pos);
                       
                       // Verify - with the mutant, parsing should fail because whitespace isn't skipped
                       assertNull("Parser should fail to parse when whitespace isn't properly handled", result);
                       assertEquals("Parse position should not advance when parsing fails", 0, pos.getIndex());
                       
                       // Additional verification that it's not failing for other reasons
                       // Try same input without whitespace
                       pos.setIndex(0);
                       String validInput = "1 2/3"; // No extra spaces
                       Fraction validResult = parser.parse(validInput, pos);
                       assertNotNull("Parser should handle valid input without extra whitespace", validResult);
                       assertEquals(1, validResult.getNumerator());
                       assertEquals(3, validResult.getDenominator());
                   }

 @Test
                 public void testParseDetectsNumeratorFormatMutation() {
                     // Setup different formats for whole and numerator
                     java.text.NumberFormat wholeFormat = new java.text.DecimalFormat("0");
                     java.text.NumberFormat numeratorFormat = new java.text.DecimalFormat("0.0");
                     
                     // Create ProperFractionFormat with different formats
                     ProperFractionFormat parser = new ProperFractionFormat(
                         wholeFormat, 
                         numeratorFormat, 
                         new java.text.DecimalFormat("0") // denominator format
                     );
                     
                     // Test input - "1 1.5/2" should parse differently based on format
                     // With original code: whole=1, numerator=1.5 (but since numeratorFormat expects int, should fail)
                     // With mutated code: whole=1, numerator=1 (since using wholeFormat)
                     java.text.ParsePosition pos = new java.text.ParsePosition(0);
                     String source = "1 1.5/2";
                     
                     // Execute parse
                     Fraction result = parser.parse(source, pos);
                     
                     // Verify - original should return null (numerator parse fails)
                     // Mutated would return Fraction(3,2) (1 + 1/2)
                     assertNull("Should return null when numerator format doesn't match", result);
                     assertEquals("Error index should be set", 2, pos.getErrorIndex());
                     
                     // Additional verification - test with valid numerator format
                     parser = new ProperFractionFormat(
                         new java.text.DecimalFormat("0"), 
                         new java.text.DecimalFormat("0"), 
                         new java.text.DecimalFormat("0")
                     );
                     pos = new java.text.ParsePosition(0);
                     result = parser.parse("1 1/2", pos);
                     assertNotNull("Should parse valid fraction", result);
                     assertEquals(3, result.getNumerator());
                     assertEquals(2, result.getDenominator());
                 }

 @Test
             public void testParseWithoutDenominatorDetectsMutant() {
                 // Setup
                 ProperFractionFormat formatter = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "3"; // Just a numerator, no denominator
                 
                 // Execute
                 Fraction result = formatter.parse(source, pos);
                 
                 // Verify
                 assertNotNull("Should return a Fraction for valid numerator-only input", result);
                 assertEquals("Numerator should match input value", 3, result.getNumerator());
                 assertEquals("Denominator should be 1 for numerator-only input", 1, result.getDenominator());
                 
                 // This assertion would catch the mutant:
                 // Mutant would return numerator=1, denominator=3
                 // Original returns numerator=3, denominator=1
             }

 @Test
            public void testParseWithInvalidSeparatorDetectsErrorPosition() {
                // Setup
                ProperFractionFormat formatter = new ProperFractionFormat();
                String source = "1 2 x 3"; // Invalid separator 'x'
                ParsePosition pos = new ParsePosition(0);
                
                // Execute
                Fraction result = formatter.parse(source, pos);
                
                // Verify
                assertNull("Should return null for invalid separator", result);
                assertEquals("Error index should be set to position of invalid separator", 4, pos.getErrorIndex());
                assertEquals("Index should be reset to initial position", 0, pos.getIndex());
            }

 @Test
          public void testParseWithDifferentNumeratorDenominatorFormats() {
              // Setup different formats for numerator and denominator
              java.text.NumberFormat numeratorFormat = new java.text.DecimalFormat("#");
              java.text.NumberFormat denominatorFormat = new java.text.DecimalFormat("0");
              java.text.NumberFormat wholeFormat = new java.text.DecimalFormat("#");
              
              // Create parser with different formats
              ProperFractionFormat parser = new ProperFractionFormat(
                  wholeFormat, numeratorFormat, denominatorFormat);
              
              // Test string that would parse differently with different formats
              // "1 1/01" - numerator format ("#") won't parse leading 0, denominator format ("0") will
              String source = "1 1/01";
              java.text.ParsePosition pos = new java.text.ParsePosition(0);
              
              // Execute parse
              Fraction result = parser.parse(source, pos);
              
              // Verify parsing succeeded (would fail with mutant using numerator format for denominator)
              assertNotNull("Should parse successfully with proper denominator format", result);
              assertEquals(1, result.getNumerator());
              assertEquals(1, result.getDenominator());  // Would be 0 if using numerator format
              
              // Verify position advanced correctly
              assertEquals(source.length(), pos.getIndex());
          }

 @Test
     public void testParseWithoutDenominatorDetectsMutant1() throws Exception {
         // Setup mocks and test data
         ProperFractionFormat format = new ProperFractionFormat();
         ParsePosition pos = new ParsePosition(0);
         String source = "3"; // Input without '/' character
         
         // Create spy without mocking protected methods
         ProperFractionFormat spyFormat = spy(format);
         
         // Mock whole number parsing to return null (not needed for this case)
         when(spyFormat.getWholeFormat().parse(anyString(), any(ParsePosition.class))).thenReturn(null);
         
         // Mock numerator parsing to return 3
         Number num = 3;
         when(spyFormat.getNumeratorFormat().parse(anyString(), any(ParsePosition.class))).thenReturn(num);
         
         // Use reflection to mock parseNextCharacter to return 0 (no '/' character)
         Method parseNextCharMethod = ProperFractionFormat.class.getSuperclass()
                 .getDeclaredMethod("parseNextCharacter", String.class, ParsePosition.class);
         parseNextCharMethod.setAccessible(true);
         when(parseNextCharMethod.invoke(spyFormat, anyString(), any(ParsePosition.class))).thenReturn((char)0);
         
         // Execute
         Fraction result = spyFormat.parse(source, pos);
         
         // Verify
         assertNotNull("Result should not be null", result);
         assertEquals("Numerator should be exactly 3", 3, result.getNumerator());
         assertEquals("Denominator should be 1", 1, result.getDenominator());
         
         // This test will fail if the mutant is present because:
         // - Original code returns Fraction(3, 1)
         // - Mutant returns Fraction(4, 1)
         // The assertion on numerator will catch this difference
     }

 @Test
 public void testParse_NoDenominator_ReturnsFractionWithDenominatorOne() {
     // Setup
     ProperFractionFormat formatter = new ProperFractionFormat();
     ParsePosition pos = new ParsePosition(0);
     String source = "3";  // Just a numerator, no denominator
     
     // Execute
     Fraction result = formatter.parse(source, pos);
     
     // Verify
     assertNotNull("Should return a Fraction object", result);
     assertEquals("Numerator should match input", 3, result.getNumerator());
     assertEquals("Denominator should be 1 when no denominator provided", 
                  1, result.getDenominator());
     
     // Also test position was advanced correctly
     assertEquals("Parse position should advance", 
                  source.length(), pos.getIndex());
 }

 @Test
 public void testParse_NoDenominatorWithWhitespace_ReturnsFractionWithDenominatorOne() {
     // Setup
     ProperFractionFormat formatter = new ProperFractionFormat();
     ParsePosition pos = new ParsePosition(0);
     String source = "5   ";  // Numerator with trailing whitespace
     
     // Execute
     Fraction result = formatter.parse(source, pos);
     
     // Verify
     assertNotNull("Should return a Fraction object", result);
     assertEquals("Numerator should match input", 5, result.getNumerator());
     assertEquals("Denominator should be 1 when no denominator provided", 
                  1, result.getDenominator());
     
     // Also test position was advanced past whitespace
     assertEquals("Parse position should advance past whitespace", 
                  source.length(), pos.getIndex());
 }

}
